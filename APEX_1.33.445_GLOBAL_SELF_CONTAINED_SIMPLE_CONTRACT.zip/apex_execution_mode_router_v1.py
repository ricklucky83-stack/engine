from __future__ import annotations
import csv, re, zipfile
from pathlib import Path
TRIGGERS=("RUN SKILL ENG","RUN SKILL ENGINE")
LIVE_LINE_RE=re.compile(r"(?m)^\s*1\s+\S+\s*$.*^\s*2\s+\S+\s*$.*^\s*3\s+\S+(?:\s+\S+)*\s*$.*^\s*4\s+\d+\s*$",re.S)

BOARD_COMMAND_RE=re.compile(r"^\s*(?:SHOW\s+)?BOARD(?:\s*!+)?\s*$",re.I)
FAST_PATH_RE=re.compile(r"\bFAST[ _-]?PATH\b",re.I)
SHOW_METRICS_RE=re.compile(r"\bSHOW\s+(?:RUN\s+)?METRICS(?:\s+AND\s+STATS)?\b",re.I)
BARE_MIN_RE=re.compile(r"\bBARE[ _-]?MIN\b",re.I)

def command_authority(command_text:str='', execution_mode:str='LIVE_PRODUCTION')->dict:
    board=bool(BOARD_COMMAND_RE.match(command_text or ''))
    live=(execution_mode=='LIVE_PRODUCTION')
    fast=bool(FAST_PATH_RE.search(command_text or ''))
    metrics=bool(SHOW_METRICS_RE.search(command_text or ''))
    bare_min=bool(BARE_MIN_RE.search(command_text or ''))
    return {
        'USER_COMMAND_AUTHORITY': True,
        'ASSISTANT_OVERRIDE_ALLOWED': False,
        'UNAUTHORIZED_POLICY_MUTATION_ALLOWED': False,
        'UNPROVEN_ACTIVE_STATUS_ALLOWED': False,
        'COMMENTARY_MAY_REPLACE_REQUESTED_EXECUTION': False,
        'BOARD_COMMAND': board,
        'BOARD_COMMAND_REQUIRES_IMMEDIATE_BOARD_PAYLOAD': bool(live and board),
        'FAST_PATH': fast,
        'FAST_PATH_STALL_FAILURE_HARD_BLOCK': bool(live and fast),
        'FAST_PATH_SEMANTIC_STATE_PARITY_REQUIRED': bool(live and fast),
        'FAST_PATH_STALE_RUNTIME_QUARANTINE_REQUIRED': bool(live and fast),
        'FAST_PATH_ENUMERATION_HARD_BAN': bool(live and fast),
        'FAST_PATH_HASH_POLICY': 'OFF',
        'FAST_PATH_HASH_CHECKS_ENABLED': False,
        'FAST_PATH_BUNDLE_HASH_CHECK_ENABLED': False,
        'FAST_PATH_ENCODED_HASH_CHECK_ENABLED': False,
        'FAST_PATH_INTERNAL_MANIFEST_HASH_CHECK_ENABLED': False,
        'FAST_PATH_NESTED_MANIFEST_HASH_CHECK_ENABLED': False,
        'FAST_PATH_HASH_REPAIR_ALLOWED': False,
        'FAST_PATH_POINTER_ROTATION_ALLOWED': False if live and fast else None,
        'FAST_PATH_STATE_MUTATION_ALLOWED': False,
        'FAST_PATH_HASH_OPERATIONS_REQUIRE_EXPLICIT_USER_COMMAND': True,
        'SHOW_EVERY_EXECUTION_STEP': True if live else None,
        'EXECUTION_STEP_STREAM_REQUIRED': True if live else None,
        'EXECUTION_STEP_OMISSION_ALLOWED': False if live else None,
        'EXECUTION_STEP_NARRATIVE_ALLOWED': False if live else None,
        'EXECUTION_STEP_FORMAT': 'STEP_NN_ACTION' if live else None,
        'MAX_NON_EXECUTION_ACTIONS_BEFORE_LAUNCH': 2 if live and fast else None,
        'SHOW_RUN_METRICS': metrics,
        'BARE_MIN': bare_min,
        'ENGINE_PROFILE': 'BARE_MIN_SIMPLE' if bare_min else 'REGULAR_PRODUCTION',
        'REGULAR_ENGINE_MUTATION_ALLOWED': False if bare_min else None,
        'LIVE_AUDITS_ENABLED': False if live else None,
        'LIVE_DIAGNOSTICS_ENABLED': False if live else None,
        'LIVE_DIAGNOSTIC_TESTS_ENABLED': False if live else None,
        'LIVE_REGRESSION_STRESS_TESTS_ENABLED': False if live else None,
        'LIVE_NESTED_ENGINE_MANIFEST_SCAN_ENABLED': False if live else None,
        'LIVE_REDUNDANT_SOURCE_HASH_AUDITS_ENABLED': False if live else None,
        'LIVE_EXECUTION_CRITICAL_VALIDATION_ONLY': True if live else None,
        'LIVE_NO_AUDIT_DIAGNOSTIC_TEST_PATCH_ID': 'APEX_GLOBAL_LIVE_RUN_NO_AUDIT_DIAGNOSTIC_TEST_HARD_CORRECTIVE_ACTION_v1' if live else None,
        'CURRENT_MESSAGE_POOL_AUTHORITY_REQUIRED': bool(live and fast),
        'TERMINAL_ARTIFACT_RECONCILIATION_REQUIRED': bool(live and fast),
        'COMPLETED_BOARD_CHECK_BEFORE_USER_VISIBLE_FAILURE': bool(live and fast),
        'RUN_UNTIL_BOARD_OR_TRUE_RUN_INVALID': bool(live),
        'RECOVERABLE_CHILD_EXIT_TERMINAL_ALLOWED': False if live else None,
        'MISSING_BOARD_ARTIFACT_TERMINAL_ALLOWED': False if live else None,
        'AI_TERMINAL_DECISION_REQUIRED_IS_CONTINUATION': False,
        'SAME_SLATE_RERUN_PROHIBITED_WHEN_VERIFIED_BOARD_EXISTS': bool(live and fast),
        'TOOL_RUNTIME_THROTTLE_IS_RECOVERABLE_TRANSPORT_SIGNAL': bool(live and fast),
        'STATE_POINTER_SESSION_CACHE_REQUIRED': False,
        'MACHINE_STATUS_ALLOWED_ONLY_WHEN_PROCESS_PROVEN_ACTIVE': bool(live and fast),
        'TERMINAL_USER_PAYLOAD_ALLOWLIST': ['FINAL_BOARD','RUN_METRICS','RUN_INVALID_TRUE_IMPOSSIBILITY','MACHINE_STATUS_IF_PROVEN_ACTIVE_GT_15S'] if live else ['NORMAL'],
    }

def _header_has_rank_lineup(text:str)->bool:
    try: row=next(csv.reader([text.splitlines()[0]]))
    except Exception: return False
    cols={re.sub(r"[^a-z0-9]+","",x.lower()) for x in row}
    return "rank" in cols and "lineup" in cols

def is_contest_results_file(path:str|Path)->bool:
    p=Path(path); name=p.name.lower()
    if re.search(r"contest[-_ ]?standings|contest.*results",name): return True
    if not p.exists() or not p.is_file(): return False
    try:
        if p.suffix.lower()=='.csv':
            return _header_has_rank_lineup(p.read_text(encoding='utf-8-sig',errors='ignore')[:65536])
        if p.suffix.lower()=='.zip':
            with zipfile.ZipFile(p) as z:
                for member in z.namelist():
                    if member.lower().endswith('.csv'):
                        with z.open(member) as f:
                            head=f.read(65536).decode('utf-8-sig','ignore')
                        if _header_has_rank_lineup(head): return True
    except Exception: return False
    return False

def classify_execution_mode(command_text:str='', attachments:list[str]|tuple[str,...]=()):
    contest=[str(Path(x)) for x in attachments if is_contest_results_file(x)]
    trigger=any(t in command_text.upper() for t in TRIGGERS)
    template=bool(LIVE_LINE_RE.search(command_text))
    if contest:
        return {**command_authority(command_text,'POSTLOCK_DIAGNOSTIC'),'EXECUTION_MODE':'POSTLOCK_DIAGNOSTIC','MODE_SIGNAL':'CONTEST_RESULTS_FILE','CONTEST_FILE_DETECTED':True,'CONTEST_FILES':contest,'LIVE_TEMPLATE_DETECTED':template,'TRIGGER_DETECTED':trigger}
    if template:
        return {**command_authority(command_text,'LIVE_PRODUCTION'),'EXECUTION_MODE':'LIVE_PRODUCTION','MODE_SIGNAL':'LIVE_RUN_TEMPLATE','CONTEST_FILE_DETECTED':False,'CONTEST_FILES':[],'LIVE_TEMPLATE_DETECTED':True,'TRIGGER_DETECTED':trigger}
    if trigger:
        return {**command_authority(command_text,'LIVE_PRODUCTION'),'EXECUTION_MODE':'LIVE_PRODUCTION','MODE_SIGNAL':'ACTIVATION_TRIGGER_NO_CONTEST_FILE','CONTEST_FILE_DETECTED':False,'CONTEST_FILES':[],'LIVE_TEMPLATE_DETECTED':template,'TRIGGER_DETECTED':True}
    return {**command_authority(command_text,'UNRESOLVED'),'EXECUTION_MODE':'UNRESOLVED','MODE_SIGNAL':'NO_AUTHORITATIVE_SIGNAL','CONTEST_FILE_DETECTED':False,'CONTEST_FILES':[],'LIVE_TEMPLATE_DETECTED':template,'TRIGGER_DETECTED':False}
