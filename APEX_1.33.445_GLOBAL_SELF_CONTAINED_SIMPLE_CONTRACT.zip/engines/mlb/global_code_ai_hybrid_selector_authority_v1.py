from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Dict, List, Mapping, Sequence, Tuple
import json

PATCH_ID = "GLOBAL_CODE_AI_HYBRID_SELECTOR_AUTHORITY_v1"
PRODUCTION_SELECTOR = "CODE_AI_HYBRID_SELECTOR"
DETERMINISTIC_CODE_ONLY_SELECTOR = "DIAGNOSTIC_COMPARATOR_ONLY"
SELECTOR_REPLACEMENT_REQUIRES_EXPLICIT_USER_AUTHORIZATION = True

class GlobalHybridSelectorFailure(RuntimeError):
    pass

@dataclass(frozen=True)
class Candidate:
    lineup_id: str
    players: Tuple[str, ...]
    salary: int
    selector_eligible: bool
    legal: bool
    active_verified: bool
    metrics: Mapping[str, float]
    structure_family: str
    salary_geometry: str

@dataclass(frozen=True)
class AISelection:
    lineup_id: str
    priority: int
    reason_codes: Tuple[str, ...]

ALLOWED_REASON_CODES = frozenset({
    "ELITE_WIN_PATH",
    "ELITE_TOP_0_1_PATH",
    "ELITE_TOP_1_PATH",
    "P99_TAIL",
    "CVAR99_TAIL",
    "P95_TAIL",
    "CORRELATION_PATH",
    "LEVERAGE_PATH",
    "LOW_DUPLICATION_PATH",
    "SALARY_GEOMETRY_PATH",
    "STRUCTURE_DIVERSIFICATION",
    "PORTFOLIO_MARGINAL_VALUE",
})

def _candidate_row(c: Candidate) -> dict:
    return {
        "lineup_id": c.lineup_id,
        "players": list(c.players),
        "salary": c.salary,
        "selector_eligible": c.selector_eligible,
        "legal": c.legal,
        "active_verified": c.active_verified,
        "metrics": dict(sorted(c.metrics.items())),
        "structure_family": c.structure_family,
        "salary_geometry": c.salary_geometry,
    }

def freeze_candidates(candidates: Sequence[Candidate]) -> str:
    # Preserve the exact canonical hash semantics without materializing a second
    # full candidate matrix or one giant JSON string. This is critical for large
    # Classic slates where every Phase-2 lineup must remain selector-visible.
    ordered = sorted(candidates, key=lambda c: c.lineup_id)
    seen = set()
    h = sha256()
    h.update(b"[")
    first = True
    for c in ordered:
        if c.lineup_id in seen:
            raise GlobalHybridSelectorFailure("DUPLICATE_LINEUP_ID")
        seen.add(c.lineup_id)
        if not c.legal:
            raise GlobalHybridSelectorFailure(f"ILLEGAL_CANDIDATE:{c.lineup_id}")
        if not c.active_verified:
            raise GlobalHybridSelectorFailure(f"INACTIVE_CANDIDATE:{c.lineup_id}")
        if len(c.players) != len(set(c.players)):
            raise GlobalHybridSelectorFailure(f"DUPLICATE_PLAYER:{c.lineup_id}")
        if not first:
            h.update(b",")
        first = False
        h.update(json.dumps(_candidate_row(c), sort_keys=True, separators=(",", ":")).encode())
    h.update(b"]")
    return h.hexdigest()

def build_ai_review_packet(
    candidates: Sequence[Candidate],
    *,
    sport: str,
    mode: str,
    prelock: bool,
) -> Mapping[str, object]:
    if not prelock:
        raise GlobalHybridSelectorFailure("POST_LOCK_AI_SELECTION_PROHIBITED")
    freeze_hash = freeze_candidates(candidates)
    eligible_count = sum(1 for c in candidates if c.selector_eligible)
    if not eligible_count:
        raise GlobalHybridSelectorFailure("ZERO_SELECTOR_ELIGIBLE_ROWS")
    # The full matrix remains in selector_candidates and is reviewed by the
    # production selector. Persist only the immutable freeze identity here so
    # the audit packet does not duplicate hundreds of thousands of rows in RAM.
    return {
        "patch_id": PATCH_ID,
        "selector_mode": PRODUCTION_SELECTOR,
        "sport": sport,
        "mode": mode,
        "candidate_freeze_hash": freeze_hash,
        "candidate_count": len(candidates),
        "eligible_count": eligible_count,
        "allowed_reason_codes": sorted(ALLOWED_REASON_CODES),
        "candidate_storage": "STREAMED_HASH_ONLY_FULL_SELECTOR_REVIEW",
        "candidates": [],
    }

def validate_ai_selection(
    candidates: Sequence[Candidate],
    selections: Sequence[AISelection],
    *,
    expected_freeze_hash: str,
    board_size: int,
    allow_exact_duplicates: bool = False,
) -> Tuple[Candidate, ...]:
    if freeze_candidates(candidates) != expected_freeze_hash:
        raise GlobalHybridSelectorFailure("FROZEN_MATRIX_HASH_MISMATCH")
    if len(selections) != board_size:
        raise GlobalHybridSelectorFailure("AI_BOARD_SIZE_MISMATCH")

    by_id: Dict[str, Candidate] = {c.lineup_id: c for c in candidates}
    out: List[Candidate] = []
    used_ids = set()
    used_player_sets = set()

    for s in sorted(selections, key=lambda x: x.priority):
        if s.lineup_id not in by_id:
            raise GlobalHybridSelectorFailure(f"AI_CREATED_UNSEEN_LINEUP:{s.lineup_id}")
        c = by_id[s.lineup_id]
        if not c.selector_eligible:
            raise GlobalHybridSelectorFailure(f"AI_SELECTED_INELIGIBLE_LINEUP:{s.lineup_id}")
        if s.lineup_id in used_ids:
            raise GlobalHybridSelectorFailure(f"AI_DUPLICATE_LINEUP_ID:{s.lineup_id}")
        if not s.reason_codes:
            raise GlobalHybridSelectorFailure(f"AI_MISSING_REASON_CODES:{s.lineup_id}")
        invalid = set(s.reason_codes) - ALLOWED_REASON_CODES
        if invalid:
            raise GlobalHybridSelectorFailure(
                f"AI_INVALID_REASON_CODES:{s.lineup_id}:{','.join(sorted(invalid))}"
            )
        key = tuple(sorted(c.players))
        if not allow_exact_duplicates and key in used_player_sets:
            raise GlobalHybridSelectorFailure(f"FINAL_ENTRY_EXACT_DUPLICATE:{s.lineup_id}")
        used_ids.add(s.lineup_id)
        used_player_sets.add(key)
        out.append(c)

    return tuple(out)

def architecture_change_guard(
    *,
    requested_change: str,
    explicit_user_authorization: bool,
) -> None:
    architectural_terms = {
        "replace selector",
        "change selector",
        "code-only selector",
        "ai-only selector",
        "new selector architecture",
    }
    if any(term in requested_change.lower() for term in architectural_terms):
        if not explicit_user_authorization:
            raise GlobalHybridSelectorFailure(
                "ARCHITECTURE_CHANGE_BLOCKED:ASK_USER_BEFORE_CHANGE"
            )
