#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, os, subprocess, sys, tempfile
from pathlib import Path

_STATE_ROOT_FOR_IMPORTS = Path(__file__).resolve().parents[2]
if str(_STATE_ROOT_FOR_IMPORTS) not in sys.path:
    sys.path.insert(0, str(_STATE_ROOT_FOR_IMPORTS))
from engines.common.mandatory_prebuild_roster_gate_v1 import require_prebuild_roster_check
BASE=Path(__file__).resolve().parent
STATE_ROOT=BASE.parents[1]
CLASSIC_RESUMABLE_CONTROLLER=BASE/'mlb_classic_resumable_controller_v1.py'
SHOWDOWN_CONTROLLER=BASE/'mlb_showdown_chunk_stream_controller_v1.py'
SS_HRS_CONTROLLER=BASE/'mlb_ss_hrs_chunk_stream_controller_v1.py'
MANIFEST=BASE/'APEX_MLB_RAW_POOL_RUNTIME_v1_20_3.manifest.json'
POSTLOCK_ROUTER=STATE_ROOT/'apex_postlock_check_router_v1.py'

def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def validate()->dict:
    m=json.loads(MANIFEST.read_text()); failures=[]; files={}
    for rel,expected in m['FILES'].items():
        root_candidate=STATE_ROOT/rel; base_candidate=BASE/rel; p=root_candidate if root_candidate.exists() else base_candidate; actual=sha256(p) if p.exists() else None
        status='PASS' if actual==expected else ('MISSING' if actual is None else 'HASH_MISMATCH')
        files[rel]={'status':status,'expected_sha256':expected,'actual_sha256':actual}
        if status!='PASS': failures.append(f'{status}:{rel}')
    out={'PATCH':m['PATCH'],'STATE_VERSION':m['STATE_VERSION'],'STATUS':'PASS' if not failures else 'FAIL','FAILURES':failures,'FILES':files}
    if failures: raise RuntimeError('ENGINE_INTEGRITY_HALT:'+'|'.join(failures))
    return out

def add_run_args(p):
    p.add_argument('--player-pool',required=True); p.add_argument('--field-size',required=True,type=int); p.add_argument('--execution-id',required=True); p.add_argument('--availability-receipt')
    p.add_argument('--contest-file'); p.add_argument('--phase2-manifest'); p.add_argument('--board'); p.add_argument('--receipt'); p.add_argument('--output-dir',default='/mnt/data'); p.add_argument('--board-size',type=int,default=10); p.add_argument('--seed',type=int)
    p.add_argument('--postseal-winner-json',help='Validation only; prohibited in forward-blind production runs.')

def _env_args()->argparse.Namespace:
    mode=str(os.environ.get('APEX_SPORT_MODE') or os.environ.get('APEX_MODE') or '').strip().upper()
    command={'CLASSIC':'run-classic','SHOWDOWN':'run-showdown','SD':'run-showdown','HRS':'run-hrs','SS_HRS':'run-ss-hrs'}.get(mode)
    if not command: raise RuntimeError(f'RUN_INVALID:MLB_ENV_DISPATCH_MODE_MISSING_OR_INVALID:{mode or "EMPTY"}')
    runtime_pool=str(os.environ.get('APEX_PLAYER_POOL') or '').strip()
    original_pool=str(os.environ.get('APEX_ORIGINAL_PLAYER_POOL') or runtime_pool).strip()
    receipt=str(os.environ.get('APEX_PREBUILD_AVAILABILITY_RECEIPT') or '').strip()
    field_size=int(os.environ.get('APEX_FIELD_SIZE') or 0); execution_id=str(os.environ.get('APEX_EXECUTION_ID') or field_size)
    output_dir=str(os.environ.get('APEX_OUTPUT_DIR') or '/mnt/data'); board_size=int(os.environ.get('APEX_BOARD_SIZE') or 5)
    if not runtime_pool or not Path(runtime_pool).exists(): raise RuntimeError('RUN_INVALID:MLB_ENV_DISPATCH_RUNTIME_POOL_MISSING')
    if not original_pool or not Path(original_pool).exists(): raise RuntimeError('RUN_INVALID:MLB_ENV_DISPATCH_ORIGINAL_POOL_MISSING')
    if field_size<=0: raise RuntimeError('RUN_INVALID:MLB_ENV_DISPATCH_FIELD_SIZE_INVALID')
    return argparse.Namespace(command=command,player_pool=runtime_pool,availability_pool=original_pool,field_size=field_size,execution_id=execution_id,availability_receipt=receipt or None,contest_file=os.environ.get('APEX_CONTEST_FILE'),phase2_manifest=None,board=None,receipt=None,output_dir=output_dir,board_size=board_size,seed=int(os.environ['APEX_SEED']) if os.environ.get('APEX_SEED') else None,postseal_winner_json=None)

def main()->int:
    if len(sys.argv)==1:
        args=_env_args()
    else:
        ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='command',required=True); sub.add_parser('validate')
        c=sub.add_parser('run-classic'); add_run_args(c)
        s=sub.add_parser('run-showdown'); add_run_args(s)
        h=sub.add_parser('run-hrs'); add_run_args(h)
        sh=sub.add_parser('run-ss-hrs'); add_run_args(sh)
        args=ap.parse_args()
    if args.command=='validate':
        receipt=validate()
        print(json.dumps(receipt,indent=2))
        return 0
    mode={'run-classic':'CLASSIC','run-showdown':'SHOWDOWN','run-hrs':'HRS','run-ss-hrs':'SS_HRS'}[args.command]
    if args.contest_file:
        cmd=[sys.executable,str(POSTLOCK_ROUTER),'--contest',str(Path(args.contest_file).resolve()),'--output-dir',str(Path(args.output_dir).resolve()),'--sport','MLB','--mode',mode,'--player-pool',str(Path(args.player_pool).resolve())]
        for flag,value in (('--phase2-manifest',args.phase2_manifest),('--board',args.board),('--receipt',args.receipt)):
            if value: cmd.extend([flag,str(Path(value).resolve())])
        return subprocess.run(cmd,cwd=str(STATE_ROOT),check=False).returncode
    if args.postseal_winner_json:
        raise RuntimeError('RUN_INVALID_POSTSEAL_RESULT_INPUT_ON_LIVE_PRODUCTION')
    roster_pool=getattr(args,'availability_pool',args.player_pool)
    roster_gate=require_prebuild_roster_check(args.availability_receipt,sport='MLB',mode=mode,pool_path=roster_pool,execution_id=args.execution_id,field_size=args.field_size)
    source_pool=Path(args.player_pool).resolve()
    out_players=set(roster_gate.out_players)
    if not out_players:
        verified_pool=source_pool
    else:
        output_dir=Path(args.output_dir).resolve(); output_dir.mkdir(parents=True,exist_ok=True)
        with source_pool.open('r',newline='',encoding='utf-8-sig') as src:
            reader=csv.DictReader(src); fields=reader.fieldnames or []
            player_col=next((x for x in fields if x.strip().upper()=='PLAYER'),None)
            if player_col is None: raise RuntimeError('RUN_INVALID:PLAYER_POOL_PLAYER_COLUMN_MISSING')
            rows=[row for row in reader if str(row.get(player_col,'')).strip() not in out_players]
        fd,tmp_name=tempfile.mkstemp(prefix=f'{args.execution_id}_roster_',suffix='.csv',dir=str(output_dir))
        os.close(fd); verified_pool=Path(tmp_name)
        with verified_pool.open('w',newline='',encoding='utf-8') as dst:
            writer=csv.DictWriter(dst,fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    if args.command=='run-hrs':
        raise RuntimeError('RUN_INVALID:CHUNK_STREAM_ADAPTER_REQUIRED:MLB:HRS')
    runtime={'run-classic':CLASSIC_RESUMABLE_CONTROLLER,'run-showdown':SHOWDOWN_CONTROLLER,'run-ss-hrs':SS_HRS_CONTROLLER}[args.command]
    registry_path=STATE_ROOT/'engine_registry.json'
    registry_state_version=json.loads(registry_path.read_text(encoding='utf-8')).get('STATE_VERSION','UNKNOWN') if registry_path.exists() else 'UNKNOWN'
    env=dict(os.environ); env.update({'APEX_EXECUTION_ID':str(args.execution_id),'APEX_FIELD_SIZE':str(args.field_size),'APEX_PLAYER_POOL':str(verified_pool.resolve()),'APEX_PREBUILD_AVAILABILITY_RECEIPT':str(Path(args.availability_receipt).resolve()) if args.availability_receipt else '', 'APEX_PREBUILD_ROSTER_CHECK':'PASS' if roster_gate.source_count else 'CLASSIFICATION_ONLY_NONBLOCKING','APEX_OUTPUT_DIR':str(Path(args.output_dir).resolve()),'APEX_BOARD_SIZE':str(args.board_size),'APEX_ENGINE_DIR':str(BASE),'APEX_HANDOFF_DIR':str(BASE),'APEX_GLOBAL_STATE_VERSION':str(registry_state_version),'APEX_ACTIVE_GLOBAL_STATE_VERSION':str(registry_state_version),'APEX_EXECUTION_MODE':'PRODUCTION','APEX_DIAGNOSTICS_DISABLED':'1','APEX_BOARD_FIRST_RENDERING':'BOARD_FIRST_RENDERING_v2','APEX_PRODUCTION_TRIGGER_DIRECT_EXECUTION':'2','APEX_PRODUCTION_FAST':'1','APEX_POSTBOARD_ARTIFACTS':'0','APEX_CHUNK_STREAM_ONLY':'1','APEX_GLOBAL_CHUNK_STREAM_REQUIRED':'1','APEX_MONOLITHIC_LARGE_PHASE_EXECUTION':'PROHIBITED'})
    if args.contest_file: env['APEX_CONTEST_FILE']=str(Path(args.contest_file).resolve())
    if args.seed is not None: env['APEX_SEED']=str(args.seed)
    if args.postseal_winner_json:
        if args.command!='run-showdown': raise RuntimeError('POSTSEAL_WINNER_ONLY_SUPPORTED_FOR_SHOWDOWN_VALIDATION')
        env['APEX_POSTSEAL_WINNER_JSON']=args.postseal_winner_json
    cp=subprocess.run([sys.executable,str(runtime)],env=env,cwd=str(BASE),check=False)
    return cp.returncode
if __name__=='__main__': raise SystemExit(main())
