from __future__ import annotations
import hashlib, json, os
from pathlib import Path
import numpy as np

PATCH_ID='MLB_SD_CROSS_WORLD_LOCAL_MC_RECALL_SENTINEL_v2'
ELIGIBLE_STRUCTURES=('4-2|0SP','3-3|0SP')

def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def _core_key_void(a):
    a=np.ascontiguousarray(a,dtype=np.int32)
    return a.view(np.dtype((np.void,a.dtype.itemsize*a.shape[1]))).reshape(-1)

def _eligible_mask(meta):
    branch=np.asarray(meta['branch'],object)
    sp=np.asarray(meta['sp_count'],int)
    return (sp==0) & np.isin(branch,np.asarray(['4-2','3-3'],object))

def _cpt_preserved_supported_core_incidence(lineups,meta,born,min_support=4,lineup_chunk=100000):
    lu=np.asarray(lineups[:,:6],np.int32); born=np.asarray(born,np.int32)
    eligible=_eligible_mask(meta)
    parents=born[eligible[born]]
    if not len(parents):
        return (np.empty(0,np.int32),np.empty(0,np.int32),np.empty(0,np.int32),np.empty(0,np.int32),
                dict(ELIGIBLE_PARENTS=0,CORE_COUNT=0,ANCHOR_CORE_COUNT=0,CANDIDATE_UNION=0,PAIR_MEMBERSHIPS=0))
    br=lu[parents]; bu=np.sort(br[:,1:6],axis=1)
    bk=np.vstack([np.column_stack([br[:,0],np.delete(bu,drop,axis=1)]) for drop in range(5)]).astype(np.int32,copy=False)
    bv=_core_key_void(bk)
    unique_all=np.unique(bv)
    uv,counts=np.unique(bv,return_counts=True)
    anchors=np.sort(uv[counts>=int(min_support)])
    if not len(anchors):
        return (np.empty(0,np.int32),np.empty(0,np.int32),np.empty(0,np.int32),np.empty(0,np.int32),
                dict(ELIGIBLE_PARENTS=int(len(parents)),CORE_COUNT=int(len(unique_all)),ANCHOR_CORE_COUNT=0,CANDIDATE_UNION=0,PAIR_MEMBERSHIPS=0))
    pair_core=[]; pair_global=[]; elig_ids=np.flatnonzero(eligible); n=len(elig_ids)
    for off in range(0,n,int(lineup_chunk)):
        gids=elig_ids[off:min(n,off+int(lineup_chunk))]
        r=lu[gids]; ru=np.sort(r[:,1:6],axis=1)
        for drop in range(5):
            ck=np.column_stack([r[:,0],np.delete(ru,drop,axis=1)]).astype(np.int32,copy=False)
            cv=_core_key_void(ck); ix=np.searchsorted(anchors,cv); ok=ix<len(anchors)
            if ok.any():
                rows=np.flatnonzero(ok); rows=rows[anchors[ix[rows]]==cv[rows]]
                if len(rows):
                    pair_core.append(ix[rows].astype(np.int32,copy=False))
                    pair_global.append(gids[rows].astype(np.int32,copy=False))
    if not pair_global:
        return (np.empty(0,np.int32),np.empty(0,np.int32),np.empty(0,np.int32),np.empty(0,np.int32),
                dict(ELIGIBLE_PARENTS=int(len(parents)),CORE_COUNT=int(len(unique_all)),ANCHOR_CORE_COUNT=int(len(anchors)),CANDIDATE_UNION=0,PAIR_MEMBERSHIPS=0))
    pc=np.concatenate(pair_core); pg=np.concatenate(pair_global)
    order=np.lexsort((pg,pc)); pc=pc[order]; pg=pg[order]
    keep=np.ones(len(pc),bool); keep[1:]=(pc[1:]!=pc[:-1])|(pg[1:]!=pg[:-1]); pc=pc[keep]; pg=pg[keep]
    cand=np.unique(pg).astype(np.int32); ppos=np.searchsorted(cand,pg).astype(np.int32)
    # Assign every candidate to exactly one deterministic local neighborhood:
    # the anchored CPT-preserved core with the greatest native support.
    # Ties resolve by anchor-key order. This makes recurrence a true across-world
    # signal rather than repeated votes from several overlapping cores.
    anchor_support=np.asarray(counts[counts>=int(min_support)],np.int32)
    # counts above follow uv order; anchors are uv[counts>=min_support] and already sorted.
    ordp=np.argsort(ppos,kind='mergesort'); pp_s=ppos[ordp]; pc_s=pc[ordp]
    starts_p=np.r_[0,1+np.flatnonzero(pp_s[1:]!=pp_s[:-1])]; ends_p=np.r_[starts_p[1:],len(pp_s)]
    primary=np.full(len(cand),-1,np.int32)
    for a,b in zip(starts_p,ends_p):
        ci=int(pp_s[a]); cores=pc_s[a:b]; sup=anchor_support[cores]
        primary[ci]=int(cores[np.lexsort((cores,-sup))[0]])
    return cand,pc,ppos,primary,dict(ELIGIBLE_PARENTS=int(len(parents)),CORE_COUNT=int(len(unique_all)),ANCHOR_CORE_COUNT=int(len(anchors)),CANDIDATE_UNION=int(len(cand)),PAIR_MEMBERSHIPS=int(len(pg)),PRIMARY_CORE_POLICY='MAX_NATIVE_SUPPORT_THEN_CORE_KEY')

def _atomic_npz(path,**arrays):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_name(path.name+'.tmp')
    with open(tmp,'wb') as fh:
        np.savez_compressed(fh,**arrays); fh.flush(); os.fsync(fh.fileno())
    os.replace(tmp,path)

def cross_world_local_mc_recall_closure(born,lineups,meta,scores,mx,kth,top10_threshold,score_lineups,
                                        checkpoint_dir=None,windows=5,window_trials=2000,local_topk=1,
                                        require_windows=4,min_core_support=4,lineup_chunk=8192,trial_chunk=500,
                                        source_sha256=None):
    born=np.asarray(born,np.int32); scores=np.asarray(scores); total=int(windows)*int(window_trials)
    if total>len(scores): raise RuntimeError('CROSS_WORLD_LOCAL_MC_RECALL_INSUFFICIENT_PILOT_WORLDS')
    cand,pcore,ppos,primary_core,core_receipt=_cpt_preserved_supported_core_incidence(lineups,meta,born,min_support=min_core_support)
    base=dict(PATCH_ID=PATCH_ID,SOURCE_SHA256=source_sha256,WINDOWS=int(windows),WINDOW_TRIALS=int(window_trials),PILOT_TRIALS_USED=total,
              LOCAL_TOPK=int(local_topk),MIN_RECURRENT_WINDOWS=int(require_windows),ANCHOR_MIN_NATIVE_CORE_SUPPORT=int(min_core_support),
              SCORE_CHUNK_SIZE=int(lineup_chunk),CHUNK_AND_STREAM=True,WINDOW_CHECKPOINT_ATOMIC=True,
              CPT_ORIENTATION_PRESERVED_IN_LOCAL_CORE=True,ELIGIBLE_STRUCTURES=list(ELIGIBLE_STRUCTURES),GLOBAL_MC_PRIMARY_CHANGED=False,
              MC_ROLE='LOCAL_GENERATOR_RECALL_SENTINEL_ONLY',POSTLOCK_RESULTS_USED=False,PLAYER_NAME_CONSTANTS_USED=False,REALIZED_POINTS_USED=False,
              LEGAL_SOURCE='POST_STRUCTURAL_GATE_LEGAL_LINEUP_MATRIX',PARENT_BIRTHS=int(len(born)),**core_receipt)
    if not len(cand):
        return born,{**base,'TRIGGERED':False,'QUALIFIED_ADDITIONS':0,'EXPANDED_BIRTHS':int(len(born)),'WINDOW_CHECKPOINTS_LOADED':0,'WINDOW_CHECKPOINTS_COMMITTED':0,'WINDOW_QUALIFIED_COUNTS':[]}
    h=hashlib.sha256(); h.update(born.tobytes()); h.update(cand.tobytes()); h.update(np.asarray(mx[:total],np.float32).tobytes()); h.update(np.asarray(kth[:total],np.float32).tobytes()); h.update(np.asarray(top10_threshold[:total],np.float32).tobytes()); h.update(str(source_sha256 or '').encode()); fence=h.hexdigest()
    cdir=Path(checkpoint_dir) if checkpoint_dir is not None else None
    if cdir is not None: cdir.mkdir(parents=True,exist_ok=True)
    _chunk_stream_only=os.environ.get("APEX_CHUNK_STREAM_ONLY","0")=="1"
    _new_window_budget=max(1,int(os.environ.get("APEX_CHUNK_STREAM_CROSS_WORLD_WINDOW_BUDGET","1"))) if _chunk_stream_only else 1000000
    _new_windows_this_call=0
    minrank=np.full((int(windows),len(cand)),32767,np.int16); loaded_n=0; committed_n=0; qual_counts=[]; window_receipts=[]
    ordc=np.argsort(pcore,kind='mergesort'); sc=pcore[ordc]; sp=ppos[ordc]
    starts=np.r_[0,1+np.flatnonzero(sc[1:]!=sc[:-1])]; ends=np.r_[starts[1:],len(sc)]
    for w in range(int(windows)):
        ts=w*int(window_trials); te=ts+int(window_trials); loaded=False
        fp=(cdir/f'window_{w+1:02d}.npz') if cdir is not None else None; jp=(cdir/f'window_{w+1:02d}.json') if cdir is not None else None
        if fp is not None and fp.exists() and jp.exists():
            try:
                cp=json.loads(jp.read_text())
                if cp.get('FENCE')==fence and int(cp.get('START',-1))==ts and int(cp.get('END',-1))==te and cp.get('SOURCE_SHA256')==source_sha256:
                    z=np.load(fp); ids=np.asarray(z['candidate_ids'],np.int32)
                    if np.array_equal(ids,cand):
                        top01=np.asarray(z['top01']); win=np.asarray(z['win']); p99=np.asarray(z['p99']); p95=np.asarray(z['p95']); mean=np.asarray(z['mean']); loaded=True; loaded_n+=1
            except Exception: loaded=False
        chunks=0
        if not loaded:
            top01=np.empty(len(cand),np.float32); win=np.empty(len(cand),np.float32); p99=np.empty(len(cand),np.float32); p95=np.empty(len(cand),np.float32); mean=np.empty(len(cand),np.float32)
            for a in range(0,len(cand),int(lineup_chunk)):
                b=min(len(cand),a+int(lineup_chunk)); chunks+=1
                q=score_lineups(scores[ts:te],lineups,np.asarray(mx[ts:te]),np.asarray(kth[ts:te]),np.asarray(top10_threshold[ts:te]),cand[a:b],trial_chunk=trial_chunk)
                top01[a:b]=q['top01']; win[a:b]=q['win']; p99[a:b]=q['p99']; p95[a:b]=q['p95']; mean[a:b]=q['mean']
            if fp is not None:
                _atomic_npz(fp,top01=top01,win=win,p99=p99,p95=p95,mean=mean,candidate_ids=cand)
                cp=dict(PATCH_ID=PATCH_ID,SOURCE_SHA256=source_sha256,FENCE=fence,WINDOW=w+1,START=ts,END=te,ROWS=int(len(cand)),SCORE_CHUNKS=int(chunks),COMMIT_STATUS='COMMITTED')
                tmp=jp.with_name(jp.name+'.tmp'); tmp.write_text(json.dumps(cp,sort_keys=True,indent=2)); os.replace(tmp,jp); committed_n+=1
                _new_windows_this_call += 1
                if _chunk_stream_only and _new_windows_this_call >= _new_window_budget and w < int(windows)-1:
                    raise RuntimeError(f"CHECKPOINTED_CONTINUE:CROSS_WORLD_WINDOW:{w+1}")
        # Rank once inside each candidate's strongest native-supported local core.
        valid=np.flatnonzero(primary_core>=0)
        inc_order=np.lexsort((cand[valid],-mean[valid],-p95[valid],-p99[valid],-win[valid],-top01[valid],primary_core[valid]))
        vv=valid[inc_order]; pc_sorted=primary_core[vv]
        group_start=np.r_[0,1+np.flatnonzero(pc_sorted[1:]!=pc_sorted[:-1])]
        group_len=np.diff(np.r_[group_start,len(pc_sorted)])
        ranks=(np.arange(len(pc_sorted),dtype=np.int32)-np.repeat(group_start,group_len)+1).astype(np.int16)
        minrank[w,vv]=ranks
        qual_counts.append(int((minrank[w]<=int(local_topk)).sum()))
        window_receipts.append(dict(WINDOW=w+1,START=ts,END=te,ROWS=int(len(cand)),RESUMED=bool(loaded),COMMIT_STATUS='COMMITTED'))
    recurrence=(minrank<=int(local_topk)).sum(axis=0)
    hist={str(i):int((recurrence==i).sum()) for i in range(int(windows)+1)}
    add=cand[recurrence>=int(require_windows)]; expanded=np.unique(np.concatenate([born,add])).astype(np.int32)
    return expanded,{**base,'TRIGGERED':bool(len(expanded)>len(born)),'QUALIFIED_ADDITIONS':int(len(expanded)-len(born)),'EXPANDED_BIRTHS':int(len(expanded)),
                     'WINDOW_CHECKPOINT_FINGERPRINT':fence,'WINDOW_CHECKPOINTS_LOADED':int(loaded_n),'WINDOW_CHECKPOINTS_COMMITTED':int(committed_n),
                     'WINDOW_QUALIFIED_COUNTS':qual_counts,'RECURRENCE_HISTOGRAM':hist,'WINDOW_RECEIPTS':window_receipts}
