from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

PATCH_ID = 'MLB_CLASSIC_RS44_SAME_GAME_DEEP_REP_SATELLITE_v1'
GENERATOR_PATCH_ID = 'MLB_CLASSIC_BLIND_LOW_TOTAL_ANCHORED_44_STRATIFIED_COVERAGE_v7'
OBJECTIVE_SCORE_FLOOR = 0.80
MIN_CORE_TOP01_RETENTION = 0.50
REQUIRED_REP = 'LAST'
REQUIRED_BOARD_SIZE = 5

@dataclass(frozen=True)
class SatelliteCandidate:
    position: int
    lineup_id: str
    birth_source: str
    salary: int
    team_pair: tuple[str, str] | None
    rep_a: str | None
    rep_b: str | None
    objective_score: float
    top01_rate: float


def _is_mutual_opponent_pair(pair: tuple[str, str] | None, team_opponents: Mapping[str, str]) -> bool:
    if pair is None or len(pair) != 2:
        return False
    a, b = str(pair[0]), str(pair[1])
    return a != b and str(team_opponents.get(a, '')) == b and str(team_opponents.get(b, '')) == a


def apply_satellite(
    *,
    core_positions: Sequence[int],
    candidates: Sequence[SatelliteCandidate],
    team_opponents: Mapping[str, str],
    salary_floor: int,
    board_size: int = REQUIRED_BOARD_SIZE,
    objective_score_floor: float = OBJECTIVE_SCORE_FLOOR,
    min_core_top01_retention: float = MIN_CORE_TOP01_RETENTION,
) -> tuple[list[int], dict[str, Any]]:
    core = [int(x) for x in core_positions]
    receipt: dict[str, Any] = {
        'PATCH_ID': PATCH_ID,
        'STATUS': 'NOOP',
        'BOARD_SIZE': int(board_size),
        'CORE_SIZE_INPUT': len(core),
        'SATELLITE_SLOTS': 1,
        'OBJECTIVE_SCORE_FLOOR': float(objective_score_floor),
        'MIN_CORE_TOP01_RETENTION': float(min_core_top01_retention),
        'REQUIRED_REP_MODE': [REQUIRED_REP, REQUIRED_REP],
        'REQUIRED_STRUCTURE': '4-4_SAME_GAME_MUTUAL_OPPONENT',
        'REQUIRED_BIRTH_SOURCE': GENERATOR_PATCH_ID,
        'REQUIRED_SALARY': int(salary_floor),
        'RUNTIME_CONTEST_FIELDS_USED': False,
        'POSTLOCK_FIELDS_USED': False,
        'PLAYER_NAME_RULES': False,
        'TEAM_NAME_CONSTANTS': False,
    }
    if int(board_size) != REQUIRED_BOARD_SIZE or len(core) != REQUIRED_BOARD_SIZE:
        receipt['STATUS'] = 'NOOP_BOARD_SHAPE'
        return core, receipt

    by_pos = {int(c.position): c for c in candidates}
    core_top01 = [float(by_pos[p].top01_rate) for p in core if p in by_pos]
    if len(core_top01) != len(core):
        receipt['STATUS'] = 'NOOP_CORE_METRIC_PARITY'
        return core, receipt
    weakest_core_top01 = min(core_top01)
    tail_floor = weakest_core_top01 * float(min_core_top01_retention)
    receipt['WEAKEST_CORE_TOP01_RATE'] = float(weakest_core_top01)
    receipt['SATELLITE_TOP01_FLOOR'] = float(tail_floor)

    eligible: list[SatelliteCandidate] = []
    rejection_counts = {
        'BIRTH_SOURCE': 0, 'SALARY': 0, 'PAIR': 0, 'REP': 0, 'OBJECTIVE': 0, 'TAIL_RETENTION': 0, 'ALREADY_CORE': 0,
    }
    core_set = set(core)
    for c in candidates:
        if c.position in core_set:
            rejection_counts['ALREADY_CORE'] += 1; continue
        if str(c.birth_source) != GENERATOR_PATCH_ID:
            rejection_counts['BIRTH_SOURCE'] += 1; continue
        if int(c.salary) != int(salary_floor):
            rejection_counts['SALARY'] += 1; continue
        if not _is_mutual_opponent_pair(c.team_pair, team_opponents):
            rejection_counts['PAIR'] += 1; continue
        if str(c.rep_a) != REQUIRED_REP or str(c.rep_b) != REQUIRED_REP:
            rejection_counts['REP'] += 1; continue
        if float(c.objective_score) < float(objective_score_floor):
            rejection_counts['OBJECTIVE'] += 1; continue
        if float(c.top01_rate) < float(tail_floor):
            rejection_counts['TAIL_RETENTION'] += 1; continue
        eligible.append(c)

    receipt['REJECTION_COUNTS'] = rejection_counts
    receipt['ELIGIBLE_ROWS'] = len(eligible)
    if not eligible:
        receipt['STATUS'] = 'NOOP_NO_ELIGIBLE_SATELLITE'
        return core, receipt

    eligible.sort(key=lambda c: (-float(c.objective_score), -float(c.top01_rate), str(c.lineup_id)))
    pick = eligible[0]
    # The fifth Core-5 position is the parent's last marginal portfolio seat.
    # Preserve the first four common-world positions and use exactly one bounded satellite.
    out = core[:4] + [int(pick.position)]
    if len(set(out)) != REQUIRED_BOARD_SIZE:
        receipt['STATUS'] = 'NOOP_UNIQUENESS_GUARD'
        return core, receipt
    receipt.update({
        'STATUS': 'ACTIVE',
        'SELECTED_SATELLITE_POSITION': int(pick.position),
        'SELECTED_SATELLITE_LINEUP_ID': str(pick.lineup_id),
        'SELECTED_OBJECTIVE_SCORE': float(pick.objective_score),
        'SELECTED_TOP01_RATE': float(pick.top01_rate),
        'TOP01_RETENTION_VS_WEAKEST_CORE': float(pick.top01_rate / max(weakest_core_top01, 1e-30)),
        'EVICTED_CORE_POSITION': int(core[4]),
        'FINAL_POSITIONS': list(out),
    })
    return out, receipt
