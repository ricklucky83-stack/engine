from __future__ import annotations
import math, re, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

EVALUATOR_ID='MLB_SHOWDOWN_POSTLOCK_BOARD_CONTEST_ORDER_EVALUATOR_v1_1'
FPTS_ROUNDING_TOLERANCE=0.011
IDENTITY_PATCH_ID='MLB_POSTLOCK_NICKNAME_IDENTITY_RECONCILIATION_v1'
MLB_GENERATIONAL_SUFFIXES=frozenset({'jr','sr','ii','iii','iv'})
MLB_POSTLOCK_IDENTITY_ALIASES={'kike hernandez':'enrique hernandez','kik hernandez':'enrique hernandez'}

def _normalize_identity_name(value):
    text=re.sub(r'[^a-z0-9]+',' ',str(value).lower()).strip()
    return re.sub(r'\s+',' ',text)

def identity_name(value):
    tokens=_normalize_identity_name(value).split()
    while tokens and tokens[-1] in MLB_GENERATIONAL_SUFFIXES:
        tokens.pop()
    ident=' '.join(tokens)
    return MLB_POSTLOCK_IDENTITY_ALIASES.get(ident,ident)

def identity_lineup_key(cpt,utils):
    return identity_name(cpt), tuple(sorted(identity_name(x) for x in utils))

def identity_fpts(values):
    out={}; raws={}
    for raw,score in values.items():
        ident=identity_name(raw)
        if not ident: continue
        raws.setdefault(ident,[]).append((str(raw),float(score)))
    for ident,items in raws.items():
        spread=max(v for _,v in items)-min(v for _,v in items)
        if spread>FPTS_ROUNDING_TOLERANCE:
            raise RuntimeError(f'POSTLOCK_IDENTITY_FPTS_COLLISION:{ident}:{spread:.12f}')
        out[ident]=float(np.median([v for _,v in items]))
    return out



def lineup_key(cpt, utils):
    return str(cpt).strip(), tuple(sorted(str(x).strip() for x in utils))


def parse_lineup(text):
    if not isinstance(text, str) or not text.strip():
        return None
    parts=re.findall(r'(CPT|UTIL)\s+(.+?)(?=\s+(?:CPT|UTIL)\s+|$)',text.strip())
    cpt=[name.strip() for role,name in parts if role=='CPT']
    utils=[name.strip() for role,name in parts if role=='UTIL']
    if len(cpt)!=1 or len(utils)!=5:
        return None
    return lineup_key(cpt[0],utils)


def read_standings(path):
    path=Path(path)
    if path.suffix.lower()=='.zip':
        with zipfile.ZipFile(path) as z:
            csvs=[n for n in z.namelist() if n.lower().endswith('.csv')]
            if len(csvs)!=1:
                raise RuntimeError(f'STANDINGS_ZIP_CSV_COUNT:{len(csvs)}')
            with z.open(csvs[0]) as f: return pd.read_csv(f)
    return pd.read_csv(path)


def _col(df,*names):
    lookup={str(c).strip().lower():c for c in df.columns}
    for n in names:
        if n.lower() in lookup: return lookup[n.lower()]
    return None


def normalized_fpts(df):
    """Return base player FPTS after removing DraftKings CPT scoring scale."""
    player_col=_col(df,'Player'); fpts_col=_col(df,'FPTS')
    if player_col is None or fpts_col is None:
        return {},0.0
    pr=df[df[player_col].notna() & df[fpts_col].notna()].copy()
    if pr.empty:
        return {},0.0
    role_col=_col(df,'Roster Position','RosterPosition')
    if role_col is None:
        raise RuntimeError('STANDINGS_ROSTER_POSITION_REQUIRED_FOR_ROLE_NORMALIZATION')

    values={}
    for _,row in pr.iterrows():
        player=str(row[player_col]).strip()
        role=str(row[role_col]).strip().upper()
        try: score=float(row[fpts_col])
        except (TypeError,ValueError): continue
        if role=='CPT': score/=1.5
        elif role!='UTIL':
            raise RuntimeError(f'STANDINGS_ROSTER_POSITION_INVALID:{role}')
        values.setdefault(player,[]).append(score)
    if not values:
        return {},0.0
    spread=max(max(scores)-min(scores) for scores in values.values())
    if spread>FPTS_ROUNDING_TOLERANCE:
        raise RuntimeError(f'ROLE_NORMALIZED_FPTS_CONSISTENCY:{spread:.12f}')
    return {player:float(np.median(scores)) for player,scores in values.items()},float(spread)


def evaluate_board(board_df, contest_path, out_path=None):
    contest_path=Path(contest_path)
    df=read_standings(contest_path)
    rank_col=_col(df,'Rank'); points_col=_col(df,'Points'); lineup_col=_col(df,'Lineup')
    if rank_col is None or points_col is None or lineup_col is None:
        raise RuntimeError('STANDINGS_REQUIRED_COLUMNS_MISSING')

    entries=df[df[lineup_col].notna()].copy()
    entries[rank_col]=pd.to_numeric(entries[rank_col],errors='coerce')
    entries[points_col]=pd.to_numeric(entries[points_col],errors='coerce')
    entries=entries[entries[rank_col].notna() & entries[points_col].notna()]
    exact={}
    for _,row in entries.iterrows():
        raw_key=parse_lineup(row[lineup_col])
        if raw_key is None: continue
        key=identity_lineup_key(raw_key[0],raw_key[1])
        val=(int(row[rank_col]),float(row[points_col]))
        if key not in exact or val[0]<exact[key][0]: exact[key]=val

    fpts_raw,fpts_spread=normalized_fpts(df)
    fpts=identity_fpts(fpts_raw)
    field_points=np.sort(entries[points_col].astype(float).to_numpy())[::-1]

    rows=[]
    for _,r in board_df.sort_values('RANK').iterrows():
        display_key=lineup_key(r['CPT'],[r[f'UTIL{i}'] for i in range(1,6)])
        key=identity_lineup_key(display_key[0],display_key[1])
        exact_hit=exact.get(key)
        actual_score=None; contest_rank=None; source='UNRESOLVED'
        if exact_hit:
            contest_rank,actual_score=exact_hit; source='EXACT_FIELD_MATCH'
        elif all(name in fpts for name in (key[0],*key[1])) and len(field_points):
            actual_score=1.5*fpts[key[0]]+sum(fpts[x] for x in key[1])
            contest_rank=int(1+np.sum(field_points>actual_score+1e-9)); source='VIRTUAL_IF_PLAYED'
        rows.append(dict(BOARD_RANK=int(r['RANK']),CPT=display_key[0],UTILS='|'.join(display_key[1]),ACTUAL_POINTS=actual_score,CONTEST_RANK=contest_rank,RANK_SOURCE=source))
    audit=pd.DataFrame(rows)
    if out_path is not None: audit.to_csv(out_path,index=False)

    resolved=audit[audit.CONTEST_RANK.notna()].copy()
    if len(resolved)>=2:
        rho=float(spearmanr(resolved.BOARD_RANK.astype(float),resolved.CONTEST_RANK.astype(float)).statistic)
        rel=1.0/np.log2(resolved.CONTEST_RANK.astype(float).to_numpy()+1.0)
        dcg=float(np.sum(rel/np.log2(resolved.BOARD_RANK.astype(float).to_numpy()+1.0)))
        ideal=np.sort(rel)[::-1]
        idcg=float(np.sum(ideal/np.log2(np.arange(1,len(ideal)+1)+1.0)))
        ndcg=dcg/idcg if idcg>0 else None
    else:
        rho=None; ndcg=None
    summary=dict(
        EVALUATOR_ID=EVALUATOR_ID,
        CONTEST_FILE=str(contest_path),
        CONTEST_ROWS=int(len(entries)),
        RESOLVED_BOARD_LINEUPS=int(len(resolved)),
        EXACT_FIELD_MATCHES=int((audit.RANK_SOURCE=='EXACT_FIELD_MATCH').sum()),
        VIRTUAL_IF_PLAYED=int((audit.RANK_SOURCE=='VIRTUAL_IF_PLAYED').sum()),
        BEST_BOARD_CONTEST_RANK=int(resolved.CONTEST_RANK.min()) if len(resolved) else None,
        BOARD_RANK_1_CONTEST_RANK=int(resolved.loc[resolved.BOARD_RANK==1,'CONTEST_RANK'].iloc[0]) if (resolved.BOARD_RANK==1).any() else None,
        TOP10_CONTEST_OVERLAP=int((resolved.CONTEST_RANK<=10).sum()),
        BOARD_RANK_VS_CONTEST_RANK_SPEARMAN=rho,
        NDCG_AT_10=ndcg,
        MEAN_RECIPROCAL_CONTEST_RANK=float(np.mean(1.0/resolved.CONTEST_RANK.astype(float))) if len(resolved) else None,
        FPTS_ROLE_NORMALIZATION='CPT_DIVIDE_1_5_UTIL_UNCHANGED',
        FPTS_NORMALIZATION_MAX_SPREAD=fpts_spread,
        FPTS_NORMALIZATION_CONSISTENCY='PASS',
        ACTUAL_RESULTS_USED_BY_SELECTOR=False,
    )
    return audit,summary
