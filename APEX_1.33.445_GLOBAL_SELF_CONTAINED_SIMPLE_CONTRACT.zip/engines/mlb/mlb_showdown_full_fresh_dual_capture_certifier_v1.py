#!/usr/bin/env python3
"""Post-lock certification for full-fresh MLB Showdown dual capture.

This module is validation-only. It may inspect a completed post-lock validation
receipt after the forward pre-lock production run has terminated. It must never
be imported by, or provide inputs to, the production selector.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Mapping

PATCH_ID = "MLB_SD_FULL_FRESH_50K_DUAL_CAPTURE_CERTIFICATION_v1"
POSTLOCK_ONLY = True
FORWARD_ENGINE_IMPORT_ALLOWED = False
SELECTOR_INPUT_ALLOWED = False
MIN_PHASE1_TRIALS = 50_000
REQUIRED_FINAL_CORE5_SIZE = 5


def _truth(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().upper() in {"TRUE", "PASS", "YES", "1"}
    return bool(value)


def certify(receipt: Mapping[str, Any]) -> dict[str, Any]:
    """Fail closed unless a fresh 50K forward run captured both truth targets.

    Target identities are supplied only by the post-lock validation receipt.
    This function evaluates certification metadata and never feeds identities,
    realized scores, or target membership back into production selection.
    """
    winner = receipt.get("ACTUAL_CONTEST_WINNER") or {}
    perfect = receipt.get("LINESTAR_PERFECT") or {}
    checks = {
        "FRESH_END_TO_END_RUN": _truth(receipt.get("FRESH_END_TO_END_RUN")),
        "PHASE1_TRIALS_GE_50000": int(receipt.get("PHASE1_TRIALS") or 0) >= MIN_PHASE1_TRIALS,
        "FINAL_PLAYABLE_CORE5_SIZE_5": int(receipt.get("FINAL_PLAYABLE_BOARD_SIZE") or 0) == REQUIRED_FINAL_CORE5_SIZE,
        "GLOBAL_CORE5_ENFORCED": _truth(receipt.get("GLOBAL_FINAL_PLAYABLE_CORE5_ENFORCED")),
        "MACHINE_BOARD_PARITY": str(receipt.get("MACHINE_BOARD_PARITY", "")).upper() == "PASS",
        "PRODUCTION_POSTLOCK_INPUT_ABSENT": not _truth(receipt.get("PRODUCTION_POSTLOCK_INPUT_USED")),
        "PRODUCTION_PLAYER_NAME_CONSTANTS_ABSENT": not _truth(receipt.get("PRODUCTION_PLAYER_NAME_CONSTANTS_USED")),
        "ACTUAL_WINNER_FINAL_CORE5_CAPTURE": _truth(winner.get("FINAL_CORE5_CAPTURE")),
        "PERFECT_FINAL_CORE5_CAPTURE": _truth(perfect.get("FINAL_CORE5_CAPTURE")),
        "UPSTREAM_STRICT_GATE_PASS": str(receipt.get("STRICT_SUCCESS_GATE", "")).upper() == "PASS",
        "UPSTREAM_STATUS_PASS": str(receipt.get("STATUS", "")).upper() == "PASS",
    }
    passed = all(checks.values())
    return {
        "PATCH_ID": PATCH_ID,
        "STATUS": "PASS" if passed else "FAIL",
        "CERTIFICATION_GATE": "PASS" if passed else "BLOCK",
        "POSTLOCK_ONLY": POSTLOCK_ONLY,
        "FORWARD_ENGINE_IMPORT_ALLOWED": FORWARD_ENGINE_IMPORT_ALLOWED,
        "SELECTOR_INPUT_ALLOWED": SELECTOR_INPUT_ALLOWED,
        "MIN_PHASE1_TRIALS": MIN_PHASE1_TRIALS,
        "REQUIRED_FINAL_CORE5_SIZE": REQUIRED_FINAL_CORE5_SIZE,
        "STATE_VERSION_VALIDATED": str(receipt.get("STATE_VERSION", "")),
        "CHECKS": checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--output")
    args = parser.parse_args()
    receipt = json.loads(Path(args.receipt).read_text(encoding="utf-8"))
    result = certify(receipt)
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if result["CERTIFICATION_GATE"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
