from __future__ import annotations

"""Prelock MLB hitter challenge/opportunity adjustment.

This module estimates whether a hitter is likely to receive attackable plate
appearances rather than being pitched around. It intentionally uses only
prelock slate/player-pool fields and never consumes realized results.

The model is structural, not name-based: elite power + market respect + salary
+ ownership + walk history + weak protection + a walk-prone opposing starter
can raise pitch-around risk. Lower-owned credible power with stronger
protection and a more attack-oriented opposing starter can earn an upward
attackability adjustment.
"""

from dataclasses import dataclass, asdict
from typing import Mapping, Sequence, Any
import math
import numpy as np

PATCH_ID = "MLB_HITTER_ATTACKABLE_PA_AND_CHALK_FAILURE_EDGE_v1"
MODEL_ID = "PRELOCK_PITCH_AROUND_RISK_ATTACKABLE_PA_v1"


@dataclass(frozen=True)
class AttackablePAProfile:
    pitch_around_risk: float
    challenge_index: float
    attackable_pa_multiplier: float
    walk_multiplier: float
    chalk_failure_edge: float
    respect_index: float
    power_index: float
    market_hr_index: float
    pitcher_nibble_index: float
    protection_index: float
    isolation_index: float

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


def _num(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        s = str(v).strip().replace("%", "").replace(",", "")
        if s in {"", "-", "nan", "None", "NA", "N/A"}:
            return default
        x = float(s)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _american_to_prob(v: Any) -> float:
    try:
        s = str(v).strip().replace("+", "").replace(",", "")
        if s in {"", "-", "nan", "None"}:
            return 0.0
        x = float(s)
        if x > 0:
            return 100.0 / (x + 100.0)
        if x < 0:
            return (-x) / ((-x) + 100.0)
    except Exception:
        pass
    return 0.0


def _rank01(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    n = len(values)
    if n <= 1:
        return np.full(n, 0.5, dtype=float)
    finite = np.isfinite(values)
    if not finite.any():
        return np.full(n, 0.5, dtype=float)
    fill = float(np.nanmedian(values[finite]))
    x = np.where(finite, values, fill)
    order = np.argsort(x, kind="mergesort")
    ranks = np.empty(n, dtype=float)
    ranks[order] = np.linspace(0.0, 1.0, n)
    return ranks


def _is_hitter(row: Mapping[str, Any]) -> bool:
    if str(row.get("POS", "")).strip().upper() == "P":
        return False
    try:
        lu = int(float(str(row.get("LINEUP", "")).strip()))
        return 1 <= lu <= 9
    except Exception:
        return False


def _is_pitcher(row: Mapping[str, Any]) -> bool:
    return str(row.get("POS", "")).strip().upper() == "P" or str(row.get("LINEUP", "")).strip().upper() == "SP"


def build_attackable_pa_profiles(rows: Sequence[Mapping[str, Any]], *, mode: str) -> list[AttackablePAProfile]:
    mode = str(mode).upper().strip()
    if mode not in {"CLASSIC", "SHOWDOWN", "HRS"}:
        raise ValueError(f"UNSUPPORTED_MLB_MODE:{mode}")

    n = len(rows)
    neutral = AttackablePAProfile(
        pitch_around_risk=0.5, challenge_index=0.5,
        attackable_pa_multiplier=1.0, walk_multiplier=1.0,
        chalk_failure_edge=0.0, respect_index=0.5, power_index=0.5,
        market_hr_index=0.5, pitcher_nibble_index=0.5,
        protection_index=0.5, isolation_index=0.0,
    )
    out = [neutral for _ in range(n)]
    hidx = [i for i, r in enumerate(rows) if _is_hitter(r)]
    if not hidx:
        return out

    # Starter map lets hitter rows inherit opponent pitcher walk/command traits.
    spmap: dict[str, Mapping[str, Any]] = {}
    for r in rows:
        if _is_pitcher(r):
            name = str(r.get("PLAYER", "")).strip()
            if name:
                spmap[name] = r

    def arr(key: str, default: float = 0.0) -> np.ndarray:
        return np.array([_num(rows[i].get(key), default) for i in hidx], dtype=float)

    iso = arr("ISO", 0.145)
    barrel = arr("Barrel %", 6.0)
    hard = arr("Hard%", 34.0)
    ev = arr("EV", 88.0)
    slg = arr("SLG", 0.410)
    bb = arr("BB%", 8.0)
    obp = arr("OBP", 0.315)
    sal = arr("SAL", 4000.0)
    own = arr("RST%", 5.0)
    lineup = arr("LINEUP", 5.0)

    market = []
    for i in hidx:
        r = rows[i]
        p = _american_to_prob(r.get("1+ HR"))
        if p <= 0:
            hp = _num(r.get("HR%"), 0.0)
            if hp > 1:
                hp /= 100.0
            p = hp
        market.append(p if p > 0 else 0.08)
    market = np.asarray(market, dtype=float)

    power = (
        0.31 * _rank01(iso)
        + 0.24 * _rank01(barrel)
        + 0.17 * _rank01(hard)
        + 0.13 * _rank01(ev)
        + 0.15 * _rank01(slg)
    )
    market_rank = _rank01(market)
    salary_rank = _rank01(sal)
    own_rank = _rank01(own)
    bb_rank = _rank01(bb)
    obp_rank = _rank01(obp)

    # Build next-hitter protection from same-team lineup order.
    by_team_order: dict[tuple[str, int], int] = {}
    local_by_global = {g: j for j, g in enumerate(hidx)}
    for g in hidx:
        r = rows[g]
        try:
            lu = int(float(str(r.get("LINEUP", "")).strip()))
        except Exception:
            continue
        by_team_order[(str(r.get("TEAM", "")).strip(), lu)] = g
    protection = np.full(len(hidx), 0.5, dtype=float)
    team_power_values: dict[str, list[float]] = {}
    for j, g in enumerate(hidx):
        team = str(rows[g].get("TEAM", "")).strip()
        team_power_values.setdefault(team, []).append(float(power[j]))
        lu = int(round(lineup[j]))
        nxt = by_team_order.get((team, lu + 1))
        if nxt is not None and nxt in local_by_global:
            protection[j] = float(power[local_by_global[nxt]])
        elif lu == 9:
            leadoff = by_team_order.get((team, 1))
            if leadoff is not None and leadoff in local_by_global:
                protection[j] = float(power[local_by_global[leadoff]])

    team_median_power = {
        t: float(np.median(v)) if v else 0.5 for t, v in team_power_values.items()
    }
    isolation = np.zeros(len(hidx), dtype=float)
    for j, g in enumerate(hidx):
        t = str(rows[g].get("TEAM", "")).strip()
        isolation[j] = float(np.clip((power[j] - team_median_power.get(t, 0.5)) / 0.5, 0.0, 1.0))

    pitcher_bb9 = np.zeros(len(hidx), dtype=float)
    pitcher_kbb = np.zeros(len(hidx), dtype=float)
    pitcher_k9 = np.zeros(len(hidx), dtype=float)
    for j, g in enumerate(hidx):
        r = rows[g]
        pr = spmap.get(str(r.get("Opp Pitcher", "")).strip(), {})
        pitcher_bb9[j] = _num(pr.get("BB/9"), _num(r.get("BB/9"), 3.0))
        pitcher_kbb[j] = _num(pr.get("K/BB"), _num(r.get("K/BB"), 2.7))
        pitcher_k9[j] = _num(pr.get("K/9"), _num(r.get("K/9"), 8.2))
    nibble = (
        0.52 * _rank01(pitcher_bb9)
        + 0.30 * (1.0 - _rank01(pitcher_kbb))
        + 0.18 * (1.0 - _rank01(pitcher_k9))
    )

    respect = (
        0.29 * power
        + 0.20 * market_rank
        + 0.15 * salary_rank
        + 0.13 * own_rank
        + 0.13 * bb_rank
        + 0.10 * obp_rank
    )
    weak_protection = 1.0 - protection
    middle_order = np.where((lineup >= 3) & (lineup <= 5), 1.0, np.where(lineup <= 2, 0.55, 0.25))
    raw_risk = (
        0.30 * respect
        + 0.18 * bb_rank
        + 0.18 * nibble
        + 0.14 * weak_protection
        + 0.12 * isolation
        + 0.08 * middle_order
    )
    # Keep the first production version bounded: it should reshape tail worlds,
    # not erase elite hitters from consideration.
    risk = np.clip(0.06 + 0.88 * raw_risk, 0.06, 0.94)
    challenge = 1.0 - risk

    mode_slope = {"HRS": 0.18, "SHOWDOWN": 0.16, "CLASSIC": 0.14}[mode]
    attack_mult = np.clip(1.0 + mode_slope * (challenge - 0.5), 1.0 - mode_slope / 2.0, 1.0 + mode_slope / 2.0)
    walk_mult = np.clip(1.0 + 0.50 * (risk - 0.5), 0.75, 1.25)

    chalk_pressure = 0.56 * own_rank + 0.44 * salary_rank
    failure_edge = np.clip(
        chalk_pressure * (0.60 * risk + 0.20 * weak_protection + 0.20 * nibble),
        0.0,
        1.0,
    )

    for j, g in enumerate(hidx):
        out[g] = AttackablePAProfile(
            pitch_around_risk=float(risk[j]),
            challenge_index=float(challenge[j]),
            attackable_pa_multiplier=float(attack_mult[j]),
            walk_multiplier=float(walk_mult[j]),
            chalk_failure_edge=float(failure_edge[j]),
            respect_index=float(respect[j]),
            power_index=float(power[j]),
            market_hr_index=float(market_rank[j]),
            pitcher_nibble_index=float(nibble[j]),
            protection_index=float(protection[j]),
            isolation_index=float(isolation[j]),
        )
    return out


def receipt(rows: Sequence[Mapping[str, Any]], profiles: Sequence[AttackablePAProfile], *, mode: str) -> dict[str, Any]:
    hitters = [(rows[i], p) for i, p in enumerate(profiles) if _is_hitter(rows[i])]
    high_risk = sorted(hitters, key=lambda rp: (-rp[1].pitch_around_risk, str(rp[0].get("PLAYER", ""))))[:10]
    high_fail = sorted(hitters, key=lambda rp: (-rp[1].chalk_failure_edge, str(rp[0].get("PLAYER", ""))))[:10]
    return {
        "PATCH_ID": PATCH_ID,
        "MODEL_ID": MODEL_ID,
        "MODE": str(mode).upper(),
        "POSTLOCK_RESULTS_USED": False,
        "PLAYER_NAME_PRIOR_USED": False,
        "HITTER_COUNT": len(hitters),
        "TOP_PITCH_AROUND_RISK": [
            {"PLAYER": str(r.get("PLAYER", "")), "RISK": round(p.pitch_around_risk, 6), "ATTACK_MULT": round(p.attackable_pa_multiplier, 6)}
            for r, p in high_risk
        ],
        "TOP_CHALK_FAILURE_EDGE": [
            {"PLAYER": str(r.get("PLAYER", "")), "EDGE": round(p.chalk_failure_edge, 6), "RISK": round(p.pitch_around_risk, 6)}
            for r, p in high_fail
        ],
    }
