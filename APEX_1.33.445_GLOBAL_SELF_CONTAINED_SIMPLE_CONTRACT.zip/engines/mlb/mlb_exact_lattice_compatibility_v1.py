from __future__ import annotations

from functools import lru_cache
from typing import Iterable

FULL_SLOT_MASK = (1 << 8) - 1
PATCH_ID = "MLB_CLASSIC_EXACT_LATTICE_COMPATIBILITY_FAST_PATH_v1"

@lru_cache(maxsize=200_000)
def assignment_mask_code(player_slot_masks: tuple[int, ...]) -> int:
    """Return a 256-bit code whose set bits are reachable occupied-slot masks.

    Each input integer is an 8-bit mask of eligible concrete roster slots. Duplicate
    OF slots are represented as distinct bits, preserving exact DK assignment semantics.
    """
    states = 1  # bit 0 => occupied mask 0 is reachable
    for eligible in player_slot_masks:
        new_states = 0
        bits = states
        while bits:
            low = bits & -bits
            occupied = low.bit_length() - 1
            bits ^= low
            available = int(eligible) & (~occupied) & FULL_SLOT_MASK
            while available:
                slot_bit = available & -available
                available ^= slot_bit
                new_states |= 1 << (occupied | slot_bit)
        states = new_states
        if not states:
            return 0
    return states

@lru_cache(maxsize=200_000)
def complement_mask_code(mask_code: int) -> int:
    out = 0
    bits = int(mask_code)
    while bits:
        low = bits & -bits
        occupied = low.bit_length() - 1
        bits ^= low
        out |= 1 << (FULL_SLOT_MASK ^ occupied)
    return out

def compatible(mask_code_a: int, mask_code_b: int) -> bool:
    return bool(complement_mask_code(int(mask_code_a)) & int(mask_code_b))

def direct_full_assignment_exists(player_slot_masks: Iterable[int]) -> bool:
    return bool(assignment_mask_code(tuple(int(x) for x in player_slot_masks)) & (1 << FULL_SLOT_MASK))
