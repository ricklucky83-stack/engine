from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Mapping, Sequence, Tuple
import json

PATCH_ID = "GLOBAL_DFS_CORE_CLOSURE_PROFILE_CALIBRATION_v2"

PRIMARY = (
    "top_0_1_phase1_pct",
    "win_phase1_pct",
    "top_1_phase1_pct",
    "p99_phase1_pct",
    "p95_phase1_pct",
)
CORE = (
    "core_correlation_phase1_pct",
    "anchor_quality_phase1_pct",
    "secondary_anchor_upside_phase1_pct",
)
CLOSURE = (
    "differentiated_closure_phase1_pct",
    "salary_flexibility_phase1_pct",
    "duplication_risk_inverse_phase1_pct",
    "portfolio_marginal_value_phase1_pct",
)
OWNERSHIP = "ownership_tiebreak"

class ProfileCalibrationFailure(RuntimeError):
    pass

@dataclass(frozen=True)
class Candidate:
    lineup_id: str
    sport: str
    mode: str
    legal: bool
    active_verified: bool
    phase1_calibration_sha256: str
    features: Mapping[str, float]
    phase1_pareto_nondominated: bool = False
    phase1_profile_recall_lane: bool = False

@dataclass(frozen=True)
class QualifiedProfile:
    lineup_id: str
    qualification_lanes: Tuple[str, ...]
    primary_average: float
    core_average: float
    closure_average: float
    ownership_tiebreak: float

def _validate_percentile(value: float, field: str, lineup_id: str) -> float:
    number = float(value)
    if number < 0.0 or number > 1.0:
        raise ProfileCalibrationFailure(
            f"INVALID_PHASE1_PERCENTILE:{lineup_id}:{field}:{number}"
        )
    return number

def qualify_profiles(
    candidates: Sequence[Candidate],
    *,
    expected_phase1_calibration_sha256: str,
    primary_floor: float = 0.70,
    core_floor: float = 0.65,
    closure_floor: float = 0.65,
    elite_single_signal_floor: float = 0.90,
) -> Tuple[QualifiedProfile, ...]:
    if not candidates:
        raise ProfileCalibrationFailure("EMPTY_CANDIDATE_MATRIX")
    if not expected_phase1_calibration_sha256:
        raise ProfileCalibrationFailure("MISSING_EXPECTED_PHASE1_HASH")

    required = set(PRIMARY + CORE + CLOSURE + (OWNERSHIP,))
    qualified = []

    for candidate in candidates:
        if not candidate.legal:
            raise ProfileCalibrationFailure(
                f"ILLEGAL_CANDIDATE:{candidate.lineup_id}"
            )
        if not candidate.active_verified:
            raise ProfileCalibrationFailure(
                f"INACTIVE_CANDIDATE:{candidate.lineup_id}"
            )
        if candidate.phase1_calibration_sha256 != expected_phase1_calibration_sha256:
            raise ProfileCalibrationFailure(
                f"PHASE1_HASH_MISMATCH:{candidate.lineup_id}"
            )

        missing = required - set(candidate.features)
        if missing:
            raise ProfileCalibrationFailure(
                f"MISSING_FROZEN_PHASE1_FEATURES:{candidate.lineup_id}:"
                + ",".join(sorted(missing))
            )

        primary_values = [
            _validate_percentile(
                candidate.features[name],
                name,
                candidate.lineup_id,
            )
            for name in PRIMARY
        ]
        core_values = [
            _validate_percentile(
                candidate.features[name],
                name,
                candidate.lineup_id,
            )
            for name in CORE
        ]
        closure_values = [
            _validate_percentile(
                candidate.features[name],
                name,
                candidate.lineup_id,
            )
            for name in CLOSURE
        ]

        primary_average = sum(primary_values) / len(primary_values)
        core_average = sum(core_values) / len(core_values)
        closure_average = sum(closure_values) / len(closure_values)

        lanes = []
        if (
            primary_average >= primary_floor
            and core_average >= core_floor
            and closure_average >= closure_floor
        ):
            lanes.append("STRONG_CORE_PLUS_DIFFERENTIATED_CLOSURE")

        if max(primary_values) >= elite_single_signal_floor:
            lanes.append("ELITE_SINGLE_PHASE1_TAIL_SIGNAL")

        if candidate.phase1_pareto_nondominated:
            lanes.append("PHASE1_PARETO_FRONTIER")

        if candidate.phase1_profile_recall_lane:
            lanes.append("PHASE1_PROFILE_RECALL_LANE")

        if not lanes:
            continue

        qualified.append(
            QualifiedProfile(
                lineup_id=candidate.lineup_id,
                qualification_lanes=tuple(lanes),
                primary_average=primary_average,
                core_average=core_average,
                closure_average=closure_average,
                ownership_tiebreak=float(candidate.features[OWNERSHIP]),
            )
        )

    # Ownership is strictly last.
    return tuple(
        sorted(
            qualified,
            key=lambda row: (
                -row.primary_average,
                -row.core_average,
                -row.closure_average,
                -row.ownership_tiebreak,
                row.lineup_id,
            ),
        )
    )

def fingerprint(
    candidates: Sequence[Candidate],
    qualified: Sequence[QualifiedProfile],
    *,
    expected_phase1_calibration_sha256: str,
) -> str:
    payload = {
        "patch": PATCH_ID,
        "phase1_calibration_sha256": expected_phase1_calibration_sha256,
        "candidate_ids": sorted(row.lineup_id for row in candidates),
        "qualified": [
            {
                "lineup_id": row.lineup_id,
                "lanes": list(row.qualification_lanes),
                "primary_average": row.primary_average,
                "core_average": row.core_average,
                "closure_average": row.closure_average,
            }
            for row in qualified
        ],
        "downstream_percentile_recalculation": False,
        "ownership_main_score_weight": 0.0,
        "ownership_position": "FINAL_TIEBREAK_ONLY",
    }
    return sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
