from __future__ import annotations

"""Pre-lock SS-HRS event-rank geometry recall protection.

This module is intentionally outcome-blind.  It operates only on player event
ranks derived from the frozen pre-lock P_EVENT surface and candidate metrics
already produced by the SS-HRS engine.  It does not inspect contest standings,
realized home runs, player names, or post-lock ownership.
"""

from dataclasses import dataclass
from typing import Sequence

import numpy as np
import pandas as pd

PATCH_ID = "MLB_SS_HRS_HISTORICAL_EVENT_RANK_GEOMETRY_RESERVE_v1"
STATUS = "ACTIVE_ADDITIVE_RECALL_PROTECTION"


@dataclass(frozen=True)
class GeometryPolicy:
    strong_rank_max: int = 40
    bridge_rank_max: int = 120
    min_strong_hitters: int = 2

    def validate(self) -> None:
        if self.strong_rank_max <= 0:
            raise ValueError("INVALID_STRONG_RANK_MAX")
        if self.bridge_rank_max < self.strong_rank_max:
            raise ValueError("INVALID_BRIDGE_RANK_MAX")
        if not 1 <= self.min_strong_hitters <= 3:
            raise ValueError("INVALID_MIN_STRONG_HITTERS")


DEFAULT_POLICY = GeometryPolicy()


def event_rank_band(rank: int) -> str:
    r = int(rank)
    if r <= 0:
        raise ValueError("INVALID_EVENT_RANK")
    if r <= 15:
        return "A"
    if r <= 40:
        return "B"
    if r <= 80:
        return "C"
    if r <= 120:
        return "D"
    return "E"


def geometry_code(ranks: Sequence[int]) -> str:
    if len(ranks) != 3:
        raise ValueError("SS_HRS_GEOMETRY_REQUIRES_THREE_RANKS")
    return "".join(sorted(event_rank_band(int(r)) for r in ranks))


def protected_mask(
    rank_matrix: np.ndarray,
    policy: GeometryPolicy = DEFAULT_POLICY,
) -> np.ndarray:
    """Return the additive recall mask for legal three-hitter candidates.

    Cross-slate rule:
      * at least two hitters rank 1..40 by frozen pre-lock P_EVENT; and
      * every hitter ranks 1..120.

    No candidate outside this mask is deleted.  The mask is a reserve/union
    authority for downstream AI review, never a replacement for full Phase-2
    visibility.
    """
    policy.validate()
    rm = np.asarray(rank_matrix, dtype=np.int32)
    if rm.ndim != 2 or rm.shape[1] != 3:
        raise ValueError("SS_HRS_RANK_MATRIX_SHAPE_INVALID")
    if np.any(rm <= 0):
        raise ValueError("SS_HRS_EVENT_RANK_NONPOSITIVE")
    strong = (rm <= int(policy.strong_rank_max)).sum(axis=1)
    bridge_ok = rm.max(axis=1) <= int(policy.bridge_rank_max)
    return (strong >= int(policy.min_strong_hitters)) & bridge_ok


def reserve_frame(
    cand: pd.DataFrame,
    comb: np.ndarray,
    event_rank: np.ndarray,
    policy: GeometryPolicy = DEFAULT_POLICY,
) -> pd.DataFrame:
    """Build a deterministic protected review surface from frozen candidates."""
    if len(cand) != len(comb):
        raise ValueError("SS_HRS_CANDIDATE_COMB_LENGTH_MISMATCH")
    ranks = np.asarray(event_rank, dtype=np.int32)
    matrix = ranks[np.asarray(comb, dtype=np.int32)]
    mask = protected_mask(matrix, policy)
    idx = cand.index.to_numpy()[mask]
    if not len(idx):
        cols = [
            "candidate_index", "i", "j", "k", "event_rank_1", "event_rank_2",
            "event_rank_3", "geometry_code", "p3", "p2plus", "expected_hrs",
            "pair_surface", "score", "route",
            "SS_HRS_EVENT_RANK_GEOMETRY_PROTECTED",
        ]
        return pd.DataFrame(columns=cols)

    sub = cand.loc[idx, [
        "i", "j", "k", "p3", "p2plus", "expected_hrs", "pair_surface", "score", "route"
    ]].copy()
    sub.insert(0, "candidate_index", idx.astype(np.int64))
    m = matrix[mask]
    m = np.sort(m, axis=1)
    sub["event_rank_1"] = m[:, 0]
    sub["event_rank_2"] = m[:, 1]
    sub["event_rank_3"] = m[:, 2]
    sub["geometry_code"] = [geometry_code(row) for row in m]
    sub["SS_HRS_EVENT_RANK_GEOMETRY_PROTECTED"] = True
    # Ordering is pre-lock and ownership-free.  It is only a deterministic
    # review order; every protected row remains in the reserve surface.
    sub = sub.sort_values(
        ["p3", "p2plus", "expected_hrs", "pair_surface", "score"],
        ascending=False,
        kind="mergesort",
    ).reset_index(drop=True)
    return sub


def union_with_prefilter(base_indices: Sequence[int], reserve_indices: Sequence[int]) -> np.ndarray:
    """Stable union used by SS-HRS AI Pass-1/Pass-2 shortlist construction."""
    seen: set[int] = set()
    out: list[int] = []
    for source in (base_indices, reserve_indices):
        for raw in source:
            idx = int(raw)
            if idx not in seen:
                seen.add(idx)
                out.append(idx)
    return np.asarray(out, dtype=np.int64)
