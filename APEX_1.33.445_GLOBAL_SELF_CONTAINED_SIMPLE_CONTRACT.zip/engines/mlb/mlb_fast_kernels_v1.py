from __future__ import annotations

import numpy as np
from numba import get_num_threads, njit, prange

KERNEL_ID = "MLB_NUMBA_PARALLEL_LINEUP_SCORE_KERNEL_v1"

@njit(cache=True, parallel=True, fastmath=False)
def score_lineup_block_numba(score_surface: np.ndarray, block: np.ndarray) -> np.ndarray:
    """Exact float32 slot-order lineup sums, parallelized across lineups."""
    n_trials = score_surface.shape[0]
    n_lineups = block.shape[0]
    n_slots = block.shape[1]
    out = np.empty((n_trials, n_lineups), dtype=np.float32)
    for lineup_index in prange(n_lineups):
        for trial_index in range(n_trials):
            total = np.float32(0.0)
            for slot_index in range(n_slots):
                total = np.float32(total + score_surface[trial_index, block[lineup_index, slot_index]])
            out[trial_index, lineup_index] = total
    return out

def runtime_receipt() -> dict[str, object]:
    return {"KERNEL_ID":KERNEL_ID,"NUMBA_PARALLEL_JIT":"AVAILABLE","NUMBA_THREADS":int(get_num_threads()),"FASTMATH":False,"FLOAT_ACCUMULATION":"EXACT_FLOAT32_SLOT_ORDER","SLOW_FALLBACK":"PROHIBITED_RUN_INVALID"}
