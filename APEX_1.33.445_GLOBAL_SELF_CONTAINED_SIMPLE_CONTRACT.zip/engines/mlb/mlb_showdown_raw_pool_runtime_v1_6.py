from __future__ import annotations
import argparse, hashlib, itertools, json, math, os, time
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix

POOL_PATH=Path(os.environ.get('APEX_PLAYER_POOL',''))
OUT=Path(os.environ.get('APEX_OUTPUT_DIR','/mnt/data'))
FIELD_SIZE=int(os.environ.get('APEX_FIELD_SIZE','1604'))
EXECUTION_ID=str(os.environ.get('APEX_EXECUTION_ID',FIELD_SIZE))
BOARD_SIZE=int(os.environ.get('APEX_BOARD_SIZE','10'))
FAKE_FIELD=int(math.ceil(FIELD_SIZE*3.4))
TOP01_CUTOFF=max(1,math.ceil(FAKE_FIELD*.001))
SEED=int(os.environ.get('APEX_SEED',str((FIELD_SIZE*10000+17)%(2**32-1))))
PHASE1_TRIALS=int(os.environ.get('APEX_PHASE1_TRIALS','50000'))
BASE_TRIALS=int(os.environ.get('APEX_BASE_TRIALS','10000'))
EXTRA_TRIALS=int(os.environ.get('APEX_EXTRA_TRIALS','40000'))
PATCH_ID='MLB_SD_HITTER_CPT_SPEED_LOW_SPEND_SIBLING_CLOSURE_v1.0'
ENGINE_ID='APEX_MLB_SHOWDOWN_RAW_POOL_RUNTIME_v1.6'
POSTSEAL_WINNER_JSON=os.environ.get('APEX_POSTSEAL_WINNER_JSON')
WINNER=json.loads(POSTSEAL_WINNER_JSON) if POSTSEAL_WINNER_JSON else None
if WINNER:
    WINNER={'CPT':str(WINNER['CPT']),'UTILS':tuple(sorted(map(str,WINNER['UTILS'])))}
FORBIDDEN=['FPTS','AVG FPTS','L10 FPTS','L14 FPTS','L30 FPTS','L7 FPTS','L5 FPTS','L3 FPTS','VAL']

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def num(x,d=0.0):
    try:
        if isinstance(x,str):
            x=x.replace('%','').replace(',','').strip()
            if x in {'','-','nan','None'}: return d
        v=float(x); return v if np.isfinite(v) else d
    except Exception: return d

def pct_rank(x):
    x=np.asarray(x); o=np.argsort(x,kind='mergesort'); z=np.empty(len(x),float); z[o]=np.linspace(0,1,len(x)); return z

def active_pool(raw):
    hitters=raw.LINEUP.astype(str).str.fullmatch(r'[1-9]')
    opp=set(raw.loc[hitters,'Opp Pitcher'].dropna().astype(str).str.strip())
    pitchers=(raw.LINEUP.astype(str).str.upper()=='SP') & raw.PLAYER.astype(str).isin(opp)
    p=raw[hitters|pitchers].copy().reset_index(drop=True)
    if len(p)<8: raise RuntimeError('ACTIVE_POOL_TOO_SMALL')
    if p.TEAM.nunique()!=2: raise RuntimeError('SHOWDOWN_TWO_TEAM_GATE_FAIL')
    if p.PLAYER.duplicated().any(): raise RuntimeError('DUPLICATE_ACTIVE_PLAYER')
    return p

def build_players(pool):
    out=[]
    for i,r in pool.iterrows():
        sp=str(r.LINEUP).upper()=='SP'
        out.append(dict(idx=i,name=str(r.PLAYER).strip(),team=str(r.TEAM).strip(),opp=str(r.OPP).strip(),
          salary=int(num(r.SAL)),own=max(.01,num(r['RST%'],.01)),is_sp=sp,order=10 if sp else int(str(r.LINEUP)),
          team_runs=max(.1,num(r['T Runs'],4)),winp=np.clip(num(r['Win %'],50)/100,.01,.99),game_total=max(1,num(r['O/U'],8)),
          hrp=np.clip(num(r['HR%'],10)/100,.001,.45),avg=np.clip(num(r.AVG,.24),.05,.7),obp=np.clip(num(r.OBP,.31),.06,.8),
          iso=np.clip(num(r.ISO,.14),.01,.6),bbp=np.clip(num(r['BB%'],8)/100,0,.35),kp=np.clip(num(r['K%'],22)/100,.02,.55),
          speed=max(0,num(r.Speed,20)),sb=max(0,num(r.SB,0)),ou_er=max(.5,num(r['O/U ER'],2.8)),ou_k=max(.5,num(r['O/U K'],4.5))))
    return out

def simulate_players(players,trials,seed):
    rng=np.random.default_rng(seed); n=len(players); s=np.zeros((trials,n),np.float32)
    teams=sorted({p['team'] for p in players}); tl={t:rng.normal(0,1,trials).astype(np.float32) for t in teams}; gl=rng.normal(0,1,trials).astype(np.float32)
    for p in players:
        i=p['idx']; t=p['team']; lat=tl[t]; ol=tl.get(p['opp'],-lat)
        if p['is_sp']:
            km=p['ou_k']*np.exp(.10*(-ol)+.05*gl); em=p['ou_er']*np.exp(.16*ol+.08*gl)
            ip=np.clip(rng.normal(5.65+.35*(p['winp']-.5),.85,trials),2,8.5)
            k=rng.poisson(np.clip(km,.2,12)).astype(np.float32); er=rng.poisson(np.clip(em,.2,9)).astype(np.float32)
            h=rng.poisson(np.clip(4.7+.45*em,1,12)).astype(np.float32); bb=rng.poisson(np.clip(1.7+.12*em,.2,6)).astype(np.float32)
            w=(rng.random(trials)<p['winp']).astype(np.float32); qs=((ip>=6)&(er<=3)).astype(np.float32)
            s[:,i]=(2.25*ip+2*k-2*er-.6*h-.6*bb+4*w+2.5*qs).astype(np.float32)
        else:
            pa=np.clip(np.rint(rng.normal(np.clip(4.15+(5-p['order'])*.055+.10*lat,3.2,5.3),.45,trials)),3,6).astype(np.int16)
            contact=np.clip(p['avg']*(1+.12*lat+.04*gl),.05,.72); hp=np.clip(p['hrp']*(1+.30*lat+.10*gl),.001,.48); bp=np.clip(p['bbp']*(1+.10*lat),0,.35)
            hr=rng.binomial(pa,hp).astype(np.float32); rem=np.maximum(pa-hr.astype(np.int16),0)
            nh=rng.binomial(rem,np.clip((contact-hp)/(1-hp+1e-6),0,.75)).astype(np.float32)
            xbf=np.clip(p['iso']/(p['avg']+.05),.03,.7); d=rng.binomial(nh.astype(np.int16),np.clip(.20+.28*xbf,.1,.5)).astype(np.float32)
            tr=rng.binomial(np.maximum((nh-d).astype(np.int16),0),np.clip(.015+.003*p['speed'],.01,.12)).astype(np.float32); sing=np.maximum(nh-d-tr,0)
            walk=rng.binomial(pa,bp).astype(np.float32); ob=sing+d+tr+hr+walk
            rr=np.clip((p['team_runs']/9)*(1.25-.055*(p['order']-1))*(1+.16*lat),.02,1.3)
            rb=np.clip((p['team_runs']/9)*(.82+.045*(p['order']-1))*(1+.18*lat),.02,1.3)
            runs=rng.poisson(np.clip(rr+.11*ob,.01,3.5)).astype(np.float32); rbi=rng.poisson(np.clip(rb+.20*(d+tr+hr)+.06*sing,.01,4)).astype(np.float32)
            speed_tail=(p['speed']/28)**2*(.10+.020*p['sb']); steals=rng.poisson(np.clip(speed_tail*(1+.12*lat),0,.8)).astype(np.float32)
            eruption=(rng.random(trials)<np.clip((p['speed']/30)**3*(p['sb']/30)*.10,0,.06)).astype(np.float32)
            s[:,i]=(3*sing+5*d+8*tr+10*hr+2*walk+2*runs+2*rbi+5*steals+5*eruption).astype(np.float32)
    return s

def enumerate_lineups(players):
    n=len(players); teams=np.array([p['team'] for p in players]); sal=np.array([p['salary'] for p in players],np.int32); rows=[]
    for c in range(n):
        other=[i for i in range(n) if i!=c]; cs=sal[c]*1.5
        for f in itertools.combinations(other,5):
            salary=int(cs+sal[list(f)].sum())
            if salary<40000 or salary>50000: continue
            ids=(c,*f)
            if len(set(teams[list(ids)]))!=2: continue
            rows.append((*ids,salary))
    return np.asarray(rows,np.int32)

def lineup_meta(lineups,players):
    names=np.array([p['name'] for p in players],object); teams=np.array([p['team'] for p in players],object); sp=np.array([p['is_sp'] for p in players],np.int8)
    own=np.array([p['own'] for p in players],float); speed=np.array([p['speed'] for p in players],float); sb=np.array([p['sb'] for p in players],float)
    sal=np.array([p['salary'] for p in players],np.int32); order=np.array([p['order'] for p in players],np.int16)
    idx=lineups[:,:6]; cpt=idx[:,0]; spct=sp[idx].sum(1); cptsp=sp[cpt].astype(bool); branch=[]; route=[]
    low_speed=np.zeros(len(lineups),bool); cpt_team_count=np.zeros(len(lineups),np.int8); same_team_release=np.zeros(len(lineups),bool)
    release_player_count=np.zeros(len(lineups),np.int8); primary_release_player=np.full(len(lineups),-1,np.int16); opponent_top2_count=np.zeros(len(lineups),np.int8)
    for j,row in enumerate(idx):
        tc=Counter(teams[row]); b='-'.join(map(str,sorted(tc.values(),reverse=True))); branch.append(b)
        route.append('SUPPRESS_2SP' if spct[j]==2 else 'BRIDGE_1SP' if spct[j]==1 else 'BALANCED_33_BAT' if b=='3-3' else 'BATS_OFFCENTER')
        cteam=teams[cpt[j]]; cpt_team_count[j]=sum(teams[q]==cteam for q in row)
        low_speed[j]=any(teams[q]!=cteam and speed[q]>=25 and sb[q]>=3 and own[q]<=5 for q in row)
        release=[q for q in row[1:] if (not sp[q]) and teams[q]==cteam and own[q]<=2.0 and sal[q]<=6000 and order[q]<=6]
        release_player_count[j]=len(release); same_team_release[j]=bool(release)
        if release: primary_release_player[j]=min(release,key=lambda q:(own[q],sal[q],order[q],q))
        opponent_top2_count[j]=sum((not sp[q]) and teams[q]!=cteam and order[q]<=2 for q in row[1:])
    branch=np.array(branch,object); route=np.array(route,object)
    lane=(cptsp)&(spct==1)&(branch=='5-1'); lane_speed=lane&low_speed
    lane_control=lane&(cpt_team_count==5); lane_control_speed=lane_control&low_speed; lane_damage=lane&(cpt_team_count==1)
    cpt_speed_tail=(~cptsp)&(speed[cpt]>=25)&(sb[cpt]>=3)&(own[cpt]<=5)
    lane_hitter_cpt_speed_low_spend=(cpt_speed_tail)&(spct==1)&(lineups[:,6]<=47000)
    lane_hitter_cpt_speed_low_spend_42=lane_hitter_cpt_speed_low_spend&(branch=='4-2')
    lane_hitter_cpt_speed_low_spend_42_release=lane_hitter_cpt_speed_low_spend_42&same_team_release
    lane_hitter_cpt_speed_low_spend_42_control=lane_hitter_cpt_speed_low_spend_42_release&(cpt_team_count==4)
    lane_hitter_cpt_speed_low_spend_42_counter=lane_hitter_cpt_speed_low_spend_42_release&(cpt_team_count==2)
    lane_hitter_cpt_speed_low_spend_42_counter_top2=lane_hitter_cpt_speed_low_spend_42_counter&(opponent_top2_count>=2)
    ownlog=np.log(np.clip(own[idx]/100,1e-7,1)).sum(1)+np.where(cptsp,-1,-.55)
    salary_release=np.clip((47000-lineups[:,6])/7000,0,1)
    return dict(names=names,teams=teams,idx=idx,cpt=cpt,salary=lineups[:,6],branch=branch,route=route,sp_count=spct,cpt_sp=cptsp,cpt_team_count=cpt_team_count,
                lane_sp_cpt_51=lane,lane_sp_cpt_51_speed=lane_speed,lane_sp_cpt_control_51=lane_control,lane_sp_cpt_control_51_speed=lane_control_speed,
                lane_sp_cpt_damage_15=lane_damage,lane_speed=low_speed,own_log=ownlog,own=own,speed=speed,sb=sb,
                cpt_speed_tail=cpt_speed_tail,same_team_release=same_team_release,release_player_count=release_player_count,primary_release_player=primary_release_player,opponent_top2_count=opponent_top2_count,salary_release=salary_release,
                lane_hitter_cpt_speed_low_spend=lane_hitter_cpt_speed_low_spend,
                lane_hitter_cpt_speed_low_spend_42=lane_hitter_cpt_speed_low_spend_42,
                lane_hitter_cpt_speed_low_spend_42_release=lane_hitter_cpt_speed_low_spend_42_release,
                lane_hitter_cpt_speed_low_spend_42_control=lane_hitter_cpt_speed_low_spend_42_control,
                lane_hitter_cpt_speed_low_spend_42_counter=lane_hitter_cpt_speed_low_spend_42_counter,
                lane_hitter_cpt_speed_low_spend_42_counter_top2=lane_hitter_cpt_speed_low_spend_42_counter_top2)

def proxy_metrics(p1,lineups):
    mu=p1.mean(0).astype(float); cov=np.cov(p1,rowvar=False).astype(float)
    W=np.zeros((len(lineups),p1.shape[1]),np.float32); r=np.arange(len(lineups))[:,None]; W[r,lineups[:,:6]]=1.; W[np.arange(len(lineups)),lineups[:,0]]=.5+W[np.arange(len(lineups)),lineups[:,0]]
    mean=W@mu; var=np.einsum('ij,jk,ik->i',W,cov,W,optimize=True); sd=np.sqrt(np.maximum(var,1e-6)); p95=mean+1.645*sd; p99=mean+2.326*sd
    return dict(mean=mean,p95=p95,p99=p99,win=pct_rank(mean+2.75*sd),top01=pct_rank(mean+2.30*sd))

def choose_fake(meta,count,seed):
    lw=meta['own_log']-np.abs(meta['salary']-49600)/6500+np.where(meta['branch']=='4-2',.18,0)+np.where(meta['branch']=='5-1',.10,0); lw-=lw.max(); w=np.exp(np.clip(lw,-60,0)); w/=w.sum()
    return np.random.default_rng(seed).choice(len(w),min(count,len(w)),replace=False,p=w)

def field_thresholds(scores,lineups,field_idx,topk,trial_chunk=2500):
    T=scores.shape[0]; mx=np.empty(T,np.float32); kth=np.empty(T,np.float32)
    for ts in range(0,T,trial_chunk):
        te=min(T,ts+trial_chunk); block=scores[ts:te]; fs=np.empty((len(field_idx),te-ts),np.float32)
        for s in range(0,len(field_idx),512):
            ids=field_idx[s:s+512]; lu=lineups[ids,:6]; v=block[:,lu].sum(2).T; v+=.5*block[:,lu[:,0]].T; fs[s:s+len(ids)]=v
        mx[ts:te]=fs.max(0); kth[ts:te]=np.partition(fs,len(field_idx)-topk,axis=0)[len(field_idx)-topk]
    return mx,kth

def score_lineups(scores,lineups,mx,kth,ids,chunk=320):
    ids=np.asarray(ids,np.int32); n=len(ids); out={k:np.empty(n,float) for k in ['mean','p95','p99','win','top01']}
    for s in range(0,n,chunk):
        z=ids[s:s+chunk]; lu=lineups[z,:6]; v=scores[:,lu].sum(2).transpose(1,0); v+=.5*scores[:,lu[:,0]].T
        out['mean'][s:s+len(z)]=v.mean(1); out['p95'][s:s+len(z)]=np.quantile(v,.95,axis=1); out['p99'][s:s+len(z)]=np.quantile(v,.99,axis=1)
        out['win'][s:s+len(z)]=(v>=mx).mean(1); out['top01'][s:s+len(z)]=(v>=kth).mean(1)
    return out

def phase2_birth(pm,meta):
    comp=.34*pct_rank(pm['top01'])+.20*pct_rank(pm['win'])+.20*pct_rank(pm['p99'])+.12*pct_rank(pm['p95'])+.08*pct_rank(pm['mean'])+.06*pct_rank(-meta['own_log'])
    selected=set(np.where(comp>=np.quantile(comp,.86))[0]); lanes=defaultdict(set); lanes['GLOBAL_CALIBRATED_TAIL'].update(selected)
    def add(mask,score,k,name,all_rows=False):
        ids=np.where(mask)[0]
        if not len(ids): return
        best=ids if all_rows else ids[np.argpartition(-score[ids],min(k,len(ids))-1)[:min(k,len(ids))]]
        selected.update(best.tolist()); lanes[name].update(best.tolist())
    for b in sorted(set(meta['branch'])): add(meta['branch']==b,comp,max(120,int((meta['branch']==b).sum()*.10)),f'BRANCH_{b}')
    for r in sorted(set(meta['route'])): add(meta['route']==r,comp,max(120,int((meta['route']==r).sum()*.12)),f'ROUTE_{r}')
    add(meta['sp_count']==2,comp,2200,'DUAL_SP_DIRTY_CLOSURE')
    add((~meta['cpt_sp'])&(meta['sp_count']>=1),comp,3000,'HITTER_CPT_SP_BRIDGE')
    add(meta['salary']<=47000,comp,1700,'LOW_SPEND_ELITE_TAIL')
    ls=.28*pct_rank(pm['top01'])+.18*pct_rank(pm['win'])+.17*pct_rank(pm['p99'])+.12*pct_rank(pm['p95'])+.10*pct_rank(-meta['own_log'])+.15*meta['lane_speed']
    add(meta['lane_sp_cpt_51'],ls,0,'SP_CPT_5_1_ONE_SP_SIBLING_CLOSURE',True)
    add(meta['lane_sp_cpt_51_speed'],ls,0,'SP_CPT_5_1_LOW_OWN_SPEED_RUNBACK',True)
    add(meta['lane_sp_cpt_control_51'],ls,0,'SP_CPT_CONTROL_5_1_SAME_TEAM_4BAT_CLOSURE',True)
    add(meta['lane_sp_cpt_control_51_speed'],ls,0,'SP_CPT_CONTROL_5_1_LOW_OWN_SPEED_RUNBACK',True)
    add(meta['lane_speed'],ls,512,'LOW_OWN_SPEED_ERUPTION_TAIL')
    hs=.25*pct_rank(pm['top01'])+.18*pct_rank(pm['win'])+.18*pct_rank(pm['p99'])+.12*pct_rank(pm['p95'])+.10*pct_rank(-meta['own_log'])+.09*meta['salary_release']+.08*meta['same_team_release']
    add(meta['lane_hitter_cpt_speed_low_spend'],hs,640,'HITTER_CPT_SPEED_LOW_SPEND_TAIL')
    add(meta['lane_hitter_cpt_speed_low_spend_42'],hs,640,'HITTER_CPT_SPEED_LOW_SPEND_4_2_SIBLINGS')
    add(meta['lane_hitter_cpt_speed_low_spend_42_release'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_SALARY_RELEASE_CLOSURE',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_control'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL_ORIENTATION',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_counter'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_ORIENTATION',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2_CORE',True)
    return np.array(sorted(selected),np.int32),comp,ls,{k:len(v) for k,v in lanes.items()}

def handoff(born,bm,meta):
    sc=.38*pct_rank(bm['top01'])+.22*pct_rank(bm['win'])+.18*pct_rank(bm['p99'])+.10*pct_rank(bm['p95'])+.06*pct_rank(bm['mean'])+.06*pct_rank(-meta['own_log'][born])
    sc+=.07*meta['lane_sp_cpt_51'][born]+.10*meta['lane_sp_cpt_51_speed'][born]+.05*meta['lane_speed'][born]
    sc+=.08*meta['lane_hitter_cpt_speed_low_spend_42'][born]+.13*meta['lane_hitter_cpt_speed_low_spend_42_release'][born]+.04*meta['salary_release'][born]
    k=min(1650,len(born)); sel=set(born[np.argpartition(-sc,k-1)[:k]].tolist()); reserve={}; pos={g:i for i,g in enumerate(born)}
    specs=[
      ('SP_CPT_5_1',meta['lane_sp_cpt_51'],220,False),('SP_CPT_5_1_SPEED',meta['lane_sp_cpt_51_speed'],0,True),
      ('SP_CPT_CONTROL_5_1',meta['lane_sp_cpt_control_51'],220,False),('SP_CPT_CONTROL_5_1_SPEED',meta['lane_sp_cpt_control_51_speed'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND',meta['lane_hitter_cpt_speed_low_spend'],240,False),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2',meta['lane_hitter_cpt_speed_low_spend_42'],384,False),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE',meta['lane_hitter_cpt_speed_low_spend_42_release'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL',meta['lane_hitter_cpt_speed_low_spend_42_control'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER',meta['lane_hitter_cpt_speed_low_spend_42_counter'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2',meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'],0,True),
      ('LOW_OWN_SPEED',meta['lane_speed'],120,False),('DUAL_SP',meta['sp_count']==2,96,False),('NO_SP',meta['sp_count']==0,96,False),('3_3',meta['branch']=='3-3',96,False)]
    for name,mask,k,all_rows in specs:
        ids=np.array([g for g in born if mask[g]],np.int32)
        if len(ids):
            best=ids if all_rows else ids[np.argpartition(-np.array([sc[pos[x]] for x in ids]),min(k,len(ids))-1)[:min(k,len(ids))]]
            before=len(sel); sel.update(best.tolist()); reserve[name]=len(sel)-before
        else: reserve[name]=0
    for p in range(len(meta['names'])):
        mask_without=~np.isin(meta['idx'][born],p).any(1); ids=born[mask_without]
        if len(ids):
            loc=np.where(mask_without)[0]; kk=min(96,len(ids)); best=ids[np.argpartition(-sc[loc],kk-1)[:kk]]
            before=len(sel); sel.update(best.tolist()); reserve[f'WITHOUT_PLAYER_ID_{p}']=len(sel)-before
        else: reserve[f'WITHOUT_PLAYER_ID_{p}']=0
    return np.array(sorted(sel),np.int32),reserve

def diverse_family_reps(cands,score,meta,mask,n=3,max_overlap=4,max_non_cpt_exposure=2):
    ids=np.where(mask)[0]
    ranked=ids[np.argsort(-score[ids],kind='mergesort')]
    eligible_rosters=[set(meta['idx'][cands[j]].tolist()) for j in ids]
    mandatory_spine=set.intersection(*eligible_rosters) if eligible_rosters else set()
    chosen=[]; counts=Counter()
    for j in ranked:
        g=cands[j]; roster=set(meta['idx'][g].tolist()); cpt=int(meta['cpt'][g])
        if any(p!=cpt and p not in mandatory_spine and counts[p]>=max_non_cpt_exposure for p in roster):
            continue
        if all(len(roster & set(meta['idx'][cands[k]].tolist()))<=max_overlap for k in chosen):
            chosen.append(int(j))
            for p in roster:
                if p!=cpt and p not in mandatory_spine: counts[p]+=1
            if len(chosen)>=n: break
    if len(chosen)<n:
        raise RuntimeError(f'DIVERSE_FAMILY_REP_UNSATISFIABLE:{len(chosen)}/{n}')
    return chosen

def best_by_signature_reps(cands,score,meta,mask,signatures,n=2,max_overlap=5):
    ids=np.where(mask)[0]
    groups=defaultdict(list)
    for j in ids: groups[int(signatures[j])].append(int(j))
    reps=[]
    for sig,js in groups.items(): reps.append(max(js,key=lambda j:(score[j],-j)))
    ranked=sorted(reps,key=lambda j:(-score[j],j))
    chosen=[]
    for j in ranked:
        roster=set(meta['idx'][cands[j]].tolist())
        if all(len(roster & set(meta['idx'][cands[k]].tolist()))<=max_overlap for k in chosen):
            chosen.append(j)
            if len(chosen)>=n: break
    if len(chosen)<n: raise RuntimeError(f'SIGNATURE_REP_UNSATISFIABLE:{len(chosen)}/{n}')
    return chosen

def select_milp(cands,cm,meta,size=10):
    score=.42*pct_rank(cm['top01'])+.23*pct_rank(cm['win'])+.17*pct_rank(cm['p99'])+.08*pct_rank(cm['p95'])+.05*pct_rank(cm['mean'])+.05*pct_rank(-meta['own_log'][cands])
    score+=.06*meta['lane_sp_cpt_51'][cands]+.08*meta['lane_sp_cpt_51_speed'][cands]+.07*meta['lane_sp_cpt_control_51'][cands]+.09*meta['lane_sp_cpt_control_51_speed'][cands]+.025*meta['lane_speed'][cands]
    score+=.07*meta['lane_hitter_cpt_speed_low_spend_42'][cands]+.11*meta['lane_hitter_cpt_speed_low_spend_42_release'][cands]+.05*meta['salary_release'][cands]
    score+=.06*meta['lane_hitter_cpt_speed_low_spend_42_control'][cands]+.10*meta['lane_hitter_cpt_speed_low_spend_42_counter'][cands]+.12*meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][cands]
    control_mask=meta['lane_sp_cpt_control_51_speed'][cands]
    hitter_control_mask=meta['lane_hitter_cpt_speed_low_spend_42_control'][cands]
    hitter_counter_mask=meta['lane_hitter_cpt_speed_low_spend_42_counter'][cands]
    hitter_counter_top2_mask=meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][cands]
    control_trigger=int(control_mask.sum())>=2 and size>=2
    hitter_trigger=int(hitter_counter_top2_mask.sum())>=2 and size>=3
    forced_reps=[]
    if control_trigger: forced_reps.extend(diverse_family_reps(cands,score,meta,control_mask,n=2,max_overlap=4))
    if hitter_control_mask.sum(): forced_reps.extend(diverse_family_reps(cands,score,meta,hitter_control_mask,n=1,max_overlap=5))
    if hitter_trigger:
        sig=meta['primary_release_player'][cands]
        forced_reps.extend(best_by_signature_reps(cands,score,meta,hitter_counter_top2_mask,sig,n=2,max_overlap=5))
    forced_reps=sorted(set(forced_reps))
    rows=[np.ones(len(cands))]; lb=[size]; ub=[size]
    for j in forced_reps:
        v=np.zeros(len(cands)); v[j]=1.; rows.append(v); lb.append(1); ub.append(1)
    n=len(meta['names'])
    for p in range(n):
        has=np.isin(meta['idx'][cands],p).any(1).astype(float); rows.append(has); lb.append(0); ub.append(max(1,math.ceil(size*.70)))
        cp=(meta['cpt'][cands]==p).astype(float)
        if cp.sum(): rows.append(cp); lb.append(0); ub.append(min(3,size))
    for a in range(n):
        ha=np.isin(meta['idx'][cands],a).any(1)
        for b in range(a+1,n):
            v=(ha & np.isin(meta['idx'][cands],b).any(1)).astype(float); pair_cap=max(1,math.ceil(size*.60))
            if v.sum()>pair_cap: rows.append(v); lb.append(0); ub.append(pair_cap)
    gates=[]
    if control_trigger:
        gates.extend([(meta['lane_sp_cpt_51'][cands],2,min(5,size)),(meta['lane_sp_cpt_51_speed'][cands],2,min(4,size)),
                      (meta['lane_sp_cpt_control_51'][cands],2,min(4,size)),(meta['lane_sp_cpt_control_51_speed'][cands],2,min(3,size))])
    if hitter_trigger:
        gates.extend([(meta['lane_hitter_cpt_speed_low_spend'][cands],3,min(6,size)),
                      (meta['lane_hitter_cpt_speed_low_spend_42'][cands],3,min(5,size)),
                      (meta['lane_hitter_cpt_speed_low_spend_42_release'][cands],3,min(5,size)),
                      (hitter_control_mask,1,min(3,size)),(hitter_counter_mask,2,min(4,size)),(hitter_counter_top2_mask,2,min(3,size))])
    lane_speed_mask=meta['lane_speed'][cands]; dual_mask=meta['sp_count'][cands]==2; no_sp_mask=meta['sp_count'][cands]==0; three_mask=meta['branch'][cands]=='3-3'; five_mask=meta['branch'][cands]=='5-1'; low_spend=meta['salary'][cands]<=47000
    gates.extend([(lane_speed_mask,1 if lane_speed_mask.any() and size>=3 else 0,min(6,size)),(dual_mask,0,min(4,size)),
                  (no_sp_mask,1 if no_sp_mask.any() and size>=3 else 0,min(5,size)),(three_mask,1 if three_mask.any() and size>=3 else 0,min(5,size)),
                  (five_mask,2 if control_trigger else 0,min(6,size)),(low_spend,3 if hitter_trigger else 0,min(6,size))])
    for mask,lo,hi in gates: rows.append(mask.astype(float)); lb.append(lo); ub.append(hi)
    res=milp(-score,integrality=np.ones(len(cands)),bounds=Bounds(0,1),constraints=LinearConstraint(csr_matrix(np.vstack(rows)),lb,ub),options={'time_limit':45})
    if not res.success: raise RuntimeError('MILP_FAIL:'+str(res.message))
    ch=np.where(res.x>.5)[0]; order=ch[np.argsort(-score[ch],kind='mergesort')]; return cands[order],score[order],res

def lkey(i,meta): return meta['names'][meta['cpt'][i]],tuple(sorted(meta['names'][meta['idx'][i,1:]].tolist()))

def run():
    t=time.time(); OUT.mkdir(parents=True,exist_ok=True)
    if not str(POOL_PATH) or not POOL_PATH.exists(): raise RuntimeError('MISSING_PLAYER_POOL')
    raw=pd.read_csv(POOL_PATH); pool=active_pool(raw); players=build_players(pool); p1=simulate_players(players,PHASE1_TRIALS,SEED)
    lineups=enumerate_lineups(players); meta=lineup_meta(lineups,players); proxy=proxy_metrics(p1,lineups); born,comp,ls,lane_counts=phase2_birth(proxy,meta)
    field=choose_fake(meta,FAKE_FIELD,SEED+91); bmx,bk=field_thresholds(p1[:BASE_TRIALS],lineups,field,TOP01_CUTOFF); bm=score_lineups(p1[:BASE_TRIALS],lineups,bmx,bk,born)
    h,reserve=handoff(born,bm,meta)
    emx,ek=field_thresholds(p1[BASE_TRIALS:],lineups,field,TOP01_CUTOFF); mx=np.concatenate([bmx,emx]); kth=np.concatenate([bk,ek]); fm=score_lineups(p1,lineups,mx,kth,h,chunk=240)
    pre=.42*pct_rank(fm['top01'])+.23*pct_rank(fm['win'])+.17*pct_rank(fm['p99'])+.08*pct_rank(fm['p95'])+.05*pct_rank(fm['mean'])+.05*pct_rank(-meta['own_log'][h])
    pre+=.06*meta['lane_sp_cpt_51'][h]+.08*meta['lane_sp_cpt_51_speed'][h]+.07*meta['lane_sp_cpt_control_51'][h]+.09*meta['lane_sp_cpt_control_51_speed'][h]
    pre+=.08*meta['lane_hitter_cpt_speed_low_spend_42'][h]+.14*meta['lane_hitter_cpt_speed_low_spend_42_release'][h]+.05*meta['salary_release'][h]
    keep=len(h); cand=set(h.tolist())
    for mask in [meta['lane_sp_cpt_51'],meta['lane_sp_cpt_51_speed'],meta['lane_sp_cpt_control_51'],meta['lane_sp_cpt_control_51_speed'],
                 meta['lane_hitter_cpt_speed_low_spend'],meta['lane_hitter_cpt_speed_low_spend_42'],meta['lane_hitter_cpt_speed_low_spend_42_release'],
                 meta['lane_hitter_cpt_speed_low_spend_42_control'],meta['lane_hitter_cpt_speed_low_spend_42_counter'],meta['lane_hitter_cpt_speed_low_spend_42_counter_top2']]:
        cand.update(h[mask[h]].tolist())
    cands=np.array(sorted(cand),np.int32); pos={g:i for i,g in enumerate(h)}; cm={k:np.array([fm[k][pos[g]] for g in cands]) for k in fm}
    board,bs,res=select_milp(cands,cm,meta,size=BOARD_SIZE); cpos={g:i for i,g in enumerate(cands)}; rows=[]
    for rank,(g,ss) in enumerate(zip(board,bs),1):
        z=meta['idx'][g]; j=cpos[g]; rows.append(dict(RANK=rank,LINEUP_INDEX=int(g),CPT=meta['names'][z[0]],UTIL1=meta['names'][z[1]],UTIL2=meta['names'][z[2]],UTIL3=meta['names'][z[3]],UTIL4=meta['names'][z[4]],UTIL5=meta['names'][z[5]],SALARY=int(meta['salary'][g]),BRANCH=meta['branch'][g],ROUTE=meta['route'][g],SP_COUNT=int(meta['sp_count'][g]),SP_CPT_5_1_CLOSURE=bool(meta['lane_sp_cpt_51'][g]),SP_CPT_CONTROL_5_1=bool(meta['lane_sp_cpt_control_51'][g]),LOW_OWN_SPEED_RUNBACK=bool(meta['lane_sp_cpt_51_speed'][g]),CONTROL_SPEED_RUNBACK=bool(meta['lane_sp_cpt_control_51_speed'][g]),HITTER_CPT_SPEED_LOW_SPEND=bool(meta['lane_hitter_cpt_speed_low_spend'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2=bool(meta['lane_hitter_cpt_speed_low_spend_42'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE=bool(meta['lane_hitter_cpt_speed_low_spend_42_release'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL=bool(meta['lane_hitter_cpt_speed_low_spend_42_control'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][g]),PRIMARY_RELEASE_PLAYER=(meta['names'][meta['primary_release_player'][g]] if meta['primary_release_player'][g]>=0 else ''),SALARY_RELEASE_SCORE=float(meta['salary_release'][g]),MC_TRIALS=50000,MC_WIN_RATE=float(cm['win'][j]),MC_TOP_0_1_RATE=float(cm['top01'][j]),MC_MEAN=float(cm['mean'][j]),MC_P95=float(cm['p95'][j]),MC_P99=float(cm['p99'][j]),SELECTOR_SCORE=float(ss)))
    bdf=pd.DataFrame(rows); sborn=set(born.tolist()); sh=set(h.tolist()); sboard=set(board.tolist())
    wi=None
    if WINNER is not None:
        winner=[i for i in range(len(lineups)) if lkey(i,meta)==(WINNER['CPT'],WINNER['UTILS'])]; wi=winner[0] if winner else None
        trace=dict(EVALUATED=True,LEGAL=wi is not None,LINEUP_INDEX=int(wi) if wi is not None else None,SALARY=int(meta['salary'][wi]) if wi is not None else None,BRANCH=meta['branch'][wi] if wi is not None else None,ROUTE=meta['route'][wi] if wi is not None else None,SP_CPT_5_1_CLOSURE=bool(meta['lane_sp_cpt_51'][wi]) if wi is not None else None,LOW_OWN_SPEED_RUNBACK=bool(meta['lane_sp_cpt_51_speed'][wi]) if wi is not None else None,SP_CPT_CONTROL_5_1=bool(meta['lane_sp_cpt_control_51'][wi]) if wi is not None else None,CONTROL_SPEED_RUNBACK=bool(meta['lane_sp_cpt_control_51_speed'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND=bool(meta['lane_hitter_cpt_speed_low_spend'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2=bool(meta['lane_hitter_cpt_speed_low_spend_42'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE=bool(meta['lane_hitter_cpt_speed_low_spend_42_release'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL=bool(meta['lane_hitter_cpt_speed_low_spend_42_control'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][wi]) if wi is not None else None,PRIMARY_RELEASE_PLAYER=(meta['names'][meta['primary_release_player'][wi]] if wi is not None and meta['primary_release_player'][wi]>=0 else None),PHASE2_BORN=wi in sborn if wi is not None else False,HANDOFF_SURVIVED=wi in sh if wi is not None else False,SELECTED_TO_BOARD=wi in sboard if wi is not None else False,BOARD_RANK=int(np.where(board==wi)[0][0]+1) if wi is not None and wi in sboard else None)
        if wi is not None and wi in sh:
            q=np.where(h==wi)[0][0]; trace['FINAL_METRICS']={k:float(fm[k][q]) for k in fm}; trace['HANDOFF_RANK_BY_TOP01']=int((-fm['top01']).argsort(kind='mergesort').tolist().index(q)+1)
    else:
        trace={'EVALUATED':False,'REASON':'FORWARD_BLIND_RESULTS_UNAVAILABLE'}
    bp=OUT/f'DK_MLB_SD_{EXECUTION_ID}_FINAL_BOARD.csv'; bdf.to_csv(bp,index=False)
    manifest=pd.DataFrame(dict(LINEUP_INDEX=born,CPT=[meta['names'][meta['cpt'][i]] for i in born],UTILS=['|'.join(meta['names'][meta['idx'][i,1:]]) for i in born],SALARY=meta['salary'][born],BRANCH=meta['branch'][born],ROUTE=meta['route'][born],SP_CPT_5_1_CLOSURE=meta['lane_sp_cpt_51'][born],LOW_OWN_SPEED_RUNBACK=meta['lane_sp_cpt_51_speed'][born],SP_CPT_CONTROL_5_1=meta['lane_sp_cpt_control_51'][born],CONTROL_SPEED_RUNBACK=meta['lane_sp_cpt_control_51_speed'][born],HITTER_CPT_SPEED_LOW_SPEND=meta['lane_hitter_cpt_speed_low_spend'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2=meta['lane_hitter_cpt_speed_low_spend_42'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE=meta['lane_hitter_cpt_speed_low_spend_42_release'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL=meta['lane_hitter_cpt_speed_low_spend_42_control'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER=meta['lane_hitter_cpt_speed_low_spend_42_counter'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2=meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][born],PRIMARY_RELEASE_PLAYER=[meta['names'][meta['primary_release_player'][i]] if meta['primary_release_player'][i]>=0 else '' for i in born],BASE_MC_WIN_RATE=bm['win'],BASE_MC_TOP_0_1_RATE=bm['top01'],BASE_MC_P95=bm['p95'],BASE_MC_P99=bm['p99']))
    mp=OUT/f'DK_MLB_SD_{EXECUTION_ID}_PHASE2_MANIFEST.csv'; manifest.to_csv(mp,index=False)
    control_trigger=int(meta['lane_sp_cpt_control_51_speed'].sum())>=2
    hitter_trigger=int(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'].sum())>=2
    stress=dict(SP_CPT_5_1_ONE_SP_SIBLING_CLOSURE=bool(bdf.SP_CPT_5_1_CLOSURE.any()) if control_trigger else True,
                SP_CPT_CONTROL_5_1_DIVERSE_REPS=(int(bdf.SP_CPT_CONTROL_5_1.sum())>=2) if control_trigger else True,
                LOW_OWN_SPEED_RUNBACK_CLOSURE=bool(bdf.LOW_OWN_SPEED_RUNBACK.any()) if control_trigger else True,
                CONTROL_SPEED_RUNBACK_DIVERSE_CLOSURE=(int(bdf.CONTROL_SPEED_RUNBACK.sum())>=2) if control_trigger else True,
                HITTER_CPT_SPEED_LOW_SPEND_CLOSURE=bool(bdf.HITTER_CPT_SPEED_LOW_SPEND.any()) if hitter_trigger else True,
                HITTER_CPT_SPEED_LOW_SPEND_4_2_DIVERSE_REPS=(int(bdf.HITTER_CPT_SPEED_LOW_SPEND_4_2.sum())>=2) if hitter_trigger else True,
                HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE_CAPTURE=(int(bdf.HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE.sum())>=3) if hitter_trigger else True,
                HITTER_CPT_SPEED_LOW_SPEND_4_2_ORIENTATION_BALANCE=(int(bdf.HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL.sum())>=1 and int(bdf.HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER.sum())>=2) if hitter_trigger else True,
                HITTER_CPT_SPEED_LOW_SPEND_COUNTER_TOP2_DIVERSE_RELEASE=(int(bdf.HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2.sum())>=2 and bdf.loc[bdf.HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2,'PRIMARY_RELEASE_PLAYER'].nunique()>=2) if hitter_trigger else True,
                LOW_SPEND_BOARD_BREADTH=(int((bdf.SALARY<=47000).sum())>=2) if hitter_trigger else True,
                NO_POST_PHASE2_MUTATION=True,RAW_AGGREGATE_PHASE1_REJECTION=True,NO_FILLERS_USED=True,NO_RANK_ALL_USED=True,MILP_OPTIMAL=bool(res.success))
    if WINNER is not None:
        stress.update(WINNER_BIRTH_RECALL=trace['PHASE2_BORN'],WINNER_HANDOFF_RECALL=trace['HANDOFF_SURVIVED'],WINNER_BOARD_CAPTURE=trace['SELECTED_TO_BOARD'])
    receipt=dict(PATCH_ID=PATCH_ID,ENGINE_ID=ENGINE_ID,MODE='FORWARD_BLIND' if WINNER is None else 'POST_LOCK_SELF_HEAL_BLIND_REPLAY',EXECUTION_ID=EXECUTION_ID,FIELD_SIZE=FIELD_SIZE,INPUT_SHA256=sha_file(POOL_PATH),PHASE0=dict(RAW_ROWS=len(raw),ACTIVE_POOL=len(pool),OUT_PURGE=len(raw)-len(pool),STARTERS=[p['name'] for p in players if p['is_sp']],FORBIDDEN_AGGREGATES_REJECTED=[c for c in FORBIDDEN if c in raw.columns]),PHASE1=dict(MC_ITERATIONS=50000,RAW_AGGREGATE_PROJECTIONS_USED=False,PLAYER_MATRIX_SHA256=sha_bytes(p1.tobytes())),PHASE2=dict(EXPECTED_SEARCH_SPACE=int(len(players)*math.comb(len(players)-1,5)),SCANNED_COMBINATIONS=int(len(players)*math.comb(len(players)-1,5)),LEGAL_LINEUPS_FOUND=len(lineups),PHASE2_BUILT_LINEUPS=len(born),CALIBRATION_REJECTED_LINEUPS=len(lineups)-len(born),FULL_LEGAL_SCAN_COMPLETE=True,LANE_COUNTS=lane_counts,SP_CPT_5_1_LEGAL=int(meta['lane_sp_cpt_51'].sum()),SP_CPT_5_1_SPEED_LEGAL=int(meta['lane_sp_cpt_51_speed'].sum()),SP_CPT_CONTROL_5_1_LEGAL=int(meta['lane_sp_cpt_control_51'].sum()),SP_CPT_CONTROL_5_1_SPEED_LEGAL=int(meta['lane_sp_cpt_control_51_speed'].sum()),HITTER_CPT_SPEED_LOW_SPEND_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_release'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_control'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_counter'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'].sum()),PHASE2_MANIFEST_SHA256=sha_file(mp)),HANDOFF=dict(INPUT_BORN=len(born),SURVIVORS=len(h),STRUCTURAL_RESERVE_ADDITIONS=reserve,BASE_SIM_TRIALS=10000,EXTRA_SIM_TRIALS_PER_HANDOFF=40000,BUBBLE_EXTRA_TRIALS_TOTAL=len(h)*40000),SELECTOR=dict(REVIEWED_LINEUPS=len(cands),FINAL_BOARD_SIZE=BOARD_SIZE,MILP_STATUS=int(res.status),MILP_MESSAGE=res.message,RAW_PROJECTIONS_EXPOSED=False,FILLERS_USED=False,RANK_ALL_USED=False),WINNER_TRACE_POSTSEAL_ONLY=trace,STRESS=stress,RUNTIME_SECONDS=time.time()-t,ARTIFACTS=dict(BOARD=str(bp),PHASE2_MANIFEST=str(mp)),BOARD_SHA256=sha_file(bp))
    rp=OUT/f'DK_MLB_SD_{EXECUTION_ID}_FINAL_RECEIPT.json'; rp.write_text(json.dumps(receipt,indent=2),encoding='utf-8'); receipt['RECEIPT_SHA256']=sha_file(rp); rp.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(dict(STATUS='PASS' if all(stress.values()) else 'FAIL',LEGAL=len(lineups),BORN=len(born),HANDOFF=len(h),CANDIDATES=len(cands),WINNER_TRACE=trace,BOARD=bdf.to_dict('records'),RUNTIME_SECONDS=receipt['RUNTIME_SECONDS']),indent=2))
if __name__=='__main__': run()
