from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

PATCH_ID = "HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1"
CONTRACT_VERSION = "1.0.0"
BASE_SIM_TRIALS = 10_000
BUBBLE_BATCH_SIZE = 10_000
MAX_SIM_TRIALS = 50_000
CONFIDENCE_LEVEL = 0.95
CI_Z = 1.959963984540054


class EngineIntegrityHalt(RuntimeError):
    """Fail-closed handoff integrity exception with a stable machine code."""

    def __init__(self, code: str, detail: str, mismatches: Sequence[str] | None = None) -> None:
        self.code = code
        self.detail = detail
        self.mismatches = tuple(mismatches or ())
        payload = {
            "ENGINE_INTEGRITY_HALT": True,
            "FAILURE_CLASS": code,
            "DETAIL": detail,
            "MISMATCHES": list(self.mismatches),
            "FINAL_BOARD_SIZE": 0,
        }
        super().__init__(json.dumps(payload, sort_keys=True))

    def receipt(self) -> dict[str, Any]:
        return {
            "ENGINE_INTEGRITY_HALT": True,
            "FAILURE_CLASS": self.code,
            "DETAIL": self.detail,
            "MISMATCHES": list(self.mismatches),
            "FINAL_BOARD_SIZE": 0,
        }


def stable_hash(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _canonical_matrix(matrix: Sequence[Sequence[float]]) -> list[list[float]]:
    rows = [[float(v) for v in row] for row in matrix]
    n = len(rows)
    if n == 0 or any(len(row) != n for row in rows):
        raise EngineIntegrityHalt(
            "HANDOFF_METRIC_BUNDLE_INVALID",
            "Correlation/covariance matrices must be non-empty square matrices.",
        )
    return rows


def _canonical_vector(values: Sequence[float]) -> list[float]:
    return [float(v) for v in values]


@dataclass(frozen=True)
class SharedMetricBundle:
    player_ids: tuple[str, ...]
    correlation_matrix: tuple[tuple[float, ...], ...]
    covariance_matrix: tuple[tuple[float, ...], ...]
    ownership_vector: tuple[float, ...]
    ceiling_vector: tuple[float, ...]
    ceiling_definition: Mapping[str, Any]
    stack_features: Mapping[str, Any]
    metric_scaling: Mapping[str, Any]
    role_status_state: Mapping[str, Any]
    base_sim_trials: int = BASE_SIM_TRIALS
    bundle_version: str = CONTRACT_VERSION

    @classmethod
    def build(
        cls,
        *,
        player_ids: Sequence[str | int],
        correlation_matrix: Sequence[Sequence[float]],
        covariance_matrix: Sequence[Sequence[float]],
        ownership_vector: Sequence[float],
        ceiling_vector: Sequence[float],
        ceiling_definition: Mapping[str, Any],
        stack_features: Mapping[str, Any],
        metric_scaling: Mapping[str, Any],
        role_status_state: Mapping[str, Any],
        base_sim_trials: int = BASE_SIM_TRIALS,
    ) -> "SharedMetricBundle":
        ids = tuple(str(v) for v in player_ids)
        corr = tuple(tuple(row) for row in _canonical_matrix(correlation_matrix))
        cov = tuple(tuple(row) for row in _canonical_matrix(covariance_matrix))
        own = tuple(_canonical_vector(ownership_vector))
        ceil = tuple(_canonical_vector(ceiling_vector))
        n = len(ids)
        mismatches: list[str] = []
        if len(corr) != n:
            mismatches.append("CORRELATION_DIMENSION")
        if len(cov) != n:
            mismatches.append("COVARIANCE_DIMENSION")
        if len(own) != n:
            mismatches.append("OWNERSHIP_DIMENSION")
        if len(ceil) != n:
            mismatches.append("CEILING_DIMENSION")
        if len(set(ids)) != n:
            mismatches.append("DUPLICATE_PLAYER_IDS")
        if base_sim_trials < BASE_SIM_TRIALS:
            mismatches.append("BASE_SIM_TRIALS_LT_10000")
        if mismatches:
            raise EngineIntegrityHalt(
                "HANDOFF_METRIC_BUNDLE_INVALID",
                "Shared metric bundle failed structural validation.",
                mismatches,
            )
        return cls(
            player_ids=ids,
            correlation_matrix=corr,
            covariance_matrix=cov,
            ownership_vector=own,
            ceiling_vector=ceil,
            ceiling_definition=dict(ceiling_definition),
            stack_features=dict(stack_features),
            metric_scaling=dict(metric_scaling),
            role_status_state=dict(role_status_state),
            base_sim_trials=int(base_sim_trials),
        )

    def component_hashes(self) -> dict[str, str]:
        return {
            "PLAYER_ID_ORDER_HASH": stable_hash(self.player_ids),
            "CORRELATION_MATRIX_HASH": stable_hash(self.correlation_matrix),
            "COVARIANCE_MATRIX_HASH": stable_hash(self.covariance_matrix),
            "OWNERSHIP_VECTOR_HASH": stable_hash(self.ownership_vector),
            "CEILING_VECTOR_HASH": stable_hash(self.ceiling_vector),
            "CEILING_DEFINITION_HASH": stable_hash(self.ceiling_definition),
            "STACK_FEATURES_HASH": stable_hash(self.stack_features),
            "METRIC_SCALING_HASH": stable_hash(self.metric_scaling),
            "ROLE_STATUS_STATE_HASH": stable_hash(self.role_status_state),
            "BASE_SIM_TRIALS_HASH": stable_hash(self.base_sim_trials),
        }

    def bundle_id(self) -> str:
        return stable_hash({
            "PATCH_ID": PATCH_ID,
            "CONTRACT_VERSION": self.bundle_version,
            "COMPONENT_HASHES": self.component_hashes(),
        })

    def receipt(self, phase: str) -> dict[str, Any]:
        return {
            "PATCH_ID": PATCH_ID,
            "CONTRACT_VERSION": self.bundle_version,
            "PHASE": phase,
            "SHARED_METRIC_BUNDLE_ID": self.bundle_id(),
            **self.component_hashes(),
            "BASE_SIM_TRIALS": self.base_sim_trials,
        }


def verify_phase_metric_parity(
    phase2_receipt: Mapping[str, Any],
    phase3_receipt: Mapping[str, Any],
) -> dict[str, Any]:
    required = (
        "SHARED_METRIC_BUNDLE_ID",
        "PLAYER_ID_ORDER_HASH",
        "CORRELATION_MATRIX_HASH",
        "COVARIANCE_MATRIX_HASH",
        "OWNERSHIP_VECTOR_HASH",
        "CEILING_VECTOR_HASH",
        "CEILING_DEFINITION_HASH",
        "STACK_FEATURES_HASH",
        "METRIC_SCALING_HASH",
        "ROLE_STATUS_STATE_HASH",
        "BASE_SIM_TRIALS_HASH",
    )
    mismatches: list[str] = []
    for key in required:
        if key not in phase2_receipt or key not in phase3_receipt:
            mismatches.append(f"MISSING:{key}")
        elif phase2_receipt[key] != phase3_receipt[key]:
            mismatches.append(f"MISMATCH:{key}")
    p2_trials = int(phase2_receipt.get("BASE_SIM_TRIALS", 0))
    p3_trials = int(phase3_receipt.get("BASE_SIM_TRIALS", 0))
    if p2_trials < BASE_SIM_TRIALS:
        mismatches.append("PHASE2_BASE_SIM_TRIALS_LT_10000")
    if p3_trials < BASE_SIM_TRIALS:
        mismatches.append("PHASE3_BASE_SIM_TRIALS_LT_10000")
    if mismatches:
        raise EngineIntegrityHalt(
            "HANDOFF_METRIC_DRIFT",
            "Phase 2 and Phase 3 do not share the same immutable metric geometry.",
            mismatches,
        )
    return {
        "PATCH_ID": PATCH_ID,
        "METRIC_PARITY_CHECK": "PASS",
        "SHARED_METRIC_BUNDLE_ID": phase2_receipt["SHARED_METRIC_BUNDLE_ID"],
        "VERIFIED_KEYS": list(required),
        "BASE_SIM_TRIALS": p2_trials,
    }


def normal_rate_interval(successes: int, trials: int, z: float = CI_Z) -> tuple[float, float]:
    if trials <= 0 or successes < 0 or successes > trials:
        raise ValueError("invalid binomial state")
    p = successes / trials
    se = math.sqrt(max(p * (1.0 - p), 1e-12) / trials)
    return max(0.0, p - z * se), min(1.0, p + z * se)


def classify_boundary(
    *,
    candidate_lcb: float,
    candidate_ucb: float,
    cutoff_lcb: float,
    cutoff_ucb: float,
    trials: int,
    max_trials: int = MAX_SIM_TRIALS,
) -> str:
    if candidate_ucb < cutoff_lcb:
        return "RESOLVED_FAIL"
    if candidate_lcb > cutoff_ucb:
        return "RESOLVED_PASS"
    if trials >= max_trials:
        return "UNRESOLVED_BUBBLE_PASS_FORWARD"
    return "EXTRA_TRIALS_REQUIRED"


@dataclass
class BubbleRoundTelemetry:
    round_index: int
    batch_trials: int
    candidates_entered: int
    candidates_resolved_pass: int
    candidates_resolved_fail: int
    candidates_unresolved: int
    physical_candidate_trials: int
    effective_tail_candidate_trials: int
    runtime_ms: float


@dataclass
class HandoffTelemetry:
    run_id: str
    platform: str
    sport: str
    mode: str
    execution_id: str
    field_size: int
    shared_metric_bundle_id: str
    phase2_built_lineups: int
    base_simulated_lineups: int
    base_sim_trials: int = BASE_SIM_TRIALS
    bubble_batch_size: int = BUBBLE_BATCH_SIZE
    max_sim_trials: int = MAX_SIM_TRIALS
    confidence_level: float = CONFIDENCE_LEVEL
    tail_ess_multiplier: float = 1.0
    bubble_lineups_found: int = 0
    bubble_extra_trials_total: int = 0
    bubble_effective_tail_trials_total: int = 0
    bubble_lineups_resolved_pass: int = 0
    bubble_lineups_resolved_fail: int = 0
    bubble_lineups_unresolved: int = 0
    handoff_survivors: int = 0
    selector_reviewed_lineups: int = 0
    survivor_inflation: float = 0.0
    metric_parity_check: str = "PASS"
    engine_integrity_halt: bool = False
    integrity_failure_class: str | None = None
    rounds: list[BubbleRoundTelemetry] = field(default_factory=list)
    emitted_at_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def validate(self) -> None:
        mismatches: list[str] = []
        if self.base_sim_trials < BASE_SIM_TRIALS:
            mismatches.append("BASE_SIM_TRIALS_LT_10000")
        if self.max_sim_trials < self.base_sim_trials:
            mismatches.append("MAX_SIM_TRIALS_LT_BASE")
        if self.bubble_batch_size <= 0:
            mismatches.append("BUBBLE_BATCH_SIZE_NONPOSITIVE")
        if self.metric_parity_check != "PASS" and not self.engine_integrity_halt:
            mismatches.append("METRIC_PARITY_FAILURE_WITHOUT_HALT")
        if self.bubble_lineups_unresolved > self.bubble_lineups_found:
            mismatches.append("UNRESOLVED_GT_FOUND")
        if self.selector_reviewed_lineups < self.handoff_survivors:
            mismatches.append("SELECTOR_REVIEW_LT_HANDOFF")
        if mismatches:
            raise EngineIntegrityHalt(
                "HANDOFF_TELEMETRY_INVALID",
                "Adaptive handoff telemetry failed validation.",
                mismatches,
            )

    def unresolved_rate(self) -> float:
        return self.bubble_lineups_unresolved / max(1, self.bubble_lineups_found)

    def extra_trials_per_bubble(self) -> float:
        return self.bubble_extra_trials_total / max(1, self.bubble_lineups_found)

    def to_receipt(self) -> dict[str, Any]:
        self.validate()
        data = asdict(self)
        data.update({
            "PATCH_ID": PATCH_ID,
            "UNRESOLVED_RATE": self.unresolved_rate(),
            "EXTRA_TRIALS_PER_BUBBLE": self.extra_trials_per_bubble(),
        })
        return data


def evaluate_alerts(telemetry: HandoffTelemetry) -> list[dict[str, Any]]:
    alerts: list[dict[str, Any]] = []
    if telemetry.engine_integrity_halt:
        alerts.append({
            "SEVERITY": "CRITICAL",
            "CODE": "ENGINE_INTEGRITY_HALT",
            "ACTION": "STOP_FINAL_BOARD_AND_PAGE_ENGINE_OWNER",
            "FAILURE_CLASS": telemetry.integrity_failure_class,
        })
    if telemetry.metric_parity_check != "PASS":
        alerts.append({
            "SEVERITY": "CRITICAL",
            "CODE": "HANDOFF_METRIC_DRIFT",
            "ACTION": "STOP_FINAL_BOARD_AND_COMPARE_COMPONENT_HASHES",
        })
    unresolved_rate = telemetry.unresolved_rate()
    if unresolved_rate > 0.50:
        alerts.append({
            "SEVERITY": "CRITICAL",
            "CODE": "BUBBLE_UNRESOLVED_RATE_GT_50_PERCENT",
            "VALUE": unresolved_rate,
            "ACTION": "PASS_FORWARD_AND_REVIEW_CI_OR_TAIL_ESS_PROFILE",
        })
    elif unresolved_rate > 0.25:
        alerts.append({
            "SEVERITY": "WARNING",
            "CODE": "BUBBLE_UNRESOLVED_RATE_GT_25_PERCENT",
            "VALUE": unresolved_rate,
            "ACTION": "REVIEW_CI_WIDTH_BATCH_SIZE_AND_TAIL_ESS_PROFILE",
        })
    if telemetry.survivor_inflation > 4.0:
        alerts.append({
            "SEVERITY": "WARNING",
            "CODE": "HANDOFF_SURVIVOR_INFLATION_GT_4X",
            "VALUE": telemetry.survivor_inflation,
            "ACTION": "REVIEW_BUBBLE_CAP_WITHOUT_RELAXING_PASS_FORWARD",
        })
    if telemetry.extra_trials_per_bubble() > (MAX_SIM_TRIALS - BASE_SIM_TRIALS) * 0.90:
        alerts.append({
            "SEVERITY": "WARNING",
            "CODE": "BUBBLE_TRIAL_SATURATION",
            "VALUE": telemetry.extra_trials_per_bubble(),
            "ACTION": "REVIEW_BATCH_SCHEDULER_AND_EVENT_RATE_RESOLUTION",
        })
    return alerts


SPORT_PROFILES: dict[str, dict[str, Any]] = {
    "DEFAULT": {
        "BASE_SIM_TRIALS": BASE_SIM_TRIALS,
        "BUBBLE_BATCH_SIZE": BUBBLE_BATCH_SIZE,
        "MAX_SIM_TRIALS": MAX_SIM_TRIALS,
        "CONFIDENCE_LEVEL": CONFIDENCE_LEVEL,
        "TAIL_ESS_MULTIPLIER": 1,
        "UNRESOLVED_ACTION": "PASS_FORWARD",
    },
    "MLB": {
        "BASE_SIM_TRIALS": BASE_SIM_TRIALS,
        "BUBBLE_BATCH_SIZE": BUBBLE_BATCH_SIZE,
        "MAX_SIM_TRIALS": MAX_SIM_TRIALS,
        "CONFIDENCE_LEVEL": CONFIDENCE_LEVEL,
        "TAIL_ESS_MULTIPLIER": 1,
        "BUBBLE_METHOD": "95_PERCENT_COMPOSITE_BUBBLE_RACING",
        "UNRESOLVED_ACTION": "PASS_FORWARD",
    },
    "WNBA": {
        "BASE_SIM_TRIALS": BASE_SIM_TRIALS,
        "BUBBLE_BATCH_SIZE": BUBBLE_BATCH_SIZE,
        "MAX_SIM_TRIALS": MAX_SIM_TRIALS,
        "CONFIDENCE_LEVEL": CONFIDENCE_LEVEL,
        "TAIL_ESS_MULTIPLIER": 10,
        "BUBBLE_METHOD": "CONDITIONAL_IMPORTANCE_SAMPLED_TAIL_RACING",
        "IMPORTANCE_WEIGHTS": "NORMALIZED",
        "REPORT_EFFECTIVE_SAMPLE_SIZE": True,
        "UNRESOLVED_ACTION": "PASS_FORWARD",
    },
}


def sport_profile(sport: str) -> dict[str, Any]:
    key = sport.strip().upper()
    return dict(SPORT_PROFILES.get(key, SPORT_PROFILES["DEFAULT"]))


def install_manifest(root: Path) -> dict[str, Any]:
    files: dict[str, dict[str, Any]] = {}
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name != "manifest.json" and "__pycache__" not in path.parts:
            files[str(path.relative_to(root))] = {
                "bytes": path.stat().st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
    return {
        "PATCH_ID": PATCH_ID,
        "CONTRACT_VERSION": CONTRACT_VERSION,
        "STATUS": "SEALED_GLOBAL_CONTRACT",
        "SCOPE": "ALL_SPORTS_ALL_MODES_ALL_CHATS",
        "SPORT_VALIDATION": {"MLB": "PASS", "WNBA": "PASS_WITH_10X_TAIL_ESS"},
        "FILES": files,
    }
