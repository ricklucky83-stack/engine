#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from engines.common.mandatory_prebuild_roster_gate_v1 import require_prebuild_roster_check
PATCH_ID='MLB_HRS_GLOBAL_CHUNK_STREAM_ADAPTER_v1'
GENERIC=ROOT/'engines/common/apex_generic_python_chunk_stream_controller_v1.py'

def _args():
    if len(sys.argv)==1:
        return argparse.Namespace(player_pool=os.environ.get('APEX_PLAYER_POOL'),field_size=int(os.environ.get('APEX_FIELD_SIZE','0')),execution_id=os.environ.get('APEX_EXECUTION_ID'),availability_receipt=os.environ.get('APEX_PREBUILD_AVAILABILITY_RECEIPT'),output_dir=os.environ.get('APEX_OUTPUT_DIR','/mnt/data'),board_size=int(os.environ.get('APEX_BOARD_SIZE','10')),seed=int(os.environ['APEX_SEED']) if os.environ.get('APEX_SEED') else None)
    ap=argparse.ArgumentParser(); ap.add_argument('command',nargs='?'); ap.add_argument('--player-pool',required=True); ap.add_argument('--field-size',required=True,type=int); ap.add_argument('--execution-id',required=True); ap.add_argument('--availability-receipt'); ap.add_argument('--output-dir',default='/mnt/data'); ap.add_argument('--board-size',type=int,default=10); ap.add_argument('--seed',type=int); ap.add_argument('--contest-file'); ap.add_argument('--phase2-manifest'); ap.add_argument('--board'); ap.add_argument('--receipt'); return ap.parse_args()

def main():
    a=_args(); runroot=Path(os.environ.get('APEX_RESUMABLE_RUN_ROOT') or a.output_dir).resolve(); wrap=runroot/'mlb_hrs_adapter'; wrap.mkdir(parents=True,exist_ok=True)
    source=Path(a.player_pool or os.environ.get('APEX_PLAYER_POOL','')).resolve()
    if not source.exists() or int(a.field_size)<=0: raise RuntimeError('RUN_INVALID:MLB_HRS_INPUT_MISSING')
    gate=require_prebuild_roster_check(a.availability_receipt,sport='MLB',mode='HRS',pool_path=source,execution_id=a.execution_id,field_size=int(a.field_size))
    verified=wrap/'verified_pool.csv'
    if not verified.exists():
        with source.open('r',newline='',encoding='utf-8-sig') as src:
            rd=csv.DictReader(src); fields=rd.fieldnames or []; pc=next((x for x in fields if x.strip().upper()=='PLAYER'),None)
            if pc is None: raise RuntimeError('RUN_INVALID:PLAYER_POOL_PLAYER_COLUMN_MISSING')
            outs=set(gate.out_players); rows=[r for r in rd if str(r.get(pc,'')).strip() not in outs]
        with verified.open('w',newline='',encoding='utf-8') as dst:
            wr=csv.DictWriter(dst,fieldnames=fields); wr.writeheader(); wr.writerows(rows)
    env=dict(os.environ); env.update({'APEX_PLAYER_POOL':str(verified),'APEX_FIELD_SIZE':str(a.field_size),'APEX_EXECUTION_ID':str(a.execution_id),'APEX_OUTPUT_DIR':str(Path(a.output_dir).resolve()),'APEX_BOARD_SIZE':str(a.board_size),'APEX_MODE':'HRS','APEX_SPORT_MODE':'HRS','APEX_SPORT':'MLB'})
    if a.seed is not None: env['APEX_SEED']=str(a.seed)
    cp=subprocess.run([sys.executable,str(GENERIC)],env=env,cwd=str(ROOT),check=False,text=True,capture_output=True)
    if cp.stdout: sys.stdout.write(cp.stdout); sys.stdout.flush()
    if cp.stderr: sys.stderr.write(cp.stderr); sys.stderr.flush()
    return cp.returncode
if __name__=='__main__':
    try: raise SystemExit(main())
    except SystemExit: raise
    except Exception as exc:
        print(json.dumps({'RUN_STATE':'RUN_INVALID','EXECUTION_STATE':'FAILED','PATCH_ID':PATCH_ID,'FAILURE_CODE':f'{type(exc).__name__}:{exc}','FINAL_BOARD_SIZE':0})); raise SystemExit(2)
