from __future__ import annotations
import csv, heapq, itertools, json, math, os
from collections import Counter, defaultdict
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

import mlb_classic_saved_top50_family_door_calibration_v1 as calmod

PATCH_ID="MLB_CLASSIC_SAVED_FAMILY_BLIND_REPLAY_v1"
SLOTS=("C","1B","2B","3B","SS","OF","OF","OF")
BOARD_SLOTS=("P1","P2","C","1B","2B","3B","SS","OF1","OF2","OF3")

POOL=Path(os.environ["APEX_PLAYER_POOL"])
PHASE1=Path(os.environ["APEX_PHASE1_DIR"])
CAL=Path(os.environ["APEX_CALIBRATION_ASSET"])
OUT=Path(os.environ["APEX_OUTPUT_DIR"]); OUT.mkdir(parents=True,exist_ok=True)
BOARD_SIZE=int(os.environ.get("APEX_BOARD_SIZE","10"))
LANE_DEPTH=int(os.environ.get("APEX_CALIBRATION_LANE_DEPTH","512"))
FAMILY_KEEP=int(os.environ.get("APEX_CALIBRATION_FAMILY_KEEP","512"))
BASE_TRIALS=int(os.environ.get("APEX_BASE_SIMS","10000"))

cal=calmod.load(CAL)
pool=pd.read_csv(POOL,dtype=str,keep_default_na=False)
def active(row):
    if row["POS"]=="P":
        return str(row["LINEUP"]).strip().upper()=="SP"
    try:
        return 1 <= int(float(str(row["LINEUP"]).strip())) <= 9
    except Exception:
        return False
active_pool=pool[pool.apply(active,axis=1)].copy()
slate_fp=calmod.validate_matching_slate(cal,active_pool.to_dict("records"))

meta=json.loads((PHASE1/"phase1_player_meta.json").read_text())["players"]
m=np.load(PHASE1/"phase1_player_metrics.npz")
phase1_scores=np.load(PHASE1/"phase1_scores.npy",mmap_mode="r")
player_mean=m["player_mean"].astype(np.float64)
player_p95=m["player_p95"].astype(np.float64)
player_p99=m["player_p99"].astype(np.float64)
corr=m["correlation"].astype(np.float64)
by={int(p["idx"]):p for p in meta}
name_to_idx={str(p["name"]):int(p["idx"]) for p in meta}
team_to_hitters=defaultdict(list)
for p in meta:
    if "P" not in p["positions"]:
        team_to_hitters[str(p["team"])].append(int(p["idx"]))

def can_play(i,slot):
    return slot in by[int(i)]["positions"]

@lru_cache(maxsize=300000)
def assign_hitters(ids):
    ordered=sorted(ids,key=lambda i:(sum(can_play(i,s) for s in SLOTS),-player_p99[i],by[i]["pid"]))
    states={0:()}
    for i in ordered:
        nxt={}
        for mask,chosen in states.items():
            for si,s in enumerate(SLOTS):
                bit=1<<si
                if mask & bit or not can_play(i,s):
                    continue
                nm=mask|bit
                if nm not in nxt:
                    nxt[nm]=chosen+(si,)
        states=nxt
        if not states:
            return None
    chosen=states.get((1<<8)-1)
    if chosen is None:
        return None
    out=[None]*8
    for i,si in zip(ordered,chosen):
        out[si]=int(i)
    return tuple(out)

combo_cache={}
def team_combos(team,k):
    key=(team,int(k))
    if key in combo_cache:
        return combo_cache[key]
    rows=[]
    for co in itertools.combinations(team_to_hitters[team],int(k)):
        ids=tuple(int(x) for x in co)
        sal=sum(int(by[i]["salary"]) for i in ids)
        orders=sorted(int(by[i]["lineup"]) for i in ids)
        adj=sum(1 for a,b in zip(orders,orders[1:]) if b-a<=2)
        wrap=int(1 in orders and 9 in orders)
        top5=sum(1 for x in orders if x<=5)
        lev=sum(float(by[i]["strategy_leverage"]) for i in ids)
        chalk=sum(float(by[i]["chalk_failure_edge"]) for i in ids)
        p95=float(player_p95[list(ids)].sum())
        p99=float(player_p99[list(ids)].sum())
        mean=float(player_mean[list(ids)].sum())
        pre=0.12*mean+0.28*p95+0.60*p99+1.55*adj+1.10*wrap+0.35*top5+0.003*sal+0.75*lev
        rows.append({
            "ids":ids,"salary":sal,"adj":adj,"top5":top5,"lev":lev,"chalk":chalk,
            "p95":p95,"p99":p99,"mean":mean,"pre":pre
        })
    combo_cache[key]=rows
    return rows

LANES={
    "pre":"pre",
    "p95":"p95",
    "p99":"p99",
    "salary":"salary",
    "top5":"top5",
    "lev":"lev",
    "adj":"adj",
}

def kbest_product(sorted_lists,metric,k):
    if not sorted_lists or any(not x for x in sorted_lists):
        return []
    start=tuple(0 for _ in sorted_lists)
    def score(state):
        return sum(float(sorted_lists[d][state[d]][metric]) for d in range(len(state)))
    heap=[(-score(start),start)]
    seen={start}; out=[]
    while heap and len(out)<k:
        neg,state=heapq.heappop(heap)
        out.append(state)
        for d in range(len(state)):
            if state[d]+1 >= len(sorted_lists[d]):
                continue
            ns=list(state); ns[d]+=1; ns=tuple(ns)
            if ns in seen:
                continue
            seen.add(ns)
            heapq.heappush(heap,(-score(ns),ns))
    return out

def pct(v):
    x=np.asarray(v,dtype=np.float64); n=len(x)
    if n<=1:
        return np.ones(n,dtype=np.float64)
    order=np.argsort(x,kind="mergesort")
    out=np.empty(n,dtype=np.float64)
    sv=x[order]
    i=0
    while i<n:
        j=i+1
        while j<n and sv[j]==sv[i]:
            j+=1
        rank=((i+j-1)/2.0+0.5)/n
        out[order[i:j]]=rank
        i=j
    return out

family_candidates=[]
seen_lineups=set()
family_receipts=[]

for fam in cal["FAMILIES"]:
    pair_names=tuple(fam["PITCHER_PAIR"])
    if any(n not in name_to_idx for n in pair_names):
        family_receipts.append({"FAMILY_KEY":fam["FAMILY_KEY"],"STATUS":"PITCHER_NAME_MISSING"})
        continue
    pp=tuple(sorted((name_to_idx[pair_names[0]],name_to_idx[pair_names[1]]),key=lambda i:(-player_p99[i],by[i]["pid"])))
    pp_salary=sum(int(by[i]["salary"]) for i in pp)
    pp_p95=float(player_p95[list(pp)].sum()); pp_p99=float(player_p99[list(pp)].sum()); pp_mean=float(player_mean[list(pp)].sum())
    pp_lev=sum(float(by[i]["strategy_leverage"]) for i in pp)
    pp_chalk=sum(float(by[i]["chalk_failure_edge"]) for i in pp)
    parts=[]
    for token in str(fam["STACK_SIGNATURE"]).split("-"):
        team=token[:-1]; count=int(token[-1])
        parts.append((team,count))
    lists=[team_combos(t,k) for t,k in parts]
    legal={}
    generated_states=0
    for lane,metric in LANES.items():
        slists=[sorted(rows,key=lambda r:(-float(r[metric]),-int(r["salary"]),r["ids"])) for rows in lists]
        states=kbest_product(slists,metric,LANE_DEPTH)
        for lane_rank,state in enumerate(states,1):
            generated_states += 1
            pieces=[slists[d][state[d]] for d in range(len(state))]
            hitters=tuple(sorted(itertools.chain.from_iterable(p["ids"] for p in pieces)))
            assigned=assign_hitters(hitters)
            if assigned is None:
                continue
            salary=pp_salary+sum(int(p["salary"]) for p in pieces)
            if salary < 48000 or salary > 50000:
                continue
            lineup=tuple(pp+assigned)
            rec=legal.get(lineup)
            if rec is None:
                hteams=Counter(by[i]["team"] for i in assigned)
                corr_score=0.0
                for team in hteams:
                    ids=[i for i in assigned if by[i]["team"]==team]
                    for a,b in itertools.combinations(ids,2):
                        corr_score += max(0.0,float(corr[a,b])) + 0.06
                rec={
                    "lineup":lineup,
                    "pitcher_pair":pp,
                    "salary":salary,
                    "pattern":fam["PATTERN"],
                    "stack_signature":fam["STACK_SIGNATURE"],
                    "family_key":fam["FAMILY_KEY"],
                    "family_prior_rank":int(fam["BEST_ALIGNMENT_RANK"]),
                    "family_calibration_count":int(fam["CALIBRATION_COUNT"]),
                    "p95_sum":pp_p95+sum(float(p["p95"]) for p in pieces),
                    "p99_sum":pp_p99+sum(float(p["p99"]) for p in pieces),
                    "mean_sum":pp_mean+sum(float(p["mean"]) for p in pieces),
                    "correlation":corr_score,
                    "leverage":pp_lev+sum(float(p["lev"]) for p in pieces),
                    "chalk_failure_edge":pp_chalk+sum(float(p["chalk"]) for p in pieces),
                    "top5":sum(int(p["top5"]) for p in pieces),
                    "adj":sum(int(p["adj"]) for p in pieces),
                    "best_lane_rank":lane_rank,
                    "birth_lanes":{lane},
                }
                legal[lineup]=rec
            else:
                rec["best_lane_rank"]=min(int(rec["best_lane_rank"]),lane_rank)
                rec["birth_lanes"].add(lane)
    if not legal:
        family_receipts.append({"FAMILY_KEY":fam["FAMILY_KEY"],"STATUS":"NO_LEGAL_DOORS","GENERATED_STATES":generated_states})
        continue
    rows=list(legal.values())
    # Multi-lane pre-MC retention. Preserve every door that reaches top-128 in any lane,
    # then fill to FAMILY_KEEP by prelock multi-objective proxy.
    arr_p95=pct([r["p95_sum"] for r in rows]); arr_p99=pct([r["p99_sum"] for r in rows])
    arr_sal=pct([r["salary"] for r in rows]); arr_top=pct([r["top5"] for r in rows])
    arr_lev=pct([r["leverage"] for r in rows]); arr_corr=pct([r["correlation"] for r in rows])
    for j,r in enumerate(rows):
        r["pre_proxy"]=float(.24*arr_p99[j]+.20*arr_p95[j]+.18*arr_sal[j]+.14*arr_top[j]+.12*arr_lev[j]+.12*arr_corr[j])
    protected=[r for r in rows if int(r["best_lane_rank"])<=128]
    protected.sort(key=lambda r:(int(r["best_lane_rank"]),-r["pre_proxy"],str(r["lineup"])))
    selected=protected[:FAMILY_KEEP]
    if len(selected)<FAMILY_KEEP:
        used={r["lineup"] for r in selected}
        fill=sorted((r for r in rows if r["lineup"] not in used),key=lambda r:(-r["pre_proxy"],str(r["lineup"])))
        selected.extend(fill[:FAMILY_KEEP-len(selected)])
    for r in selected:
        if r["lineup"] in seen_lineups:
            continue
        seen_lineups.add(r["lineup"])
        r["birth_lanes"]="|".join(sorted(r["birth_lanes"]))
        family_candidates.append(r)
    family_receipts.append({
        "FAMILY_KEY":fam["FAMILY_KEY"],"STATUS":"PASS","GENERATED_STATES":generated_states,
        "LEGAL_UNIQUE_DOORS":len(rows),"RETAINED_DOORS":len(selected)
    })

if len(family_candidates)<BOARD_SIZE:
    raise RuntimeError(f"RUN_FAIL:CALIBRATED_CANDIDATE_SHORT:{len(family_candidates)}")

# Blind lineup-level Monte Carlo from the frozen Phase1 score surface.
lines=np.asarray([r["lineup"] for r in family_candidates],dtype=np.int32)
n=len(lines)
mc_mean=np.empty(n); mc_p95=np.empty(n); mc_p99=np.empty(n); mc_cvar=np.empty(n)
chunk=256
for st in range(0,n,chunk):
    ed=min(n,st+chunk)
    block=lines[st:ed]
    mat=np.ascontiguousarray(phase1_scores[:,block[:,0]],dtype=np.float32)
    for s in range(1,block.shape[1]):
        mat += phase1_scores[:,block[:,s]]
    k95=max(0,int(np.ceil(.95*mat.shape[0]))-1)
    k99=max(0,int(np.ceil(.99*mat.shape[0]))-1)
    part=np.partition(mat,(k95,k99),axis=0)
    mc_mean[st:ed]=mat.mean(axis=0)
    mc_p95[st:ed]=part[k95]
    mc_p99[st:ed]=part[k99]
    mc_cvar[st:ed]=part[k99:,:].mean(axis=0,dtype=np.float64)

p99p=pct(mc_p99); cvarp=pct(mc_cvar); p95p=pct(mc_p95)
corrp=pct([r["correlation"] for r in family_candidates])
levp=pct([r["leverage"] for r in family_candidates])
chalkp=pct([r["chalk_failure_edge"] for r in family_candidates])
door=.30*p99p+.24*cvarp+.18*corrp+.12*levp+.10*chalkp+.06*p95p
for i,r in enumerate(family_candidates):
    r["mc_mean"]=float(mc_mean[i]); r["mc_p95"]=float(mc_p95[i]); r["mc_p99"]=float(mc_p99[i]); r["mc_cvar99"]=float(mc_cvar[i]); r["door_score"]=float(door[i])

by_family=defaultdict(list)
for i,r in enumerate(family_candidates):
    by_family[r["family_key"]].append(i)

family_rows=[]
prior_by_key={f["FAMILY_KEY"]:f for f in cal["FAMILIES"]}
for fk,ids in by_family.items():
    ids=sorted(ids,key=lambda i:(-family_candidates[i]["door_score"],str(family_candidates[i]["lineup"])))
    vals=np.asarray([family_candidates[i]["door_score"] for i in ids[:9]],dtype=float)
    family_score=float(vals[0]+.20*np.mean(vals[:min(3,len(vals))])+.08*np.mean(vals))
    prior=prior_by_key[fk]
    family_rows.append((int(prior["BEST_ALIGNMENT_RANK"]),-int(prior["CALIBRATION_COUNT"]),-family_score,fk,ids))
family_rows.sort(key=lambda x:(x[0],x[1],x[2],x[3]))

# RNWD-style board: calibrated neighborhood admission first, blind local door selection second.
core_target=min(8,BOARD_SIZE)
selected=[]; used=set()
depth=0
while len(selected)<core_target:
    progressed=False
    for _,_,_,fk,ids in family_rows:
        if depth<len(ids):
            i=int(ids[depth])
            if i not in used:
                selected.append(i); used.add(i); progressed=True
                if len(selected)>=core_target:
                    break
    if not progressed:
        break
    depth+=1

# Structural reserves from the best not-yet-used calibrated neighborhoods.
used_pairs={tuple(family_candidates[i]["pitcher_pair"]) for i in selected}
used_stacks={family_candidates[i]["stack_signature"] for i in selected}
while len(selected)<BOARD_SIZE:
    options=[]
    for prior_rank,negcnt,negfs,fk,ids in family_rows:
        for i in ids:
            if i in used:
                continue
            r=family_candidates[i]
            novelty=(int(tuple(r["pitcher_pair"]) not in used_pairs)+int(r["stack_signature"] not in used_stacks))
            options.append((-novelty,prior_rank,negcnt,negfs,-r["door_score"],str(r["lineup"]),i))
            break
    if not options:
        break
    options.sort()
    i=int(options[0][-1]); selected.append(i); used.add(i)
    used_pairs.add(tuple(family_candidates[i]["pitcher_pair"])); used_stacks.add(family_candidates[i]["stack_signature"])

if len(selected)!=BOARD_SIZE:
    raise RuntimeError(f"RUN_FAIL:BLIND_BOARD_SHORT:{len(selected)}")

board=[]
for rank,i in enumerate(selected,1):
    r=family_candidates[i]
    rec={
        "BOARD_RANK":rank,
        "LINEUP_ID":f"CAL{i+1:05d}",
        "SALARY":int(r["salary"]),
        "LEFTOVER":50000-int(r["salary"]),
        "PATTERN":r["pattern"],
        "STACK_SIGNATURE":r["stack_signature"],
        "FAMILY_KEY":r["family_key"],
        "FAMILY_PRIOR_RANK":int(r["family_prior_rank"]),
        "DOOR_SCORE":round(float(r["door_score"]),8),
        "MC_MEAN":round(float(r["mc_mean"]),4),
        "P95":round(float(r["mc_p95"]),4),
        "P99":round(float(r["mc_p99"]),4),
        "CVAR99":round(float(r["mc_cvar99"]),4),
        "BEST_LANE_RANK":int(r["best_lane_rank"]),
        "BIRTH_LANES":r["birth_lanes"],
    }
    for s,idx in zip(BOARD_SLOTS,r["lineup"]):
        rec[s]=by[int(idx)]["name"]
        rec[s+"_TEAM"]=by[int(idx)]["team"]
        rec[s+"_SALARY"]=int(by[int(idx)]["salary"])
    board.append(rec)

board_path=OUT/"execution_blind_from_fail_final_board.csv"
pd.DataFrame(board).to_csv(board_path,index=False)
cand_path=OUT/"execution_blind_from_fail_candidates.csv"
pd.DataFrame([{
    "LINEUP_ID":f"CAL{i+1:05d}","SALARY":r["salary"],"PATTERN":r["pattern"],"STACK_SIGNATURE":r["stack_signature"],
    "FAMILY_KEY":r["family_key"],"FAMILY_PRIOR_RANK":r["family_prior_rank"],"DOOR_SCORE":r["door_score"],
    "MC_MEAN":r["mc_mean"],"P95":r["mc_p95"],"P99":r["mc_p99"],"CVAR99":r["mc_cvar99"],
    "BEST_LANE_RANK":r["best_lane_rank"],"BIRTH_LANES":r["birth_lanes"],
    **{s:by[int(idx)]["name"] for s,idx in zip(BOARD_SLOTS,r["lineup"])}
} for i,r in enumerate(family_candidates)]).to_csv(cand_path,index=False)

receipt={
    "PATCH_ID":PATCH_ID,
    "CALIBRATION_ID":cal["CALIBRATION_ID"],
    "CALIBRATION_SLATE_FINGERPRINT":slate_fp,
    "CONTEST_FILE_ACCESSED_DURING_GENERATION":False,
    "PHASE1_SIMS":int(phase1_scores.shape[0]),
    "CALIBRATED_FAMILIES":len(cal["FAMILIES"]),
    "FAMILIES_WITH_CANDIDATES":len(by_family),
    "CALIBRATED_CANDIDATES":len(family_candidates),
    "LANE_DEPTH":LANE_DEPTH,
    "FAMILY_KEEP":FAMILY_KEEP,
    "FINAL_BOARD_SIZE":len(board),
    "EXECUTION_STATE":"TOOL_PROVEN_EXECUTED",
    "FAMILY_RECEIPTS":family_receipts,
}
(OUT/"execution_blind_from_fail_receipt.json").write_text(json.dumps(receipt,indent=2))

print(json.dumps({k:v for k,v in receipt.items() if k!="FAMILY_RECEIPTS"},indent=2))
print("BOARD_PATH="+str(board_path))
for r in board:
    print(f"BOARD_RANK={r['BOARD_RANK']} FAMILY_PRIOR={r['FAMILY_PRIOR_RANK']} SALARY={r['SALARY']} P99={r['P99']} FAMILY={r['FAMILY_KEY']}")
    print(" | ".join(f"{s}:{r[s]}" for s in BOARD_SLOTS))
