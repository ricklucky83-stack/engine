from __future__ import annotations
import numpy as np
import pandas as pd

PATCH_ID='MLB_SD_WINNER_PHENOTYPE_SELECTOR_V1'
ALPHA=0.015
STATUS='ACTIVE_LOCAL_CALIBRATED_THREE_CONTROL'


def _pct(v):
    v=np.asarray(v,float); n=len(v)
    if n<=1: return np.ones(n,float)
    return pd.Series(v).rank(method='average',pct=True).to_numpy(float)


def _lane_pct(score,mask):
    score=np.asarray(score,float); mask=np.asarray(mask,bool); out=np.zeros(len(score),float); ids=np.flatnonzero(mask)
    if len(ids): out[ids]=_pct(score[ids])
    return out


def score_frozen_phase2(pool:pd.DataFrame, phase2:pd.DataFrame, base_det_score:np.ndarray):
    """One read-only winner-phenotype selector over an already-frozen Phase-2 universe.

    No birth/delete/swap. No contest ranks/points. No post-lock inputs.
    Four heads are intentionally plural so RP-closer, hitter-CPT eruption, and
    dual-SP/SP-CPT winners are not erased by one universal archetype.
    """
    ids=phase2[['CPT_ID','U1_ID','U2_ID','U3_ID','U4_ID','U5_ID']].to_numpy(int)
    sp=pool['_IS_STARTER'].astype(bool).to_numpy(); rp=pool['_IS_RP'].astype(bool).to_numpy(); qrp=pool['_RP_QUALIFIED'].astype(bool).to_numpy()
    rolep=pd.to_numeric(pool['_ROLE_PROB'],errors='coerce').fillna(0).to_numpy(float)
    own=pd.to_numeric(pool['RST%'],errors='coerce').fillna(0).to_numpy(float)
    teams=pool['TEAM'].astype(str).to_numpy(); line=pool['LINEUP'].astype(str).to_numpy()
    order=np.array([int(x) if str(x).isdigit() else 10 for x in line],int)

    base_pct=_pct(base_det_score)
    p99_pct=_pct(phase2['PHASE1_P99'].to_numpy(float)); salary_pct=_pct(phase2['SALARY'].to_numpy(float))
    own_sum_pct=_pct(own[ids].sum(1))
    hit=~(sp[ids]|rp[ids]); team0=teams[0]
    h0=((teams[ids]==team0)&hit).sum(1); h1=hit.sum(1)-h0
    max_stack_pct=_pct(np.maximum(h0,h1)); top4_pct=_pct(((order[ids]<=4)&hit).sum(1))
    dual=phase2['DUAL_SP'].astype(bool).to_numpy(); cpt_sp=sp[ids[:,0]]; cpt_rp=rp[ids[:,0]]; cpt_hitter=~(cpt_sp|cpt_rp)
    qual_rp_any=((rp[ids]&qrp[ids]).sum(1)>0); rp_role_pct=_pct(np.where(rp[ids],rolep[ids],0).max(1))

    # Reusable common core: stable projection/tail + salary + concentration + soft structure.
    common_raw=(.30*base_pct + .22*p99_pct + .15*salary_pct + .14*max_stack_pct +
                .08*dual.astype(float) + .07*cpt_sp.astype(float) + .04*top4_pct - .05*own_sum_pct)
    common=_pct(common_raw)

    # Exception heads preserve winner species that the common core can suppress.
    sp_dual_raw=.30*base_pct+.25*p99_pct+.20*salary_pct+.15*max_stack_pct+.10*top4_pct
    hitter_cpt_raw=.30*base_pct+.25*p99_pct+.20*max_stack_pct+.15*top4_pct+.10*salary_pct
    closer_raw=.30*base_pct+.25*p99_pct+.20*salary_pct+.15*rp_role_pct+.10*max_stack_pct

    sp_dual=_lane_pct(sp_dual_raw,dual&cpt_sp)
    hitter_cpt=_lane_pct(hitter_cpt_raw,cpt_hitter)
    closer=_lane_pct(closer_raw,dual&qual_rp_any)

    heads=np.column_stack([common,sp_dual,hitter_cpt,closer])
    labels=np.array(['COMMON_CORE','DUAL_SP_SP_CPT','HITTER_CPT_ERUPTION','DUAL_SP_QUALIFIED_RP'],object)
    winner_like=heads.max(1); phenotype=labels[heads.argmax(1)]
    selector_score=base_pct + ALPHA*winner_like

    return pd.DataFrame({
        'BASE_DET_PCT':base_pct,
        'COMMON_CORE_SCORE':common,
        'DUAL_SP_SP_CPT_SCORE':sp_dual,
        'HITTER_CPT_ERUPTION_SCORE':hitter_cpt,
        'DUAL_SP_QUALIFIED_RP_SCORE':closer,
        'WINNER_PHENOTYPE':phenotype,
        'WINNER_PHENOTYPE_SCORE':winner_like,
        'WINNER_SELECTOR_SCORE':selector_score,
    })
