from __future__ import annotations

import heapq
import itertools
import math
import os
import time
from collections import Counter, defaultdict
from typing import Any, Callable, Mapping, Sequence

import numpy as np

PATCH_ID = "MLB_CLASSIC_ADAPTIVE_PRELOCK_FAMILY_DOOR_RECALL_v1"
DOCTRINE_ID = "MLB_CLASSIC_ADAPTIVE_PRELOCK_FAMILY_DOOR_RECALL_v1"

BASE_DEPTH = int(os.environ.get("APEX_ADAPTIVE_FAMILY_BASE_DEPTH", "512"))
ESCALATION_DEPTH = int(os.environ.get("APEX_ADAPTIVE_FAMILY_ESCALATION_DEPTH", "8192"))
STARVED_PAIR_CAP = int(os.environ.get("APEX_ADAPTIVE_FAMILY_STARVED_PAIR_CAP", "2"))
SHELLS_PER_PAIR = int(os.environ.get("APEX_ADAPTIVE_FAMILY_SHELLS_PER_PAIR", "96"))
RETAIN_PER_ESCALATED_SHELL = int(os.environ.get("APEX_ADAPTIVE_FAMILY_RETAIN_PER_SHELL", "64"))
ENABLED = os.environ.get("APEX_ADAPTIVE_FAMILY_DOOR_RECALL", "1") != "0"

# Existing production-supported championship structures. Selection inside this set is
# purely pre-lock: choose the structure with the lowest native-birth/Phase2-target ratio.
CHAMPIONSHIP_PATTERNS = (
    "5-3", "5-2-1", "5-1-1-1", "4-4", "4-3-1", "4-2-2", "4-2-1-1", "3-3-2",
)


def _lev_metric(
    row: tuple[tuple[int, ...], int, float],
    *,
    by_idx: Mapping[int, Mapping[str, Any]],
    player_p99: np.ndarray,
) -> float:
    ids, _salary, _pre = row
    # Exact production strategic-leverage lane used by the saved-family blind replay.
    return float(sum(float(by_idx[int(i)].get("strategy_leverage", 0.0)) for i in ids))


def _kbest_states(metric_lists: Sequence[np.ndarray], limit: int):
    if limit <= 0 or not metric_lists or any(len(x) == 0 for x in metric_lists):
        return
    start = tuple(0 for _ in metric_lists)

    def score(state: tuple[int, ...]) -> float:
        return float(sum(metric_lists[d][state[d]] for d in range(len(state))))

    heap: list[tuple[float, tuple[int, ...]]] = [(-score(start), start)]
    seen = {start}
    emitted = 0
    while heap and emitted < limit:
        _, state = heapq.heappop(heap)
        emitted += 1
        yield emitted, state
        for d in range(len(state)):
            if state[d] + 1 >= len(metric_lists[d]):
                continue
            ns = list(state)
            ns[d] += 1
            nt = tuple(ns)
            if nt in seen:
                continue
            seen.add(nt)
            heapq.heappush(heap, (-score(nt), nt))



def _topk_product_paths(metric_lists: Sequence[np.ndarray], limit: int) -> np.ndarray:
    """Exact top-K additive product states using iterative NumPy top-K contraction."""
    if limit <= 0 or not metric_lists or any(len(x) == 0 for x in metric_lists):
        return np.empty((0, len(metric_lists)), dtype=np.int32)
    first = np.asarray(metric_lists[0], dtype=np.float64)[: min(limit, len(metric_lists[0]))]
    scores = first.copy()
    paths = np.arange(len(scores), dtype=np.int32).reshape(-1, 1)
    for raw in metric_lists[1:]:
        arr = np.asarray(raw, dtype=np.float64)[: min(limit, len(raw))]
        total = scores[:, None] + arr[None, :]
        flat = total.ravel()
        take = min(int(limit), int(flat.size))
        if take < flat.size:
            sel = np.argpartition(-flat, take - 1)[:take]
        else:
            sel = np.arange(flat.size, dtype=np.int64)
        # Deterministic score-descending order; flat index breaks ties.
        order = np.lexsort((sel, -flat[sel]))
        sel = sel[order]
        width = len(arr)
        prev = (sel // width).astype(np.int32, copy=False)
        cur = (sel % width).astype(np.int32, copy=False)
        paths = np.column_stack((paths[prev], cur))
        scores = flat[sel]
    return paths

def _canonical_parts(sizes: Sequence[int], chosen: Sequence[str]) -> tuple[tuple[str, int], ...]:
    return tuple(sorted(((str(t), int(k)) for t, k in zip(chosen, sizes)), key=lambda x: (-x[1], x[0])))


def _sorted_combo_cache(
    combo_pool: Mapping[tuple[str, int], Sequence[tuple[tuple[int, ...], int, float]]],
    *,
    by_idx: Mapping[int, Mapping[str, Any]],
    player_p99: np.ndarray,
) -> dict[tuple[str, int], tuple[list[tuple[tuple[int, ...], int, float]], np.ndarray]]:
    cache = {}
    for key, source in combo_pool.items():
        rows = list(source)
        rows.sort(key=lambda r: (-_lev_metric(r, by_idx=by_idx, player_p99=player_p99), -int(r[1]), r[0]))
        metrics = np.asarray([_lev_metric(r, by_idx=by_idx, player_p99=player_p99) for r in rows], dtype=np.float64)
        cache[(str(key[0]), int(key[1]))] = (rows, metrics)
    return cache


def _starved_pair_shells(
    *,
    sizes: tuple[int, ...],
    pair_pos: int,
    pair_rank: int,
    teams: Sequence[str],
    combo_pool: Mapping[tuple[str, int], Sequence[tuple[tuple[int, ...], int, float]]],
    combo_cache: Mapping[tuple[str, int], tuple[list[tuple[tuple[int, ...], int, float]], np.ndarray]],
    pitcher_pairs: Sequence[tuple[tuple[int, int], float]],
    by_idx: Mapping[int, Mapping[str, Any]],
    player_p99: np.ndarray,
    team_weight_map: Mapping[str, float],
) -> list[dict[str, Any]]:
    raw_pp = tuple(int(x) for x in pitcher_pairs[int(pair_pos)][0])
    pp = tuple(sorted(raw_pp, key=lambda i: (-float(player_p99[i]), str(by_idx[i].get("pid", i)))))
    blocked = {str(by_idx[pp[0]].get("opp", "")), str(by_idx[pp[1]].get("opp", ""))}
    allowed = [str(t) for t in teams if str(t) not in blocked]
    if len(allowed) < len(sizes):
        return []

    shells: dict[tuple[tuple[str, int], ...], dict[str, Any]] = {}
    for chosen in itertools.permutations(allowed, len(sizes)):
        parts = _canonical_parts(sizes, chosen)
        if parts in shells:
            continue
        if any(not combo_pool.get((team, size), ()) for team, size in parts):
            continue
        primary_size = max(sizes)
        primary_team = next(team for team, size in parts if size == primary_size)
        lev = float(sum(float(combo_cache[(team, size)][1][0]) for team, size in parts))
        shells[parts] = {
            "PAIR": pp,
            "PAIR_RANK": int(pair_rank),
            "PARTS": parts,
            "PRIMARY_TEAM": primary_team,
            "LEVERAGE": float(lev),
        }

    # One primary-team cell per starved pitcher pair. Choose the weakest native
    # calibration-weight primary team, because this repair exists specifically to
    # recover championship-capable families suppressed by the global birth prior.
    # This is pre-lock and generic; no player/team identity is hardcoded.
    by_primary: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in shells.values():
        by_primary[str(r["PRIMARY_TEAM"])].append(r)
    if not by_primary:
        return []
    primary_team = min(
        by_primary,
        key=lambda team: (float(team_weight_map.get(team, math.inf)), team),
    )
    ranked = sorted(
        by_primary[primary_team],
        key=lambda r: (-r["LEVERAGE"], r["PARTS"]),
    )
    return ranked[:SHELLS_PER_PAIR]


def _scan_shell_leverage_only(
    shell: Mapping[str, Any],
    *,
    combo_cache: Mapping[tuple[str, int], tuple[list[tuple[tuple[int, ...], int, float]], np.ndarray]],
    by_idx: Mapping[int, Mapping[str, Any]],
    assign_hitters: Callable[[tuple[int, ...]], tuple[int, ...] | None],
    salary_min: int,
    salary_max: int,
    max_hitters_team: int,
) -> tuple[bool, list[dict[str, Any]], dict[str, Any]]:
    pp = tuple(int(x) for x in shell["PAIR"])
    parts = tuple((str(t), int(k)) for t, k in shell["PARTS"])
    pitcher_salary = sum(int(by_idx[i]["salary"]) for i in pp)
    sorted_lists = [combo_cache[(team, size)][0] for team, size in parts]
    metric_lists = [combo_cache[(team, size)][1] for team, size in parts]

    paths = _topk_product_paths(metric_lists, ESCALATION_DEPTH)
    if paths.size == 0:
        return True, [], {"BASE_EXAMINED": 0, "ZERO_DOOR": True, "ESCALATED": True, "DEEP_EXAMINED": 0, "LEGAL_UNIQUE_DOORS": 0, "RETAINED_DOORS": 0}

    # Salary can be rejected vectorially before any roster-position work.
    salaries = np.full(len(paths), pitcher_salary, dtype=np.int32)
    for d in range(paths.shape[1]):
        piece_salaries = np.asarray([int(r[1]) for r in sorted_lists[d]], dtype=np.int32)
        salaries += piece_salaries[paths[:, d]]
    salary_ok = (salaries >= int(salary_min)) & (salaries <= int(salary_max))

    legal: dict[tuple[int, ...], dict[str, Any]] = {}
    first_base_legal = None
    for zero_idx in np.flatnonzero(salary_ok).tolist():
        lane_rank = int(zero_idx) + 1
        state = paths[zero_idx]
        hitters = tuple(sorted(itertools.chain.from_iterable(sorted_lists[d][int(state[d])][0] for d in range(len(state)))))
        assigned = assign_hitters(hitters)
        if assigned is None:
            continue
        if lane_rank <= BASE_DEPTH:
            first_base_legal = lane_rank
            break
        if hitters not in legal:
            legal[hitters] = {"HITTERS": hitters, "BEST_LANE_RANK": lane_rank, "BIRTH_LANES": {"LEV"}}

    if first_base_legal is not None:
        return False, [], {"BASE_EXAMINED": int(first_base_legal), "ZERO_DOOR": False, "ESCALATED": False}

    # If there was no base-depth legal door, continue across all salary-valid deep states.
    # The first pass may already have populated some deep legal rows before encountering a
    # hypothetical base row only if ordering were violated; lane_rank order prevents that.
    legal.clear()
    for zero_idx in np.flatnonzero(salary_ok & (np.arange(len(paths)) >= BASE_DEPTH)).tolist():
        lane_rank = int(zero_idx) + 1
        state = paths[zero_idx]
        hitters = tuple(sorted(itertools.chain.from_iterable(sorted_lists[d][int(state[d])][0] for d in range(len(state)))))
        if assign_hitters(hitters) is None:
            continue
        if hitters not in legal:
            legal[hitters] = {"HITTERS": hitters, "BEST_LANE_RANK": lane_rank, "BIRTH_LANES": {"LEV"}}

    rows = sorted(legal.values(), key=lambda r: (int(r["BEST_LANE_RANK"]), r["HITTERS"]))[:RETAIN_PER_ESCALATED_SHELL]
    return True, rows, {
        "BASE_EXAMINED": int(min(BASE_DEPTH, len(paths))),
        "ZERO_DOOR": True,
        "ESCALATED": True,
        "DEEP_EXAMINED": int(len(paths)),
        "LEGAL_UNIQUE_DOORS": len(legal),
        "RETAINED_DOORS": len(rows),
    }


def apply(
    *,
    phase2: Sequence[Mapping[str, Any]],
    pattern_counts: Mapping[str, int],
    pattern_targets: Mapping[str, int],
    patterns: Sequence[tuple[str, tuple[int, ...], str, int]],
    teams: Sequence[str],
    team_weight_map: Mapping[str, float],
    combo_pool: Mapping[tuple[str, int], Sequence[tuple[tuple[int, ...], int, float]]],
    pitcher_pairs: Sequence[tuple[tuple[int, int], float]],
    pair_scores: np.ndarray,
    by_idx: Mapping[int, Mapping[str, Any]],
    player_p99: np.ndarray,
    assign_hitters: Callable[[tuple[int, ...]], tuple[int, ...] | None],
    materialize_candidate: Callable[..., Mapping[str, Any] | None],
    salary_min: int,
    salary_max: int,
    max_hitters_team: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    started = time.time()
    if not ENABLED:
        return [], {"PATCH_ID": PATCH_ID, "DOCTRINE_ID": DOCTRINE_ID, "STATUS": "DISABLED", "POSTLOCK_INPUTS_USED": False, "SELECTOR_CHANGED": False}

    pattern_map = {str(name): (tuple(int(x) for x in sizes), str(lane)) for name, sizes, lane, _ in patterns}
    eligible = [
        name for name in CHAMPIONSHIP_PATTERNS
        if name in pattern_map and int(pattern_targets.get(name, 0)) > 0 and int(pattern_counts.get(name, 0)) < int(pattern_targets.get(name, 0))
    ]
    if not eligible:
        return [], {
            "PATCH_ID": PATCH_ID, "DOCTRINE_ID": DOCTRINE_ID, "STATUS": "PASS_NO_TRIGGER",
            "POSTLOCK_INPUTS_USED": False, "CONTEST_FILE_ACCESSED": False, "SELECTOR_CHANGED": False,
            "GENERATION_SECONDS": round(time.time() - started, 6),
        }

    selected_pattern = min(
        eligible,
        key=lambda name: (float(pattern_counts.get(name, 0)) / max(1, int(pattern_targets.get(name, 0))), CHAMPIONSHIP_PATTERNS.index(name)),
    )
    sizes, lane = pattern_map[selected_pattern]

    native_pair_counts = Counter()
    for row in phase2:
        if str(row.get("pattern")) != selected_pattern:
            continue
        native_pair_counts[tuple(sorted(int(i) for i in row["pitcher_pair"]))] += 1

    pair_order = np.argsort(-np.asarray(pair_scores, dtype=np.float64), kind="stable")
    starved = []
    for pair_rank, pair_pos in enumerate(pair_order.tolist(), 1):
        pp_key = tuple(sorted(int(i) for i in pitcher_pairs[int(pair_pos)][0]))
        if native_pair_counts.get(pp_key, 0) != 0:
            continue
        starved.append((int(pair_pos), int(pair_rank)))
        if len(starved) >= STARVED_PAIR_CAP:
            break

    combo_cache = _sorted_combo_cache(combo_pool, by_idx=by_idx, player_p99=player_p99)
    added_rows: list[dict[str, Any]] = []
    shell_receipts: list[dict[str, Any]] = []
    zero_door_shells = 0

    for pair_pos, pair_rank in starved:
        shells = _starved_pair_shells(
            sizes=sizes,
            pair_pos=pair_pos,
            pair_rank=pair_rank,
            teams=teams,
            combo_pool=combo_pool,
            combo_cache=combo_cache,
            pitcher_pairs=pitcher_pairs,
            by_idx=by_idx,
            player_p99=player_p99,
            team_weight_map=team_weight_map,
        )
        for shell in shells:
            escalated, doors, scan = _scan_shell_leverage_only(
                shell,
                combo_cache=combo_cache,
                by_idx=by_idx,
                assign_hitters=assign_hitters,
                salary_min=salary_min,
                salary_max=salary_max,
                max_hitters_team=max_hitters_team,
            )
            if scan.get("ZERO_DOOR"):
                zero_door_shells += 1
            shell_added = 0
            if escalated:
                for door in doors:
                    row = materialize_candidate(
                        tuple(int(i) for i in door["HITTERS"]),
                        tuple(int(i) for i in shell["PAIR"]),
                        selected_pattern,
                        lane,
                        birth_source=PATCH_ID,
                    )
                    if row is None:
                        continue
                    row = dict(row)
                    row["adaptive_family_best_lane_rank"] = int(door["BEST_LANE_RANK"])
                    row["adaptive_family_birth_lanes"] = "LEV"
                    added_rows.append(row)
                    shell_added += 1
            shell_receipts.append({
                "PATTERN": selected_pattern,
                "PAIR_RANK": int(shell["PAIR_RANK"]),
                "PRIMARY_TEAM": str(shell["PRIMARY_TEAM"]),
                "PARTS": [list(x) for x in shell["PARTS"]],
                **scan,
                "ROWS_ADDED": int(shell_added),
            })

    return added_rows, {
        "PATCH_ID": PATCH_ID,
        "DOCTRINE_ID": DOCTRINE_ID,
        "STATUS": "PASS",
        "TRIGGER": "MOST_UNDERFILLED_PRELOCK_CHAMPIONSHIP_PATTERN_PLUS_TOP_STARVED_PITCHER_PAIRS",
        "SELECTED_PATTERN": selected_pattern,
        "PATTERN_TARGET": int(pattern_targets[selected_pattern]),
        "PATTERN_NATIVE_BIRTHS": int(pattern_counts.get(selected_pattern, 0)),
        "STARVED_PAIR_CAP": STARVED_PAIR_CAP,
        "STARVED_PAIR_RANKS": [rank for _pos, rank in starved],
        "SHELLS_PER_PAIR": SHELLS_PER_PAIR,
        "FAMILY_ESCALATION_TRIGGER": "ZERO_LEGAL_DOORS_IN_LEVERAGE_LANE_AT_DEPTH_512",
        "BASE_DEPTH": BASE_DEPTH,
        "ESCALATION_DEPTH": ESCALATION_DEPTH,
        "LANES": ["LEV"],
        "SHELLS_SCANNED": len(shell_receipts),
        "ZERO_DOOR_SHELLS": int(zero_door_shells),
        "ROWS_ADDED": len(added_rows),
        "POSTLOCK_INPUTS_USED": False,
        "CONTEST_FILE_ACCESSED": False,
        "PLAYER_NAME_HARDCODES": False,
        "TEAM_NAME_HARDCODES": False,
        "SELECTOR_CHANGED": False,
        "PHASE1_SCORE_SURFACE_CHANGED": False,
        "PITCHER_PAIR_CALIBRATION_CHANGED": False,
        "GENERATION_SECONDS": round(time.time() - started, 6),
        "SHELL_RECEIPTS": shell_receipts,
    }
