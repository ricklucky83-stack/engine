from __future__ import annotations
import argparse, hashlib, json, os, subprocess, sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
CLASSIC_RUNTIME=BASE/'mlb_classic_raw_pool_runtime_v1_4.py'
SHOWDOWN_RUNTIME=BASE/'mlb_showdown_raw_pool_runtime_v1_5.py'
MANIFEST=BASE/'APEX_MLB_RAW_POOL_RUNTIME_v1_5.manifest.json'

def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def validate()->dict:
    m=json.loads(MANIFEST.read_text()); failures=[]; files={}
    for rel,expected in m['FILES'].items():
        p=BASE/rel; actual=sha256(p) if p.exists() else None
        status='PASS' if actual==expected else ('MISSING' if actual is None else 'HASH_MISMATCH')
        files[rel]={'status':status,'expected_sha256':expected,'actual_sha256':actual}
        if status!='PASS': failures.append(f'{status}:{rel}')
    out={'PATCH':m['PATCH'],'STATUS':'PASS' if not failures else 'FAIL','FAILURES':failures,'FILES':files}
    if failures: raise RuntimeError('ENGINE_INTEGRITY_HALT:'+'|'.join(failures))
    return out

def add_run_args(p):
    p.add_argument('--player-pool',required=True); p.add_argument('--field-size',required=True,type=int); p.add_argument('--execution-id',required=True)
    p.add_argument('--contest-file'); p.add_argument('--output-dir',default='/mnt/data'); p.add_argument('--board-size',type=int,default=10); p.add_argument('--seed',type=int)
    p.add_argument('--postseal-winner-json',help='Validation only; prohibited in forward-blind production runs.')

def main()->int:
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='command',required=True); sub.add_parser('validate')
    c=sub.add_parser('run-classic'); add_run_args(c)
    s=sub.add_parser('run-showdown'); add_run_args(s)
    args=ap.parse_args(); receipt=validate()
    if args.command=='validate': print(json.dumps(receipt,indent=2)); return 0
    runtime=CLASSIC_RUNTIME if args.command=='run-classic' else SHOWDOWN_RUNTIME
    env=dict(os.environ); env.update({'APEX_EXECUTION_ID':str(args.execution_id),'APEX_FIELD_SIZE':str(args.field_size),'APEX_PLAYER_POOL':str(Path(args.player_pool).resolve()),'APEX_OUTPUT_DIR':str(Path(args.output_dir).resolve()),'APEX_BOARD_SIZE':str(args.board_size),'APEX_ENGINE_DIR':str(BASE),'APEX_HANDOFF_DIR':str(BASE),'APEX_GLOBAL_STATE_VERSION':'1.5.0'})
    if args.contest_file: env['APEX_CONTEST_FILE']=str(Path(args.contest_file).resolve())
    if args.seed is not None: env['APEX_SEED']=str(args.seed)
    if args.postseal_winner_json:
        if args.command!='run-showdown': raise RuntimeError('POSTSEAL_WINNER_ONLY_SUPPORTED_FOR_SHOWDOWN_VALIDATION')
        env['APEX_POSTSEAL_WINNER_JSON']=args.postseal_winner_json
    cp=subprocess.run([sys.executable,str(runtime)],env=env,cwd=str(BASE),check=False)
    return cp.returncode
if __name__=='__main__': raise SystemExit(main())
