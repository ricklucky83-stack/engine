from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from typing import Mapping, Sequence

PATCH_ID = "MLB_CLASSIC_5_2_1_TO_4_3_1_ADJACENT_FAMILY_CLOSURE_v1"
PARENT_PATTERN = "5-2-1"
CHILD_PATTERN = "4-3-1"
TRANSITION = f"{PARENT_PATTERN}->{CHILD_PATTERN}"


@dataclass(frozen=True)
class AdjacentFamilySwap:
    removed_player_id: int
    added_player_id: int
    parent_pattern: str
    child_pattern: str
    primary_team: str
    secondary_team: str
    singleton_team: str


@dataclass(frozen=True)
class AdjacentFamilyAttemptAudit:
    patch_id: str
    transition: str
    expected_attempts: int
    attempted_attempts: int
    unique_expected_attempts: int
    unique_attempted_attempts: int
    missing_attempts: int
    unexpected_attempts: int
    duplicate_attempts: int
    status: str

    def to_receipt(self) -> dict[str, object]:
        return asdict(self)


def pattern_from_hitters(hitter_ids: Sequence[int], player_team: Mapping[int, str]) -> str:
    counts = sorted(Counter(str(player_team[int(idx)]) for idx in hitter_ids).values(), reverse=True)
    return "-".join(str(int(x)) for x in counts)


def _groups(hitter_ids: Sequence[int], player_team: Mapping[int, str]) -> dict[str, tuple[int, ...]]:
    grouped: dict[str, list[int]] = {}
    for idx in hitter_ids:
        grouped.setdefault(str(player_team[int(idx)]), []).append(int(idx))
    return {team: tuple(sorted(ids)) for team, ids in grouped.items()}


def swaps_5_2_1_to_4_3_1(
    hitter_ids: Sequence[int],
    player_team: Mapping[int, str],
    team_to_hitters: Mapping[str, Sequence[int]],
    blocked_teams: Sequence[str] = (),
) -> tuple[AdjacentFamilySwap, ...]:
    """Enumerate every deterministic 7-of-8 adjacent 5-2-1 -> 4-3-1 sibling.

    One hitter leaves the primary five-stack and one unrostered hitter from the
    already-present secondary two-stack enters. The singleton team, hitter-team
    set, and pitcher pair (owned by the caller) are preserved.
    """
    current = tuple(int(x) for x in hitter_ids)
    if len(current) != 8 or len(set(current)) != 8:
        return ()
    if pattern_from_hitters(current, player_team) != PARENT_PATTERN:
        return ()
    groups = _groups(current, player_team)
    primary = [team for team, ids in groups.items() if len(ids) == 5]
    secondary = [team for team, ids in groups.items() if len(ids) == 2]
    singleton = [team for team, ids in groups.items() if len(ids) == 1]
    if len(primary) != 1 or len(secondary) != 1 or len(singleton) != 1:
        return ()
    primary_team, secondary_team, singleton_team = primary[0], secondary[0], singleton[0]
    if secondary_team in set(map(str, blocked_teams)):
        return ()
    current_set = set(current)
    out: list[AdjacentFamilySwap] = []
    for removed in groups[primary_team]:
        for added in sorted(map(int, team_to_hitters.get(secondary_team, ()))):
            if added in current_set:
                continue
            out.append(AdjacentFamilySwap(
                removed_player_id=int(removed),
                added_player_id=int(added),
                parent_pattern=PARENT_PATTERN,
                child_pattern=CHILD_PATTERN,
                primary_team=primary_team,
                secondary_team=secondary_team,
                singleton_team=singleton_team,
            ))
    out.sort(key=lambda x: (
        x.primary_team,
        x.secondary_team,
        x.singleton_team,
        x.removed_player_id,
        x.added_player_id,
    ))
    return tuple(out)


def apply_swap(hitter_ids: Sequence[int], swap: AdjacentFamilySwap) -> tuple[int, ...]:
    current = tuple(int(x) for x in hitter_ids)
    if swap.removed_player_id not in current or swap.added_player_id in current:
        raise ValueError("INVALID_ADJACENT_FAMILY_SWAP")
    child = tuple(sorted(
        swap.added_player_id if idx == swap.removed_player_id else idx
        for idx in current
    ))
    if len(child) != 8 or len(set(child)) != 8:
        raise ValueError("INVALID_ADJACENT_FAMILY_RESULT")
    return child


def validate_adjacent_family_sibling(
    parent_hitters: Sequence[int],
    child_hitters: Sequence[int],
    player_team: Mapping[int, str],
) -> bool:
    parent = tuple(map(int, parent_hitters))
    child = tuple(map(int, child_hitters))
    if len(parent) != 8 or len(set(parent)) != 8 or len(child) != 8 or len(set(child)) != 8:
        return False
    if len(set(parent) & set(child)) != 7:
        return False
    if pattern_from_hitters(parent, player_team) != PARENT_PATTERN:
        return False
    if pattern_from_hitters(child, player_team) != CHILD_PATTERN:
        return False
    p = _groups(parent, player_team)
    c = _groups(child, player_team)
    if set(p) != set(c) or len(p) != 3:
        return False
    primary = [team for team, ids in p.items() if len(ids) == 5]
    secondary = [team for team, ids in p.items() if len(ids) == 2]
    singleton = [team for team, ids in p.items() if len(ids) == 1]
    if len(primary) != 1 or len(secondary) != 1 or len(singleton) != 1:
        return False
    primary_team, secondary_team, singleton_team = primary[0], secondary[0], singleton[0]
    return (
        len(c.get(primary_team, ())) == 4
        and len(c.get(secondary_team, ())) == 3
        and len(c.get(singleton_team, ())) == 1
    )


def swap_identity(swap: AdjacentFamilySwap) -> tuple[object, ...]:
    return (
        int(swap.removed_player_id),
        int(swap.added_player_id),
        str(swap.parent_pattern),
        str(swap.child_pattern),
        str(swap.primary_team),
        str(swap.secondary_team),
        str(swap.singleton_team),
    )


def audit_swap_attempt_completeness(
    expected_attempt_keys: Sequence[tuple[object, ...]],
    attempted_attempt_keys: Sequence[tuple[object, ...]],
) -> AdjacentFamilyAttemptAudit:
    expected = Counter(tuple(x) for x in expected_attempt_keys)
    attempted = Counter(tuple(x) for x in attempted_attempt_keys)
    missing = expected - attempted
    unexpected = attempted - expected
    duplicates = sum(max(0, count - expected.get(key, 0)) for key, count in attempted.items())
    status = "PASS" if not missing and not unexpected and duplicates == 0 else "FAIL"
    return AdjacentFamilyAttemptAudit(
        patch_id=PATCH_ID,
        transition=TRANSITION,
        expected_attempts=sum(expected.values()),
        attempted_attempts=sum(attempted.values()),
        unique_expected_attempts=len(expected),
        unique_attempted_attempts=len(attempted),
        missing_attempts=sum(missing.values()),
        unexpected_attempts=sum(unexpected.values()),
        duplicate_attempts=int(duplicates),
        status=status,
    )
