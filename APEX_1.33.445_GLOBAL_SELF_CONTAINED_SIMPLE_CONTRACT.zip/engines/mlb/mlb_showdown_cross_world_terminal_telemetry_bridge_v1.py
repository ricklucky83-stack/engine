from __future__ import annotations
from pathlib import Path
from typing import Any
import hashlib, json
import numpy as np

PATCH_ID='MLB_SD_CROSS_WORLD_TERMINAL_TELEMETRY_BRIDGE_v1'
WINDOWS=5
LOCAL_TOPK=1

def reconstruct_from_candidate_core(candidate_ids, primary_core, parent_born, expanded_born, checkpoint_dir, *, windows=WINDOWS, local_topk=LOCAL_TOPK):
    cand=np.asarray(candidate_ids,dtype=np.int32)
    core=np.asarray(primary_core,dtype=np.int32)
    parent=np.asarray(parent_born,dtype=np.int32)
    expanded=np.asarray(expanded_born,dtype=np.int32)
    if cand.ndim!=1 or core.shape!=cand.shape:
        raise RuntimeError('TERMINAL_TELEMETRY_CANDIDATE_CORE_SHAPE_MISMATCH')
    if int(windows)!=5:
        raise RuntimeError('TERMINAL_TELEMETRY_WINDOW_COUNT_MUST_BE_5')
    cdir=Path(checkpoint_dir)
    minrank=np.full((int(windows),len(cand)),32767,np.int16)
    checkpoint_sha=[]
    for w in range(int(windows)):
        fp=cdir/f'window_{w+1:02d}.npz'
        jp=cdir/f'window_{w+1:02d}.json'
        if not fp.exists() or not jp.exists():
            raise RuntimeError(f'TERMINAL_TELEMETRY_CHECKPOINT_MISSING:{w+1}')
        cp=json.loads(jp.read_text())
        if cp.get('COMMIT_STATUS')!='COMMITTED':
            raise RuntimeError(f'TERMINAL_TELEMETRY_CHECKPOINT_NOT_COMMITTED:{w+1}')
        z=np.load(fp)
        ids=np.asarray(z['candidate_ids'],np.int32)
        if not np.array_equal(ids,cand):
            raise RuntimeError(f'TERMINAL_TELEMETRY_CANDIDATE_ID_MISMATCH:{w+1}')
        top01=np.asarray(z['top01']); win=np.asarray(z['win']); p99=np.asarray(z['p99']); p95=np.asarray(z['p95']); mean=np.asarray(z['mean'])
        valid=np.flatnonzero(core>=0)
        inc_order=np.lexsort((cand[valid],-mean[valid],-p95[valid],-p99[valid],-win[valid],-top01[valid],core[valid]))
        vv=valid[inc_order]; pc_sorted=core[vv]
        group_start=np.r_[0,1+np.flatnonzero(pc_sorted[1:]!=pc_sorted[:-1])]
        group_len=np.diff(np.r_[group_start,len(pc_sorted)])
        ranks=(np.arange(len(pc_sorted),dtype=np.int32)-np.repeat(group_start,group_len)+1).astype(np.int16)
        minrank[w,vv]=ranks
        h=hashlib.sha256(); h.update(fp.read_bytes()); checkpoint_sha.append(h.hexdigest())
    recurrence=(minrank<=int(local_topk)).sum(axis=0).astype(np.int16)
    parent_mask=np.isin(cand,parent)
    expanded_mask=np.isin(cand,expanded)
    added_mask=expanded_mask & (~parent_mask)
    telemetry=dict(candidate_ids=cand,primary_core=core,minrank=minrank,recurrence=recurrence,parent_mask=parent_mask,expanded_mask=expanded_mask,added_mask=added_mask)
    receipt=dict(PATCH_ID=PATCH_ID,STATUS='PASS',WINDOWS=int(windows),LOCAL_TOPK=int(local_topk),CANDIDATE_COUNT=int(len(cand)),PARENT_COUNT=int(parent_mask.sum()),EXPANDED_COUNT=int(expanded_mask.sum()),ADDED_COUNT=int(added_mask.sum()),CHECKPOINT_SHA256=checkpoint_sha,POSTLOCK_RESULTS_USED=False,PLAYER_NAME_CONSTANTS_USED=False,REALIZED_POINTS_USED=False,GLOBAL_MC_PRIMARY_CHANGED=False)
    return telemetry,receipt
