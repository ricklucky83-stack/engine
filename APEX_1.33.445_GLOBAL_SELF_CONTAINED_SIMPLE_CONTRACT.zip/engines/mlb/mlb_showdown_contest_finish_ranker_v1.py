from __future__ import annotations
import numpy as np
from mlb_advisor_tail_selector_v1 import context_profile, ranking_order, ordinal_score, PATCH_ID as ADVISOR_SELECTOR_PATCH_ID
import mlb_right_neighborhood_wrong_door_authority_v1 as rnwd

PATCH_ID = 'MLB_SD_MC_PRIMARY_TERMINAL_ORDER_REPAIR_v1'
RANKER_ID = 'MC_TOP01_PRIMARY_TERMINAL_ORDER_v1'


def pct_rank(x):
    x = np.asarray(x, dtype=float)
    if len(x) <= 1: return np.ones(len(x), dtype=float)
    order = np.argsort(x, kind='mergesort'); out = np.empty(len(x), dtype=float); out[order] = np.linspace(0.0, 1.0, len(x)); return out


def wilson_lcb(p, n, z=1.0):
    p=np.clip(np.asarray(p,float),0,1); n=np.maximum(np.asarray(n,float),1); den=1+(z*z)/n; center=p+(z*z)/(2*n); adj=z*np.sqrt((p*(1-p)/n)+(z*z)/(4*n*n)); return np.clip((center-adj)/den,0,1)


def wilson_ucb(p, n, z=1.0):
    p=np.clip(np.asarray(p,float),0,1); n=np.maximum(np.asarray(n,float),1); den=1+(z*z)/n; center=p+(z*z)/(2*n); adj=z*np.sqrt((p*(1-p)/n)+(z*z)/(4*n*n)); return np.clip((center+adj)/den,0,1)


def contest_finish_components(cands, metrics, meta, trials=50000, field_size=10000, slate_games=1):
    cands=np.asarray(cands,np.int32); n=len(cands)
    top01=np.asarray(metrics['top01'],float); win=np.asarray(metrics['win'],float); p99=np.asarray(metrics['p99'],float); p95=np.asarray(metrics['p95'],float)
    cvar99=np.asarray(metrics.get('cvar99',p99),float); trial_n=np.asarray(metrics.get('trials',np.full(n,trials)),float)
    top10_lcb=wilson_lcb(np.asarray(metrics['top10'],float),trial_n,z=1.0); top01_lcb=wilson_lcb(top01,trial_n,z=1.0); win_lcb=wilson_lcb(win,trial_n,z=1.0)
    own=np.asarray(meta['own_log'][cands],float); leverage=pct_rank(-own)
    ctx=context_profile(field_size,slate_games,int(np.max(trial_n)) if len(trial_n) else int(trials))
    score,_rnwd = rnwd.showdown_score(cands, {'p99':p99,'cvar99':cvar99,'p95':p95}, meta)
    order=np.argsort(-score,kind='mergesort')
    return {'score':score,'top10_lcb':top10_lcb,'top01_lcb':top01_lcb,'win_lcb':win_lcb,'p99':p99,'p95':p95,'order':order,'context':ctx.as_dict(),'advisor_selector_patch':ADVISOR_SELECTOR_PATCH_ID}


def rank_selected_board(selected,cands,components,meta,podium_depth=2):
    selected=np.asarray(selected,np.int32); cands=np.asarray(cands,np.int32); pos={int(g):i for i,g in enumerate(cands)}
    score=np.asarray(components['score'],float)
    family=np.asarray(components.get('family_score',score),float)
    individual=np.asarray(components.get('individual_score',score),float)
    top01=np.asarray(components.get('top01_lcb',np.zeros(len(cands))),float)
    win=np.asarray(components.get('win_lcb',np.zeros(len(cands))),float)
    p99=np.asarray(components.get('p99',np.zeros(len(cands))),float)
    duplication_supplied='projected_duplication' in components
    duplication=np.asarray(components.get('projected_duplication',np.zeros(len(cands))),float)
    # The portfolio is selected on frozen common-world championship coverage.
    # Preserve that MC authority at the terminal boundary: structural/family
    # scores may resolve only exact MC ties and cannot push a lower Top-0.1 row
    # ahead of a stronger survivor before global Core-5 sealing.
    ordered=np.asarray(sorted((int(g) for g in selected),key=lambda g:(-top01[pos[g]],-win[pos[g]],-p99[pos[g]],-family[pos[g]],-individual[pos[g]],duplication[pos[g]],g)),np.int32)
    ordered_scores=np.asarray([top01[pos[int(g)]] for g in ordered],float)
    reasons=[]
    for g in ordered:
        i=pos[int(g)]
        if duplication_supplied:
            reasons.append('TOP_0_1_PRIMARY_DUPLICATION_FINAL_TIEBREAKER')
        else:
            reasons.append('TOP_0_1_PRIMARY_NEAR_TIE_ORDER')
    return ordered,ordered_scores,reasons
