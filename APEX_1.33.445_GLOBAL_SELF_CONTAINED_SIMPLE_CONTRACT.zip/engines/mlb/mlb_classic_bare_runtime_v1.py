from __future__ import annotations

import csv
import json
import math
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix

ENGINE_ID = "APEX_MLB_CLASSIC_BARE_RUNTIME_v1"
PATCH_ID = "MLB_CLASSIC_BARE_ESSENTIALS_FAST_PATH_v1"

EXECUTION_ID = os.environ.get("APEX_EXECUTION_ID", "UNSET")
FIELD_SIZE = int(os.environ.get("APEX_FIELD_SIZE", "0"))
BOARD_SIZE = int(os.environ.get("APEX_BOARD_SIZE", "10"))
CANDIDATE_TARGET = int(os.environ.get("APEX_BARE_CANDIDATES", "64"))
SIM_TRIALS = int(os.environ.get("APEX_BARE_SIM_TRIALS", "4096"))
SALARY_MIN = int(os.environ.get("APEX_SALARY_MIN", "48000"))
SALARY_MAX = int(os.environ.get("APEX_SALARY_MAX", "50000"))
MAX_HITTERS_TEAM = int(os.environ.get("APEX_MAX_HITTERS_TEAM", "5"))
MAX_BOARD_EXPOSURE = int(os.environ.get("APEX_MAX_BOARD_EXPOSURE", "7"))
MAX_CANDIDATE_OVERLAP = int(os.environ.get("APEX_MAX_CANDIDATE_OVERLAP", "8"))
SEED = int(os.environ.get("APEX_SEED", str(max(FIELD_SIZE, 1) * 1000003 + 260821)))
INPUT_RAW = os.environ.get("APEX_PLAYER_POOL", "")
OUT_DIR = Path(os.environ.get("APEX_OUTPUT_DIR", "/mnt/data"))
GLOBAL_STATE_VERSION = os.environ.get("APEX_GLOBAL_STATE_VERSION", "UNKNOWN")

if EXECUTION_ID == "UNSET" or FIELD_SIZE <= 0 or not INPUT_RAW:
    raise RuntimeError("RUN_INVALID:MISSING_REQUIRED_RUNTIME_ARGUMENTS")
if os.environ.get("APEX_PREBUILD_ROSTER_CHECK") != "PASS":
    raise RuntimeError("RUN_INVALID:PREBUILD_ROSTER_GATE_NOT_PASSED")
if SIM_TRIALS <= 0:
    raise RuntimeError("ENGINE_INTEGRITY_HALT:MC_ITERATIONS_ZERO")
if BOARD_SIZE <= 0 or CANDIDATE_TARGET < BOARD_SIZE:
    raise RuntimeError("RUN_INVALID:BARE_CANDIDATE_TARGET_LT_BOARD_SIZE")

INPUT = Path(INPUT_RAW)
OUT_DIR.mkdir(parents=True, exist_ok=True)

SLOTS = ("P1", "P2", "C", "1B", "2B", "3B", "SS", "OF1", "OF2", "OF3")
HITTER_SLOTS = set(SLOTS[2:])
SCENARIOS = (
    "BALANCED", "POWER", "LEVERAGE", "RECENT_CEILING",
    "RUN_ENV", "SPEED", "PITCHER_K", "LOW_OWNED_TAIL",
)


def num(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        s = str(v).strip().replace("$", "").replace(",", "").replace("%", "").replace("+", "")
        if not s or s in {"-", "–", "—", "nan", "None"}:
            return default
        return float(s)
    except Exception:
        return default


def american_prob(v: Any) -> float:
    x = num(v, float("nan"))
    if not math.isfinite(x) or x == 0:
        return 0.0
    return 100.0 / (x + 100.0) if x > 0 else (-x) / ((-x) + 100.0)


def zscore(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=np.float64)
    sd = float(np.std(a))
    return np.zeros_like(a) if sd < 1e-9 else (a - float(np.mean(a))) / sd


def eligible_slots(pos: str) -> tuple[str, ...]:
    parts = {x.strip().upper() for x in str(pos).split("/") if x.strip()}
    out: list[str] = []
    if "P" in parts:
        out.extend(("P1", "P2"))
    for p in ("C", "1B", "2B", "3B", "SS"):
        if p in parts:
            out.append(p)
    if "OF" in parts:
        out.extend(("OF1", "OF2", "OF3"))
    return tuple(out)


def load_active_pool(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        raise RuntimeError(f"RUN_INVALID:PLAYER_POOL_MISSING:{path}")
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        rows = [dict(r) for r in reader]
        headers = set(reader.fieldnames or ())
    required = {"PLAYER", "POS", "LINEUP", "TEAM", "OPP", "SAL", "FPTS", "RST%", "T Runs", "Win %"}
    missing = sorted(required - headers)
    if missing:
        raise RuntimeError("RUN_INVALID:MISSING_REQUIRED_COLUMNS:" + ",".join(missing))

    active: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for raw_idx, r in enumerate(rows):
        pos = str(r.get("POS", "")).strip().upper()
        lineup_raw = str(r.get("LINEUP", "")).strip().upper()
        is_p = pos == "P" and lineup_raw == "SP"
        is_h = False
        if pos != "P":
            try:
                is_h = 1 <= int(float(lineup_raw)) <= 9
            except Exception:
                is_h = False
        if not (is_p or is_h):
            continue
        name = str(r.get("PLAYER", "")).strip()
        team = str(r.get("TEAM", "")).strip().upper()
        key = (name, pos, team)
        if not name or not team or key in seen:
            continue
        seen.add(key)
        active.append({
            "idx": len(active), "raw_idx": raw_idx, "name": name, "pos": pos,
            "team": team, "opp": str(r.get("OPP", "")).strip().upper(),
            "salary": int(round(num(r.get("SAL"), 0.0))),
            "fpts": num(r.get("FPTS"), 0.0), "rst": num(r.get("RST%"), 0.0),
            "team_runs": num(r.get("T Runs"), 0.0), "win_pct": num(r.get("Win %"), 0.0),
            "lineup": 0 if is_p else int(float(lineup_raw)),
            "avg": num(r.get("AVG FPTS"), num(r.get("FPTS"), 0.0)),
            "l7": num(r.get("L7 FPTS"), num(r.get("FPTS"), 0.0)),
            "l3": num(r.get("L3 FPTS"), num(r.get("FPTS"), 0.0)),
            "hr_p": american_prob(r.get("1+ HR")), "hit_p": american_prob(r.get("1+ Hit")),
            "rbi_p": american_prob(r.get("1+ RBI")), "sb_p": american_prob(r.get("1+ SB")),
            "tb": num(r.get("O/U TB"), 0.0), "k_prop": num(r.get("O/U K"), 0.0),
            "k9": num(r.get("K/9"), 0.0), "swstr": num(r.get("SwStr%"), 0.0),
            "xfip": num(r.get("xFIP"), 0.0), "hr9": num(r.get("HR/9"), 0.0),
            "slots": eligible_slots(pos),
        })
    if sum(p["pos"] == "P" for p in active) < 2 or sum(p["pos"] != "P" for p in active) < 8:
        raise RuntimeError("RUN_INVALID:NO_LEGAL_ROSTER_POOL")
    return active


players = load_active_pool(INPUT)
N = len(players)
by_idx = {p["idx"]: p for p in players}
teams = sorted({p["team"] for p in players if p["pos"] != "P"})
team_to_hitters = {t: [p["idx"] for p in players if p["pos"] != "P" and p["team"] == t] for t in teams}

# Compact role-specific feature matrix. No diagnostics, no historical adapters, no family-closure tree.
h_idx = np.array([p["idx"] for p in players if p["pos"] != "P"], dtype=np.int32)
p_idx = np.array([p["idx"] for p in players if p["pos"] == "P"], dtype=np.int32)

base = np.zeros(N, dtype=np.float64)
power = np.zeros(N, dtype=np.float64)
leverage = np.zeros(N, dtype=np.float64)
recent = np.zeros(N, dtype=np.float64)
run_env = np.zeros(N, dtype=np.float64)
speed = np.zeros(N, dtype=np.float64)
pitcher_k = np.zeros(N, dtype=np.float64)

if h_idx.size:
    hfpts = np.array([players[i]["fpts"] for i in h_idx])
    hhr = np.array([players[i]["hr_p"] for i in h_idx])
    hhit = np.array([players[i]["hit_p"] for i in h_idx])
    hrbi = np.array([players[i]["rbi_p"] for i in h_idx])
    hsb = np.array([players[i]["sb_p"] for i in h_idx])
    htb = np.array([players[i]["tb"] for i in h_idx])
    hrun = np.array([players[i]["team_runs"] for i in h_idx])
    hrecent = np.array([max(players[i]["l3"], players[i]["l7"], players[i]["avg"]) for i in h_idx])
    horder = np.array([(10 - players[i]["lineup"]) / 9.0 for i in h_idx])
    hown = np.array([players[i]["rst"] for i in h_idx])
    base[h_idx] = 1.00*zscore(hfpts) + 0.38*zscore(hhit) + 0.32*zscore(hrun) + 0.18*zscore(horder)
    power[h_idx] = 0.90*zscore(hhr) + 0.45*zscore(hrbi) + 0.35*zscore(htb)
    leverage[h_idx] = -zscore(np.log1p(np.maximum(hown, 0)))
    recent[h_idx] = zscore(hrecent)
    run_env[h_idx] = zscore(hrun)
    speed[h_idx] = zscore(hsb)

if p_idx.size:
    pfpts = np.array([players[i]["fpts"] for i in p_idx])
    pk = np.array([players[i]["k_prop"] for i in p_idx])
    pk9 = np.array([players[i]["k9"] for i in p_idx])
    psw = np.array([players[i]["swstr"] for i in p_idx])
    pwin = np.array([players[i]["win_pct"] for i in p_idx])
    pxfip = np.array([players[i]["xfip"] for i in p_idx])
    phr9 = np.array([players[i]["hr9"] for i in p_idx])
    pown = np.array([players[i]["rst"] for i in p_idx])
    base[p_idx] = 1.10*zscore(pfpts) + 0.45*zscore(pwin) + 0.25*zscore(-pxfip)
    pitcher_k[p_idx] = 0.70*zscore(pk) + 0.70*zscore(pk9) + 0.35*zscore(psw) + 0.20*zscore(-phr9)
    leverage[p_idx] = -zscore(np.log1p(np.maximum(pown, 0)))
    recent[p_idx] = zscore(np.array([max(players[i]["l3"], players[i]["l7"], players[i]["avg"]) for i in p_idx]))

scenario_weight = {
    "BALANCED": base + .30*power + .15*recent + .10*leverage + .20*pitcher_k,
    "POWER": base + .85*power + .10*recent + .05*leverage + .20*pitcher_k,
    "LEVERAGE": base + .25*power + .10*recent + .55*leverage + .20*pitcher_k,
    "RECENT_CEILING": base + .30*power + .65*recent + .10*leverage + .20*pitcher_k,
    "RUN_ENV": base + .30*power + .55*run_env + .10*leverage + .20*pitcher_k,
    "SPEED": base + .25*power + .50*speed + .15*leverage + .20*pitcher_k,
    "PITCHER_K": base + .25*power + .10*leverage + .85*pitcher_k,
    "LOW_OWNED_TAIL": base + .45*power + .60*leverage + .25*recent + .25*pitcher_k,
}

# Assignment variables exist only when the player is eligible for the slot.
assign: list[tuple[int, str]] = []
for p in players:
    for s in p["slots"]:
        assign.append((p["idx"], s))
A = len(assign)
assign_by_slot: dict[str, list[int]] = defaultdict(list)
assign_by_player: dict[int, list[int]] = defaultdict(list)
for j, (i, s) in enumerate(assign):
    assign_by_slot[s].append(j)
    assign_by_player[i].append(j)

y4_offset = A
y5_offset = y4_offset + len(teams)
V = A + 2*len(teams)
team_pos = {t: k for k, t in enumerate(teams)}

base_rows: list[tuple[list[int], list[float], float, float]] = []
for s in SLOTS:
    js = assign_by_slot[s]
    if not js:
        raise RuntimeError(f"RUN_INVALID:POSITION_UNFILLABLE:{s}")
    base_rows.append((js, [1.0]*len(js), 1.0, 1.0))
for i in range(N):
    js = assign_by_player[i]
    if js:
        base_rows.append((js, [1.0]*len(js), -np.inf, 1.0))
# Salary floor/ceiling.
salary_js = list(range(A))
salary_vals = [float(players[i]["salary"]) for i, _ in assign]
base_rows.append((salary_js, salary_vals, float(SALARY_MIN), float(SALARY_MAX)))
# Maximum five hitters from one team; stack threshold binaries for 4+ and 5+ bonuses.
for t in teams:
    hit_js = [j for j, (i, s) in enumerate(assign) if s in HITTER_SLOTS and players[i]["team"] == t]
    if not hit_js:
        continue
    base_rows.append((hit_js, [1.0]*len(hit_js), -np.inf, float(MAX_HITTERS_TEAM)))
    k = team_pos[t]
    base_rows.append((hit_js + [y4_offset+k], [-1.0]*len(hit_js) + [4.0], -np.inf, 0.0))
    base_rows.append((hit_js + [y5_offset+k], [-1.0]*len(hit_js) + [5.0], -np.inf, 0.0))


def make_constraints(no_goods: list[set[int]], blocked: set[int]) -> LinearConstraint:
    rows = list(base_rows)
    for selected in no_goods:
        js = [j for j, (i, _) in enumerate(assign) if i in selected]
        rows.append((js, [1.0]*len(js), -np.inf, float(MAX_CANDIDATE_OVERLAP)))
    for i in blocked:
        js = assign_by_player[i]
        if js:
            rows.append((js, [1.0]*len(js), 0.0, 0.0))
    data: list[float] = []
    indices: list[int] = []
    indptr = [0]
    lb = np.empty(len(rows), dtype=np.float64)
    ub = np.empty(len(rows), dtype=np.float64)
    for r, (js, vals, lo, hi) in enumerate(rows):
        indices.extend(js); data.extend(vals); indptr.append(len(indices)); lb[r] = lo; ub[r] = hi
    mat = csr_matrix((np.asarray(data), np.asarray(indices), np.asarray(indptr)), shape=(len(rows), V))
    return LinearConstraint(mat, lb, ub)


bounds = Bounds(np.zeros(V), np.ones(V))
integrality = np.ones(V, dtype=np.int8)
no_goods: list[set[int]] = []
candidate_exposure: Counter[int] = Counter()
candidates: list[dict[str, Any]] = []

for k in range(CANDIDATE_TARGET):
    scenario = SCENARIOS[k % len(SCENARIOS)]
    w = scenario_weight[scenario]
    c = np.zeros(V, dtype=np.float64)
    for j, (i, _) in enumerate(assign):
        # Tiny deterministic tie-breaker prevents unstable equivalent solutions.
        tie = ((i * 131 + k * 17 + j * 7) % 997) * 1e-7
        c[j] = -(w[i] + tie)
    c[y4_offset:y5_offset] = -0.42
    c[y5_offset:] = -0.72
    exposure_limit = max(2, int(math.ceil((k + 1) * 0.62)))
    blocked = {i for i, n in candidate_exposure.items() if n >= exposure_limit}
    res = milp(c=c, integrality=integrality, bounds=bounds, constraints=make_constraints(no_goods, blocked), options={"presolve": True, "mip_rel_gap": 0.002, "time_limit": 2.0})
    if not res.success or res.x is None:
        break
    chosen_assign = np.flatnonzero(res.x[:A] > 0.5)
    if len(chosen_assign) != len(SLOTS):
        raise RuntimeError("RUN_FAIL:BARE_MILP_SLOT_COUNT")
    slot_map = {assign[j][1]: assign[j][0] for j in chosen_assign}
    selected = set(slot_map.values())
    if len(selected) != 10:
        raise RuntimeError("RUN_FAIL:BARE_MILP_DUPLICATE_PLAYER")
    salary = sum(players[i]["salary"] for i in selected)
    if not (SALARY_MIN <= salary <= SALARY_MAX):
        raise RuntimeError("RUN_FAIL:BARE_MILP_SALARY")
    hit_counts = Counter(players[i]["team"] for i in selected if players[i]["pos"] != "P")
    if hit_counts and max(hit_counts.values()) > MAX_HITTERS_TEAM:
        raise RuntimeError("RUN_FAIL:BARE_MILP_TEAM_MAX")
    own_prod = 1.0
    for i in selected:
        own_prod *= max(players[i]["rst"] / 100.0, 1e-4)
    candidates.append({
        "candidate_id": f"B{k+1:03d}", "scenario": scenario, "slot_map": slot_map,
        "selected": tuple(sorted(selected)), "salary": salary,
        "stack": "-".join(map(str, sorted(hit_counts.values(), reverse=True))),
        "stack_signature": "/".join(f"{t}{n}" for t, n in sorted(hit_counts.items(), key=lambda x:(-x[1], x[0]))),
        "ownership_product": own_prod,
    })
    no_goods.append(selected)
    candidate_exposure.update(selected)

if len(candidates) < BOARD_SIZE:
    raise RuntimeError(f"RUN_FAIL:BARE_CANDIDATE_SHORT:{len(candidates)}:{BOARD_SIZE}")

# Minimal coherent simulation: player shock + shared team shock. This is the only simulation layer.
rng = np.random.default_rng(SEED)
means = np.array([p["fpts"] for p in players], dtype=np.float32)
sigmas = np.empty(N, dtype=np.float32)
for i, p in enumerate(players):
    if p["pos"] == "P":
        sigmas[i] = max(5.5, 0.42*abs(p["fpts"]) + 0.35*p["k9"] + 1.0)
    else:
        sigmas[i] = max(4.8, 0.62*abs(p["fpts"]) + 7.0*p["hr_p"] + 2.0*p["sb_p"])
normal = rng.standard_normal((N, SIM_TRIALS), dtype=np.float32)
heavy = (rng.chisquare(3.0, (N, SIM_TRIALS)).astype(np.float32) - 3.0) / np.float32(math.sqrt(6.0))
outcomes = means[:, None] + sigmas[:, None] * (np.float32(.78)*normal + np.float32(.22)*heavy)

team_shocks = {t: rng.standard_normal(SIM_TRIALS).astype(np.float32) for t in teams}
for i, p in enumerate(players):
    if p["pos"] != "P":
        outcomes[i] += team_shocks[p["team"]] * np.float32(1.1 + 2.4*p["hr_p"])
        outcomes[i] = np.maximum(outcomes[i], 0.0)
    else:
        outcomes[i] = np.maximum(outcomes[i], -12.0)

C = len(candidates)
incidence = np.zeros((C, N), dtype=np.float32)
for cidx, cand in enumerate(candidates):
    incidence[cidx, list(cand["selected"])] = 1.0
scores = incidence @ outcomes
p95 = np.quantile(scores, .95, axis=1)
p99 = np.quantile(scores, .99, axis=1)
q99 = p99[:, None]
cvar99 = np.array([float(np.mean(scores[i][scores[i] >= q99[i, 0]])) for i in range(C)])
winners = np.argmax(scores, axis=0)
win_rate = np.bincount(winners, minlength=C).astype(np.float64) / SIM_TRIALS
# Contest-size-aware top-tail proxy: high quantile + win probability + ownership leverage.
log_own = np.log(np.maximum(np.array([c["ownership_product"] for c in candidates]), 1e-30))
lev = -zscore(log_own)
stack5 = np.array([1.0 if c["stack"].startswith("5-") else 0.0 for c in candidates])
final_metric = 0.50*zscore(p99) + 0.30*zscore(cvar99) + 0.55*zscore(win_rate) + 0.16*lev + 0.08*stack5

# Exact final-board selection: one compact MILP, enforcing the only portfolio cap retained.
# Variables are candidate lineups; objective is the tail metric.
board_rows: list[tuple[list[int], list[float], float, float]] = []
board_rows.append((list(range(C)), [1.0]*C, float(BOARD_SIZE), float(BOARD_SIZE)))
for i in range(N):
    ids = [j for j, cand in enumerate(candidates) if i in cand["selected"]]
    if ids:
        board_rows.append((ids, [1.0]*len(ids), -np.inf, float(MAX_BOARD_EXPOSURE)))
_data: list[float] = []
_indices: list[int] = []
_indptr = [0]
_lb = np.empty(len(board_rows), dtype=np.float64)
_ub = np.empty(len(board_rows), dtype=np.float64)
for r, (js, vals, lo, hi) in enumerate(board_rows):
    _indices.extend(js); _data.extend(vals); _indptr.append(len(_indices)); _lb[r] = lo; _ub[r] = hi
_board_A = csr_matrix((np.asarray(_data), np.asarray(_indices), np.asarray(_indptr)), shape=(len(board_rows), C))
_board_res = milp(
    c=-final_metric.astype(np.float64), integrality=np.ones(C, dtype=np.int8),
    bounds=Bounds(np.zeros(C), np.ones(C)), constraints=LinearConstraint(_board_A, _lb, _ub),
    options={"presolve": True, "mip_rel_gap": 0.0, "time_limit": 3.0},
)
if not _board_res.success or _board_res.x is None:
    raise RuntimeError("RUN_FAIL:BARE_BOARD_PORTFOLIO_INFEASIBLE")
selected_board_idx = np.flatnonzero(_board_res.x > 0.5)
if len(selected_board_idx) != BOARD_SIZE:
    raise RuntimeError(f"RUN_FAIL:BARE_BOARD_SHORT:{len(selected_board_idx)}:{BOARD_SIZE}")
selected_board_idx = selected_board_idx[np.argsort(-final_metric[selected_board_idx], kind="stable")]
board: list[dict[str, Any]] = []
for idx in selected_board_idx:
    cand = candidates[int(idx)]
    row: dict[str, Any] = {
        "BOARD_RANK": len(board)+1, "LINEUP_ID": cand["candidate_id"], "SALARY": cand["salary"],
        "LEFTOVER": SALARY_MAX-cand["salary"], "STACK": cand["stack"], "STACK_SIGNATURE": cand["stack_signature"],
        "SCENARIO": cand["scenario"], "MC_WIN_RATE": round(float(win_rate[idx]), 8),
        "P95": round(float(p95[idx]), 4), "P99": round(float(p99[idx]), 4), "CVAR99": round(float(cvar99[idx]), 4),
    }
    for slot in SLOTS:
        p = players[cand["slot_map"][slot]]
        row[slot] = p["name"]
        row[slot+"_TEAM"] = p["team"]
        row[slot+"_SALARY"] = p["salary"]
    board.append(row)

if len(board) != BOARD_SIZE:
    raise RuntimeError(f"RUN_FAIL:BARE_BOARD_SHORT:{len(board)}:{BOARD_SIZE}")

board_path = OUT_DIR / f"execution_{EXECUTION_ID}_final_board.csv"
with board_path.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(board[0].keys()))
    writer.writeheader(); writer.writerows(board)

receipt = {
    "GLOBAL_STATE_VERSION": GLOBAL_STATE_VERSION,
    "ENGINE_ID": ENGINE_ID,
    "PATCH_ID": PATCH_ID,
    "ACTIVE_POOL": N,
    "OUT_PURGE": "PREBUILD_ROSTER_GATE_APPLIED",
    "PHASE2_BUILT_LINEUPS": C,
    "BASE_SIM_TRIALS": SIM_TRIALS,
    "BUBBLE_EXTRA_TRIALS_TOTAL": 0,
    "BUBBLE_LINEUPS_UNRESOLVED": 0,
    "HANDOFF_SURVIVORS": C,
    "SELECTOR_REVIEWED_LINEUPS": C,
    "FINAL_BOARD_SIZE": len(board),
    "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
    "ENGINE_PROFILE": "BARE_ESSENTIALS_ONLY",
    "REMOVED_LAYERS": [
        "PHASE1_CALIBRATION_ARTIFACTS", "FAMILY_SIBLING_CLOSURE_TREE", "CROSS_PATTERN_RECALL_TREE",
        "MACRO_SPINE_RECALL", "AI_REVIEW_PACKET", "HISTORICAL_CONSENSUS_SELECTOR",
        "NONINFERIOR_BUBBLE_RESIM", "POSTBOARD_DIAGNOSTICS", "RUNTIME_TELEMETRY", "AUDIT_ARTIFACT_ZIP"
    ],
    "RETAINED_LAYERS": [
        "PREBUILD_ROSTER_GATE", "DK_LEGALITY_MILP", "SALARY_GATE", "TEAM_MAX_GATE",
        "DETERMINISTIC_MULTI_SCENARIO_BIRTH", "COHERENT_VECTOR_MC", "TAIL_SELECTOR", "BOARD_EXPOSURE_CAP", "BOARD_RENDER"
    ],
    "FINAL_BOARD_PATH": str(board_path),
    "FINAL_BOARD": board,
}
print(json.dumps(receipt, separators=(",", ":")))
