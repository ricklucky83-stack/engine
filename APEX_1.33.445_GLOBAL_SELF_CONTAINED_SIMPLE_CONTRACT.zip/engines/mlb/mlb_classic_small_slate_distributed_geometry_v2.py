from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Tuple

PATCH_ID = "MLB_CLASSIC_SMALL_SLATE_DISTRIBUTED_GEOMETRY_v2"

MANDATORY_STRUCTURE_LANES = frozenset({
    "5_X_FAMILIES",
    "4_X_FAMILIES",
    "3_3_2",
    "3_3_1_1",
    "3_2_2_1",
    "3_2_1_1_1",
    "2_2_2_2",
    "2_2_2_1_1",
    "2_2_1_1_1_1",
    "2_1_1_1_1_1_1",
})

@dataclass(frozen=True)
class Candidate:
    lineup_id: str
    structure_lane: str
    salary: int
    pitcher_pair: Tuple[str, str]
    mc_win_rate: float
    mc_top_0_1_rate: float
    p95: float
    p99: float
    correlation_score: float
    duplication_risk: float
    ownership_product: float

def validate_structure_lane(candidate: Candidate) -> bool:
    return candidate.structure_lane in MANDATORY_STRUCTURE_LANES

def salary_percentiles(
    salaries: Sequence[int],
) -> Tuple[float, float, float]:
    if not salaries:
        raise ValueError("Qualified salary distribution is empty.")
    ordered = sorted(salaries)

    def pct(p: float) -> float:
        index = (len(ordered) - 1) * p
        lower = int(index)
        upper = min(lower + 1, len(ordered) - 1)
        fraction = index - lower
        return (
            ordered[lower] * (1.0 - fraction)
            + ordered[upper] * fraction
        )

    return pct(0.25), pct(0.50), pct(0.75)

def salary_lane(
    salary: int,
    p25: float,
    p50: float,
    p75: float,
) -> str:
    if salary < p25:
        return "DEEP_DISCOUNT"
    if salary < p50:
        return "LOW_SPEND"
    if salary < p75:
        return "MID_SPEND"
    return "HIGH_SPEND"

def qualify_candidate(candidate: Candidate) -> bool:
    if not validate_structure_lane(candidate):
        return False
    return all(
        [
            max(candidate.mc_win_rate, candidate.mc_top_0_1_rate) > 0,
            max(candidate.p95, candidate.p99) > 0,
            candidate.correlation_score > 0,
            candidate.duplication_risk >= 0,
            candidate.ownership_product >= 0,
        ]
    )

def preserve_pitcher_pair_across_lanes(
    candidates: Sequence[Candidate],
    max_per_pair_per_lane: int = 1,
) -> List[Candidate]:
    selected: List[Candidate] = []
    counts: Dict[Tuple[Tuple[str, str], str], int] = {}

    ranked = sorted(
        (row for row in candidates if qualify_candidate(row)),
        key=lambda row: (
            -row.mc_win_rate,
            -row.mc_top_0_1_rate,
            -row.p99,
            -row.p95,
            -row.correlation_score,
            row.duplication_risk,
            row.ownership_product,  # ownership is final tie-break
        ),
    )

    for row in ranked:
        key = (tuple(sorted(row.pitcher_pair)), row.structure_lane)
        if counts.get(key, 0) >= max_per_pair_per_lane:
            continue
        selected.append(row)
        counts[key] = counts.get(key, 0) + 1

    return selected

def validate_phase_recall(
    legal_lane_counts: Dict[str, int],
    surviving_lane_counts: Dict[str, int],
) -> None:
    missing = [
        lane
        for lane, legal_count in legal_lane_counts.items()
        if legal_count > 0 and surviving_lane_counts.get(lane, 0) <= 0
    ]
    if missing:
        raise RuntimeError(
            "RUN_FAIL:DISTRIBUTED_STRUCTURE_RECALL_FAILURE:"
            + ",".join(sorted(missing))
        )

def validate_final_entries(
    lineup_ids: Sequence[str],
    allow_duplicates: bool = False,
) -> None:
    if not allow_duplicates and len(lineup_ids) != len(set(lineup_ids)):
        raise RuntimeError("RUN_FAIL:FINAL_ENTRY_EXACT_DUPLICATES")

def promotion_ready(
    tested_lanes: Iterable[str],
    raw_end_to_end_replay_complete: bool,
    phase2_recall_complete: bool,
    phase3_recall_complete: bool,
    phase3_1_zero_structure_rejections: bool,
    final_entry_duplicates: int,
    no_rank_regression: bool,
) -> bool:
    return all(
        [
            MANDATORY_STRUCTURE_LANES.issubset(set(tested_lanes)),
            raw_end_to_end_replay_complete,
            phase2_recall_complete,
            phase3_recall_complete,
            phase3_1_zero_structure_rejections,
            final_entry_duplicates == 0,
            no_rank_regression,
        ]
    )
