from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from itertools import combinations
from typing import Mapping, Sequence

PATCH_ID = "MLB_CLASSIC_CROSS_PATTERN_FAMILY_SIBLING_CLOSURE_v2"
ALLOWED_TRANSITIONS = frozenset({("5-3", "5-2-1"), ("5-2-1", "5-1-1-1")})


@dataclass(frozen=True)
class CrossPatternSwap:
    removed_player_id: int
    added_player_id: int
    parent_pattern: str
    child_pattern: str
    primary_team: str
    secondary_team: str
    added_team: str


@dataclass(frozen=True)
class CrossPatternClosureTelemetry:
    patch_id: str
    parent_5_3_rows: int
    parent_5_2_1_rows: int
    attempts_5_3_to_5_2_1: int
    rows_5_3_to_5_2_1: int
    attempts_5_2_1_to_5_1_1_1: int
    rows_5_2_1_to_5_1_1_1: int
    integrity_failures: int
    generation_seconds: float

    def to_receipt(self) -> dict[str, object]:
        return asdict(self)


def pattern_from_hitters(hitter_ids: Sequence[int], player_team: Mapping[int, str]) -> str:
    counts = sorted(Counter(player_team[int(idx)] for idx in hitter_ids).values(), reverse=True)
    return "-".join(str(int(x)) for x in counts)


def primary_five_stack(
    hitter_ids: Sequence[int],
    player_team: Mapping[int, str],
) -> tuple[str, tuple[int, ...]]:
    groups: dict[str, list[int]] = {}
    for idx in hitter_ids:
        groups.setdefault(player_team[int(idx)], []).append(int(idx))
    five = [(team, tuple(sorted(ids))) for team, ids in groups.items() if len(ids) == 5]
    if len(five) != 1:
        raise ValueError("CROSS_PATTERN_PRIMARY_FIVE_STACK_REQUIRED")
    return five[0]


def spine_key(
    pitcher_pair: Sequence[int],
    hitter_ids: Sequence[int],
    player_team: Mapping[int, str],
) -> tuple[tuple[int, int], str, tuple[int, ...]]:
    team, five = primary_five_stack(hitter_ids, player_team)
    pp = tuple(int(x) for x in pitcher_pair)
    if len(pp) != 2:
        raise ValueError("CROSS_PATTERN_PITCHER_PAIR_REQUIRED")
    return (pp, team, five)


def _groups(hitter_ids: Sequence[int], player_team: Mapping[int, str]) -> dict[str, tuple[int, ...]]:
    grouped: dict[str, list[int]] = {}
    for idx in hitter_ids:
        grouped.setdefault(player_team[int(idx)], []).append(int(idx))
    return {team: tuple(sorted(ids)) for team, ids in grouped.items()}


def swaps_5_3_to_5_2_1(
    hitter_ids: Sequence[int],
    player_team: Mapping[int, str],
    team_to_hitters: Mapping[str, Sequence[int]],
    blocked_teams: Sequence[str] = (),
) -> tuple[CrossPatternSwap, ...]:
    if pattern_from_hitters(hitter_ids, player_team) != "5-3":
        return ()
    groups = _groups(hitter_ids, player_team)
    primary_team = next(team for team, ids in groups.items() if len(ids) == 5)
    secondary_team = next(team for team, ids in groups.items() if len(ids) == 3)
    blocked = set(map(str, blocked_teams))
    current = set(map(int, hitter_ids))
    out: list[CrossPatternSwap] = []
    for removed in groups[secondary_team]:
        for added_team in sorted(team_to_hitters):
            if added_team in {primary_team, secondary_team} or added_team in blocked:
                continue
            for added in sorted(map(int, team_to_hitters[added_team])):
                if added in current:
                    continue
                out.append(CrossPatternSwap(
                    removed_player_id=int(removed),
                    added_player_id=int(added),
                    parent_pattern="5-3",
                    child_pattern="5-2-1",
                    primary_team=primary_team,
                    secondary_team=secondary_team,
                    added_team=added_team,
                ))
    out.sort(key=lambda x: (
        x.primary_team, x.secondary_team, x.added_team,
        x.removed_player_id, x.added_player_id,
    ))
    return tuple(out)


def swaps_5_2_1_to_5_1_1_1(
    hitter_ids: Sequence[int],
    player_team: Mapping[int, str],
    team_to_hitters: Mapping[str, Sequence[int]],
    blocked_teams: Sequence[str] = (),
) -> tuple[CrossPatternSwap, ...]:
    if pattern_from_hitters(hitter_ids, player_team) != "5-2-1":
        return ()
    groups = _groups(hitter_ids, player_team)
    primary_team = next(team for team, ids in groups.items() if len(ids) == 5)
    secondary_team = next(team for team, ids in groups.items() if len(ids) == 2)
    existing_teams = set(groups)
    blocked = set(map(str, blocked_teams))
    current = set(map(int, hitter_ids))
    out: list[CrossPatternSwap] = []
    for removed in groups[secondary_team]:
        for added_team in sorted(team_to_hitters):
            if added_team in existing_teams or added_team in blocked:
                continue
            for added in sorted(map(int, team_to_hitters[added_team])):
                if added in current:
                    continue
                out.append(CrossPatternSwap(
                    removed_player_id=int(removed),
                    added_player_id=int(added),
                    parent_pattern="5-2-1",
                    child_pattern="5-1-1-1",
                    primary_team=primary_team,
                    secondary_team=secondary_team,
                    added_team=added_team,
                ))
    out.sort(key=lambda x: (
        x.primary_team, x.secondary_team, x.added_team,
        x.removed_player_id, x.added_player_id,
    ))
    return tuple(out)


def apply_cross_pattern_swap(hitter_ids: Sequence[int], swap: CrossPatternSwap) -> tuple[int, ...]:
    current = tuple(int(x) for x in hitter_ids)
    if swap.removed_player_id not in current or swap.added_player_id in current:
        raise ValueError("INVALID_CROSS_PATTERN_SWAP")
    child = tuple(sorted(
        swap.added_player_id if idx == swap.removed_player_id else idx
        for idx in current
    ))
    if len(child) != 8 or len(set(child)) != 8:
        raise ValueError("INVALID_CROSS_PATTERN_RESULT")
    return child


def validate_cross_pattern_sibling(
    parent_hitters: Sequence[int],
    child_hitters: Sequence[int],
    player_team: Mapping[int, str],
) -> bool:
    parent = set(map(int, parent_hitters))
    child = set(map(int, child_hitters))
    if len(parent) != 8 or len(child) != 8 or len(parent & child) != 7:
        return False
    parent_pattern = pattern_from_hitters(tuple(parent), player_team)
    child_pattern = pattern_from_hitters(tuple(child), player_team)
    if (parent_pattern, child_pattern) not in ALLOWED_TRANSITIONS:
        return False
    try:
        p_team, p_five = primary_five_stack(tuple(parent), player_team)
        c_team, c_five = primary_five_stack(tuple(child), player_team)
    except ValueError:
        return False
    return p_team == c_team and p_five == c_five
