#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, re, shutil, zipfile
from datetime import datetime, timezone
from pathlib import Path

PATCH_ID = 'MLB_SS_HRS_501_750_PROSPECTIVE_EXACT_WINNER_CERTIFICATION_v1'
SCHEMA_VERSION = '1.0.0'
FIELD_MIN, FIELD_MAX = 501, 750
BOARD_SIZE = 10
MIN_MC = 10000
RETRO_READ_ONLY_CONTESTS = {'191864350','191950963'}
POSTLOCK_KEYS = ('ACTUAL','REALIZED','POSTLOCK','CONTEST_RANK','FINISH_RANK','WINNING_LINEUP')

class GateError(RuntimeError): pass

def sha256_file(p: Path) -> str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024), b''): h.update(b)
    return h.hexdigest()

def atomic_json(p:Path,obj:dict)->None:
    p.parent.mkdir(parents=True,exist_ok=True); t=p.with_suffix(p.suffix+'.tmp')
    with t.open('w',encoding='utf-8') as f:
        json.dump(obj,f,indent=2,sort_keys=True); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(t,p)

def utc_now()->str: return datetime.now(timezone.utc).isoformat()

def canon_name(x:str)->str:
    s=str(x or '').lower()
    s=re.sub(r'\b(jr|sr|ii|iii|iv|v)\b\.?',' ',s)
    s=re.sub(r'[^a-z0-9]+',' ',s)
    return ' '.join(s.split())

def lineup_set(text:str)->tuple[str,...]:
    toks=re.split(r'\s+UTIL\s+', ' '+str(text or '').strip())
    names=[]
    for t in toks:
        t=re.sub(r'^\s*UTIL\s*','',t).strip()
        if t: names.append(canon_name(t))
    return tuple(sorted(x for x in names if x))

def _read_board(path:Path)->list[dict]:
    if path.suffix.lower()=='.json':
        obj=json.loads(path.read_text(encoding='utf-8'))
        rows=obj.get('FINAL_BOARD',obj.get('BOARD',obj)) if isinstance(obj,dict) else obj
        if not isinstance(rows,list): raise GateError('BOARD_JSON_ROWS_INVALID')
        return [dict(x) for x in rows]
    with path.open('r',encoding='utf-8-sig',newline='') as f: return [dict(x) for x in csv.DictReader(f)]

def _row_players(r:dict)->tuple[str,...]:
    vals=[]
    for k in ('UTIL1','UTIL2','UTIL3','P1','P2','P3','PLAYER1','PLAYER2','PLAYER3'):
        if r.get(k): vals.append(canon_name(r[k]))
    if len(vals)<3 and r.get('players'):
        raw=r['players']
        if isinstance(raw,list): vals=[canon_name(x) for x in raw]
        else: vals=[canon_name(x) for x in re.split(r'\s*[|/]\s*',str(raw)) if str(x).strip()]
    return tuple(sorted(vals[:3]))

def _receipt_int(r:dict,*keys,default=0)->int:
    for k in keys:
        if k in r:
            try:return int(float(r[k]))
            except:pass
    rec=r.get('RECEIPTS',{}) if isinstance(r.get('RECEIPTS'),dict) else {}
    for k in keys:
        if k in rec:
            try:return int(float(rec[k]))
            except:pass
    return int(default)

def freeze(*,receipt_path:Path,candidate_db:Path,board_path:Path,player_pool:Path,field_size:int,execution_id:str,engine_source:Path,output_dir:Path)->dict:
    if not (FIELD_MIN<=field_size<=FIELD_MAX): raise GateError(f'FIELD_OUTSIDE_501_750:{field_size}')
    for p,label in ((receipt_path,'RECEIPT'),(candidate_db,'CANDIDATE_DB'),(board_path,'BOARD'),(player_pool,'PLAYER_POOL'),(engine_source,'ENGINE_SOURCE')):
        if not p.exists(): raise GateError(f'{label}_MISSING:{p}')
    receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
    mc=_receipt_int(receipt,'MC_ITERATIONS','BASE_SIM_TRIALS','mc_sims')
    fake=_receipt_int(receipt,'FAKE_FIELD_ENTRIES','field_size',default=field_size)
    p2=_receipt_int(receipt,'PHASE2_BUILT_LINEUPS','candidate_lineups_frozen')
    reviewed=_receipt_int(receipt,'SELECTOR_REVIEWED_LINEUPS','selector_reviewed_lineups')
    method=str(receipt.get('EXECUTION_METHOD') or receipt.get('METHOD') or '')
    if mc<MIN_MC: raise GateError(f'MC_BELOW_MINIMUM:{mc}:{MIN_MC}')
    if fake<field_size: raise GateError(f'FAKE_FIELD_BELOW_CONTEST:{fake}:{field_size}')
    if p2<=0 or reviewed!=p2: raise GateError(f'FULL_SELECTOR_REVIEW_PARITY_FAIL:{p2}:{reviewed}')
    if method!='CHUNK_AND_STREAM_ONLY': raise GateError(f'EXECUTION_METHOD_INVALID:{method}')
    rows=_read_board(board_path)
    if len(rows)!=BOARD_SIZE: raise GateError(f'BOARD_SIZE_INVALID:{len(rows)}:{BOARD_SIZE}')
    for row in rows:
        for k in row:
            ku=str(k).upper()
            if any(tok in ku for tok in POSTLOCK_KEYS): raise GateError(f'POSTLOCK_FIELD_IN_PRELOCK_BOARD:{k}')
    root=output_dir/f'APEX_MLB_SS_HRS_{execution_id}_501_750_PROSPECTIVE_HOLDOUT'
    root.mkdir(parents=True,exist_ok=True)
    frozen_board=root/'frozen_board.csv'; frozen_receipt=root/'frozen_receipt.json'
    shutil.copyfile(board_path,frozen_board); shutil.copyfile(receipt_path,frozen_receipt)
    manifest={
        'SCHEMA_VERSION':SCHEMA_VERSION,'PATCH_ID':PATCH_ID,'STATUS':'PRELOCK_FROZEN_OUTCOME_PENDING',
        'CAPTURED_AT_UTC':utc_now(),'SPORT':'MLB','MODE':'SS_HRS','FIELD_SIZE':field_size,'EXECUTION_ID':str(execution_id),
        'CERTIFICATION_SCOPE':'UNSEEN_PROSPECTIVE_501_750_ONLY','RETROSPECTIVE_CONTROLS_READ_ONLY':sorted(RETRO_READ_ONLY_CONTESTS),
        'RETROSPECTIVE_CONTROLS_CERTIFICATION_ELIGIBLE':False,'EXECUTION_METHOD':'CHUNK_AND_STREAM_ONLY',
        'MC_ITERATIONS':mc,'FAKE_FIELD_ENTRIES':fake,'PHASE2_BUILT_LINEUPS':p2,'SELECTOR_REVIEWED_LINEUPS':reviewed,
        'PLAYER_POOL_SHA256':sha256_file(player_pool),'ENGINE_SOURCE_SHA256':sha256_file(engine_source),
        'CANDIDATE_DB_PATH':str(candidate_db.resolve()),'CANDIDATE_DB_SHA256':sha256_file(candidate_db),
        'FINAL_BOARD_PATH':str(frozen_board),'FINAL_BOARD_SHA256':sha256_file(frozen_board),'RECEIPT_SHA256':sha256_file(frozen_receipt),
        'EXACT_ENTERED_RANK1_REQUIRED':True,'SCORE_RANK1_WITHOUT_EXACT_FIELD_MATCH_COUNTS_AS_WINNER':False,
        'POSTLOCK_SELECTOR_MUTATION_ALLOWED':False,'PRODUCTION_SELECTOR_MUTATION_ALLOWED':False,
    }
    mp=root/'prelock_manifest.json'; atomic_json(mp,manifest)
    return {'PATCH_ID':PATCH_ID,'STATUS':'PASS','PRELOCK_MANIFEST_PATH':str(mp),'PRELOCK_MANIFEST_SHA256':sha256_file(mp),'HOLDOUT_STATUS':manifest['STATUS']}

def _standings_rows(path:Path)->list[dict]:
    if path.suffix.lower()=='.zip':
        with zipfile.ZipFile(path) as z:
            names=[x for x in z.namelist() if x.lower().endswith('.csv')]
            if len(names)!=1: raise GateError(f'STANDINGS_ZIP_CSV_COUNT:{len(names)}')
            import io
            with z.open(names[0]) as f:
                return [dict(r) for r in csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig',newline=''))]
    with path.open('r',encoding='utf-8-sig',newline='') as f:return [dict(r) for r in csv.DictReader(f)]

def _contest_id(path:Path)->str:
    m=re.search(r'(\d{8,})',path.name); return m.group(1) if m else 'UNKNOWN'

def evaluate(*,manifest_path:Path,standings_path:Path,observed_at_utc:str|None=None)->dict:
    if not manifest_path.exists() or not standings_path.exists(): raise GateError('EVALUATION_INPUT_MISSING')
    m=json.loads(manifest_path.read_text(encoding='utf-8'))
    captured=datetime.fromisoformat(str(m['CAPTURED_AT_UTC']).replace('Z','+00:00'))
    observed=datetime.fromisoformat(observed_at_utc.replace('Z','+00:00')) if observed_at_utc else datetime.now(timezone.utc)
    if observed<=captured: raise GateError('OUTCOME_TIMESTAMP_NOT_AFTER_PRELOCK_FREEZE')
    if sha256_file(Path(m['CANDIDATE_DB_PATH']))!=m['CANDIDATE_DB_SHA256']: raise GateError('CANDIDATE_DB_HASH_DRIFT')
    board=_read_board(Path(m['FINAL_BOARD_PATH'])); board_sets=[_row_players(x) for x in board]
    rows=_standings_rows(standings_path)
    entries=[]; player_fpts={}
    for r in rows:
        if r.get('Player') and r.get('FPTS') not in (None,''):
            try: player_fpts[canon_name(r['Player'])]=float(r['FPTS'])
            except: pass
        if r.get('Lineup'):
            try: rank=int(float(str(r.get('Rank','')).replace(',','')))
            except: continue
            try: pts=float(r.get('Points',0) or 0)
            except: pts=0.0
            s=lineup_set(r['Lineup'])
            if len(s)==3: entries.append((rank,pts,s))
    if not entries: raise GateError('NO_STANDINGS_ENTRY_ROWS')
    best_rank=min(x[0] for x in entries); winners={x[2] for x in entries if x[0]==best_rank}
    exact_hits=[i+1 for i,s in enumerate(board_sets) if s in winners]
    points=[x[1] for x in entries]
    board_eval=[]
    for i,s in enumerate(board_sets):
        exact_ranks=[x[0] for x in entries if x[2]==s]
        score=sum(player_fpts.get(p,0.0) for p in s)
        score_rank=1+sum(1 for q in points if q>score)
        board_eval.append({'BOARD_RANK':i+1,'PLAYERS':list(s),'EXACT_FIELD_MATCH':bool(exact_ranks),'EXACT_FIELD_BEST_RANK':min(exact_ranks) if exact_ranks else None,'REALIZED_HR_SCORE':score,'SCORE_RANK':score_rank})
    best_score_rank=min(x['SCORE_RANK'] for x in board_eval)
    top01_cut=max(1,math.ceil(len(entries)*0.001))
    cid=_contest_id(standings_path); retro=cid in RETRO_READ_ONLY_CONTESTS
    winner_capture=bool(exact_hits)
    if retro: decision='RETROSPECTIVE_READ_ONLY_NOT_CERTIFYING'
    elif winner_capture: decision='CANDIDATE_ADVANCES'
    elif best_score_rank<=top01_cut: decision='RESEARCH_ONLY_TOP01_NO_EXACT_WINNER'
    else: decision='REPAIR_REQUIRED'
    out={
        'SCHEMA_VERSION':SCHEMA_VERSION,'PATCH_ID':PATCH_ID,'STATUS':'PASS','CONTEST_ID':cid,'FIELD_ROWS':len(entries),
        'RETROSPECTIVE_READ_ONLY':retro,'CERTIFICATION_ELIGIBLE':not retro,'EXACT_ENTERED_WINNER_CAPTURE':winner_capture,
        'WINNER_BOARD_RANKS':exact_hits,'BEST_SCORE_RANK':best_score_rank,'TOP_0_1_CUTOFF_RANK':top01_cut,
        'SCORE_RANK1_WITHOUT_EXACT_FIELD_MATCH_COUNTS_AS_WINNER':False,'DECISION':decision,'BOARD_EVALUATION':board_eval,
        'PRELOCK_MANIFEST_SHA256':sha256_file(manifest_path),'OUTCOME_SHA256':sha256_file(standings_path),'OUTCOME_OBSERVED_AT_UTC':observed.isoformat(),
    }
    ep=manifest_path.parent/'postlock_evaluation.json'; atomic_json(ep,out); return out

def main()->int:
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    f=sub.add_parser('freeze');
    for x in ('receipt','candidate-db','board','player-pool','engine-source','output-dir'): f.add_argument('--'+x,required=True)
    f.add_argument('--field-size',type=int,required=True); f.add_argument('--execution-id',required=True)
    e=sub.add_parser('evaluate'); e.add_argument('--manifest',required=True); e.add_argument('--standings',required=True); e.add_argument('--observed-at-utc')
    a=ap.parse_args()
    try:
        if a.cmd=='freeze':
            out=freeze(receipt_path=Path(a.receipt),candidate_db=Path(a.candidate_db),board_path=Path(a.board),player_pool=Path(a.player_pool),field_size=a.field_size,execution_id=a.execution_id,engine_source=Path(a.engine_source),output_dir=Path(a.output_dir))
        else: out=evaluate(manifest_path=Path(a.manifest),standings_path=Path(a.standings),observed_at_utc=a.observed_at_utc)
        print(json.dumps(out,sort_keys=True)); return 0
    except Exception as exc:
        print(json.dumps({'PATCH_ID':PATCH_ID,'STATUS':'FAIL','FAILURE_CODE':f'{type(exc).__name__}:{exc}'},sort_keys=True)); return 1
if __name__=='__main__': raise SystemExit(main())
