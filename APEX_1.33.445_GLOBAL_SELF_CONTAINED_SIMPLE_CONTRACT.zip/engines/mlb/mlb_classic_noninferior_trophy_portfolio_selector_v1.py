from __future__ import annotations

from dataclasses import dataclass
from typing import Hashable, Mapping, Sequence
import hashlib
import json
import math

import numpy as np

import mlb_advisor_tail_selector_v1 as advisor
import mlb_classic_historical_consensus_selector_v1 as historical

PATCH_ID = "MLB_CLASSIC_NONINFERIOR_TROPHY_PORTFOLIO_SELECTOR_v1"
SELECTOR_MODE = "TOP_0_1_NONINFERIOR_TROPHY_FRONTIER_MARGINAL_COVERAGE"
PRIMARY_OBJECTIVE = "TOP_0_1_PERCENT_BOARD_CAPTURE"
WEIGHTED_METRIC_SUM_USED = False
HARD_PLAYER_EXPOSURE_CAP_USED = False
HARD_FAMILY_QUOTAS_USED = False
HARD_PITCHER_PAIR_QUOTAS_USED = False
HARD_SALARY_BIAS_USED = False
POSTLOCK_RESULTS_USED_BY_SELECTOR = False
PLAYER_NAMES_USED_BY_SELECTOR = False
TEAM_NAMES_USED_BY_SELECTOR = False
OPAQUE_STRUCTURAL_IDENTITY_ONLY = True


class NoninferiorTrophySelectorIntegrityError(RuntimeError):
    pass


PROHIBITED_METRIC_NAMES = frozenset({
    "PLAYER", "PLAYER_NAME", "NAME", "RAW_PROJECTION", "PROJECTION",
    "ACTUAL_FPTS", "POSTLOCK_FPTS", "CONTEST_RANK", "REALIZED_RESULT",
    "ACTUAL_SCORE", "ACTUAL_POINTS", "WINNER", "PERFECT", "SALARY_SCORE",
})


@dataclass(frozen=True)
class StructuralIdentity:
    """Opaque pre-lock redundancy identity for one candidate.

    Keys may encode structural equality but must not encode a preference for any
    named player/team. Player tokens are used only for pairwise overlap.
    """

    lineup_id: str
    players: tuple[Hashable, ...]
    macro_spine_key: Hashable
    pitcher_pair_key: Hashable
    stack_key: Hashable
    family_key: Hashable
    salary_geometry_key: Hashable


@dataclass(frozen=True)
class PortfolioSelection:
    positions: np.ndarray
    baseline_order: np.ndarray
    quality_tier: np.ndarray
    primary_delta: float
    lcb_delta: float
    frontier_size: int
    selected_tier_counts: tuple[tuple[int, int], ...]
    unique_macro_spines: int
    unique_pitcher_pairs: int
    unique_stack_keys: int
    unique_families: int
    unique_salary_geometries: int
    max_pairwise_player_overlap: int


def _metric(metrics: Mapping[str, np.ndarray], name: str, n: int, default: float = 0.0) -> np.ndarray:
    if name.upper() in PROHIBITED_METRIC_NAMES:
        raise NoninferiorTrophySelectorIntegrityError(f"PROHIBITED_SELECTOR_METRIC:{name}")
    if name not in metrics:
        return np.full(n, default, dtype=np.float64)
    arr = np.asarray(metrics[name], dtype=np.float64)
    if arr.ndim != 1 or len(arr) != n:
        raise NoninferiorTrophySelectorIntegrityError(f"BAD_SELECTOR_METRIC_SHAPE:{name}:{arr.shape}:{n}")
    if not np.all(np.isfinite(arr)):
        raise NoninferiorTrophySelectorIntegrityError(f"NONFINITE_SELECTOR_METRIC:{name}")
    return arr


def _field_tie_width(context: advisor.ContextProfile) -> float:
    base = max(float(context.primary_tie_width), np.finfo(np.float64).eps)
    if int(context.field_size) <= 300:
        return base
    if int(context.field_size) <= 3000:
        return min(0.0005, base * 2.0)
    return min(0.0005, base * 2.5)


def _noninferiority_deltas(primary: np.ndarray, context: advisor.ContextProfile) -> tuple[float, float]:
    """Return bounded material-loss tolerances for the Top-0.1 frontier.

    Uncertainty is not treated as an asset. The material tolerance is determined
    from field context, simulation resolution, and a capped fraction of the best
    observed Top-0.1 rate. Finite-sample uncertainty is handled separately by the
    conservative LCB gate; noisier rows therefore become *less* likely to share the
    elite tier rather than receiving a wider corridor.
    """
    if len(primary) == 0:
        return 0.0, 0.0
    n_trials = max(1, int(context.trials))
    width = _field_tie_width(context)
    best = max(0.0, float(np.max(primary)))
    resolution = 1.0 / float(n_trials)
    relative_material = 0.10 * best
    primary_delta = max(4.0 * width, 2.0 * resolution, min(0.0004, max(0.00015, relative_material)))
    primary_delta = min(primary_delta, 0.0004)
    # LCB must stay within the same material-loss tolerance. A lower-trial/noisier
    # candidate receives no uncertainty bonus.
    lcb_delta = primary_delta
    return float(primary_delta), float(lcb_delta)


def quality_tiers(
    metrics: Mapping[str, np.ndarray],
    *,
    context: advisor.ContextProfile,
) -> tuple[np.ndarray, float, float]:
    if "top01_rate" not in metrics:
        raise NoninferiorTrophySelectorIntegrityError("MISSING_SELECTOR_METRIC:top01_rate")
    n = len(np.asarray(metrics["top01_rate"]))
    primary = _metric(metrics, "top01_rate", n)
    lcb = _metric(metrics, "top01_lcb", n)
    primary_delta, lcb_delta = _noninferiority_deltas(primary, context)
    if n == 0:
        return np.empty(0, dtype=np.int64), primary_delta, lcb_delta
    best_primary = float(np.max(primary))
    anchor_idx = int(np.lexsort((np.arange(n, dtype=np.int64), -lcb, -primary))[0])
    best_lcb = float(lcb[anchor_idx])
    p_tier = np.floor(np.maximum(0.0, best_primary - primary) / max(primary_delta, np.finfo(float).eps) + 1e-12).astype(np.int64)
    l_tier = np.floor(np.maximum(0.0, best_lcb - lcb) / max(lcb_delta, np.finfo(float).eps) + 1e-12).astype(np.int64)
    # A candidate is in an elite tier only if neither its rate nor its conservative
    # lower bound is materially behind. This prevents a noisy novelty route from
    # receiving diversity credit it did not earn.
    return np.maximum(p_tier, l_tier), primary_delta, lcb_delta


def _stable_id_key(value: str) -> tuple[int, str]:
    s = str(value)
    # L000123 style IDs sort naturally by numeric suffix while arbitrary IDs still
    # have deterministic lexical behavior.
    digits = "".join(ch for ch in s if ch.isdigit())
    return (int(digits) if digits else 2**63 - 1, s)


def _max_overlap(candidate: StructuralIdentity, selected: Sequence[StructuralIdentity]) -> int:
    if not selected:
        return 0
    c = set(candidate.players)
    return max(len(c.intersection(s.players)) for s in selected)


def _validate_structures(structures: Sequence[StructuralIdentity], n: int) -> None:
    if len(structures) != n:
        raise NoninferiorTrophySelectorIntegrityError(f"STRUCTURE_COUNT_MISMATCH:{len(structures)}:{n}")
    ids = [str(s.lineup_id) for s in structures]
    if len(set(ids)) != len(ids):
        raise NoninferiorTrophySelectorIntegrityError("DUPLICATE_STRUCTURAL_LINEUP_ID")
    for s in structures:
        if len(s.players) != len(set(s.players)):
            raise NoninferiorTrophySelectorIntegrityError(f"DUPLICATE_PLAYER_TOKEN:{s.lineup_id}")


def select_portfolio(
    metrics: Mapping[str, np.ndarray],
    structures: Sequence[StructuralIdentity],
    *,
    context: advisor.ContextProfile,
    board_size: int,
) -> PortfolioSelection:
    """Select a Top-0.1 trophy board without hard diversity quotas.

    1) Historical Top-0.1 selector defines the deterministic quality ordering.
    2) MC-aware non-inferiority tiers define where structural diversification is
       allowed to act.
    3) Inside a tier, marginal structural coverage resolves near-ties.
    4) Tiers are exhausted in order, so novelty can never rescue a materially
       weaker trophy-probability path.
    """
    if board_size <= 0:
        raise NoninferiorTrophySelectorIntegrityError("BOARD_SIZE_MUST_BE_POSITIVE")
    if "top01_rate" not in metrics:
        raise NoninferiorTrophySelectorIntegrityError("MISSING_SELECTOR_METRIC:top01_rate")
    for key in metrics:
        if str(key).upper() in PROHIBITED_METRIC_NAMES:
            raise NoninferiorTrophySelectorIntegrityError(f"PROHIBITED_SELECTOR_METRIC:{key}")
    n = len(np.asarray(metrics["top01_rate"]))
    if n < board_size:
        raise NoninferiorTrophySelectorIntegrityError(f"INSUFFICIENT_SELECTOR_ROWS:{n}:{board_size}")
    _validate_structures(structures, n)

    baseline = historical.ranking_order(metrics, context=context)
    if len(baseline) != n or len(set(map(int, baseline))) != n:
        raise NoninferiorTrophySelectorIntegrityError("BASELINE_ORDER_INVALID")
    base_rank = np.empty(n, dtype=np.int64)
    base_rank[baseline] = np.arange(n, dtype=np.int64)
    tiers, primary_delta, lcb_delta = quality_tiers(metrics, context=context)
    leverage = _metric(metrics, "leverage", n)
    chalk_fade = _metric(metrics, "chalk_failure_fade_edge", n)
    primary = _metric(metrics, "top01_rate", n)
    lcb = _metric(metrics, "top01_lcb", n)
    p99 = _metric(metrics, "p99", n)
    cvar99 = _metric(metrics, "cvar99", n)

    selected_idx: list[int] = []
    selected_structures: list[StructuralIdentity] = []
    remaining = set(range(n))
    selected_tier_counts: list[tuple[int, int]] = []

    for tier in sorted(set(int(x) for x in tiers)):
        tier_pool = [i for i in remaining if int(tiers[i]) == tier]
        tier_selected = 0
        while tier_pool and len(selected_idx) < board_size:
            if not selected_idx:
                # Preserve the strongest historical trophy candidate as the board
                # anchor. Structural coverage only acts after an elite anchor exists.
                i = min(tier_pool, key=lambda j: (int(base_rank[j]), _stable_id_key(structures[j].lineup_id)))
            else:
                used_macro = {s.macro_spine_key for s in selected_structures}
                used_pair = {s.pitcher_pair_key for s in selected_structures}
                used_stack = {s.stack_key for s in selected_structures}
                used_family = {s.family_key for s in selected_structures}
                used_salary_geom = {s.salary_geometry_key for s in selected_structures}

                def marginal_key(j: int) -> tuple:
                    s = structures[j]
                    # Lexicographic, not weighted: structural route novelty first
                    # only because all rows here have already earned the same
                    # non-inferiority tier. MC quality then resolves equal coverage.
                    return (
                        -(1 if s.macro_spine_key not in used_macro else 0),
                        -(1 if s.pitcher_pair_key not in used_pair else 0),
                        -(1 if s.stack_key not in used_stack else 0),
                        -(1 if s.family_key not in used_family else 0),
                        -(1 if s.salary_geometry_key not in used_salary_geom else 0),
                        _max_overlap(s, selected_structures),
                        -float(lcb[j]),
                        -float(primary[j]),
                        -float(cvar99[j]),
                        -float(p99[j]),
                        -float(leverage[j]),
                        -float(chalk_fade[j]),
                        int(base_rank[j]),
                        _stable_id_key(s.lineup_id),
                    )

                i = min(tier_pool, key=marginal_key)
            selected_idx.append(int(i))
            selected_structures.append(structures[i])
            remaining.remove(i)
            tier_pool.remove(i)
            tier_selected += 1
        if tier_selected:
            selected_tier_counts.append((tier, tier_selected))
        if len(selected_idx) >= board_size:
            break

    if len(selected_idx) != board_size:
        raise NoninferiorTrophySelectorIntegrityError(f"PORTFOLIO_SELECTION_INCOMPLETE:{len(selected_idx)}:{board_size}")

    max_overlap = 0
    for a in range(len(selected_structures)):
        sa = set(selected_structures[a].players)
        for b in range(a):
            max_overlap = max(max_overlap, len(sa.intersection(selected_structures[b].players)))

    return PortfolioSelection(
        positions=np.asarray(selected_idx, dtype=np.int64),
        baseline_order=np.asarray(baseline, dtype=np.int64),
        quality_tier=np.asarray(tiers, dtype=np.int64),
        primary_delta=primary_delta,
        lcb_delta=lcb_delta,
        frontier_size=int(np.sum(tiers == 0)),
        selected_tier_counts=tuple(selected_tier_counts),
        unique_macro_spines=len({s.macro_spine_key for s in selected_structures}),
        unique_pitcher_pairs=len({s.pitcher_pair_key for s in selected_structures}),
        unique_stack_keys=len({s.stack_key for s in selected_structures}),
        unique_families=len({s.family_key for s in selected_structures}),
        unique_salary_geometries=len({s.salary_geometry_key for s in selected_structures}),
        max_pairwise_player_overlap=int(max_overlap),
    )


def selector_receipt(selection: PortfolioSelection, context: advisor.ContextProfile, candidate_count: int) -> dict[str, object]:
    payload: dict[str, object] = {
        "PATCH_ID": PATCH_ID,
        "SELECTOR_MODE": SELECTOR_MODE,
        "SELECTOR_PRIMARY_OBJECTIVE": PRIMARY_OBJECTIVE,
        "SELECTOR_PRIMARY_METRIC": "MC_TOP_0_1_RATE",
        "NONINFERIORITY_RULE": "MC_AWARE_BOUNDED_TOP01_AND_LCB_QUALITY_TIERS",
        "PRIMARY_NONINFERIORITY_DELTA": float(selection.primary_delta),
        "LCB_NONINFERIORITY_DELTA": float(selection.lcb_delta),
        "ELITE_FRONTIER_SIZE": int(selection.frontier_size),
        "SELECTED_TIER_COUNTS": [[int(k), int(v)] for k, v in selection.selected_tier_counts],
        "PORTFOLIO_RULE": "LEXICOGRAPHIC_MARGINAL_STRUCTURAL_COVERAGE_WITHIN_NONINFERIOR_TIER",
        "STRUCTURAL_COVERAGE_ORDER": [
            "MACRO_SPINE_NOVELTY",
            "PITCHER_PAIR_NOVELTY",
            "STACK_ROUTE_NOVELTY",
            "STRUCTURE_FAMILY_NOVELTY",
            "SALARY_GEOMETRY_NOVELTY",
            "LOWER_PLAYER_OVERLAP",
            "PRELOCK_MC_QUALITY",
            "BASELINE_SELECTOR_ORDER",
        ],
        "UNIQUE_MACRO_SPINES_SELECTED": int(selection.unique_macro_spines),
        "UNIQUE_PITCHER_PAIRS_SELECTED": int(selection.unique_pitcher_pairs),
        "UNIQUE_STACK_KEYS_SELECTED": int(selection.unique_stack_keys),
        "UNIQUE_STRUCTURE_FAMILIES_SELECTED": int(selection.unique_families),
        "UNIQUE_SALARY_GEOMETRIES_SELECTED": int(selection.unique_salary_geometries),
        "MAX_PAIRWISE_PLAYER_OVERLAP": int(selection.max_pairwise_player_overlap),
        "SELECTOR_WEIGHTED_METRIC_SUM_USED": WEIGHTED_METRIC_SUM_USED,
        "HARD_PLAYER_EXPOSURE_CAP_USED": HARD_PLAYER_EXPOSURE_CAP_USED,
        "HARD_FAMILY_QUOTAS_USED": HARD_FAMILY_QUOTAS_USED,
        "HARD_PITCHER_PAIR_QUOTAS_USED": HARD_PITCHER_PAIR_QUOTAS_USED,
        "HARD_SALARY_BIAS_USED": HARD_SALARY_BIAS_USED,
        "OPAQUE_STRUCTURAL_IDENTITY_ONLY": OPAQUE_STRUCTURAL_IDENTITY_ONLY,
        "RAW_PROJECTIONS_USED_BY_SELECTOR": False,
        "POSTLOCK_RESULTS_USED_BY_SELECTOR": POSTLOCK_RESULTS_USED_BY_SELECTOR,
        "PLAYER_NAMES_USED_BY_SELECTOR": PLAYER_NAMES_USED_BY_SELECTOR,
        "TEAM_NAMES_USED_BY_SELECTOR": TEAM_NAMES_USED_BY_SELECTOR,
        "SELECTOR_REVIEWED_LINEUPS": int(candidate_count),
        "FIELD_SLATE_CONTEXT": context.as_dict(),
    }
    payload["SELECTOR_PLAN_SHA256"] = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return payload
