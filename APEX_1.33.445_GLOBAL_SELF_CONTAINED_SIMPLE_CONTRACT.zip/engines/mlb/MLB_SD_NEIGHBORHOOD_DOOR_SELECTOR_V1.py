from __future__ import annotations
import numpy as np
import pandas as pd
from pathlib import Path
import sys
_COMMON = str(Path(__file__).resolve().parents[1] / 'common')
if _COMMON not in sys.path: sys.path.insert(0, _COMMON)
from apex_execution_path_primacy_v2 import percentile_rank_numpy, stable_desc_rank

PATCH_ID='MLB_SD_NEIGHBORHOOD_DOOR_SELECTOR_V1'
STATUS='ACTIVE_PRODUCTION'
ARCHITECTURE='NEIGHBORHOOD_ADMISSION_THEN_LOCAL_DOOR_SELECTION'


def _pct(v):
    return percentile_rank_numpy(v)


def select_frozen_legal_universe(pool:pd.DataFrame, legal:pd.DataFrame, base_det_score:np.ndarray)->pd.DataFrame:
    """Two-stage pre-lock selector over a frozen legal universe.

    Stage 1 admits structural neighborhoods. Stage 2 ranks doors only inside
    admitted neighborhoods, then interleaves neighborhood representatives so
    one global score cannot erase a live trophy neighborhood.
    """
    x=legal.copy().reset_index(drop=True)
    ids=x[['CPT_ID','U1_ID','U2_ID','U3_ID','U4_ID','U5_ID']].to_numpy(int)
    teams=pool['TEAM'].astype(str).to_numpy()
    starter=pool['_IS_STARTER'].astype(bool).to_numpy()
    rp=pool['_IS_RP'].astype(bool).to_numpy()
    own=pool['_OWN'].to_numpy(float)
    n=len(x)
    if n==0: return x

    cpt=ids[:,0]
    cpt_team=teams[cpt]
    same=(teams[ids]==cpt_team[:,None]).sum(1)
    opp=6-same
    sp_count=starter[ids].sum(1)
    rp_count=rp[ids].sum(1)
    cpt_role=np.where(starter[cpt],'SP',np.where(rp[cpt],'RP','HITTER'))
    role_code=np.array([f'{int(a)}-{int(b)}|{r}|DSP{int(s>=2)}|RP{int(q)}' for a,b,r,s,q in zip(same,opp,cpt_role,sp_count,rp_count)],object)
    cpt_key=np.array([str(v) for v in cpt],object)
    neighborhood=np.char.add(np.char.add(cpt_key,'|'),role_code.astype(str))

    base=np.asarray(base_det_score,float)
    base_pct=_pct(base)
    salary_pct=_pct(x['SALARY'].to_numpy(float))
    ownprod=np.prod(np.clip(own[ids]/100.0,1e-8,1.0),axis=1)
    unique_pct=_pct(-ownprod)  # derived ownership only; never raw provider RST

    # Stage 1: score neighborhoods by their strongest root plus local depth.
    codes,inv=np.unique(neighborhood,return_inverse=True)
    ngh_score=np.zeros(len(codes),float)
    ngh_best_rank=np.zeros(len(codes),int)
    base_rank=stable_desc_rank(base)
    for g in range(len(codes)):
        z=np.flatnonzero(inv==g)
        vals=np.sort(base_pct[z])[::-1]
        ngh_score[g]=float(vals[0] + .22*np.mean(vals[:min(3,len(vals))]) + .08*np.mean(vals[:min(8,len(vals))]))
        ngh_best_rank[g]=int(base_rank[z].min())
    gorder=np.lexsort((codes,-ngh_score))
    g_rank=np.empty(len(codes),int); g_rank[gorder]=np.arange(1,len(codes)+1)

    # Admit all neighborhoods with a strong global root plus enough top structural neighborhoods.
    root_cut=max(50,int(np.ceil(n*.0025)))
    breadth=max(12,min(len(codes),32))
    admitted=(ngh_best_rank<=root_cut) | (g_rank<=breadth)

    # Stage 2: door score is local-first. Global base remains a component, not the architecture.
    local_pct=np.zeros(n,float)
    for g in range(len(codes)):
        z=np.flatnonzero(inv==g)
        local_pct[z]=_pct(base[z])
    door=.62*local_pct + .20*base_pct + .10*salary_pct + .08*unique_pct

    # Interleave best doors from admitted neighborhoods before taking second/third doors.
    selected=[]; depth=0
    admitted_groups=[int(g) for g in gorder if admitted[g]]
    group_orders={g: np.flatnonzero(inv==g)[np.argsort(-door[np.flatnonzero(inv==g)],kind='mergesort')] for g in admitted_groups}
    remaining=set(range(n))
    while remaining and admitted_groups:
        progressed=False
        for g in admitted_groups:
            go=group_orders[g]
            if depth < len(go):
                i=int(go[depth])
                if i in remaining:
                    selected.append(i); remaining.remove(i); progressed=True
        if not progressed: break
        depth+=1
        if len(selected)>=min(n,500): break
    if remaining:
        rest=np.array(sorted(remaining),int)
        rest=rest[np.lexsort((rest,-door[rest],-base[rest]))]
        selected.extend(rest.tolist())

    out=x.iloc[np.asarray(selected,int)].copy().reset_index(drop=True)
    src=np.asarray(selected,int)
    out['BASE_DET_SCORE']=base[src]
    out['BASE_DET_PCT']=base_pct[src]
    out['NEIGHBORHOOD_KEY']=neighborhood[src]
    out['NEIGHBORHOOD_SCORE']=ngh_score[inv[src]]
    out['NEIGHBORHOOD_RANK']=g_rank[inv[src]]
    out['NEIGHBORHOOD_ADMITTED']=admitted[inv[src]]
    out['LOCAL_DOOR_SCORE']=door[src]
    out['SELECTOR_RANK']=np.arange(1,len(out)+1)
    out['SELECTOR_PATCH_ID']=PATCH_ID
    return out
