from __future__ import annotations
import numpy as np

PATCH_ID='MLB_SD_PHASE1_PHASE3_SIGNAL_FAITHFUL_BOARD_RANKER_v2'
RANKER_ID='PHASE1_PHASE3_SIGNAL_PRIMARY_FAMILY_TIEBREAK_v2'


def pct_rank(x):
    x=np.asarray(x,dtype=float)
    if len(x)<=1:return np.ones(len(x),dtype=float)
    order=np.argsort(x,kind='mergesort');out=np.empty(len(x),dtype=float);out[order]=np.linspace(0.,1.,len(x));return out


def wilson_lcb(p,n,z=1.0):
    p=np.clip(np.asarray(p,dtype=float),0.,1.);n=max(int(n),1);den=1.+z*z/n;center=p+z*z/(2*n);adj=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n));return np.clip((center-adj)/den,0.,1.)


def contest_finish_components(cands,metrics,meta,trials=50000):
    cands=np.asarray(cands,dtype=np.int32)
    top10=np.asarray(metrics['top10'],float);top01=np.asarray(metrics['top01'],float);win=np.asarray(metrics['win'],float);p99=np.asarray(metrics['p99'],float);p95=np.asarray(metrics['p95'],float);mean=np.asarray(metrics['mean'],float)
    top10_lcb=wilson_lcb(top10,trials,1.0);top01_lcb=wilson_lcb(top01,trials,1.0);win_lcb=wilson_lcb(win,trials,1.0)
    # Phase 1 / Phase 3 simulation signal is the primary decision surface.
    signal=(.30*pct_rank(top10_lcb)+.24*pct_rank(top01_lcb)+.17*pct_rank(win_lcb)+.11*pct_rank(p99)+.06*pct_rank(p95)+.03*pct_rank(mean)+.05*pct_rank(-meta['own_log'][cands])+.04*pct_rank(meta['salary_release'][cands]))
    # Predeclared structural families are permitted only as a bounded tie-break.
    family=(meta['lane_sp_cpt_51'][cands].astype(float)+meta['lane_sp_cpt_51_speed'][cands].astype(float)+meta['lane_sp_cpt_control_51'][cands].astype(float)+meta['lane_sp_cpt_control_51_speed'][cands].astype(float)+meta['lane_hitter_cpt_speed_low_spend_42'][cands].astype(float)+meta['lane_hitter_cpt_speed_low_spend_42_release'][cands].astype(float)+meta['lane_hitter_cpt_speed_low_spend_42_control'][cands].astype(float)+meta['lane_hitter_cpt_speed_low_spend_42_counter'][cands].astype(float)+meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][cands].astype(float)+meta['lane_hitter_cpt_same_team_sp_control'][cands].astype(float)+meta['lane_hitter_cpt_favorite_51_sp_opp_punt'][cands].astype(float)+meta['lane_hitter_cpt_favorite_42_sp_rp'][cands].astype(float)+meta['lane_hitter_cpt_favorite_51_sp_contact_core'][cands].astype(float)+meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'][cands].astype(float)+meta['lane_sp_cpt_control_51_speed_top2_core'][cands].astype(float)+meta['lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release'][cands].astype(float))
    family=np.clip(family/6.0,0.,1.)
    return {'score':signal,'signal_score':signal,'family_tiebreak':family,'top10_lcb':top10_lcb,'top01_lcb':top01_lcb,'win_lcb':win_lcb}


def rank_selected_board(selected,cands,components,meta,tie_eps=0.005):
    selected=np.asarray(selected,dtype=np.int32);cands=np.asarray(cands,dtype=np.int32);pos={int(g):i for i,g in enumerate(cands)}
    sig=np.asarray(components.get('signal_score',components['score']),float);fam=np.asarray(components.get('family_tiebreak',np.zeros(len(cands))),float)
    def key(g):
        j=pos[int(g)]
        # Bucket only near-ties; family never moves a materially weaker signal above a stronger one.
        bucket=round(float(sig[j])/tie_eps) if tie_eps>0 else float(sig[j])
        return (-bucket,-float(sig[j]),-float(fam[j]),int(g))
    ordered=np.asarray(sorted(map(int,selected),key=key),dtype=np.int32)
    scores=np.asarray([sig[pos[int(g)]] for g in ordered],float)
    reasons=[]
    for k,g in enumerate(ordered):
        j=pos[int(g)]
        if k and abs(scores[k-1]-scores[k])<=tie_eps and fam[j]>0: reasons.append('PHASE1_PHASE3_SIGNAL_TIE_FAMILY_TIEBREAK')
        else: reasons.append('PHASE1_PHASE3_SIGNAL_PRIMARY')
    return ordered,scores,reasons


def phase1_signal_ordering_ok(board_scores,tol=1e-12):
    s=np.asarray(board_scores,float)
    return bool(np.all(s[:-1]+tol>=s[1:]))
