from __future__ import annotations

"""Pre-lock MLB Showdown NORMAL_MARKET failure-species feature extractor.

Research-only diagnostic module. It does not route, rank, select, promote, or mutate
production state. Features are computed from the frozen Phase-2 candidate surface.
"""

import argparse
import collections
import hashlib
import importlib.util
import itertools
import json
import math
import os
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

import numpy as np
import pandas as pd

FEATURE_EXTRACTOR_ID = "MLB_SD_NORMAL_MARKET_FAILURE_SPECIES_FEATURE_EXTRACTOR_v1"
FEATURE_SCHEMA_VERSION = "1.0"
PRODUCTION_ROUTING_AUTHORITY = False


def _safe_ratio(num: float, den: float, default: float = 0.0) -> float:
    return float(num / den) if den and np.isfinite(den) else float(default)


def _weighted_mean(values: Sequence[float], weights: Sequence[float]) -> float:
    v = np.asarray(values, dtype=float)
    w = np.asarray(weights, dtype=float)
    good = np.isfinite(v) & np.isfinite(w) & (w >= 0)
    if not np.any(good):
        return 0.0
    v, w = v[good], w[good]
    s = float(w.sum())
    return float(np.average(v, weights=w)) if s > 0 else float(v.mean())


def normalized_concentration_index(probabilities: Sequence[float], top_n: int = 10) -> Dict[str, float]:
    p = np.clip(np.asarray(probabilities, dtype=float), 0.0, None)
    n = len(p)
    if n == 0:
        return {"mass_share": 0.0, "index": 0.0, "population_share": 0.0}
    k = min(max(1, int(top_n)), n)
    total = float(p.sum())
    top = float(np.sort(p)[-k:].sum())
    mass_share = _safe_ratio(top, total) if total > 0 else k / n
    population_share = k / n
    return {
        "mass_share": float(mass_share),
        "population_share": float(population_share),
        "index": _safe_ratio(mass_share, population_share),
    }


def effective_count(masses: Sequence[float]) -> float:
    x = np.clip(np.asarray(masses, dtype=float), 0.0, None)
    s = float(x.sum())
    if s <= 0:
        return 0.0
    q = x / s
    hhi = float(np.sum(q * q))
    return _safe_ratio(1.0, hhi)


def normalized_entropy(masses: Sequence[float]) -> float:
    x = np.clip(np.asarray(masses, dtype=float), 0.0, None)
    positive = x[x > 0]
    if len(positive) <= 1:
        return 0.0
    q = positive / positive.sum()
    h = float(-np.sum(q * np.log(q)))
    return _safe_ratio(h, math.log(len(positive)))


def family_residual_metrics(probabilities: Sequence[float], tail_cap: int = 10) -> Dict[str, float]:
    p = np.sort(np.clip(np.asarray(probabilities, dtype=float), 0.0, None))[::-1]
    if len(p) == 0 or p[0] <= 0:
        return {
            "primary": 0.0,
            "trailing_mean": 0.0,
            "residual_mass_density": 0.0,
            "residual_mass_ratio": 0.0,
            "fragmentation_proxy": 0.0,
        }
    tail = p[1:min(len(p), max(2, int(tail_cap) + 1))]
    trailing_mean = float(tail.mean()) if len(tail) else 0.0
    residual_sum = float(p[1:].sum())
    primary = float(p[0])
    return {
        "primary": primary,
        "trailing_mean": trailing_mean,
        "residual_mass_density": _safe_ratio(trailing_mean, primary),
        "residual_mass_ratio": _safe_ratio(residual_sum, primary),
        "fragmentation_proxy": _safe_ratio(float(p.sum()), primary),
    }


def roster_overlap_stats(rosters: Sequence[Sequence[int]]) -> Dict[str, float]:
    rr = [set(map(int, r)) for r in rosters]
    if len(rr) < 2:
        return {
            "mean_overlap_fraction": 0.0,
            "mean_jaccard": 0.0,
            "max_shared_players": 0.0,
            "share_pairs_ge4_shared": 0.0,
        }
    overlap, jaccard, ge4 = [], [], []
    max_shared = 0
    for a, b in itertools.combinations(rr, 2):
        shared = len(a & b)
        max_shared = max(max_shared, shared)
        overlap.append(shared / max(1, len(a)))
        jaccard.append(shared / max(1, len(a | b)))
        ge4.append(shared >= 4)
    return {
        "mean_overlap_fraction": float(np.mean(overlap)),
        "mean_jaccard": float(np.mean(jaccard)),
        "max_shared_players": float(max_shared),
        "share_pairs_ge4_shared": float(np.mean(ge4)),
    }


def _load_runtime(state_root: Path, field_size: int, trials: int, seed: int, module_tag: str):
    eng = state_root / "engines" / "mlb"
    common = state_root / "engines" / "common"
    sys.path.insert(0, str(eng))
    sys.path.insert(0, str(common))
    os.environ["APEX_FIELD_SIZE"] = str(field_size)
    os.environ["APEX_EXECUTION_MODE"] = "DIAGNOSTIC"
    os.environ["APEX_PHASE1_TRIALS"] = str(trials)
    os.environ["APEX_BASE_TRIALS"] = str(trials)
    os.environ["APEX_EXTRA_TRIALS"] = "0"
    os.environ["APEX_SEED"] = str(seed)
    path = eng / "mlb_showdown_raw_pool_runtime_v1_7.py"
    spec = importlib.util.spec_from_file_location(f"apex_sd_feature_{module_tag}", path)
    rt = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(rt)
    return rt, path


def _branch_and_sp_count(lineup_row: np.ndarray, team: np.ndarray, is_sp: np.ndarray) -> Tuple[str, int]:
    ids = [int(x) for x in lineup_row[:6]]
    counts = collections.Counter(str(team[q]) for q in ids)
    split = sorted(counts.values(), reverse=True)
    branch = f"{split[0]}-{split[1]}" if len(split) >= 2 else f"{split[0]}-0"
    sp_count = int(sum(bool(is_sp[q]) for q in ids))
    return branch, sp_count


def _build_pair_families(
    born: np.ndarray,
    L: np.ndarray,
    team: np.ndarray,
    is_sp: np.ndarray,
    is_rp: np.ndarray,
) -> Mapping[Tuple[Tuple[int, ...], str, int, int], List[int]]:
    fam: Dict[Tuple[Tuple[int, ...], str, int, int], List[int]] = collections.defaultdict(list)
    for local_idx, global_idx in enumerate(born):
        row = L[int(global_idx), :6]
        spt = tuple(sorted(int(q) for q in row if is_sp[int(q)]))
        by_team: Dict[str, List[int]] = collections.defaultdict(list)
        for q in row:
            q = int(q)
            if not is_sp[q] and not is_rp[q]:
                by_team[str(team[q])].append(q)
        for tm, ids in by_team.items():
            for a, b in itertools.combinations(sorted(ids), 2):
                fam[(spt, tm, a, b)].append(local_idx)
    return fam


def _top_family_records(
    fam: Mapping[Tuple[Tuple[int, ...], str, int, int], List[int]],
    top01: np.ndarray,
    win: np.ndarray,
    L: np.ndarray,
    born: np.ndarray,
    names: np.ndarray,
    top_k: int = 5,
) -> List[dict]:
    rows = []
    for key, local_ids in fam.items():
        if len(local_ids) < 3:
            continue
        idx = np.asarray(local_ids, dtype=int)
        t = np.asarray(top01[idx], dtype=float)
        w = np.asarray(win[idx], dtype=float)
        residual = family_residual_metrics(t)
        cpt_mass: Dict[int, float] = collections.defaultdict(float)
        for li, mass in zip(idx, t):
            global_idx = int(born[int(li)])
            cpt = int(L[global_idx, 0])
            cpt_mass[cpt] += float(mass)
        family_mass = float(t.sum())
        rows.append(
            {
                "key": key,
                "members": int(len(idx)),
                "top01_mass": family_mass,
                "win_mass": float(w.sum()),
                **residual,
                "cpt_effective_count": effective_count(list(cpt_mass.values())),
                "cpt_entropy_norm": normalized_entropy(list(cpt_mass.values())),
                "cpt_distinct": int(len(cpt_mass)),
                "cpt_ids": sorted(int(x) for x in cpt_mass),
                "cpt_names": [str(names[x]) for x in sorted(cpt_mass)],
            }
        )
    rows.sort(key=lambda x: (x["top01_mass"], x["win_mass"], x["members"]), reverse=True)
    return rows[: max(1, int(top_k))]


def _structural_lane_metrics(
    born: np.ndarray,
    L: np.ndarray,
    team: np.ndarray,
    is_sp: np.ndarray,
    weights: np.ndarray,
) -> dict:
    lane_mass: Dict[str, float] = collections.defaultdict(float)
    branch_mass: Dict[str, float] = collections.defaultdict(float)
    sp_mass: Dict[str, float] = collections.defaultdict(float)
    for local_idx, global_idx in enumerate(born):
        branch, sp_count = _branch_and_sp_count(L[int(global_idx)], team, is_sp)
        mass = float(max(0.0, weights[local_idx]))
        lane_mass[f"{branch}|SP{sp_count}"] += mass
        branch_mass[branch] += mass
        sp_mass[f"SP{sp_count}"] += mass

    def hhi(d: Mapping[str, float]) -> float:
        v = np.asarray(list(d.values()), dtype=float)
        s = float(v.sum())
        if s <= 0:
            return 0.0
        q = v / s
        return float(np.sum(q * q))

    return {
        "joint_hhi": hhi(lane_mass),
        "branch_hhi": hhi(branch_mass),
        "sp_count_hhi": hhi(sp_mass),
        "joint_mass": dict(sorted(lane_mass.items())),
        "branch_mass": dict(sorted(branch_mass.items())),
        "sp_count_mass": dict(sorted(sp_mass.items())),
    }


def extract_prelock_features(
    pool_path: str | Path,
    field_size: int,
    *,
    label: str,
    state_root: str | Path,
    trials: int = 10000,
    seed: int | None = None,
) -> dict:
    pool_path = Path(pool_path)
    state_root = Path(state_root)
    if seed is None:
        seed = int((field_size * 10000 + 17) % (2**32 - 1))
    rt, runtime_path = _load_runtime(state_root, field_size, trials, seed, label.replace("-", "_"))

    raw = pd.read_csv(pool_path)
    pool = rt.active_pool(raw)
    players = rt.build_players(pool)
    names = np.asarray([p["name"] for p in players], dtype=object)
    team = np.asarray([p["team"] for p in players], dtype=object)
    is_sp = np.asarray([bool(p["is_sp"]) for p in players], dtype=bool)
    is_rp = np.asarray([bool(p["is_rp"]) for p in players], dtype=bool)

    p1 = rt.simulate_players(players, trials, rt.SEED)
    rt.qualify_relief_paths(players, p1)
    L = rt.enumerate_lineups(players)
    meta = rt.lineup_meta(L, players)
    ctx1 = rt.build_phase1_context(meta)
    proxy = rt.proxy_metrics(p1, L)
    born, comp, ls, lanes = rt.phase2_birth(proxy, meta)
    fake_n = int(np.ceil(field_size * 3.4))
    field = rt.choose_fake(meta, fake_n, rt.SEED + 91)
    ctx = rt.merge_phase2_context(ctx1, rt._LAST_FIELD_RECEIPT)
    high_dual = bool(rt._high_dual_sp_cpt_market(ctx))
    route = "HIGH_DUAL_SP" if high_dual else "NORMAL_MARKET"

    receipt = {
        "FEATURE_EXTRACTOR_ID": FEATURE_EXTRACTOR_ID,
        "FEATURE_SCHEMA_VERSION": FEATURE_SCHEMA_VERSION,
        "PRODUCTION_ROUTING_AUTHORITY": PRODUCTION_ROUTING_AUTHORITY,
        "label": label,
        "field_size": int(field_size),
        "route": route,
        "pool_sha256": hashlib.sha256(pool_path.read_bytes()).hexdigest(),
        "runtime_source_sha256": hashlib.sha256(runtime_path.read_bytes()).hexdigest(),
        "active_pool": int(len(players)),
        "legal_lineups": int(len(L)),
        "phase2_born": int(len(born)),
        "trials": int(trials),
        "field_receipt": rt._LAST_FIELD_RECEIPT,
        "status": "BYPASS_HIGH_DUAL_SP" if high_dual else "FEATURES_EXTRACTED",
    }
    if high_dual:
        return receipt
    if len(born) == 0:
        receipt["status"] = "NO_PHASE2_BORN"
        return receipt

    top01_n = max(1, int(np.ceil(len(field) * .001)))
    top10_n = max(1, min(len(field), int(np.ceil(10 * len(field) / max(field_size, 1)))))
    mx, kth, k10 = rt.field_thresholds(p1, L, field, top01_n, top10_n)
    bm = rt.score_lineups(p1, L, mx, kth, k10, born)
    bm["trials"] = np.full(len(born), trials, dtype=float)

    baseline, _, _, _ = rt.select_milp(born, bm, meta, size=10, slate_context=ctx)
    baseline_rosters = [L[int(g), :6] for g in baseline]
    redundancy = roster_overlap_stats(baseline_rosters)

    concentration = normalized_concentration_index(bm["win"], top_n=10)
    fam = _build_pair_families(born, L, team, is_sp, is_rp)
    top_families = _top_family_records(fam, np.asarray(bm["top01"]), np.asarray(bm["win"]), L, born, names, top_k=5)
    family_weights = [x["top01_mass"] for x in top_families]
    residual_density = _weighted_mean([x["residual_mass_density"] for x in top_families], family_weights)
    residual_ratio = _weighted_mean([x["residual_mass_ratio"] for x in top_families], family_weights)
    fragmentation_proxy = _weighted_mean([x["fragmentation_proxy"] for x in top_families], family_weights)
    cpt_effective = _weighted_mean([x["cpt_effective_count"] for x in top_families], family_weights)
    cpt_entropy = _weighted_mean([x["cpt_entropy_norm"] for x in top_families], family_weights)
    lane = _structural_lane_metrics(born, L, team, is_sp, np.asarray(bm["top01"], dtype=float))

    receipt["features"] = {
        "FAMILY_RESIDUAL_MASS_DENSITY": float(residual_density),
        "EXACT_LINE_CONCENTRATION_INDEX": float(concentration["index"]),
        "RECIPROCAL_CPT_BREADTH": float(cpt_effective),
        "STRUCTURAL_LANE_CONCENTRATION": float(lane["joint_hhi"]),
        "BASELINE_PORTFOLIO_REDUNDANCY": float(redundancy["mean_overlap_fraction"]),
    }
    receipt["supporting_metrics"] = {
        "family_residual_mass_ratio": float(residual_ratio),
        "family_fragmentation_proxy": float(fragmentation_proxy),
        "exact_line_top10_win_mass_share": float(concentration["mass_share"]),
        "exact_line_top10_population_share": float(concentration["population_share"]),
        "reciprocal_cpt_entropy_norm": float(cpt_entropy),
        "structural_lane_branch_hhi": float(lane["branch_hhi"]),
        "structural_lane_sp_count_hhi": float(lane["sp_count_hhi"]),
        **redundancy,
    }
    receipt["top5_family_diagnostics"] = [
        {k: v for k, v in row.items() if k != "key"} for row in top_families
    ]
    receipt["structural_lane_mass"] = {
        "joint": lane["joint_mass"],
        "branch": lane["branch_mass"],
        "sp_count": lane["sp_count_mass"],
    }
    receipt["baseline_lineup_indices"] = [int(x) for x in baseline]
    return receipt


def _run_manifest(manifest_path: Path, state_root: Path, trials: int, output_dir: Path) -> List[dict]:
    payload = json.loads(manifest_path.read_text())
    records = payload.get("records", payload if isinstance(payload, list) else [])
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for rec in records:
        label = str(rec["label"])
        try:
            out = extract_prelock_features(
                rec["pool"], int(rec["field_size"]), label=label,
                state_root=state_root, trials=int(rec.get("trials", trials)),
                seed=rec.get("seed"),
            )
        except Exception as exc:
            out = {
                "FEATURE_EXTRACTOR_ID": FEATURE_EXTRACTOR_ID,
                "label": label,
                "field_size": int(rec["field_size"]),
                "status": "EXTRACTION_ERROR",
                "error_type": type(exc).__name__,
                "error": str(exc),
            }
        (output_dir / f"{label}_features.json").write_text(json.dumps(out, indent=2))
        flat = {
            "FEATURE_EXTRACTOR_ID": out.get("FEATURE_EXTRACTOR_ID", FEATURE_EXTRACTOR_ID),
            "FEATURE_SCHEMA_VERSION": out.get("FEATURE_SCHEMA_VERSION", FEATURE_SCHEMA_VERSION),
            "PRODUCTION_ROUTING_AUTHORITY": out.get("PRODUCTION_ROUTING_AUTHORITY", PRODUCTION_ROUTING_AUTHORITY),
            "MATRIX_AUTHORITY": "RESEARCH_SCOUT_ONLY",
            "label": label,
            "field_size": out.get("field_size"),
            "route": out.get("route"),
            "status": out.get("status"),
            "trials": out.get("trials", rec.get("trials", trials)),
            "pool_sha256": out.get("pool_sha256"),
            "runtime_source_sha256": out.get("runtime_source_sha256"),
            "active_pool": out.get("active_pool"),
            "legal_lineups": out.get("legal_lineups"),
            "phase2_born": out.get("phase2_born"),
            "error_type": out.get("error_type"),
            "error": out.get("error"),
        }
        flat.update(out.get("features", {}))
        flat.update({f"support__{k}": v for k, v in out.get("supporting_metrics", {}).items() if np.isscalar(v)})
        rows.append(flat)
    pd.DataFrame(rows).to_csv(output_dir / "MLB_SD_NORMAL_MARKET_FAILURE_SPECIES_FEATURE_MATRIX_v1.csv", index=False)
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--state-root", default=str(Path(__file__).resolve().parents[3]))
    ap.add_argument("--trials", type=int, default=10000)
    ap.add_argument("--manifest")
    ap.add_argument("--output-dir", default="/mnt/data/mlb_sd_failure_species_features_v1")
    ap.add_argument("--label")
    ap.add_argument("--pool")
    ap.add_argument("--field-size", type=int)
    args = ap.parse_args()
    state_root = Path(args.state_root)
    if args.manifest:
        rows = _run_manifest(Path(args.manifest), state_root, args.trials, Path(args.output_dir))
        print(json.dumps({"extractor": FEATURE_EXTRACTOR_ID, "records": len(rows), "output_dir": args.output_dir}, indent=2))
        return
    if not args.label or not args.pool or not args.field_size:
        ap.error("single mode requires --label --pool --field-size")
    try:
        out = extract_prelock_features(args.pool, args.field_size, label=args.label, state_root=state_root, trials=args.trials)
    except Exception as exc:
        out = {
            "FEATURE_EXTRACTOR_ID": FEATURE_EXTRACTOR_ID,
            "FEATURE_SCHEMA_VERSION": FEATURE_SCHEMA_VERSION,
            "PRODUCTION_ROUTING_AUTHORITY": PRODUCTION_ROUTING_AUTHORITY,
            "label": args.label,
            "field_size": int(args.field_size),
            "trials": int(args.trials),
            "status": "EXTRACTION_ERROR",
            "error_type": type(exc).__name__,
            "error": str(exc),
        }
    Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    p = Path(args.output_dir) / f"{args.label}_features.json"
    p.write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
