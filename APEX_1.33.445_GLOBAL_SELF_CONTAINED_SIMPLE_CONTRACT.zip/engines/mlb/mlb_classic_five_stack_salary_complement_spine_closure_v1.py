from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

import numpy as np

PATCH_ID = 'MLB_CLASSIC_FIVE_STACK_SALARY_COMPLEMENT_SPINE_CLOSURE_v1'
DOCTRINE_ID = PATCH_ID
SALARY_BUCKET = 100
TAIL_DEPTH_PER_BUCKET = 96
LEVERAGE_DEPTH_PER_BUCKET = 96
MAX_ROWS_PER_SPINE = 3


@dataclass(frozen=True)
class Shell:
    pattern: str
    pitcher_pair: tuple[int, int]
    companions: tuple[int, int, int]
    salary: int
    tail_score: float
    ownership_product: float
    ownership_sum: float

    @property
    def key(self) -> tuple[Any, ...]:
        return (self.pattern, self.pitcher_pair, self.companions)


def _primary_five_stack(
    hitter_ids: Sequence[int],
    hitter_team_by_idx: Mapping[int, str],
) -> tuple[str, tuple[int, ...]] | None:
    counts = Counter(str(hitter_team_by_idx[int(i)]) for i in hitter_ids)
    if not counts or max(counts.values()) != 5:
        return None
    primary = min(team for team, count in counts.items() if count == 5)
    spine = tuple(sorted(int(i) for i in hitter_ids if str(hitter_team_by_idx[int(i)]) == primary))
    return primary, spine


def represented_five_stack_spines(
    phase2: Sequence[Mapping[str, Any]],
    hitter_team_by_idx: Mapping[int, str],
) -> set[tuple[str, tuple[int, ...]]]:
    represented: set[tuple[str, tuple[int, ...]]] = set()
    for row in phase2:
        root = _primary_five_stack(tuple(int(i) for i in row['lineup'][2:]), hitter_team_by_idx)
        if root is not None:
            represented.add(root)
    return represented


def position_feasible_five_stack_spines(
    combo_pool: Mapping[tuple[str, int], Sequence[tuple[tuple[int, ...], int, float]]],
    combo_assignment_code: Callable[[tuple[int, ...]], int],
) -> dict[tuple[str, tuple[int, ...]], int]:
    feasible: dict[tuple[str, tuple[int, ...]], int] = {}
    for (team, size), rows in sorted(combo_pool.items(), key=lambda item: item[0]):
        if int(size) != 5:
            continue
        for combo, salary, _ in rows:
            spine = tuple(sorted(int(i) for i in combo))
            if int(combo_assignment_code(spine)) == 0:
                continue
            feasible[(str(team), spine)] = int(salary)
    return feasible


def build_shell_frontier(
    phase2: Sequence[Mapping[str, Any]],
    *,
    by_idx: Mapping[int, Mapping[str, Any]],
    hitter_team_by_idx: Mapping[int, str],
    player_mean: np.ndarray,
    player_p95: np.ndarray,
    player_p99: np.ndarray,
    tail_depth_per_bucket: int = TAIL_DEPTH_PER_BUCKET,
    leverage_depth_per_bucket: int = LEVERAGE_DEPTH_PER_BUCKET,
) -> dict[int, tuple[Shell, ...]]:
    # A shell is a pre-lock 5-1-1-1 companion structure already demonstrated legal
    # somewhere in Phase 2: pitcher pair + three singleton hitters. Recombining a
    # missing five-stack spine with these shells creates no post-lock feature and no
    # new projection model; it only closes a salary/position reachability gap.
    unique: dict[tuple[Any, ...], Shell] = {}
    for row in phase2:
        pattern = str(row.get('pattern'))
        if pattern not in {'5-3', '5-2-1', '5-1-1-1'}:
            continue
        hitters = tuple(int(i) for i in row['lineup'][2:])
        root = _primary_five_stack(hitters, hitter_team_by_idx)
        if root is None:
            continue
        primary, spine = root
        companions = tuple(sorted(int(i) for i in hitters if str(hitter_team_by_idx[int(i)]) != primary))
        if len(companions) != 3:
            continue
        companion_counts = Counter(str(hitter_team_by_idx[int(i)]) for i in companions)
        expected_pattern = '5-' + '-'.join(str(x) for x in sorted(companion_counts.values(), reverse=True))
        if expected_pattern != pattern:
            continue
        pp = tuple(sorted(int(i) for i in row['pitcher_pair']))
        shell_ids = tuple((*pp, *companions))
        salary = int(sum(int(by_idx[int(i)]['salary']) for i in shell_ids))
        tail_score = float(
            (0.10 * player_mean[list(shell_ids)] + 0.28 * player_p95[list(shell_ids)] + 0.62 * player_p99[list(shell_ids)]).sum()
            + sum(float(by_idx[int(i)].get('strategy_leverage', 0.0)) for i in shell_ids) * 0.55
            + sum(1.0 for i in shell_ids if bool(by_idx[int(i)].get('strategy_salary_unlock', False))) * 0.40
        )
        own = np.asarray([max(float(by_idx[int(i)].get('ownership_pct', 0.05)), 0.05) / 100.0 for i in shell_ids], dtype=np.float64)
        shell = Shell(
            pattern=pattern,
            pitcher_pair=pp,
            companions=companions,
            salary=salary,
            tail_score=tail_score,
            ownership_product=float(np.prod(own)),
            ownership_sum=float(sum(float(by_idx[int(i)].get('ownership_pct', 0.0)) for i in shell_ids)),
        )
        prior = unique.get(shell.key)
        if prior is None or (shell.tail_score, shell.salary, tuple(-i for i in shell.companions)) > (prior.tail_score, prior.salary, tuple(-i for i in prior.companions)):
            unique[shell.key] = shell

    buckets: dict[int, list[Shell]] = defaultdict(list)
    for shell in unique.values():
        buckets[int(shell.salary // SALARY_BUCKET)].append(shell)

    frontier: dict[int, tuple[Shell, ...]] = {}
    for bucket, rows in buckets.items():
        tail = sorted(rows, key=lambda s: (-s.tail_score, -s.salary, s.pattern, s.pitcher_pair, s.companions))[: max(1, int(tail_depth_per_bucket))]
        leverage = sorted(rows, key=lambda s: (s.ownership_product, s.ownership_sum, -s.tail_score, -s.salary, s.pattern, s.pitcher_pair, s.companions))[: max(1, int(leverage_depth_per_bucket))]
        merged = {s.key: s for s in (*tail, *leverage)}
        frontier[bucket] = tuple(sorted(merged.values(), key=lambda s: (-s.tail_score, s.ownership_product, -s.salary, s.pattern, s.pitcher_pair, s.companions)))
    return frontier


def apply_closure(
    *,
    phase2: list[dict[str, Any]],
    combo_pool: Mapping[tuple[str, int], Sequence[tuple[tuple[int, ...], int, float]]],
    combo_assignment_code: Callable[[tuple[int, ...]], int],
    by_idx: Mapping[int, Mapping[str, Any]],
    hitter_team_by_idx: Mapping[int, str],
    player_mean: np.ndarray,
    player_p95: np.ndarray,
    player_p99: np.ndarray,
    salary_min: int,
    salary_max: int,
    materialize_candidate: Callable[..., dict[str, Any] | None],
    max_rows_per_spine: int = MAX_ROWS_PER_SPINE,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    represented_before = represented_five_stack_spines(phase2, hitter_team_by_idx)
    feasible = position_feasible_five_stack_spines(combo_pool, combo_assignment_code)
    missing = tuple(sorted(set(feasible) - represented_before, key=lambda key: (key[0], key[1])))
    frontier = build_shell_frontier(
        phase2,
        by_idx=by_idx,
        hitter_team_by_idx=hitter_team_by_idx,
        player_mean=player_mean,
        player_p95=player_p95,
        player_p99=player_p99,
    )

    added: list[dict[str, Any]] = []
    resolved_spines: set[tuple[str, tuple[int, ...]]] = set()
    objective_counts = Counter()
    attempts = 0
    candidate_shells_scanned = 0

    for team, spine in missing:
        stack_salary = int(feasible[(team, spine)])
        min_shell = int(salary_min - stack_salary)
        max_shell = int(salary_max - stack_salary)
        if max_shell < 0:
            continue
        candidate_map: dict[tuple[Any, ...], Shell] = {}
        for bucket in range(max(0, min_shell // SALARY_BUCKET - 1), max_shell // SALARY_BUCKET + 2):
            for shell in frontier.get(bucket, ()):
                if min_shell <= int(shell.salary) <= max_shell:
                    candidate_map[shell.key] = shell
        candidates = tuple(candidate_map.values())
        candidate_shells_scanned += len(candidates)
        if not candidates:
            continue

        orders = (
            ('TAIL', sorted(candidates, key=lambda s: (-s.tail_score, s.ownership_product, -s.salary, s.pattern, s.pitcher_pair, s.companions))),
            ('LEVERAGE', sorted(candidates, key=lambda s: (s.ownership_product, s.ownership_sum, -s.tail_score, -s.salary, s.pattern, s.pitcher_pair, s.companions))),
            ('SALARY_GEOMETRY', sorted(candidates, key=lambda s: (abs(int(salary_max) - int(stack_salary + s.salary)), -s.tail_score, s.ownership_product, s.pattern, s.pitcher_pair, s.companions))),
        )
        used_shells: set[tuple[Any, ...]] = set()
        spine_rows = 0
        for objective, ordered in orders:
            if spine_rows >= max(1, int(max_rows_per_spine)):
                break
            for shell in ordered:
                if shell.key in used_shells:
                    continue
                attempts += 1
                child_hitters = tuple(sorted((*spine, *shell.companions)))
                row = materialize_candidate(
                    child_hitters,
                    shell.pitcher_pair,
                    shell.pattern,
                    '5_X_FAMILIES',
                    birth_source=PATCH_ID,
                    root_spine_key=('FIVE_STACK_SPINE', team, spine),
                    closure_transition=f'MISSING_5_STACK_SPINE->{shell.pattern}_SALARY_COMPLEMENT',
                )
                used_shells.add(shell.key)
                if row is None:
                    continue
                row['spine_closure_objective'] = objective
                row['spine_closure_shell_salary'] = int(shell.salary)
                row['spine_closure_shell_pattern'] = shell.pattern
                added.append(row)
                resolved_spines.add((team, spine))
                objective_counts[objective] += 1
                spine_rows += 1
                break

    # Rare fallback: if the shell frontier cannot complete a position-feasible spine,
    # deterministically exhaust salary-bounded 5-X companion geometry using pitcher
    # pairs already present in Phase 2 and the raw pre-lock team combo pools. This is
    # only reached for residual spines, so the search stays bounded while eliminating
    # root reachability dependence on whichever 5-X shells happened to be born first.
    fallback_attempts = 0
    fallback_rows = 0
    fallback_pattern_attempts = Counter()
    pair_set = {tuple(sorted(int(i) for i in row['pitcher_pair'])) for row in phase2}
    pair_order = sorted(
        pair_set,
        key=lambda pp: (
            -float((0.15 * player_mean[list(pp)] + 0.30 * player_p95[list(pp)] + 0.55 * player_p99[list(pp)]).sum()),
            -sum(int(by_idx[int(i)]['salary']) for i in pp),
            pp,
        ),
    )
    hitter_teams = tuple(sorted({str(team) for team, size in combo_pool if int(size) == 1}))

    def fallback_materialize(
        *,
        team: str,
        spine: tuple[int, ...],
        pp: tuple[int, int],
        companions: tuple[int, int, int],
        pattern: str,
    ) -> dict[str, Any] | None:
        nonlocal fallback_attempts
        fallback_attempts += 1
        fallback_pattern_attempts[pattern] += 1
        return materialize_candidate(
            tuple(sorted((*spine, *companions))),
            pp,
            pattern,
            '5_X_FAMILIES',
            birth_source=PATCH_ID,
            root_spine_key=('FIVE_STACK_SPINE', team, spine),
            closure_transition=f'MISSING_5_STACK_SPINE->{pattern}_SALARY_BOUNDED_FALLBACK',
        )

    unresolved_pre_fallback = tuple(sorted(set(feasible) - (represented_before | resolved_spines), key=lambda key: (key[0], key[1])))
    for team, spine in unresolved_pre_fallback:
        stack_salary = int(feasible[(team, spine)])
        found_row: dict[str, Any] | None = None
        found_pattern: str | None = None
        found_shell_salary: int | None = None

        for pp in pair_order:
            pp_salary = sum(int(by_idx[int(i)]['salary']) for i in pp)
            blocked = {str(by_idx[int(i)]['opp']) for i in pp}
            if team in blocked:
                continue
            min_companion = int(salary_min - stack_salary - pp_salary)
            max_companion = int(salary_max - stack_salary - pp_salary)
            if max_companion < 0:
                continue

            # 5-3: one three-hitter companion team.
            for team3 in hitter_teams:
                if team3 == team or team3 in blocked:
                    continue
                for combo3, combo_salary, _combo_score in combo_pool.get((team3, 3), ()):
                    if int(combo_salary) < min_companion or int(combo_salary) > max_companion:
                        continue
                    row = fallback_materialize(
                        team=team,
                        spine=spine,
                        pp=pp,
                        companions=tuple(int(i) for i in combo3),
                        pattern='5-3',
                    )
                    if row is not None:
                        found_row, found_pattern, found_shell_salary = row, '5-3', int(combo_salary) + pp_salary
                        break
                if found_row is not None:
                    break
            if found_row is not None:
                break

            # 5-2-1: two hitters from one team plus one from a distinct team.
            for team2 in hitter_teams:
                if team2 == team or team2 in blocked:
                    continue
                for combo2, salary2, _score2 in combo_pool.get((team2, 2), ()):
                    rem_lo = int(min_companion - int(salary2))
                    rem_hi = int(max_companion - int(salary2))
                    if rem_hi < 0:
                        continue
                    for team1 in hitter_teams:
                        if team1 in {team, team2} or team1 in blocked:
                            continue
                        for combo1, salary1, _score1 in combo_pool.get((team1, 1), ()):
                            if int(salary1) < rem_lo or int(salary1) > rem_hi:
                                continue
                            companions = tuple(sorted((*tuple(int(i) for i in combo2), int(combo1[0]))))
                            row = fallback_materialize(
                                team=team,
                                spine=spine,
                                pp=pp,
                                companions=companions,
                                pattern='5-2-1',
                            )
                            if row is not None:
                                found_row, found_pattern, found_shell_salary = row, '5-2-1', int(salary2) + int(salary1) + pp_salary
                                break
                        if found_row is not None:
                            break
                    if found_row is not None:
                        break
                if found_row is not None:
                    break
            if found_row is not None:
                break

            # 5-1-1-1: one hitter from each of three distinct companion teams.
            candidate_teams = [t for t in hitter_teams if t != team and t not in blocked]
            for ta_i in range(len(candidate_teams) - 2):
                ta = candidate_teams[ta_i]
                for tb_i in range(ta_i + 1, len(candidate_teams) - 1):
                    tb = candidate_teams[tb_i]
                    for tc_i in range(tb_i + 1, len(candidate_teams)):
                        tc = candidate_teams[tc_i]
                        for combo_a, salary_a, _score_a in combo_pool.get((ta, 1), ()):
                            for combo_b, salary_b, _score_b in combo_pool.get((tb, 1), ()):
                                rem_lo = int(min_companion - int(salary_a) - int(salary_b))
                                rem_hi = int(max_companion - int(salary_a) - int(salary_b))
                                if rem_hi < 0:
                                    continue
                                for combo_c, salary_c, _score_c in combo_pool.get((tc, 1), ()):
                                    if int(salary_c) < rem_lo or int(salary_c) > rem_hi:
                                        continue
                                    companions = tuple(sorted((int(combo_a[0]), int(combo_b[0]), int(combo_c[0]))))
                                    row = fallback_materialize(
                                        team=team,
                                        spine=spine,
                                        pp=pp,
                                        companions=companions,
                                        pattern='5-1-1-1',
                                    )
                                    if row is not None:
                                        found_row = row
                                        found_pattern = '5-1-1-1'
                                        found_shell_salary = int(salary_a) + int(salary_b) + int(salary_c) + pp_salary
                                        break
                                if found_row is not None:
                                    break
                            if found_row is not None:
                                break
                        if found_row is not None:
                            break
                    if found_row is not None:
                        break
                if found_row is not None:
                    break
            if found_row is not None:
                break

        if found_row is not None and found_pattern is not None:
            found_row['spine_closure_objective'] = f'SALARY_BOUNDED_{found_pattern}_FALLBACK'
            found_row['spine_closure_shell_pattern'] = found_pattern
            if found_shell_salary is not None:
                found_row['spine_closure_shell_salary'] = int(found_shell_salary)
            added.append(found_row)
            resolved_spines.add((team, spine))
            objective_counts[f'SALARY_BOUNDED_{found_pattern}_FALLBACK'] += 1
            fallback_rows += 1

    represented_after = represented_before | resolved_spines
    unresolved = tuple(sorted(set(feasible) - represented_after, key=lambda key: (key[0], key[1])))
    receipt = {
        'PATCH_ID': PATCH_ID,
        'STATUS': 'PASS' if len(added) >= len(resolved_spines) else 'FAIL',
        'MODE': 'PRODUCTION_PRELOCK_ADDITIVE_CLOSURE',
        'POSTLOCK_RESULTS_USED': False,
        'PLAYER_OR_TEAM_HARDCODING': False,
        'EXISTING_PHASE2_ROWS_REMOVED': 0,
        'POSITION_FEASIBLE_FIVE_STACK_SPINES': len(feasible),
        'REPRESENTED_FIVE_STACK_SPINES_BEFORE': len(represented_before),
        'MISSING_SPINES_BEFORE': len(missing),
        'SPINES_RESOLVED': len(resolved_spines),
        'UNRESOLVED_SPINES_AFTER': len(unresolved),
        'REPRESENTED_FIVE_STACK_SPINES_AFTER': len(represented_after),
        'ROWS_ADDED': len(added),
        'MAX_ROWS_PER_SPINE': int(max_rows_per_spine),
        'SHELL_SALARY_BUCKET': SALARY_BUCKET,
        'TAIL_DEPTH_PER_BUCKET': TAIL_DEPTH_PER_BUCKET,
        'LEVERAGE_DEPTH_PER_BUCKET': LEVERAGE_DEPTH_PER_BUCKET,
        'SHELL_FRONTIER_BUCKETS': len(frontier),
        'CANDIDATE_SHELLS_SCANNED': int(candidate_shells_scanned),
        'MATERIALIZATION_ATTEMPTS': int(attempts),
        'FALLBACK_MATERIALIZATION_ATTEMPTS': int(fallback_attempts),
        'FALLBACK_ROWS_ADDED': int(fallback_rows),
        'FALLBACK_PATTERN_ATTEMPTS': dict(fallback_pattern_attempts),
        'OBJECTIVE_ROWS': dict(objective_counts),
        'UNRESOLVED_SPINE_SAMPLE': [
            {'TEAM': team, 'SPINE': list(spine), 'STACK_SALARY': int(feasible[(team, spine)])}
            for team, spine in unresolved[:20]
        ],
        'METHODS': [
            'POSITION_FEASIBLE_FIVE_STACK_SPINE_ENUMERATION',
            'PRELOCK_5_X_COMPLETION_SHELL_REUSE',
            'SALARY_BUCKETED_TAIL_FRONTIER',
            'SALARY_BUCKETED_OWNERSHIP_LEVERAGE_FRONTIER',
            'TAIL_LEVERAGE_SALARY_GEOMETRY_THREE_LANE_COMPLETION',
            'SALARY_BOUNDED_5_X_BRANCH_AND_BOUND_FALLBACK',
            'ADDITIVE_ONLY_HASH_DEDUPLICATED_MATERIALIZATION',
        ],
    }
    return added, receipt
