from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from itertools import combinations
from typing import Mapping, Sequence

PATCH_ID = "MLB_CLASSIC_CROSS_PATTERN_RECALL_AND_FULL_REVIEW_v3"
ALLOWED_TRANSITIONS = frozenset({("5-3", "5-2-1"), ("5-2-1", "5-1-1-1")})


@dataclass(frozen=True)
class CrossPatternSwap:
    removed_player_id: int
    added_player_id: int
    parent_pattern: str
    child_pattern: str
    primary_team: str
    secondary_team: str
    added_team: str


@dataclass(frozen=True)
class CrossPatternClosureTelemetry:
    patch_id: str
    parent_5_3_rows: int
    parent_5_2_1_rows: int
    attempts_5_3_to_5_2_1: int
    rows_5_3_to_5_2_1: int
    attempts_5_2_1_to_5_1_1_1: int
    rows_5_2_1_to_5_1_1_1: int
    integrity_failures: int
    generation_seconds: float

    def to_receipt(self) -> dict[str, object]:
        return asdict(self)


def pattern_from_hitters(hitter_ids: Sequence[int], player_team: Mapping[int, str]) -> str:
    counts = sorted(Counter(player_team[int(idx)] for idx in hitter_ids).values(), reverse=True)
    return "-".join(str(int(x)) for x in counts)


def primary_five_stack(
    hitter_ids: Sequence[int],
    player_team: Mapping[int, str],
) -> tuple[str, tuple[int, ...]]:
    groups: dict[str, list[int]] = {}
    for idx in hitter_ids:
        groups.setdefault(player_team[int(idx)], []).append(int(idx))
    five = [(team, tuple(sorted(ids))) for team, ids in groups.items() if len(ids) == 5]
    if len(five) != 1:
        raise ValueError("CROSS_PATTERN_PRIMARY_FIVE_STACK_REQUIRED")
    return five[0]


def spine_key(
    pitcher_pair: Sequence[int],
    hitter_ids: Sequence[int],
    player_team: Mapping[int, str],
) -> tuple[tuple[int, int], str, tuple[int, ...]]:
    team, five = primary_five_stack(hitter_ids, player_team)
    pp = tuple(int(x) for x in pitcher_pair)
    if len(pp) != 2:
        raise ValueError("CROSS_PATTERN_PITCHER_PAIR_REQUIRED")
    return (pp, team, five)


def _groups(hitter_ids: Sequence[int], player_team: Mapping[int, str]) -> dict[str, tuple[int, ...]]:
    grouped: dict[str, list[int]] = {}
    for idx in hitter_ids:
        grouped.setdefault(player_team[int(idx)], []).append(int(idx))
    return {team: tuple(sorted(ids)) for team, ids in grouped.items()}


def swaps_5_3_to_5_2_1(
    hitter_ids: Sequence[int],
    player_team: Mapping[int, str],
    team_to_hitters: Mapping[str, Sequence[int]],
    blocked_teams: Sequence[str] = (),
) -> tuple[CrossPatternSwap, ...]:
    if pattern_from_hitters(hitter_ids, player_team) != "5-3":
        return ()
    groups = _groups(hitter_ids, player_team)
    primary_team = next(team for team, ids in groups.items() if len(ids) == 5)
    secondary_team = next(team for team, ids in groups.items() if len(ids) == 3)
    blocked = set(map(str, blocked_teams))
    current = set(map(int, hitter_ids))
    out: list[CrossPatternSwap] = []
    for removed in groups[secondary_team]:
        for added_team in sorted(team_to_hitters):
            if added_team in {primary_team, secondary_team} or added_team in blocked:
                continue
            for added in sorted(map(int, team_to_hitters[added_team])):
                if added in current:
                    continue
                out.append(CrossPatternSwap(
                    removed_player_id=int(removed),
                    added_player_id=int(added),
                    parent_pattern="5-3",
                    child_pattern="5-2-1",
                    primary_team=primary_team,
                    secondary_team=secondary_team,
                    added_team=added_team,
                ))
    out.sort(key=lambda x: (
        x.primary_team, x.secondary_team, x.added_team,
        x.removed_player_id, x.added_player_id,
    ))
    return tuple(out)


def swaps_5_2_1_to_5_1_1_1(
    hitter_ids: Sequence[int],
    player_team: Mapping[int, str],
    team_to_hitters: Mapping[str, Sequence[int]],
    blocked_teams: Sequence[str] = (),
) -> tuple[CrossPatternSwap, ...]:
    if pattern_from_hitters(hitter_ids, player_team) != "5-2-1":
        return ()
    groups = _groups(hitter_ids, player_team)
    primary_team = next(team for team, ids in groups.items() if len(ids) == 5)
    secondary_team = next(team for team, ids in groups.items() if len(ids) == 2)
    existing_teams = set(groups)
    blocked = set(map(str, blocked_teams))
    current = set(map(int, hitter_ids))
    out: list[CrossPatternSwap] = []
    for removed in groups[secondary_team]:
        for added_team in sorted(team_to_hitters):
            if added_team in existing_teams or added_team in blocked:
                continue
            for added in sorted(map(int, team_to_hitters[added_team])):
                if added in current:
                    continue
                out.append(CrossPatternSwap(
                    removed_player_id=int(removed),
                    added_player_id=int(added),
                    parent_pattern="5-2-1",
                    child_pattern="5-1-1-1",
                    primary_team=primary_team,
                    secondary_team=secondary_team,
                    added_team=added_team,
                ))
    out.sort(key=lambda x: (
        x.primary_team, x.secondary_team, x.added_team,
        x.removed_player_id, x.added_player_id,
    ))
    return tuple(out)


def apply_cross_pattern_swap(hitter_ids: Sequence[int], swap: CrossPatternSwap) -> tuple[int, ...]:
    current = tuple(int(x) for x in hitter_ids)
    if swap.removed_player_id not in current or swap.added_player_id in current:
        raise ValueError("INVALID_CROSS_PATTERN_SWAP")
    child = tuple(sorted(
        swap.added_player_id if idx == swap.removed_player_id else idx
        for idx in current
    ))
    if len(child) != 8 or len(set(child)) != 8:
        raise ValueError("INVALID_CROSS_PATTERN_RESULT")
    return child


def validate_cross_pattern_sibling(
    parent_hitters: Sequence[int],
    child_hitters: Sequence[int],
    player_team: Mapping[int, str],
) -> bool:
    # Exact single-pass equivalent of the original Counter + pattern + group
    # validation. This path is performance critical in production FAST mode.
    parent = tuple(int(x) for x in parent_hitters)
    child = tuple(int(x) for x in child_hitters)
    if len(parent) != 8 or len(child) != 8:
        return False
    parent_set = set(parent)
    child_set = set(child)
    if len(parent_set) != 8 or len(child_set) != 8 or len(parent_set & child_set) != 7:
        return False

    p_counts: dict[str, int] = {}
    c_counts: dict[str, int] = {}
    for idx in parent:
        team = player_team[idx]
        p_counts[team] = p_counts.get(team, 0) + 1
    for idx in child:
        team = player_team[idx]
        c_counts[team] = c_counts.get(team, 0) + 1
    p_pattern = tuple(sorted(p_counts.values(), reverse=True))
    c_pattern = tuple(sorted(c_counts.values(), reverse=True))
    if not ((p_pattern == (5, 3) and c_pattern == (5, 2, 1)) or
            (p_pattern == (5, 2, 1) and c_pattern == (5, 1, 1, 1))):
        return False

    p_team = next((team for team, count in p_counts.items() if count == 5), None)
    c_team = next((team for team, count in c_counts.items() if count == 5), None)
    if p_team is None or c_team is None or p_team != c_team:
        return False
    p_five = tuple(sorted(idx for idx in parent if player_team[idx] == p_team))
    c_five = tuple(sorted(idx for idx in child if player_team[idx] == c_team))
    return p_five == c_five

@dataclass(frozen=True)
class CrossPatternAttemptAudit:
    patch_id: str
    transition: str
    expected_attempts: int
    attempted_attempts: int
    unique_expected_attempts: int
    unique_attempted_attempts: int
    missing_attempts: int
    unexpected_attempts: int
    duplicate_attempts: int
    status: str

    def to_receipt(self) -> dict[str, object]:
        return asdict(self)


def swap_identity(swap: CrossPatternSwap) -> tuple[object, ...]:
    return (
        int(swap.removed_player_id),
        int(swap.added_player_id),
        str(swap.parent_pattern),
        str(swap.child_pattern),
        str(swap.primary_team),
        str(swap.secondary_team),
        str(swap.added_team),
    )


def audit_swap_attempt_completeness(
    expected_attempt_keys: Sequence[tuple[object, ...]],
    attempted_attempt_keys: Sequence[tuple[object, ...]],
    *,
    transition: str,
) -> CrossPatternAttemptAudit:
    """Prove that every deterministic pre-lock swap candidate was attempted once.

    Keys must include a parent-spine identity plus ``swap_identity`` so identical
    player swaps from distinct calibrated parents remain distinct attempts.
    """
    expected = Counter(tuple(x) for x in expected_attempt_keys)
    attempted = Counter(tuple(x) for x in attempted_attempt_keys)
    missing = expected - attempted
    unexpected = attempted - expected
    duplicates = sum(max(0, count - expected.get(key, 0)) for key, count in attempted.items())
    status = 'PASS' if not missing and not unexpected and duplicates == 0 else 'FAIL'
    return CrossPatternAttemptAudit(
        patch_id=PATCH_ID,
        transition=str(transition),
        expected_attempts=sum(expected.values()),
        attempted_attempts=sum(attempted.values()),
        unique_expected_attempts=len(expected),
        unique_attempted_attempts=len(attempted),
        missing_attempts=sum(missing.values()),
        unexpected_attempts=sum(unexpected.values()),
        duplicate_attempts=int(duplicates),
        status=status,
    )

