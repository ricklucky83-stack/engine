from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence
import hashlib
import json

import numpy as np

import mlb_advisor_tail_selector_v1 as advisor

PATCH_ID = "MLB_CLASSIC_HISTORICAL_CONSENSUS_HYBRID_SELECTOR_v1"
SELECTOR_MODE = "TOP_0_1_PRIMARY_CLASSIC_HISTORICAL_CONSENSUS_NEAR_TIE"
PRIMARY_OBJECTIVE = "RECURRING_SAME_WORLD_CHAMPIONSHIP_SYSTEM_CAPTURE_THEN_TOP_0_1"
WEIGHTED_METRIC_SUM_USED = False
HARD_FAMILY_QUOTAS_USED = False
HARD_PITCHER_PAIR_QUOTAS_USED = False
HARD_SALARY_BIAS_USED = False
OWNERSHIP_DECISION_POSITION = "FIELD_SIZE_ADJUSTED_ELITE_EQUIVALENCE_LEVERAGE"
LEVERAGE_DOCTRINE_ID = "APEX_GLOBAL_FIELD_SIZE_ADJUSTED_DUPLICATION_LEVERAGE_VARIANCE_v1"
LEVERAGE_IMPLEMENTATION_ID = "MLB_CLASSIC_FIELD_SIZE_ADJUSTED_DUPLICATION_LEVERAGE_VARIANCE_v1"
CHALK_FAILURE_EDGE_PATCH_ID = "MLB_HITTER_ATTACKABLE_PA_AND_CHALK_FAILURE_EDGE_v1"


class ClassicHistoricalSelectorIntegrityError(RuntimeError):
    pass


PROHIBITED_METRIC_NAMES = frozenset({
    "PLAYER", "PLAYER_NAME", "NAME", "RAW_PROJECTION", "PROJECTION",
    "ACTUAL_FPTS", "POSTLOCK_FPTS", "CONTEST_RANK", "REALIZED_RESULT",
    "ORIGINAL_SELECTOR", "OBJECTIVE", "WEIGHTED_SCORE", "SALARY_SCORE",
})


@dataclass(frozen=True)
class ConsensusDiagnostics:
    anchor_lane: np.ndarray
    field_realism_lane: np.ndarray
    eruption_distributed_lane: np.ndarray
    historical_consensus: np.ndarray


def _metric(metrics: Mapping[str, np.ndarray], name: str, n: int, default: float = 0.0) -> np.ndarray:
    if name.upper() in PROHIBITED_METRIC_NAMES:
        raise ClassicHistoricalSelectorIntegrityError(f"PROHIBITED_SELECTOR_METRIC:{name}")
    if name not in metrics:
        return np.full(n, default, dtype=np.float64)
    arr = np.asarray(metrics[name], dtype=np.float64)
    if arr.ndim != 1 or len(arr) != n:
        raise ClassicHistoricalSelectorIntegrityError(f"BAD_SELECTOR_METRIC_SHAPE:{name}:{arr.shape}:{n}")
    return np.nan_to_num(arr, nan=-np.inf, posinf=np.inf, neginf=-np.inf)


def _pct(arr: np.ndarray) -> np.ndarray:
    """Deterministic [0,1] percentile rank, higher is better."""
    a = np.asarray(arr, dtype=np.float64)
    n = len(a)
    if n <= 1:
        return np.ones(n, dtype=np.float64)
    order = np.argsort(a, kind="mergesort")
    ranks = np.empty(n, dtype=np.float64)
    ranks[order] = np.arange(n, dtype=np.float64)
    # Average equal-value ranks so row order cannot create selector preference.
    vals = a[order]
    start = 0
    while start < n:
        end = start + 1
        while end < n and vals[end] == vals[start]:
            end += 1
        if end - start > 1:
            avg = (start + end - 1) / 2.0
            ranks[order[start:end]] = avg
        start = end
    return ranks / float(n - 1)


def consensus_diagnostics(metrics: Mapping[str, np.ndarray]) -> ConsensusDiagnostics:
    """Build Classic-only historical route strength without a weighted sum.

    Old Classic controls do not support one universal winner template. They support
    coexistence of at least three generic routes: pitcher-anchor shells, correlated
    field-realistic shells, and eruption/distributed shells that may leave salary.
    We therefore score each route by its weakest required percentile and take the
    strongest valid route. No player/team identity, salary preference, projection,
    ownership, or post-lock result enters these route strengths.
    """
    if "top01_rate" not in metrics:
        raise ClassicHistoricalSelectorIntegrityError("MISSING_SELECTOR_METRIC:top01_rate")
    n = len(np.asarray(metrics["top01_rate"]))

    p99_pct = _pct(_metric(metrics, "p99", n))
    cvar99_pct = _pct(_metric(metrics, "cvar99", n))
    corr_pct = _pct(_metric(metrics, "correlation", n))
    anchor = _metric(metrics, "anchor_quality_pct", n)
    secondary = _metric(metrics, "secondary_anchor_pct", n)
    closure = _metric(metrics, "closure_pct", n)

    # Inputs from the Classic runtime are already percentiles. Clamp rather than
    # renormalizing so their meaning is stable across candidate ordering.
    anchor = np.clip(anchor, 0.0, 1.0)
    secondary = np.clip(secondary, 0.0, 1.0)
    closure = np.clip(closure, 0.0, 1.0)

    # Alternate routes are intentionally OR-combined (maximum). A valid salary-void
    # or distributed eruption route must not be erased merely because it lacks an
    # elite pitcher-anchor profile, and vice versa.
    anchor_lane = np.minimum.reduce((anchor, secondary, p99_pct))
    field_realism_lane = np.minimum.reduce((closure, corr_pct, cvar99_pct))
    eruption_distributed_lane = np.minimum.reduce((closure, p99_pct, cvar99_pct))
    historical_consensus = np.maximum.reduce((anchor_lane, field_realism_lane, eruption_distributed_lane))
    return ConsensusDiagnostics(anchor_lane, field_realism_lane, eruption_distributed_lane, historical_consensus)


def ranking_order(
    metrics: Mapping[str, np.ndarray],
    *,
    context: advisor.ContextProfile,
    primary_metric: str = "top01_rate",
    primary_lcb_metric: str = "top01_lcb",
) -> np.ndarray:
    """Top-0.1-primary Classic ordering with historical consensus only in near ties."""
    if primary_metric.upper() in PROHIBITED_METRIC_NAMES:
        raise ClassicHistoricalSelectorIntegrityError(f"PROHIBITED_SELECTOR_METRIC:{primary_metric}")
    if primary_metric not in metrics:
        raise ClassicHistoricalSelectorIntegrityError(f"MISSING_SELECTOR_METRIC:{primary_metric}")
    n = len(np.asarray(metrics[primary_metric]))
    primary = _metric(metrics, primary_metric, n)
    base_width = max(float(context.primary_tie_width), np.finfo(np.float64).eps)
    if int(context.field_size) <= 300:
        leverage_tier = "SMALL"
        width = base_width
    elif int(context.field_size) <= 3000:
        leverage_tier = "MEDIUM"
        width = min(0.0005, base_width * 2.0)
    else:
        leverage_tier = "LARGE"
        width = min(0.0005, base_width * 2.5)
    # Relative gap buckets avoid arbitrary absolute bucket-boundary flips.
    # Bucket 0 is the best-primary equivalence corridor; larger integers are
    # progressively weaker trophy-probability tiers.
    primary_best = float(np.max(primary)) if n else 0.0
    bucket = np.floor(np.maximum(0.0, primary_best - primary) / width + 1e-12)

    top01_lcb = _metric(metrics, primary_lcb_metric, n)
    lcb_best = float(np.max(top01_lcb)) if n else 0.0
    lcb_bucket = np.floor(np.maximum(0.0, lcb_best - top01_lcb) / width + 1e-12)
    win = _metric(metrics, "win_rate", n)
    cvar99 = _metric(metrics, "cvar99", n)
    p99 = _metric(metrics, "p99", n)
    p95 = _metric(metrics, "p95", n)
    corr = _metric(metrics, "correlation", n)
    leverage = _metric(metrics, "leverage", n)
    chalk_fade = _metric(metrics, "chalk_failure_fade_edge", n)
    top1 = _metric(metrics, "top1_rate", n)
    consensus = consensus_diagnostics(metrics).historical_consensus
    same_world_core = _metric(metrics, 'same_world_core_mass', n)
    same_world_half = _metric(metrics, 'same_world_core_half_min', n)
    same_world_strict = _metric(metrics, 'same_world_strict_mass', n)
    same_world_loose = _metric(metrics, 'same_world_loose_mass', n)
    same_world_win = _metric(metrics, 'same_world_win_mass', n)
    same_world_conversion = _metric(metrics, 'same_world_top01_conversion', n)

    # Complete-system same-world recurrence is primary. Standard Top-0.1/Win tail
    # strength remains the fallback when the finite common-world tape contains no
    # recurring full-wheel event. Pairwise correlation is only a late tiebreak.
    # Ceiling/trophy probability establishes eligibility. Duplication leverage is
    # then field-size adjusted inside the elite-equivalence corridor; it is never
    # allowed to rescue a materially weaker Top-0.1 path and never contaminates
    # P99/CVaR99. No weighted objective is formed.
    if leverage_tier == "LARGE":
        tiebreaks = (
            leverage, chalk_fade, lcb_bucket, consensus, win, cvar99, p99, corr, top1, p95, primary
        )
    elif leverage_tier == "MEDIUM":
        tiebreaks = (
            lcb_bucket, leverage, chalk_fade, consensus, win, cvar99, p99, corr, top1, p95, primary
        )
    else:
        tiebreaks = (
            top01_lcb, consensus, win, cvar99, p99, corr, top1, p95, leverage, chalk_fade, primary
        )

    keys: list[np.ndarray] = [np.arange(n, dtype=np.int64)]
    for arr in reversed(tiebreaks):
        keys.append(-np.asarray(arr, dtype=np.float64))
    keys.append(bucket)
    keys.append(-np.asarray(same_world_conversion, dtype=np.float64))
    keys.append(-np.asarray(same_world_loose, dtype=np.float64))
    keys.append(-np.asarray(same_world_strict, dtype=np.float64))
    keys.append(-np.asarray(same_world_win, dtype=np.float64))
    keys.append(-np.asarray(same_world_half, dtype=np.float64))
    keys.append(-np.asarray(same_world_core, dtype=np.float64))
    return np.lexsort(tuple(keys)).astype(np.int64, copy=False)


def ordinal_score(order: Sequence[int], n: int) -> np.ndarray:
    return advisor.ordinal_score(order, n)


def select_ranked_stream(order: Sequence[int], *, board_size: int) -> np.ndarray:
    return advisor.select_ranked_stream(order, board_size=board_size)


def selector_receipt(context: advisor.ContextProfile, candidate_count: int) -> dict[str, object]:
    payload = {
        "PATCH_ID": PATCH_ID,
        "SELECTOR_MODE": SELECTOR_MODE,
        "SELECTOR_PRIMARY_OBJECTIVE": PRIMARY_OBJECTIVE,
        "SELECTOR_PRIMARY_METRIC": "SAME_WORLD_CORE_MASS",
        "SECONDARY_PRIMARY_METRIC": "MC_TOP_0_1_RATE",
        "HISTORICAL_CONSENSUS_SCOPE": "CLASSIC_ONLY_NEAR_TIE",
        "HISTORICAL_ROUTE_LOGIC": [
            "ANCHOR_LANE_MIN(anchor_quality,secondary_anchor,p99_pct)",
            "FIELD_REALISM_LANE_MIN(closure,correlation_pct,cvar99_pct)",
            "ERUPTION_DISTRIBUTED_LANE_MIN(closure,p99_pct,cvar99_pct)",
            "CONSENSUS_MAX_OF_VALID_ROUTES",
        ],
        "OWNERSHIP_DECISION_POSITION": OWNERSHIP_DECISION_POSITION,
        "LEVERAGE_DOCTRINE_ID": LEVERAGE_DOCTRINE_ID,
        "LEVERAGE_IMPLEMENTATION_ID": LEVERAGE_IMPLEMENTATION_ID,
        "MLB_CLASSIC_LEVERAGE_TIER": "SMALL" if int(context.field_size) <= 300 else "MEDIUM" if int(context.field_size) <= 3000 else "LARGE",
        "SELECTOR_WEIGHTED_METRIC_SUM_USED": WEIGHTED_METRIC_SUM_USED,
        "HARD_FAMILY_QUOTAS_USED": HARD_FAMILY_QUOTAS_USED,
        "HARD_PITCHER_PAIR_QUOTAS_USED": HARD_PITCHER_PAIR_QUOTAS_USED,
        "HARD_SALARY_BIAS_USED": HARD_SALARY_BIAS_USED,
        "SELECTOR_REVIEWED_LINEUPS": int(candidate_count),
        "FIELD_SLATE_CONTEXT": context.as_dict(),
        "RAW_PROJECTIONS_USED_BY_SELECTOR": False,
        "POSTLOCK_RESULTS_USED_BY_SELECTOR": False,
        "PLAYER_NAMES_USED_BY_SELECTOR": False,
        "TEAM_NAMES_USED_BY_SELECTOR": False,
    }
    payload["SELECTOR_PLAN_SHA256"] = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return payload
