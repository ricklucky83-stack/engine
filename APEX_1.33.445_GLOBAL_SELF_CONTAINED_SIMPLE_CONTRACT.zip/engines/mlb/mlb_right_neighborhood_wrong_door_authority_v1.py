from __future__ import annotations
from collections import defaultdict
import numpy as np

PATCH_ID = "MLB_RIGHT_NEIGHBORHOOD_WRONG_DOOR_AUTHORITY_v1"
STATUS = "ACTIVE_PRODUCTION_LOCKED"
SCOPE = "ALL_DRAFTKINGS_MLB_MODES"
MC_PRIMARY_AUTHORITY = False
MC_HARD_VETO = False
TOP_DOORS_PER_FAMILY = 9
ELITE_CORE_SLOTS = 8
RESERVE_SLOTS_DEFAULT = 2

def _pct(x):
    x=np.asarray(x,float); n=len(x)
    if n<=1: return np.ones(n,float)
    order=np.argsort(x,kind='mergesort'); out=np.empty(n,float); out[order]=np.linspace(0.0,1.0,n); return out

def _arr(metrics,key,n,default=0.0):
    a=np.asarray(metrics.get(key,np.full(n,default)),float)
    if len(a)!=n: raise RuntimeError(f"RNWD_METRIC_LENGTH_MISMATCH:{key}:{len(a)}:{n}")
    return a

def classic_positions(metrics, structures, board_size:int):
    n=len(structures)
    if n < board_size: raise RuntimeError(f"RNWD_CLASSIC_INSUFFICIENT:{n}:{board_size}")
    # MC rates/LCBs intentionally excluded from authority score.
    p99=_pct(_arr(metrics,'p99',n)); cvar=_pct(_arr(metrics,'cvar99',n)); p95=_pct(_arr(metrics,'p95',n))
    corr=_pct(_arr(metrics,'correlation',n)); lev=_pct(_arr(metrics,'leverage',n)); chalk=_pct(_arr(metrics,'chalk_failure_fade_edge',n))
    door=0.30*p99+0.24*cvar+0.18*corr+0.12*lev+0.10*chalk+0.06*p95
    fam=defaultdict(list)
    for i,s in enumerate(structures):
        fam[(s.pitcher_pair_key,s.stack_key,s.family_key)].append(i)
    fam_rows=[]
    for k,ids in fam.items():
        ids=sorted(ids,key=lambda i:(-door[i],str(structures[i].lineup_id)))
        top=ids[:TOP_DOORS_PER_FAMILY]
        vals=np.asarray([door[i] for i in top],float)
        fscore=float(vals[0] + 0.20*np.mean(vals[:min(3,len(vals))]) + 0.08*np.mean(vals))
        fam_rows.append((fscore,k,top))
    fam_rows.sort(key=lambda z:(-z[0],str(z[1])))

    # ELITE 8 = eight board slots, not eight forced families. Build the core by
    # round-robin neighborhood representatives before taking second doors.
    core_target=min(ELITE_CORE_SLOTS,board_size,n)
    core=[]; depth=0
    while len(core)<core_target:
        added=False
        for fs,k,ids in fam_rows:
            if depth < len(ids):
                i=int(ids[depth])
                if i not in core:
                    core.append(i); added=True
                    if len(core)>=core_target: break
        if not added: break
        depth += 1
    if len(core)<core_target:
        fallback=sorted(range(n),key=lambda i:(-door[i],str(structures[i].lineup_id)))
        for i in fallback:
            if i not in core: core.append(int(i))
            if len(core)>=core_target: break

    selected=list(core); used_macro={structures[i].macro_spine_key for i in selected}; used_pair={structures[i].pitcher_pair_key for i in selected}; used_stack={structures[i].stack_key for i in selected}; used_players=[set(structures[i].players) for i in selected]
    remaining=[i for i in range(n) if i not in set(selected)]
    fam_rank={k:r for r,(_,k,_) in enumerate(fam_rows)}
    fam_score={k:fs for fs,k,_ in fam_rows}
    def reserve_key(i):
        st=structures[i]; fk=(st.pitcher_pair_key,st.stack_key,st.family_key)
        ov=max((len(set(st.players)&p) for p in used_players),default=0)
        return (-(1 if st.macro_spine_key not in used_macro else 0),-(1 if st.pitcher_pair_key not in used_pair else 0),-(1 if st.stack_key not in used_stack else 0),fam_rank.get(fk,10**9),ov,-fam_score.get(fk,0.0),-door[i],str(st.lineup_id))
    while remaining and len(selected)<board_size:
        i=min(remaining,key=reserve_key); st=structures[i]
        selected.append(int(i)); remaining.remove(i); used_macro.add(st.macro_spine_key); used_pair.add(st.pitcher_pair_key); used_stack.add(st.stack_key); used_players.append(set(st.players))
    if len(selected)!=board_size: raise RuntimeError(f"RNWD_CLASSIC_SELECTION_INCOMPLETE:{len(selected)}:{board_size}")
    return np.asarray(selected,np.int64), {'PATCH_ID':PATCH_ID,'AUTHORITY':'ELITE8_RNWD_CORE_PLUS_STRUCTURAL_RESERVE','MC_PRIMARY_AUTHORITY':False,'MC_HARD_VETO':False,'TOP_DOORS_PER_FAMILY':TOP_DOORS_PER_FAMILY,'ELITE_CORE_SLOTS':core_target,'RESERVE_SLOTS':int(board_size-core_target),'FAMILY_COUNT':len(fam_rows),'CANDIDATE_COUNT':n}

def showdown_elite8_local(cands, metrics, meta, board_size:int=10):
    cands=np.asarray(cands,np.int32); n=len(cands)
    if n==0: return []
    p99=_pct(_arr(metrics,'p99',n)); cvar=_pct(_arr(metrics,'cvar99',n)); p95=_pct(_arr(metrics,'p95',n))
    own=np.asarray(meta['own_log'][cands],float); conf=np.asarray(meta.get('field_own_confidence',np.ones(len(meta['idx']))),float)[cands]; lev=_pct(-own)*conf
    base=0.44*p99+0.28*cvar+0.16*p95+0.12*lev-0.08*(1.0-conf)
    route=np.asarray(meta['route'],object)[cands]; branch=np.asarray(meta['branch'],object)[cands]
    fam=defaultdict(list)
    for i,k in enumerate(zip(route.tolist(),branch.tolist())): fam[k].append(i)
    rows=[]
    for k,ids in fam.items():
        ids=sorted(ids,key=lambda i:(-base[i],int(cands[i])))
        vals=np.asarray([base[i] for i in ids[:TOP_DOORS_PER_FAMILY]],float)
        fs=float(vals[0]+0.18*np.mean(vals[:min(3,len(vals))]))
        rows.append((fs,k,ids[:TOP_DOORS_PER_FAMILY]))
    rows.sort(key=lambda z:(-z[0],str(z[1])))
    target=min(ELITE_CORE_SLOTS,board_size,n); out=[]; depth=0
    while len(out)<target:
        added=False
        for fs,k,ids in rows:
            if depth < len(ids):
                j=int(ids[depth])
                if j not in out: out.append(j); added=True
                if len(out)>=target: break
        if not added: break
        depth += 1
    return out

def showdown_score(cands, metrics, meta):
    cands=np.asarray(cands,np.int32); n=len(cands)
    p99=_pct(_arr(metrics,'p99',n)); cvar=_pct(_arr(metrics,'cvar99',n)); p95=_pct(_arr(metrics,'p95',n))
    own=np.asarray(meta['own_log'][cands],float); lev=_pct(-own)
    route=np.asarray(meta['route'],object)[cands]; branch=np.asarray(meta['branch'],object)[cands]
    base=0.44*p99+0.28*cvar+0.16*p95+0.12*lev
    fam=defaultdict(list)
    for i,k in enumerate(zip(route.tolist(),branch.tolist())): fam[k].append(i)
    f=np.zeros(n,float)
    for ids in fam.values():
        vals=np.sort(base[ids])[::-1]; fs=float(vals[0]+0.18*np.mean(vals[:min(3,len(vals))]))
        f[ids]=fs
    score=0.72*f+0.28*base
    return score, {'PATCH_ID':PATCH_ID,'AUTHORITY':'ROUTE_BRANCH_NEIGHBORHOOD_THEN_DOOR','MC_PRIMARY_AUTHORITY':False,'MC_HARD_VETO':False,'FAMILY_COUNT':len(fam)}

def hrs_ranked(cand):
    # HRS has no MC-primary selector; install the same family-first routing on its explicit route neighborhoods.
    df=cand.copy(); n=len(df)
    if n==0: return df
    score=_pct(df['score'].to_numpy(float)); p3=_pct(df['p3'].to_numpy(float)); p2=_pct(df['p2plus'].to_numpy(float))
    door=0.50*score+0.30*p3+0.20*p2
    fam=df['route'].astype(str).to_numpy(); fscore={}
    for r in sorted(set(fam)):
        ids=np.where(fam==r)[0]; vals=np.sort(door[ids])[::-1]; fscore[r]=float(vals[0]+0.20*np.mean(vals[:min(3,len(vals))]))
    df['_RNWD_FAMILY_SCORE']=[fscore[r] for r in fam]; df['_RNWD_DOOR_SCORE']=door
    return df.sort_values(['_RNWD_FAMILY_SCORE','_RNWD_DOOR_SCORE','score','p3','p2plus'],ascending=False,kind='mergesort')
