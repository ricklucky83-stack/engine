#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

PATCH_ID = "MLB_CLASSIC_RAW_HOLDOUT_AUTO_INGEST_AND_AUTONOMOUS_LOSO_TRIGGER_v1"
MINIMUM_DISTINCT_BLIND_SLATES = 2


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def scan_vault(vault: Path) -> list[dict[str, Any]]:
    rows = []
    for path in sorted(vault.rglob("pair_manifest.json")):
        payload = json.loads(path.read_text())
        if payload.get("MODE") != "MLB_CLASSIC":
            continue
        payload["MANIFEST_PATH"] = str(path)
        payload["PAIR_ROOT"] = str(path.parent)
        rows.append(payload)
    return rows


def distinct_folds(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    best: dict[str, dict[str, Any]] = {}
    for row in rows:
        if not row.get("BLIND_CONTROL_ELIGIBLE", True):
            continue
        slate = row.get("SLATE_SHA256")
        if not slate:
            continue
        current = best.get(str(slate))
        if current is None or str(row.get("CONTEST_SHA256", "")) < str(current.get("CONTEST_SHA256", "")):
            best[str(slate)] = row
    return [best[key] for key in sorted(best)]


def _run_runtime(root: Path, runtime_rel: str, pool: Path, field: int, out: Path, execution_id: int, version: str) -> dict[str, Path]:
    out.mkdir(parents=True, exist_ok=True)
    engine_dir = root / "engines/mlb"
    handoff_dir = root / "current_handoff"
    runtime = root / runtime_rel
    if not runtime.is_file():
        raise RuntimeError(f"RUNTIME_MISSING:{runtime}")
    env = os.environ.copy()
    env.update({
        "PYTHONDONTWRITEBYTECODE": "1",
        "APEX_EXECUTION_ID": str(execution_id),
        "APEX_FIELD_SIZE": str(field),
        "APEX_PLAYER_POOL": str(pool),
        "APEX_OUTPUT_DIR": str(out),
        "APEX_ENGINE_DIR": str(engine_dir),
        "APEX_HANDOFF_DIR": str(handoff_dir),
        "APEX_GLOBAL_STATE_VERSION": version,
        "APEX_PHASE1_SIMS": "50000",
        "APEX_BASE_SIMS": "10000",
        "APEX_BUBBLE_BATCH": "10000",
        "APEX_MAX_SIMS": "50000",
    })
    log = out / "runtime.log"
    with log.open("w", encoding="utf-8") as f:
        run = subprocess.run([sys.executable, str(runtime)], cwd=root, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=900)
    if run.returncode != 0:
        raise RuntimeError(f"RUNTIME_FAILED:{runtime_rel}:EXIT_{run.returncode}:LOG={log}")
    prefix = f"execution_{execution_id}"
    files = {
        "manifest": out / f"{prefix}_phase2_roster_manifest.csv",
        "board": out / f"{prefix}_final_board.csv",
        "receipt": out / f"{prefix}_final_receipt.json",
        "log": log,
    }
    missing = [str(path) for path in files.values() if not path.is_file()]
    if missing:
        raise RuntimeError(f"RUNTIME_OUTPUT_MISSING:{missing}")
    return files


def build_plan(
    vault: Path,
    output_dir: Path,
    execute: bool,
    candidate_engine_root: Path | None = None,
    baseline_engine_root: Path | None = None,
) -> dict[str, Any]:
    rows = scan_vault(vault)
    folds = distinct_folds(rows)
    excluded_rows = [r for r in rows if not r.get("BLIND_CONTROL_ELIGIBLE", True)]
    reasons = []
    if len(folds) < MINIMUM_DISTINCT_BLIND_SLATES:
        reasons.append(f"DISTINCT_BYTE_COMPLETE_BLIND_SLATE_COUNT_{len(folds)}_LT_{MINIMUM_DISTINCT_BLIND_SLATES}")
    if execute and candidate_engine_root is None:
        reasons.append("CANDIDATE_ENGINE_ROOT_REQUIRED")
    if execute and baseline_engine_root is None:
        reasons.append("BASELINE_ENGINE_ROOT_REQUIRED_FOR_IMPROVEMENT_PROOF")
    ready = not reasons
    output_dir.mkdir(parents=True, exist_ok=True)
    plan_rows = []
    for index, fold in enumerate(folds, start=1):
        plan_rows.append({
            "FOLD": index,
            "SLATE_SHA256": fold["SLATE_SHA256"],
            "PAIR_SHA256": fold["PAIR_SHA256"],
            "FIELD_SIZE": int(fold["FIELD_SIZE"]),
            "FIELD_BAND": fold["FIELD_BAND"],
            "POOL": str(vault / fold["POOL_FILE"]),
            "CONTEST": str(vault / fold["CONTEST_FILE"]),
        })
    plan: dict[str, Any] = {
        "PATCH_ID": PATCH_ID,
        "MODE": "BLIND_MULTI_SLATE_CERTIFICATION_RESEARCH_ONLY",
        "RAW_PAIR_MANIFESTS_FOUND": len(rows),
        "TARGET_OR_OTHER_EXCLUDED_PAIR_MANIFESTS": len(excluded_rows),
        "DISTINCT_BYTE_COMPLETE_BLIND_SLATES": len(folds),
        "MINIMUM_DISTINCT_BYTE_COMPLETE_BLIND_SLATES": MINIMUM_DISTINCT_BLIND_SLATES,
        "LOSO_READY": ready,
        "LOSO_TRIGGERED": bool(ready),
        "LOSO_EXECUTED": False,
        "FAIL_CLOSED": not ready,
        "BLOCK_REASONS": reasons,
        "PRODUCTION_MUTATED": False,
        "AUTOMATIC_PRODUCTION_PROMOTION_ALLOWED": False,
        "FOLDS": plan_rows,
    }
    (output_dir / "loso_fold_plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    if not ready or not execute:
        plan["NEXT_ACTION"] = "WAIT_FOR_TWO_DISTINCT_BYTE_COMPLETE_BLIND_PAIRS" if not ready else "EXECUTE_AUTONOMOUS_BASELINE_VS_CANDIDATE_LOSO"
        (output_dir / "loso_controller_receipt.json").write_text(json.dumps(plan, indent=2) + "\n")
        return plan

    assert candidate_engine_root is not None and baseline_engine_root is not None
    matcher = candidate_engine_root / "engines/mlb/mlb_classic_postlock_contest_matcher_v1.py"
    if not matcher.is_file():
        raise RuntimeError(f"POSTLOCK_MATCHER_MISSING:{matcher}")
    results = []
    for fold in plan_rows:
        fold_dir = output_dir / f"fold_{fold['FOLD']:02d}_{fold['SLATE_SHA256'][:12]}"
        baseline_out = fold_dir / "baseline_v1_19"
        candidate_out = fold_dir / "candidate_v1_20_1"
        execution_id = int(fold["FIELD_SIZE"]) * 1000 + int(fold["FOLD"])
        baseline_files = _run_runtime(
            baseline_engine_root, "engines/mlb/mlb_classic_raw_pool_runtime_v1_4.py",
            Path(fold["POOL"]), int(fold["FIELD_SIZE"]), baseline_out, execution_id, "1.19.0",
        )
        candidate_files = _run_runtime(
            candidate_engine_root, "engines/mlb/mlb_classic_raw_pool_runtime_v1_20.py",
            Path(fold["POOL"]), int(fold["FIELD_SIZE"]), candidate_out, execution_id, "1.20.1-CANDIDATE",
        )
        match_receipt = fold_dir / "postlock_baseline_vs_candidate_match.json"
        cmd = [
            sys.executable, str(matcher),
            "--contest", fold["CONTEST"],
            "--player-pool", fold["POOL"],
            "--candidate-manifest", str(candidate_files["manifest"]),
            "--candidate-board", str(candidate_files["board"]),
            "--candidate-receipt", str(candidate_files["receipt"]),
            "--baseline-manifest", str(baseline_files["manifest"]),
            "--output", str(match_receipt),
        ]
        subprocess.run(cmd, check=True, cwd=candidate_engine_root, timeout=120)
        match = json.loads(match_receipt.read_text())
        results.append({
            "FOLD": fold["FOLD"],
            "SLATE_SHA256": fold["SLATE_SHA256"],
            "PAIR_SHA256": fold["PAIR_SHA256"],
            "BASELINE_MANIFEST_SHA256": sha256(baseline_files["manifest"]),
            "CANDIDATE_MANIFEST_SHA256": sha256(candidate_files["manifest"]),
            **match,
        })
    n = len(results)
    compatibility_failures = sum(not bool(r.get("POOL_CONTEST_COMPATIBILITY_PASS")) for r in results)
    candidate_births = sum(bool(r["WINNER_BORN_CANDIDATE_PHASE2"]) for r in results)
    baseline_births = sum(bool(r["WINNER_BORN_BASELINE_PHASE2"]) for r in results)
    improvements = sum(bool(r["CANDIDATE_BIRTH_AND_BASELINE_MISS"]) for r in results)
    regressions = sum(bool(r["WINNER_BORN_BASELINE_PHASE2"] and not r["WINNER_BORN_CANDIDATE_PHASE2"]) for r in results)
    review_hits = sum(bool(r["WINNER_REACHED_CANDIDATE_SELECTOR_REVIEW"]) for r in results)
    plan.update({
        "LOSO_EXECUTED": True,
        "FAIL_CLOSED": False,
        "FOLD_RESULTS": results,
        "BASELINE_WINNER_BIRTHS": baseline_births,
        "CANDIDATE_WINNER_BIRTHS": candidate_births,
        "CANDIDATE_WINNER_SELECTOR_REVIEW_HITS": review_hits,
        "CANDIDATE_BIRTH_IMPROVEMENTS": improvements,
        "CANDIDATE_BIRTH_REGRESSIONS": regressions,
        "BASELINE_WINNER_BIRTH_RATE": baseline_births / n if n else 0.0,
        "CANDIDATE_WINNER_BIRTH_RATE": candidate_births / n if n else 0.0,
        "POSTLOCK_COMPATIBILITY_FAILURES": compatibility_failures,
        "PROMOTION_REVIEW_ELIGIBLE": bool(n >= MINIMUM_DISTINCT_BLIND_SLATES and compatibility_failures == 0 and improvements >= 1 and regressions == 0 and candidate_births >= baseline_births),
        "AUTOMATIC_PRODUCTION_PROMOTION_ALLOWED": False,
        "NEXT_ACTION": "SEPARATE_IMMUTABLE_GLOBAL_STATE_CERTIFICATION_REVIEW",
    })
    (output_dir / "loso_controller_receipt.json").write_text(json.dumps(plan, indent=2) + "\n")
    return plan


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--vault", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--candidate-engine-root")
    parser.add_argument("--baseline-engine-root")
    args = parser.parse_args()
    result = build_plan(
        Path(args.vault), Path(args.output_dir), args.execute,
        Path(args.candidate_engine_root) if args.candidate_engine_root else None,
        Path(args.baseline_engine_root) if args.baseline_engine_root else None,
    )
    print(json.dumps({k: result[k] for k in (
        "DISTINCT_BYTE_COMPLETE_BLIND_SLATES", "LOSO_READY", "LOSO_TRIGGERED",
        "LOSO_EXECUTED", "FAIL_CLOSED", "AUTOMATIC_PRODUCTION_PROMOTION_ALLOWED",
    )}, indent=2))
    return 0 if not args.execute or not result["FAIL_CLOSED"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
