from __future__ import annotations
from typing import Mapping, Sequence

PATCH_ID = 'MLB_CLASSIC_FAST_521_DISTRIBUTED_RANK_LATTICE_v1'
PRIMARY_TEAM_DEPTH = 6
FIVE_RANKS = (1, 3, 5, 7, 9, 11, 13, 15)
PAIR_RANKS = (1, 4, 8, 12, 16)
SINGLE_RANKS = (1, 4, 8)
COMPATIBLE_PITCHER_PAIR_RANKS = (1, 3, 5, 8)


def select_primary_teams(team_weight_map: Mapping[str, float], depth: int = PRIMARY_TEAM_DEPTH) -> tuple[str, ...]:
    return tuple(t for t, _ in sorted(team_weight_map.items(), key=lambda kv: (-float(kv[1]), str(kv[0])))[:max(0, int(depth))])


def rank_positions(length: int, one_based_ranks: Sequence[int]) -> tuple[int, ...]:
    return tuple(int(r) - 1 for r in one_based_ranks if 1 <= int(r) <= int(length))


def receipt(*, attempted_hitter_cores: int, position_legal_cores: int, pitcher_bind_attempts: int, rows_added: int, generation_seconds: float) -> dict[str, object]:
    return {
        'PATCH_ID': PATCH_ID,
        'STATUS': 'PASS',
        'PRIMARY_TEAM_DEPTH': PRIMARY_TEAM_DEPTH,
        'FIVE_RANKS': list(FIVE_RANKS),
        'PAIR_RANKS': list(PAIR_RANKS),
        'SINGLE_RANKS': list(SINGLE_RANKS),
        'COMPATIBLE_PITCHER_PAIR_RANKS': list(COMPATIBLE_PITCHER_PAIR_RANKS),
        'ATTEMPTED_HITTER_CORES': int(attempted_hitter_cores),
        'POSITION_LEGAL_HITTER_CORES': int(position_legal_cores),
        'PITCHER_BIND_ATTEMPTS': int(pitcher_bind_attempts),
        'ROWS_ADDED': int(rows_added),
        'PRELOCK_ONLY': True,
        'POSTLOCK_INPUT_USED': False,
        'PLAYER_IDENTITY_TARGETING': False,
        'TEAM_IDENTITY_TARGETING': False,
        'GENERATION_SECONDS': round(float(generation_seconds), 6),
    }
