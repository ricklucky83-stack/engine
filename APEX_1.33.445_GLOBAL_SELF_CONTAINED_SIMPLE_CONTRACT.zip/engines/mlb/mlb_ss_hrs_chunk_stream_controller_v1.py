#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, heapq, itertools, json, math, os, re, sqlite3, sys, time
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import mlb_hitter_attackable_pa_adjustment_v1 as attackable_pa_mod
import mlb_ss_hrs_501_750_prospective_certification_v1 as cert_gate

PATCH_ID='MLB_SS_HRS_501_750_ENGINE_OWNED_CHUNK_STREAM_v1'
SCHEMA_VERSION='1.0.0'
KERNEL_ID='SS_HRS_v1.2_EVENT_NATIVE_HR_COUNT_PBP_POISSON_MC_BINDING'
SELECTOR_PATCH_ID='MLB_SS_HRS_MAGIC_DONKEY_STANDALONE_VARIANCE_PORTFOLIO_v1'
CONTINUE_RC=75
FIELD_MIN,FIELD_MAX=501,750
REQUIRED=['PLAYER','POS','LINEUP','TEAM','OPP','SAL','RST%','Time (ET)','1+ HR','HR%','ISO','Barrel %','Hard%','EV','Opp Pitcher','Opp ERA','T Runs','Win %','O/U','TEMP','WIND']
FORBIDDEN_PHASE1_INPUTS=['FPTS','AVG FPTS','L10 FPTS','L14 FPTS','L30 FPTS','L7 FPTS','L5 FPTS','L3 FPTS','VAL']
BASE=Path(__file__).resolve().parent
STATE_ROOT=BASE.parents[1]
POOL=Path(os.environ.get('APEX_PLAYER_POOL','')).resolve()
OUT=Path(os.environ.get('APEX_OUTPUT_DIR','/mnt/data')).resolve()
EXECUTION_ID=str(os.environ.get('APEX_EXECUTION_ID','UNSET'))
FIELD_SIZE=int(os.environ.get('APEX_FIELD_SIZE','0') or 0)
BOARD_SIZE=int(os.environ.get('APEX_BOARD_SIZE','10') or 10)
MC_SIMS=int(os.environ.get('APEX_SS_HRS_MC_SIMS','25000') or 25000)
COMBO_CHUNK=int(os.environ.get('APEX_SS_HRS_COMBO_CHUNK','100000') or 100000)
RANK_CHUNK=int(os.environ.get('APEX_SS_HRS_RANK_CHUNK','250000') or 250000)
RUN_ROOT=Path(os.environ.get('APEX_RESUMABLE_RUN_ROOT',str(OUT/f'.apex_mlb_ss_hrs_{EXECUTION_ID}'))).resolve()/ 'mlb_ss_hrs_chunk_stream_v1'
RUN_ROOT.mkdir(parents=True,exist_ok=True)
STATE_PATH=RUN_ROOT/'controller_state.json'; PLAYERS_PATH=RUN_ROOT/'players.json'; META_PATH=RUN_ROOT/'prep_meta.json'; DB_PATH=RUN_ROOT/'candidate_surface.sqlite'
BOARD_PATH=OUT/f'DK_MLB_SS_HRS_{EXECUTION_ID}_FINAL_BOARD.csv'; RECEIPT_PATH=OUT/f'DK_MLB_SS_HRS_{EXECUTION_ID}_FINAL_RECEIPT.json'
SOURCE=Path(__file__).resolve()

class EngineError(RuntimeError): pass

def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def stable_hash(obj:object)->str:
    return hashlib.sha256(json.dumps(obj,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()

def atomic_json(p:Path,obj:dict)->None:
    t=p.with_suffix(p.suffix+'.tmp')
    with t.open('w',encoding='utf-8') as f: json.dump(obj,f,indent=2,sort_keys=True); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(t,p)

def to_num(v)->float:
    if pd.isna(v): return np.nan
    s=str(v).strip().replace('%','').replace(',','')
    if s in {'','-','nan','None'}: return np.nan
    try:return float(s)
    except:return np.nan

def american_to_prob(v)->float:
    if pd.isna(v): return np.nan
    s=str(v).strip().replace('+','').replace(',','')
    if s in {'','-','nan','None'}: return np.nan
    try:x=float(s)
    except:return np.nan
    return 100/(x+100) if x>0 else ((-x)/((-x)+100) if x<0 else np.nan)

def pct_rank(s)->pd.Series:
    ss=pd.Series(s,dtype='float64')
    return pd.Series(np.full(len(ss),.5),index=ss.index) if ss.notna().sum()==0 else ss.rank(pct=True).fillna(.5)

def wind_parse(x)->tuple[float,float]:
    s=str(x); nums=re.findall(r'[-+]?\d*\.?\d+',s); speed=float(nums[0]) if nums else 0.0; low=s.lower()
    d=1.0 if 'out' in low else (-.6 if 'in' in low else (.15 if ('r-l' in low or 'l-r' in low) else 0.0))
    return speed,d

def con_open()->sqlite3.Connection:
    c=sqlite3.connect(DB_PATH,timeout=120); c.execute('PRAGMA journal_mode=WAL'); c.execute('PRAGMA synchronous=FULL'); c.execute('PRAGMA temp_store=FILE'); c.execute('PRAGMA cache_size=-65536'); return c

def load_state()->dict:
    if not STATE_PATH.exists(): return {}
    try:return json.loads(STATE_PATH.read_text(encoding='utf-8'))
    except:return {}

def save_state(s:dict)->None: atomic_json(STATE_PATH,s)

def identity()->dict:
    if not POOL.exists(): raise EngineError('RUN_INVALID:SS_HRS_PLAYER_POOL_MISSING')
    if not (FIELD_MIN<=FIELD_SIZE<=FIELD_MAX): raise EngineError(f'RUN_INVALID:SS_HRS_CHUNK_STREAM_FIELD_SCOPE_REQUIRES_501_750:{FIELD_SIZE}')
    if BOARD_SIZE!=10: raise EngineError(f'RUN_INVALID:SS_HRS_501_750_BOARD_SIZE_REQUIRES_10:{BOARD_SIZE}')
    if MC_SIMS<10000: raise EngineError(f'RUN_INVALID:SS_HRS_MC_MINIMUM_10000:{MC_SIMS}')
    if os.environ.get('APEX_CHUNK_STREAM_ONLY')!='1': raise EngineError('RUN_INVALID:SS_HRS_CHUNK_STREAM_ONLY_REQUIRED')
    return {'PATCH_ID':PATCH_ID,'SCHEMA_VERSION':SCHEMA_VERSION,'POOL_SHA256':sha256_file(POOL),'FIELD_SIZE':FIELD_SIZE,'BOARD_SIZE':BOARD_SIZE,'MC_SIMS':MC_SIMS,'EXECUTION_ID':EXECUTION_ID,'SOURCE_SHA256':sha256_file(SOURCE),'STATE_VERSION':str(os.environ.get('APEX_GLOBAL_STATE_VERSION','UNSPECIFIED'))}

def prep()->dict:
    raw=pd.read_csv(POOL); raw_hash=sha256_file(POOL); raw['_APEX_ROW_ID']=np.arange(len(raw),dtype=np.int32)
    missing=[x for x in REQUIRED if x not in raw.columns]
    if missing: raise EngineError('MISSING_REQUIRED_COLUMNS:'+','.join(missing))
    attack=attackable_pa_mod.build_attackable_pa_profiles(raw.to_dict('records'),mode='HRS')
    attack_receipt=attackable_pa_mod.receipt(raw.to_dict('records'),attack,mode='HRS')
    pit=raw[(raw['LINEUP'].astype(str).eq('SP'))|(raw['POS'].astype(str).eq('P'))].copy(); spmap={}
    for _,row in pit.iterrows():
        spmap[str(row['PLAYER']).strip()]={k:to_num(row.get(src)) for k,src in [('era','ERA'),('fip','FIP'),('xfip','xFIP'),('hr9','HR/9'),('k9','K/9'),('kbb','K/BB'),('gb','GB%'),('ou_k','O/U K'),('ou_er','O/U ER'),('bb9','BB/9')]}
    line=raw['LINEUP'].astype(str).str.strip(); pos=raw['POS'].astype(str).str.strip()
    hit=raw[(~line.isin(['BN','SP','nan',''])) & (~pos.eq('P'))].copy().reset_index(drop=True)
    if len(hit)<3: raise EngineError('NO_LEGAL_ACTIVE_HITTER_POOL')
    for name in ['pitch_around_risk','challenge_index','attackable_pa_multiplier','walk_multiplier','chalk_failure_edge']:
        hit[name]=[getattr(attack[int(x)],name) for x in hit['_APEX_ROW_ID']]
    for col in ['SAL','RST%','HR%','ISO','Barrel %','Hard%','EV','T Runs','Win %','O/U','TEMP','Opp ERA','AVG','OBP','OPS','SLG','wOBA','xBA']:
        hit[col+'_n']=hit[col].map(to_num) if col in hit.columns else np.nan
    hit['p_market_odds']=hit['1+ HR'].map(american_to_prob); hit['p_hr_col']=hit['HR%_n']/100.0; hit['p_market']=hit['p_hr_col'].fillna(hit['p_market_odds'])
    med=hit['p_market'].median(); hit['p_market']=hit['p_market'].fillna(.08 if pd.isna(med) else med).clip(.015,.38)
    for key in ['era','fip','xfip','hr9','k9','kbb','gb','ou_k','ou_er','bb9']:
        hit['opp_sp_'+key]=hit['Opp Pitcher'].astype(str).str.strip().map(lambda x,k=key:spmap.get(x,{}).get(k,np.nan))
    hit['opp_sp_era']=hit['opp_sp_era'].fillna(hit['Opp ERA_n'])
    defaults={'opp_sp_fip':4.20,'opp_sp_xfip':4.15,'opp_sp_hr9':1.05,'opp_sp_k9':8.2,'opp_sp_kbb':2.7,'opp_sp_gb':43.0,'opp_sp_ou_k':4.5,'opp_sp_ou_er':2.5,'opp_sp_bb9':3.0}
    for col,d in defaults.items():hit[col]=hit[col].fillna(d)
    for col in ['ISO_n','Barrel %_n','Hard%_n','EV_n','T Runs_n','O/U_n','TEMP_n','SAL_n','RST%_n','Win %_n']:
        med=hit[col].median(); hit[col]=hit[col].fillna(0.0 if pd.isna(med) else med)
    hit['power_idx']=.38*pct_rank(hit['ISO_n'])+.28*pct_rank(hit['Barrel %_n'])+.20*pct_rank(hit['Hard%_n'])+.14*pct_rank(hit['EV_n'])
    hit['opp_risk_idx']=.34*pct_rank(hit['opp_sp_hr9'])+.25*pct_rank(hit['opp_sp_xfip'])+.18*pct_rank(hit['opp_sp_era'])+.13*(1-pct_rank(hit['opp_sp_gb']))+.10*(1-pct_rank(hit['opp_sp_k9']))
    wind=hit['WIND'].map(wind_parse); hit['wind_speed']=[x[0] for x in wind]; hit['wind_dir']=[x[1] for x in wind]
    hit['env_idx']=.36*pct_rank(hit['T Runs_n'])+.20*pct_rank(hit['O/U_n'])+.18*pct_rank(hit['TEMP_n'])+.16*pct_rank(hit['wind_speed']*hit['wind_dir'])+.10*pct_rank(hit['Win %_n'])
    hit['slot_n']=hit['LINEUP'].map(to_num).fillna(9); hit['slot_idx']=(10-hit['slot_n'])/9.0
    hit['ss_axis_idx']=.38*pct_rank(hit['SAL_n'])+.26*(1-pct_rank(hit['RST%_n']))+.22*hit['slot_idx']+.14*pct_rank(hit['p_market'])
    hit['starter_exit_pressure']=.40*pct_rank(hit['opp_sp_ou_er'])+.24*(1-pct_rank(hit['opp_sp_ou_k']))+.18*pct_rank(hit['opp_sp_bb9'])+.18*pct_rank(hit['T Runs_n'])
    hit['macro_bullpen_curve']=1.0+(hit['starter_exit_pressure']-.5)*.14
    factor=1.0+.16*(hit['power_idx']-.5)+.10*(hit['opp_risk_idx']-.5)+.08*(hit['env_idx']-.5)+.05*(hit['ss_axis_idx']-.5)
    hit['p_event_raw']=(hit['p_market']*factor*hit['macro_bullpen_curve']).clip(.025,.39)
    hit['p_event_pre_attackability']=(.78*hit['p_market']+.22*hit['p_event_raw']).clip(.02,.38); hit['p_event']=hit['p_event_pre_attackability']; hit['p_event_attackable']=(hit['p_event']*hit['attackable_pa_multiplier']).clip(.02,.38)
    keep=['PLAYER','POS','LINEUP','TEAM','OPP','SAL_n','RST%_n','1+ HR','Opp Pitcher','p_market','p_event','p_event_attackable','power_idx','env_idx','ss_axis_idx','challenge_index','pitch_around_risk','attackable_pa_multiplier','chalk_failure_edge']
    PLAYERS_PATH.write_text(hit[keep].to_json(orient='records'),encoding='utf-8')
    p=hit['p_event'].to_numpy(float); env=hit['env_idx'].to_numpy(float); power=hit['power_idx'].to_numpy(float)
    seed=int(os.environ['APEX_SEED']) if os.environ.get('APEX_SEED') else int(hashlib.sha256(f'{EXECUTION_ID}|{raw_hash}'.encode()).hexdigest()[:8],16)
    rng=np.random.default_rng(seed); sim=rng.random((MC_SIMS,len(hit)))<p; mc_p=sim.mean(axis=0)
    phase1=np.lexsort((-hit['RST%_n'].to_numpy(float),-env,-power,-p))[:18]
    phase1_rows=[{'player':str(hit.loc[int(u),'PLAYER']),'p_event':float(p[u]),'mc_p':float(mc_p[u])} for u in phase1]
    meta={'raw_rows':len(raw),'active_hitters':len(hit),'bench_removed':int((line=='BN').sum()),'starting_pitchers':len(pit),'seed':seed,'forbidden_present':[x for x in FORBIDDEN_PHASE1_INPUTS if x in raw.columns],'phase1_surface':phase1_rows,'attackable_pa_receipt':attack_receipt}
    atomic_json(META_PATH,meta)
    with con_open() as con:
        con.execute('DROP TABLE IF EXISTS cand'); con.execute('DROP TABLE IF EXISTS ranks'); con.execute('DROP TABLE IF EXISTS family')
        con.execute('''CREATE TABLE cand(id INTEGER PRIMARY KEY,i INTEGER,j INTEGER,k INTEGER,route TEXT,p3 REAL,p2_exact REAL,p2plus REAL,p3_attack REAL,p2plus_attack REAL,challenge_mean REAL,expected_hrs REAL,cov_bonus REAL,pair_surface REAL,dup_proxy REAL,tail_count INTEGER,high_chalk_count INTEGER,same_team_pairs INTEGER,same_game_pairs INTEGER,top_anchor_count INTEGER,score REAL,salary_total REAL,door REAL)''')
        con.execute('CREATE TABLE ranks(id INTEGER PRIMARY KEY,score_pct REAL,p3_pct REAL,p2_pct REAL)'); con.execute('CREATE TABLE family(route TEXT PRIMARY KEY,fscore REAL)'); con.commit()
    return meta

def players()->pd.DataFrame: return pd.DataFrame(json.loads(PLAYERS_PATH.read_text(encoding='utf-8')))

def combo_chunk(n:int,cursor:list[int],limit:int):
    i,j,k=map(int,cursor); out=[]
    while len(out)<limit and i<n-2:
        out.append((i,j,k)); k+=1
        if k>=n: j+=1; k=j+1
        if j>=n-1: i+=1; j=i+1; k=j+1
    return out,[i,j,k],bool(i>=n-2)

def enum_step(state:dict)->tuple[int,int,bool]:
    h=players(); n=len(h); raw_triples,new_cursor,done=combo_chunk(n,state.get('combo_cursor',[0,1,2]),COMBO_CHUNK)
    if not raw_triples:return 0,0,True
    arr=np.asarray(raw_triples,dtype=np.int32); a,b,c=arr[:,0],arr[:,1],arr[:,2]
    p=h['p_event'].to_numpy(float); pa2=h['p_event_attackable'].to_numpy(float); rst=np.maximum(h['RST%_n'].to_numpy(float),.05); sal=h['SAL_n'].to_numpy(float); power=h['power_idx'].to_numpy(float); env=h['env_idx'].to_numpy(float); ss=h['ss_axis_idx'].to_numpy(float); challenge=h['challenge_index'].to_numpy(float)
    teams=h['TEAM'].astype(str).to_numpy(); opp=h['OPP'].astype(str).to_numpy(); codes=pd.Categorical(teams).codes
    tm=codes[arr]; legal=~((tm[:,0]==tm[:,1])&(tm[:,1]==tm[:,2])); arr=arr[legal]; tm=tm[legal]
    if len(arr):
        a,b,c=arr[:,0],arr[:,1],arr[:,2]; p1,p2,p3v=p[a],p[b],p[c]; p3=p1*p2*p3v; p2exact=p1*p2*(1-p3v)+p1*p3v*(1-p2)+p2*p3v*(1-p1); p2plus=p2exact+p3; expected=p1+p2+p3v
        q1,q2,q3=pa2[a],pa2[b],pa2[c]; p3a=q1*q2*q3; p2a=q1*q2*(1-q3)+q1*q3*(1-q2)+q2*q3*(1-q1); p2pa=p2a+p3a; ch=(challenge[a]+challenge[b]+challenge[c])/3.0
        st=(tm[:,0]==tm[:,1]).astype(np.int8)+(tm[:,0]==tm[:,2]).astype(np.int8)+(tm[:,1]==tm[:,2]).astype(np.int8)
        op=(((opp[a]==teams[b])|(opp[b]==teams[a])).astype(np.int8)+((opp[a]==teams[c])|(opp[c]==teams[a])).astype(np.int8)+((opp[b]==teams[c])|(opp[c]==teams[b])).astype(np.int8)); sg=np.minimum(3,st+op)
        em=(env[a]+env[b]+env[c])/3.0; pm=(power[a]+power[b]+power[c])/3.0; sm=(ss[a]+ss[b]+ss[c])/3.0; cov=1.0+.06*st+.04*sg+.08*np.maximum(0,em-.65)
        dup=FIELD_SIZE*(rst[a]/100)*(rst[b]/100)*(rst[c]/100)*(1.0+.16*st); tail=(rst[a]<=5).astype(np.int8)+(rst[b]<=5).astype(np.int8)+(rst[c]<=5).astype(np.int8); low=(rst[a]<=2.5).astype(np.int8)+(rst[b]<=2.5).astype(np.int8)+(rst[c]<=2.5).astype(np.int8); high=(rst[a]>=10).astype(np.int8)+(rst[b]>=10).astype(np.int8)+(rst[c]>=10).astype(np.int8)
        q92=np.quantile(p,.92); top=(p1>=q92).astype(np.int8)+(p2>=q92).astype(np.int8)+(p3v>=q92).astype(np.int8); lev=1/(1+35*dup); score=1000*p3*1.45+100*p2plus*.88+18*expected+4.8*pm+3.6*em+2.4*sm+1.8*lev+.25*tail-.18*np.maximum(0,high-1)
        route=np.full(len(arr),'BALANCED_CROSS_ENV_PAIR',dtype=object); route[(top>=2)&(high>=1)]='CEILING_CHALK_PAIR'; route[(st>=1)&(tail>=1)]='TEAM_PAIR_TAIL_BRIDGE'; route[(st>=1)&(tail<1)]='TEAM_PAIR_ENV_CLUSTER'; route[(st<1)&(low>=2)]='LOW_OWNED_CROSS_ENV_RESERVE'; route[(st<1)&(low<2)&(tail>=1)]='FIELD_RECOGNIZED_TAIL_LOCK'
        base=int(state.get('legal_count',0)); ids=np.arange(base,base+len(arr),dtype=np.int64)
        rows=zip(ids,arr[:,0],arr[:,1],arr[:,2],route,p3,p2exact,p2plus,p3a,p2pa,ch,expected,cov,p2plus*cov,dup,tail,high,st,sg,top,score,sal[a]+sal[b]+sal[c])
        with con_open() as con:
            con.executemany('INSERT INTO cand(id,i,j,k,route,p3,p2_exact,p2plus,p3_attack,p2plus_attack,challenge_mean,expected_hrs,cov_bonus,pair_surface,dup_proxy,tail_count,high_chalk_count,same_team_pairs,same_game_pairs,top_anchor_count,score,salary_total) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[tuple(x.item() if hasattr(x,'item') else x for x in r) for r in rows]); con.commit()
        state['legal_count']=base+len(arr)
    state['combo_cursor']=new_cursor; state['raw_combo_count']=int(state.get('raw_combo_count',0))+len(raw_triples)
    return len(raw_triples),len(arr),done

def rank_step(state:dict,metric:str,dest:str)->bool:
    n=int(state['legal_count']); key='rank_'+dest; cur=state.get(key,{}); pos=int(cur.get('position',0)); last_val=cur.get('last_value'); last_id=int(cur.get('last_id',-1))
    with con_open() as con:
        con.execute(f'CREATE INDEX IF NOT EXISTS idx_{metric}_asc ON cand({metric} ASC,id ASC)')
        if pos==0: rows=con.execute(f'SELECT id,{metric} FROM cand ORDER BY {metric} ASC,id ASC LIMIT ?',(RANK_CHUNK,)).fetchall()
        else: rows=con.execute(f'SELECT id,{metric} FROM cand WHERE {metric}>? OR ({metric}=? AND id>?) ORDER BY {metric} ASC,id ASC LIMIT ?',(last_val,last_val,last_id,RANK_CHUNK)).fetchall()
        payload=[]
        for off,(cid,val) in enumerate(rows): payload.append((float((pos+off)/(n-1)) if n>1 else 1.0,int(cid)))
        if dest=='score_pct': con.executemany('INSERT INTO ranks(id,score_pct) VALUES (?,?) ON CONFLICT(id) DO UPDATE SET score_pct=excluded.score_pct',[(cid,pct) for pct,cid in payload])
        else: con.executemany(f'UPDATE ranks SET {dest}=? WHERE id=?',payload)
        con.commit()
    if rows: state[key]={'position':pos+len(rows),'last_value':float(rows[-1][1]),'last_id':int(rows[-1][0])}
    return pos+len(rows)>=n

def door_step(state:dict)->bool:
    last=int(state.get('door_last_id',-1));
    with con_open() as con:
        rows=con.execute('SELECT c.id,r.score_pct,r.p3_pct,r.p2_pct FROM cand c JOIN ranks r USING(id) WHERE c.id>? ORDER BY c.id LIMIT ?',(last,RANK_CHUNK)).fetchall()
        con.executemany('UPDATE cand SET door=? WHERE id=?',[(.50*s+.30*p3+.20*p2,cid) for cid,s,p3,p2 in rows]); con.commit()
    if rows: state['door_last_id']=int(rows[-1][0])
    return not rows or int(state.get('door_last_id',-1))>=int(state['legal_count'])-1

def family_stage()->None:
    with con_open() as con:
        routes=[x[0] for x in con.execute('SELECT DISTINCT route FROM cand ORDER BY route')]
        con.execute('DELETE FROM family')
        for route in routes:
            vals=[float(x[0]) for x in con.execute('SELECT door FROM cand WHERE route=? ORDER BY door DESC,id ASC LIMIT 3',(route,))]
            fs=float(vals[0]+.20*np.mean(vals)) if vals else 0.0
            con.execute('INSERT INTO family(route,fscore) VALUES (?,?)',(route,fs))
        con.commit()

def create_index(name:str,sql:str)->None:
    with con_open() as con: con.execute(f'CREATE INDEX IF NOT EXISTS {name} ON cand({sql})'); con.commit()

def candidate_row(con,cid:int):
    r=con.execute('SELECT id,i,j,k,route,p3,p2plus,p3_attack,p2plus_attack,challenge_mean,expected_hrs,dup_proxy,score,salary_total FROM cand WHERE id=?',(int(cid),)).fetchone()
    if not r: raise EngineError(f'CANDIDATE_NOT_FOUND:{cid}')
    keys=['id','i','j','k','route','p3','p2plus','p3_attack','p2plus_attack','challenge_mean','expected_hrs','dup_proxy','score','salary_total']; return dict(zip(keys,r))

def rnwd_stream(con):
    fam={r:float(s) for r,s in con.execute('SELECT route,fscore FROM family')}; curs={}; heap=[]
    for route,fs in fam.items():
        cur=con.execute('SELECT id,i,j,k,route,p3,p2plus,p3_attack,p2plus_attack,challenge_mean,expected_hrs,dup_proxy,score,salary_total,door FROM cand WHERE route=? ORDER BY door DESC,score DESC,p3 DESC,p2plus DESC,id ASC',(route,)); row=cur.fetchone(); curs[route]=cur
        if row: heapq.heappush(heap,(-fs,-row[13],-row[12],-row[5],-row[6],row[0],route,row))
    keys=['id','i','j','k','route','p3','p2plus','p3_attack','p2plus_attack','challenge_mean','expected_hrs','dup_proxy','score','salary_total','door']
    while heap:
        *_,route,row=heapq.heappop(heap); yield dict(zip(keys,row)); nxt=curs[route].fetchone()
        if nxt: heapq.heappush(heap,(-fam[route],-nxt[13],-nxt[12],-nxt[5],-nxt[6],nxt[0],route,nxt))

def select_board()->tuple[list[int],dict,dict[int,str]]:
    h=players(); n=len(h); p=h['p_event'].to_numpy(float); pattack=h['p_event_attackable'].to_numpy(float); rst=h['RST%_n'].to_numpy(float); power=h['power_idx'].to_numpy(float); er=h['p_event'].rank(method='first',ascending=False).astype(int).to_numpy()
    primary=set(h.sort_values(['p_event','RST%_n','SAL_n'],ascending=False).head(12).index.tolist())
    elite=sorted(((float(p[i]*p[j]),(int(i),int(j))) for i,j in itertools.combinations(range(n),2)),reverse=True)[:3]; elite_set={tuple(sorted(q)) for _,q in elite}
    with con_open() as con:
        core=[]; ae=Counter(); pe=Counter(); repeated=None
        for row in rnwd_stream(con):
            ids=tuple(sorted((int(row['i']),int(row['j']),int(row['k'])))); pairs=[tuple(x) for x in itertools.combinations(ids,2)]
            if any(u in primary and ae[u]>=4 for u in ids):continue
            reps=[q for q in pairs if pe[q]>=1]
            if reps:
                d=set(reps)
                if len(d)!=1:continue
                q=next(iter(d))
                if q not in elite_set or (repeated is not None and repeated!=q) or pe[q]>=2:continue
            core.append(int(row['id']))
            for u in ids:ae[u]+=1
            for q in pairs:
                if pe[q]==1 and q in elite_set and repeated is None: repeated=q
                pe[q]+=1
            if len(core)>=8:break
        def exposure(indices):
            pc=Counter(); qc=Counter()
            for cid in indices:
                r=candidate_row(con,cid); ids=sorted((int(r['i']),int(r['j']),int(r['k'])))
                for u in ids:pc[u]+=1
                for q in itertools.combinations(ids,2):qc[tuple(q)]+=1
            return pc,qc
        def reserve(kind,selected,attack=False):
            pc,qc=exposure(selected)
            order='p2plus_attack DESC,challenge_mean DESC,p3_attack DESC,p2plus DESC,score DESC,id ASC' if (kind=='STANDALONE_VARIANCE' and attack) else 'p2plus DESC,p3 DESC,score DESC,id ASC'
            for rr in con.execute('SELECT id,i,j,k,p2plus,p2plus_attack FROM cand ORDER BY '+order):
                cid,i,j,k,p2p,p2pa=rr
                if int(cid) in selected:continue
                ids=np.asarray([i,j,k],dtype=int); ranks=er[ids]; pes=p[ids]; rs=rst[ids]; pw=power[ids]
                if kind=='MID_POWER_PAIR': mid=(ranks>=13)&(ranks<=25)&(pes>=.14)&(rs<=7)&(pw>=.70); ok=int((ranks<=8).sum())==1 and int(mid.sum())>=2; paircap=2
                elif kind=='MID_DEEP_POWER_PAIR': mid=(ranks>=13)&(ranks<=25)&(pes>=.14)&(rs<=7)&(pw>=.70); deep=(ranks>=26)&(ranks<=60)&(pes>=.14)&(rs<=7)&(pw>=.70); ok=int((ranks<=8).sum())==1 and int(mid.sum())>=1 and int(deep.sum())>=1; paircap=2
                else:
                    pesa=pattack[ids]; qual=(pes>=.105)&(pesa>=.100)&(rs<=7)&(pw>=.68); deep=(ranks>=20)&qual; ok=int((ranks<=10).sum())==0 and int(qual.sum())>=2 and int(deep.sum())>=1 and float(p2p)>=.085 and float(p2pa)>=.080; paircap=1
                if not ok:continue
                il=sorted(map(int,ids))
                if any(pc[u]>=4 for u in il) or any(qc[tuple(q)]>=paircap for q in itertools.combinations(il,2)):continue
                return int(cid)
            return None
        def fallback(selected):
            pc,qc=exposure(selected)
            for r in rnwd_stream(con):
                cid=int(r['id'])
                if cid in selected:continue
                ids=sorted((int(r['i']),int(r['j']),int(r['k'])))
                if any(pc[u]>=4 for u in ids) or any(qc[tuple(q)]>=1 for q in itertools.combinations(ids,2)):continue
                return cid
            return None
        def metrics(indices):
            pids=sorted({u for cid in indices for u in [candidate_row(con,cid)['i'],candidate_row(con,cid)['j'],candidate_row(con,cid)['k']]})
            if len(pids)>20:return {'p_any3':None,'p_any2plus':None,'expected_max':None,'unique_players':len(pids)}
            loc={u:j for j,u in enumerate(pids)}; masks=[]
            for cid in indices:
                r=candidate_row(con,cid); mask=0
                for u in (r['i'],r['j'],r['k']):mask|=1<<loc[u]
                masks.append(mask)
            probs=np.asarray([p[u] for u in pids],float); a3=a2=em=0.0
            for state in range(1<<len(pids)):
                prob=1.0
                for j,q in enumerate(probs):prob*=q if ((state>>j)&1) else (1-q)
                mx=max(int((state&m).bit_count()) for m in masks); a3+=prob*(mx>=3); a2+=prob*(mx>=2); em+=prob*mx
            return {'p_any3':float(a3),'p_any2plus':float(a2),'expected_max':float(em),'unique_players':len(pids)}
        magic_a=reserve('MID_POWER_PAIR',core); lane_a='MAGIC_DONKEY_MID_POWER_PAIR'
        if magic_a is None:magic_a=fallback(core); lane_a='MAGIC_DONKEY_ADAPTIVE_FALLBACK'
        base9=core+([magic_a] if magic_a is not None else []); sb=reserve('STANDALONE_VARIANCE',base9,False); sa=reserve('STANDALONE_VARIANCE',base9,True); magic_b=reserve('MID_DEEP_POWER_PAIR',base9); lane_b='MAGIC_DONKEY_MID_DEEP_POWER_PAIR'
        if magic_b is None:magic_b=fallback(base9); lane_b='MAGIC_DONKEY_ADAPTIVE_FALLBACK'
        lanes={}
        if len(core)==8 and magic_a is not None and magic_b is not None and sb is not None:
            def best(sidx):
                opts=[]
                for d in range(8):
                    trial=[x for j,x in enumerate(core) if j!=d]+[magic_a,magic_b,int(sidx)]; met=metrics(trial); opts.append((float(met['p_any3'] or 0),float(met['p_any2plus'] or 0),float(met['expected_max'] or 0),int(met['unique_players']),-d,d,trial,met))
                return max(opts)
            basebest=best(sb); chosen=basebest; standalone=sb; accepted=False; cmp={}
            if sa is not None:
                attackbest=best(sa); bm=basebest[-1]; am=attackbest[-1]; nonreg=float(am['p_any3'] or 0)+1e-12>=float(bm['p_any3'] or 0) and float(am['p_any2plus'] or 0)+1e-12>=float(bm['p_any2plus'] or 0) and float(am['expected_max'] or 0)+1e-12>=float(bm['expected_max'] or 0); cmp={'baseline_idx':sb,'attackable_idx':sa,'baseline_metrics':bm,'attackable_metrics':am,'nonregression_pass':nonreg}
                if nonreg:standalone=sa;chosen=attackbest;accepted=True
            *_,drop,selected,finalmet=chosen
            for x in selected:lanes[int(x)]='ADAPTIVE_CORE'
            lanes[magic_a]=lane_a; lanes[magic_b]=lane_b; lanes[standalone]='STANDALONE_VARIANCE_RESERVE'
            meta={'status':'ACTIVE_HARD_GATED','core_count':8,'elite_repeat_pair':list(repeated) if repeated else None,'magic_a_idx':magic_a,'magic_a_lane':lane_a,'magic_b_idx':magic_b,'magic_b_lane':lane_b,'standalone_idx':standalone,'attackable_standalone_accepted':accepted,'attackable_nonregression_comparison':cmp,'dropped_core_rank':drop+1,'final_portfolio_metrics':finalmet}
            return list(map(int,selected)),meta,lanes
        # fail closed to legacy baseline constraints but still through streamed RNWD order.
        selected=[]; ae=Counter(); pe=Counter(); rexp=Counter()
        for r in rnwd_stream(con):
            ids=sorted((int(r['i']),int(r['j']),int(r['k']))); qs=[tuple(q) for q in itertools.combinations(ids,2)]
            if any(u in primary and ae[u]>=4 for u in ids) or any(pe[q]>=2 for q in qs) or rexp[str(r['route'])]>=4:continue
            selected.append(int(r['id'])); [ae.__setitem__(u,ae[u]+1) for u in ids]; [pe.__setitem__(q,pe[q]+1) for q in qs]; rexp[str(r['route'])]+=1
            if len(selected)>=10:break
        return selected,{'status':'FAIL_CLOSED_TO_BASELINE_V1_2','final_portfolio_metrics':metrics(selected)}, {int(x):'BASELINE_V1_2_FAIL_CLOSED' for x in selected}

def quantile_db(con,col:str,q:float)->float:
    n=int(con.execute('SELECT COUNT(*) FROM cand').fetchone()[0]); x=(n-1)*q; lo=int(math.floor(x)); hi=int(math.ceil(x)); a=float(con.execute(f'SELECT {col} FROM cand ORDER BY {col} ASC,id ASC LIMIT 1 OFFSET ?',(lo,)).fetchone()[0]); b=float(con.execute(f'SELECT {col} FROM cand ORDER BY {col} ASC,id ASC LIMIT 1 OFFSET ?',(hi,)).fetchone()[0]); return a+(b-a)*(x-lo)

def finalize(state:dict)->dict:
    h=players(); meta=json.loads(META_PATH.read_text(encoding='utf-8')); selected,smeta,lanes=select_board()
    if len(selected)!=10:raise EngineError(f'FINAL_BOARD_SIZE_INVALID:{len(selected)}')
    p=h['p_event'].to_numpy(float); seed=int(meta['seed']); rng=np.random.default_rng(seed); sim=rng.random((MC_SIMS,len(h)))<p
    rows=[]; mc=[]
    with con_open() as con:
        n=int(con.execute('SELECT COUNT(*) FROM cand').fetchone()[0]); field_thr=quantile_db(con,'score',.995); bar=quantile_db(con,'p2plus',.975); phase3=int(con.execute('SELECT COUNT(*) FROM cand WHERE p2plus>=? OR score>=?',(bar,field_thr)).fetchone()[0])
        top100=[{'i':int(a),'j':int(b),'k':int(c),'score':round(float(s),8)} for a,b,c,s in con.execute('SELECT i,j,k,score FROM cand ORDER BY score DESC,id ASC LIMIT 100')]; phase2_hash=stable_hash({'input_hash':sha256_file(POOL),'seed':seed,'field':FIELD_SIZE,'n_candidates':n,'calibration':KERNEL_ID,'top100_idx':top100})
        for rank,cid in enumerate(selected,1):
            r=candidate_row(con,cid); ids=[int(r['i']),int(r['j']),int(r['k'])]; names=[str(h.loc[u,'PLAYER']) for u in ids]; counts=sim[:,ids].sum(axis=1); mc.append({'rank':rank,'mc_p_3hr':float((counts==3).mean()),'mc_p_2plus_hr':float((counts>=2).mean())})
            rows.append({'RANK':rank,'CANDIDATE_ID':cid,'UTIL1':names[0],'UTIL2':names[1],'UTIL3':names[2],'ROUTE':r['route'],'SELECTOR_LANE':lanes.get(cid,'ADAPTIVE_CORE'),'P3':float(r['p3']),'P2PLUS':float(r['p2plus']),'EXPECTED_HRS':float(r['expected_hrs']),'DUP_PROXY_X_FIELD':float(r['dup_proxy']),'SALARY_TOTAL_INFO':float(r['salary_total'])})
        route_counts={r:int(c) for r,c in con.execute('SELECT route,COUNT(*) FROM cand GROUP BY route')}; phase3_routes={r:int(c) for r,c in con.execute('SELECT route,COUNT(*) FROM cand WHERE p2plus>=? OR score>=? GROUP BY route',(bar,field_thr))}
    with BOARD_PATH.open('w',encoding='utf-8',newline='') as f: w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    receipt={'RUN_STATUS':'PASS','EXECUTION_STATE':'TOOL_PROVEN_EXECUTED','RUN_STATE':'BOARD_READY','PATCH_ID':PATCH_ID,'KERNEL_ID':KERNEL_ID,'SELECTOR_PATCH_ID':SELECTOR_PATCH_ID,'EXECUTION_METHOD':'CHUNK_AND_STREAM_ONLY','FULL_TRIAD_ARRAY_MATERIALIZED':False,'DISK_BACKED_CANDIDATE_SURFACE':True,'FIELD_SIZE':FIELD_SIZE,'FAKE_FIELD_ENTRIES':FIELD_SIZE,'MC_ITERATIONS':MC_SIMS,'ACTIVE_POOL':len(h),'OUT_PURGE':int(meta['bench_removed']),'PHASE2_BUILT_LINEUPS':int(state['legal_count']),'SELECTOR_REVIEWED_LINEUPS':int(state['legal_count']),'PHASE3_SURVIVORS':phase3,'PHASE2_HASH':phase2_hash,'FIELD_THRESHOLD_SCORE':field_thr,'BAR_SCORE_P2PLUS':bar,'ROUTE_COUNTS_ALL':route_counts,'PHASE3_ROUTE_COUNTS':phase3_routes,'SELECTOR_META':smeta,'MC_VALIDATION_SELECTED':mc,'FINAL_BOARD_SIZE':10,'FINAL_BOARD':rows,'BOARD_ARTIFACT_PATH':str(BOARD_PATH),'CANDIDATE_DB_PATH':str(DB_PATH),'CANDIDATE_DB_SHA256':sha256_file(DB_PATH),'CHUNK_COUNTS':{'RAW_COMBINATIONS_STREAMED':int(state.get('raw_combo_count',0)),'LEGAL_TRIADS_STREAMED':int(state['legal_count']),'COMBO_CHUNK_MAX':COMBO_CHUNK,'RANK_CHUNK_MAX':RANK_CHUNK}}
    atomic_json(RECEIPT_PATH,receipt)
    cert=cert_gate.freeze(receipt_path=RECEIPT_PATH,candidate_db=DB_PATH,board_path=BOARD_PATH,player_pool=POOL,field_size=FIELD_SIZE,execution_id=EXECUTION_ID,engine_source=SOURCE,output_dir=OUT); receipt['PROSPECTIVE_CERTIFICATION_GATE']=cert; atomic_json(RECEIPT_PATH,receipt)
    return receipt

def emit_continue(state:dict,completed:str,next_stage:str):
    save_state(state); print(json.dumps({'RUN_STATE':'CHECKPOINTED_CONTINUE','EXECUTION_STATE':'RESUMABLE','PATCH_ID':PATCH_ID,'COMPLETED_STAGE':completed,'NEXT_STAGE':next_stage,'STAGE_INDEX':int(state.get('stage_index',0)),'CHECKPOINT':str(STATE_PATH),'CONTROLLER_STATE':str(STATE_PATH)},sort_keys=True),flush=True); raise SystemExit(CONTINUE_RC)

def main()->int:
    ident=identity(); state=load_state()
    if state and state.get('IDENTITY')!=ident:
        stale=RUN_ROOT.with_name(RUN_ROOT.name+f'.stale.{time.time_ns()}'); os.replace(RUN_ROOT,stale); RUN_ROOT.mkdir(parents=True,exist_ok=True); state={}
    if not state: state={'IDENTITY':ident,'stage':'PREP','stage_index':0,'combo_cursor':[0,1,2],'raw_combo_count':0,'legal_count':0}
    st=state['stage']
    if st=='PREP': prep(); state.update({'stage':'ENUMERATE','stage_index':1}); emit_continue(state,'PREP','ENUMERATE')
    if st=='ENUMERATE':
        raw,legal,done=enum_step(state)
        if not done: emit_continue(state,f'ENUMERATE:RAW_{state["raw_combo_count"]}:LEGAL_{state["legal_count"]}','ENUMERATE')
        if int(state['legal_count'])<=0:raise EngineError('ZERO_LEGAL_TRIADS')
        state.update({'stage':'RANK_SCORE','stage_index':2}); emit_continue(state,f'ENUMERATE_COMPLETE:LEGAL_{state["legal_count"]}','RANK_SCORE')
    if st=='RANK_SCORE':
        done=rank_step(state,'score','score_pct')
        if not done:emit_continue(state,f'RANK_SCORE:{state["rank_score_pct"]["position"]}','RANK_SCORE')
        state.update({'stage':'RANK_P3','stage_index':3});emit_continue(state,'RANK_SCORE_COMPLETE','RANK_P3')
    if st=='RANK_P3':
        done=rank_step(state,'p3','p3_pct')
        if not done:emit_continue(state,f'RANK_P3:{state["rank_p3_pct"]["position"]}','RANK_P3')
        state.update({'stage':'RANK_P2','stage_index':4});emit_continue(state,'RANK_P3_COMPLETE','RANK_P2')
    if st=='RANK_P2':
        done=rank_step(state,'p2plus','p2_pct')
        if not done:emit_continue(state,f'RANK_P2:{state["rank_p2_pct"]["position"]}','RANK_P2')
        state.update({'stage':'DOOR','stage_index':5});emit_continue(state,'RANK_P2_COMPLETE','DOOR')
    if st=='DOOR':
        done=door_step(state)
        if not done:emit_continue(state,f'DOOR:{state.get("door_last_id",-1)}','DOOR')
        state.update({'stage':'FAMILY','stage_index':6});emit_continue(state,'DOOR_COMPLETE','FAMILY')
    if st=='FAMILY': family_stage(); state.update({'stage':'INDEX_RNWD','stage_index':7});emit_continue(state,'FAMILY_COMPLETE','INDEX_RNWD')
    if st=='INDEX_RNWD': create_index('idx_route_door','route ASC,door DESC,score DESC,p3 DESC,p2plus DESC,id ASC'); state.update({'stage':'INDEX_RESERVE','stage_index':8});emit_continue(state,'INDEX_RNWD_COMPLETE','INDEX_RESERVE')
    if st=='INDEX_RESERVE': create_index('idx_reserve','p2plus DESC,p3 DESC,score DESC,id ASC'); state.update({'stage':'INDEX_ATTACK','stage_index':9});emit_continue(state,'INDEX_RESERVE_COMPLETE','INDEX_ATTACK')
    if st=='INDEX_ATTACK': create_index('idx_attack','p2plus_attack DESC,challenge_mean DESC,p3_attack DESC,p2plus DESC,score DESC,id ASC'); state.update({'stage':'FINALIZE','stage_index':10});emit_continue(state,'INDEX_ATTACK_COMPLETE','FINALIZE')
    if st=='FINALIZE':
        receipt=finalize(state); state.update({'stage':'COMPLETE','stage_index':11,'FINAL_BOARD_PATH':str(BOARD_PATH),'FINAL_RECEIPT_PATH':str(RECEIPT_PATH)});save_state(state);print(json.dumps(receipt,sort_keys=True),flush=True);return 0
    if st=='COMPLETE':
        receipt=json.loads(RECEIPT_PATH.read_text(encoding='utf-8'));print(json.dumps(receipt,sort_keys=True),flush=True);return 0
    raise EngineError(f'UNKNOWN_STAGE:{st}')

if __name__=='__main__':
    try: raise SystemExit(main())
    except SystemExit: raise
    except Exception as exc:
        print(json.dumps({'RUN_STATE':'FAILED','EXECUTION_STATE':'RUN_INVALID','PATCH_ID':PATCH_ID,'FAILURE_CODE':f'{type(exc).__name__}:{exc}'},sort_keys=True),flush=True);raise SystemExit(1)
