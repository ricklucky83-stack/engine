from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np

import mlb_advisor_tail_selector_v1 as advisor
import mlb_classic_historical_consensus_selector_v1 as historical
import mlb_classic_noninferior_trophy_portfolio_selector_v1 as parent
import mlb_right_neighborhood_wrong_door_authority_v1 as rnwd

PATCH_ID = "MLB_CLASSIC_MULTI_EVENT_COMMON_WORLD_MARGINAL_PORTFOLIO_v1"
SELECTOR_MODE = "NONINFERIOR_MULTI_EVENT_COMMON_WORLD_WEIGHTED_MARGINAL_COVERAGE"
PRIMARY_OBJECTIVE = "RECURRING_FULL_WHEEL_CHAMPIONSHIP_WORLD_UNION_THEN_WIN_AND_TOP_0_1"
POSTLOCK_RESULTS_USED_BY_SELECTOR = False
HARD_PLAYER_EXPOSURE_CAP_USED = False
HARD_FAMILY_QUOTAS_USED = False
HARD_PITCHER_PAIR_QUOTAS_USED = False
WEIGHTED_STATIC_METRIC_SUM_USED = False
WEIGHTED_MARGINAL_EVENT_COVERAGE_USED = True
RNWD_AUTHORITY_USED = False
RNWD_CONTROL_ONLY = True
COMMON_WORLD_WEIGHTS = {"win": 1.50, "top01": 1.00, "top1": 0.10}
COMMON_WORLD_WEIGHT_RATIO = (15, 10, 1)
StructuralIdentity = parent.StructuralIdentity


@dataclass(frozen=True)
class PortfolioSelection:
    positions: np.ndarray
    rnwd_control_positions: np.ndarray
    quality_tier: np.ndarray
    primary_delta: float
    lcb_delta: float
    frontier_size: int
    selected_tier_counts: tuple[tuple[int, int], ...]
    unique_macro_spines: int
    unique_pitcher_pairs: int
    unique_stack_keys: int
    unique_families: int
    unique_salary_geometries: int
    max_pairwise_player_overlap: int
    rnwd_win_union_hits: int
    rnwd_top01_union_hits: int
    rnwd_top1_union_hits: int
    selected_win_union_hits: int
    selected_top01_union_hits: int
    selected_top1_union_hits: int
    selected_fullwheel_win_union_hits: int
    selected_fullwheel_top01_union_hits: int
    marginal_hits_by_slot: tuple[tuple[int, int, int, int], ...]
    fullwheel_marginal_hits_by_slot: tuple[tuple[int, int], ...]
    same_world_authority_active: bool
    common_worlds: int


_POP8 = np.unpackbits(np.arange(256, dtype=np.uint8)[:, None], axis=1).sum(axis=1).astype(np.int16)


def _popcount_sum_u8(values: np.ndarray, *, axis=None) -> np.ndarray | np.integer:
    """Count set bits with native NumPy popcount when available.

    This is an execution-only optimization. It preserves the existing uint8
    packed-world representation and returns int64 sums exactly matching the
    legacy 256-entry lookup table. The fallback keeps compatibility with
    NumPy builds that predate ``np.bitwise_count``.
    """
    arr = np.asarray(values, dtype=np.uint8)
    bitwise_count = getattr(np, "bitwise_count", None)
    if bitwise_count is not None:
        return bitwise_count(arr).sum(axis=axis, dtype=np.int64)
    return _POP8[arr].sum(axis=axis, dtype=np.int64)


def _metric(metrics: Mapping[str, np.ndarray], key: str, n: int) -> np.ndarray:
    if key not in metrics:
        return np.zeros(n, dtype=np.float64)
    arr = np.asarray(metrics[key], dtype=np.float64)
    if arr.ndim != 1 or len(arr) != n:
        raise RuntimeError(f"METRIC_LENGTH_MISMATCH:{key}:{arr.shape}:{n}")
    if not np.all(np.isfinite(arr)):
        raise RuntimeError(f"NONFINITE_SELECTOR_METRIC:{key}")
    return arr


def _validate_bits(name: str, bits: np.ndarray, n: int, common_worlds: int, row_indices: np.ndarray | None = None) -> np.ndarray:
    arr = np.asarray(bits)
    expected_bytes = (int(common_worlds) + 7) // 8
    if arr.dtype != np.uint8 or arr.ndim != 2:
        raise RuntimeError(f"{name}_BITS_FORMAT_INVALID:{arr.dtype}:{arr.shape}")
    if arr.shape[1] != expected_bytes:
        raise RuntimeError(f"{name}_BITS_WIDTH_MISMATCH:{arr.shape}:{expected_bytes}")
    if row_indices is None:
        if arr.shape[0] != n:
            raise RuntimeError(f"{name}_BITS_SHAPE_MISMATCH:{arr.shape}:{n}:{expected_bytes}")
    else:
        rows = np.asarray(row_indices, dtype=np.int64)
        if rows.ndim != 1 or len(rows) != n:
            raise RuntimeError(f"{name}_ROW_INDEX_LENGTH_MISMATCH:{rows.shape}:{n}")
        if len(rows) and (int(rows.min()) < 0 or int(rows.max()) >= arr.shape[0]):
            raise RuntimeError(f"{name}_ROW_INDEX_BOUNDS:{int(rows.min())}:{int(rows.max())}:{arr.shape[0]}")
    return arr


def _source_row(position: int, row_indices: np.ndarray | None) -> int:
    return int(position) if row_indices is None else int(row_indices[int(position)])


def _union_hits(bits: np.ndarray, positions: Sequence[int], row_indices: np.ndarray | None = None) -> int:
    covered = np.zeros(bits.shape[1], dtype=np.uint8)
    for j in positions:
        covered |= bits[_source_row(int(j), row_indices)]
    return int(_popcount_sum_u8(covered))


def _gain_vector(bits: np.ndarray, pool: Sequence[int], covered: np.ndarray, row_indices: np.ndarray | None = None, block_rows: int = 4096) -> np.ndarray:
    ids = np.asarray(pool, dtype=np.int64)
    if len(ids) == 0:
        return np.empty(0, dtype=np.int64)
    inverse = np.bitwise_not(covered)
    out = np.empty(len(ids), dtype=np.int64)
    block_rows = max(1, int(block_rows))
    for start in range(0, len(ids), block_rows):
        stop = min(len(ids), start + block_rows)
        local = ids[start:stop]
        source = local if row_indices is None else row_indices[local]
        block = bits[source]
        out[start:stop] = _popcount_sum_u8(np.bitwise_and(block, inverse), axis=1)
    return out


def _max_overlap_index(j: int, selected: Sequence[int], structures: Sequence[StructuralIdentity]) -> int:
    if not selected:
        return 0
    s = set(structures[int(j)].players)
    return max(len(s.intersection(structures[int(k)].players)) for k in selected)


def select_portfolio(
    metrics: Mapping[str, np.ndarray],
    structures: Sequence[StructuralIdentity],
    *,
    win_bits: np.ndarray,
    top01_bits: np.ndarray,
    top1_bits: np.ndarray,
    fullwheel_top01_bits: np.ndarray | None = None,
    fullwheel_win_bits: np.ndarray | None = None,
    row_indices: np.ndarray | None = None,
    common_worlds: int,
    context: advisor.ContextProfile,
    board_size: int,
) -> PortfolioSelection:
    """Select a pre-lock MLB Classic board using validated common-world marginal coverage.

    Governance order:
      1. Parent Top-0.1 noninferiority/LCB quality tiers are a hard gate.
      2. First seat is the strongest conservative elite anchor.
      3. Remaining seats maximize incremental shared-world event coverage using
         WIN:Top-0.1:Top-1 = 15:10:1.
      4. Pairwise player overlap and conservative tail metrics resolve exact ties.
      5. RNWD is retained only as a diagnostic control and has no board authority.
    """
    if board_size <= 0:
        raise RuntimeError("BOARD_SIZE_MUST_BE_POSITIVE")
    if "top01_rate" not in metrics:
        raise RuntimeError("MISSING_SELECTOR_METRIC:top01_rate")
    n = len(np.asarray(metrics["top01_rate"]))
    if n < board_size:
        raise RuntimeError(f"INSUFFICIENT_SELECTOR_ROWS:{n}:{board_size}")
    parent._validate_structures(structures, n)
    for key in metrics:
        if str(key).upper() in parent.PROHIBITED_METRIC_NAMES:
            raise RuntimeError(f"PROHIBITED_SELECTOR_METRIC:{key}")

    rows = None if row_indices is None else np.asarray(row_indices, dtype=np.int64)
    win_bits = _validate_bits("WIN", win_bits, n, common_worlds, rows)
    top01_bits = _validate_bits("TOP01", top01_bits, n, common_worlds, rows)
    top1_bits = _validate_bits("TOP1", top1_bits, n, common_worlds, rows)
    if fullwheel_top01_bits is None:
        fullwheel_top01_bits = np.zeros((n, top01_bits.shape[1]), dtype=np.uint8)
        fw_top_rows = None
    else:
        fullwheel_top01_bits = _validate_bits("FULLWHEEL_TOP01", fullwheel_top01_bits, n, common_worlds, rows)
        fw_top_rows = rows
    if fullwheel_win_bits is None:
        fullwheel_win_bits = np.zeros((n, win_bits.shape[1]), dtype=np.uint8)
        fw_win_rows = None
    else:
        fullwheel_win_bits = _validate_bits("FULLWHEEL_WIN", fullwheel_win_bits, n, common_worlds, rows)
        fw_win_rows = rows

    parent_tiers, primary_delta, lcb_delta = parent.quality_tiers(metrics, context=context)
    baseline = historical.ranking_order(metrics, context=context)
    base_rank = np.empty(n, dtype=np.int64)
    base_rank[baseline] = np.arange(n, dtype=np.int64)

    primary = _metric(metrics, "top01_rate", n)
    lcb = _metric(metrics, "top01_lcb", n)
    win_rate = _metric(metrics, "win_rate", n)
    cvar99 = _metric(metrics, "cvar99", n)
    p99 = _metric(metrics, "p99", n)
    same_world_core = _metric(metrics, "same_world_core_mass", n)
    same_world_half = _metric(metrics, "same_world_core_half_min", n)
    same_world_strict = _metric(metrics, "same_world_strict_mass", n)
    same_world_loose = _metric(metrics, "same_world_loose_mass", n)
    same_world_conversion = _metric(metrics, "same_world_top01_conversion", n)
    same_world_authority_active = bool(np.any(same_world_core > 0.0))
    # A full-wheel event is already a strict subset of a Top-0.1 event. When such
    # events exist, a Top-0.1-only noninferiority tier may not block the stronger
    # complete-system evidence. If the tape contains no full-wheel recurrence,
    # the preexisting Top-0.1 tiers remain the exact fallback.
    tiers = np.zeros_like(parent_tiers) if same_world_authority_active else parent_tiers

    rnwd_positions, _rnwd_receipt = rnwd.classic_positions(metrics, structures, board_size)

    selected: list[int] = []
    selected_structures: list[StructuralIdentity] = []
    tier_counts: list[tuple[int, int]] = []
    marginal: list[tuple[int, int, int, int]] = []
    fullwheel_marginal: list[tuple[int, int]] = []
    covered_win = np.zeros(win_bits.shape[1], dtype=np.uint8)
    covered_top01 = np.zeros(top01_bits.shape[1], dtype=np.uint8)
    covered_top1 = np.zeros(top1_bits.shape[1], dtype=np.uint8)
    covered_fullwheel_win = np.zeros(fullwheel_win_bits.shape[1], dtype=np.uint8)
    covered_fullwheel_top01 = np.zeros(fullwheel_top01_bits.shape[1], dtype=np.uint8)

    for tier in sorted(set(int(x) for x in tiers)):
        pool = [i for i in range(n) if int(tiers[i]) == tier and i not in selected]
        count = 0
        while pool and len(selected) < board_size:
            if not selected:
                j = min(
                    pool,
                    key=lambda x: (
                        -float(same_world_core[x]),
                        -float(same_world_half[x]),
                        -float(same_world_strict[x]),
                        -float(same_world_loose[x]),
                        -float(same_world_conversion[x]),
                        -float(lcb[x]),
                        -float(win_rate[x]),
                        -float(primary[x]),
                        -float(cvar99[x]),
                        -float(p99[x]),
                        int(base_rank[x]),
                        parent._stable_id_key(structures[x].lineup_id),
                    ),
                )
                gain_fw_win = _union_hits(fullwheel_win_bits, [j], fw_win_rows)
                gain_fw_top01 = _union_hits(fullwheel_top01_bits, [j], fw_top_rows)
                gain_win = _union_hits(win_bits, [j], rows)
                gain_top01 = _union_hits(top01_bits, [j], rows)
                gain_top1 = _union_hits(top1_bits, [j], rows)
            else:
                gain_fw_win_vec = _gain_vector(fullwheel_win_bits, pool, covered_fullwheel_win, fw_win_rows)
                gain_fw_top01_vec = _gain_vector(fullwheel_top01_bits, pool, covered_fullwheel_top01, fw_top_rows)
                gain_win_vec = _gain_vector(win_bits, pool, covered_win, rows)
                gain_top01_vec = _gain_vector(top01_bits, pool, covered_top01, rows)
                gain_top1_vec = _gain_vector(top1_bits, pool, covered_top1, rows)
                standard_score = (
                    COMMON_WORLD_WEIGHTS["win"] * gain_win_vec
                    + COMMON_WORLD_WEIGHTS["top01"] * gain_top01_vec
                    + COMMON_WORLD_WEIGHTS["top1"] * gain_top1_vec
                )
                if same_world_authority_active:
                    best_tuple = max(
                        (int(gain_fw_win_vec[k]), int(gain_fw_top01_vec[k]), float(standard_score[k]))
                        for k in range(len(pool))
                    )
                    tied_local = [k for k in range(len(pool)) if (int(gain_fw_win_vec[k]), int(gain_fw_top01_vec[k]), float(standard_score[k])) == best_tuple]
                else:
                    best = float(np.max(standard_score))
                    tied_local = np.flatnonzero(np.isclose(standard_score, best, rtol=0.0, atol=1e-12)).tolist()

                def tie_key(local_idx: int):
                    candidate = int(pool[int(local_idx)])
                    if same_world_authority_active:
                        system_key = (
                            -float(same_world_core[candidate]),
                            -float(same_world_half[candidate]),
                            -float(same_world_strict[candidate]),
                            -float(same_world_loose[candidate]),
                            -float(same_world_conversion[candidate]),
                        )
                    else:
                        system_key = ()
                    return system_key + (
                        _max_overlap_index(candidate, selected, structures),
                        -float(lcb[candidate]),
                        -float(win_rate[candidate]),
                        -float(primary[candidate]),
                        -float(cvar99[candidate]),
                        -float(p99[candidate]),
                        int(base_rank[candidate]),
                        parent._stable_id_key(structures[candidate].lineup_id),
                    )

                local = min(map(int, tied_local), key=tie_key)
                j = int(pool[local])
                gain_fw_win = int(gain_fw_win_vec[local])
                gain_fw_top01 = int(gain_fw_top01_vec[local])
                gain_win = int(gain_win_vec[local])
                gain_top01 = int(gain_top01_vec[local])
                gain_top1 = int(gain_top1_vec[local])

            selected.append(j)
            selected_structures.append(structures[j])
            pool.remove(j)
            count += 1
            marginal.append((int(gain_win), int(gain_top01), int(gain_top1), int(tier)))
            fullwheel_marginal.append((int(gain_fw_win), int(gain_fw_top01)))
            covered_fullwheel_win |= fullwheel_win_bits[_source_row(j, fw_win_rows)]
            covered_fullwheel_top01 |= fullwheel_top01_bits[_source_row(j, fw_top_rows)]
            covered_win |= win_bits[_source_row(j, rows)]
            covered_top01 |= top01_bits[_source_row(j, rows)]
            covered_top1 |= top1_bits[_source_row(j, rows)]

        if count:
            tier_counts.append((int(tier), int(count)))
        if len(selected) >= board_size:
            break

    if len(selected) != board_size:
        raise RuntimeError(f"COMMON_WORLD_SELECTION_INCOMPLETE:{len(selected)}:{board_size}")

    max_overlap = 0
    for a in range(len(selected_structures)):
        pa = set(selected_structures[a].players)
        for b in range(a):
            max_overlap = max(max_overlap, len(pa.intersection(selected_structures[b].players)))

    return PortfolioSelection(
        positions=np.asarray(selected, dtype=np.int64),
        rnwd_control_positions=np.asarray(rnwd_positions, dtype=np.int64),
        quality_tier=np.asarray(tiers, dtype=np.int64),
        primary_delta=float(primary_delta),
        lcb_delta=float(lcb_delta),
        frontier_size=int(np.sum(tiers == 0)),
        selected_tier_counts=tuple(tier_counts),
        unique_macro_spines=len({s.macro_spine_key for s in selected_structures}),
        unique_pitcher_pairs=len({s.pitcher_pair_key for s in selected_structures}),
        unique_stack_keys=len({s.stack_key for s in selected_structures}),
        unique_families=len({s.family_key for s in selected_structures}),
        unique_salary_geometries=len({s.salary_geometry_key for s in selected_structures}),
        max_pairwise_player_overlap=int(max_overlap),
        rnwd_win_union_hits=_union_hits(win_bits, rnwd_positions, rows),
        rnwd_top01_union_hits=_union_hits(top01_bits, rnwd_positions, rows),
        rnwd_top1_union_hits=_union_hits(top1_bits, rnwd_positions, rows),
        selected_win_union_hits=int(_POP8[covered_win].sum()),
        selected_top01_union_hits=int(_POP8[covered_top01].sum()),
        selected_top1_union_hits=int(_POP8[covered_top1].sum()),
        selected_fullwheel_win_union_hits=int(_POP8[covered_fullwheel_win].sum()),
        selected_fullwheel_top01_union_hits=int(_POP8[covered_fullwheel_top01].sum()),
        marginal_hits_by_slot=tuple(marginal),
        fullwheel_marginal_hits_by_slot=tuple(fullwheel_marginal),
        same_world_authority_active=bool(same_world_authority_active),
        common_worlds=int(common_worlds),
    )


def selector_receipt(sel: PortfolioSelection, context: advisor.ContextProfile, candidate_count: int) -> dict[str, object]:
    return {
        "PATCH_ID": PATCH_ID,
        "SELECTOR_MODE": SELECTOR_MODE,
        "PRIMARY_OBJECTIVE": PRIMARY_OBJECTIVE,
        "CANDIDATE_COUNT": int(candidate_count),
        "COMMON_WORLDS": int(sel.common_worlds),
        "COMMON_WORLD_WEIGHTS": dict(COMMON_WORLD_WEIGHTS),
        "COMMON_WORLD_WEIGHT_RATIO": list(COMMON_WORLD_WEIGHT_RATIO),
        "RNWD_AUTHORITY_USED": False,
        "RNWD_CONTROL_ONLY": True,
        "RNWD_WIN_UNION_HITS": int(sel.rnwd_win_union_hits),
        "RNWD_TOP01_UNION_HITS": int(sel.rnwd_top01_union_hits),
        "RNWD_TOP1_UNION_HITS": int(sel.rnwd_top1_union_hits),
        "SELECTED_WIN_UNION_HITS": int(sel.selected_win_union_hits),
        "SELECTED_TOP01_UNION_HITS": int(sel.selected_top01_union_hits),
        "SELECTED_TOP1_UNION_HITS": int(sel.selected_top1_union_hits),
        "SELECTED_FULLWHEEL_WIN_UNION_HITS": int(sel.selected_fullwheel_win_union_hits),
        "SELECTED_FULLWHEEL_TOP01_UNION_HITS": int(sel.selected_fullwheel_top01_union_hits),
        "SELECTED_FULLWHEEL_WIN_UNION_RATE": sel.selected_fullwheel_win_union_hits / max(1, sel.common_worlds),
        "SELECTED_FULLWHEEL_TOP01_UNION_RATE": sel.selected_fullwheel_top01_union_hits / max(1, sel.common_worlds),
        "MARGINAL_EVENT_AUTHORITY": "LEXICOGRAPHIC_FULLWHEEL_WIN_FULLWHEEL_TOP01_WIN_TOP01_TOP1",
        "SAME_WORLD_AUTHORITY_ACTIVE": bool(sel.same_world_authority_active),
        "SELECTED_WIN_UNION_RATE": sel.selected_win_union_hits / max(1, sel.common_worlds),
        "SELECTED_TOP01_UNION_RATE": sel.selected_top01_union_hits / max(1, sel.common_worlds),
        "SELECTED_TOP1_UNION_RATE": sel.selected_top1_union_hits / max(1, sel.common_worlds),
        "MARGINAL_HITS_BY_SLOT": [list(x) for x in sel.marginal_hits_by_slot],
        "FULLWHEEL_MARGINAL_HITS_BY_SLOT": [list(x) for x in sel.fullwheel_marginal_hits_by_slot],
        "NONINFERIOR_FRONTIER_SIZE": int(sel.frontier_size),
        "PRIMARY_NONINFERIORITY_DELTA": float(sel.primary_delta),
        "LCB_NONINFERIORITY_DELTA": float(sel.lcb_delta),
        "SELECTED_TIER_COUNTS": [list(x) for x in sel.selected_tier_counts],
        "UNIQUE_MACRO_SPINES_SELECTED": int(sel.unique_macro_spines),
        "UNIQUE_PITCHER_PAIRS_SELECTED": int(sel.unique_pitcher_pairs),
        "UNIQUE_STACK_KEYS_SELECTED": int(sel.unique_stack_keys),
        "MAX_PAIRWISE_PLAYER_OVERLAP": int(sel.max_pairwise_player_overlap),
        "PARENT_SELECTOR_PATCH_ID": parent.PATCH_ID,
        "POSTLOCK_RESULTS_USED_BY_SELECTOR": False,
        "HARD_PLAYER_EXPOSURE_CAP_USED": False,
        "HARD_FAMILY_QUOTAS_USED": False,
        "HARD_PITCHER_PAIR_QUOTAS_USED": False,
        "WEIGHTED_STATIC_METRIC_SUM_USED": False,
        "WEIGHTED_MARGINAL_EVENT_COVERAGE_USED": True,
        "LEXICOGRAPHIC_FULL_WHEEL_EVENT_COVERAGE_USED": bool(sel.same_world_authority_active),
        "FIELD_CONTEXT": context.as_dict(),
    }
