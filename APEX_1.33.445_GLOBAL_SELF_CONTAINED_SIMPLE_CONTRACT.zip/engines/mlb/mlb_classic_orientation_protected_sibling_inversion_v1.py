from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

import numpy as np

PATCH_ID = 'MLB_CLASSIC_ORIENTATION_PROTECTED_SIBLING_INVERSION_v1'
PATCH_REVISION = 2
CERTIFICATION_CLASS = 'HISTORICAL_CAUSAL_TRIANGULATION'
FORWARD_FIREWALL = (
    'NO_PLAYER_NAME_RULES',
    'NO_TEAM_NAME_RULES',
    'NO_CONTEST_POINTS',
    'NO_CONTEST_RANK',
    'NO_ACTUAL_FPTS',
    'NO_POSTLOCK_OWNERSHIP',
    'NO_WINNER_IDENTITY',
    'NO_ENTRY_NAME',
)
MAX_FIELD_SIZE = 10_000
MIN_TROPHY_HIT_RETENTION = 0.90
MAX_SWAPS = 2
HARD_PLAYER_EXPOSURE_CAP = 7

_POPCOUNT = np.asarray([int(i).bit_count() for i in range(256)], dtype=np.uint8)


@dataclass(frozen=True)
class CandidateView:
    position: int
    lineup_id: str
    players: tuple[int, ...]
    pitcher_pair: tuple[int, int]
    pattern: str
    stack_signature: str
    primary_team: str
    primary_players: tuple[int, ...]
    secondary_team: str
    secondary_players: tuple[int, int]
    singleton_team: str
    singleton_player: int
    secondary_orders: tuple[int, int]
    top01_hits: int


def _is_adjacent_pair(orders: tuple[int, int]) -> bool:
    a, b = sorted(map(int, orders))
    return (b - a == 1) or (a == 1 and b == 9)


def _orientation_view(
    position: int,
    candidate: Any,
    roster: Mapping[str, Any],
    by_idx: Mapping[int, Mapping[str, Any]],
    top01_hits: int,
) -> CandidateView | None:
    if str(roster.get('pattern', '')) != '5-2-1':
        return None
    lineup = tuple(map(int, roster['lineup']))
    pitcher_pair = tuple(sorted(map(int, roster['pitcher_pair'])))
    hitter_ids = tuple(i for i in lineup if i not in pitcher_pair)
    counts = Counter(str(by_idx[i]['team']) for i in hitter_ids)
    if sorted(counts.values(), reverse=True) != [5, 2, 1]:
        return None
    primary_team = next(t for t, n in counts.items() if n == 5)
    secondary_team = next(t for t, n in counts.items() if n == 2)
    singleton_team = next(t for t, n in counts.items() if n == 1)
    primary_players = tuple(sorted(i for i in hitter_ids if str(by_idx[i]['team']) == primary_team))
    secondary_players = tuple(sorted(i for i in hitter_ids if str(by_idx[i]['team']) == secondary_team))
    singleton_player = next(i for i in hitter_ids if str(by_idx[i]['team']) == singleton_team)
    orders = tuple(sorted(int(by_idx[i]['lineup']) for i in secondary_players if by_idx[i].get('lineup') is not None))
    if len(orders) != 2:
        return None
    return CandidateView(
        position=int(position), lineup_id=str(candidate.lineup_id), players=tuple(sorted(lineup)),
        pitcher_pair=pitcher_pair, pattern='5-2-1', stack_signature=str(roster.get('stack_signature', '')),
        primary_team=primary_team, primary_players=primary_players,
        secondary_team=secondary_team, secondary_players=secondary_players,
        singleton_team=singleton_team, singleton_player=int(singleton_player),
        secondary_orders=orders, top01_hits=int(top01_hits),
    )


def _same_sibling_door(parent: CandidateView, alt: CandidateView) -> bool:
    if parent.position == alt.position:
        return False
    if parent.pitcher_pair != alt.pitcher_pair:
        return False
    if parent.pattern != alt.pattern or parent.stack_signature != alt.stack_signature:
        return False
    if parent.primary_team != alt.primary_team or parent.primary_players != alt.primary_players:
        return False
    if parent.secondary_team != alt.secondary_team:
        return False
    if parent.singleton_team != alt.singleton_team or parent.singleton_player != alt.singleton_player:
        return False
    if len(set(parent.players) & set(alt.players)) != 9:
        return False
    if parent.secondary_orders == alt.secondary_orders:
        return False
    if not _is_adjacent_pair(alt.secondary_orders):
        return False
    return True


def _exposure_counts(positions: Sequence[int], views: Mapping[int, CandidateView]) -> Counter[int]:
    out: Counter[int] = Counter()
    for pos in positions:
        view = views.get(int(pos))
        if view is not None:
            out.update(view.players)
    return out


def apply_orientation_protected_sibling_inversion(
    selected_positions: Sequence[int],
    selector_candidates: Sequence[Any],
    row_by_lineup_id: Mapping[str, Mapping[str, Any]],
    by_idx: Mapping[int, Mapping[str, Any]],
    top01_bits: np.ndarray,
    *,
    field_size: int,
    board_size: int,
    min_trophy_hit_retention: float = MIN_TROPHY_HIT_RETENTION,
    hard_player_exposure_cap: int = HARD_PLAYER_EXPOSURE_CAP,
    max_swaps: int = MAX_SWAPS,
    max_field_size: int = MAX_FIELD_SIZE,
) -> tuple[list[int], dict[str, Any]]:
    selected = list(map(int, selected_positions))
    receipt: dict[str, Any] = {
        'PATCH_ID': PATCH_ID,
        'PATCH_REVISION': PATCH_REVISION,
        'CERTIFICATION_CLASS': CERTIFICATION_CLASS,
        'FORWARD_FIREWALL': list(FORWARD_FIREWALL),
        'FORWARD_FIREWALL_ASSERTED': True,
        'IDEMPOTENCY_GUARD': True,
        'STATUS': 'NOT_TRIGGERED',
        'FIELD_SIZE': int(field_size),
        'MAX_FIELD_SIZE': int(max_field_size),
        'BOARD_SIZE': int(board_size),
        'MIN_TROPHY_HIT_RETENTION': float(min_trophy_hit_retention),
        'HARD_PLAYER_EXPOSURE_CAP': int(hard_player_exposure_cap),
        'MAX_SWAPS': int(max_swaps),
        'PLAYER_NAME_RULES': False,
        'TEAM_NAME_RULES': False,
        'CONTEST_FIELDS_USED': False,
        'POSTLOCK_FIELDS_USED': False,
        'COMMON_WORLD_TOP01_BITS_USED': True,
        'CANONICAL_ORIENTATION_RULE': 'DEEPEST_ADJACENT_OR_WRAP_SECONDARY_PAIR_WITH_MINIMUM_TAIL_RETENTION',
        'SWAPS': [],
    }
    if int(field_size) > int(max_field_size):
        receipt['STATUS'] = 'FIELD_BUCKET_BYPASS'
        receipt['FINAL_POSITIONS'] = selected
        return selected, receipt
    if len(selected) != int(board_size) or board_size <= 0:
        receipt['STATUS'] = 'BOARD_SIZE_BYPASS'
        receipt['FINAL_POSITIONS'] = selected
        return selected, receipt
    if len(set(selected)) != len(selected):
        raise ValueError('ORIENTATION_SIBLING_DUPLICATE_INPUT_BOARD_POSITION')
    if (
        isinstance(top01_bits, tuple)
        and len(top01_bits) == 3
        and top01_bits[0] == 'APEX_INDEXED_WORLD_BITS_V1'
    ):
        base_bits = np.asarray(top01_bits[1], dtype=np.uint8)
        row_indices = np.asarray(top01_bits[2], dtype=np.int64)
        if base_bits.ndim != 2 or row_indices.ndim != 1 or len(row_indices) != len(selector_candidates):
            raise ValueError('ORIENTATION_SIBLING_INDEXED_TOP01_BITS_SHAPE_MISMATCH')
        if len(row_indices) and (int(row_indices.min()) < 0 or int(row_indices.max()) >= base_bits.shape[0]):
            raise ValueError('ORIENTATION_SIBLING_INDEXED_TOP01_BITS_RANGE_MISMATCH')
        hit_counts = np.empty(len(row_indices), dtype=np.int32)
        block = 4096
        for start in range(0, len(row_indices), block):
            idx = row_indices[start:start + block]
            hit_counts[start:start + len(idx)] = _POPCOUNT[base_bits[idx]].sum(axis=1, dtype=np.int32)
    else:
        bits = np.asarray(top01_bits, dtype=np.uint8)
        if bits.ndim != 2 or bits.shape[0] != len(selector_candidates):
            raise ValueError('ORIENTATION_SIBLING_TOP01_BITS_SHAPE_MISMATCH')
        hit_counts = _POPCOUNT[bits].sum(axis=1, dtype=np.int32)
    views: dict[int, CandidateView] = {}
    for j, candidate in enumerate(selector_candidates):
        roster = row_by_lineup_id[str(candidate.lineup_id)]
        view = _orientation_view(j, candidate, roster, by_idx, int(hit_counts[j]))
        if view is not None:
            views[j] = view
    exposure = _exposure_counts(selected, views)
    # Account for non-5-2-1 selected lineups too, since the cap is board-global.
    for pos in selected:
        if pos in views:
            continue
        roster = row_by_lineup_id[str(selector_candidates[pos].lineup_id)]
        exposure.update(map(int, roster['lineup']))

    input_max_exposure = int(max((n for n in exposure.values() if n > 0), default=0))
    receipt['INPUT_MAX_PLAYER_EXPOSURE'] = input_max_exposure
    receipt['INPUT_EXPOSURE_CAP_PASS'] = input_max_exposure <= int(hard_player_exposure_cap)
    if input_max_exposure > int(hard_player_exposure_cap):
        receipt['STATUS'] = 'INPUT_EXPOSURE_CAP_BREACH_NO_MUTATION'
        receipt['SWAP_COUNT'] = 0
        receipt['MAX_PLAYER_EXPOSURE'] = input_max_exposure
        receipt['EXPOSURE_CAP_PASS'] = False
        receipt['UNIQUE_BOARD_POSITIONS_PASS'] = True
        receipt['FINAL_POSITIONS'] = list(map(int, selected))
        return selected, receipt

    swaps = 0
    for slot, parent_pos in enumerate(list(selected)):
        if swaps >= int(max_swaps):
            break
        parent = views.get(parent_pos)
        if parent is None or parent.top01_hits <= 0:
            continue
        # Canonical representative of a sibling door: the deepest adjacent/wrap
        # secondary orientation that retains the parent's common-world tail mass.
        # Including the parent itself when already adjacent makes the operation
        # idempotent: a protected board cannot oscillate on a second invocation.
        eligible: list[tuple[int, int, float, int, str, CandidateView]] = []
        selected_set = set(selected)
        if _is_adjacent_pair(parent.secondary_orders):
            a, b = parent.secondary_orders
            eligible.append((min(a,b), max(a,b), 1.0, int(parent.top01_hits), parent.lineup_id, parent))
        for alt_pos, alt in views.items():
            if alt_pos in selected_set:
                continue
            if not _same_sibling_door(parent, alt):
                continue
            retention = float(alt.top01_hits) / float(parent.top01_hits)
            if retention + 1e-12 < float(min_trophy_hit_retention):
                continue
            # Hard cap is evaluated after removing parent and adding alternate.
            trial = exposure.copy()
            trial.subtract(parent.players)
            trial.update(alt.players)
            if max((n for n in trial.values() if n > 0), default=0) > int(hard_player_exposure_cap):
                continue
            a, b = alt.secondary_orders
            eligible.append((min(a,b), max(a,b), retention, int(alt.top01_hits), alt.lineup_id, alt))
        if not eligible:
            continue
        eligible.sort(key=lambda x: (-x[0], -x[1], -x[2], -x[3], x[4]))
        _, _, retention, _, _, alt = eligible[0]
        if alt.position == parent.position:
            continue
        exposure.subtract(parent.players)
        exposure.update(alt.players)
        selected[slot] = int(alt.position)
        swaps += 1
        receipt['SWAPS'].append({
            'BOARD_SLOT': int(slot + 1),
            'PARENT_LINEUP_ID': parent.lineup_id,
            'ALTERNATE_LINEUP_ID': alt.lineup_id,
            'PARENT_SECONDARY_ORDERS': list(parent.secondary_orders),
            'ALTERNATE_SECONDARY_ORDERS': list(alt.secondary_orders),
            'PARENT_TOP01_HITS': int(parent.top01_hits),
            'ALTERNATE_TOP01_HITS': int(alt.top01_hits),
            'TROPHY_HIT_RETENTION': float(retention),
            'PLAYER_OVERLAP': 9,
        })
    if len(set(selected)) != len(selected):
        raise ValueError('ORIENTATION_SIBLING_DUPLICATE_OUTPUT_BOARD_POSITION')
    max_exposure = int(max((n for n in exposure.values() if n > 0), default=0))
    if max_exposure > int(hard_player_exposure_cap):
        raise ValueError('ORIENTATION_SIBLING_EXPOSURE_CAP_BREACH')
    receipt['SWAP_COUNT'] = int(swaps)
    receipt['MAX_PLAYER_EXPOSURE'] = max_exposure
    receipt['EXPOSURE_CAP_PASS'] = True
    receipt['UNIQUE_BOARD_POSITIONS_PASS'] = True
    receipt['FINAL_POSITIONS'] = list(map(int, selected))
    receipt['STATUS'] = 'TRIGGERED' if swaps else 'NO_ELIGIBLE_SIBLING_NOOP'
    return selected, receipt
