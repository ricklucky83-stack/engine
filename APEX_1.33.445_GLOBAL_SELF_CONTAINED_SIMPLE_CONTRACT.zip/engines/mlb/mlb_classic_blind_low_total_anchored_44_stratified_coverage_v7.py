from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from itertools import combinations
from typing import Any, Callable, Mapping, Sequence

GENERATOR_PATCH_ID = 'MLB_CLASSIC_BLIND_LOW_TOTAL_ANCHORED_44_STRATIFIED_COVERAGE_v7'
HANDOFF_PATCH_ID = 'MLB_CLASSIC_BLIND_RS44_NATIVE_SHADOW_RECURRENCE_RESERVE_v7'
MAX_ACTIVE_TEAMS = 8
LOW_TOTAL_CUT = 4.0
STRATA = 32
PER_TEAM_PAIR_ACCEPTED_CAP = 600
FLOOR_ROWS_PER_STACK_FAMILY = 19
GLOBAL_FLOOR_RESERVE_CAP = 76

# Rep modes are deliberately symmetric. MID/MID is followed immediately by both
# directional MID/LAST variants so team ordering cannot create a one-sided lane.
REP_MODES = (
    ('MID', 'MID'),
    ('LAST', 'LAST'),
    ('FIRST', 'FIRST'),
    ('LAST', 'MID'), ('MID', 'LAST'),
)


def _split_bounds(n: int, strata: int = STRATA) -> list[tuple[int, int]]:
    if n <= 0:
        return []
    s = max(1, min(int(strata), n))
    q, r = divmod(n, s)
    out=[]; st=0
    for i in range(s):
        width=q+(1 if i<r else 0)
        out.append((st, st+width))
        st += width
    return out


def stratified_representatives(rows: Sequence[Any], strata: int = STRATA) -> list[dict[str, Any]]:
    out=[]
    for sid,(st,ed) in enumerate(_split_bounds(len(rows), strata)):
        if ed <= st:
            continue
        positions = {
            'FIRST': st,
            'MID': st + (ed-st)//2,
            'LAST': ed-1,
        }
        dedup={}
        for rep,pos in positions.items():
            dedup.setdefault(pos, []).append(rep)
        for pos,reps in sorted(dedup.items()):
            out.append({'stratum':sid,'rank0':pos,'rank1':pos+1,'reps':tuple(reps),'row':rows[pos]})
    return out


def _rep_index(reps: Sequence[dict[str,Any]]) -> dict[tuple[int,str], dict[str,Any]]:
    out={}
    for rec in reps:
        for rep in rec['reps']:
            out[(int(rec['stratum']), str(rep))] = rec
    return out


def _pair_salary(pp: Sequence[int], by_idx: Mapping[int, Mapping[str,Any]]) -> int:
    return int(by_idx[int(pp[0])]['salary']) + int(by_idx[int(pp[1])]['salary'])


def _min_salary_legal_binding(
    *,
    hitters: tuple[int,...],
    pitcher_pairs: Sequence[tuple[tuple[int,int], float]],
    by_idx: Mapping[int, Mapping[str,Any]],
    salary_min: int,
    salary_max: int,
    materialize: Callable[..., dict[str,Any] | None],
    row_meta: Mapping[str,Any],
) -> dict[str,Any] | None:
    hsalary = sum(int(by_idx[i]['salary']) for i in hitters)
    eligible=[]
    for pp, tail in pitcher_pairs:
        psal=_pair_salary(pp,by_idx)
        total=hsalary+psal
        if salary_min <= total <= salary_max:
            eligible.append((psal, -float(tail), tuple(pp)))
    eligible.sort(key=lambda x:(x[0],x[1],x[2]))
    for _,__,pp in eligible:
        # Runtime materializer owns position, team-cap, opponent-pitcher conflict,
        # dedupe, exact lineup ordering, ownership and pre-score authority.
        row = materialize(
            tuple(sorted(hitters)),
            tuple(pp),
            '4-4',
            '4_X_FAMILIES',
            birth_source=GENERATOR_PATCH_ID,
        )
        if row is not None:
            row.update(row_meta)
            return row
    return None


def apply_generator(
    *,
    phase2: list[dict[str,Any]],
    combo_pool: Mapping[tuple[str,int], Sequence[tuple[tuple[int,...],int,float]]],
    teams: Sequence[str],
    team_total: Mapping[str,float],
    pitcher_pairs: Sequence[tuple[tuple[int,int],float]],
    by_idx: Mapping[int, Mapping[str,Any]],
    salary_min: int,
    salary_max: int,
    materialize: Callable[..., dict[str,Any] | None],
    max_active_teams: int = MAX_ACTIVE_TEAMS,
    low_total_cut: float = LOW_TOTAL_CUT,
    per_team_pair_cap: int = PER_TEAM_PAIR_ACCEPTED_CAP,
) -> tuple[list[dict[str,Any]], dict[str,Any]]:
    teams=tuple(sorted(map(str,teams)))
    if len(teams)>int(max_active_teams):
        return [], {'PATCH_ID':GENERATOR_PATCH_ID,'STATUS':'NOOP_SCOPE','ACTIVE_TEAMS':len(teams),'MAX_ACTIVE_TEAMS':int(max_active_teams),'ROWS_ADDED':0,'POSTLOCK_INPUT_USED':False}
    eligible_pairs=[p for p in combinations(teams,2) if min(float(team_total.get(p[0],99.0)),float(team_total.get(p[1],99.0))) < float(low_total_cut)]
    reps_by_team={}
    idx_by_team={}
    for t in teams:
        reps=stratified_representatives(combo_pool.get((t,4),()), STRATA)
        reps_by_team[t]=reps
        idx_by_team[t]=_rep_index(reps)
    added=[]; attempted=0; ordinal=0; pair_counts={}
    for ta,tb in eligible_pairs:
        accepted=0
        ia,ib=idx_by_team[ta],idx_by_team[tb]
        sa=sorted({k[0] for k in ia}); sb=sorted({k[0] for k in ib})
        # Full stratum-cell coverage is traversed for each symmetric rep mode.
        for ra,rb in REP_MODES:
            for a_sid in sa:
                a=ia.get((a_sid,ra))
                if a is None: continue
                for b_sid in sb:
                    b=ib.get((b_sid,rb))
                    if b is None: continue
                    attempted += 1
                    ha=tuple(map(int,a['row'][0])); hb=tuple(map(int,b['row'][0]))
                    hitters=tuple(sorted(ha+hb))
                    ordinal += 1
                    row=_min_salary_legal_binding(
                        hitters=hitters,pitcher_pairs=pitcher_pairs,by_idx=by_idx,
                        salary_min=int(salary_min),salary_max=int(salary_max),materialize=materialize,
                        row_meta={
                            'rs44_team_pair':(ta,tb),
                            'rs44_stratum_a':int(a_sid),'rs44_stratum_b':int(b_sid),
                            'rs44_rep_a':ra,'rs44_rep_b':rb,
                            'rs44_combo_rank_a':int(a['rank1']),'rs44_combo_rank_b':int(b['rank1']),
                            'rs44_generation_ordinal':int(ordinal),
                        },
                    )
                    if row is None:
                        continue
                    phase2.append(row); added.append(row); accepted += 1
                    if accepted >= int(per_team_pair_cap):
                        break
                if accepted >= int(per_team_pair_cap): break
            if accepted >= int(per_team_pair_cap): break
        pair_counts[f'{ta}|{tb}']=accepted
    receipt={
        'PATCH_ID':GENERATOR_PATCH_ID,'STATUS':'PASS','ACTIVE_TEAMS':len(teams),
        'MAX_ACTIVE_TEAMS':int(max_active_teams),'LOW_TOTAL_CUT':float(low_total_cut),
        'STRATA':STRATA,'REP_MODES':[list(x) for x in REP_MODES],
        'PER_TEAM_PAIR_ACCEPTED_CAP':int(per_team_pair_cap),
        'ELIGIBLE_TEAM_PAIRS':len(eligible_pairs),'ATTEMPTED_HITTER_CORES':int(attempted),
        'ROWS_ADDED':len(added),'ROWS_BY_TEAM_PAIR':pair_counts,
        'PITCHER_BINDING':'MINIMUM_SALARY_LEGAL_PAIR_FIRST',
        'PRELOCK_ONLY':True,'POSTLOCK_INPUT_USED':False,'PLAYER_IDENTITY_TARGETING':False,
        'TEAM_IDENTITY_TARGETING':False,'CONTEST_RESULT_TARGETING':False,
    }
    return added, receipt


def salary_floor_reserve_indices(
    phase2: Sequence[Mapping[str,Any]], *, salary_min: int,
    per_family_cap: int = FLOOR_ROWS_PER_STACK_FAMILY,
    global_cap: int = GLOBAL_FLOOR_RESERVE_CAP,
) -> tuple[list[int],dict[str,Any]]:
    fam=defaultdict(list)
    for i,r in enumerate(phase2):
        if r.get('birth_source') != GENERATOR_PATCH_ID: continue
        if int(r.get('salary',-1)) != int(salary_min): continue
        fam[str(r.get('stack_signature',''))].append(i)
    picks=[]
    for key in sorted(fam):
        ids=sorted(fam[key], key=lambda i:(int(phase2[i].get('rs44_generation_ordinal',10**18)), str(phase2[i].get('lineup_id',''))))
        picks.extend(ids[:max(0,int(per_family_cap))])
    picks=sorted(dict.fromkeys(picks), key=lambda i:(int(phase2[i].get('rs44_generation_ordinal',10**18)), i))[:max(0,int(global_cap))]
    return picks, {
        'PATCH_ID':HANDOFF_PATCH_ID,'FLOOR_ROWS_FOUND':sum(len(v) for v in fam.values()),
        'FAMILIES_WITH_FLOOR_ROWS':len(fam),'PER_FAMILY_CAP':int(per_family_cap),
        'GLOBAL_CAP':int(global_cap),'RESERVE_ROWS':len(picks),'SALARY_FLOOR':int(salary_min),
        'PRELOCK_ONLY':True,'POSTLOCK_INPUT_USED':False,
    }


def fixed_budget_replace(
    *,
    phase2: Sequence[Mapping[str,Any]],
    recurrence_order: Sequence[int],
    active_qualified_ids: set[int],
    base_top_ids: set[int],
    budget: int,
    reserve_ids: Sequence[int],
) -> tuple[set[int],dict[str,Any]]:
    budget=max(0,int(budget))
    reserve=list(dict.fromkeys(int(i) for i in reserve_ids))
    reserve=reserve[:budget]
    reserve_set=set(reserve)
    native=lambda i: phase2[int(i)].get('birth_source') != GENERATOR_PATCH_ID
    native_mandatory={int(i) for i in active_qualified_ids if native(i) and int(i) not in base_top_ids}
    capacity=max(0,budget-len(reserve_set))
    if len(native_mandatory)>capacity:
        raise RuntimeError(f'RUN_INVALID:{HANDOFF_PATCH_ID}:NATIVE_MANDATORY_ROWS_EXCEED_CAPACITY')
    selected=set(reserve_set)|set(native_mandatory)
    for i in recurrence_order:
        i=int(i)
        if len(selected)>=budget: break
        if native(i): selected.add(i)
    if len(selected)<budget:
        for i in recurrence_order:
            i=int(i)
            if len(selected)>=budget: break
            selected.add(i)
    if len(selected)>budget:
        raise RuntimeError(f'RUN_INVALID:{HANDOFF_PATCH_ID}:BUDGET_OVERFLOW')
    return selected, {
        'PATCH_ID':HANDOFF_PATCH_ID,'STATUS':'PASS','PHASE3_BUDGET':budget,
        'ACTIVE_NATIVE_STRUCTURAL_MANDATORY_ROWS':len(native_mandatory),
        'RESERVE_ROWS_ADMITTED':len(reserve_set),
        'NATIVE_ROWS_SELECTED':sum(1 for i in selected if native(i)),
        'PATCH_ROWS_SELECTED':sum(1 for i in selected if not native(i)),
        'FINAL_ROWS':len(selected),'FIXED_BUDGET_REPLACEMENT':True,
        'NATIVE_RECURRENCE_PRESERVATION':True,
        'POSTLOCK_INPUT_USED':False,'SELECTOR_MUTATION':False,
    }
