#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, json, os, subprocess, sys, time
from pathlib import Path

PATCH_ID='MLB_SHOWDOWN_TERMINAL_DURABLE_COMMIT_v1'
SCHEMA_VERSION='1.2.0'
CONTINUE_RC=75
INTERNAL_SUBCHUNK_CONTINUE_RC=76
BASE=Path(__file__).resolve().parent
STATE_ROOT=BASE.parents[1]
SOURCE=BASE/'mlb_showdown_raw_pool_runtime_v1_7.py'
WORKER=STATE_ROOT/'engines/common/mlb_showdown_execution_window_checkpoint_runner_v1.py'
EXECUTION_ID=str(os.environ.get('APEX_EXECUTION_ID','UNSET'))
OUT=Path(os.environ.get('APEX_OUTPUT_DIR','/mnt/data')).resolve()
POOL=Path(os.environ.get('APEX_PLAYER_POOL','')).resolve()
FIELD_SIZE=int(os.environ.get('APEX_FIELD_SIZE','0') or 0)
RUN_ROOT=Path(os.environ.get('APEX_RESUMABLE_RUN_ROOT',str(OUT/f'.apex_mlb_showdown_{EXECUTION_ID}'))).resolve()
CTRL_ROOT=RUN_ROOT/'mlb_showdown_engine_owned_resume_v1'
CTRL_ROOT.mkdir(parents=True,exist_ok=True)
STATE_PATH=CTRL_ROOT/'controller_state.json'
SOURCE_SHA=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
WORKER_SHA=hashlib.sha256(WORKER.read_bytes()).hexdigest()
POOL_SHA=hashlib.sha256(POOL.read_bytes()).hexdigest() if POOL.exists() else ''

if not POOL.exists(): raise RuntimeError('RUN_INVALID:MLB_SD_CHUNK_STREAM_PLAYER_POOL_MISSING')
if FIELD_SIZE<=0: raise RuntimeError('RUN_INVALID:MLB_SD_CHUNK_STREAM_FIELD_SIZE_INVALID')

def atomic_json(path:Path,obj:dict)->None:
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8') as f:
        json.dump(obj,f,indent=2,sort_keys=True); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)

def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()

def _identity()->dict:
    return {
        'SCHEMA_VERSION':SCHEMA_VERSION,'PATCH_ID':PATCH_ID,'POOL_SHA256':POOL_SHA,
        'FIELD_SIZE':FIELD_SIZE,'EXECUTION_ID':EXECUTION_ID,'SOURCE_SHA256':SOURCE_SHA,
        'WORKER_SHA256':WORKER_SHA,'STATE_VERSION':str(os.environ.get('APEX_GLOBAL_STATE_VERSION') or 'UNSPECIFIED'),
    }

def _run_statement_bounds()->list[tuple[int,int,str]]:
    tree=ast.parse(SOURCE.read_text(encoding='utf-8'))
    runs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run']
    if len(runs)!=1: raise RuntimeError(f'RUN_INVALID:MLB_SD_RUN_FUNCTION_NOT_UNIQUE:{len(runs)}')
    body=runs[0].body
    lines=SOURCE.read_text(encoding='utf-8').splitlines()
    def hit(fragment:str, exact:bool=False):
        matches=[i+1 for i,line in enumerate(lines) if ((line.strip()==fragment) if exact else (fragment in line))]
        if len(matches)!=1: raise RuntimeError(f'RUN_INVALID:MLB_SD_STAGE_MARKER_NOT_UNIQUE:{fragment}:{len(matches)}')
        line_no=matches[0]
        q=[n for n in body if int(n.lineno)<=line_no<=int(n.end_lineno)]
        if not q: raise RuntimeError(f'RUN_INVALID:MLB_SD_STAGE_STATEMENT_MISSING:{fragment}')
        ends=sorted({int(n.end_lineno) for n in q})
        if len(ends)!=1: raise RuntimeError(f'RUN_INVALID:MLB_SD_STAGE_END_AMBIGUOUS:{fragment}:{ends}')
        return ends[0]
    # Each boundary is a complete run-body statement. This keeps source semantics exact.
    markers=[
        ('PREP_CALIBRATION',"PHASE2_INPUT_CALIBRATION_SHA256"),
        ('LEGAL_SURFACE',"STRUCTURAL_CONFLICT_HARD_REJECT_SURVIVED_PRE_PHASE2"),
        ('PHASE2_FIELD_THRESHOLDS',"field=choose_fake"),
        ('CROSS_WORLD_HANDOFF',"PHASE3_INPUT_CALIBRATION_SHA256"),
        ('ADAPTIVE_BUBBLE',"fm['trials']=trials_by_h",True),
        ('ELITE_SIBLINGS_AND_NATIVE_SELECTOR',"RUN_STATE='PROVISIONAL_BOARD_SEALED'"),
        ('AI_TERMINAL_AND_CHAMPIONSHIP_RESERVE',"_ai_receipt=terminal_ai_mod.write_review_surface("),
        ('FINAL_BOARD_AND_RECEIPTS',"print(json.dumps(dict(STATUS='PASS' if all(stress.values()) else 'FAIL'"),
    ]
    out=[]; start=int(body[0].lineno)
    for marker in markers:
        name,fragment=marker[0],marker[1]
        exact=bool(marker[2]) if len(marker)>2 else False
        end=int(hit(fragment,exact=exact)); out.append((start,end,name))
        later=[int(x.lineno) for x in body if int(x.lineno)>end]
        start=min(later) if later else end+1
    if out[-1][1]!=int(body[-1].end_lineno):
        raise RuntimeError(f'RUN_INVALID:MLB_SD_STAGE_COVERAGE_INCOMPLETE:{out[-1][1]}:{body[-1].end_lineno}')
    return out

STAGES=_run_statement_bounds()
IDENTITY=_identity()
if STATE_PATH.exists():
    try: state=json.loads(STATE_PATH.read_text(encoding='utf-8'))
    except Exception: state={}
    if state.get('IDENTITY')!=IDENTITY:
        stale=CTRL_ROOT.with_name(CTRL_ROOT.name+f'.stale.{time.time_ns()}')
        os.replace(CTRL_ROOT,stale); CTRL_ROOT.mkdir(parents=True,exist_ok=True); state={}
else: state={}
if not state:
    state={'PATCH_ID':PATCH_ID,'SCHEMA_VERSION':SCHEMA_VERSION,'IDENTITY':IDENTITY,'STAGE_INDEX':0,'COMPLETED_STAGES':[],'SUBCHUNK_CONTINUES':0,'EXECUTION_STATE':'RUNNING','LAST_CHECKPOINT':''}
    atomic_json(STATE_PATH,state)

idx=int(state.get('STAGE_INDEX',0))
if idx>=len(STAGES):
    board=OUT/f'DK_MLB_SD_{EXECUTION_ID}_FINAL_BOARD.csv'
    receipt=OUT/f'DK_MLB_SD_{EXECUTION_ID}_FINAL_RECEIPT.json'
    if board.exists() and receipt.exists():
        print(json.dumps({'RUN_STATE':'COMPLETE','EXECUTION_STATE':'TOOL_PROVEN_EXECUTED','PATCH_ID':PATCH_ID,'FINAL_BOARD_PATH':str(board),'FINAL_RECEIPT_PATH':str(receipt),'CONTROLLER_STATE':str(STATE_PATH)}),flush=True)
        raise SystemExit(0)
    raise RuntimeError('RUN_INVALID:MLB_SD_CHUNK_STREAM_TERMINAL_ARTIFACT_MISSING')

start,end,name=STAGES[idx]
prev=str(state.get('LAST_CHECKPOINT') or '')
ck_out=str(CTRL_ROOT/f'checkpoint_{idx:02d}_{name}.pkl')
env=dict(os.environ)
env.update({
    'APEX_CHUNK_STREAM_ONLY':'1','APEX_GLOBAL_CHUNK_STREAM_REQUIRED':'1',
    'APEX_CHUNK_STREAM_CROSS_WORLD_WINDOW_BUDGET':'1',
    'APEX_INTERNAL_SPLIT_SOURCE':str(SOURCE),'APEX_INTERNAL_SPLIT_SOURCE_SHA256':SOURCE_SHA,
    'APEX_INTERNAL_SPLIT_STAGE_NAME':name,'APEX_INTERNAL_SPLIT_START':str(start),'APEX_INTERNAL_SPLIT_END':str(end),
    'APEX_INTERNAL_SPLIT_CHECKPOINT_IN':prev,'APEX_INTERNAL_SPLIT_CHECKPOINT_OUT':ck_out,
    'APEX_INTERNAL_SPLIT_FINAL':'1' if idx==len(STAGES)-1 else '0',
})
cp=subprocess.run([sys.executable,str(WORKER)],env=env,cwd=str(STATE_ROOT),check=False)
if cp.returncode==INTERNAL_SUBCHUNK_CONTINUE_RC:
    state['SUBCHUNK_CONTINUES']=int(state.get('SUBCHUNK_CONTINUES',0))+1
    state['EXECUTION_STATE']='RESUMABLE'; atomic_json(STATE_PATH,state)
    wdir=OUT/f'DK_MLB_SD_{EXECUTION_ID}_CROSS_WORLD_V2'
    committed=len(list(wdir.glob('window_*.json'))) if wdir.exists() else 0
    print(json.dumps({'RUN_STATE':'CHECKPOINTED_CONTINUE','EXECUTION_STATE':'RESUMABLE','PATCH_ID':PATCH_ID,'COMPLETED_STAGE':f'{name}:WINDOW_{committed:02d}','NEXT_STAGE':name,'STAGE_INDEX':idx,'SUBCHUNK_CURSOR':committed,'CHECKPOINT':prev,'CONTROLLER_STATE':str(STATE_PATH)}),flush=True)
    raise SystemExit(CONTINUE_RC)
if cp.returncode!=0: raise SystemExit(cp.returncode)
if idx==len(STAGES)-1:
    state['STAGE_INDEX']=len(STAGES); state['EXECUTION_STATE']='COMPLETED'; state['COMPLETED_STAGES']=list(state.get('COMPLETED_STAGES',[]))+[name]; atomic_json(STATE_PATH,state)
    # The raw final stage emitted NATIVE_BOARD_READY and completed its receipts.
    raise SystemExit(0)
if not Path(ck_out).exists(): raise RuntimeError(f'RUN_INVALID:MLB_SD_CHUNK_CHECKPOINT_NOT_COMMITTED:{name}')
state['LAST_CHECKPOINT']=ck_out; state['STAGE_INDEX']=idx+1; state['EXECUTION_STATE']='RESUMABLE'; state['COMPLETED_STAGES']=list(state.get('COMPLETED_STAGES',[]))+[name]; atomic_json(STATE_PATH,state)
# Keep only the newest full-state checkpoint. Cross-world subchunks have their own atomic files.
for p in CTRL_ROOT.glob('checkpoint_*.pkl'):
    if p.resolve()!=Path(ck_out).resolve():
        try: p.unlink()
        except FileNotFoundError: pass
next_name=STAGES[idx+1][2]
print(json.dumps({'RUN_STATE':'CHECKPOINTED_CONTINUE','EXECUTION_STATE':'RESUMABLE','PATCH_ID':PATCH_ID,'COMPLETED_STAGE':name,'NEXT_STAGE':next_name,'STAGE_INDEX':idx+1,'CHECKPOINT':ck_out,'CHECKPOINT_SHA256':sha256_file(Path(ck_out)),'CONTROLLER_STATE':str(STATE_PATH)}),flush=True)
raise SystemExit(CONTINUE_RC)
