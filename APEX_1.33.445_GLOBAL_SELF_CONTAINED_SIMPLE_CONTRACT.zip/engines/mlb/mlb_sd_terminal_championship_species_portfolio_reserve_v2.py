from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import hashlib, json
import numpy as np
import pandas as pd

PATCH_ID='MLB_SD_TERMINAL_CHAMPIONSHIP_SPECIES_PORTFOLIO_RESERVE_v2'
BOARD_SIZE=5
CROSS_WORLD_TRIAD_SEATS=3
BALANCED_RESERVE_SEATS=2
EXTREME_CONCENTRATION_SHARE=0.80

@dataclass(frozen=True)
class ReserveResult:
    selected_ids: tuple[int,...]
    receipt: dict[str,Any]

def _playerset(row: pd.Series) -> frozenset[str]:
    return frozenset(str(row[x]).casefold() for x in ('CPT','UTIL1','UTIL2','UTIL3','UTIL4','UTIL5'))

def _overlap(a: pd.Series,b: pd.Series) -> int:
    return len(_playerset(a)&_playerset(b))

def _baseline_stats(board: pd.DataFrame)->dict[str,Any]:
    cpt=board['CPT'].astype(str); branch=board['BRANCH'].astype(str); sp=pd.to_numeric(board['SP_COUNT'],errors='coerce').fillna(9)
    return {
        'SAME_CPT_SHARE':float(cpt.value_counts(normalize=True).max()) if len(cpt) else 0.0,
        'FIVE_ONE_SHARE':float((branch=='5-1').mean()) if len(branch) else 0.0,
        'ZERO_SP_COUNT':int((sp==0).sum()),
    }

def _attach_recurrence(rows:pd.DataFrame, telemetry:dict[str,np.ndarray])->pd.DataFrame:
    ids=np.asarray(telemetry['candidate_ids'],dtype=np.int64)
    rec=np.asarray(telemetry['recurrence'],dtype=np.int16)
    mr=np.asarray(telemetry['minrank'],dtype=np.int16)
    if mr.shape[0]!=5: raise ValueError('RECURRENCE_WINDOW_COUNT_MUST_BE_5')
    t=pd.DataFrame({'LINEUP_ID':ids,'WORLD_COVERAGE_COUNT':rec})
    for i in range(5): t[f'WORLD_{i+1}_LOCAL_RANK']=mr[i]
    if 'added_mask' in telemetry:
        t['CROSS_WORLD_ADDED']=np.asarray(telemetry['added_mask'],dtype=bool)
    else:
        t['CROSS_WORLD_ADDED']=False
    out=rows.merge(t,on='LINEUP_ID',how='left')
    out['WORLD_COVERAGE_COUNT']=out['WORLD_COVERAGE_COUNT'].fillna(0).astype(np.int16)
    out['CROSS_WORLD_ADDED']=out['CROSS_WORLD_ADDED'].fillna(False).astype(bool)
    for i in range(5): out[f'WORLD_{i+1}_LOCAL_RANK']=out[f'WORLD_{i+1}_LOCAL_RANK'].fillna(99).astype(np.int16)
    out['CPT_ROLE_EVIDENCE']=pd.to_numeric(out['CPT_CONDITIONAL_SUPPORT'],errors='coerce').fillna(0)*pd.to_numeric(out['CPT_STRATEGIC_LEVERAGE'],errors='coerce').fillna(0)
    return out

def _family_table(rows:pd.DataFrame)->pd.DataFrame:
    d=rows.copy()
    if 'AI_PLAYERSET_CANONICAL' not in d:
        d['AI_PLAYERSET_CANONICAL']=d[['CPT','UTIL1','UTIL2','UTIL3','UTIL4','UTIL5']].astype(str).apply(lambda r:'|'.join(sorted(x.casefold() for x in r)),axis=1)
    d['REC4']=(d['WORLD_COVERAGE_COUNT']>=4).astype(np.int8)
    numeric=['MC_TOP_0_1_RATE','MC_WIN_RATE','MC_P99','AI_LINEUP_CONDITIONAL_SUPPORT_SUM','AI_MARKET_TAIL_SUPPORT_PCTL','PROJECTED_EXACT_MATCH_DUPLICATION','SP_COUNT']
    for c in numeric:
        d[c]=pd.to_numeric(d[c],errors='coerce')
    g=d.groupby('AI_PLAYERSET_CANONICAL',sort=False,observed=True)
    agg=g.agg(
        N_ORIENT=('LINEUP_ID','count'),
        MAX_REC=('WORLD_COVERAGE_COUNT','max'),SUM_REC=('WORLD_COVERAGE_COUNT','sum'),REC4_ORIENT=('REC4','sum'),
        ANY_CROSS_WORLD_ADDED=('CROSS_WORLD_ADDED','max'),
        SUM_TOP01=('MC_TOP_0_1_RATE','sum'),MAX_TOP01=('MC_TOP_0_1_RATE','max'),MAX_WIN=('MC_WIN_RATE','max'),MAX_P99=('MC_P99','max'),
        MAX_SUPPORT=('AI_LINEUP_CONDITIONAL_SUPPORT_SUM','max'),MAX_MARKET_TAIL=('AI_MARKET_TAIL_SUPPORT_PCTL','max'),MIN_DUP=('PROJECTED_EXACT_MATCH_DUPLICATION','min'),
        SP_COUNT_MIN=('SP_COUNT','min'),SP_COUNT_MAX=('SP_COUNT','max'),
    ).reset_index()
    mins=[]
    for i in range(5): mins.append(g[f'WORLD_{i+1}_LOCAL_RANK'].min().rename(f'FAM_W{i+1}_BEST_RANK'))
    m=pd.concat(mins,axis=1).reset_index(); agg=agg.merge(m,on='AI_PLAYERSET_CANONICAL',how='left')
    a=agg[[f'FAM_W{i}_BEST_RANK' for i in range(1,6)]].to_numpy()
    agg['FAMILY_RANK1_COV']=(a<=1).sum(axis=1); agg['FAMILY_TOP2_COV']=(a<=2).sum(axis=1)
    best=d.sort_values(['AI_PLAYERSET_CANONICAL','CPT_ROLE_EVIDENCE','CPT_CONDITIONAL_SUPPORT','CPT_MUTATION_SUPPORT','CPT','LINEUP_ID'],ascending=[True,False,False,False,True,True],kind='mergesort').drop_duplicates('AI_PLAYERSET_CANONICAL')
    best=best[['AI_PLAYERSET_CANONICAL','LINEUP_ID','CPT','BRANCH','ROUTE','CPT_ROLE_EVIDENCE']].rename(columns={'LINEUP_ID':'BEST_ROLE_LINEUP_ID','CPT':'BEST_ROLE_CPT','BRANCH':'BRANCH_MODE','ROUTE':'ROUTE_MODE','CPT_ROLE_EVIDENCE':'BEST_ROLE_SCORE'})
    return agg.merge(best,on='AI_PLAYERSET_CANONICAL',how='left')

def _cross_world_triad(fam:pd.DataFrame)->pd.DataFrame:
    e=fam[(fam['ANY_CROSS_WORLD_ADDED'])&(fam['SP_COUNT_MIN']==0)&(fam['FAMILY_RANK1_COV']==5)&(fam['FAMILY_TOP2_COV']==5)&(fam['REC4_ORIENT']>=1)].copy()
    return e.sort_values(['REC4_ORIENT','BEST_ROLE_SCORE','SUM_TOP01','SUM_REC','MAX_P99','AI_PLAYERSET_CANONICAL'],ascending=[False,False,False,False,False,True],kind='mergesort').head(CROSS_WORLD_TRIAD_SEATS)

def _balanced_reserve(fam:pd.DataFrame)->pd.DataFrame:
    e=fam[(fam['SP_COUNT_MIN']==0)&(fam['FAMILY_RANK1_COV']==5)&(fam['FAMILY_TOP2_COV']==5)&(fam['BRANCH_MODE']=='3-3')].copy()
    if e.empty: return e
    lanes=e.groupby('BEST_ROLE_CPT',as_index=False).agg(BEST_ROLE_SCORE=('BEST_ROLE_SCORE','max'),MAX_SUM_TOP01=('SUM_TOP01','max'))
    lanes=lanes.sort_values(['BEST_ROLE_SCORE','MAX_SUM_TOP01','BEST_ROLE_CPT'],ascending=[False,False,True],kind='mergesort').head(BALANCED_RESERVE_SEATS)
    picks=[]; metrics=['SUM_REC','SUM_TOP01','MAX_P99','MAX_SUPPORT','MAX_MARKET_TAIL']
    for cpt in lanes['BEST_ROLE_CPT']:
        s=e[e['BEST_ROLE_CPT']==cpt].copy(); p=pd.DataFrame(index=s.index)
        for m in metrics: p[m]=s[m].rank(pct=True,method='average')
        s['ROBUST_MIN']=p.min(axis=1); s['ROBUST_GMEAN']=np.exp(np.log(p.clip(1e-12)).mean(axis=1))
        s=s.sort_values(['ROBUST_MIN','ROBUST_GMEAN','SUM_TOP01','MAX_P99','AI_PLAYERSET_CANONICAL'],ascending=[False,False,False,False,True],kind='mergesort')
        picks.append(s.iloc[0])
    return pd.DataFrame(picks)

def select(rows:pd.DataFrame, baseline_board:pd.DataFrame, telemetry:dict[str,np.ndarray], board_size:int=BOARD_SIZE)->ReserveResult:
    if board_size!=5: raise ValueError('THIS_POLICY_IS_DEFINED_FOR_TOP5_ONLY')
    d=_attach_recurrence(rows,telemetry); fam=_family_table(d); st=_baseline_stats(baseline_board)
    reserve_ids=[]; triad_ids=[]; balanced_ids=[]
    if st['ZERO_SP_COUNT']<=1 and st['FIVE_ONE_SHARE']<EXTREME_CONCENTRATION_SHARE:
        tri=_cross_world_triad(fam); triad_ids=[int(x) for x in tri['BEST_ROLE_LINEUP_ID'].tolist()]; reserve_ids.extend(triad_ids)
    if st['SAME_CPT_SHARE']>=EXTREME_CONCENTRATION_SHARE and st['FIVE_ONE_SHARE']>=EXTREME_CONCENTRATION_SHARE:
        bal=_balanced_reserve(fam); balanced_ids=[int(x) for x in bal['BEST_ROLE_LINEUP_ID'].tolist()]
        reserve_ids=[x for x in reserve_ids if x not in balanced_ids][:max(0,board_size-len(balanced_ids))]+balanced_ids
    selected=[]
    for x in reserve_ids:
        if x not in selected and len(selected)<board_size: selected.append(x)
    for x in baseline_board['LINEUP_INDEX'].astype(int).tolist():
        if x not in selected and len(selected)<board_size: selected.append(x)
    if len(selected)!=board_size: raise RuntimeError(f'PORTFOLIO_SHORT_BOARD:{len(selected)}')
    by=d.set_index('LINEUP_ID')
    chosen=by.loc[selected]
    ovs=[]
    for i in range(len(chosen)):
        for j in range(i+1,len(chosen)): ovs.append(_overlap(chosen.iloc[i],chosen.iloc[j]))
    receipt={
        'PATCH_ID':PATCH_ID,'STATUS':'PASS','BOARD_SIZE':board_size,'BASELINE':st,
        'CROSS_WORLD_TRIAD_IDS':triad_ids,'BALANCED_RESERVE_IDS':balanced_ids,'SELECTED_IDS':selected,
        'MAX_PAIRWISE_PLAYER_OVERLAP':max(ovs) if ovs else 0,'AVG_PAIRWISE_PLAYER_OVERLAP':float(np.mean(ovs)) if ovs else 0.0,
        'POSTLOCK_RESULTS_USED':False,'PLAYER_NAME_CONSTANTS_USED':False,'CONTEST_RANK_USED':False,
        'CROSS_WORLD_ADDED_PROVENANCE_REQUIRED':True,'FAMILY_WORLD_COVERAGE_REQUIRED':True,
        'BASELINE_REPLACEMENT_OCCURRED':bool(selected!=baseline_board['LINEUP_INDEX'].astype(int).tolist()),
        'CALLER_CONTROLS_PRODUCTION_MUTATION':True,
    }
    return ReserveResult(tuple(selected),receipt)
