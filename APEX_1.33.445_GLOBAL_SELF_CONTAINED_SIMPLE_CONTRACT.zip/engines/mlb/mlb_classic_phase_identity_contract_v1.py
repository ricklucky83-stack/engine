from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from typing import Sequence

PATCH_ID = "MLB_CLASSIC_PHASE2_IDENTITY_CONTRACT_v1"


@dataclass(frozen=True)
class PhaseIdentityReceipt:
    patch_id: str
    phase2_count: int
    phase3_count: int
    handoff_count: int
    selector_count: int
    phase2_identity_hash: str
    phase3_identity_hash: str
    handoff_identity_hash: str
    selector_identity_hash: str
    duplicate_ids: int
    missing_from_phase3: int
    missing_from_handoff: int
    missing_from_selector: int
    unexpected_phase3: int
    unexpected_handoff: int
    unexpected_selector: int
    post_phase2_mutation_count: int
    status: str

    def to_receipt(self) -> dict[str, object]:
        return asdict(self)


def canonical_identity_hash(lineup_ids: Sequence[str]) -> str:
    canonical = sorted(str(x) for x in lineup_ids)
    payload = json.dumps(canonical, separators=(",", ":"), ensure_ascii=True).encode()
    return hashlib.sha256(payload).hexdigest()


def assert_phase_identity_contract(
    phase2_ids: Sequence[str],
    phase3_ids: Sequence[str],
    handoff_ids: Sequence[str],
    selector_ids: Sequence[str],
) -> PhaseIdentityReceipt:
    phases = {
        "phase2": tuple(str(x) for x in phase2_ids),
        "phase3": tuple(str(x) for x in phase3_ids),
        "handoff": tuple(str(x) for x in handoff_ids),
        "selector": tuple(str(x) for x in selector_ids),
    }
    duplicate_ids = sum(len(ids) - len(set(ids)) for ids in phases.values())
    p2 = set(phases["phase2"])
    deltas = {}
    for name in ("phase3", "handoff", "selector"):
        current = set(phases[name])
        deltas[f"missing_from_{name}"] = len(p2 - current)
        deltas[f"unexpected_{name}"] = len(current - p2)
    hashes = {name: canonical_identity_hash(ids) for name, ids in phases.items()}
    post_phase2_mutation_count = sum(deltas.values())
    status = "PASS" if duplicate_ids == 0 and post_phase2_mutation_count == 0 and len(set(hashes.values())) == 1 else "FAIL"
    receipt = PhaseIdentityReceipt(
        patch_id=PATCH_ID,
        phase2_count=len(phases["phase2"]),
        phase3_count=len(phases["phase3"]),
        handoff_count=len(phases["handoff"]),
        selector_count=len(phases["selector"]),
        phase2_identity_hash=hashes["phase2"],
        phase3_identity_hash=hashes["phase3"],
        handoff_identity_hash=hashes["handoff"],
        selector_identity_hash=hashes["selector"],
        duplicate_ids=int(duplicate_ids),
        missing_from_phase3=deltas["missing_from_phase3"],
        missing_from_handoff=deltas["missing_from_handoff"],
        missing_from_selector=deltas["missing_from_selector"],
        unexpected_phase3=deltas["unexpected_phase3"],
        unexpected_handoff=deltas["unexpected_handoff"],
        unexpected_selector=deltas["unexpected_selector"],
        post_phase2_mutation_count=int(post_phase2_mutation_count),
        status=status,
    )
    if receipt.status != "PASS":
        raise RuntimeError("ENGINE_INTEGRITY_HALT:PHASE2_PHASE3_HANDOFF_SELECTOR_IDENTITY_CONTRACT")
    return receipt
