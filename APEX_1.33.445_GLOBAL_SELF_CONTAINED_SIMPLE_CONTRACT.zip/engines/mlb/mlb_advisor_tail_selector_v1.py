from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence
import hashlib
import json
import math

import numpy as np

PATCH_ID = "MLB_ADVISOR_RIGHT_TAIL_PRIMARY_SELECTOR_v1"
SELECTOR_MODE = "TOP_0_1_PRIMARY_ORDERED_TIEBREAK"
PRIMARY_OBJECTIVE = "TOP_0_1_PERCENT_BOARD_CAPTURE"
WEIGHTED_METRIC_SUM_USED = False
HARD_FAMILY_QUOTAS_USED = False
HARD_PITCHER_PAIR_QUOTAS_USED = False


class AdvisorSelectorIntegrityError(RuntimeError):
    pass


PROHIBITED_METRIC_NAMES = frozenset({
    "PLAYER", "PLAYER_NAME", "NAME", "RAW_PROJECTION", "PROJECTION",
    "ACTUAL_FPTS", "POSTLOCK_FPTS", "CONTEST_RANK", "REALIZED_RESULT",
    "ORIGINAL_SELECTOR", "OBJECTIVE", "WEIGHTED_SCORE",
})


@dataclass(frozen=True)
class ContextProfile:
    field_size: int
    slate_games: int
    trials: int
    primary_tie_width: float
    leverage_priority: str

    def as_dict(self) -> dict[str, object]:
        return {
            "field_size": int(self.field_size),
            "slate_games": int(self.slate_games),
            "trials": int(self.trials),
            "primary_tie_width": float(self.primary_tie_width),
            "leverage_priority": str(self.leverage_priority),
        }


def context_profile(field_size: int, slate_games: int, trials: int) -> ContextProfile:
    """Field/slate-aware ranking context without changing the primary objective.

    The primary metric is always lineup Top-0.1 probability. Context only controls
    the width of the statistical near-tie bucket and ordering of secondary signals.
    That prevents duplication/correlation/portfolio terms from overcoming a
    materially stronger Top-0.1 path.
    """
    f = max(1, int(field_size))
    g = max(1, int(slate_games))
    t = max(1, int(trials))
    resolution = 1.0 / t
    # Bigger fields demand finer separation of actual trophy probability; small
    # fields tolerate a slightly wider statistical near-tie bucket. Never wider
    # than 5 basis points of absolute probability.
    field_component = 0.05 / f
    slate_component = 0.00002 * max(0.0, min(1.0, (6.0 - min(g, 6)) / 5.0))
    tie = float(min(0.0005, max(resolution, field_component + slate_component)))
    leverage_priority = "HIGH" if f >= 3000 else "MEDIUM" if f >= 500 else "LOW"
    return ContextProfile(f, g, t, tie, leverage_priority)


def _metric(metrics: Mapping[str, np.ndarray], name: str, n: int, default: float = 0.0) -> np.ndarray:
    if name not in metrics:
        return np.full(n, default, dtype=np.float64)
    arr = np.asarray(metrics[name], dtype=np.float64)
    if arr.ndim != 1 or len(arr) != n:
        raise AdvisorSelectorIntegrityError(f"BAD_SELECTOR_METRIC_SHAPE:{name}:{arr.shape}:{n}")
    return np.nan_to_num(arr, nan=-np.inf, posinf=np.inf, neginf=-np.inf)


def ranking_order(
    metrics: Mapping[str, np.ndarray],
    *,
    context: ContextProfile,
    primary_metric: str = "top01_rate",
    primary_lcb_metric: str = "top01_lcb",
) -> np.ndarray:
    """Lexicographic Top-0.1 ranking. No weighted metric sum is formed."""
    if primary_metric.upper() in PROHIBITED_METRIC_NAMES:
        raise AdvisorSelectorIntegrityError(f"PROHIBITED_SELECTOR_METRIC:{primary_metric}")
    if primary_metric not in metrics:
        raise AdvisorSelectorIntegrityError(f"MISSING_SELECTOR_METRIC:{primary_metric}")
    n = len(np.asarray(metrics[primary_metric]))
    primary = _metric(metrics, primary_metric, n)
    width = max(float(context.primary_tie_width), np.finfo(np.float64).eps)
    bucket = np.floor((primary + width * 0.5) / width)

    top01_lcb = _metric(metrics, primary_lcb_metric, n)
    win = _metric(metrics, "win_rate", n)
    cvar99 = _metric(metrics, "cvar99", n)
    p99 = _metric(metrics, "p99", n)
    p95 = _metric(metrics, "p95", n)
    corr = _metric(metrics, "correlation", n)
    leverage = _metric(metrics, "leverage", n)
    top1 = _metric(metrics, "top1_rate", n)

    # Within a near-tie only: confidence/trophy path first, then realized right
    # tail, then structure/leverage. Field size changes only whether leverage is
    # considered before or after correlation.
    if context.leverage_priority == "HIGH":
        tiebreaks = (top01_lcb, win, cvar99, p99, leverage, corr, top1, p95, primary)
    elif context.leverage_priority == "MEDIUM":
        tiebreaks = (top01_lcb, win, cvar99, p99, corr, leverage, top1, p95, primary)
    else:
        tiebreaks = (top01_lcb, win, cvar99, p99, corr, top1, p95, leverage, primary)

    # np.lexsort uses the final key as primary. Stable row index is the final
    # deterministic tie-breaker. Negative values sort descending.
    keys: list[np.ndarray] = [np.arange(n, dtype=np.int64)]
    for arr in reversed(tiebreaks):
        keys.append(-np.asarray(arr, dtype=np.float64))
    keys.append(-bucket)
    return np.lexsort(tuple(keys)).astype(np.int64, copy=False)


def ordinal_score(order: Sequence[int], n: int) -> np.ndarray:
    out = np.zeros(int(n), dtype=np.float64)
    order = np.asarray(order, dtype=np.int64)
    if len(order):
        out[order] = (len(order) - np.arange(len(order), dtype=np.float64)) / max(1, len(order))
    return out


def select_ranked_stream(order: Sequence[int], *, board_size: int) -> np.ndarray:
    """Select directly from the sealed ranked stream; no family/pair quotas."""
    order = np.asarray(order, dtype=np.int32)
    if len(order) < int(board_size):
        raise AdvisorSelectorIntegrityError(f"INSUFFICIENT_SELECTOR_ROWS:{len(order)}:{board_size}")
    return order[: int(board_size)].copy()


def selector_receipt(context: ContextProfile, candidate_count: int) -> dict[str, object]:
    payload = {
        "PATCH_ID": PATCH_ID,
        "SELECTOR_MODE": SELECTOR_MODE,
        "SELECTOR_PRIMARY_OBJECTIVE": PRIMARY_OBJECTIVE,
        "SELECTOR_PRIMARY_METRIC": "MC_TOP_0_1_RATE",
        "SELECTOR_WEIGHTED_METRIC_SUM_USED": WEIGHTED_METRIC_SUM_USED,
        "HARD_FAMILY_QUOTAS_USED": HARD_FAMILY_QUOTAS_USED,
        "HARD_PITCHER_PAIR_QUOTAS_USED": HARD_PITCHER_PAIR_QUOTAS_USED,
        "SELECTOR_REVIEWED_LINEUPS": int(candidate_count),
        "FIELD_SLATE_CONTEXT": context.as_dict(),
        "RAW_PROJECTIONS_USED_BY_SELECTOR": False,
        "POSTLOCK_RESULTS_USED_BY_SELECTOR": False,
        "PLAYER_NAMES_USED_BY_SELECTOR": False,
    }
    payload["SELECTOR_PLAN_SHA256"] = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return payload
