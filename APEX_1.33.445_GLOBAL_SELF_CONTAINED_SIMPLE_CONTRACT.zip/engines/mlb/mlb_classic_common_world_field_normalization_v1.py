from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np

PATCH_ID = "MLB_CLASSIC_COMMON_WORLD_FIELD_NORMALIZATION_v1"


@dataclass(frozen=True)
class CommonWorldFieldThresholds:
    top1: np.ndarray
    top01: np.ndarray
    win: np.ndarray
    receipt: dict[str, Any]


def contest_rank_cutoffs(field_size: int) -> tuple[int, int, int]:
    """Return integer rank cutoffs (Top-1%, Top-0.1%, Win) for a contest field."""
    n = int(field_size)
    if n <= 0:
        raise ValueError("field_size must be positive")
    top1_k = max(1, int(math.ceil(n * 0.01)))
    top01_k = max(1, int(math.ceil(n * 0.001)))
    return top1_k, top01_k, 1


def contest_quantiles(field_size: int) -> tuple[float, float, float]:
    top1_k, top01_k, win_k = contest_rank_cutoffs(field_size)
    n = float(field_size)
    return (
        max(0.0, min(1.0, 1.0 - top1_k / n)),
        max(0.0, min(1.0, 1.0 - top01_k / n)),
        max(0.0, min(1.0, 1.0 - win_k / n)),
    )


def _line_score_block(score_surface: np.ndarray, lines: np.ndarray) -> np.ndarray:
    worlds = int(score_surface.shape[0])
    width = int(lines.shape[0])
    out = np.zeros((worlds, width), dtype=np.float32)
    for slot in range(lines.shape[1]):
        out += score_surface[:, lines[:, slot]]
    return out


def _line_chunk_size(worlds: int, max_working_set_bytes: int) -> int:
    bytes_per_line = max(1, worlds) * np.dtype(np.float32).itemsize
    return max(1, int(max_working_set_bytes) // max(1, bytes_per_line))


def common_world_field_thresholds(
    score_surface: np.ndarray,
    fixed_field_lines: np.ndarray,
    *,
    field_size: int,
    max_working_set_bytes: int = 25 * 1024 * 1024,
    calibration_line_count: int = 512,
) -> CommonWorldFieldThresholds:
    """Build contest-size-aware per-world field thresholds.

    The fixed ownership/structure-weighted field sample is scored in every world.
    Per-world location and scale are estimated from the full fixed sample. Tail
    quantiles are estimated on pooled within-world standardized field scores,
    then mapped back into every world. This removes cross-world location/scale
    mixing while keeping runtime bounded for large contest fields.
    """
    surface = np.asarray(score_surface, dtype=np.float32)
    lines = np.asarray(fixed_field_lines, dtype=np.int32)
    if surface.ndim != 2:
        raise ValueError("score_surface must be 2D [world, player]")
    if lines.ndim != 2 or len(lines) == 0:
        raise ValueError("fixed_field_lines must be non-empty 2D [lineup, slot]")
    if int(lines.min()) < 0 or int(lines.max()) >= surface.shape[1]:
        raise ValueError("fixed_field_lines contains out-of-range player index")

    worlds = int(surface.shape[0])
    field_lines = int(lines.shape[0])
    chunk = min(field_lines, _line_chunk_size(worlds, max_working_set_bytes))

    sum_scores = np.zeros(worlds, dtype=np.float64)
    sumsq_scores = np.zeros(worlds, dtype=np.float64)
    for st in range(0, field_lines, chunk):
        ed = min(field_lines, st + chunk)
        mat = _line_score_block(surface, lines[st:ed])
        sum_scores += mat.sum(axis=1, dtype=np.float64)
        sumsq_scores += np.square(mat, dtype=np.float32).sum(axis=1, dtype=np.float64)

    mean = sum_scores / float(field_lines)
    var = np.maximum(0.0, sumsq_scores / float(field_lines) - np.square(mean))
    scale = np.sqrt(var)
    positive_scale = scale[scale > 1e-6]
    if positive_scale.size == 0:
        raise ValueError("fixed field has zero within-world variance")
    scale_floor = max(1e-6, float(np.quantile(positive_scale, 0.01)) * 0.05)
    scale_safe = np.maximum(scale, scale_floor)

    # Keep standardized calibration storage plus one score block within the same
    # bounded working-set envelope. A minimum of 32 lines is enough for tests;
    # production normally resolves to hundreds of lines at 10K worlds.
    max_cal_by_memory = max(32, int(max_working_set_bytes) // max(1, worlds * np.dtype(np.float32).itemsize * 2))
    cal_n = min(field_lines, max(32, min(int(calibration_line_count), max_cal_by_memory)))
    cal_lines = lines[:cal_n]
    standardized = np.empty(worlds * cal_n, dtype=np.float32)
    cursor = 0
    cal_chunk = min(cal_n, max(1, _line_chunk_size(worlds, max_working_set_bytes // 2)))
    for st in range(0, cal_n, cal_chunk):
        ed = min(cal_n, st + cal_chunk)
        mat = _line_score_block(surface, cal_lines[st:ed])
        z = (mat - mean[:, None]) / scale_safe[:, None]
        count = z.size
        standardized[cursor:cursor + count] = z.reshape(-1)
        cursor += count
    if cursor != standardized.size:
        raise RuntimeError("standardized field calibration cursor mismatch")

    q_top1, q_top01, q_win = contest_quantiles(int(field_size))
    z_top1, z_top01, z_win = np.quantile(
        standardized,
        [q_top1, q_top01, q_win],
        method="linear",
    ).astype(np.float64)

    top1 = (mean + scale_safe * float(z_top1)).astype(np.float32)
    top01 = (mean + scale_safe * float(z_top01)).astype(np.float32)
    win = (mean + scale_safe * float(z_win)).astype(np.float32)

    # Rank nesting is a hard invariant: winner is never easier than Top-0.1,
    # which is never easier than Top-1. Small contests naturally collapse
    # Top-0.1 to the win boundary when ceil(0.001 * field_size) == 1.
    top01 = np.maximum(top01, top1)
    win = np.maximum(win, top01)

    top1_k, top01_k, win_k = contest_rank_cutoffs(int(field_size))
    receipt = {
        "PATCH_ID": PATCH_ID,
        "FIELD_SIZE": int(field_size),
        "FIXED_FIELD_SAMPLE_LINEUPS": field_lines,
        "CALIBRATION_FIELD_LINEUPS": int(cal_n),
        "WORLDS": worlds,
        "TOP1_RANK_CUTOFF": int(top1_k),
        "TOP01_RANK_CUTOFF": int(top01_k),
        "WIN_RANK_CUTOFF": int(win_k),
        "TOP1_QUANTILE": float(q_top1),
        "TOP01_QUANTILE": float(q_top01),
        "WIN_QUANTILE": float(q_win),
        "STANDARDIZED_TOP1_Z": float(z_top1),
        "STANDARDIZED_TOP01_Z": float(z_top01),
        "STANDARDIZED_WIN_Z": float(z_win),
        "WORLD_MEAN_MIN": float(mean.min()),
        "WORLD_MEAN_MAX": float(mean.max()),
        "WORLD_SCALE_MIN": float(scale_safe.min()),
        "WORLD_SCALE_MAX": float(scale_safe.max()),
        "RANK_NESTING_VALID": bool(np.all(win >= top01) and np.all(top01 >= top1)),
        "TOP01_EQUALS_WIN_FOR_SINGLE_SEAT": bool(top01_k != 1 or np.array_equal(top01, win)),
        "CROSS_WORLD_GLOBAL_STATIC_CUTOFF_USED": False,
    }
    return CommonWorldFieldThresholds(top1=top1, top01=top01, win=win, receipt=receipt)
