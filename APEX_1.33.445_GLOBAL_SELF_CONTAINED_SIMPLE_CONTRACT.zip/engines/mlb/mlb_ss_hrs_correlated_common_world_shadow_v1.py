from __future__ import annotations

"""Shadow-only correlated common-world kernel for DraftKings MLB SS HRS.

This module does not replace the production SS HRS selector.  It supplies the
correlation-aware simulation, synthetic-field, trial-backed tail metrics, and
marginal-world portfolio utilities required for cross-validation before any
promotion decision.
"""

from collections import Counter
from dataclasses import dataclass
import itertools
import math
from typing import Iterable, Sequence

import numpy as np
from scipy.special import ndtr
from scipy.stats import poisson

PATCH_ID = "MLB_SS_HRS_CORRELATED_COMMON_WORLD_SHADOW_v1"
KERNEL_ID = "SS_HRS_CORRELATED_GAUSSIAN_COPULA_POISSON_COMMON_WORLD_SHADOW_v1"
STATUS = "SHADOW_ONLY_NOT_PRODUCTION_PROMOTED"


@dataclass(frozen=True)
class CopulaConfig:
    # Latent Gaussian correlation. Same-team players share both game and team
    # factors; opponents in the same game share only the game factor.
    same_game_rho: float = 0.05
    same_team_rho: float = 0.12
    trial_chunk: int = 1024

    def validate(self) -> None:
        if not (0.0 <= self.same_game_rho < 1.0):
            raise ValueError("INVALID_SAME_GAME_RHO")
        if not (self.same_game_rho <= self.same_team_rho < 1.0):
            raise ValueError("INVALID_SAME_TEAM_RHO")
        if self.trial_chunk <= 0:
            raise ValueError("INVALID_TRIAL_CHUNK")


@dataclass(frozen=True)
class SelectorWeights:
    # Shadow defaults emphasize winner-take-all equity. They are configuration,
    # not a production constant, and must be cross-validated before promotion.
    win: float = 0.70
    top01: float = 0.20
    top1: float = 0.10

    def normalized(self) -> tuple[float, float, float]:
        vals = np.asarray([self.win, self.top01, self.top1], dtype=float)
        if np.any(vals < 0) or float(vals.sum()) <= 0:
            raise ValueError("INVALID_SELECTOR_WEIGHTS")
        vals /= vals.sum()
        return float(vals[0]), float(vals[1]), float(vals[2])


def lambda_from_p_event(p_event: np.ndarray | Sequence[float]) -> np.ndarray:
    """Map P(N>=1) to Poisson lambda exactly: lambda=-log(1-p)."""
    p = np.asarray(p_event, dtype=np.float64)
    if np.any(~np.isfinite(p)):
        raise ValueError("NONFINITE_P_EVENT")
    p = np.clip(p, 1e-9, 1.0 - 1e-9)
    return -np.log1p(-p)


def canonical_game_codes(teams: Sequence[str], opponents: Sequence[str]) -> np.ndarray:
    if len(teams) != len(opponents):
        raise ValueError("TEAM_OPP_LENGTH_MISMATCH")
    keys = ["|".join(sorted((str(t), str(o)))) for t, o in zip(teams, opponents)]
    _, codes = np.unique(np.asarray(keys, dtype=object), return_inverse=True)
    return codes.astype(np.int32)


def categorical_codes(values: Sequence[str]) -> np.ndarray:
    _, codes = np.unique(np.asarray(values, dtype=object), return_inverse=True)
    return codes.astype(np.int32)


def gaussian_copula_poisson_counts(
    p_event: np.ndarray | Sequence[float],
    team_codes: np.ndarray | Sequence[int],
    game_codes: np.ndarray | Sequence[int],
    trials: int,
    seed: int,
    config: CopulaConfig = CopulaConfig(),
) -> np.ndarray:
    """Generate rank-preserving Gaussian-copula Poisson HR counts.

    Same-team players share game + team latent normals. Same-game opponents share
    the game latent normal. Player residuals remain independent. Marginal
    P(N>=1) is preserved through lambda=-log(1-p) and inverse Poisson CDF.
    """
    config.validate()
    p = np.asarray(p_event, dtype=np.float64)
    team = np.asarray(team_codes, dtype=np.int32)
    game = np.asarray(game_codes, dtype=np.int32)
    n = p.size
    if team.size != n or game.size != n:
        raise ValueError("FACTOR_CODE_LENGTH_MISMATCH")
    if trials <= 0:
        raise ValueError("INVALID_TRIAL_COUNT")

    lam = lambda_from_p_event(p)
    n_team = int(team.max()) + 1 if n else 0
    n_game = int(game.max()) + 1 if n else 0
    rho_game = float(config.same_game_rho)
    rho_team_extra = float(config.same_team_rho - config.same_game_rho)
    residual_var = 1.0 - float(config.same_team_rho)
    if residual_var <= 0:
        raise ValueError("INVALID_COPULA_VARIANCE")

    g_load = math.sqrt(rho_game)
    t_load = math.sqrt(rho_team_extra)
    e_load = math.sqrt(residual_var)
    rng = np.random.default_rng(int(seed))
    out = np.empty((int(trials), n), dtype=np.int8)

    for start in range(0, int(trials), int(config.trial_chunk)):
        stop = min(int(trials), start + int(config.trial_chunk))
        m = stop - start
        game_z = rng.standard_normal((m, n_game))
        team_z = rng.standard_normal((m, n_team))
        eps = rng.standard_normal((m, n))
        z = g_load * game_z[:, game] + t_load * team_z[:, team] + e_load * eps
        u = ndtr(z)
        # Protect ppf from exact 0/1 floating endpoints.
        u = np.clip(u, 1e-12, 1.0 - 1e-12)
        counts = poisson.ppf(u, lam[None, :]).astype(np.int8, copy=False)
        out[start:stop] = counts
    return out


def empirical_pair_correlation(counts: np.ndarray, i: int, j: int) -> float:
    x = (np.asarray(counts)[:, int(i)] > 0).astype(np.float64)
    y = (np.asarray(counts)[:, int(j)] > 0).astype(np.float64)
    if x.std() == 0 or y.std() == 0:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])


def generate_synthetic_field(
    field_size: int,
    rst_pct: np.ndarray | Sequence[float],
    p_market: np.ndarray | Sequence[float],
    team_codes: np.ndarray | Sequence[int],
    game_codes: np.ndarray | Sequence[int],
    seed: int,
    same_team_boost: float = 1.35,
    same_game_boost: float = 1.12,
) -> np.ndarray:
    """Generate a legal three-hitter public field with ownership/chalk affinity.

    Duplicates across field entries are intentionally allowed because projected
    duplication is part of tournament economics. Within an entry players are
    unique and no team may occupy all three slots.
    """
    if field_size <= 0:
        raise ValueError("INVALID_FIELD_SIZE")
    rst = np.maximum(np.asarray(rst_pct, dtype=np.float64), 0.05)
    pm = np.maximum(np.asarray(p_market, dtype=np.float64), 1e-6)
    team = np.asarray(team_codes, dtype=np.int32)
    game = np.asarray(game_codes, dtype=np.int32)
    n = rst.size
    if n < 3 or pm.size != n or team.size != n or game.size != n:
        raise ValueError("INVALID_FIELD_INPUT_SHAPE")

    # Public-selection base: ownership is primary, market HR probability is a
    # secondary realism term. Normalize only selection weights, never player HR
    # event probabilities.
    rst_w = rst / rst.sum()
    pm_w = pm / pm.sum()
    base = 0.82 * rst_w + 0.18 * pm_w
    base /= base.sum()

    rng = np.random.default_rng(int(seed))
    field = np.empty((int(field_size), 3), dtype=np.int32)
    all_idx = np.arange(n, dtype=np.int32)

    for r in range(int(field_size)):
        first = int(rng.choice(all_idx, p=base))
        chosen = [first]
        for _slot in (1, 2):
            w = base.copy()
            w[chosen] = 0.0
            same_team = team == team[first]
            same_game = game == game[first]
            w[same_game] *= float(same_game_boost)
            w[same_team] *= float(same_team_boost)
            if len(chosen) == 2 and team[chosen[0]] == team[chosen[1]]:
                w[team == team[chosen[0]]] = 0.0
            total = float(w.sum())
            if total <= 0:
                legal = np.ones(n, dtype=bool)
                legal[chosen] = False
                if len(chosen) == 2 and team[chosen[0]] == team[chosen[1]]:
                    legal &= team != team[chosen[0]]
                options = all_idx[legal]
                nxt = int(rng.choice(options))
            else:
                nxt = int(rng.choice(all_idx, p=w / total))
            chosen.append(nxt)
        field[r] = np.sort(np.asarray(chosen, dtype=np.int32))
    return field


def _kth_highest_threshold(scores: np.ndarray, kth: int) -> np.ndarray:
    if kth <= 1:
        return scores.max(axis=1)
    kth = min(int(kth), scores.shape[1])
    pos = scores.shape[1] - kth
    return np.partition(scores, pos, axis=1)[:, pos]


def field_trial_thresholds(
    counts: np.ndarray,
    field_triads: np.ndarray,
    top01_fraction: float = 0.001,
    top1_fraction: float = 0.01,
    trial_chunk: int = 512,
) -> dict[str, np.ndarray]:
    counts = np.asarray(counts)
    tri = np.asarray(field_triads, dtype=np.int32)
    if tri.ndim != 2 or tri.shape[1] != 3:
        raise ValueError("FIELD_TRIADS_MUST_BE_Nx3")
    trials = counts.shape[0]
    fsize = tri.shape[0]
    top01_n = max(1, int(math.ceil(fsize * float(top01_fraction))))
    top1_n = max(1, int(math.ceil(fsize * float(top1_fraction))))
    mx = np.empty(trials, dtype=np.int16)
    t01 = np.empty(trials, dtype=np.int16)
    t1 = np.empty(trials, dtype=np.int16)
    a, b, c = tri[:, 0], tri[:, 1], tri[:, 2]
    for start in range(0, trials, int(trial_chunk)):
        stop = min(trials, start + int(trial_chunk))
        s = counts[start:stop, a].astype(np.int16)
        s += counts[start:stop, b]
        s += counts[start:stop, c]
        mx[start:stop] = s.max(axis=1)
        t01[start:stop] = _kth_highest_threshold(s, top01_n)
        t1[start:stop] = _kth_highest_threshold(s, top1_n)
    return {"field_max": mx, "top01_threshold": t01, "top1_threshold": t1}


def evaluate_candidates(
    counts: np.ndarray,
    candidate_triads: np.ndarray,
    thresholds: dict[str, np.ndarray],
    dup_proxy: np.ndarray | Sequence[float] | None = None,
    candidate_chunk: int = 1024,
    return_masks: bool = False,
) -> dict[str, np.ndarray]:
    counts = np.asarray(counts)
    tri = np.asarray(candidate_triads, dtype=np.int32)
    if tri.ndim != 2 or tri.shape[1] != 3:
        raise ValueError("CANDIDATE_TRIADS_MUST_BE_Nx3")
    trials = counts.shape[0]
    for key in ("field_max", "top01_threshold", "top1_threshold"):
        if key not in thresholds or len(thresholds[key]) != trials:
            raise ValueError(f"INVALID_THRESHOLD:{key}")
    n = tri.shape[0]
    win_rate = np.zeros(n, dtype=np.float64)
    win_tie_rate = np.zeros(n, dtype=np.float64)
    top01_rate = np.zeros(n, dtype=np.float64)
    top1_rate = np.zeros(n, dtype=np.float64)
    masks = None
    if return_masks:
        masks = {
            "win": np.empty((n, trials), dtype=bool),
            "top01": np.empty((n, trials), dtype=bool),
            "top1": np.empty((n, trials), dtype=bool),
        }
    fmax = np.asarray(thresholds["field_max"])[:, None]
    t01 = np.asarray(thresholds["top01_threshold"])[:, None]
    t1 = np.asarray(thresholds["top1_threshold"])[:, None]

    for start in range(0, n, int(candidate_chunk)):
        stop = min(n, start + int(candidate_chunk))
        q = tri[start:stop]
        s = counts[:, q[:, 0]].astype(np.int16)
        s += counts[:, q[:, 1]]
        s += counts[:, q[:, 2]]
        outright = s > fmax
        tied = s >= fmax
        e01 = s >= t01
        e1 = s >= t1
        win_rate[start:stop] = outright.mean(axis=0)
        win_tie_rate[start:stop] = tied.mean(axis=0)
        top01_rate[start:stop] = e01.mean(axis=0)
        top1_rate[start:stop] = e1.mean(axis=0)
        if masks is not None:
            masks["win"][start:stop] = outright.T
            masks["top01"][start:stop] = e01.T
            masks["top1"][start:stop] = e1.T

    if dup_proxy is None:
        dup = np.zeros(n, dtype=np.float64)
    else:
        dup = np.maximum(np.asarray(dup_proxy, dtype=np.float64), 0.0)
        if dup.size != n:
            raise ValueError("DUP_PROXY_LENGTH_MISMATCH")
    championship_mass = win_rate / (1.0 + dup)
    result = {
        "p_win": win_rate,
        "p_win_tie": win_tie_rate,
        "p_top01": top01_rate,
        "p_top1": top1_rate,
        "championship_mass": championship_mass,
    }
    if masks is not None:
        result.update({f"mask_{k}": v for k, v in masks.items()})
    return result


def scalar_shadow_score(metrics: dict[str, np.ndarray], weights: SelectorWeights = SelectorWeights()) -> np.ndarray:
    w_win, w_01, w_1 = weights.normalized()
    return (
        w_win * np.asarray(metrics["p_win"], dtype=float)
        + w_01 * np.asarray(metrics["p_top01"], dtype=float)
        + w_1 * np.asarray(metrics["p_top1"], dtype=float)
    )


def select_marginal_world_portfolio(
    triads: np.ndarray,
    metrics: dict[str, np.ndarray],
    board_size: int = 10,
    weights: SelectorWeights = SelectorWeights(),
    primary_anchor_set: set[int] | None = None,
    primary_anchor_cap: int = 4,
    pair_cap: int = 2,
) -> list[int]:
    """Greedy conditional-world coverage selector on a finalist pool.

    Requires trial masks from evaluate_candidates(return_masks=True). The gain is
    computed only from worlds not already covered by the current portfolio.
    """
    tri = np.asarray(triads, dtype=np.int32)
    win_mask = np.asarray(metrics["mask_win"], dtype=bool)
    t01_mask = np.asarray(metrics["mask_top01"], dtype=bool)
    t1_mask = np.asarray(metrics["mask_top1"], dtype=bool)
    if win_mask.shape != t01_mask.shape or win_mask.shape != t1_mask.shape:
        raise ValueError("MASK_SHAPE_MISMATCH")
    if win_mask.shape[0] != tri.shape[0]:
        raise ValueError("MASK_TRIAD_COUNT_MISMATCH")
    w_win, w_01, w_1 = weights.normalized()
    cmass = np.asarray(metrics.get("championship_mass", np.zeros(len(tri))), dtype=float)
    anchors = primary_anchor_set or set()
    selected: list[int] = []
    anchor_exp: Counter[int] = Counter()
    pair_exp: Counter[tuple[int, int]] = Counter()
    covered_win = np.zeros(win_mask.shape[1], dtype=bool)
    covered_01 = np.zeros(win_mask.shape[1], dtype=bool)
    covered_1 = np.zeros(win_mask.shape[1], dtype=bool)
    remaining = set(range(len(tri)))

    for _ in range(min(int(board_size), len(tri))):
        best = None
        best_key = None
        for idx in remaining:
            ids = tuple(int(x) for x in tri[idx])
            if any(u in anchors and anchor_exp[u] >= int(primary_anchor_cap) for u in ids):
                continue
            pairs = [tuple(sorted(p)) for p in itertools.combinations(ids, 2)]
            if any(pair_exp[p] >= int(pair_cap) for p in pairs):
                continue
            dwin = np.count_nonzero(win_mask[idx] & ~covered_win) / win_mask.shape[1]
            d01 = np.count_nonzero(t01_mask[idx] & ~covered_01) / win_mask.shape[1]
            d1 = np.count_nonzero(t1_mask[idx] & ~covered_1) / win_mask.shape[1]
            gain = w_win * dwin + w_01 * d01 + w_1 * d1
            key = (gain, cmass[idx], metrics["p_win"][idx], metrics["p_top01"][idx], metrics["p_top1"][idx])
            if best_key is None or key > best_key:
                best_key = key
                best = idx
        if best is None:
            break
        selected.append(int(best))
        remaining.remove(best)
        ids = tuple(int(x) for x in tri[best])
        for u in ids:
            anchor_exp[u] += 1
        for pair in itertools.combinations(ids, 2):
            pair_exp[tuple(sorted(pair))] += 1
        covered_win |= win_mask[best]
        covered_01 |= t01_mask[best]
        covered_1 |= t1_mask[best]
    return selected


def duplicate_counts(field_triads: np.ndarray) -> Counter[tuple[int, int, int]]:
    return Counter(tuple(sorted(map(int, row))) for row in np.asarray(field_triads))


def shadow_receipt_stub() -> dict:
    return {
        "PATCH_ID": PATCH_ID,
        "KERNEL_ID": KERNEL_ID,
        "STATUS": STATUS,
        "PRODUCTION_ENTRYPOINT_CHANGED": False,
        "PRODUCTION_SELECTOR_CHANGED": False,
        "PROMOTION_REQUIRES_FULL_CROSS_VALIDATION": True,
        "MARGINAL_P_EVENT_PRESERVATION": "POISSON_LAMBDA_EQUALS_NEG_LOG_ONE_MINUS_P_EVENT",
        "DEPENDENCE": "GAUSSIAN_COPULA_GAME_PLUS_TEAM_LATENT_FACTORS",
        "FIELD": "SYNTHETIC_OWNERSHIP_WEIGHTED_LEGAL_TRIADS_WITH_DUPLICATES_ALLOWED",
        "TAIL_METRICS": ["P_WIN", "P_WIN_TIE", "P_TOP_0.1", "P_TOP_1", "CHAMPIONSHIP_MASS"],
        "SELECTOR": "GREEDY_MARGINAL_COMMON_WORLD_COVERAGE_SHADOW_ONLY",
    }
