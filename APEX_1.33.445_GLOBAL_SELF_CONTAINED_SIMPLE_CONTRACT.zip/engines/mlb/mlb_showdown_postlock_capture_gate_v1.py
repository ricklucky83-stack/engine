#!/usr/bin/env python3
"""Fail-closed MLB Showdown winner/perfect post-lock capture gate.

Realized results are audit-only. This module never mutates, reorders, or
promotes a frozen production board.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from mlb_showdown_postlock_board_rank_evaluator_v1 import (
    FPTS_ROUNDING_TOLERANCE,
    lineup_key,
    normalized_fpts,
    parse_lineup,
    read_standings,
)


AUDITOR_ID = "MLB_SD_POSTLOCK_ROLE_NORMALIZED_CAPTURE_GATE_v1"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def matrix_keys(
    path: Path,
    identity_map: dict[str, str],
) -> dict[tuple[str, tuple[str, ...]], str]:
    columns = ["LINEUP_ID", "CPT", "UTIL1", "UTIL2", "UTIL3", "UTIL4", "UTIL5"]
    matrix = pd.read_csv(path, usecols=columns)
    keys: dict[tuple[str, tuple[str, ...]], str] = {}
    for _, row in matrix.iterrows():
        roster = [str(row["CPT"]), *[str(row[f"UTIL{i}"]) for i in range(1, 6)]]
        roster = [identity_map.get(value, value) for value in roster]
        keys[lineup_key(roster[0], roster[1:])] = str(row["LINEUP_ID"])
    return keys


def observed_perfect(
    players: list[str],
    salary: dict[str, int],
    team: dict[str, str],
    fpts: dict[str, float],
) -> tuple[float, list[tuple[tuple[str, tuple[str, ...]], int]]]:
    """Enumerate the post-lock truth surface, never the pre-lock candidate universe."""
    best_score = -math.inf
    best: list[tuple[tuple[str, tuple[str, ...]], int]] = []
    for core in itertools.combinations(players, 6):
        if len({team[player] for player in core}) < 2:
            continue
        for cpt in core:
            lineup_salary = int(round(
                1.5 * salary[cpt]
                + sum(salary[player] for player in core if player != cpt)
            ))
            if lineup_salary > 50_000:
                continue
            score = 1.5 * fpts[cpt] + sum(
                fpts[player] for player in core if player != cpt
            )
            key = lineup_key(cpt, [player for player in core if player != cpt])
            if score > best_score + 1e-9:
                best_score = score
                best = [(key, lineup_salary)]
            elif abs(score - best_score) <= 1e-9:
                best.append((key, lineup_salary))
    if not best:
        raise RuntimeError("OBSERVED_PERFECT_UNIVERSE_EMPTY")
    return float(best_score), best


def audit_capture(
    *,
    board_path: Path,
    pool_path: Path,
    standings_path: Path,
    active_pool_path: Path,
    phase2_path: Path,
    handoff_path: Path,
    identity_map_path: Path,
    field_size: int,
) -> tuple[dict[str, object], pd.DataFrame]:
    board_hash_before = sha256(board_path)
    standings = read_standings(standings_path)
    required = {"Rank", "Points", "Lineup", "EntryId"}
    if not required.issubset(standings.columns):
        raise RuntimeError("STANDINGS_ENTRY_SCHEMA")
    fpts, max_spread = normalized_fpts(standings)
    if not fpts:
        raise RuntimeError("STANDINGS_PLAYER_FPTS_EMPTY")

    entries: list[tuple[int, float, tuple[str, tuple[str, ...]]]] = []
    for _, row in standings[standings["Lineup"].notna()].iterrows():
        key = parse_lineup(row["Lineup"])
        if key is None:
            continue
        try:
            entries.append((int(row["Rank"]), float(row["Points"]), key))
        except (TypeError, ValueError):
            continue
    if not entries:
        raise RuntimeError("STANDINGS_VALID_LINEUPS_EMPTY")
    declared_entries = {
        str(value).strip()
        for value in standings["EntryId"].dropna()
        if str(value).strip()
    }
    if len(declared_entries) != int(field_size):
        raise RuntimeError(
            f"FIELD_SIZE_MISMATCH:EXPECTED_{field_size}:OBSERVED_{len(declared_entries)}"
        )

    active = pd.read_csv(active_pool_path)
    name_column = "PLAYER" if "PLAYER" in active.columns else "player"
    team_column = "TEAM" if "TEAM" in active.columns else "team"
    if name_column not in active.columns or team_column not in active.columns:
        raise RuntimeError("ACTIVE_POOL_SCHEMA")
    active_names = {str(value).strip() for value in active[name_column]}
    teams = {
        str(row[name_column]).strip(): str(row[team_column]).strip()
        for _, row in active.iterrows()
    }

    pool = pd.read_csv(pool_path)
    if not {"PLAYER", "SAL"}.issubset(pool.columns):
        raise RuntimeError("RAW_POOL_SALARY_SCHEMA")
    salaries = {
        str(row["PLAYER"]).strip(): int(float(row["SAL"]))
        for _, row in pool.iterrows()
        if str(row["PLAYER"]).strip() in active_names
    }
    missing_fpts = sorted(active_names - set(fpts))
    observed_players = sorted(active_names & set(fpts) & set(salaries) & set(teams))
    perfect_lower_bound, observed_perfect_rows = observed_perfect(
        observed_players,
        salaries,
        teams,
        fpts,
    )
    observed_perfect_keys = {key for key, _ in observed_perfect_rows}

    with identity_map_path.open(newline="", encoding="utf-8-sig") as handle:
        identity_rows = list(csv.DictReader(handle))
    if not identity_rows or not {"PLAYER_ID", "PLAYER"}.issubset(identity_rows[0]):
        raise RuntimeError("IDENTITY_MAP_SCHEMA")
    identity_map = {row["PLAYER_ID"]: row["PLAYER"] for row in identity_rows}
    phase2 = matrix_keys(phase2_path, identity_map)
    handoff = matrix_keys(handoff_path, identity_map)

    board = pd.read_csv(board_path)
    rank_column = "BOARD_RANK" if "BOARD_RANK" in board.columns else "RANK"
    required_board = {rank_column, "CPT", "UTIL1", "UTIL2", "UTIL3", "UTIL4", "UTIL5"}
    if not required_board.issubset(board.columns):
        raise RuntimeError("BOARD_SCHEMA")
    board_keys = [
        lineup_key(row["CPT"], [row[f"UTIL{i}"] for i in range(1, 6)])
        for _, row in board.sort_values(rank_column).iterrows()
    ]
    if not board_keys or len(board_keys) != len(set(board_keys)):
        raise RuntimeError("BOARD_DUPLICATE_OR_EMPTY")
    if any(player not in fpts for key in board_keys for player in (key[0], *key[1])):
        raise RuntimeError("BOARD_PLAYER_FPTS_MISSING")

    field_points = np.asarray([points for _, points, _ in entries], dtype=float)
    exact: dict[tuple[str, tuple[str, ...]], tuple[int, float]] = {}
    for rank, points, key in entries:
        if key not in exact or rank < exact[key][0]:
            exact[key] = (rank, points)
    audit_rows = []
    for board_rank, key in enumerate(board_keys, 1):
        actual_score = 1.5 * fpts[key[0]] + sum(fpts[player] for player in key[1])
        if key in exact:
            contest_rank = int(exact[key][0])
            source = "EXACT_FIELD_MATCH"
        else:
            contest_rank = int(
                1 + np.sum(field_points > actual_score + FPTS_ROUNDING_TOLERANCE)
            )
            source = "VIRTUAL_IF_PLAYED"
        audit_rows.append({
            "BOARD_RANK": board_rank,
            "CPT": key[0],
            "UTILS": "|".join(key[1]),
            "ACTUAL_POINTS": round(float(actual_score), 6),
            "CONTEST_RANK": contest_rank,
            "RANK_SOURCE": source,
        })
    audit = pd.DataFrame(audit_rows)

    winner_rank = min(rank for rank, _, _ in entries)
    winner_keys = {key for rank, _, key in entries if rank == winner_rank}
    board_set = set(board_keys)
    winner_capture = bool(winner_keys & board_set)
    observed_perfect_capture = bool(observed_perfect_keys & board_set)
    perfect_complete = not missing_fpts
    perfect_capture = bool(perfect_complete and observed_perfect_capture)
    board_best_actual = float(audit["ACTUAL_POINTS"].max())
    perfect_absent_proven = bool(
        board_best_actual + FPTS_ROUNDING_TOLERANCE < perfect_lower_bound
        or (perfect_complete and not observed_perfect_capture)
    )
    board_hash_after = sha256(board_path)
    board_hash_unchanged = board_hash_before == board_hash_after

    receipt: dict[str, object] = {
        "AUDITOR_ID": AUDITOR_ID,
        "STATUS": "PASS" if winner_capture and perfect_capture and board_hash_unchanged else "FAIL",
        "FIELD_SIZE": int(field_size),
        "VALID_CONTEST_LINEUPS": len(entries),
        "FPTS_ROLE_NORMALIZATION": "CPT_DIVIDE_1_5_UTIL_UNCHANGED",
        "FPTS_NORMALIZATION_MAX_SPREAD": max_spread,
        "FPTS_NORMALIZATION_CONSISTENCY": "PASS",
        "ACTIVE_PLAYER_FPTS_COMPLETE": perfect_complete,
        "MISSING_ACTIVE_PLAYER_FPTS": missing_fpts,
        "CONTEST_WINNER_BIRTH": winner_keys.issubset(phase2),
        "CONTEST_WINNER_HANDOFF": winner_keys.issubset(handoff),
        "CONTEST_WINNER_BOARD": winner_capture,
        "CONTEST_WINNER_BOARD_RANKS": [
            rank for rank, key in enumerate(board_keys, 1) if key in winner_keys
        ],
        "OBSERVED_PERFECT_SCORE_LOWER_BOUND": perfect_lower_bound,
        "OBSERVED_PERFECT_TIE_COUNT": len(observed_perfect_rows),
        "OBSERVED_PERFECT_BIRTH": observed_perfect_keys.issubset(phase2),
        "OBSERVED_PERFECT_HANDOFF": observed_perfect_keys.issubset(handoff),
        "OBSERVED_PERFECT_BOARD": observed_perfect_capture,
        "PERFECT_CAPTURE_CERTIFIED": perfect_capture,
        "PERFECT_ABSENT_FROM_BOARD_PROVEN": perfect_absent_proven,
        "BEST_BOARD_ACTUAL_POINTS": board_best_actual,
        "BEST_BOARD_CONTEST_RANK": int(audit["CONTEST_RANK"].min()),
        "TOP10_CONTEST_OVERLAP": int((audit["CONTEST_RANK"] <= 10).sum()),
        "BOARD_RESULTS_USED_BY_SELECTOR": False,
        "BOARD_MUTATION_ALLOWED": False,
        "POST_AUDIT_PROMOTION_ALLOWED": False,
        "BOARD_SHA256_BEFORE_POSTLOCK": board_hash_before,
        "BOARD_SHA256_AFTER_POSTLOCK": board_hash_after,
        "BOARD_HASH_UNCHANGED": board_hash_unchanged,
        "SELECTOR_CALIBRATION_PROMOTION_GATE": (
            "PASS" if winner_capture and perfect_capture and board_hash_unchanged else "BLOCK"
        ),
    }
    return receipt, audit


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--board", required=True)
    parser.add_argument("--pool", required=True)
    parser.add_argument("--standings", required=True)
    parser.add_argument("--active-pool", required=True)
    parser.add_argument("--phase2", required=True)
    parser.add_argument("--handoff", required=True)
    parser.add_argument("--identity-map", required=True)
    parser.add_argument("--field-size", required=True, type=int)
    parser.add_argument("--output-receipt", required=True)
    parser.add_argument("--output-audit", required=True)
    args = parser.parse_args()
    receipt, audit = audit_capture(
        board_path=Path(args.board),
        pool_path=Path(args.pool),
        standings_path=Path(args.standings),
        active_pool_path=Path(args.active_pool),
        phase2_path=Path(args.phase2),
        handoff_path=Path(args.handoff),
        identity_map_path=Path(args.identity_map),
        field_size=args.field_size,
    )
    audit.to_csv(args.output_audit, index=False)
    Path(args.output_receipt).write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(receipt, sort_keys=True))
    return 0 if receipt["SELECTOR_CALIBRATION_PROMOTION_GATE"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
