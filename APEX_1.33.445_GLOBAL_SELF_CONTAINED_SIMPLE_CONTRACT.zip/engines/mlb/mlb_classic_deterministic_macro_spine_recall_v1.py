from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence
import math
import numpy as np

PATCH_ID = "MLB_CLASSIC_DETERMINISTIC_MACRO_SPINE_RECALL_v1"

@dataclass(frozen=True)
class MacroSpineConfig:
    primary_team_fraction: float = 1.00
    primary_team_min: int = 8
    pitcher_pair_fraction: float = 1.00
    pitcher_pair_min: int = 64
    primary_combo_quantiles: tuple[float, ...] = (0.00, 0.20, 0.40, 0.60, 0.80)
    max_seed_rows_per_spine: int = 15
    seed_budget_fraction: float = 0.60
    seed_budget_min: int = 3000
    seed_budget_max: int = 12000

DEFAULT_CONFIG = MacroSpineConfig()


def _bounded_count(n: int, fraction: float, minimum: int) -> int:
    if n <= 0:
        return 0
    return min(n, max(minimum, int(math.ceil(n * fraction))))


def select_primary_teams(team_weight_map: Mapping[str, float], config: MacroSpineConfig = DEFAULT_CONFIG) -> tuple[str, ...]:
    ranked = sorted(team_weight_map, key=lambda t: (-float(team_weight_map[t]), str(t)))
    return tuple(ranked[:_bounded_count(len(ranked), config.primary_team_fraction, config.primary_team_min)])


def select_pitcher_pair_positions(pair_scores: Sequence[float], config: MacroSpineConfig = DEFAULT_CONFIG) -> tuple[int, ...]:
    arr = np.asarray(pair_scores, dtype=np.float64)
    if arr.size == 0:
        return ()
    order = np.argsort(-arr, kind="mergesort")
    k = _bounded_count(int(arr.size), config.pitcher_pair_fraction, config.pitcher_pair_min)
    return tuple(int(x) for x in order[:k])



def seed_row_budget(phase2_target: int, config: MacroSpineConfig = DEFAULT_CONFIG) -> int:
    target = max(0, int(phase2_target))
    if target <= 0:
        return 0
    budget = max(int(config.seed_budget_min), int(math.ceil(target * float(config.seed_budget_fraction))))
    return min(int(config.seed_budget_max), target, budget)


def quantile_indices(n: int, quantiles: Sequence[float] = DEFAULT_CONFIG.primary_combo_quantiles) -> tuple[int, ...]:
    if n <= 0:
        return ()
    out: list[int] = []
    for q in quantiles:
        q = min(1.0, max(0.0, float(q)))
        idx = int(round((n - 1) * q))
        if idx not in out:
            out.append(idx)
    return tuple(out)


def rotating_quantile_index(n: int, ordinal: int, quantiles: Sequence[float] = DEFAULT_CONFIG.primary_combo_quantiles) -> int:
    ids = quantile_indices(n, quantiles)
    if not ids:
        raise ValueError("EMPTY_PRIMARY_COMBO_POOL")
    return int(ids[int(ordinal) % len(ids)])


def receipt(*, selected_teams: Sequence[str], selected_pair_positions: Sequence[int], seed_rows: int, attempted_spines: int, legal_spines: int, seed_budget: int | None = None, budget_exhausted: bool = False) -> dict[str, object]:
    return {
        "PATCH_ID": PATCH_ID,
        "STATUS": "PASS",
        "PRIMARY_TEAM_COUNT": len(selected_teams),
        "PITCHER_PAIR_COUNT": len(selected_pair_positions),
        "ATTEMPTED_MACRO_SPINES": int(attempted_spines),
        "LEGAL_MACRO_SPINES": int(legal_spines),
        "SEED_ROWS_ADDED": int(seed_rows),
        "SEED_ROW_BUDGET": None if seed_budget is None else int(seed_budget),
        "SEED_BUDGET_EXHAUSTED": bool(budget_exhausted),
        "OUTCOME_DATA_USED": False,
        "METHODS": [
            "PRELOCK_TEAM_WEIGHT_RANK_COVERAGE",
            "PRELOCK_PITCHER_PAIR_RANK_COVERAGE",
            "MULTI_QUANTILE_PRIMARY_STACK_COVERAGE",
            "DETERMINISTIC_COMPANION_SHAPE_COMPLETION",
            "HASH_SET_LINEUP_DEDUPLICATION",
        ],
    }
