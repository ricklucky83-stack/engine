from __future__ import annotations

from collections.abc import Mapping, Iterator
from hashlib import sha256
import json
from types import MappingProxyType
from typing import Any

PATCH_ID = 'MLB_SHOWDOWN_IMMUTABLE_SLATE_CONTEXT_PARITY_v1'


def _deep_freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(k): _deep_freeze(v) for k, v in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(_deep_freeze(v) for v in value)
    if isinstance(value, set):
        return tuple(sorted(_deep_freeze(v) for v in value))
    if hasattr(value, 'item'):
        try:
            return value.item()
        except Exception:
            pass
    return value


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _thaw(v) for k, v in value.items()}
    if isinstance(value, tuple):
        return [_thaw(v) for v in value]
    return value


class FrozenSlateContext(Mapping):
    __slots__ = ('_data', '_sha256')

    def __init__(self, values: Mapping[str, Any]):
        frozen = {str(k): _deep_freeze(v) for k, v in values.items()}
        object.__setattr__(self, '_data', MappingProxyType(frozen))
        payload = json.dumps(_thaw(self._data), sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
        object.__setattr__(self, '_sha256', sha256(payload).hexdigest())

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    @property
    def sha256(self) -> str:
        return self._sha256

    def as_dict(self) -> dict[str, Any]:
        return _thaw(self._data)

    def __setattr__(self, name: str, value: Any) -> None:
        raise TypeError('FROZEN_SLATE_CONTEXT_IMMUTABLE')


def build_phase1_context(meta: Mapping[str, Any]) -> FrozenSlateContext:
    spids = tuple(int(x) for x in meta.get('sp_player_ids', ()))
    if len(spids) != 2:
        raise RuntimeError(f'SLATE_CONTEXT_CONFIRMED_STARTERS_REQUIRED:{len(spids)}')
    own = meta['own']
    ownerships = tuple(float(own[i]) / 100.0 for i in spids)
    hi = max(ownerships)
    lo = min(ownerships)
    lower_owned_sp = spids[min(range(len(spids)), key=lambda j: (ownerships[j], spids[j]))]
    return FrozenSlateContext({
        'CONTEXT_SCHEMA': PATCH_ID,
        'CONFIRMED_STARTERS': 2,
        'STARTER_IDS': spids,
        'STARTER_OWNERSHIP_VALUES': ownerships,
        'STARTER_OWNERSHIP_GAP': float(hi - lo),
        'LOWER_OWNED_SP_ID': int(lower_owned_sp),
        'PHASE1_CONTEXT_FROZEN': True,
    })


def merge_phase2_context(phase1_context: FrozenSlateContext, field_receipt: Mapping[str, Any]) -> FrozenSlateContext:
    if not isinstance(phase1_context, FrozenSlateContext):
        raise TypeError('PHASE1_CONTEXT_NOT_FROZEN')
    required = ('TARGET_DUAL_SP_SHARE', 'TARGET_SP_CPT_SHARE')
    missing = [k for k in required if k not in field_receipt]
    if missing:
        raise RuntimeError('SLATE_CONTEXT_PHASE2_MISSING:' + ','.join(missing))
    merged = phase1_context.as_dict()
    merged.update({
        'TARGET_DUAL_SP_SHARE': float(field_receipt['TARGET_DUAL_SP_SHARE']),
        'TARGET_SP_CPT_SHARE': float(field_receipt['TARGET_SP_CPT_SHARE']),
        'ACTUAL_DUAL_SP_SHARE': float(field_receipt.get('ACTUAL_DUAL_SP_SHARE', field_receipt['TARGET_DUAL_SP_SHARE'])),
        'ACTUAL_SP_CPT_SHARE': float(field_receipt.get('ACTUAL_SP_CPT_SHARE', field_receipt['TARGET_SP_CPT_SHARE'])),
        'PHASE2_CONTEXT_MERGED': True,
        'SELECTOR_RECOMPUTATION': 'PROHIBITED',
    })
    return FrozenSlateContext(merged)


def assert_context_unchanged(context: FrozenSlateContext, expected_sha256: str, stage: str) -> None:
    if not isinstance(context, FrozenSlateContext):
        raise RuntimeError(f'SLATE_CONTEXT_NOT_FROZEN:{stage}')
    if context.sha256 != str(expected_sha256):
        raise RuntimeError(f'SLATE_CONTEXT_DRIFT:{stage}:{expected_sha256}:{context.sha256}')
