from __future__ import annotations
import json, re
from datetime import datetime
from pathlib import Path

SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def _dt(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def validate_evidence(evidence: dict) -> dict:
    controls = evidence.get("CONTROLS", [])
    target_hash = evidence.get("TARGET_POOL_SHA256_EXCLUDED", "")
    target_time = evidence.get("TARGET_SLATE_LOCK_UTC", "")
    required = int(evidence.get("REQUIRED_DISTINCT_CONTROLS", 2))
    failures: list[str] = []
    accepted: list[dict] = []
    for i, c in enumerate(controls):
        prefix = f"CONTROL_{i+1}"
        required_true = [
            "RAW_BYTES_MOUNTED_AT_SOURCE", "POOL_SCHEMA_PASS", "CONTEST_SCHEMA_PASS",
            "COMPATIBILITY_PASS", "BYTE_COMPLETE_SOURCE_PROOF", "PRELOCK_POOL_SOURCE",
        ]
        for key in required_true:
            if c.get(key) is not True:
                failures.append(f"{prefix}_{key}_FAIL")
        if c.get("SYNTHETIC") is not False:
            failures.append(f"{prefix}_SYNTHETIC_FAIL")
        if c.get("TARGET_SLATE") is not False:
            failures.append(f"{prefix}_TARGET_SLATE_FAIL")
        for key in ("POOL_SHA256", "CONTEST_SHA256"):
            if not SHA256_RE.match(str(c.get(key, ""))):
                failures.append(f"{prefix}_{key}_INVALID")
        if c.get("POOL_SHA256") == target_hash:
            failures.append(f"{prefix}_TARGET_POOL_HASH_COLLISION")
        try:
            if _dt(str(c["SOURCE_EXECUTED_AT_UTC"])) >= _dt(str(target_time)):
                failures.append(f"{prefix}_NOT_PRETARGET")
        except Exception:
            failures.append(f"{prefix}_TIME_INVALID")
        if not c.get("FILE_LIBRARY_SOURCE_FILE_ID") or not c.get("SOURCE_RECEIPT_TITLE"):
            failures.append(f"{prefix}_SOURCE_IDENTITY_MISSING")
        if not any(x.startswith(prefix) for x in failures):
            accepted.append(c)
    distinct_slates = len({c.get("SLATE_ID") for c in accepted})
    distinct_pool_hashes = len({c.get("POOL_SHA256") for c in accepted})
    distinct_contest_hashes = len({c.get("CONTEST_SHA256") for c in accepted})
    if distinct_slates < required: failures.append("DISTINCT_SLATE_DEFICIT")
    if distinct_pool_hashes < required: failures.append("DISTINCT_POOL_HASH_DEFICIT")
    if distinct_contest_hashes < required: failures.append("DISTINCT_CONTEST_HASH_DEFICIT")
    passed = not failures and len(accepted) >= required
    return {
        "CERTIFICATION_ID": evidence.get("CERTIFICATION_ID"),
        "STATUS": "PASS" if passed else "FAIL_CLOSED",
        "REQUIRED_DISTINCT_CONTROLS": required,
        "ACCEPTED_CONTROLS": len(accepted),
        "DISTINCT_SLATES": distinct_slates,
        "DISTINCT_POOL_HASHES": distinct_pool_hashes,
        "DISTINCT_CONTEST_HASHES": distinct_contest_hashes,
        "TARGET_POOL_HASH_EXCLUSION_PASS": all(c.get("POOL_SHA256") != target_hash for c in accepted),
        "FAILURES": failures,
        "GLOBAL_CONTROL_GATE_SATISFIED": passed,
        "AUTOMATIC_PRODUCTION_PROMOTION_ALLOWED": False,
        "POSTLOCK_FORWARD_INFLUENCE": False,
    }


def certify(evidence_path: str | Path, output_path: str | Path) -> dict:
    evidence = json.loads(Path(evidence_path).read_text())
    result = validate_evidence(evidence)
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(json.dumps(result, indent=2) + "\n")
    return result
