#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, itertools, json, os, subprocess, sys, pickle
from pathlib import Path

PATCH_ID='MLB_CLASSIC_STAGE0_STATELESS_MICROCHUNK_PLUS_CROSS_PATTERN_BLOCK_RESUME_v1'
CONTROLLER_SCHEMA_VERSION='mlb_classic_controller.v3'
CONTINUE_RC=75
BASE=Path(__file__).resolve().parent
STATE_ROOT=BASE.parents[1]
# Engine-owned import closure: checkpoints may contain instances from sibling
# engine/common modules. Hydration must never depend on Chat/PYTHONPATH setup.
for _import_root in (STATE_ROOT, BASE, STATE_ROOT/'engines/common'):
    _import_s=str(_import_root)
    if _import_s not in sys.path:
        sys.path.insert(0,_import_s)
SOURCE=BASE/'mlb_classic_raw_pool_runtime_v1_20_2.py'
import apex_terminal_ai_hybrid_selector_v6 as terminal_ai
import apex_authority_walkforward_persistence_v1 as authority_persist
WORKER=STATE_ROOT/'engines/common/mlb_classic_execution_window_checkpoint_runner_v2.py'
EXECUTION_ID=str(os.environ.get('APEX_EXECUTION_ID','UNSET'))
OUT=Path(os.environ.get('APEX_OUTPUT_DIR','/mnt/data')).resolve()
POOL=Path(os.environ['APEX_PLAYER_POOL']).resolve()
RUN_ROOT=Path(os.environ.get('APEX_RESUMABLE_RUN_ROOT',str(OUT/f'.apex_mlb_classic_{EXECUTION_ID}'))).resolve()
CTRL_ROOT=RUN_ROOT/'mlb_classic_engine_owned_resume'
CTRL_ROOT.mkdir(parents=True,exist_ok=True)
STATE_PATH=CTRL_ROOT/'controller_state.json'
SOURCE_SHA=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
POOL_SHA=hashlib.sha256(POOL.read_bytes()).hexdigest()
NOTION_AUTHORITY_SHA256=str(os.environ.get('APEX_NOTION_AUTHORITY_SHA256','')).strip().lower()
NOTION_AUTHORITY_SOURCE=str(os.environ.get('APEX_NOTION_AUTHORITY_SOURCE','UNSET')).strip()
if not NOTION_AUTHORITY_SHA256:
    raise RuntimeError('RUN_INVALID:NOTION_AUTHORITY_SHA256_MISSING')
if os.environ.get('APEX_REQUIRE_LIVE_NOTION_AUTHORITY','0') == '1' and NOTION_AUTHORITY_SOURCE == 'BUNDLED_NOTION_SNAPSHOT':
    raise RuntimeError('RUN_INVALID:LIVE_NOTION_AUTHORITY_REQUIRED:SNAPSHOT_FALLBACK_REJECTED')


def _fsync_dir(path:Path)->None:
    flags=getattr(os,'O_DIRECTORY',0) | os.O_RDONLY
    fd=os.open(str(path),flags)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def atomic_json(path:Path,obj:dict)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8') as f:
        json.dump(obj,f,indent=2,sort_keys=True,separators=(',',':')); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)
    _fsync_dir(path.parent)

def sha256_file(path:Path,block_bytes:int=8*1024*1024)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        while True:
            block=f.read(block_bytes)
            if not block: break
            h.update(block)
    return h.hexdigest()

def validate_controller_state(obj:dict)->None:
    if str(obj.get('CONTROLLER_SCHEMA_VERSION','')) != CONTROLLER_SCHEMA_VERSION:
        raise RuntimeError(f"RUN_INVALID:CONTROLLER_SCHEMA_MISMATCH:{obj.get('CONTROLLER_SCHEMA_VERSION')}:{CONTROLLER_SCHEMA_VERSION}")
    for key in ('STAGE_INDEX','HEAVY_CURSOR','PACKET_CURSOR','STAGE0_PATTERN_CURSOR','CROSS_PARENT_CURSOR'):
        value=obj.get(key)
        if not isinstance(value,int) or value < 0:
            raise RuntimeError(f'RUN_INVALID:CONTROLLER_STATE_FIELD_INVALID:{key}:{value}')
    if not isinstance(obj.get('COMPLETED_STAGES'),list):
        raise RuntimeError('RUN_INVALID:CONTROLLER_COMPLETED_STAGES_INVALID')




def _checkpoint_order_key(path: Path) -> tuple[int, int, str]:
    """Order engine checkpoints by semantic stage/cursor, never filesystem mtime."""
    parts=path.stem.split('_')
    try:
        stage=int(parts[1])
    except Exception:
        stage=-1
    try:
        cursor=int(parts[-1]) if parts and parts[-1].isdigit() and len(parts) > 3 else -1
    except Exception:
        cursor=-1
    return (stage,cursor,path.name)


def prune_checkpoint_files(current: str, fallback: str = '') -> tuple[str, ...]:
    keep={str(Path(x).resolve()) for x in (current,fallback) if x}
    removed=[]
    for tmp in CTRL_ROOT.glob('checkpoint_*.pkl.tmp'):
        try:
            tmp.unlink(); removed.append(str(tmp))
        except FileNotFoundError:
            pass
    for q in CTRL_ROOT.glob('checkpoint_*.pkl'):
        if str(q.resolve()) in keep:
            continue
        try:
            q.unlink(); removed.append(str(q))
        except FileNotFoundError:
            pass
    return tuple(removed)

def find_line(lines:list[str], needle:str)->int:
    hits=[i for i,x in enumerate(lines,1) if needle in x]
    if len(hits)!=1: raise RuntimeError(f'RUN_INVALID:INTERNAL_STAGE_MARKER_NOT_UNIQUE:{needle}:{len(hits)}')
    return hits[0]


def hitter_team_count()->int:
    with POOL.open('r',newline='',encoding='utf-8-sig') as f:
        rd=csv.DictReader(f); fields=rd.fieldnames or []
        team_col=next((x for x in fields if x.strip().upper() in {'TEAM','TEAMABBREV','TEAM_ABBREV'}),None)
        pos_col=next((x for x in fields if x.strip().upper() in {'POS','POSITION','POSITIONS'}),None)
        if not team_col: raise RuntimeError('RUN_INVALID:PLAYER_POOL_TEAM_COLUMN_MISSING')
        teams=set()
        for r in rd:
            pos=str(r.get(pos_col,'')).upper() if pos_col else ''
            if pos and all(tok.strip() in {'P','SP','RP'} for tok in pos.replace('/',',').split(',')):
                continue
            t=str(r.get(team_col,'')).strip()
            if t: teams.add(t)
        return len(teams)

lines=SOURCE.read_text(encoding='utf-8').splitlines()
import ast
_tree=ast.parse(SOURCE.read_text(encoding='utf-8'))
_top=[n for n in _tree.body if hasattr(n,'lineno') and hasattr(n,'end_lineno')]

def marker_line(needle:str)->int:
    hits=[i for i,x in enumerate(lines,1) if needle in x]
    if len(hits)!=1: raise RuntimeError(f'RUN_INVALID:INTERNAL_STAGE_MARKER_NOT_UNIQUE:{needle}:{len(hits)}')
    return hits[0]

def stmt_bounds(needle:str)->tuple[int,int]:
    line=marker_line(needle)
    hits=[n for n in _top if n.lineno<=line<=n.end_lineno]
    if len(hits)!=1: raise RuntimeError(f'RUN_INVALID:INTERNAL_STAGE_STATEMENT_NOT_UNIQUE:{needle}:{len(hits)}')
    return int(hits[0].lineno),int(hits[0].end_lineno)


def stmt_bounds_exact_line(text:str)->tuple[int,int]:
    hits=[i for i,x in enumerate(lines,1) if x.strip()==text]
    if len(hits)!=1: raise RuntimeError(f'RUN_INVALID:INTERNAL_EXACT_STAGE_MARKER_NOT_UNIQUE:{text}:{len(hits)}')
    line=hits[0]
    hits2=[n for n in _top if n.lineno<=line<=n.end_lineno]
    if len(hits2)!=1: raise RuntimeError(f'RUN_INVALID:INTERNAL_EXACT_STAGE_STATEMENT_NOT_UNIQUE:{text}:{len(hits2)}')
    return int(hits2[0].lineno),int(hits2[0].end_lineno)

def next_stmt(after_line:int)->int:
    vals=[int(n.lineno) for n in _top if int(n.lineno)>int(after_line)]
    if not vals: raise RuntimeError(f'RUN_INVALID:INTERNAL_NEXT_STAGE_MISSING:{after_line}')
    return min(vals)

def prev_stmt_end(before_line:int)->int:
    vals=[int(n.end_lineno) for n in _top if int(n.end_lineno)<int(before_line)]
    if not vals: raise RuntimeError(f'RUN_INVALID:INTERNAL_PREVIOUS_STAGE_MISSING:{before_line}')
    return max(vals)

def stage_after(prev_end:int, end_marker:str)->tuple[int,int]:
    return next_stmt(prev_end), stmt_bounds(end_marker)[1]

_phase1_started=stmt_bounds_exact_line("started = time.time()")
_phase1_done=stmt_bounds("print(f'STAGE=PHASE1_SIM_DONE")
_stage0_pattern_loop=stmt_bounds("for pattern_name, sizes, lane, _ in PATTERNS:")
_stage0_adaptive=stmt_bounds("adaptive_family_rows, adaptive_family_receipt = adaptive_family_door_mod.apply(")
_stage0_boot_end=prev_stmt_end(_phase1_started[0])
_stage0_prepattern_end=prev_stmt_end(_stage0_pattern_loop[0])
_a=stmt_bounds("print(json.dumps({'STAGE':'PHASE2_ADAPTIVE_FAMILY_DOOR_RECALL'")
_cross_checkpoint_stmt=stmt_bounds("_cross_checkpoint = mlb_phase2_blocks.MLBPhase2Checkpoint(OUT, EXECUTION_ID, MLB_PHASE2_POOL_HASH, 'PHASE2_RIGHT_NEIGHBORHOOD_CROSS_PATTERN')")
_cross_parent_loop=stmt_bounds("for _block_idx, _block_start, _block_end in mlb_phase2_blocks.block_ranges(len(right_neighborhood_5_3_parents), MLB_PHASE2_BLOCK_ROWS):")
_b=stmt_bounds("print(json.dumps({'STAGE': 'PHASE2_CROSS_PATTERN_FAMILY_CLOSURE'")
_c=stmt_bounds("print(json.dumps({'STAGE':'PHASE2_RIGHT_NEIGHBORHOOD_BORN_PRIMARY_COMPLEMENT_RECOMBINATION'")
_d=stmt_bounds("print(json.dumps({'STAGE': 'PHASE2_DETERMINISTIC_MACRO_SPINE_RECALL'")
_e=stmt_bounds("'STAGE': 'PHASE2_POST_MACRO_COMPLEMENT_RECOMBINATION'")
_preheavy=stmt_bounds("if len(pitcher_pairs) >= 40:")
_heavy=stmt_bounds("if len(pitcher_pairs) >= 15:")
_f=stmt_bounds("print(json.dumps({'STAGE': 'PHASE2_FIVE_STACK_SALARY_COMPLEMENT_SPINE_CLOSURE'")
_g=stmt_bounds("print(json.dumps({'STAGE':'PHASE2_FAST_521_DISTRIBUTED_RANK_LATTICE'")
_h=stmt_bounds("print(f'STAGE=PHASE2_SHORTLIST_DONE")
_i=stmt_bounds("print(f'STAGE=PHASE3_BASE_MC_DONE")
_j=stmt_bounds("print(f'STAGE=ADAPTIVE_BUBBLE_DONE")
_q=stmt_bounds("for j, i in enumerate(handoff_indices):")
_k=stmt_bounds("print(f'STAGE=AI_REVIEW_PACKET_READY")
_q_prep_end=max(int(n.end_lineno) for n in _top if int(n.end_lineno) < int(_q[0]))
_l=stmt_bounds("print(json.dumps({'STAGE':'DOMINANT_STACK_INVERSION_SENTINEL'")
_m=stmt_bounds("print(json.dumps({'STAGE':'CAR_SHOP_TOP50_GENERIC_FEATURE_RESERVE'")
_n=stmt_bounds("print(json.dumps({'STAGE':'ORIENTATION_PROTECTED_SIBLING_INVERSION'")
_o=stmt_bounds("print(json.dumps({'STAGE':'CLASSIC_NONINFERIOR_COMMON_WORLD_TOP01_PORTFOLIO_READY'")
_p=stmt_bounds_exact_line("_validate_and_emit_board_ready()")

stages=[
    ('STAGE0_BOOTSTRAP_POOL_FREEZE',1,_stage0_boot_end),
    ('STAGE0_PHASE1_SIMULATION',_phase1_started[0],_phase1_done[1]),
    ('STAGE0_PHASE1_CALIBRATION_PHASE2_PREP',next_stmt(_phase1_done[1]),_stage0_prepattern_end),
    ('STAGE0_PHASE2_BASE_PATTERN_BIRTH',_stage0_pattern_loop[0],_stage0_pattern_loop[1]),
    ('STAGE0_ADAPTIVE_FAMILY_DOOR',_stage0_adaptive[0],_a[1]),
    ('PHASE2_CROSS_PATTERN_PREP',next_stmt(_a[1]),_cross_checkpoint_stmt[1]),
    ('PHASE2_CROSS_PATTERN_ONE_HOP',_cross_parent_loop[0],_cross_parent_loop[1]),
    ('PHASE2_CROSS_PATTERN_FINALIZE',next_stmt(_cross_parent_loop[1]),_b[1]),
    ('PHASE2_LATTICE_PAIR_COMPLEMENT',next_stmt(_b[1]),_c[1]),
    ('PHASE2_MACRO_SPINE',next_stmt(_c[1]),_d[1]),
    ('PHASE2_POST_MACRO_COMPLEMENT',next_stmt(_d[1]),_e[1]),
    ('PHASE2_DISTRIBUTED_GEOMETRY_PRE_HEAVY',next_stmt(_e[1]),_preheavy[1]),
    ('PHASE2_221111_HEAVY',_heavy[0],_heavy[1]),
    ('PHASE2_DISTRIBUTED_GEOMETRY_FINAL',next_stmt(_heavy[1]),_f[1]),
    ('PHASE2_ADJACENT_521',next_stmt(_f[1]),_g[1]),
    ('PHASE2_FREEZE_RECURRENCE_SHORTLIST',next_stmt(_g[1]),_h[1]),
    ('PHASE3_BASE_MC',next_stmt(_h[1]),_i[1]),
    ('PHASE3_ADAPTIVE_BUBBLE',next_stmt(_i[1]),_j[1]),
    ('HANDOFF_SELECTOR_PREP',next_stmt(_j[1]),_q_prep_end),
    ('HANDOFF_RAW_SELECTOR_PACKET',_q[0],_q[1]),
    ('HANDOFF_SELECTOR_FINALIZE',next_stmt(_q[1]),_k[1]),
    ('SELECTOR_DOMINANT_INVERSION',next_stmt(_k[1]),_l[1]),
    ('SELECTOR_CARSHOP_RESERVE',next_stmt(_l[1]),_m[1]),
    ('SELECTOR_521_ORIENTATION',next_stmt(_m[1]),_n[1]),
    ('SELECTOR_COMMON_WORLD_CORE5',next_stmt(_n[1]),_o[1]),
    ('FINAL_BOARD',next_stmt(_o[1]),_p[1]),
]

identity={'PATCH_ID':PATCH_ID,'CONTROLLER_SCHEMA_VERSION':CONTROLLER_SCHEMA_VERSION,'SOURCE_SHA256':SOURCE_SHA,'PLAYER_POOL_SHA256':POOL_SHA,'EXECUTION_ID':EXECUTION_ID,'NOTION_AUTHORITY_SHA256':NOTION_AUTHORITY_SHA256,'NOTION_AUTHORITY_SOURCE':NOTION_AUTHORITY_SOURCE}
if STATE_PATH.exists():
    state=json.loads(STATE_PATH.read_text(encoding='utf-8'))
    if any(str(state.get(k))!=str(v) for k,v in identity.items()):
        stale=STATE_PATH.with_name(f'controller_state.stale.{os.getpid()}.json'); os.replace(STATE_PATH,stale); state={}
else: state={}
if not state:
    # State-version promotion may quarantine the outer runner root. Recover the
    # newest compatible engine-owned controller checkpoint mechanically when the
    # raw runtime and player pool identities are unchanged.
    migrated=None
    # State-digest changes can legitimately create a new outer run-root name even
    # when the MLB raw runtime and player pool are byte-identical. Discover every
    # sibling run root for this exact execution and choose the most advanced
    # committed compatible controller state. Folder recency alone is not authority.
    _roots=[]
    _seen=set()
    for _pattern in (RUN_ROOT.name+'.stale.*', f'MLB_CLASSIC_{EXECUTION_ID}_*'):
        for _root in RUN_ROOT.parent.glob(_pattern):
            try:_resolved=str(_root.resolve())
            except Exception:continue
            if _resolved==str(RUN_ROOT.resolve()) or _resolved in _seen:
                continue
            _seen.add(_resolved); _roots.append(_root)
    _compatible=[]
    for stale_root in _roots:
        prior=stale_root/'mlb_classic_engine_owned_resume'/'controller_state.json'
        if not prior.exists():
            continue
        try:
            candidate=json.loads(prior.read_text(encoding='utf-8'))
        except Exception:
            continue
        if not all(str(candidate.get(k))==str(v) for k,v in identity.items()):
            continue
        last_raw=str(candidate.get('LAST_CHECKPOINT') or '').strip()
        last=Path(last_raw) if last_raw else None
        if last is not None and not last.exists() and last.name:
            relocated=stale_root/'mlb_classic_engine_owned_resume'/last.name
            if relocated.exists():
                last=relocated
                candidate['LAST_CHECKPOINT']=str(relocated)
        # A prior terminal-stage fallthrough could leave STAGE_INDEX complete but
        # LAST_CHECKPOINT empty even though the pre-final checkpoint is durable.
        # Recover that exact checkpoint and replay FINAL_BOARD only.
        if (last is None or not last.exists()) and int(candidate.get('STAGE_INDEX',0))>=len(stages):
            _ck_dir=stale_root/'mlb_classic_engine_owned_resume'
            _cks=sorted(_ck_dir.glob('checkpoint_*.pkl'))
            if _cks:
                last=max(_cks,key=_checkpoint_order_key)
                candidate['LAST_CHECKPOINT']=str(last)
                candidate['STAGE_INDEX']=len(stages)-1
                candidate['COMPLETED_STAGES']=[x for x in list(candidate.get('COMPLETED_STAGES') or []) if str(x)!='FINAL_BOARD']
        if last is None or not last.exists():
            continue
        score=(
            int(candidate.get('STAGE_INDEX',0)),
            int(candidate.get('PACKET_CURSOR',0)),
            int(candidate.get('HEAVY_CURSOR',0)),
            int(candidate.get('STAGE0_PATTERN_CURSOR',0)),
            int(candidate.get('CROSS_PARENT_CURSOR',0)),
            int(prior.stat().st_mtime_ns),
        )
        _compatible.append((score,stale_root,candidate))
    if _compatible:
        _compatible.sort(key=lambda x:x[0],reverse=True)
        _score,stale_root,candidate=_compatible[0]
        migrated=dict(candidate)
        migrated['MIGRATED_FROM_RUN_ROOT']=str(stale_root)
        migrated['MIGRATION_SELECTION_SCORE']=list(_score[:3])
        migrated.setdefault('PACKET_CURSOR',0)
        migrated.setdefault('STAGE0_PATTERN_CURSOR',0)
        migrated.setdefault('CROSS_PARENT_CURSOR',0)
        migrated.setdefault('CHECKPOINT_RECEIPTS',{})
    if migrated is not None:
        state=migrated
        atomic_json(STATE_PATH,state)
    else:
        state={**identity,'STAGE_INDEX':0,'HEAVY_CURSOR':0,'PACKET_CURSOR':0,'STAGE0_PATTERN_CURSOR':0,'CROSS_PARENT_CURSOR':0,'LAST_CHECKPOINT':'','LAST_CHECKPOINT_SHA256':'','LAST_CHECKPOINT_BYTES':0,'CHECKPOINT_RECEIPTS':{},'COMPLETED_STAGES':[],'EXECUTION_STATE':'RUNNING'}
        atomic_json(STATE_PATH,state)
validate_controller_state(state)

def emit_native_terminal_handoff(state:dict)->dict:
    board=OUT/f'execution_{EXECUTION_ID}_final_board.csv'
    if not board.exists():
        raise RuntimeError('RUN_INVALID:FINAL_BOARD_MISSING_FOR_NATIVE_TERMINAL_HANDOFF')
    ck=Path(str(state.get('LAST_CHECKPOINT') or ''))
    if not ck.exists():
        raise RuntimeError('RUN_INVALID:SELECTOR_CHECKPOINT_MISSING_FOR_NATIVE_TERMINAL_HANDOFF')
    with ck.open('rb') as f:
        d=pickle.load(f)
    candidates=list(d.get('selector_candidates') or [])
    selector_order=list(d.get('selector_order') or [])
    objective_score=list(d.get('objective_score') or [])
    row_by=dict(d.get('row_by_lineup_id') or {})
    by_idx=dict(d.get('by_idx') or {})
    if not candidates or len(candidates)!=len(row_by):
        raise RuntimeError(f'RUN_INVALID:MLB_CLASSIC_TERMINAL_HANDOFF_COUNT_MISMATCH:{len(candidates)}:{len(row_by)}')
    if len(selector_order)!=len(candidates) or len(objective_score)!=len(candidates):
        raise RuntimeError(f'RUN_INVALID:MLB_CLASSIC_TERMINAL_SELECTOR_STATE_MISMATCH:{len(candidates)}:{len(selector_order)}:{len(objective_score)}')
    slots=('P1','P2','C','1B','2B','3B','SS','OF1','OF2','OF3')
    rows=[]
    _selector_rank_by_id = {str(candidates[int(idx)].lineup_id): int(rank + 1) for rank, idx in enumerate(selector_order)}
    _selector_score_by_id = {str(candidates[j].lineup_id): float(objective_score[j]) for j in range(len(candidates))}
    with board.open("r", encoding="utf-8-sig", newline="") as _bf:
        _native_pre_rows = list(csv.DictReader(_bf))
    _native_selected_ids = {str(r.get("LINEUP_ID", "")) for r in _native_pre_rows}
    for c in candidates:
        lid=str(c.lineup_id)
        roster=row_by.get(lid)
        if roster is None:
            raise RuntimeError(f'RUN_INVALID:MLB_CLASSIC_TERMINAL_HANDOFF_ROSTER_MISSING:{lid}')
        lineup=tuple(roster['lineup'])
        if len(lineup)!=10:
            raise RuntimeError(f'RUN_INVALID:MLB_CLASSIC_TERMINAL_HANDOFF_ROSTER_SIZE:{lid}:{len(lineup)}')
        metrics=dict(c.metrics)
        rec={
            'LINEUP_ID':lid,
            'SALARY':int(c.salary),
            'LEFTOVER':50000-int(c.salary),
            'STRUCTURE_FAMILY':str(getattr(c,'structure_family',roster.get('pattern',''))),
            'STRUCTURE_LANE':str(roster.get('lane','')),
            'STACK_SIGNATURE':str(roster.get('stack_signature','')),
            'MC_WIN_RATE':float(metrics.get('MC_WIN_RATE',0.0)),
            'MC_TOP_0_1_RATE':float(metrics.get('MC_TOP_0_1_RATE',0.0)),
            'MC_TOP_0_1_LCB':float(metrics.get('MC_TOP_0_1_LCB',0.0)),
            'MC_TOP_1_RATE':float(metrics.get('MC_TOP_1_RATE',0.0)),
            'MC_P95':float(metrics.get('P95',0.0)),
            'MC_P99':float(metrics.get('P99',0.0)),
            'MC_CVAR99':float(metrics.get('CVAR99',metrics.get('P99',0.0))),
            'MC_TRIALS':int(float(metrics.get('TRIALS',0.0))),
            'CORRELATION_SCORE':float(metrics.get('CORRELATION_SCORE',0.0)),
            'PROJECTED_EXACT_MATCH_DUPLICATION':float(metrics.get('DUPLICATION_RISK',0.0)),
            'OWNERSHIP_PRODUCT':float(metrics.get('OWNERSHIP_PRODUCT',0.0)),
            'CHALK_FAILURE_FADE_EDGE':float(metrics.get('CHALK_FAILURE_FADE_EDGE',0.0)),
            'SAME_WORLD_STRICT_MASS':float(metrics.get('SAME_WORLD_STRICT_MASS',0.0)),
            'SAME_WORLD_CORE_MASS':float(metrics.get('SAME_WORLD_CORE_MASS',0.0)),
            'SAME_WORLD_LOOSE_MASS':float(metrics.get('SAME_WORLD_LOOSE_MASS',0.0)),
            'SAME_WORLD_WIN_MASS':float(metrics.get('SAME_WORLD_WIN_MASS',0.0)),
            'SAME_WORLD_CORE_HALF_MIN':float(metrics.get('SAME_WORLD_CORE_HALF_MIN',0.0)),
            'SAME_WORLD_TOP01_CONVERSION':float(metrics.get('SAME_WORLD_TOP01_CONVERSION',0.0)),
            'WORLD_COVERAGE':float(metrics.get('WORLD_COVERAGE',0.0)),
            'WORLD_COVERAGE_COUNT':float(metrics.get('WORLD_COVERAGE_COUNT',0.0)),
            'TOTAL_RECURRENCE':float(metrics.get('TOTAL_RECURRENCE',0.0)),
            'CURRENT_SELECTOR_SCORE':float(_selector_score_by_id.get(lid,0.0)),
            'CURRENT_SELECTOR_RANK':int(_selector_rank_by_id.get(lid,len(candidates)+1)),
            'CURRENT_SELECTOR_SELECTED':int(lid in _native_selected_ids),
        }
        _hitters = tuple(int(i) for i in lineup[2:])
        _market_tt = float(sum(float(team_total.get(str(by_idx[int(i)]['team']), 4.5)) for i in _hitters) / max(1, len(_hitters)))
        rec['LINEUP_MARKET_TT'] = _market_tt
        rec['STACK_MARKET_TOTAL'] = _market_tt
        rec['STRATEGY_SCORE'] = float(sum(float(by_idx[int(i)].get('strategy_leverage',0.0)) for i in lineup))
        for slot,idx0 in zip(slots,lineup):
            meta=by_idx[int(idx0)]
            rec[slot]=str(meta['name'])
            rec[slot+'_TEAM']=str(meta['team'])
            rec[slot+'_SALARY']=int(meta['salary'])
            rec[slot+'_ID']=str(meta['pid'])
        rows.append(rec)
    surface=OUT/f'DK_MLB_CLASSIC_{EXECUTION_ID}_AI_TERMINAL_CANDIDATES.csv'
    receipt=OUT/f'DK_MLB_CLASSIC_{EXECUTION_ID}_AI_TERMINAL_CANDIDATES_RECEIPT.json'
    ai=terminal_ai.write_review_surface(
        rows,csv_path=surface,receipt_path=receipt,sport='MLB',mode='CLASSIC',execution_id=EXECUTION_ID,
        context={
            'GLOBAL_FULL_HANDOFF':True,'NO_PRUNING':True,
            'DECLARED_SELECTOR_REVIEWED_LINEUPS':len(rows),
            'SOURCE':'MLB_CLASSIC_ENGINE_OWNED_SELECTOR_CHECKPOINT',
            'CURRENT_CODE_SELECTOR_ROLE':'ADVISORY_COMPARATOR_ONLY',
        },
    )
    durable_export={
        'STATUS':'NOT_ATTEMPTED','PATCH_ID':'MLB_CLASSIC_AUTHORITY_DURABLE_EXPORT_v1',
        'BUNDLE_PATH':'','BUNDLE_SHA256':'','RECEIPT_PATH':'','ERROR_CLASS':'','ERROR':'',
    }
    try:
        durable_export=authority_persist.seal_durable_prelock_bundle(
            candidate_surface=surface, candidate_receipt=receipt,
            prelock_surface=ai['AUTHORITY_PRELOCK_SURFACE'],
            prelock_manifest=ai['AUTHORITY_PRELOCK_MANIFEST'],
            final_board=board, controller_state=STATE_PATH,
            native_artifacts_zip=OUT/f'execution_{EXECUTION_ID}_artifacts.zip',
            output_zip=OUT/f'execution_{EXECUTION_ID}_authority_calibration_bundle.zip',
        )
    except Exception as exc:
        durable_export={
            'STATUS':'FAILED_NONBLOCKING','PATCH_ID':'MLB_CLASSIC_AUTHORITY_DURABLE_EXPORT_v1',
            'BUNDLE_PATH':'','BUNDLE_SHA256':'','RECEIPT_PATH':'',
            'ERROR_CLASS':type(exc).__name__,'ERROR':str(exc)[:500],
        }
    with board.open('r',encoding='utf-8-sig',newline='') as f:
        native_board=list(csv.DictReader(f))
    obj={
        'RUN_STATE':'NATIVE_BOARD_READY_FOR_GLOBAL_CORE5',
        'EXECUTION_STATE':'EXECUTION_ATTEMPTED',
        'PATCH_ID':'MLB_CLASSIC_GLOBAL_TERMINAL_SELECTOR_HANDOFF_v1',
        'SPORT':'MLB','MODE':'CLASSIC','EXECUTION_ID':EXECUTION_ID,
        'TERMINAL_PLAYABLE_BOARD':False,
        'GLOBAL_CHAMPIONSHIP_CORE_REQUIRED':True,
        'GLOBAL_CHAMPIONSHIP_CORE_SIZE':5,
        'NATIVE_BOARD_SIZE':len(native_board),
        'FINAL_BOARD_SIZE':len(native_board),
        'FINAL_BOARD':native_board,
        'AI_TERMINAL_AUTHORITY_REQUIRED':False,
        'AI_TERMINAL_PATCH_ID':terminal_ai.PATCH_ID,
        'AI_TERMINAL_CANDIDATE_SURFACE_PATH':str(surface),
        'AI_TERMINAL_CANDIDATE_RECEIPT_PATH':str(receipt),
        'AI_TERMINAL_CANDIDATE_FREEZE_SHA256':ai['CANDIDATE_FREEZE_SHA256'],
        'AI_TERMINAL_CANDIDATE_COUNT':len(rows),
        'SELECTOR_REVIEWED_LINEUPS':len(rows),
        'AI_TERMINAL_NO_PRUNING':True,
        'WORLD_RECURRENCE_BREADTH_AVAILABLE':True,
        'AUTHORITY_DURABLE_EXPORT_STATUS':str(durable_export.get('STATUS','')),
        'AUTHORITY_DURABLE_EXPORT_PATCH_ID':str(durable_export.get('PATCH_ID','MLB_CLASSIC_AUTHORITY_DURABLE_EXPORT_v1')),
        'AUTHORITY_DURABLE_BUNDLE_PATH':str(durable_export.get('BUNDLE_PATH','')),
        'AUTHORITY_DURABLE_BUNDLE_SHA256':str(durable_export.get('BUNDLE_SHA256','')),
        'AUTHORITY_DURABLE_EXPORT_RECEIPT':str(durable_export.get('RECEIPT_PATH','')),
        'AUTHORITY_DURABLE_EXPORT_ERROR_CLASS':str(durable_export.get('ERROR_CLASS','')),
        'AUTHORITY_DURABLE_EXPORT_ERROR':str(durable_export.get('ERROR','')),
        'CONTROLLER_STATE':str(STATE_PATH),
    }
    print(json.dumps(obj,indent=2),flush=True)
    return obj

idx=int(state.get('STAGE_INDEX',0))
if idx>=len(stages):
    board=OUT/f'execution_{EXECUTION_ID}_final_board.csv'
    if not board.exists(): raise RuntimeError('RUN_INVALID:FINAL_BOARD_MISSING_AFTER_CONTROLLER_COMPLETE')
    emit_native_terminal_handoff(state)
    print(json.dumps({'RUN_STATE':'COMPLETE','EXECUTION_STATE':'TOOL_PROVEN_EXECUTED','PATCH_ID':PATCH_ID,'FINAL_BOARD_PATH':str(board),'CONTROLLER_STATE':str(STATE_PATH)}),flush=True)
    raise SystemExit(0)

name,start,end=stages[idx]
ck_in=str(state.get('LAST_CHECKPOINT') or '')
_previous_checkpoint=ck_in
final=(name=='FINAL_BOARD')
ck_out='' if final else str(CTRL_ROOT/f'checkpoint_{idx:02d}_{name}.pkl')
env=dict(os.environ)
env.update({
    'APEX_INTERNAL_SPLIT_SOURCE':str(SOURCE),
    'APEX_INTERNAL_SPLIT_SOURCE_SHA256':SOURCE_SHA,
    'APEX_INTERNAL_SPLIT_STAGE_NAME':name,
    'APEX_INTERNAL_SPLIT_START':str(start),
    'APEX_INTERNAL_SPLIT_END':str(end),
    'APEX_INTERNAL_SPLIT_CHECKPOINT_IN':ck_in,
    'APEX_INTERNAL_SPLIT_CHECKPOINT_OUT':ck_out,
    'APEX_INTERNAL_SPLIT_FINAL':'1' if final else '0',
})

if name=='STAGE0_PHASE2_BASE_PATTERN_BIRTH':
    if not ck_in:
        raise RuntimeError('RUN_INVALID:STAGE0_PATTERN_CHECKPOINT_INPUT_MISSING')
    with open(ck_in,'rb') as _pattern_f:
        _pattern_state=pickle.load(_pattern_f)
    total=len(_pattern_state.get('PATTERNS') or [])
    cursor=int(state.get('STAGE0_PATTERN_CURSOR',0))
    step=max(1,int(os.environ.get('APEX_MLB_CLASSIC_STAGE0_PATTERN_CHUNK','1')))
    stop=min(total,cursor+step)
    if total <= 0:
        raise RuntimeError('RUN_INVALID:STAGE0_PATTERN_TOTAL_ZERO')
    env['APEX_INTERNAL_LOOP_KIND']='STAGE0_BASE_PATTERN_BIRTH'
    env['APEX_INTERNAL_PATTERN_START']=str(cursor); env['APEX_INTERNAL_PATTERN_END']=str(stop)
    ck_out=str(CTRL_ROOT/f'checkpoint_{idx:02d}_{name}_{stop:04d}.pkl'); env['APEX_INTERNAL_SPLIT_CHECKPOINT_OUT']=ck_out
elif name=='PHASE2_CROSS_PATTERN_ONE_HOP':
    if not ck_in:
        raise RuntimeError('RUN_INVALID:CROSS_PATTERN_CHECKPOINT_INPUT_MISSING')
    with open(ck_in,'rb') as _cross_f:
        _cross_state=pickle.load(_cross_f)
    total=len(_cross_state.get('right_neighborhood_5_3_parents') or [])
    cursor=int(state.get('CROSS_PARENT_CURSOR',0))
    step=int(_cross_state.get('MLB_PHASE2_BLOCK_ROWS',4096))
    if step != 4096:
        raise RuntimeError(f'RUN_INVALID:CROSS_PATTERN_BLOCK_ROWS:{step}')
    stop=min(total,cursor+step)
    if total <= 0:
        raise RuntimeError('RUN_INVALID:CROSS_PATTERN_PARENT_TOTAL_ZERO')
    env['APEX_INTERNAL_LOOP_KIND']='CROSS_PATTERN_PARENT_BLOCK'
    env['APEX_INTERNAL_CROSS_PARENT_START']=str(cursor)
    env['APEX_INTERNAL_CROSS_PARENT_END']=str(stop)
    env['APEX_INTERNAL_CROSS_BLOCK_INDEX']=str(cursor // step)
    ck_out=str(CTRL_ROOT/f'checkpoint_{idx:02d}_{name}_{stop:06d}.pkl'); env['APEX_INTERNAL_SPLIT_CHECKPOINT_OUT']=ck_out
    _orphan=Path(ck_out)
    if _orphan.exists() and int(stop)>int(cursor):
        _orphan_bytes=int(_orphan.stat().st_size)
        if _orphan_bytes <= 0:
            raise RuntimeError('RUN_INVALID:CROSS_PATTERN_ORPHAN_CHECKPOINT_EMPTY')
        _orphan_sha=sha256_file(_orphan)
        state['LAST_CHECKPOINT']=str(_orphan)
        state['LAST_CHECKPOINT_SHA256']=_orphan_sha
        state['LAST_CHECKPOINT_BYTES']=_orphan_bytes
        state.setdefault('CHECKPOINT_RECEIPTS',{})[name]={'PATH':str(_orphan),'SHA256':_orphan_sha,'BYTES':_orphan_bytes,'RECOVERED_AFTER_HOST_CUTOFF':True}
        state['CROSS_PARENT_CURSOR']=int(stop)
        if int(stop)>=int(total):
            state['STAGE_INDEX']=idx+1; state['COMPLETED_STAGES'].append(name); state['CROSS_PARENT_CURSOR']=0
        state['EXECUTION_STATE']='RESUMABLE'; atomic_json(STATE_PATH,state)
        print(json.dumps({'RUN_STATE':'ORPHAN_CHECKPOINT_RECOVERED','EXECUTION_STATE':'RESUMABLE','PATCH_ID':PATCH_ID,'STAGE':name,'CURSOR':int(stop),'CHECKPOINT':str(_orphan),'CHECKPOINT_SHA256':_orphan_sha,'CHECKPOINT_BYTES':_orphan_bytes}),flush=True)
        raise SystemExit(CONTINUE_RC)
elif name=='PHASE2_221111_HEAVY':
    n=hitter_team_count(); total=n*(n-1)//2; cursor=int(state.get('HEAVY_CURSOR',0)); step=max(1,int(os.environ.get('APEX_MLB_CLASSIC_INTERNAL_PAIR_CHUNK','20')))
    stop=min(total,cursor+step)
    env['APEX_INTERNAL_221111_PAIR_START']=str(cursor); env['APEX_INTERNAL_221111_PAIR_END']=str(stop)
    ck_out=str(CTRL_ROOT/f'checkpoint_{idx:02d}_{name}_{stop:04d}.pkl'); env['APEX_INTERNAL_SPLIT_CHECKPOINT_OUT']=ck_out
elif name=='HANDOFF_RAW_SELECTOR_PACKET':
    with open(ck_in,'rb') as _packet_f:
        total=len(__import__('pickle').load(_packet_f).get('handoff_indices',[])) if ck_in else 0
    cursor=int(state.get('PACKET_CURSOR',0))
    _override=os.environ.get('APEX_MLB_CLASSIC_INTERNAL_PACKET_CHUNK')
    if _override:
        step=max(1,int(_override))
    else:
        # Packet row construction is cheap relative to serializing the full engine
        # state. Amortize checkpoint I/O while retaining a bounded resume cursor.
        remaining=max(0,total-cursor)
        step=max(1,min(20000,remaining))
    stop=min(total,cursor+step)
    if total <= 0: raise RuntimeError('RUN_INVALID:HANDOFF_PACKET_TOTAL_ZERO')
    env['APEX_INTERNAL_LOOP_KIND']='RAW_SELECTOR_PACKET'
    env['APEX_INTERNAL_PACKET_START']=str(cursor); env['APEX_INTERNAL_PACKET_END']=str(stop)
    ck_out=str(CTRL_ROOT/f'checkpoint_{idx:02d}_{name}_{stop:04d}.pkl'); env['APEX_INTERNAL_SPLIT_CHECKPOINT_OUT']=ck_out
else:
    total=None; cursor=None; stop=None

if final:
    cp=subprocess.run([str(WORKER)],env=env,cwd=str(STATE_ROOT),check=False,stdout=subprocess.PIPE,text=True)
else:
    cp=subprocess.run([str(WORKER)],env=env,cwd=str(STATE_ROOT),check=False)
board=OUT/f'execution_{EXECUTION_ID}_final_board.csv'
if final and cp.returncode==0 and board.exists():
    state['STAGE_INDEX']=len(stages); state['EXECUTION_STATE']='COMPLETED'; state['FINAL_BOARD_PATH']=str(board); atomic_json(STATE_PATH,state)
    emit_native_terminal_handoff(state)
    print(json.dumps({'RUN_STATE':'COMPLETE','EXECUTION_STATE':'TOOL_PROVEN_EXECUTED','PATCH_ID':PATCH_ID,'FINAL_BOARD_PATH':str(board),'CONTROLLER_STATE':str(STATE_PATH)}),flush=True)
    raise SystemExit(0)
if final and cp.returncode==0 and not board.exists():
    raise RuntimeError('RUN_INVALID:FINAL_BOARD_ARTIFACT_MISSING_AFTER_FINAL_STAGE')
if cp.returncode!=0:
    raise SystemExit(cp.returncode)
if not Path(ck_out).exists():
    raise RuntimeError(f'RUN_INVALID:INTERNAL_CHECKPOINT_NOT_COMMITTED:{name}')
_ck_path=Path(ck_out)
_ck_bytes=int(_ck_path.stat().st_size)
if _ck_bytes <= 0:
    raise RuntimeError(f'RUN_INVALID:INTERNAL_CHECKPOINT_EMPTY:{name}')
_ck_sha256=sha256_file(_ck_path)
state['LAST_CHECKPOINT']=ck_out
state['LAST_CHECKPOINT_SHA256']=_ck_sha256
state['LAST_CHECKPOINT_BYTES']=_ck_bytes
state.setdefault('CHECKPOINT_RECEIPTS',{})[name]={'PATH':ck_out,'SHA256':_ck_sha256,'BYTES':_ck_bytes}
if name=='STAGE0_PHASE2_BASE_PATTERN_BIRTH':
    state['STAGE0_PATTERN_CURSOR']=int(stop)
    if int(stop)>=int(total):
        state['STAGE_INDEX']=idx+1; state['COMPLETED_STAGES'].append(name); state['STAGE0_PATTERN_CURSOR']=0
elif name=='PHASE2_CROSS_PATTERN_ONE_HOP':
    state['CROSS_PARENT_CURSOR']=int(stop)
    if int(stop)>=int(total):
        state['STAGE_INDEX']=idx+1; state['COMPLETED_STAGES'].append(name); state['CROSS_PARENT_CURSOR']=0
elif name=='PHASE2_221111_HEAVY':
    state['HEAVY_CURSOR']=int(stop)
    if int(stop)>=int(total):
        state['STAGE_INDEX']=idx+1; state['COMPLETED_STAGES'].append(name); state['HEAVY_CURSOR']=0
elif name=='HANDOFF_RAW_SELECTOR_PACKET':
    state['PACKET_CURSOR']=int(stop)
    if int(stop)>=int(total):
        state['STAGE_INDEX']=idx+1; state['COMPLETED_STAGES'].append(name); state['PACKET_CURSOR']=0
else:
    state['STAGE_INDEX']=idx+1; state['COMPLETED_STAGES'].append(name)
state['EXECUTION_STATE']='RESUMABLE'; atomic_json(STATE_PATH,state)
_removed_checkpoints=prune_checkpoint_files(ck_out,_previous_checkpoint)
if _removed_checkpoints:
    print(json.dumps({'RUN_STATE':'ENGINE_CHECKPOINT_GC','PATCH_ID':PATCH_ID,'REMOVED_COUNT':len(_removed_checkpoints),'CURRENT':ck_out,'FALLBACK':_previous_checkpoint}),file=sys.stderr,flush=True)
next_name=stages[int(state['STAGE_INDEX'])][0] if int(state['STAGE_INDEX'])<len(stages) else 'FINAL_BOARD_COMPLETE'
print(json.dumps({
    'RUN_STATE':'CHECKPOINTED_CONTINUE','EXECUTION_STATE':'RESUMABLE','PATCH_ID':PATCH_ID,
    'COMPLETED_STAGE':name,'NEXT_STAGE':next_name,'STAGE_INDEX':int(state['STAGE_INDEX']),
    'STAGE0_PATTERN_CURSOR':int(state.get('STAGE0_PATTERN_CURSOR',0)),'CROSS_PARENT_CURSOR':int(state.get('CROSS_PARENT_CURSOR',0)),'HEAVY_CURSOR':int(state.get('HEAVY_CURSOR',0)),'PACKET_CURSOR':int(state.get('PACKET_CURSOR',0)),'CHECKPOINT':ck_out,'CHECKPOINT_SHA256':_ck_sha256,'CHECKPOINT_BYTES':_ck_bytes,'CONTROLLER_STATE':str(STATE_PATH)
}),flush=True)
raise SystemExit(CONTINUE_RC)
