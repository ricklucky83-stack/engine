from __future__ import annotations
import hashlib, json
from pathlib import Path

PATCH_ID="MLB_CLASSIC_SAVED_TOP50_FAMILY_DOOR_CALIBRATION_v1"

def load(path: str | Path) -> dict:
    data=json.loads(Path(path).read_text())
    if data.get("PATCH_ID") != PATCH_ID:
        raise RuntimeError("CALIBRATION_PATCH_ID_MISMATCH")
    return data

def active_slate_fingerprint(rows) -> str:
    canon=[]
    for r in rows:
        canon.append(
            f"{str(r['PLAYER']).strip()}|{str(r['TEAM']).strip()}|{str(r['OPP']).strip()}|"
            f"{str(r['POS']).strip()}|{str(r['LINEUP']).strip()}|{str(r['SAL']).strip()}"
        )
    return hashlib.sha256("\n".join(sorted(canon)).encode()).hexdigest()

def validate_matching_slate(calibration: dict, active_rows) -> str:
    fp=active_slate_fingerprint(active_rows)
    expected=str(calibration["CALIBRATION_SLATE_FINGERPRINT"])
    if fp != expected:
        raise RuntimeError(f"CALIBRATION_SLATE_MISMATCH:{fp}:{expected}")
    return fp

def families(calibration: dict):
    return tuple(calibration.get("FAMILIES", ()))
