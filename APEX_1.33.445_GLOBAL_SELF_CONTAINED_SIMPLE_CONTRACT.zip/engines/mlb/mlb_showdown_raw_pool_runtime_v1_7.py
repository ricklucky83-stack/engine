from __future__ import annotations
import argparse, base64, hashlib, itertools, json, math, os, time
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
from numba import njit
from mlb_showdown_contest_finish_ranker_v1 import PATCH_ID as RANKER_PATCH_ID, RANKER_ID, contest_finish_components, rank_selected_board, wilson_ucb, wilson_lcb
from mlb_showdown_bullpen_role_model_v1 import PATCH_ID as BULLPEN_ROLE_PATCH_ID, estimate_relief_role
from mlb_showdown_slate_context_v1 import FrozenSlateContext, build_phase1_context, merge_phase2_context, assert_context_unchanged, PATCH_ID as SLATE_CONTEXT_PATCH_ID
from mlb_showdown_postlock_board_rank_evaluator_v1 import evaluate_board
from mlb_showdown_dual_sp_trophy_posterior_v1 import PATCH_ID as DUAL_SP_TROPHY_POSTERIOR_PATCH_ID, adjust_tail_rate as dual_sp_adjust_tail_rate, calibration_receipt as dual_sp_calibration_receipt
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix
import mlb_hitter_attackable_pa_adjustment_v1 as attackable_pa_mod
import mlb_showdown_side_commitment_gate_v1 as side_commitment_gate
import mlb_showdown_perfect_family_sibling_recall_v1 as perfect_family_recall
import mlb_right_neighborhood_wrong_door_authority_v1 as rnwd
from engines.common import apex_global_championship_event_core_v1 as championship_core_mod
from engines.common import apex_terminal_ai_hybrid_selector_v6 as terminal_ai_mod
from engines.mlb.mlb_ev_live_canary_v1 import run_showdown_s1_canary

import importlib.util as _strategy_importlib_util
from engines.common.apex_pregame_data_recovery_v1 import repair_team_runs, RecoverablePregameDataGap
from engines.common.apex_team_total_mc_contract_v1 import PATCH_ID as TT_MC_PATCH_ID, environment_from_pool, correlation_matrix, team_total_paths
_STRATEGY_PATH = Path(__file__).resolve().parents[2] / "engines" / "common" / "apex_global_sports_strategy_layer_v1.py"
_strategy_spec = _strategy_importlib_util.spec_from_file_location("apex_global_sports_strategy_layer_v1", _STRATEGY_PATH)
if _strategy_spec is None or _strategy_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_SPORTS_STRATEGY_LAYER_UNAVAILABLE")
global_strategy = _strategy_importlib_util.module_from_spec(_strategy_spec)
_strategy_spec.loader.exec_module(global_strategy)
GLOBAL_SPORTS_STRATEGIST_PATCH_ID = global_strategy.PATCH_ID
_LAST_STRATEGY_RECEIPT = {}
_LAST_ATTACKABLE_PA_RECEIPT = {}
_LAST_MC_ENV_RECEIPT = {}
_LAST_TEAM_RUN_PATHS = {}

_CALIBRATION_FREEZE_PATH = Path(__file__).resolve().parents[2] / "engines" / "common" / "apex_phase1_calibration_freeze_v1.py"
_calibration_spec = _strategy_importlib_util.spec_from_file_location("apex_phase1_calibration_freeze_v1", _CALIBRATION_FREEZE_PATH)
if _calibration_spec is None or _calibration_spec.loader is None:
    raise RuntimeError("RUN_INVALID:PHASE1_CALIBRATION_FREEZE_CONTRACT_UNAVAILABLE")
calibration_freeze = _strategy_importlib_util.module_from_spec(_calibration_spec)
calibration_freeze.__package__ = ""
sys_modules = __import__('sys').modules
sys_modules[_calibration_spec.name] = calibration_freeze
_calibration_spec.loader.exec_module(calibration_freeze)
CALIBRATION_FREEZE_PATCH_ID = calibration_freeze.PATCH_ID

_SELF_CONFLICT_GATE_PATH = Path(__file__).resolve().parents[2] / "engines" / "common" / "apex_global_lineup_self_conflict_gate_v1.py"
_self_conflict_spec = _strategy_importlib_util.spec_from_file_location("apex_global_lineup_self_conflict_gate_v1", _SELF_CONFLICT_GATE_PATH)
if _self_conflict_spec is None or _self_conflict_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_LINEUP_SELF_CONFLICT_GATE_UNAVAILABLE")
self_conflict_gate = _strategy_importlib_util.module_from_spec(_self_conflict_spec)
_self_conflict_spec.loader.exec_module(self_conflict_gate)
SELF_CONFLICT_GATE_PATCH_ID = self_conflict_gate.PATCH_ID
SIDE_COMMITMENT_PATCH_ID = side_commitment_gate.PATCH_ID

POOL_PATH=Path(os.environ.get('APEX_PLAYER_POOL',''))
OUT=Path(os.environ.get('APEX_OUTPUT_DIR','/mnt/data'))
FIELD_SIZE=int(os.environ.get('APEX_FIELD_SIZE','1604'))
EXECUTION_ID=str(os.environ.get('APEX_EXECUTION_ID',FIELD_SIZE))
# APEX_MLB_SD_MAX_ENTRY_METADATA_ONLY_v1
# MAX ENTRY is not an execution authority. It may be present as inert contest
# metadata, but it may not gate execution, size a selector, or determine final
# lineup membership. Membership is owned by the .00001 qualification surface.
_MAX_ENTRY_RAW=os.environ.get('APEX_USER_ENTRIES') or os.environ.get('APEX_MAX_ENTRIES') or os.environ.get('APEX_BOARD_SIZE')
try:
    MAX_ENTRY_METADATA=(int(_MAX_ENTRY_RAW) if _MAX_ENTRY_RAW is not None and str(_MAX_ENTRY_RAW).strip() else None)
except Exception:
    MAX_ENTRY_METADATA=None
OUTPUT_LINEUP_QUOTA=None
FAKE_FIELD=int(math.ceil(FIELD_SIZE*3.4))
TOP01_CUTOFF=max(1,math.ceil(FAKE_FIELD*.001))
TOP10_EQUIV_CUTOFF=max(1,min(FAKE_FIELD,math.ceil(10*FAKE_FIELD/max(FIELD_SIZE,1))))
SEED=int(os.environ.get('APEX_SEED',str((FIELD_SIZE*10000+17)%(2**32-1))))
PHASE1_TRIALS=int(os.environ.get('APEX_PHASE1_TRIALS','50000'))
BASE_TRIALS=PHASE1_TRIALS if os.environ.get('APEX_ENGINE_ONLY_EXECUTION_CONTRACT') else int(os.environ.get('APEX_BASE_TRIALS','10000'))
EXTRA_TRIALS=0 if os.environ.get('APEX_ENGINE_ONLY_EXECUTION_CONTRACT') else int(os.environ.get('APEX_EXTRA_TRIALS','40000'))
MULTI_SEED_BASE_TRIALS=int(os.environ.get('APEX_MULTI_SEED_BASE_TRIALS','10000'))
MULTI_SEED_MAX_ROUNDS=int(os.environ.get('APEX_MULTI_SEED_MAX_ROUNDS','3'))
MULTI_SEED_SEED0=int(os.environ.get('APEX_MULTI_SEED_SEED0',str((SEED+1000003)%(2**32-1))))
MC_TRIAL_CHUNK=max(250,int(os.environ.get('APEX_MC_TRIAL_CHUNK','5000')))
MC_CHECKPOINT_ENABLED=os.environ.get('APEX_MC_CHECKPOINT_ENABLED','1').strip().lower() not in {'0','false','no','off'}
FIELD_THRESHOLD_TRIAL_CHUNK=max(100,int(os.environ.get('APEX_FIELD_THRESHOLD_TRIAL_CHUNK','1000')))
LINEUP_SCORE_TRIAL_CHUNK=max(100,int(os.environ.get('APEX_LINEUP_SCORE_TRIAL_CHUNK','500')))
STREAMING_PATCH_ID='MLB_SD_STREAMING_MC_CHECKPOINT_AND_CHUNKED_SCORING_v1'
_LAST_STREAMING_RECEIPTS={}
ROLE_COMPLETE_PATCH_ID='MLB_SD_ROLE_COMPLETE_PARITY_TAIL_SHADOW_v1.0'
PATCH_ID='MLB_SD_PRODUCTION_REPAIRED_MC_PORTFOLIO_UNION_v1'
DIVERSITY_PATCH_ID='MLB_SD_SP_CPT_CONTROL_5_1_DIVERSE_SIBLING_CLOSURE_v2.3'
ENGINE_ID='APEX_MLB_SHOWDOWN_RAW_POOL_RUNTIME_v1.9.1_STREAMING_CHECKPOINT'
RP_RESTORE_PATCH_ID='MLB_SD_ELITE_DUAL_RP_CONDITIONAL_RECALL_v1'
FIELD_SELECTOR_REPAIR_PATCH_ID='MLB_SD_OWNERSHIP_CALIBRATED_FIELD_AND_ELITE_TAIL_SELECTOR_v1'
HR_PROBABILITY_PARITY_PATCH_ID='MLB_SD_CLASSIC_HR_GAME_TO_PA_PARITY_v1'
ELITE_CORE_SIBLING_PATCH_ID='MLB_SD_ELITE_CORE_ONE_SWAP_SIBLING_PRESERVATION_v1'
PRODUCTION_MC_PATCH_ID='MLB_SD_EVENT_NATIVE_MC_REPAIR_v1'
PORTFOLIO_UNION_SELECTOR_PATCH_ID='MLB_SD_PORTFOLIO_UNION_SELECTOR_v1'
UNDERDOG_OPP_SP_42_CLOSURE_PATCH_ID='MLB_SD_HITTER_CPT_UNDERDOG_OPP_SP_4_2_ISOLATED_DAMAGE_PREMIUM_CORE_v1'
CAPTAIN_ELIGIBILITY_PATCH_ID='MLB_SD_CAPTAIN_BARGAIN_VALUE_FIRST_v1'
CAPTAIN_BARGAIN_LINEUP_TAIL_RATIO=0.97
CAPTAIN_BARGAIN_INDIVIDUAL_TAIL_RATIO=0.83
CAPTAIN_BARGAIN_MAX_BASE_SALARY_SHARE=0.80
CAPTAIN_COVERAGE_INDIVIDUAL_TAIL_RATIO=0.80
SLATE_BREAKER_MEDIAN_MULT=1.25
SLATE_BREAKER_IQR_MULT=1.50
SLATE_BREAKER_GAP_ABS=4.0
SLATE_BREAKER_GAP_SECOND_RATIO=0.12
SLATE_BREAKER_GAP_IQR_MULT=0.75
HIGH_MARKET_SP_CPT_42_BIRTH_PATCH_ID='MLB_SD_HIGH_HIGH_SP_CPT_CONTROL_4_2_MULTI_TAIL_BIRTH_CLOSURE_v2'
SP_CPT_DUAL_SP_ATTACK_HEDGE_PATCH_ID='MLB_SD_SP_CPT_DUAL_SP_ATTACK_HEDGE_RECALL_v1'
CHAMPIONSHIP_CORE_CAPTAIN_PROMOTION_PATCH_ID='APEX_MLB_SHOWDOWN_CHAMPIONSHIP_CORE_CAPTAIN_PRIORITY_PROMOTION_v1'
CORE5_HIGH_CONFIDENCE_PARLAY_PATCH_ID='MLB_SD_CORE5_HIGH_CONFIDENCE_PARLAY_v1'
PERFECT_FAMILY_SIBLING_RECALL_PATCH_ID=perfect_family_recall.PATCH_ID
SINGLE_RP_FULL_VISIBILITY_PATCH_ID='MLB_SD_SINGLE_RP_CALIBRATION_QUALIFIED_FULL_VISIBILITY_v1'
UNDERDOG_VALUE_CPT_51_SINGLE_RP_PATCH_ID='MLB_SD_HITTER_CPT_UNDERDOG_5_1_SP_SINGLE_RP_RECALL_v1'
BARGAIN_CORE5_SELECTOR_PATCH_ID='MLB_SD_BARGAIN_CPT_AND_UNDERDOG_5_1_DISTRIBUTED_CORE5_v1'
GLOBAL_CORE_PROTECTION_KEY_PARITY_PATCH_ID='MLB_SD_GLOBAL_CORE_PROTECTION_KEY_PARITY_v1'
UNDERDOG_VALUE_CPT_ELITE_COND_RP_CORE5_PATCH_ID='MLB_SD_UNDERDOG_VALUE_CPT_NO_FULL_PRICE_ELITE_COND_RP_CORE5_v1'
UNDERDOG_VALUE_CPT_ELITE_COND_RP_ROLE_FLOOR=0.15
UNDERDOG_VALUE_CPT_ELITE_COND_RP_TAIL_RATIO=0.95
CORE5_FULL_RUN_PRIORITY_ZERO_GAIN_PATCH_ID=championship_core_mod.PRIORITY_CORE_FULL_RUN_QUALIFIED_ZERO_GAIN_PATCH_ID
CROSS_BRANCH_FIVE_PLAYER_FAMILY_CLOSURE_PATCH_ID='MLB_SD_CROSS_BRANCH_FIVE_PLAYER_CHAMPIONSHIP_FAMILY_CLOSURE_v1'
CROSS_BRANCH_SUPERANCHOR_CORE5_PATCH_ID='MLB_SD_CROSS_BRANCH_SUPERANCHOR_LOW_OWN_FAMILY_CORE5_SENTINEL_v1'
POSTSEAL_WINNER_JSON=os.environ.get('APEX_POSTSEAL_WINNER_JSON')
CONTEST_FILE=os.environ.get('APEX_CONTEST_FILE')
if os.environ.get('APEX_EXECUTION_MODE', 'PRODUCTION') == 'PRODUCTION' and (POSTSEAL_WINNER_JSON or CONTEST_FILE):
    raise RuntimeError('RUN_INVALID_DIAGNOSTIC_INPUT_ON_PRODUCTION_TRIGGER')
WINNER=json.loads(POSTSEAL_WINNER_JSON) if POSTSEAL_WINNER_JSON else None
if WINNER:
    WINNER={'CPT':str(WINNER['CPT']),'UTILS':tuple(sorted(map(str,WINNER['UTILS'])))}
_LAST_FIELD_RECEIPT={}
FORBIDDEN=['FPTS','AVG FPTS','L10 FPTS','L14 FPTS','L30 FPTS','L7 FPTS','L5 FPTS','L3 FPTS','VAL']

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def num(x,d=0.0):
    try:
        if isinstance(x,str):
            x=x.replace('%','').replace(',','').strip()
            if x in {'','-','nan','None'}: return d
        v=float(x); return v if np.isfinite(v) else d
    except Exception: return d

def pct_rank(x):
    x=np.asarray(x); o=np.argsort(x,kind='mergesort'); z=np.empty(len(x),float); z[o]=np.linspace(0,1,len(x)); return z

def pct_rank_tie_aware(x):
    """Ascending percentile rank with equal values assigned the same mid-rank.

    Discrete/structural Core-5 parlay features use this helper so source-row
    order cannot manufacture leverage or late-order confidence inside ties.
    """
    x=np.asarray(x,float); n=len(x)
    if n==0: return np.zeros(0,float)
    if n==1: return np.ones(1,float)
    o=np.argsort(x,kind='mergesort'); sx=x[o]; z=np.empty(n,float)
    start=0
    while start<n:
        end=start+1
        while end<n and sx[end]==sx[start]: end+=1
        mid=((start+end-1)/2.0)/(n-1)
        z[o[start:end]]=mid
        start=end
    return z


def _prelock_market_targets_from_players(players):
    sp=[p for p in players if p.get('is_sp')]
    owns=sorted((float(p.get('own',0.0))/100.0 for p in sp),reverse=True)
    first=owns[0] if owns else 0.0; second=owns[1] if len(owns)>1 else 0.0
    dual=float(np.clip(0.20+0.55*second,0.20,0.75)) if len(owns)>=2 else 0.0
    spcpt=float(np.clip(0.25+0.45*((first+second)/2.0),0.25,0.75)) if len(owns)>=2 else float(np.clip(0.20+0.40*first,0.20,0.65))
    return {'TARGET_DUAL_SP_SHARE':dual,'TARGET_SP_CPT_SHARE':spcpt,'STARTER_OWNERSHIP_TOP2':(first,second)}


def _high_high_market_prelock(market_context):
    src=market_context or {}
    return float(src.get('TARGET_DUAL_SP_SHARE',0.0))>=0.50 and float(src.get('TARGET_SP_CPT_SHARE',0.0))>=0.50


def _utility_eligibility_arrays(players):
    rp=np.array([p['is_rp'] for p in players],np.int8)
    dual_rp_ok=np.array([int(p['is_rp'] and p.get('rp_qualified',False) and all(tag in p.get('rp_qual_reasons',()) for tag in ('P95_2P5X','ONE_PLUS_IP','K_SPIKE_2PLUS','WIN_HOLD_ROLE')) and p.get('role_prob',0.0)>=.28) for p in players],np.int8)
    teams=np.array([p['team'] for p in players],object)
    rp_keep=set()
    for team in sorted(set(teams.tolist())):
        ids=[i for i,p in enumerate(players) if p['is_rp'] and p['team']==team and p.get('rp_qualified',False)]
        ids.sort(key=lambda i:(-players[i]['role_prob'],-players[i]['games'],-players[i]['own'],players[i]['name']))
        # CAR SHOP: every calibration-qualified RP remains visible to one-RP
        # lineup enumeration. Dual-RP lineups remain separately gated by
        # dual_rp_ok inside the exact enumerator, so widening the one-RP
        # reservoir does not weaken the dual-RP role-quality contract.
        rp_keep.update(ids)
    eligible=np.array([i for i,p in enumerate(players) if not p['is_rp'] or i in rp_keep],np.int32)
    return eligible,rp,dual_rp_ok


def captain_eligibility(players,p1):
    """Pre-lock Captain gate: bargain/value first, slate-breaker by exception only.

    Captain is not awarded to the highest raw P99 merely because it is highest.
    The raw-ceiling path opens only when the leader is both astronomical relative
    to the slate and separated from the runner-up by a large, distribution-aware
    gap.  Otherwise Captain eligibility is driven by roster-unlock value: a
    cheaper player must preserve nearly all of the best legal six-man tail proxy
    while retaining a non-punt individual tail.
    """
    p1=np.asarray(p1,float); n=len(players)
    p95=np.quantile(p1,.95,axis=0); p99=np.quantile(p1,.99,axis=0)
    nonrp=np.array([i for i,p in enumerate(players) if not p['is_rp']],np.int32)
    if not len(nonrp): raise RuntimeError('CAPTAIN_ELIGIBILITY_NO_NON_RP_PLAYERS')
    sp=np.array([i for i,p in enumerate(players) if p.get('is_sp',False)],np.int32)

    # Raw-ceiling Captain is an exception, not the default.  Only the actual
    # slate leader can claim SLATE_BREAKER, and only with an astronomical level
    # plus a large separation from the second-best tail.
    vals=np.asarray(p99[nonrp],float)
    order=np.argsort(-vals,kind='mergesort')
    top_i=int(nonrp[int(order[0])]); top_p99=float(vals[int(order[0])])
    second_p99=float(vals[int(order[1])]) if len(order)>1 else 0.0
    p99_med=float(np.median(vals)); q25,q75=np.quantile(vals,[.25,.75]) if len(vals)>1 else (top_p99,top_p99)
    p99_iqr=float(max(0.0,q75-q25))
    astronomical_floor=float(max(SLATE_BREAKER_MEDIAN_MULT*p99_med,p99_med+SLATE_BREAKER_IQR_MULT*p99_iqr))
    large_gap_floor=float(max(SLATE_BREAKER_GAP_ABS,SLATE_BREAKER_GAP_SECOND_RATIO*second_p99,SLATE_BREAKER_GAP_IQR_MULT*p99_iqr))
    top_gap=float(top_p99-second_p99)
    p95_support_floor=float(np.quantile(p95[nonrp],.75))
    astronomical=bool(top_p99>=astronomical_floor-1e-12 and top_gap>=large_gap_floor-1e-12 and p95[top_i]>=p95_support_floor-1e-12)

    # If the astronomical leader is a pitcher, retain the existing blind market
    # participation confirmation.  A pitcher cannot become SLATE_BREAKER solely
    # from a simulated tail spike with no pre-lock participation support.
    sp_own_cut=None; pitcher_market_ok=True
    if players[top_i].get('is_sp',False):
        sp_own=np.array([float(players[i].get('own',0.0)) for i in sp],float)
        sp_own_cut=float(max(15.0,.50*np.max(sp_own))) if len(sp_own) else 15.0
        pitcher_market_ok=bool(float(players[top_i].get('own',0.0))>=sp_own_cut-1e-12)
    breaker=np.zeros(n,bool)
    if astronomical and pitcher_market_ok: breaker[top_i]=True

    # Bargain-shopping Captain branch.  Compare the *lineup* tail preserved by
    # each Captain salary, not sticker price or raw player P99 in isolation.
    eligible,rp,dual_rp_ok=_utility_eligibility_arrays(players)
    combos=np.asarray(list(itertools.combinations(eligible.tolist(),5)),np.int32)
    sal=np.array([p['salary'] for p in players],np.int32); teams=np.array([p['team'] for p in players],object)
    util_sal=sal[combos].sum(1); util_p99=p99[combos].sum(1)
    rp_n=rp[combos].sum(1); dual_ok_n=dual_rp_ok[combos].sum(1)
    combo_role_ok=(rp_n<=2)&((rp_n!=2)|(dual_ok_n==2))
    unlock_score=np.full(n,-np.inf,float)
    for c in nonrp:
        no_c=(combos!=int(c)).all(1); total_sal=util_sal+int(sal[c]*1.5); two_team=(teams[combos]!=teams[c]).any(1)
        ok=no_c & combo_role_ok & two_team & (total_sal>=40000) & (total_sal<=50000)
        if ok.any(): unlock_score[c]=1.5*p99[c]+float(np.max(util_p99[ok]))
    finite_ids=nonrp[np.isfinite(unlock_score[nonrp])]
    best_unlock=float(np.max(unlock_score[finite_ids])) if len(finite_ids) else float('-inf')
    unlock_cut=float(CAPTAIN_BARGAIN_LINEUP_TAIL_RATIO*best_unlock) if np.isfinite(best_unlock) else float('inf')
    individual_floor=float(CAPTAIN_BARGAIN_INDIVIDUAL_TAIL_RATIO*top_p99)
    max_sal=float(np.max(sal[nonrp])); salary_cap=float(CAPTAIN_BARGAIN_MAX_BASE_SALARY_SHARE*max_sal)
    unlock=np.zeros(n,bool)
    unlock[nonrp]=(unlock_score[nonrp]>=unlock_cut-1e-12)&(p99[nonrp]>=individual_floor-1e-12)&(sal[nonrp]<=salary_cap+1e-12)

    # Never let a degenerate slate revert to "highest P99 wins Captain".  If the
    # strict gates produce fewer than two Captains, fill by best legal six-man
    # roster-unlock proxy, preserving the bargain-shopping objective.
    # Generator recall is deliberately broader than final Captain priority.
    # Keep confirmed starters and non-RP hitters with a viable tail in the birth
    # universe as COVERAGE_ONLY so the engine does not create a generator miss
    # while still refusing to *prefer* them as Captain absent bargain value or
    # the astronomical slate-breaker exception.
    coverage=np.zeros(n,bool)
    coverage[sp]=True
    coverage[nonrp]|=(p99[nonrp]>=CAPTAIN_COVERAGE_INDIVIDUAL_TAIL_RATIO*top_p99-1e-12)
    coverage &= ~(breaker|unlock)

    fallback=np.zeros(n,bool)
    eligible_cpt=breaker|unlock|coverage
    if int(eligible_cpt.sum())<2 and len(finite_ids):
        ranked=finite_ids[np.argsort(-unlock_score[finite_ids],kind='mergesort')]
        for i in ranked:
            if eligible_cpt[int(i)]: continue
            eligible_cpt[int(i)]=True; unlock[int(i)]=True; fallback[int(i)]=True
            if int(eligible_cpt.sum())>=min(2,len(nonrp)): break

    for i,p in enumerate(players):
        ratio=(float(unlock_score[i])/best_unlock) if np.isfinite(unlock_score[i]) and np.isfinite(best_unlock) and best_unlock>0 else None
        indiv_ratio=(float(p99[i])/top_p99) if top_p99>0 else None
        p['cpt_eligible']=bool(eligible_cpt[i])
        p['cpt_slate_breaker']=bool(breaker[i])
        p['cpt_roster_unlock']=bool(unlock[i])
        p['cpt_bargain_value']=bool(unlock[i])
        p['cpt_emergency_unlock_fallback']=bool(fallback[i])
        p['cpt_coverage_only']=bool(coverage[i])
        p['cpt_player_p95']=float(p95[i]); p['cpt_player_p99']=float(p99[i])
        p['cpt_unlock_tail_proxy']=float(unlock_score[i]) if np.isfinite(unlock_score[i]) else None
        p['cpt_unlock_tail_ratio']=ratio
        p['cpt_individual_tail_ratio']=indiv_ratio
        p['cpt_priority_role']='SLATE_BREAKER' if breaker[i] else ('ROSTER_UNLOCKER' if unlock[i] else ('COVERAGE_ONLY' if coverage[i] else 'INELIGIBLE'))
    return {
        'PATCH_ID':CAPTAIN_ELIGIBILITY_PATCH_ID,
        'POLICY':'BARGAIN_VALUE_FIRST_RAW_CEILING_BY_ASTRONOMICAL_GAP_EXCEPTION_ONLY',
        'POSTLOCK_INPUT_USED':False,
        'RAW_P99_LEADER':players[top_i]['name'],
        'RAW_P99_LEADER_VALUE':top_p99,
        'RAW_P99_RUNNER_UP_VALUE':second_p99,
        'RAW_P99_LEADER_GAP':top_gap,
        'ASTRONOMICAL_P99_FLOOR':astronomical_floor,
        'LARGE_GAP_FLOOR':large_gap_floor,
        'P95_SUPPORT_FLOOR':p95_support_floor,
        'ASTRONOMICAL_GATE_PASS':bool(astronomical),
        'PITCHER_MARKET_GATE_PASS':bool(pitcher_market_ok),
        'BREAKER_P99_THRESHOLD':astronomical_floor,
        'PITCHER_BREAKER_P99_THRESHOLD':astronomical_floor,
        'PITCHER_OWNERSHIP_FLOOR':sp_own_cut,
        'UNLOCK_LINEUP_P99_THRESHOLD':unlock_cut,
        'BEST_LEGAL_SIX_MAN_TAIL_PROXY':best_unlock if np.isfinite(best_unlock) else None,
        'BARGAIN_LINEUP_TAIL_RATIO_MIN':CAPTAIN_BARGAIN_LINEUP_TAIL_RATIO,
        'BARGAIN_INDIVIDUAL_TAIL_RATIO_MIN':CAPTAIN_BARGAIN_INDIVIDUAL_TAIL_RATIO,
        'COVERAGE_INDIVIDUAL_TAIL_RATIO_MIN':CAPTAIN_COVERAGE_INDIVIDUAL_TAIL_RATIO,
        'PLAYER_P99_MEDIAN':p99_med,
        'UNLOCK_MAX_CPT_BASE_SALARY':salary_cap,
        'ELIGIBLE_COUNT':int(eligible_cpt.sum()),
        'SLATE_BREAKER_COUNT':int(breaker.sum()),
        'ROSTER_UNLOCK_COUNT':int(unlock.sum()),
        'FALLBACK_UNLOCK_COUNT':int(fallback.sum()),
        'COVERAGE_ONLY_COUNT':int(coverage.sum()),
        'ELIGIBLE_PLAYERS':[players[i]['name'] for i in np.where(eligible_cpt)[0]],
        'SLATE_BREAKERS':[players[i]['name'] for i in np.where(breaker)[0]],
        'ROSTER_UNLOCKERS':[players[i]['name'] for i in np.where(unlock)[0]],
        'COVERAGE_ONLY_PLAYERS':[players[i]['name'] for i in np.where(coverage)[0]],
    }

PREMIUM_SIGNATURE_DOOR_PATCH_ID='MLB_SD_PREMIUM_SIGNATURE_DOOR_TIEBREAK_v1'
PREMIUM_SIGNATURE_NEAR_TIE_WIDTH=0.006

def _premium_signature_quality(globals_,meta):
    g=np.asarray(globals_,np.int32); n=len(g)
    sig=np.asarray(meta.get('primary_same_team_premium_hitter',np.full(len(meta['idx']),-1)),np.int32)[g]
    safe=np.maximum(sig,0)
    psal=np.asarray(meta.get('player_salary',np.zeros(1)),float)[safe]
    pord=np.asarray(meta.get('batting_order',np.full(1,99)),float)[safe]
    pown=np.asarray(meta.get('own',np.zeros(1)),float)[safe]
    valid=sig>=0
    q=.50*pct_rank(psal)+.30*pct_rank(-pord)+.20*pct_rank(pown) if n else np.zeros(0,float)
    q=np.where(valid,q,-1.0)
    return sig,q

def _premium_signature_near_tie_order(globals_,score,meta,width=PREMIUM_SIGNATURE_NEAR_TIE_WIDTH):
    g=np.asarray(globals_,np.int32); score=np.asarray(score,float)
    if len(g)!=len(score): raise RuntimeError('PREMIUM_SIGNATURE_ORDER_LENGTH_MISMATCH')
    _,q=_premium_signature_quality(g,meta)
    w=max(float(width),1e-9); bucket=np.floor((score+w*.5)/w)
    # Clear score gaps retain authority. Premium signature only resolves rows
    # inside the same narrow score bucket.
    return np.lexsort((g,-score,-q,-bucket)).astype(np.int32,copy=False)

def _premium_signature_elite8_repair(cands,chosen_local,score,meta):
    cands=np.asarray(cands,np.int32); chosen=list(map(int,chosen_local)); score=np.asarray(score,float)
    if len(chosen)<2: return chosen
    sig,_=_premium_signature_quality(cands,meta)
    route=np.asarray(meta['route'],object)[cands]; branch=np.asarray(meta['branch'],object)[cands]
    selected=set(chosen)
    for fam in sorted(set(zip(route[chosen].tolist(),branch[chosen].tolist())),key=str):
        sel=[j for j in chosen if (route[j],branch[j])==fam]
        if len(sel)<2: continue
        seen=set(); dup=[]
        for j in sorted(sel,key=lambda j:(-score[j],j)):
            sj=int(sig[j])
            if sj in seen: dup.append(j)
            else: seen.add(sj)
        if not dup: continue
        pool=[j for j in range(len(cands)) if (route[j],branch[j])==fam and j not in selected and int(sig[j]) not in seen]
        if not pool: continue
        alt_order=_premium_signature_near_tie_order(cands[pool],score[pool],meta)
        pool=[pool[int(k)] for k in alt_order]
        for old,new in zip(sorted(dup,key=lambda j:(score[j],-j)),pool):
            if int(sig[new]) in seen: continue
            pos=chosen.index(old); chosen[pos]=int(new); selected.remove(old); selected.add(int(new)); seen.add(int(sig[new]))
    return chosen

def _premium_signature_final_board_order(selected,rank_components,meta):
    selected=np.asarray(selected,np.int32); n=len(selected)
    if n<=1: return np.arange(n,dtype=np.int32)
    family=np.asarray(rank_components.get('family_score',rank_components['score']),float)
    indiv=np.asarray(rank_components.get('individual_score',rank_components['score']),float)
    _,q=_premium_signature_quality(selected,meta)
    w=PREMIUM_SIGNATURE_NEAR_TIE_WIDTH
    fb=np.floor((family+w*.5)/w); ib=np.floor((indiv+w*.5)/w)
    return np.lexsort((selected,-indiv,-family,-q,-ib,-fb)).astype(np.int32,copy=False)

def active_pool(raw):
    lineup=raw.LINEUP.astype(str).str.strip(); hitters=lineup.str.fullmatch(r'[1-9]'); pitcher=lineup.str.upper().eq('SP')
    inferred_opp=set(raw.loc[hitters,'Opp Pitcher'].dropna().astype(str).str.strip())
    inferred_starters=pitcher & raw.PLAYER.astype(str).str.strip().isin(inferred_opp)
    if 'APEX_CONFIRMED_STARTER' in raw.columns: starters=pitcher & raw['APEX_CONFIRMED_STARTER'].fillna(False).astype(bool)
    else: starters=inferred_starters
    prior_col='RW_RST_PRIOR' if 'RW_RST_PRIOR' in raw.columns else 'RST%'; prior=raw[prior_col].map(num)
    games=raw.get('G',pd.Series(0,index=raw.index)).map(num).clip(lower=1); innings=raw.get('IP',pd.Series(0,index=raw.index)).map(num); ipg=innings/games
    inferred_bulk=pitcher & (~starters) & (prior>0) & (innings>=20) & (games>=5) & (ipg>=3.0)
    if 'APEX_BULK_ROLE_EVIDENCE' in raw.columns: bulk_role=pitcher & raw['APEX_BULK_ROLE_EVIDENCE'].fillna(False).astype(bool)
    else: bulk_role=inferred_bulk
    inferred_relief=pitcher & (~starters) & (prior>0) & ((raw.SAL.map(num)<=5000) | bulk_role)
    if 'APEX_RP_ELIGIBLE' in raw.columns: relief=pitcher & (~starters) & raw['APEX_RP_ELIGIBLE'].fillna(False).astype(bool)
    else: relief=inferred_relief
    keep=hitters|starters|relief; p=raw.loc[keep].copy()
    p['_APEX_CONFIRMED_STARTER']=starters.loc[p.index].astype(bool).to_numpy(); p['_APEX_BULK_ROLE']=bulk_role.loc[p.index].astype(bool).to_numpy(); p['_APEX_IPG']=ipg.loc[p.index].astype(float).to_numpy(); p=p.reset_index(drop=True)
    if len(p)<8: raise RuntimeError('ACTIVE_POOL_TOO_SMALL')
    if p.TEAM.nunique()!=2: raise RuntimeError('SHOWDOWN_TWO_TEAM_GATE_FAIL')
    if p.PLAYER.duplicated().any(): raise RuntimeError('DUPLICATE_ACTIVE_PLAYER')
    return p

def build_players(pool):
    global _LAST_STRATEGY_RECEIPT, _LAST_ATTACKABLE_PA_RECEIPT
    out=[]
    strategy_features=global_strategy.build_strategy_features(pool, sport="MLB", mode="SHOWDOWN")
    _LAST_STRATEGY_RECEIPT=dict(strategy_features.receipt)
    attackable_profiles=attackable_pa_mod.build_attackable_pa_profiles(pool.to_dict("records"), mode="SHOWDOWN")
    _LAST_ATTACKABLE_PA_RECEIPT=attackable_pa_mod.receipt(pool.to_dict("records"), attackable_profiles, mode="SHOWDOWN")
    for i,r in pool.iterrows():
        pitcher=str(r.LINEUP).upper()=='SP'
        confirmed_starter=bool(r.get('_APEX_CONFIRMED_STARTER',False))
        # A confirmed starter remains SP even when the market has not posted
        # K/ER props. Props calibrate the distribution; they do not define role.
        sp=pitcher and (confirmed_starter or (num(r.get('O/U K'),0)>0 and num(r.get('O/U ER'),0)>0))
        rp=pitcher and not sp
        own=max(.01,num(r['RST%'],.01)); own_fraction=own/100 if own>1 else own
        games=max(1.0,num(r.get('G'),1.0))
        bulk_role=bool(r.get('_APEX_BULK_ROLE',False)) if rp else False
        ipg=max(0.0,num(r.get('IP'),0.0)/games) if pitcher else 0.0
        bulk_ipg=max(0.0,num(r.get('_APEX_IPG'),0.0)) if bulk_role else 0.0
        role_est=estimate_relief_role(r, games=games, ipg=ipg, bulk_role=bulk_role, bulk_ipg=bulk_ipg) if rp else None
        role_prob=float(role_est.appearance_probability) if role_est is not None else 1.0
        role_evidence_grade=str(role_est.evidence_grade) if role_est is not None else 'STARTER_OR_HITTER'
        order_i=10 if pitcher else int(str(r.LINEUP))
        team_runs=max(.1,num(r['T Runs'],4))
        park_factor=max(.70,min(1.35,num(r.get('Park Factor',r.get('PF',1.0)),1.0)/(100.0 if num(r.get('Park Factor',r.get('PF',1.0)),1.0)>3 else 1.0)))
        weather_run_modifier=max(.70,min(1.30,num(r.get('Weather Run Modifier',r.get('WeatherFactor',1.0)),1.0)/(100.0 if num(r.get('Weather Run Modifier',r.get('WeatherFactor',1.0)),1.0)>3 else 1.0)))
        iso_v=float(np.clip(num(r.get('ISO'),.14),.01,.6))
        barrel=float(np.clip(num(r.get('Barrel %'),6.0)/100.0,0.0,.28))
        hard=float(np.clip(num(r.get('Hard%'),34.0)/100.0,.15,.65))
        hr_pct=num(r.get('HR%'),0.0); hr_pct=hr_pct/100.0 if hr_pct>1 else hr_pct
        pa_hint=float(np.clip(4.15+(5-order_i)*.055,3.2,5.3)) if not pitcher else 1.0
        stat_game_hr=float(np.clip(.025+.58*iso_v+.85*barrel+.08*(hard-.34),.01,.42)*(team_runs/4.5)**.42) if not pitcher else 0.0
        game_hr=float(np.clip(.50*hr_pct+.50*stat_game_hr,.005,.45)) if not pitcher else 0.0
        hr_pa=float(np.clip(1.0-(1.0-game_hr)**(1.0/max(pa_hint,3.2)),.001,.13)) if not pitcher else .001
        out.append(dict(idx=i,name=str(r.PLAYER).strip(),team=str(r.TEAM).strip(),opp=str(r.OPP).strip(),
          salary=int(num(r.SAL)),own=own,is_sp=sp,is_rp=rp,is_bulk=bulk_role,ipg=ipg,bulk_ipg=bulk_ipg,rp_qualified=(not rp),rp_qual_reasons=(),order=order_i,games=games,role_prob=role_prob,role_evidence_grade=role_evidence_grade,
          team_runs=team_runs,park_factor=park_factor,weather_run_modifier=weather_run_modifier,distribution_type=('POISSON_EVENT' if pitcher else 'BINOMIAL_EVENT_LONG_TAIL'),winp=np.clip(num(r['Win %'],50)/100,.01,.99),game_total=max(1,num(r['O/U'],8)),
          hrp=hr_pa,hr_game_prob=game_hr,avg=np.clip(num(r.AVG,.24),.05,.7),obp=np.clip(num(r.OBP,.31),.06,.8),
          iso=iso_v,bbp=np.clip(num(r['BB%'],8)/100,0,.35),kp=np.clip(num(r['K%'],22)/100,.02,.55),
          speed=max(0,num(r.Speed,20)),sb=max(0,num(r.SB,0)),ou_er=max(.5,num(r['O/U ER'],2.8)),ou_k=max(.5,num(r['O/U K'],4.5)),
          era=np.clip(num(r.get('ERA'),4.2),1.5,8),k9=np.clip(num(r.get('K/9'),8.5),3,14),bb9=np.clip(num(r.get('BB/9'),3.2),.5,7),hr9=np.clip(num(r.get('HR/9'),1.2),.2,3),
          strategy_opportunity=float(strategy_features.opportunity_score[i]),strategy_credibility=float(strategy_features.role_credibility[i]),strategy_salary_unlock=bool(strategy_features.salary_unlock[i]),strategy_leverage=float(strategy_features.strategic_leverage[i]),
          conditional_core_support=(0.35*num(r.get('O/U R'),0.0)+0.25*num(r.get('O/U TB'),0.0)+0.20*num(r.get('L10 FPTS'),0.0)+0.20*num(r.get('FPTS'),0.0)),
          mutation_incoming_support=(0.40*num(r.get('O/U R'),0.0)+0.25*num(r.get('O/U TB'),0.0)+0.035*num(r.get('L10 FPTS'),0.0)),
          pitch_around_risk=float(attackable_profiles[i].pitch_around_risk),challenge_index=float(attackable_profiles[i].challenge_index),attackable_pa_multiplier=float(attackable_profiles[i].attackable_pa_multiplier),walk_multiplier=float(attackable_profiles[i].walk_multiplier),chalk_failure_edge=float(attackable_profiles[i].chalk_failure_edge)))
    return out


def _showdown_team_total_paths(players,trials,rng,env):
    """Showdown-only market-mean-preserving team-total paths.

    Production repair: remove the previously retained Gamma mixing layer and
    reduce team-specific lognormal dispersion to sigma=0.08 while preserving
    the shared game state.  This is intentionally local to MLB Showdown so no
    MLB Classic calibration path is modified.
    """
    teams=sorted({p['team'] for p in players})
    game_lat=rng.standard_normal(trials)
    out={}; receipt={}
    for t in teams:
        ps=[p for p in players if p['team']==t]
        market=float(np.median([p.get('team_runs',4.0) for p in ps]))
        target=max(.25,market*env['stadium_park_factor']*env['weather_run_modifier']*env['projected_pace_modifier'])
        team_lat=rng.standard_normal(trials)
        mult=np.exp(.10*game_lat+.08*team_lat-.5*(.10**2+.08**2))
        lam=np.clip(target*mult,.02,20.0)
        runs=rng.poisson(lam).astype(np.float32)
        out[t]=runs
        mean=float(runs.mean())
        receipt[t]={
            'MARKET_IMPLIED_TT':market,'ENVIRONMENT_ADJUSTED_TT':target,
            'SIM_TT_MEAN':mean,'SIM_TT_DRIFT':mean-target,
            'SIM_TT_DRIFT_PCT':(mean-target)/target if target else 0.0,
            'GAMMA_MIXTURE_USED':False,'GAME_LOGNORMAL_SIGMA':0.10,
            'TEAM_LOGNORMAL_SIGMA':0.08,
        }
    return out,receipt

def simulate_players(players,trials,seed):
    global _LAST_MC_ENV_RECEIPT, _LAST_TEAM_RUN_PATHS
    rng=np.random.default_rng(seed); n=len(players); s=np.zeros((trials,n),np.float32)
    env=dict(getattr(simulate_players,'_environment',{"projected_pace_modifier":1.0,"weather_run_modifier":1.0,"stadium_park_factor":1.0}))
    C,corr_map=correlation_matrix(players)
    L=np.linalg.cholesky(C+np.eye(n)*1e-8)
    corr_lat=(rng.standard_normal((trials,n))@L.T).astype(np.float32)
    teams=sorted({p['team'] for p in players})
    team_runs_path,tt_receipt=_showdown_team_total_paths(players,trials,rng,env)
    _LAST_TEAM_RUN_PATHS=team_runs_path
    _LAST_MC_ENV_RECEIPT={
        "PATCH_ID":TT_MC_PATCH_ID,
        "GAME_ENVIRONMENT":env,
        "TEAM_TOTALS":tt_receipt,
        "CORRELATION_MAP":corr_map,
        "CORRELATION_MATRIX_DIM":n,
        "DISTRIBUTION_POLICY":"EVENT_NATIVE_POISSON_BINOMIAL_NO_GAMMA_TEAM_SIGMA_008",
        "BATTING_ORDER_DEPENDENCE":"SEQUENTIAL_PREVIOUS_ON_BASE_PRESSURE",
    }
    # Pitching paths: explicit opposing-TT path controls ER/hit environment.
    for p in players:
        if not (p['is_sp'] or p['is_rp']): continue
        i=p['idx']; ol=corr_lat[:,i]
        opp_path=team_runs_path[p['opp']]
        opp_tt=max(.25,float(np.mean(opp_path)))
        opp_ratio=np.clip((opp_path+.35)/(opp_tt+.35),.25,2.5)
        if p['is_sp']:
            km=p['ou_k']*np.exp(-.10*(opp_ratio-1)-.04*ol)
            em=p['ou_er']*opp_ratio*np.exp(.06*ol)
            # Production repair: player-specific seasonal IP/G replaces the
            # hard-coded 5.65 inning baseline.  DK MLB has no quality-start
            # scoring bonus; do not award one.
            ip_base=float(np.clip(p.get('ipg',5.65),2.0,8.0))
            ip=np.clip(rng.normal(ip_base+.35*(p['winp']-.5)-.16*(opp_ratio-1),.82,trials),2,8.5)
            k=rng.poisson(np.clip(km,.2,12)).astype(np.float32); er=rng.poisson(np.clip(em,.15,10)).astype(np.float32)
            h=rng.poisson(np.clip(4.7+.45*em,1,13)).astype(np.float32); bb=rng.poisson(np.clip(1.7+.12*em,.2,7)).astype(np.float32)
            own_path=team_runs_path[p['team']]
            win_logit=np.log(p['winp']/(1.0-p['winp']))+.16*(own_path-opp_path)
            wp=1.0/(1.0+np.exp(-win_logit))
            w=(rng.random(trials)<wp).astype(np.float32)
            s[:,i]=(2.25*ip+2*k-2*er-.6*h-.6*bb+4*w).astype(np.float32)
        else:
            appeared=rng.random(trials)<p['role_prob']
            outs=np.where(appeared,np.clip(rng.poisson(np.clip(3.0/np.sqrt(opp_ratio),.8,5.5)),1,9),0)
            ip=outs/3.0
            k=rng.poisson(p['k9']*ip/9.0).astype(np.float32)
            er=rng.poisson(p['era']*ip/9.0*opp_ratio).astype(np.float32)
            h=rng.poisson(np.clip(8.2+p['hr9'],5,13)*ip/9.0*opp_ratio).astype(np.float32)
            bb=rng.poisson(p['bb9']*ip/9.0).astype(np.float32)
            w=((rng.random(trials)<(p['winp']*.16))&appeared).astype(np.float32)
            s[:,i]=np.where(appeared,2.25*ip+2*k-2*er-.6*h-.6*bb+4*w,0).astype(np.float32)

    # Hitters are simulated in batting-order sequence within each team.
    for t in teams:
        hitters=sorted([p for p in players if p['team']==t and not p['is_sp'] and not p['is_rp']], key=lambda q:q['order'])
        prev_ob=np.zeros(trials,np.float32)
        market_tt=max(.25,float(np.median([p['team_runs'] for p in hitters])) if hitters else 4.0)
        run_ratio=np.clip((team_runs_path[t]+.35)/(market_tt+.35),.30,2.6)
        for p in hitters:
            i=p['idx']; z=corr_lat[:,i]
            seq=np.clip(prev_ob*.12,0,.45)
            corr_mult=np.exp(.075*z-.5*.075**2)
            pa_mu=np.clip(4.15+(5-p['order'])*.055+.18*(run_ratio-1)+seq,3.1,5.6)
            pa=np.clip(np.rint(rng.normal(pa_mu,.42,trials)),3,7).astype(np.int16)
            attack=float(p.get('attackable_pa_multiplier',1.0)); walk_mult=float(p.get('walk_multiplier',1.0))
            park=float(p.get('park_factor',env['stadium_park_factor']))
            weather=float(p.get('weather_run_modifier',env['weather_run_modifier']))
            power_env=np.clip((park*weather)**.55,.75,1.35)
            contact=np.clip(p['avg']*np.power(run_ratio,.16)*corr_mult*attack,.04,.74)
            hp=np.clip(p['hrp']*np.power(run_ratio,.34)*power_env*corr_mult*attack,.001,.52)
            bp=np.clip(p['bbp']*np.power(run_ratio,.10)*walk_mult,.0,.44)
            hr=rng.binomial(pa,hp).astype(np.float32); rem=np.maximum(pa-hr.astype(np.int16),0)
            nh=rng.binomial(rem,np.clip((contact-hp)/(1-hp+1e-6),0,.78)).astype(np.float32)
            xbf=np.clip(p['iso']/(p['avg']+.05),.03,.7); d=rng.binomial(nh.astype(np.int16),np.clip(.20+.28*xbf,.1,.5)).astype(np.float32)
            tr=rng.binomial(np.maximum((nh-d).astype(np.int16),0),np.clip(.015+.003*p['speed'],.01,.12)).astype(np.float32); sing=np.maximum(nh-d-tr,0)
            open_pa=np.maximum(pa-hr.astype(np.int16)-nh.astype(np.int16),0)
            cond_bp=np.clip(bp/(1.0-contact+1e-6),0,.72)
            walk=rng.binomial(open_pa,cond_bp).astype(np.float32); ob=sing+d+tr+hr+walk
            base_pressure=np.clip(prev_ob*.10,0,.55)
            rr=np.clip((team_runs_path[t]/9.0)*(1.25-.055*(p['order']-1))+.10*ob,.01,3.8)
            rb=np.clip((team_runs_path[t]/9.0)*(.82+.045*(p['order']-1))+.22*(d+tr+hr)+.08*sing+base_pressure,.01,4.4)
            runs=rng.poisson(rr).astype(np.float32); rbi=rng.poisson(rb).astype(np.float32)
            speed_tail=(p['speed']/28)**2*(.10+.020*p['sb']); steals=rng.poisson(np.clip(speed_tail*np.power(run_ratio,.10),0,.85)).astype(np.float32)
            eruption=(rng.random(trials)<np.clip((p['speed']/30)**3*(p['sb']/30)*.10,0,.06)).astype(np.float32)
            s[:,i]=(3*sing+5*d+8*tr+10*hr+2*walk+2*runs+2*rbi+5*steals+5*eruption).astype(np.float32)
            prev_ob=(.55*prev_ob+ob).astype(np.float32)
    return s

def _stream_chunk_seed(seed,chunk_index):
    return int((int(seed)+104729*(int(chunk_index)+1))%(2**32-1))

def simulate_players_streamed(players,trials,seed,tag):
    """Chunk/checkpoint Phase-1 player worlds without changing sport-model equations.

    Each chunk is generated by the production simulate_players() implementation.
    The returned object is a float32 memmap so downstream calibration, proxy,
    handoff and selector code keeps the same matrix interface without holding
    the entire player-world tape in RAM. Completed chunks are checkpointed and
    can be resumed after an interrupted execution.
    """
    global _LAST_STREAMING_RECEIPTS, _LAST_MC_ENV_RECEIPT, _LAST_TEAM_RUN_PATHS
    trials=int(trials); n=len(players); chunk=max(1,min(int(MC_TRIAL_CHUNK),trials))
    safe_tag=''.join(ch if ch.isalnum() or ch in {'_','-'} else '_' for ch in str(tag))
    matrix_path=OUT/f'DK_MLB_SD_{EXECUTION_ID}_{safe_tag}_PLAYER_MATRIX.f32.mmap'
    progress_path=OUT/f'DK_MLB_SD_{EXECUTION_ID}_{safe_tag}_STREAM_PROGRESS.json'
    expected_bytes=trials*n*np.dtype(np.float32).itemsize
    completed=0
    prior_env_receipt=None
    if MC_CHECKPOINT_ENABLED and matrix_path.exists() and progress_path.exists():
        try:
            prior=json.loads(progress_path.read_text(encoding='utf-8'))
            if (int(prior.get('TRIALS',-1))==trials and int(prior.get('PLAYERS',-1))==n
                and int(prior.get('SEED',-1))==int(seed) and int(prior.get('CHUNK',-1))==chunk
                and matrix_path.stat().st_size==expected_bytes):
                completed=max(0,min(trials,int(prior.get('COMPLETED_TRIALS',0))))
                prior_env_receipt=prior.get('MC_ENV_RECEIPT')
                if isinstance(prior_env_receipt,dict) and prior_env_receipt.get('TEAM_TOTALS'):
                    _LAST_MC_ENV_RECEIPT=dict(prior_env_receipt)
        except Exception:
            completed=0
            prior_env_receipt=None
    mode='r+' if matrix_path.exists() and matrix_path.stat().st_size==expected_bytes else 'w+'
    tape=np.memmap(matrix_path,dtype=np.float32,mode=mode,shape=(trials,n))
    if mode=='w+':
        completed=0
    chunk_receipts=[]
    started=time.time()
    for st in range(completed,trials,chunk):
        ed=min(trials,st+chunk); ci=st//chunk; cseed=_stream_chunk_seed(seed,ci)
        block=simulate_players(players,ed-st,cseed)
        tape[st:ed,:]=block
        tape.flush()
        chunk_receipts.append({
            'START':int(st),'END':int(ed),'TRIALS':int(ed-st),'SEED':int(cseed),
            'MC_ENV_RECEIPT':dict(_LAST_MC_ENV_RECEIPT) if isinstance(_LAST_MC_ENV_RECEIPT,dict) else _LAST_MC_ENV_RECEIPT,
        })
        if MC_CHECKPOINT_ENABLED:
            progress_path.write_text(json.dumps({
                'PATCH_ID':STREAMING_PATCH_ID,'TAG':safe_tag,'TRIALS':trials,'PLAYERS':n,
                'SEED':int(seed),'CHUNK':chunk,'COMPLETED_TRIALS':int(ed),
                'MATRIX_PATH':str(matrix_path),'STATUS':'IN_PROGRESS' if ed<trials else 'COMPLETE',
                'MC_ENV_RECEIPT':dict(_LAST_MC_ENV_RECEIPT) if isinstance(_LAST_MC_ENV_RECEIPT,dict) else _LAST_MC_ENV_RECEIPT,
            },indent=2),encoding='utf-8')
    if completed>=trials and not chunk_receipts and not (isinstance(_LAST_MC_ENV_RECEIPT,dict) and _LAST_MC_ENV_RECEIPT.get('TEAM_TOTALS')):
        raise RuntimeError('RUN_INVALID:MLB_SD_STREAM_RESUME_TELEMETRY_MISSING')

    # Aggregate only environment/team-total telemetry. Simulation equations and
    # downstream lineup metrics consume the complete memmap tape unchanged.
    if chunk_receipts:
        final_env=dict(chunk_receipts[-1]['MC_ENV_RECEIPT'] or {})
        tt_keys=set()
        for r in chunk_receipts:
            tt_keys.update((r.get('MC_ENV_RECEIPT') or {}).get('TEAM_TOTALS',{}).keys())
        agg_tt={}
        for team in sorted(tt_keys):
            parts=[]
            for r in chunk_receipts:
                rr=(r.get('MC_ENV_RECEIPT') or {}).get('TEAM_TOTALS',{}).get(team)
                if rr: parts.append((rr,int(r['TRIALS'])))
            if parts:
                total=sum(w for _,w in parts)
                base=dict(parts[-1][0])
                for fld in ['SIM_TT_MEAN','SIM_TT_DRIFT','SIM_TT_DRIFT_PCT']:
                    base[fld]=float(sum(float(x.get(fld,0.0))*w for x,w in parts)/max(total,1))
                agg_tt[team]=base
        final_env['TEAM_TOTALS']=agg_tt
        final_env['STREAMING_PATCH_ID']=STREAMING_PATCH_ID
        final_env['STREAMING_CHUNKS']=len(chunk_receipts)
        _LAST_MC_ENV_RECEIPT=final_env
    _LAST_TEAM_RUN_PATHS={}
    receipt={
        'PATCH_ID':STREAMING_PATCH_ID,'TAG':safe_tag,'TRIALS':trials,'PLAYERS':n,'CHUNK':chunk,
        'CHUNKS_TOTAL':int(math.ceil(trials/chunk)),'RESUMED_FROM_TRIAL':int(completed),
        'CHECKPOINT_ENABLED':bool(MC_CHECKPOINT_ENABLED),'MATRIX_PATH':str(matrix_path),
        'PROGRESS_PATH':str(progress_path),'ELAPSED_SECONDS':float(time.time()-started),
        'STATUS':'COMPLETE',
    }
    _LAST_STREAMING_RECEIPTS[safe_tag]=receipt
    return tape

def qualify_relief_paths(players,p1):
    """Restore the user-mandated MLB SD RP contract before lineup birth.

    RPs are conditional, not banned. A nonzero-role sub-$5K RP must carry at
    least one independently supported ceiling/usage path. This is player-level
    Phase-1 calibration and never uses aggregate FPTS projections.
    """
    starters={p['team']:p for p in players if p['is_sp']}
    qualified=[]
    for p in players:
        if not p['is_rp']:
            p['rp_qualified']=True; p['rp_qual_reasons']=(); continue
        x=np.asarray(p1[:,p['idx']],float)
        nz=x[np.abs(x)>1e-9]
        p95=float(np.quantile(x,.95))
        cond_p95=float(np.quantile(nz,.95)) if len(nz) else 0.0
        mult_threshold=2.5*(p['salary']/1000.0)
        one_ip=bool(p.get('ipg',0.0)>=1.0)
        lam=max(0.0,p['k9']*max(.75,p.get('ipg',0.0))/9.0)
        p2k=float(1.0-math.exp(-lam)*(1.0+lam))
        k_spike=bool(p2k>=.20 and p['role_prob']>=.25)
        win_hold=bool(p['games']>=30 and p['role_prob']>=.28 and p['winp']>=.52)
        st=starters.get(p['team'])
        early_hook=bool(st is not None and (st['ou_er']>=3.2 or (st['game_total']>=8.5 and st['winp']<.55)))
        tail=bool(p95>=mult_threshold or cond_p95>=mult_threshold)
        reasons=[]
        if tail: reasons.append('P95_2P5X')
        if one_ip: reasons.append('ONE_PLUS_IP')
        if k_spike: reasons.append('K_SPIKE_2PLUS')
        if win_hold: reasons.append('WIN_HOLD_ROLE')
        if early_hook: reasons.append('EARLY_HOOK')
        p['rp_p95']=p95; p['rp_cond_p95']=cond_p95; p['rp_p2k']=p2k
        p['rp_qualified']=bool(reasons); p['rp_qual_reasons']=tuple(reasons)
        if p['rp_qualified']: qualified.append(p['name'])
    return qualified

@njit(cache=False)
def _enumerate_showdown_numba(eligible, captains, sal, rp, dual_rp_ok, team_code):
    ne=len(eligible); nc=len(captains)
    # Exact upper bound: for each captain choose 5 from all other eligible rows.
    max_rows=nc*((ne-1)*(ne-2)*(ne-3)*(ne-4)*(ne-5)//120)
    out=np.empty((max_rows,7),np.int32); k=0
    for ci in range(nc):
        c=captains[ci]; cs=sal[c]*3//2
        for a0 in range(ne-4):
            i0=eligible[a0]
            if i0==c: continue
            for a1 in range(a0+1,ne-3):
                i1=eligible[a1]
                if i1==c: continue
                for a2 in range(a1+1,ne-2):
                    i2=eligible[a2]
                    if i2==c: continue
                    for a3 in range(a2+1,ne-1):
                        i3=eligible[a3]
                        if i3==c: continue
                        for a4 in range(a3+1,ne):
                            i4=eligible[a4]
                            if i4==c: continue
                            rp_n=rp[i0]+rp[i1]+rp[i2]+rp[i3]+rp[i4]
                            if rp_n > 2: continue
                            if rp_n == 2 and dual_rp_ok[i0]+dual_rp_ok[i1]+dual_rp_ok[i2]+dual_rp_ok[i3]+dual_rp_ok[i4] != 2: continue
                            salary=cs+sal[i0]+sal[i1]+sal[i2]+sal[i3]+sal[i4]
                            if salary<40000 or salary>50000: continue
                            t0=team_code[c]
                            same=(team_code[i0]==t0)+(team_code[i1]==t0)+(team_code[i2]==t0)+(team_code[i3]==t0)+(team_code[i4]==t0)
                            if same==5: continue
                            out[k,0]=c; out[k,1]=i0; out[k,2]=i1; out[k,3]=i2; out[k,4]=i3; out[k,5]=i4; out[k,6]=salary; k+=1
    return out[:k].copy()

def enumerate_lineups(players):
    teams=np.array([p['team'] for p in players]); sal=np.array([p['salary'] for p in players],np.int32)
    eligible,rp,dual_rp_ok=_utility_eligibility_arrays(players)
    uniq={t:i for i,t in enumerate(sorted(set(teams.tolist())))}; team_code=np.array([uniq[t] for t in teams],np.int8)
    captains=np.array([i for i in eligible if not players[i]['is_rp'] and bool(players[i].get('cpt_eligible',True))],np.int32)
    if not len(captains): raise RuntimeError('CAPTAIN_ELIGIBILITY_EMPTY')
    return _enumerate_showdown_numba(eligible,captains,sal,rp,dual_rp_ok,team_code)

def lineup_meta(lineups,players):
    """Vectorized six-slot metadata surface for MLB Showdown fast path.

    Semantics are identical to the legacy row loop; all masks operate on the
    complete legal lineup matrix, with no truncation or First-N behavior.
    """
    names=np.array([p['name'] for p in players],object); teams=np.array([p['team'] for p in players],object)
    team_vals=sorted(set(teams.tolist())); team_map={t:i for i,t in enumerate(team_vals)}; tcode=np.array([team_map[t] for t in teams],np.int8)
    sp=np.array([p['is_sp'] for p in players],np.int8); rp=np.array([p['is_rp'] for p in players],np.int8)
    bulk=np.array([p.get('is_bulk',False) for p in players],np.int8); bulk_ipg=np.array([p.get('bulk_ipg',0.0) for p in players],float)
    elite_rp=np.array([int(p['is_rp'] and p.get('rp_qualified',False) and all(tag in p.get('rp_qual_reasons',()) for tag in ('P95_2P5X','ONE_PLUS_IP','K_SPIKE_2PLUS','WIN_HOLD_ROLE')) and p.get('role_prob',0.0)>=.28) for p in players],np.int8)
    own=np.array([p['own'] for p in players],float); speed=np.array([p['speed'] for p in players],float); sb=np.array([p['sb'] for p in players],float)
    sal=np.array([p['salary'] for p in players],np.int32); order=np.array([p['order'] for p in players],np.int16); team_runs=np.array([p['team_runs'] for p in players],float); role_prob=np.array([p['role_prob'] for p in players],float)
    rp_cond_p95=np.array([float(p.get('rp_cond_p95',0.0) or 0.0) for p in players],float); rp_qualified=np.array([bool(p.get('rp_qualified',False)) for p in players],bool)
    strategy_leverage=np.array([p['strategy_leverage'] for p in players],float); strategy_unlock=np.array([p['strategy_salary_unlock'] for p in players],bool)
    conditional_core_support=np.array([p.get('conditional_core_support',0.0) for p in players],float); mutation_incoming_support=np.array([p.get('mutation_incoming_support',0.0) for p in players],float)
    pitch_around=np.array([p.get('pitch_around_risk',0.5) for p in players],float); chalk_failure=np.array([p.get('chalk_failure_edge',0.0) for p in players],float); hrp=np.array([p['hrp'] for p in players],float)
    idx=np.asarray(lineups[:,:6],np.int32); cpt=idx[:,0]; util=idx[:,1:]; n=len(idx)
    sp_i=sp[idx]; rp_i=rp[idx]; hitter_i=(sp_i==0)&(rp_i==0)
    spct=sp_i.sum(1); rpct=rp_i.sum(1); elite_rpct=elite_rp[idx].sum(1); cptsp=sp[cpt].astype(bool)
    tc=tcode[idx]; cteam=tcode[cpt]; same=(tc==cteam[:,None]); opp=~same
    cpt_team_count=same.sum(1).astype(np.int8); other_count=6-cpt_team_count
    hi=np.maximum(cpt_team_count,other_count); lo=np.minimum(cpt_team_count,other_count)
    branch=np.char.add(np.char.add(hi.astype(str),'-'),lo.astype(str)).astype(object)
    route=np.where(spct==2,'DUAL_SP_ANCHOR',np.where(spct==1,'BRIDGE_1SP',np.where(branch=='3-3','BALANCED_33_BAT','BATS_OFFCENTER'))).astype(object)
    util_same=same[:,1:]; util_opp=opp[:,1:]; util_ids=util
    util_sp=sp[util_ids].astype(bool); util_rp=rp[util_ids].astype(bool); util_hit=(~util_sp)&(~util_rp)
    same_team_sp_count=(sp_i.astype(bool)&same).sum(1).astype(np.int8)
    same_team_top2_count=(util_hit&util_same&(order[util_ids]<=2)).sum(1).astype(np.int8)
    same_team_top5_count=(util_hit&util_same&(order[util_ids]<=5)).sum(1).astype(np.int8)
    opponent_top2_count=((~util_sp)&util_opp&(order[util_ids]<=2)).sum(1).astype(np.int8)
    opponent_top5_count=(util_hit&util_opp&(order[util_ids]<=5)).sum(1).astype(np.int8)
    opponent_punt_count=(util_hit&util_opp&((order[util_ids]>=8)|(sal[util_ids]<=4000))).sum(1).astype(np.int8)
    opponent_speed_count=(util_hit&util_opp&(speed[util_ids]>=25)).sum(1).astype(np.int8)
    hitter_power_count=(hitter_i&(hrp[idx]>=.20)).sum(1).astype(np.int8)
    low_speed=(opp&(speed[idx]>=25)&(sb[idx]>=3)&(own[idx]<=5)).any(1)

    release_mask=util_hit&util_same&(own[util_ids]<=2.0)&(sal[util_ids]<=6000)&(order[util_ids]<=6)
    release_player_count=release_mask.sum(1).astype(np.int8); same_team_release=release_player_count>0
    # lexicographic min by own, salary, order, id
    rel_score=own[util_ids]*1e12+sal[util_ids]*1e6+order[util_ids]*1e3+util_ids
    rel_score=np.where(release_mask,rel_score,np.inf); rel_pos=np.argmin(rel_score,axis=1)
    primary_release_player=np.where(same_team_release,util_ids[np.arange(n),rel_pos],-1).astype(np.int16)

    rp_mask=rp[util_ids].astype(bool); rp_any=rp_mask.any(1); rp_pos=np.argmax(rp_mask,axis=1)
    primary_rp_player=np.where(rp_any,util_ids[np.arange(n),rp_pos],-1).astype(np.int16)
    rp_role_probability=np.where(rp_any,role_prob[np.maximum(primary_rp_player,0)],0.0)
    rp_conditional_p95=np.where(rp_any,rp_cond_p95[np.maximum(primary_rp_player,0)],0.0)

    bulk_mask=bulk[util_ids].astype(bool)&util_same; same_team_bulk_count=bulk_mask.sum(1).astype(np.int8); bulk_any=same_team_bulk_count>0
    # max by bulk_ipg, role_prob, id
    bulk_score=bulk_ipg[util_ids]*1e9+role_prob[util_ids]*1e5+util_ids
    bulk_score=np.where(bulk_mask,bulk_score,-np.inf); bulk_pos=np.argmax(bulk_score,axis=1)
    primary_bulk_player=np.where(bulk_any,util_ids[np.arange(n),bulk_pos],-1).astype(np.int16)
    bulk_role_probability=np.where(bulk_any,role_prob[np.maximum(primary_bulk_player,0)],0.0)
    bulk_capacity_ipg=np.where(bulk_any,bulk_ipg[np.maximum(primary_bulk_player,0)],0.0)

    same_top4=util_hit&util_same&(order[util_ids]<=4)
    has1=(same_top4&(order[util_ids]==1)).any(1); has2=(same_top4&(order[util_ids]==2)).any(1); has3=(same_top4&(order[util_ids]==3)).any(1); has4=(same_top4&(order[util_ids]==4)).any(1)
    same_team_top4_consecutive3=(has1&has2&has3)|(has2&has3&has4)

    same_hit=util_hit&util_same; same_hit_any=same_hit.any(1)
    # max by salary, -order, own, -id
    prem_score=sal[util_ids]*1e12-order[util_ids]*1e8+own[util_ids]*1e4-util_ids
    prem_score=np.where(same_hit,prem_score,-np.inf); prem_pos=np.argmax(prem_score,axis=1)
    primary_same_team_premium_hitter=np.where(same_hit_any,util_ids[np.arange(n),prem_pos],-1).astype(np.int16)
    med=np.array([float(np.median(sal[(tcode==team_map[t])&(sp==0)&(rp==0)])) for t in team_vals])
    opp_hit=util_hit&util_opp
    opponent_premium_top2=(opp_hit&(order[util_ids]<=2)&(sal[util_ids]>=med[tcode[util_ids]])).any(1)

    hit_count=hitter_i.sum(1); pitch_sum=(pitch_around[idx]*hitter_i).sum(1); chalk_sum=(chalk_failure[idx]*hitter_i).sum(1)
    lineup_pitch_around_risk=np.divide(pitch_sum,hit_count,out=np.zeros(n,float),where=hit_count>0)
    lineup_chalk_failure_exposure=chalk_sum.astype(float)
    star=np.where((sp==0)&(rp==0)&(chalk_failure>=0.45))[0]
    if len(star):
        selected_star=(idx[:,:,None]==star[None,None,:]).any(1)
        lineup_chalk_failure_fade_edge=(chalk_failure[star][None,:]*(~selected_star)).sum(1)
    else: lineup_chalk_failure_fade_edge=np.zeros(n,float)

    cpt_player_eligible=np.array([bool(p.get('cpt_eligible',True)) for p in players],bool)[cpt]
    cpt_slate_breaker=np.array([bool(p.get('cpt_slate_breaker',False)) for p in players],bool)[cpt]
    cpt_roster_unlock=np.array([bool(p.get('cpt_roster_unlock',False)) for p in players],bool)[cpt]
    cpt_bargain_tail_ratio=np.array([float(p.get('cpt_unlock_tail_ratio') or 0.0) for p in players],float)[cpt]
    same_team_mid_3_8_count=(util_hit&util_same&(order[util_ids]>=3)&(order[util_ids]<=8)).sum(1).astype(np.int8)
    lane_sp_cpt_control_42_mid_top5=cptsp&(spct==1)&(branch=='4-2')&(cpt_team_count==4)&(same_team_mid_3_8_count>=3)&(opponent_top5_count>=2)&cpt_slate_breaker
    # CAR_SHOP_REPAIR_V1: protect minority-side SP captains that also roster the
    # opposing starter.  This is the identity-free dual-SP attack-hedge family
    # observed in both 5-1 and 4-2 tournament-winning neighborhoods.
    lane_sp_cpt_dual_sp_attack_hedge=cptsp&(spct==2)&(((branch=='5-1')&(cpt_team_count==1))|((branch=='4-2')&(cpt_team_count==2)))
    lane=cptsp&(spct==1)&(branch=='5-1'); lane_speed=lane&low_speed
    lane_control=lane&(cpt_team_count==5); lane_control_speed=lane_control&low_speed; lane_damage=lane&(cpt_team_count==1)
    cpt_speed_tail=(~cptsp)&(speed[cpt]>=25)&(sb[cpt]>=3)&(own[cpt]<=5)
    lane_hitter_cpt_speed_low_spend=cpt_speed_tail&(spct==1)&(lineups[:,6]<=47000)
    lane_hitter_cpt_speed_low_spend_42=lane_hitter_cpt_speed_low_spend&(branch=='4-2')
    lane_hitter_cpt_speed_low_spend_42_release=lane_hitter_cpt_speed_low_spend_42&same_team_release
    lane_hitter_cpt_speed_low_spend_42_control=lane_hitter_cpt_speed_low_spend_42_release&(cpt_team_count==4)
    lane_hitter_cpt_speed_low_spend_42_counter=lane_hitter_cpt_speed_low_spend_42_release&(cpt_team_count==2)
    lane_hitter_cpt_speed_low_spend_42_counter_top2=lane_hitter_cpt_speed_low_spend_42_counter&(opponent_top2_count>=2)
    lane_sp_cpt_control_51_speed_top2_core=lane_control_speed&(same_team_top2_count>=2)
    primary_release_order=np.where(primary_release_player>=0,order[np.maximum(primary_release_player,0)],99).astype(np.int16)
    lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release=lane_hitter_cpt_speed_low_spend_42_counter_top2&(primary_release_order<=4)
    opp_runs=np.array([max(team_runs[tcode!=tcode[q]]) for q in cpt])
    cpt_favorite=team_runs[cpt]>opp_runs; cpt_underdog=team_runs[cpt]<opp_runs; cpt_value_order=(order[cpt]>=4)&(order[cpt]<=7)
    lane_hitter_cpt_same_team_sp_control=(~cptsp)&(spct==1)&(same_team_sp_count==1)&(cpt_team_count>=4)&cpt_favorite&cpt_value_order
    lane_hitter_cpt_favorite_51_sp_opp_punt=lane_hitter_cpt_same_team_sp_control&(branch=='5-1')&(opponent_punt_count>=1)&(lineups[:,6]>=47000)
    lane_mixed_sp_rp=(rpct==1)&(spct>=1); lane_sp2_rp1=(rpct==1)&(spct==2)
    rp_own=np.where(primary_rp_player>=0,own[np.maximum(primary_rp_player,0)],100.0); lane_low_owned_rp=lane_mixed_sp_rp&(rp_own<=5.0)
    lane_hitter_cpt_favorite_42_sp_rp=lane_hitter_cpt_same_team_sp_control&(branch=='4-2')&(rpct==1)&(lineups[:,6]>=46000)
    primary_rp_same_team=np.zeros(n,bool)
    _rp_good=np.where(primary_rp_player>=0)[0]
    if len(_rp_good):
        primary_rp_same_team[_rp_good]=tcode[primary_rp_player[_rp_good]]==cteam[_rp_good]
    # Generic bargain-shopping championship branch: underdog value hitter CPT,
    # 5-1 same-side concentration, same-team starter, one qualified same-team RP,
    # and one opposing hitter. Identity-free and prelock only.
    lane_hitter_cpt_underdog_51_sp_single_rp=(~cptsp)&cpt_roster_unlock&(branch=='5-1')&(cpt_team_count==5)&(spct==1)&(same_team_sp_count==1)&(rpct==1)&primary_rp_same_team&cpt_underdog
    lane_hitter_cpt_favorite_51_sp_contact_core=lane_hitter_cpt_favorite_51_sp_opp_punt&(same_team_top5_count>=3)&(hitter_power_count==0)&(lineups[:,6]>=47500)
    rp_reservoir=sorted(set(idx[rp[idx].astype(bool)].tolist()))
    min_rp_role={t:min((role_prob[q] for q in rp_reservoir if teams[q]==t),default=1.0) for t in set(teams)}
    rp_low_role=np.zeros(n,bool)
    good=np.where(primary_rp_player>=0)[0]
    if len(good):
        pp=primary_rp_player[good]; rp_low_role[good]=role_prob[pp]<=np.array([min_rp_role[teams[q]] for q in pp])+1e-12
    lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact=lane_hitter_cpt_favorite_42_sp_rp&rp_low_role&(order[cpt]==6)&(same_team_top5_count==1)&(opponent_top2_count>=1)&(opponent_speed_count>=1)&(hitter_power_count==0)&(lineups[:,6]>=48000)&(lineups[:,6]<=49500)
    cpt_below_team_median=sal[cpt]<=med[tcode[cpt]]; cpt_moderate_leverage=(own[cpt]>=2.0)&(own[cpt]<=25.0)
    lane_hitter_cpt_underdog_42_opp_sp_isolated_damage_premium_core=(~cptsp)&(spct==1)&(branch=='4-2')&(cpt_team_count==2)&(same_team_sp_count==0)&cpt_underdog&(own[cpt]<=2.0)&(sal[cpt]<=5000)&(order[cpt]>=2)&(order[cpt]<=7)&(lineups[:,6]>=48000)&(opponent_top5_count>=2)&(same_team_top2_count>=1)
    lane_hitter_cpt_bulk_51_middle_core_premium_runback=(~cptsp)&(branch=='5-1')&(cpt_team_count==5)&(same_team_bulk_count==1)&(bulk_capacity_ipg>=3.0)&(order[cpt]>=4)&(order[cpt]<=8)&cpt_below_team_median&cpt_moderate_leverage&same_team_top4_consecutive3&opponent_premium_top2&(lineups[:,6]>=47500)
    ownlog=np.log(np.clip(own[idx]/100,1e-7,1)).sum(1)+np.where(cptsp,-1.0,-.55)
    strategy_score=strategy_leverage[idx].sum(1)+.5*strategy_leverage[cpt]; strategy_unlock_count=strategy_unlock[idx].sum(1)
    salary_release=np.clip((47000-lineups[:,6])/7000,0,1)
    slot_w=np.ones_like(idx,dtype=float); slot_w[:,0]=1.5
    role_w=np.where(hitter_i,1.0,np.where(sp_i.astype(bool),.35,.15))
    tt_num=(team_runs[idx]*slot_w*role_w).sum(1); tt_den=(slot_w*role_w).sum(1)
    lineup_market_tt=np.divide(tt_num,tt_den,out=np.zeros(n,float),where=tt_den>0)
    tt_leverage=lineup_market_tt*np.exp(np.clip(-ownlog/12.0,-1.0,2.0))
    return dict(names=names,teams=teams,idx=idx,cpt=cpt,salary=lineups[:,6],branch=branch,route=route,sp_count=spct,rp_count=rpct,elite_rp_count=elite_rpct,cpt_sp=cptsp,cpt_team_count=cpt_team_count,same_team_sp_count=same_team_sp_count,
                lane_sp_cpt_51=lane,lane_sp_cpt_51_speed=lane_speed,lane_sp_cpt_control_51=lane_control,lane_sp_cpt_control_51_speed=lane_control_speed,lane_sp_cpt_dual_sp_attack_hedge=lane_sp_cpt_dual_sp_attack_hedge,
                lane_sp_cpt_control_42_mid_top5=lane_sp_cpt_control_42_mid_top5,same_team_mid_3_8_count=same_team_mid_3_8_count,cpt_player_eligible=cpt_player_eligible,cpt_slate_breaker=cpt_slate_breaker,cpt_roster_unlock=cpt_roster_unlock,cpt_bargain_tail_ratio=cpt_bargain_tail_ratio,
                lane_sp_cpt_damage_15=lane_damage,lane_speed=low_speed,own_log=ownlog,own=own,speed=speed,sb=sb,cpt_speed_tail=cpt_speed_tail,same_team_release=same_team_release,release_player_count=release_player_count,primary_release_player=primary_release_player,opponent_top2_count=opponent_top2_count,salary_release=salary_release,
                lane_hitter_cpt_speed_low_spend=lane_hitter_cpt_speed_low_spend,lane_hitter_cpt_speed_low_spend_42=lane_hitter_cpt_speed_low_spend_42,lane_hitter_cpt_speed_low_spend_42_release=lane_hitter_cpt_speed_low_spend_42_release,lane_hitter_cpt_speed_low_spend_42_control=lane_hitter_cpt_speed_low_spend_42_control,lane_hitter_cpt_speed_low_spend_42_counter=lane_hitter_cpt_speed_low_spend_42_counter,lane_hitter_cpt_speed_low_spend_42_counter_top2=lane_hitter_cpt_speed_low_spend_42_counter_top2,
                same_team_top2_count=same_team_top2_count,same_team_top5_count=same_team_top5_count,opponent_top5_count=opponent_top5_count,opponent_punt_count=opponent_punt_count,opponent_speed_count=opponent_speed_count,hitter_power_count=hitter_power_count,primary_release_order=primary_release_order,primary_rp_player=primary_rp_player,rp_role_probability=rp_role_probability,rp_conditional_p95=rp_conditional_p95,rp_low_role=rp_low_role,lane_sp_cpt_control_51_speed_top2_core=lane_sp_cpt_control_51_speed_top2_core,lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release=lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release,lane_hitter_cpt_same_team_sp_control=lane_hitter_cpt_same_team_sp_control,cpt_underdog=cpt_underdog,lane_hitter_cpt_underdog_42_opp_sp_isolated_damage_premium_core=lane_hitter_cpt_underdog_42_opp_sp_isolated_damage_premium_core,lane_hitter_cpt_favorite_51_sp_opp_punt=lane_hitter_cpt_favorite_51_sp_opp_punt,lane_mixed_sp_rp=lane_mixed_sp_rp,lane_sp2_rp1=lane_sp2_rp1,lane_low_owned_rp=lane_low_owned_rp,lane_hitter_cpt_favorite_42_sp_rp=lane_hitter_cpt_favorite_42_sp_rp,lane_hitter_cpt_underdog_51_sp_single_rp=lane_hitter_cpt_underdog_51_sp_single_rp,lane_hitter_cpt_favorite_51_sp_contact_core=lane_hitter_cpt_favorite_51_sp_contact_core,lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact=lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact,
                same_team_bulk_count=same_team_bulk_count,primary_bulk_player=primary_bulk_player,bulk_role_probability=bulk_role_probability,bulk_capacity_ipg=bulk_capacity_ipg,same_team_top4_consecutive3=same_team_top4_consecutive3,opponent_premium_top2=opponent_premium_top2,primary_same_team_premium_hitter=primary_same_team_premium_hitter,cpt_below_team_median=cpt_below_team_median,cpt_moderate_leverage=cpt_moderate_leverage,lane_hitter_cpt_bulk_51_middle_core_premium_runback=lane_hitter_cpt_bulk_51_middle_core_premium_runback,
                strategy_score=strategy_score,strategy_unlock_count=strategy_unlock_count,global_strategy_patch_id=GLOBAL_SPORTS_STRATEGIST_PATCH_ID,sp_player_ids=np.where(sp.astype(bool))[0].astype(np.int32),rp_player_ids=np.where(rp.astype(bool))[0].astype(np.int32),rp_qualified_player_ids=np.where(rp_qualified)[0].astype(np.int32),elite_rp_player_ids=np.where(elite_rp.astype(bool))[0].astype(np.int32),team_runs=team_runs,player_salary=sal,player_rp_cond_p95=rp_cond_p95,batting_order=order,player_conditional_core_support=conditional_core_support,player_mutation_incoming_support=mutation_incoming_support,lineup_pitch_around_risk=lineup_pitch_around_risk,lineup_chalk_failure_exposure=lineup_chalk_failure_exposure,lineup_chalk_failure_fade_edge=lineup_chalk_failure_fade_edge,attackable_pa_patch_id=attackable_pa_mod.PATCH_ID,lineup_market_tt=lineup_market_tt,tt_leverage=tt_leverage)

def proxy_metrics(p1,lineups,chunk=100000):
    """Sparse six-slot Phase-1 proxy; avoids dense lineup x player matrices."""
    mu=p1.mean(0).astype(float); cov=np.cov(p1,rowvar=False).astype(float); idx=np.asarray(lineups[:,:6],np.int32); n=len(idx)
    weights=np.ones(6,float); weights[0]=1.5
    mean=(mu[idx]*weights[None,:]).sum(1); var=np.empty(n,float)
    ww=weights[:,None]*weights[None,:]
    for st in range(0,n,chunk):
        ed=min(n,st+chunk); ii=idx[st:ed]
        cc=cov[ii[:,:,None],ii[:,None,:]]
        var[st:ed]=(cc*ww[None,:,:]).sum((1,2))
    sd=np.sqrt(np.maximum(var,1e-6)); p95=mean+1.645*sd; p99=mean+2.326*sd
    return dict(mean=mean,p95=p95,p99=p99,win=pct_rank(mean+2.75*sd),top01=pct_rank(mean+2.30*sd),top10=pct_rank(mean+2.05*sd))

def choose_fake(meta,count,seed):
    """Ownership-calibrated public-field sampler using blind starter RST%."""
    global _LAST_FIELD_RECEIPT
    lw=meta['own_log']-np.abs(meta['salary']-49600)/6500+np.where(meta['branch']=='4-2',.18,0)+np.where(meta['branch']=='5-1',.10,0)
    lw-=lw.max(); w=np.exp(np.clip(lw,-60,0)); w/=w.sum()
    rng=np.random.default_rng(seed); total=min(int(count),len(w))
    sp_ids=np.asarray(meta.get('sp_player_ids',[]),dtype=np.int32)
    sp_owns=np.sort(np.asarray(meta['own'],float)[sp_ids]/100.0)[::-1] if len(sp_ids) else np.array([],float)
    second=float(sp_owns[1]) if len(sp_owns)>=2 else 0.0; first=float(sp_owns[0]) if len(sp_owns)>=1 else 0.0
    dual_target=float(np.clip(0.20+0.55*second,0.20,0.75)) if len(sp_owns)>=2 else 0.0
    spcpt_target=float(np.clip(0.25+0.45*((first+second)/2.0),0.25,0.75)) if len(sp_owns)>=2 else float(np.clip(0.20+0.40*first,0.20,0.65))
    dual=np.asarray(meta['sp_count']==2); spcpt=np.asarray(meta['cpt_sp'],bool)
    both_target=min(dual_target,spcpt_target,max(0.0,dual_target*spcpt_target+0.10*min(dual_target,spcpt_target)))
    quotas=[
        (dual & spcpt, int(round(total*both_target)), 'DUAL_SP_CPT_SP'),
        (dual & ~spcpt, int(round(total*max(0.0,dual_target-both_target))), 'DUAL_SP_HITTER_CPT'),
        (~dual & spcpt, int(round(total*max(0.0,spcpt_target-both_target))), 'NONDUAL_SP_CPT'),
    ]
    chosen=[]; chosen_set=set(); strata={}
    def sample_mask(mask,n,label):
        if n<=0: strata[label]=0; return
        ids=np.where(mask)[0]
        if chosen_set: ids=np.array([i for i in ids if int(i) not in chosen_set],dtype=np.int32)
        if not len(ids): strata[label]=0; return
        n=min(int(n),len(ids)); ww=w[ids]; ww=ww/ww.sum(); pick=rng.choice(ids,n,replace=False,p=ww)
        chosen.extend(map(int,pick)); chosen_set.update(map(int,pick)); strata[label]=int(n)
    for mask,n,label in quotas: sample_mask(mask,n,label)
    rest=total-len(chosen)
    if rest>0:
        neutral=(~dual)&(~spcpt)
        sample_mask(neutral,rest,'NEUTRAL')
        rest=total-len(chosen)
    if rest>0:
        remaining=np.array([i for i in range(len(w)) if i not in chosen_set],dtype=np.int32)
        ww=w[remaining]; ww=ww/ww.sum(); pick=rng.choice(remaining,min(rest,len(remaining)),replace=False,p=ww)
        chosen.extend(map(int,pick)); strata['OVERFLOW']=int(len(pick))
    arr=np.asarray(chosen[:total],np.int32)
    _LAST_FIELD_RECEIPT={
        'FAKE_FIELD_SIZE':int(len(arr)),'STARTER_OWNERSHIP_TOP2':[first,second],
        'TARGET_DUAL_SP_SHARE':dual_target,'TARGET_SP_CPT_SHARE':spcpt_target,
        'ACTUAL_DUAL_SP_SHARE':float(dual[arr].mean()) if len(arr) else 0.0,
        'ACTUAL_SP_CPT_SHARE':float(spcpt[arr].mean()) if len(arr) else 0.0,
        'STRATA_COUNTS':strata,'SOURCE':'BLIND_RST_OWNERSHIP_ONLY'
    }
    return arr

def _lineup_csr_weight_matrix(lineups,ids,nplayers):
    """FAST_PATH sparse roster matrix: 1.5 CPT + five 1.0 UTIL weights."""
    ids=np.asarray(ids,np.int32); lu=np.asarray(lineups[ids,:6],np.int32); m=len(ids)
    rr=np.repeat(np.arange(m,dtype=np.int32),6); cc=lu.reshape(-1); dd=np.ones(m*6,np.float32); dd[::6]=1.5
    return csr_matrix((dd,(rr,cc)),shape=(m,int(nplayers)),dtype=np.float32)

def _direct_six_slot_scores(scores,lineups,ids,ts,te):
    """Vectorized exact six-slot scorer: 1.5 CPT + five 1.0 UTIL slots.

    The player dimension is tiny in Showdown, so direct indexed gathers avoid
    SciPy sparse-matmul dispatch overhead while preserving identical lineup
    arithmetic and fixed-memory trial chunking.
    """
    lu=np.asarray(lineups[np.asarray(ids,np.int32),:6],np.int32)
    block=np.asarray(scores[ts:te],np.float32)
    v=np.asarray(block[:,lu[:,0]].T*1.5,dtype=np.float32)
    for slot in range(1,6):
        v += block[:,lu[:,slot]].T
    return v

def field_thresholds(scores,lineups,field_idx,topk,top10k,trial_chunk=1000):
    T=scores.shape[0]; mx=np.empty(T,np.float32); kth=np.empty(T,np.float32); top10=np.empty(T,np.float32)
    field_idx=np.asarray(field_idx,np.int32); k1=len(field_idx)-topk; k10=len(field_idx)-top10k
    for ts in range(0,T,trial_chunk):
        te=min(T,ts+trial_chunk); fs=_direct_six_slot_scores(scores,lineups,field_idx,ts,te)
        mx[ts:te]=fs.max(0)
        kth[ts:te]=np.partition(fs,k1,axis=0)[k1]
        top10[ts:te]=np.partition(fs,k10,axis=0)[k10]
    return mx,kth,top10

def score_lineups(scores,lineups,mx,kth,top10_threshold,ids,trial_chunk=500):
    """FAST_PATH streaming scorer.

    Field-relative win/Top-0.1 rates are empirical common-world tail metrics.
    P95/P99 remain moment summaries for secondary tie-breaking so the full
    Phase-2 review set does not allocate an O(lineups*trials) tail matrix.
    """
    ids=np.asarray(ids,np.int32); n=len(ids); T=int(scores.shape[0])
    sm=np.zeros(n,np.float64); ss=np.zeros(n,np.float64); wc=np.zeros(n,np.int64); c01=np.zeros(n,np.int64); c10=np.zeros(n,np.int64)
    for ts in range(0,T,trial_chunk):
        te=min(T,ts+trial_chunk); v=_direct_six_slot_scores(scores,lineups,ids,ts,te)
        sm+=v.sum(1,dtype=np.float64); vd=v.astype(np.float64); ss+=(vd*vd).sum(1)
        wc+=(v>=np.asarray(mx[ts:te])[None,:]).sum(1)
        c01+=(v>=np.asarray(kth[ts:te])[None,:]).sum(1)
        c10+=(v>=np.asarray(top10_threshold[ts:te])[None,:]).sum(1)
    mean=sm/max(T,1); var=np.maximum(ss/max(T,1)-mean*mean,0.0); sd=np.sqrt(var)
    p95=mean+1.645*sd; p99=mean+2.326*sd
    return dict(mean=mean,p95=p95,p99=p99,cvar99=p99.copy(),win=wc/max(T,1),top01=c01/max(T,1),top10=c10/max(T,1))

def phase2_birth(pm,meta,market_context=None,sentinel_pm=None):
    comp=.32*pct_rank(pm['top01'])+.19*pct_rank(pm['win'])+.19*pct_rank(pm['p99'])+.11*pct_rank(pm['p95'])+.08*pct_rank(pm['mean'])+.06*pct_rank(-meta['own_log'])+.04*pct_rank(meta['strategy_score'])+.01*pct_rank(meta.get('lineup_chalk_failure_fade_edge',np.zeros(len(meta['idx']))))-meta.get('self_conflict_penalty',0.0)+meta.get('side_commitment_bonus',0.0)
    selected=set(np.where(comp>=np.quantile(comp,.97))[0]); lanes=defaultdict(set); lanes['GLOBAL_CALIBRATED_TAIL'].update(selected)
    def add(mask,score,k,name,all_rows=False):
        ids=np.where(mask)[0]
        if not len(ids): return
        best=ids if all_rows else ids[np.argpartition(-score[ids],min(k,len(ids))-1)[:min(k,len(ids))]]
        selected.update(best.tolist()); lanes[name].update(best.tolist())
    for b in sorted(set(meta['branch'])): add(meta['branch']==b,comp,max(120,int((meta['branch']==b).sum()*.03)),f'BRANCH_{b}')
    for r in sorted(set(meta['route'])): add(meta['route']==r,comp,max(120,int((meta['route']==r).sum()*.04)),f'ROUTE_{r}')
    add(meta['sp_count']==2,comp,max(2200,int((meta['sp_count']==2).sum()*.12)),'DUAL_SP_MARKET_ANCHOR_CLOSURE')
    add(meta['lane_sp_cpt_dual_sp_attack_hedge'],comp,0,'SP_CPT_DUAL_SP_ATTACK_HEDGE_RECALL',True)
    add((~meta['cpt_sp'])&(meta['sp_count']>=1),comp,3000,'HITTER_CPT_SP_BRIDGE')
    add(meta['salary']<=47000,comp,1700,'LOW_SPEND_ELITE_TAIL')
    add(meta['strategy_unlock_count']>=1,comp,1800,'GLOBAL_STRATEGY_SALARY_UNLOCK')
    ls=.28*pct_rank(pm['top01'])+.18*pct_rank(pm['win'])+.17*pct_rank(pm['p99'])+.12*pct_rank(pm['p95'])+.10*pct_rank(-meta['own_log'])+.14*meta['lane_speed']+.01*pct_rank(meta.get('lineup_chalk_failure_fade_edge',np.zeros(len(meta['idx']))))
    add(meta['lane_sp_cpt_51'],ls,0,'SP_CPT_5_1_ONE_SP_SIBLING_CLOSURE',True)
    add(meta['lane_sp_cpt_51_speed'],ls,0,'SP_CPT_5_1_LOW_OWN_SPEED_RUNBACK',True)
    add(meta['lane_sp_cpt_control_51'],ls,0,'SP_CPT_CONTROL_5_1_SAME_TEAM_4BAT_CLOSURE',True)
    add(meta['lane_sp_cpt_control_51_speed'],ls,0,'SP_CPT_CONTROL_5_1_LOW_OWN_SPEED_RUNBACK',True)
    add(meta['lane_sp_cpt_dual_sp_attack_hedge'],ls,0,'SP_CPT_DUAL_SP_ATTACK_HEDGE_TAIL_CLOSURE',True)
    add(meta['lane_speed'],ls,512,'LOW_OWN_SPEED_ERUPTION_TAIL')
    hs=.25*pct_rank(pm['top01'])+.18*pct_rank(pm['win'])+.18*pct_rank(pm['p99'])+.12*pct_rank(pm['p95'])+.10*pct_rank(-meta['own_log'])+.09*meta['salary_release']+.08*meta['same_team_release']
    add(meta['lane_hitter_cpt_speed_low_spend'],hs,640,'HITTER_CPT_SPEED_LOW_SPEND_TAIL')
    add(meta['lane_hitter_cpt_speed_low_spend_42'],hs,640,'HITTER_CPT_SPEED_LOW_SPEND_4_2_SIBLINGS')
    add(meta['lane_hitter_cpt_speed_low_spend_42_release'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_SALARY_RELEASE_CLOSURE',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_control'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL_ORIENTATION',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_counter'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_ORIENTATION',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2_CORE',True)
    role_hs=.27*pct_rank(pm['top01'])+.18*pct_rank(pm['win'])+.17*pct_rank(pm['p99'])+.11*pct_rank(pm['p95'])+.17*pct_rank(-meta['own_log'])+.10*pct_rank(meta['salary_release'])
    add(meta['lane_hitter_cpt_same_team_sp_control'],role_hs,1400,'HITTER_CPT_SAME_TEAM_SP_CONTROL_RESERVOIR')
    add(meta['lane_hitter_cpt_favorite_51_sp_opp_punt'],role_hs,0,'HITTER_CPT_FAVORITE_5_1_SP_OPP_PUNT_CLOSURE',True)
    add(meta['lane_hitter_cpt_favorite_42_sp_rp'],role_hs,0,'HITTER_CPT_FAVORITE_4_2_SP_RP_CLOSURE',True)
    add(meta['lane_hitter_cpt_underdog_51_sp_single_rp'],role_hs,0,'HITTER_CPT_UNDERDOG_5_1_SP_SINGLE_RP_RECALL',True)
    add(meta['lane_hitter_cpt_favorite_51_sp_contact_core'],role_hs,0,'HITTER_CPT_FAVORITE_5_1_SP_CONTACT_CORE_CLOSURE',True)
    add(meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'],role_hs,0,'HITTER_CPT_FAVORITE_4_2_SP_RP_UNCERTAIN_CONTACT_SIBLING_CLOSURE',True)
    add(meta['lane_hitter_cpt_underdog_42_opp_sp_isolated_damage_premium_core'],role_hs,0,'HITTER_CPT_UNDERDOG_OPP_SP_4_2_ISOLATED_DAMAGE_PREMIUM_CORE',True)
    add(meta['lane_mixed_sp_rp'],role_hs,12,'MIXED_SP_RP_SCOUT_DEPTH')
    add(meta['lane_sp2_rp1'],role_hs,8,'MIXED_ARM_ARCHETYPE_DEPTH_SP2_RP1')
    add(meta['lane_low_owned_rp'],role_hs,3,'BULLPEN_LOW_OWN_ANTIDUPE_DEPTH')
    add(meta['lane_sp_cpt_control_51_speed_top2_core'],ls,0,'SP_CPT_CONTROL_5_1_SPEED_TOP2_CORE_CLOSURE',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2_EARLY_RELEASE_CLOSURE',True)
    add(meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'],role_hs,0,'HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK_CLOSURE',True)
    # High/high SP-CPT 4-2 closure is deliberately multi-objective.  A single
    # weighted scalar can bury a genuine extreme-tail sibling when ownership or
    # team-total terms disagree with Top-0.1/P95/P99 evidence.  Reserve the union
    # of the strongest 30% on each frozen tail dimension, then hard-cap the
    # footprint at 96 by best component rank.  This is prelock, identity-free,
    # and strictly Captain-qualified through the lane definition.
    if _high_high_market_prelock(market_context):
        _hh42_mask=np.asarray(meta['lane_sp_cpt_control_42_mid_top5'],bool)
        _hh42_ids=np.where(_hh42_mask)[0]; _hh42_n=int(len(_hh42_ids))
        if _hh42_n:
            _hh42_k=min(_hh42_n,max(24,int(math.ceil(.30*_hh42_n))))
            _hh42_union=set(); _hh42_ranks=[]
            for _key in ('top01','p99','win','p95'):
                _arr=np.asarray(pm[_key],float)
                _ord=_hh42_ids[np.argsort(-_arr[_hh42_ids],kind='mergesort')]
                _hh42_union.update(map(int,_ord[:_hh42_k]))
                _rk={int(g):j for j,g in enumerate(_ord)}; _hh42_ranks.append(_rk)
            _hh42_pick=sorted(_hh42_union,key=lambda g:(min(r[g] for r in _hh42_ranks),sum(r[g] for r in _hh42_ranks),g))[:96]
            selected.update(_hh42_pick); lanes['HIGH_HIGH_SP_CPT_CONTROL_4_2_MULTI_TAIL_BIRTH_CLOSURE'].update(_hh42_pick)
            # Fixed-pilot uncertainty sentinels: one per eligible Captain orientation.
            # The deep 50K tape scores the board, but a deterministic BASE_TRIALS
            # pilot defines this optimizer's-curse hedge so deeper MC cannot move
            # the sentinel itself.  At most two pilot sentinels are added to birth.
            _front=np.zeros(len(meta['idx']),dtype=bool)
            _spm=sentinel_pm if sentinel_pm is not None else pm
            _pilot_union=set(); _pilot_ranks=[]
            for _key in ('top01','p99','win','p95'):
                _arr=np.asarray(_spm[_key],float)
                _ord=_hh42_ids[np.argsort(-_arr[_hh42_ids],kind='mergesort')]
                _pilot_union.update(map(int,_ord[:_hh42_k]))
                _pilot_ranks.append({int(g):j for j,g in enumerate(_ord)})
            _pilot_pick=sorted(_pilot_union,key=lambda g:(min(r[g] for r in _pilot_ranks),sum(r[g] for r in _pilot_ranks),g))[:96]
            _pr=[pct_rank(np.asarray(_spm[k],float)) for k in ('top01','p99','win','p95')]
            _robust=np.maximum.reduce(_pr); _avg=sum(_pr)/4.0
            for _cpt in sorted(set(map(int,np.asarray(meta['cpt'])[_pilot_pick]))):
                _cg=[g for g in _pilot_pick if int(meta['cpt'][g])==_cpt]
                if _cg:
                    _b=min(_cg,key=lambda g:(_robust[g],_avg[g],g)); _front[int(_b)]=True
            _sent=np.where(_front)[0].astype(np.int32)
            selected.update(map(int,_sent)); lanes['HIGH_HIGH_SP_CPT_CONTROL_4_2_MULTI_TAIL_BIRTH_CLOSURE'].update(map(int,_sent))
            meta['high_high_42_uncertainty_frontier_sentinel']=_front
    # Cross-branch five-player championship-family closure.  Phase-2 can form a
    # dominant 5-1 one-SP family yet miss its 4-2 hitter-CPT role mutation when
    # that sibling falls just below global route caps.  Use only frozen prelock
    # Phase-1 tail summaries and roster structure: strong born 5-1 rows seed
    # five-player cores; qualifying 4-2 one-SP hitter-CPT minority-side siblings
    # are admitted when their tail evidence remains close to the best source
    # sibling.  This is bounded, identity-free, and consumes no realized result.
    _cross_lane=np.zeros(len(meta['idx']),dtype=bool)
    _rosters=np.asarray(meta['idx'],np.int32)
    _source=np.asarray(sorted(selected),np.int32)
    _source=_source[(np.asarray(meta['branch'],object)[_source]=='5-1') &
                    (np.asarray(meta['route'],object)[_source]=='BRIDGE_1SP') &
                    (np.asarray(meta['sp_count'],int)[_source]==1) &
                    (~np.asarray(meta['cpt_sp'],bool)[_source])]
    if len(_source):
        _q01=float(np.quantile(np.asarray(pm['top01'],float),.90))
        _q99=float(np.quantile(np.asarray(pm['p99'],float),.90))
        _source=_source[(np.asarray(pm['top01'],float)[_source]>=_q01) &
                        (np.asarray(pm['p99'],float)[_source]>=_q99)]
    _core_info={}
    for _g in map(int,_source):
        _ids=tuple(sorted(map(int,_rosters[_g,:6])))
        _m=(float(pm['top01'][_g]),float(pm['win'][_g]),float(pm['p99'][_g]),float(pm['p95'][_g]))
        for _drop in range(6):
            _core=_ids[:_drop]+_ids[_drop+1:]
            _rec=_core_info.get(_core)
            if _rec is None: _core_info[_core]=[1,_g,_m]
            else:
                _rec[0]+=1
                if _m>_rec[2]: _rec[1]=_g; _rec[2]=_m
    _core_info={k:v for k,v in _core_info.items() if int(v[0])>=2}
    _target_mask=((np.asarray(meta['branch'],object)=='4-2') &
                  (np.asarray(meta['route'],object)=='BRIDGE_1SP') &
                  (np.asarray(meta['sp_count'],int)==1) &
                  (~np.asarray(meta['cpt_sp'],bool)) &
                  (np.asarray(meta['cpt_team_count'],int)==2))
    _by_core=defaultdict(list)
    if _core_info:
        for _g in map(int,np.where(_target_mask)[0]):
            _ids=tuple(sorted(map(int,_rosters[_g,:6])))
            for _drop in range(6):
                _core=_ids[:_drop]+_ids[_drop+1:]
                if _core in _core_info: _by_core[_core].append(_g)
    _qualified=[]
    for _core,_gs in _by_core.items():
        _support,_best_source,_bm=_core_info[_core]
        _b01,_bw,_b99,_b95=map(float,_bm)
        _qs=[]
        for _g in set(map(int,_gs)):
            if float(pm['top01'][_g])+1e-12 < .95*max(_b01,1e-12): continue
            if float(pm['win'][_g])+1e-12 < .95*max(_bw,1e-12): continue
            if float(pm['p99'][_g])+1e-12 < .97*max(_b99,1e-12): continue
            if float(pm['p95'][_g])+1e-12 < .97*max(_b95,1e-12): continue
            _ratios=(float(pm['top01'][_g])/max(_b01,1e-12),
                     float(pm['win'][_g])/max(_bw,1e-12),
                     float(pm['p99'][_g])/max(_b99,1e-12),
                     float(pm['p95'][_g])/max(_b95,1e-12))
            _qs.append((_g,min(_ratios),sum(_ratios)/4.0))
        if not _qs: continue
        _qs=sorted(_qs,key=lambda z:(z[1],z[2],float(pm['top01'][z[0]]),-z[0]),reverse=True)[:4]
        _qualified.append((_b01,_b99,int(_support),_core,[int(z[0]) for z in _qs]))
    _cross_pick=set()
    for _rec in sorted(_qualified,key=lambda z:(z[0],z[1],z[2],z[3]),reverse=True):
        _cross_pick.update(_rec[4])
        if len(_cross_pick)>=512: break
    if _cross_pick:
        _cross_pick=set(sorted(_cross_pick)[:512]) if len(_cross_pick)>512 else _cross_pick
        _cross_ids=np.asarray(sorted(_cross_pick),np.int32)
        _cross_lane[_cross_ids]=True
        selected.update(map(int,_cross_ids))
        lanes['CROSS_BRANCH_FIVE_PLAYER_CHAMPIONSHIP_FAMILY_CLOSURE'].update(map(int,_cross_ids))
    meta['lane_cross_branch_five_player_championship_family']=_cross_lane

    elite_rp_score=.34*pct_rank(pm['top01'])+.24*pct_rank(pm['p99'])+.18*pct_rank(pm['win'])+.12*pct_rank(pm['p95'])+.12*pct_rank(meta['salary'])
    for elite_n,label in [(1,'ELITE_SINGLE_RP_TAIL_RECALL'),(2,'ELITE_DUAL_RP_TAIL_RECALL')]:
        mask=(meta['elite_rp_count']==elite_n)
        add(mask,elite_rp_score,max(120,int(mask.sum()*.03)),label)
    return np.array(sorted(selected),np.int32),comp,ls,{k:len(v) for k,v in lanes.items()}

def handoff(born,bm,meta):
    sc=.31*pct_rank(bm['top01'])+.17*pct_rank(bm['top10'])+.21*pct_rank(bm['win'])+.16*pct_rank(bm['p99'])+.08*pct_rank(bm['p95'])+.03*pct_rank(bm['mean'])+.04*pct_rank(-meta['own_log'][born])-meta.get('self_conflict_penalty',np.zeros(len(meta['idx'])))[born]+meta.get('side_commitment_bonus',np.zeros(len(meta['idx'])))[born]
    sc+=.07*meta['lane_sp_cpt_51'][born]+.10*meta['lane_sp_cpt_51_speed'][born]+.05*meta['lane_speed'][born]+.10*meta['lane_sp_cpt_dual_sp_attack_hedge'][born]
    sc+=.08*meta['lane_hitter_cpt_speed_low_spend_42'][born]+.13*meta['lane_hitter_cpt_speed_low_spend_42_release'][born]+.04*meta['salary_release'][born]
    k=min(1650,len(born)); sel=set(born[np.argpartition(-sc,k-1)[:k]].tolist()); reserve={}; pos={g:i for i,g in enumerate(born)}
    specs=[
      ('SP_CPT_5_1',meta['lane_sp_cpt_51'],220,False),('SP_CPT_5_1_SPEED',meta['lane_sp_cpt_51_speed'],0,True),
      ('SP_CPT_CONTROL_5_1',meta['lane_sp_cpt_control_51'],220,False),('SP_CPT_CONTROL_5_1_SPEED',meta['lane_sp_cpt_control_51_speed'],0,True),('SP_CPT_DUAL_SP_ATTACK_HEDGE',meta['lane_sp_cpt_dual_sp_attack_hedge'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND',meta['lane_hitter_cpt_speed_low_spend'],240,False),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2',meta['lane_hitter_cpt_speed_low_spend_42'],384,False),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE',meta['lane_hitter_cpt_speed_low_spend_42_release'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL',meta['lane_hitter_cpt_speed_low_spend_42_control'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER',meta['lane_hitter_cpt_speed_low_spend_42_counter'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2',meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'],0,True),
      ('LOW_OWN_SPEED',meta['lane_speed'],120,False),('DUAL_SP',meta['sp_count']==2,96,False),('NO_SP',meta['sp_count']==0,96,False),('3_3',meta['branch']=='3-3',96,False)]
    for name,mask,k,all_rows in specs:
        ids=np.array([g for g in born if mask[g]],np.int32)
        if len(ids):
            best=ids if all_rows else ids[np.argpartition(-np.array([sc[pos[x]] for x in ids]),min(k,len(ids))-1)[:min(k,len(ids))]]
            before=len(sel); sel.update(best.tolist()); reserve[name]=len(sel)-before
        else: reserve[name]=0
    for p in range(len(meta['names'])):
        mask_without=~np.isin(meta['idx'][born],p).any(1); ids=born[mask_without]
        if len(ids):
            loc=np.where(mask_without)[0]; kk=min(96,len(ids)); best=ids[np.argpartition(-sc[loc],kk-1)[:kk]]
            before=len(sel); sel.update(best.tolist()); reserve[f'WITHOUT_PLAYER_ID_{p}']=len(sel)-before
        else: reserve[f'WITHOUT_PLAYER_ID_{p}']=0
    # Global state v1.19 requires Phase 2, handoff, and selector-review set
    # parity. Keep the surface accounting for diagnostics, but do not cull a
    # calibration-qualified Phase 2 lineup before independent evaluation.
    reserve['PHASE2_PARITY_RESTORED']=int(len(born)-len(sel))
    return born.copy(),reserve

def diverse_family_reps(cands,score,meta,mask,n=3,max_overlap=4,max_non_cpt_exposure=2):
    ids=np.where(mask)[0]
    ranked=ids[np.argsort(-score[ids],kind='mergesort')]
    eligible_rosters=[set(meta['idx'][cands[j]].tolist()) for j in ids]
    mandatory_spine=set.intersection(*eligible_rosters) if eligible_rosters else set()
    base_cap=max(int(max_overlap),len(mandatory_spine))
    max_cap=min(5,int(meta['idx'].shape[1])-1)
    for effective_overlap_cap in range(base_cap,max_cap+1):
        chosen=[]; counts=Counter()
        for j in ranked:
            g=cands[j]; roster=set(meta['idx'][g].tolist()); cpt=int(meta['cpt'][g])
            if any(p!=cpt and p not in mandatory_spine and counts[p]>=max_non_cpt_exposure for p in roster):
                continue
            if all(len(roster & set(meta['idx'][cands[k]].tolist()))<=effective_overlap_cap for k in chosen):
                chosen.append(int(j))
                for p in roster:
                    if p!=cpt and p not in mandatory_spine: counts[p]+=1
                if len(chosen)>=n: return chosen
    raise RuntimeError(f'DIVERSE_FAMILY_REP_UNSATISFIABLE:{len(chosen)}/{n}')

def best_by_signature_reps(cands,score,meta,mask,signatures,n=2,max_overlap=5):
    ids=np.where(mask)[0]
    groups=defaultdict(list)
    for j in ids: groups[int(signatures[j])].append(int(j))
    reps=[]
    for sig,js in groups.items(): reps.append(max(js,key=lambda j:(score[j],-j)))
    ranked=sorted(reps,key=lambda j:(-score[j],j))
    chosen=[]
    for j in ranked:
        roster=set(meta['idx'][cands[j]].tolist())
        if all(len(roster & set(meta['idx'][cands[k]].tolist()))<=max_overlap for k in chosen):
            chosen.append(j)
            if len(chosen)>=n: break
    if len(chosen)<n: raise RuntimeError(f'SIGNATURE_REP_UNSATISFIABLE:{len(chosen)}/{n}')
    return chosen

def credible_one_swap_siblings(seed_local,cands,score,cm,meta,top01_ratio=.25,p99_ratio=.90):
    """Hedge the seed's most fragile hitter slot with one-UTIL alternatives.

    Fragility is defined from the sealed source ownership signal: the
    lowest-owned non-pitcher UTIL in the elite seed. All other four UTILs and
    the CPT are held fixed. This prevents arbitrary family diversification.
    """
    seed_local=int(seed_local); g=int(cands[seed_local]); cpt=int(meta['cpt'][g])
    utils=list(map(int,meta['idx'][g,1:6])); spids=set(map(int,meta.get('sp_player_ids',[]))); rpids=set(map(int,meta.get('rp_player_ids',[])))
    hitters=[q for q in utils if q not in spids and q not in rpids]
    if not hitters: return []
    own=np.asarray(meta['own'],float); fragile=min(hitters,key=lambda q:(own[q],q)); keep=set(utils)-{fragile}
    seed_top=float(cm['top01'][seed_local]); seed_p99=float(cm['p99'][seed_local]); out=[]
    for j,g2 in enumerate(cands):
        if j==seed_local or int(meta['cpt'][g2])!=cpt: continue
        u2=set(map(int,meta['idx'][g2,1:6]))
        if fragile in u2 or len(u2)!=5 or not keep.issubset(u2): continue
        if float(cm['top01'][j])+1e-12 < top01_ratio*max(seed_top,1e-12): continue
        if float(cm['p99'][j])+1e-12 < p99_ratio*max(seed_p99,1e-12): continue
        out.append(int(j))
    return sorted(out,key=lambda j:(-score[j],j))

def _portfolio_constraints(pcands,pscore,meta,size,own,locks=(),sibling_groups=()):
    rows=[np.ones(len(pcands))]; lb=[size]; ub=[size]
    pmap={int(g):i for i,g in enumerate(pcands)}
    for g in locks:
        if int(g) not in pmap: continue
        v=np.zeros(len(pcands)); v[pmap[int(g)]]=1.; rows.append(v); lb.append(1); ub.append(1)
    for item in sibling_groups:
        if isinstance(item,tuple): globals_group,required=item
        else: globals_group,required=item,1
        mapped=[pmap[int(g)] for g in globals_group if int(g) in pmap]
        if not mapped: continue
        required=min(int(required),len(mapped))
        v=np.zeros(len(pcands)); v[np.asarray(mapped,np.int32)]=1.; rows.append(v); lb.append(required); ub.append(len(mapped))
    n=len(meta['names']); roster=meta['idx'][pcands]
    for p in range(n):
        has=np.isin(roster,p).any(1).astype(float)
        if has.sum():
            cap_share=float(np.clip(max(.70,own[p]+.10),.70,1.0)); cap=max(1,min(size,int(math.ceil(size*cap_share))))
            rows.append(has); lb.append(0); ub.append(cap)
        cp=(meta['cpt'][pcands]==p).astype(float)
        if cp.sum():
            cpt_share=.60 if own[p]>=.65 else .40 if own[p]>=.35 else .30
            cap=max(1,min(size,int(math.ceil(size*cpt_share))))
            rows.append(cp); lb.append(0); ub.append(cap)
    for a in range(n):
        ha=np.isin(roster,a).any(1)
        if not ha.any(): continue
        for b in range(a+1,n):
            v=(ha & np.isin(roster,b).any(1)).astype(float)
            if not v.any(): continue
            pair_share=float(np.clip(max(.60,min(own[a],own[b])+.10),.60,.90)); cap=max(1,min(size,int(math.ceil(size*pair_share))))
            rows.append(v); lb.append(0); ub.append(cap)
    rp_any=(meta['rp_count'][pcands]>0).astype(float); rows.append(rp_any); lb.append(0); ub.append(min(3,size))
    return LinearConstraint(csr_matrix(np.vstack(rows)),lb,ub)

def _high_dual_sp_cpt_market(slate_context=None):
    src=slate_context if slate_context is not None else _LAST_FIELD_RECEIPT
    return float(src.get('TARGET_DUAL_SP_SHARE',0.0))>=0.50 and float(src.get('TARGET_SP_CPT_SHARE',0.0))>=0.50


def _dual_sp_threshold_cliff_market(slate_context=None):
    """Cheap structural guard for the 0.50 dual-SP routing discontinuity.

    A slate with exactly two confirmed starters, both materially owned, an SP-CPT
    heavy field, and a large starter-ownership gap must not lose the lower-owned
    starter-CPT dual-SP family merely because the continuous dual-SP target lands
    a few basis points below the legacy 0.50 routing threshold.
    """
    src=slate_context if slate_context is not None else _LAST_FIELD_RECEIPT
    vals=tuple(float(x) for x in src.get('STARTER_OWNERSHIP_VALUES',()))
    if int(src.get('CONFIRMED_STARTERS',0))!=2 or len(vals)!=2: return False
    return (
        not _high_dual_sp_cpt_market(src)
        and float(src.get('TARGET_DUAL_SP_SHARE',0.0))>=0.45
        and float(src.get('TARGET_SP_CPT_SHARE',0.0))>=0.50
        and min(vals)>=0.50
        and float(src.get('STARTER_OWNERSHIP_GAP',abs(vals[0]-vals[1])))>=0.30
    )

def _market_geometry_seed_locals(cands,score,meta,max_seeds=2,slate_context=None):
    """Top individual dual-SP/SP-CPT seed per starter CPT in a market that demands it."""
    if not _high_dual_sp_cpt_market(slate_context): return []
    cands=np.asarray(cands,np.int32); score=np.asarray(score,float)
    mask=np.asarray(meta['cpt_sp'][cands],bool)&(np.asarray(meta['sp_count'][cands])==2)
    ids=np.where(mask)[0]; reps=[]
    if not len(ids): return reps
    for cpt in sorted(set(map(int,meta['cpt'][cands[ids]]))):
        z=ids[meta['cpt'][cands[ids]]==cpt]
        if len(z): reps.append(int(z[np.argmax(score[z])]))
    reps=sorted(reps,key=lambda j:(-score[j],j))
    return reps[:max_seeds]

def reciprocal_sp_cpt_local(candidate_local,cands,meta):
    """Same six-player roster with the other confirmed starter moved to CPT."""
    j=int(candidate_local); cands=np.asarray(cands,np.int32); g=int(cands[j]); row=list(map(int,meta['idx'][g,:6])); cpt=int(row[0])
    spids=set(map(int,meta.get('sp_player_ids',[]))); sps=[q for q in row if q in spids]
    if len(sps)!=2 or cpt not in spids: return None
    other=sps[0] if sps[1]==cpt else sps[1]; roster=set(row)
    for k,g2 in enumerate(cands):
        if int(meta['cpt'][int(g2)])==other and set(map(int,meta['idx'][int(g2),:6]))==roster:
            return int(k)
    return None

def market_reciprocal_candidates(cands,cm,meta,max_pairs=1,slate_context=None):
    """Blind reciprocal CPT hedge around the best credible sibling of top dual-SP seeds."""
    if not _high_dual_sp_cpt_market(slate_context): return []
    comp=contest_finish_components(cands,cm,meta,trials=BASE_TRIALS+EXTRA_TRIALS); score=np.asarray(comp['score'],float); out=[]
    for seed in _market_geometry_seed_locals(cands,score,meta,max_seeds=max_pairs,slate_context=slate_context):
        sib=credible_one_swap_siblings(seed,cands,score,cm,meta)
        if not sib: continue
        best=max(sib,key=lambda j:(float(cm['top01'][j]),float(cm['p99'][j]),score[j],-j))
        rec=reciprocal_sp_cpt_local(best,cands,meta)
        if rec is None: continue
        if float(cm['top01'][rec])+1e-12 < .20*max(float(cm['top01'][best]),1e-12): continue
        if float(cm['p99'][rec])+1e-12 < .90*max(float(cm['p99'][best]),1e-12): continue
        out.append(int(rec))
    return list(dict.fromkeys(out))[:max_pairs]

def _choose_protection_seeds(chosen_full_locals,cands,meta,max_seeds=3,slate_context=None):
    """Choose seed cores from the stage-1 portfolio using blind field geometry."""
    chosen=list(map(int,chosen_full_locals)); out=[]; used=set()
    src=slate_context if slate_context is not None else _LAST_FIELD_RECEIPT
    high_sp_cpt=float(src.get('TARGET_SP_CPT_SHARE',0.0))>=0.50
    if high_sp_cpt:
        # In starter-CPT-heavy fields, prioritize the distinct confirmed starter
        # captain cores; hitter-CPT rows remain eligible but need no forced hedge.
        for j in chosen:
            g=int(cands[j]); cpt=int(meta['cpt'][g])
            if not bool(meta['cpt_sp'][g]) or cpt in used: continue
            out.append(j); used.add(cpt)
            if len(out)>=min(2,max_seeds): return out
    for j in chosen:
        g=int(cands[j]); cpt=int(meta['cpt'][g])
        if cpt in used: continue
        out.append(j); used.add(cpt)
        if len(out)>=max_seeds: break
    return out

def baseline_portfolio_seed_locals(cands,cm,meta,size=10,max_seeds=3,slate_context=None):
    """Stage-1 blind portfolio seeds used only to allocate sibling extra trials."""
    cands=np.asarray(cands,np.int32); comp=contest_finish_components(cands,cm,meta,trials=BASE_TRIALS); score=np.asarray(comp['score'],float)
    rank1=int(np.argmax(score)); own=np.asarray(meta['own'],float)/100.0; ranked=np.argsort(-score,kind='mergesort')
    pool_full=np.asarray(ranked[:min(len(cands),max(2500,size*250))],np.int32)
    if rank1 not in set(map(int,pool_full)): pool_full=np.r_[pool_full,rank1]
    pcands=cands[pool_full]; pscore=score[pool_full]
    con=_portfolio_constraints(pcands,pscore,meta,size,own,locks=[int(cands[rank1])])
    res=milp(-pscore,integrality=np.ones(len(pcands)),bounds=Bounds(0,1),constraints=con,options={'time_limit':10})
    if not res.success: return []
    chosen=pool_full[np.where(res.x>.5)[0]]; chosen=chosen[np.argsort(-score[chosen],kind='mergesort')]
    seeds=[]
    seed_order=_market_geometry_seed_locals(cands,score,meta,max_seeds=min(2,max_seeds),slate_context=slate_context) + _choose_protection_seeds(chosen,cands,meta,max_seeds=max_seeds,slate_context=slate_context)
    for j in seed_order:
        if int(j) in seeds: continue
        if credible_one_swap_siblings(j,cands,score,cm,meta): seeds.append(int(j))
        if len(seeds)>=max_seeds: break
    return seeds

def _legacy_elite_tail_score(cands,cm,meta):
    """v1.32.20 blind-validated contest-finish score; no post-lock inputs."""
    cands=np.asarray(cands,np.int32)
    trial_n=np.asarray(cm.get('trials',np.full(len(cands),BASE_TRIALS+EXTRA_TRIALS)),float)
    top01_lcb=wilson_lcb(np.asarray(cm['top01'],float),trial_n,z=1.0)
    win_lcb=wilson_lcb(np.asarray(cm['win'],float),trial_n,z=1.0)
    return (
        .46*pct_rank(top01_lcb)
        + .30*pct_rank(win_lcb)
        + .14*pct_rank(np.asarray(cm['p99'],float))
        + .07*pct_rank(np.asarray(cm['p95'],float))
        + .03*pct_rank(-np.asarray(meta['own_log'][cands],float))
        - np.asarray(meta.get('self_conflict_penalty',np.zeros(len(meta['idx']))),float)[cands]
        + np.asarray(meta.get('side_commitment_bonus',np.zeros(len(meta['idx']))),float)[cands]
    )


def _asymmetric_dual_sp_market(meta, slate_context=None):
    if slate_context is not None:
        if not isinstance(slate_context,FrozenSlateContext): raise TypeError('SELECTOR_REQUIRES_FROZEN_SLATE_CONTEXT')
        return (
            int(slate_context.get('CONFIRMED_STARTERS',0))==2
            and (_high_dual_sp_cpt_market(slate_context) or _dual_sp_threshold_cliff_market(slate_context))
            and float(slate_context.get('STARTER_OWNERSHIP_GAP',0.0))>=0.30
        )
    if not (_high_dual_sp_cpt_market() or _dual_sp_threshold_cliff_market()): return False
    spids=list(map(int,meta.get('sp_player_ids',[])))
    if len(spids)!=2: return False
    own=sorted((float(meta['own'][i])/100.0 for i in spids),reverse=True)
    return (own[0]-own[1])>=0.30


def _feasibility_fracture_hitter_cpt_dual_sp_insurance_active(slate_context):
    """Blind public-field feasibility fracture gate; all inputs are frozen pre-lock geometry."""
    if not isinstance(slate_context,FrozenSlateContext): return False
    return (
        float(slate_context.get('TARGET_DUAL_SP_SHARE',0.0))>=0.50
        and float(slate_context.get('TARGET_SP_CPT_SHARE',0.0))>=0.50
        and (
            float(slate_context.get('ACTUAL_DUAL_SP_SHARE',1.0))<0.50
            or float(slate_context.get('ACTUAL_SP_CPT_SHARE',1.0))<0.50
        )
    )

def _low_owned_sp_cpt_lane(cands,advisor_score,meta,n=4,max_overlap=4,slate_context=None):
    """Blind asymmetric closure with bounded hitter-CPT dual-SP feasibility insurance.

    The lock budget is unchanged.  When the public-field generator cannot realize
    the high dual-SP/SP-CPT targets, reserve one of the existing four locks for
    the top advisor-ranked hitter-CPT dual-SP lineup instead of adding a fifth lock.
    """
    if not _asymmetric_dual_sp_market(meta,slate_context): return []
    if slate_context is not None:
        low=int(slate_context['LOWER_OWNED_SP_ID'])
    else:
        spids=list(map(int,meta.get('sp_player_ids',[])))
        low=min(spids,key=lambda i:(float(meta['own'][i]),i))
    ids=np.where((meta['cpt'][cands]==low)&(meta['sp_count'][cands]==2))[0]
    ranked=ids[np.argsort(-advisor_score[ids],kind='mergesort')]
    fracture=_feasibility_fracture_hitter_cpt_dual_sp_insurance_active(slate_context)
    low_budget=max(0,int(n)-1) if fracture else int(n)
    out=[]
    for j in ranked:
        roster=set(map(int,meta['idx'][int(cands[j]),:6]))
        if all(len(roster & set(map(int,meta['idx'][int(cands[k]),:6])))<=max_overlap for k in out):
            out.append(int(j))
        if len(out)>=low_budget: break
    if fracture and int(n)>0:
        c=np.asarray(cands,np.int32); score=np.asarray(advisor_score,float)
        hitter_dual=np.where((meta['sp_count'][c]==2)&(~meta['cpt_sp'][c]))[0]
        if len(hitter_dual):
            best=int(hitter_dual[np.argmax(score[hitter_dual])])
            if best not in out: out.append(best)
    return out[:int(n)]


def _legacy_market_reciprocal_candidates(cands,cm,meta,score,max_pairs=1,slate_context=None):
    if not _high_dual_sp_cpt_market(slate_context): return []
    out=[]
    for seed in _market_geometry_seed_locals(cands,score,meta,max_seeds=max_pairs,slate_context=slate_context):
        sib=credible_one_swap_siblings(seed,cands,score,cm,meta)
        if not sib: continue
        best=max(sib,key=lambda j:(float(cm['top01'][j]),float(cm['p99'][j]),score[j],-j))
        rec=reciprocal_sp_cpt_local(best,cands,meta)
        if rec is None: continue
        if float(cm['top01'][rec])+1e-12 < .20*max(float(cm['top01'][best]),1e-12): continue
        if float(cm['p99'][rec])+1e-12 < .90*max(float(cm['p99'][best]),1e-12): continue
        out.append(int(rec))
    return list(dict.fromkeys(out))[:max_pairs]



def _family_keys_local(g,meta,spids,rpids):
    row=list(map(int,meta['idx'][int(g),:6])); sp=tuple(sorted(q for q in row if q in spids))
    hitters=[q for q in row if q not in spids and q not in rpids]; teams=meta['teams']; out=[]
    for a in range(len(hitters)):
        for b in range(a+1,len(hitters)):
            x,y=hitters[a],hitters[b]
            if teams[x]==teams[y]: out.append((sp,tuple(sorted((x,y)))))
    return out


def _normal_market_elite_rp_family_closure(cands,cm,meta,advisor_score,p1,lineups,top01_threshold,size=10,slate_context=None):
    """Rare normal-market insurance lane for two independently elite RPs.

    Activation is entirely pre-lock: normal market, two RPs each clearing the
    four-signal role/tail gate, and legal Phase-2 rows containing the pair.
    Families are selected by a Pareto surface of conditional RP-appearance
    quality and ordinary common-world Top-0.1 sibling complementarity.  At most
    2/3 of board slots may be protected by this closure; the balance remains on
    the existing advisor stream.
    """
    if _high_dual_sp_cpt_market(slate_context): return [],{'ACTIVE':False,'REASON':'HIGH_DUAL_SP_BYPASS'}
    if p1 is None or lineups is None or top01_threshold is None: return [],{'ACTIVE':False,'REASON':'MISSING_COMMON_WORLD_INPUT'}
    elite=list(map(int,meta.get('elite_rp_player_ids',[])))
    if len(elite)<2: return [],{'ACTIVE':False,'REASON':'NO_STRICT_ELITE_RP_PAIR','ELITE_RP_IDS':elite}
    cands=np.asarray(cands,np.int32); advisor_score=np.asarray(advisor_score,float); top01_threshold=np.asarray(top01_threshold,float)
    spids=set(map(int,meta.get('sp_player_ids',[]))); rpids=set(map(int,meta.get('rp_player_ids',[])))
    # All strict pairs that physically coexist in the selector population.
    pair_rows=[]
    for ia in range(len(elite)):
        for ib in range(ia+1,len(elite)):
            a,b=elite[ia],elite[ib]
            ids=np.where(np.array([a in meta['idx'][int(g),:6] and b in meta['idx'][int(g),:6] for g in cands],bool))[0]
            if len(ids): pair_rows.append((a,b,ids))
    if not pair_rows: return [],{'ACTIVE':False,'REASON':'NO_ELITE_RP_PAIR_CANDIDATES','ELITE_RP_IDS':elite}
    # Build only families touched by an elite-RP pair.
    scenario={}; touched=set(); pair_mass={}
    for a,b,ids in pair_rows:
        mask=(p1[:,a]>0)&(p1[:,b]>0); mass=float(mask.mean()); pair_mass[f'{a}:{b}']=mass
        if not mask.any(): continue
        for j in ids:
            g=int(cands[int(j)]); row=meta['idx'][g,:6]
            v=1.5*p1[mask,int(row[0])] + p1[mask][:,row[1:6]].sum(axis=1)
            score=.55*float(v.mean())+.45*float(np.quantile(v,.95))
            for key in _family_keys_local(g,meta,spids,rpids):
                touched.add(key); old=scenario.get(key)
                if old is None or score>old['SCENARIO_SCORE']:
                    scenario[key]={'LOCAL':int(j),'GLOBAL':g,'SCENARIO_SCORE':score,'COND_MEAN':float(v.mean()),'COND_P95':float(np.quantile(v,.95)),'PAIR':(a,b),'PAIR_MASS':mass}
    if not scenario: return [],{'ACTIVE':False,'REASON':'NO_SCENARIO_FAMILIES','PAIR_MASS':pair_mass}
    fam={k:[] for k in touched}
    for j,g in enumerate(cands):
        for key in _family_keys_local(int(g),meta,spids,rpids):
            if key in fam: fam[key].append(int(j))
    # Common-world Top-0.1 event packs over base trials, only for touched-family members.
    base_n=min(BASE_TRIALS,p1.shape[0],len(top01_threshold)); base_p1=p1[:base_n]; thr=top01_threshold[:base_n]
    needed=sorted(set(j for ids in fam.values() for j in ids)); nbytes=(base_n+7)//8; packs={}
    for z0 in range(0,len(needed),512):
        loc=np.asarray(needed[z0:z0+512],np.int32); gs=cands[loc]; rows=meta['idx'][gs,:6]
        vals=base_p1[:,rows[:,1:6]].sum(axis=2)+1.5*base_p1[:,rows[:,0]]
        pk=np.packbits((vals>=thr[:,None]).T,axis=1)
        for q,j in enumerate(loc): packs[int(j)]=pk[q]
    pop=np.array([bin(i).count('1') for i in range(256)],np.uint8)
    zero=np.zeros(nbytes,np.uint8)
    def _count(v): return int(pop[v].sum())
    def _greedy3(ids):
        u=zero.copy(); chosen=[]; cnt=0
        for _ in range(min(3,len(ids))):
            bj=None; bc=-1; bv=None
            for j in ids:
                if j in chosen: continue
                v=np.bitwise_or(u,packs[int(j)]); c=_count(v)
                if c>bc: bj=int(j); bc=c; bv=v
            if bj is None: break
            chosen.append(bj); u=bv; cnt=bc
        return float(cnt/base_n),chosen
    recs=[]
    for key,sc in scenario.items():
        ids=fam.get(key,[])
        if not ids: continue
        best=max(float(cm['top01'][j]) for j in ids); gu,_=_greedy3(ids); comp=gu/max(best,1e-12)
        recs.append({'KEY':key,'SCENARIO_SCORE':sc['SCENARIO_SCORE'],'COMPLEMENTARITY':comp,'GREEDY3_UNION':gu,'BEST_EXACT_TOP01':best,'SCENARIO':sc,'MEMBERS':len(ids)})
    front=[]
    for i,r in enumerate(recs):
        dom=False
        for q,x in enumerate(recs):
            if q==i: continue
            if x['SCENARIO_SCORE']>=r['SCENARIO_SCORE'] and x['COMPLEMENTARITY']>=r['COMPLEMENTARITY'] and (x['SCENARIO_SCORE']>r['SCENARIO_SCORE'] or x['COMPLEMENTARITY']>r['COMPLEMENTARITY']): dom=True; break
        if not dom: front.append(r)
    # Existing Showdown max-same-script share is 2/3. Each family contributes
    # at most two protected rows, so floor(size/3) families preserves >=40%
    # of a 10-entry board for the ordinary advisor stream.
    # Down-select the nondominated frontier without scalar weights: preserve
    # both Pareto endpoints, then maximize normalized max-min spread.  This
    # keeps conditional RP strength and sibling complementarity represented.
    budget=max(1,int(size//3)); front=sorted(front,key=lambda r:(-r['SCENARIO_SCORE'],-r['COMPLEMENTARITY']))
    if len(front)>budget:
        xs=np.array([r['SCENARIO_SCORE'] for r in front],float); ys=np.array([r['COMPLEMENTARITY'] for r in front],float)
        xn=(xs-xs.min())/max(float(xs.max()-xs.min()),1e-12); yn=(ys-ys.min())/max(float(ys.max()-ys.min()),1e-12)
        chosen=[]
        for q in [int(np.argmax(xn)),int(np.argmax(yn))]:
            if q not in chosen: chosen.append(q)
            if len(chosen)>=budget: break
        while len(chosen)<budget:
            best=None; bestd=-1.0
            for q in range(len(front)):
                if q in chosen: continue
                d=min(float(np.hypot(xn[q]-xn[z],yn[q]-yn[z])) for z in chosen)
                if d>bestd+1e-12 or (abs(d-bestd)<=1e-12 and (best is None or xs[q]>xs[best])): best=q; bestd=d
            if best is None: break
            chosen.append(int(best))
        front=[front[q] for q in chosen]
    protected=[]; u=zero.copy(); family_receipts=[]
    for r in front:
        j=int(r['SCENARIO']['LOCAL'])
        if j not in protected: protected.append(j); np.bitwise_or(u,packs[j],out=u)
    # One ordinary, non-RP reciprocal-core CPT representative per selected family.
    for r in front:
        key=r['KEY']; core=set(key[0]+key[1]); lane=[]
        for j in fam[key]:
            g=int(cands[j]); cpt=int(meta['cpt'][g])
            if int(meta['rp_count'][g])!=0 or cpt not in core: continue
            lane.append(int(j))
        prim=[]
        for cpt in sorted(set(int(meta['cpt'][int(cands[j])]) for j in lane)):
            z=[j for j in lane if int(meta['cpt'][int(cands[j])])==cpt]
            if z: prim.append(max(z,key=lambda j:(float(cm['top01'][j]),float(cm['p99'][j]),float(advisor_score[j]),-j)))
        if prim:
            best=max(prim,key=lambda j:_count(np.bitwise_or(u,packs[j])))
            if best not in protected: protected.append(int(best)); np.bitwise_or(u,packs[best],out=u)
        family_receipts.append({'SP_IDS':list(map(int,key[0])),'HITTER_PAIR_IDS':list(map(int,key[1])),'SCENARIO_SCORE':float(r['SCENARIO_SCORE']),'COMPLEMENTARITY':float(r['COMPLEMENTARITY']),'SCENARIO_GLOBAL':int(r['SCENARIO']['GLOBAL']),'PAIR_IDS':list(map(int,r['SCENARIO']['PAIR'])),'PAIR_APPEARANCE_MASS':float(r['SCENARIO']['PAIR_MASS'])})
    # hard bound: never let closure exceed 2/3 of board.
    protected=protected[:int(math.floor(size*(2.0/3.0)))]
    return protected,{'ACTIVE':bool(protected),'PATCH_ID':'MLB_SD_ELITE_DUAL_RP_SCENARIO_FAMILY_SELECTOR_v1','ELITE_RP_IDS':elite,'PAIR_MASS':pair_mass,'PARETO_FAMILY_COUNT':len(front),'PROTECTED_LOCAL_COUNT':len(protected),'PROTECTED_GLOBALS':[int(cands[j]) for j in protected],'FAMILIES':family_receipts,'BASE_COMMON_WORLD_TRIALS':int(base_n),'MAX_SCRIPT_SHARE':2.0/3.0}

def _mlb_championship_family_labels(globals_,meta):
    """Sport-specific family identity for the global championship-core kernel."""
    out=[]; spids=set(map(int,np.asarray(meta.get('sp_player_ids',[]),dtype=np.int32).tolist()))
    for g in map(int,np.asarray(globals_,dtype=np.int32)):
        roster=list(map(int,np.asarray(meta['idx'][g],dtype=np.int32).tolist()))
        sps=tuple(sorted(meta['names'][q] for q in roster if q in spids))
        cpt=int(meta['cpt'][g]); teams=meta.get('teams',None)
        cpt_team=str(teams[cpt]) if teams is not None and len(teams)>cpt else 'UNKNOWN_TEAM'
        cpt_role='SP' if bool(meta.get('cpt_sp',np.zeros(len(meta['idx']),bool))[g]) else 'BAT'
        cpt_side=int(meta.get('cpt_team_count',np.zeros(len(meta['idx']),np.int8))[g])
        out.append(f"{meta['branch'][g]}|CPT_{cpt_role}_{cpt_team}|SP_{'/'.join(map(str,sps))}|CPTSIDE_{cpt_side}")
    return np.asarray(out,object)



def _sp_cpt_control_51_runback_tier_priority(globals_,quality,advisor_score,meta,slate_context=None):
    """Normal-market SP-CPT 5-1 uncertainty-tier sentinels.

    Trigger only when the blind market wants SP Captain exposure but has not
    crossed the dual-SP high/high regime.  Within the structural control lane,
    require four same-team starting hitters batting 2..6 and one opposing
    starting-hitter runback.  Preserve at most one frozen-tail representative
    from each opponent batting-order tier (TOP/MID/BOT).
    """
    if slate_context is None:
        return [],{'PATCH_ID':'MLB_SD_SP_CPT_CONTROL_5_1_MIDDLE_ORDER_RUNBACK_TIER_CLOSURE_v1','TRIGGERED':False,'REASON':'NO_FROZEN_CONTEXT'}
    ctx=slate_context.as_dict() if hasattr(slate_context,'as_dict') else dict(slate_context)
    spc=float(ctx.get('TARGET_SP_CPT_SHARE',0.0)); dual=float(ctx.get('TARGET_DUAL_SP_SHARE',0.0))
    if not (spc>=.50 and dual<.50):
        return [],{'PATCH_ID':'MLB_SD_SP_CPT_CONTROL_5_1_MIDDLE_ORDER_RUNBACK_TIER_CLOSURE_v1','TRIGGERED':False,'TARGET_SP_CPT_SHARE':spc,'TARGET_DUAL_SP_SHARE':dual}
    g=np.asarray(globals_,np.int32); q=np.asarray(quality,float); adv=np.asarray(advisor_score,float)
    teams=np.asarray(meta.get('teams',[]),object); order=np.asarray(meta.get('batting_order',[]),int); spids=set(map(int,np.asarray(meta.get('sp_player_ids',[]),np.int32)))
    tiers={'TOP':[],'MID':[],'BOT':[]}
    for j,x in enumerate(g):
        x=int(x)
        if not bool(meta['lane_sp_cpt_control_51'][x]) or not bool(meta['cpt_sp'][x]): continue
        cpt=int(meta['cpt'][x]); ct=teams[cpt]; same=[]; opp=[]
        for pid in map(int,np.asarray(meta['idx'][x,1:6],np.int32)):
            if pid in spids: continue
            if teams[pid]==ct: same.append(pid)
            else: opp.append(pid)
        if len(same)!=4 or len(opp)!=1: continue
        if not all(2<=int(order[z])<=6 for z in same): continue
        oo=int(order[opp[0]])
        if not 1<=oo<=9: continue
        tier='TOP' if oo<=3 else ('MID' if oo<=6 else 'BOT')
        tiers[tier].append(j)
    chosen=[]; detail={}
    for tier in ('TOP','MID','BOT'):
        ids=tiers[tier]
        if not ids: detail[tier]=None; continue
        best=max(ids,key=lambda j:(float(q[j]),float(adv[j]),-int(g[j])))
        chosen.append(int(best)); detail[tier]=int(g[best])
    return chosen,{'PATCH_ID':'MLB_SD_SP_CPT_CONTROL_5_1_MIDDLE_ORDER_RUNBACK_TIER_CLOSURE_v1','TRIGGERED':bool(chosen),'TARGET_SP_CPT_SHARE':spc,'TARGET_DUAL_SP_SHARE':dual,'TIER_GLOBALS':detail,'RESERVED_GLOBALS':[int(g[j]) for j in chosen],'POSTLOCK_INPUT_USED':False}


def _sp_cpt_dual_sp_attack_hedge_priority(globals_,quality,p99,meta):
    """Identity-free Core-5 sentinel for deep-release dual-SP attack hedges.

    A minority-side starter Captain can still reach a ceiling through strikeouts
    while a concentrated four-hitter majority-side block scores via isolated
    damage.  Preserve one such 5-1 family only when the four attacking hitters
    occupy the volatile 4..8 batting-order band and salary leaves at least 4K.
    P99 is primary inside the family; no post-lock result is consulted.
    """
    g=np.asarray(globals_,np.int32); q=np.asarray(quality,float); p99=np.asarray(p99,float)
    teams=np.asarray(meta.get('teams',[]),object); order=np.asarray(meta.get('batting_order',[]),int)
    spids=set(map(int,np.asarray(meta.get('sp_player_ids',[]),np.int32)))
    rpids=set(map(int,np.asarray(meta.get('rp_player_ids',[]),np.int32)))
    ids=[]
    for j,x in enumerate(g):
        x=int(x)
        if not bool(meta.get('lane_sp_cpt_dual_sp_attack_hedge',np.zeros(len(meta['idx']),bool))[x]): continue
        if str(meta['branch'][x])!='5-1' or int(meta['cpt_team_count'][x])!=1: continue
        if int(meta['salary'][x])>46000: continue
        cpt=int(meta['cpt'][x]); ct=teams[cpt]; attackers=[]
        for pid in map(int,np.asarray(meta['idx'][x,1:6],np.int32)):
            if pid in spids or pid in rpids: continue
            if teams[pid]!=ct: attackers.append(pid)
        if len(attackers)!=4: continue
        if not all(4<=int(order[pid])<=8 for pid in attackers): continue
        ids.append(j)
    if not ids:
        return [],{'PATCH_ID':'MLB_SD_SP_CPT_DUAL_SP_ATTACK_HEDGE_CORE5_SENTINEL_v1','TRIGGERED':False,'POSTLOCK_INPUT_USED':False}
    best=max(ids,key=lambda j:(float(p99[j]),float(q[j]),-int(g[j])))
    return [int(best)],{
        'PATCH_ID':'MLB_SD_SP_CPT_DUAL_SP_ATTACK_HEDGE_CORE5_SENTINEL_v1',
        'TRIGGERED':True,
        'ELIGIBLE_LOCAL_COUNT':int(len(ids)),
        'RESERVED_GLOBALS':[int(g[best])],
        'SELECTION_PRIMARY':'P99',
        'SALARY_MAX':46000,
        'ATTACKER_ORDER_BAND':[4,8],
        'POSTLOCK_INPUT_USED':False,
        'PLAYER_NAME_CONSTANTS_USED':False,
    }

def _mlb_sd_bargain_core5_priority(globals_,quality,cm,meta):
    """Prelock Core-5 priority for bargain CPT and distributed 5-1 underdog scripts.

    Production never consumes realized results or player-name constants.  The
    helper preserves (a) one underdog roster-unlocker 5-1 + same-team SP +
    single-RP representative and (b) a bounded underdog SP-CPT 5-1 distributed
    family with separate confidence and low-owned-runback representatives.
    """
    g=np.asarray(globals_,np.int32); q=np.asarray(quality,float)
    if not len(g):
        return None,0,{}, {'PATCH_ID':BARGAIN_CORE5_SELECTOR_PATCH_ID,'TRIGGERED':False,'POSTLOCK_INPUT_USED':False,'PLAYER_NAME_CONSTANTS_USED':False}
    idx=np.asarray(meta['idx'],np.int32); cpt=np.asarray(meta['cpt'],np.int32)[g]
    teams=np.asarray(meta['teams'],object); order=np.asarray(meta['batting_order'],int)
    sal=np.asarray(meta['player_salary'],float); own=np.asarray(meta['own'],float)
    spids=set(map(int,np.asarray(meta.get('sp_player_ids',[]),np.int32)))
    rpids=set(map(int,np.asarray(meta.get('rp_player_ids',[]),np.int32)))
    top01=np.asarray(cm['top01'],float); p99=np.asarray(cm['p99'],float)
    win=np.asarray(cm.get('win',np.zeros(len(g),float)),float)
    value_lane=np.asarray(meta.get('lane_hitter_cpt_underdog_51_sp_single_rp',np.zeros(len(meta['idx']),bool)),bool)[g]

    # Team-relative full-price threshold: the most expensive active hitter on
    # the Captain's team.  Distributed underdog SP-CPT families must avoid that
    # full-price anchor and instead combine exactly two top-3 and two 4-6 bats.
    team_max_hitter={}
    for t in sorted(set(teams.tolist())):
        ids=[i for i in range(len(teams)) if teams[i]==t and i not in spids and i not in rpids]
        team_max_hitter[t]=max((float(sal[i]) for i in ids),default=float('inf'))
    # Bargain-shopping value-CPT refinement.  When the underdog 5-1 value-CPT
    # family can avoid the same-team full-price hitter and still roster a
    # calibration-qualified reliever whose conditional P95 is near the best on
    # that team, preserve that branch separately.  This is an identity-free
    # prelock signal: it uses only salary, team, role probability and simulated
    # conditional relief tail.
    qualified_rp=set(map(int,np.asarray(meta.get('rp_qualified_player_ids',meta.get('rp_player_ids',[])),np.int32)))
    rp_cond=np.asarray(meta.get('rp_conditional_p95',np.zeros(len(meta['idx']),float)),float)[g]
    rp_role=np.asarray(meta.get('rp_role_probability',np.zeros(len(meta['idx']),float)),float)[g]
    primary_rp=np.asarray(meta.get('primary_rp_player',np.full(len(meta['idx']),-1,int)),int)[g]
    team_max_rp_cond={}
    for t in sorted(set(teams.tolist())):
        vals=[float(meta.get('player_rp_cond_p95',np.zeros(len(teams),float))[i]) for i in qualified_rp if teams[i]==t] if 'player_rp_cond_p95' in meta else []
        if not vals:
            # lineup_meta exposes the player ids plus the lineup primary-RP tail;
            # reconstruct the team maximum from candidate rows when a caller is
            # a lightweight unit-test fixture without the player-level vector.
            vals=[float(rp_cond[j]) for j,pid in enumerate(primary_rp) if pid>=0 and pid in qualified_rp and teams[pid]==t]
        team_max_rp_cond[t]=max(vals,default=0.0)
    value_cond_rp=np.zeros(len(g),bool)
    for j,x in enumerate(map(int,g)):
        if not value_lane[j]: continue
        cp=int(meta['cpt'][x]); ct=teams[cp]; pid=int(primary_rp[j])
        if pid<0 or pid not in qualified_rp or teams[pid]!=ct: continue
        if float(rp_role[j])+1e-12 < UNDERDOG_VALUE_CPT_ELITE_COND_RP_ROLE_FLOOR: continue
        mx=float(team_max_rp_cond.get(ct,0.0))
        if mx<=0 or float(rp_cond[j])+1e-12 < UNDERDOG_VALUE_CPT_ELITE_COND_RP_TAIL_RATIO*mx: continue
        # Full-price means the most expensive active same-team hitter. Include
        # CPT and UTIL hitters so the family truly spends down at Captain rather
        # than sneaking the sticker-price bat back into UTIL.
        full=False
        for slot,p in enumerate(map(int,idx[x,:6])):
            if p in spids or p in rpids or teams[p]!=ct: continue
            if float(sal[p])>=team_max_hitter.get(ct,float('inf'))-1e-12:
                full=True; break
        if not full: value_cond_rp[j]=True

    distributed=np.zeros(len(g),bool); runback_own=np.full(len(g),np.inf,float)
    for j,x in enumerate(map(int,g)):
        if not bool(meta['cpt_sp'][x]): continue
        if str(meta['branch'][x])!='5-1' or int(meta['cpt_team_count'][x])!=5: continue
        if int(meta['sp_count'][x])!=1 or int(meta['rp_count'][x])!=0: continue
        cp=int(meta['cpt'][x]); ct=teams[cp]
        # SP Captain must be on the lower-implied-total side.
        opp_runs=max((float(meta['team_runs'][i]) for i in range(len(teams)) if teams[i]!=ct),default=-np.inf)
        if not float(meta['team_runs'][cp]) < opp_runs: continue
        same=[]; opp=[]
        for pid in map(int,idx[x,1:6]):
            if pid in spids or pid in rpids: continue
            (same if teams[pid]==ct else opp).append(pid)
        if len(same)!=4 or len(opp)!=1: continue
        top3=sum(int(order[pid])<=3 for pid in same)
        mid46=sum(4<=int(order[pid])<=6 for pid in same)
        late=sum(int(order[pid])>=7 for pid in same)
        full_price=sum(float(sal[pid])>=team_max_hitter.get(ct,float('inf'))-1e-12 for pid in same)
        oo=int(order[opp[0]])
        if top3==2 and mid46==2 and late==0 and full_price==0 and 4<=oo<=6:
            distributed[j]=True; runback_own[j]=float(own[opp[0]])

    groups=[]; protection={}; details={}
    def _pick(label,mask,priority,cap=1,win_primary=False):
        ids=np.flatnonzero(mask)
        if not len(ids):
            details[label]=None; return
        if win_primary:
            # Within the structurally qualified bargain family, championship
            # probability is primary.  Top-0.1, P99, quality and id are stable
            # deterministic tie-breaks.
            ord_=np.lexsort((g[ids],-q[ids],-p99[ids],-top01[ids],-win[ids]))
        else:
            # Frozen tail confidence is authoritative; deterministic id breaks ties.
            ord_=np.lexsort((g[ids],-p99[ids],-top01[ids],-q[ids]))
        best=int(ids[int(ord_[0])])
        mm=np.zeros(len(g),bool); mm[best]=True; groups.append((label,mm,int(cap)))
        protection[int(g[best])]={'GLOBAL_CORE_FAMILY_ID':f'MLB_SD_BARGAIN_CORE5|{label}','GLOBAL_CORE_SCENARIO_ID':label,'GLOBAL_CORE_PRIORITY':int(priority),'GLOBAL_CORE_FAMILY_CAP':int(cap)}
        details[label]=int(g[best])

    if value_cond_rp.any():
        _pick('UNDERDOG_VALUE_CPT_5_1_NO_FULL_PRICE_ELITE_COND_RP',value_cond_rp,117,1,win_primary=True)
    else:
        _pick('UNDERDOG_VALUE_CPT_5_1_SINGLE_RP',value_lane,116,1)
    dids=np.flatnonzero(distributed)
    if len(dids):
        max01=max(float(np.max(top01[dids])),1e-12); max99=max(float(np.max(p99[dids])),1e-12)
        qualified=distributed & (top01>=.70*max01-1e-12) & (p99>=.95*max99-1e-12)
        _pick('UNDERDOG_SP_CPT_5_1_DISTRIBUTED_CONFIDENCE',qualified,115,1)
        qids=np.flatnonzero(qualified)
        if len(qids)>=2:
            med=float(np.median(runback_own[qids]))
            low=qualified & (runback_own < med-1e-12)
            _pick('UNDERDOG_SP_CPT_5_1_DISTRIBUTED_LOW_OWN_RUNBACK',low,114,1)
    total=min(3,sum(int(x[2]) for x in groups))
    return (groups if groups else None),total,protection,{
        'PATCH_ID':BARGAIN_CORE5_SELECTOR_PATCH_ID,
        'TRIGGERED':bool(groups),
        'PRIORITY_CORE_TOTAL_LIMIT':int(total),
        'SELECTED_GLOBALS':details,
        'DISTRIBUTED_ELIGIBLE_COUNT':int(distributed.sum()),
        'VALUE_CPT_ELIGIBLE_COUNT':int(value_lane.sum()),
        'VALUE_CPT_ELITE_COND_RP_ELIGIBLE_COUNT':int(value_cond_rp.sum()),
        'VALUE_CPT_ELITE_COND_RP_PATCH_ID':UNDERDOG_VALUE_CPT_ELITE_COND_RP_CORE5_PATCH_ID,
        'VALUE_CPT_ELITE_COND_RP_ROLE_FLOOR':UNDERDOG_VALUE_CPT_ELITE_COND_RP_ROLE_FLOOR,
        'VALUE_CPT_ELITE_COND_RP_TAIL_RATIO':UNDERDOG_VALUE_CPT_ELITE_COND_RP_TAIL_RATIO,
        'POSTLOCK_INPUT_USED':False,
        'PLAYER_NAME_CONSTANTS_USED':False,
    }

def _mlb_sd_core5_high_confidence_parlay_priority(globals_,quality,cm,meta,hedge_local=None,slate_context=None):
    """Build the high-confidence Core-5 parlay reserve for dual-SP-heavy slates.

    The five playable seats are treated as one five-leg confidence portfolio.
    Fixed structural representatives remain the baseline, but a dominant
    five-player championship family may earn a second sibling seat when frozen
    prelock MC evidence shows the sibling is at least as strong as the weakest
    replaceable leg.  This supports CPT-role uncertainty and one-piece secondary
    swaps without allowing diversity or historical perfect-lineup patterns to
    manufacture a weak leg.
    """
    patch=CORE5_HIGH_CONFIDENCE_PARLAY_PATCH_ID
    ctx=slate_context.as_dict() if hasattr(slate_context,'as_dict') else dict(slate_context or {})
    spids_all=np.asarray(meta.get('sp_player_ids',[]),np.int32)
    spown=sorted((float(x) for x in ctx.get('STARTER_OWNERSHIP_VALUES',())),reverse=True)
    spsal=np.asarray(meta.get('player_salary',[]),float)[spids_all] if len(spids_all) else np.asarray([],float)
    value_anchor_market=(
        int(ctx.get('CONFIRMED_STARTERS',0))==2 and len(spown)>=2 and len(spsal)>=2
        and spown[0]>=0.40 and spown[1]>=0.10
        and float(ctx.get('TARGET_SP_CPT_SHARE',0.0))>=0.35
        and float(np.min(spsal))<=5000.0 and float(np.max(spsal)-np.min(spsal))>=5000.0
    )
    if not (_high_dual_sp_cpt_market(slate_context) or value_anchor_market):
        return None,None,{}, {'PATCH_ID':patch,'TRIGGERED':False,'POSTLOCK_INPUT_USED':False,'PLAYER_NAME_CONSTANTS_USED':False}
    g=np.asarray(globals_,np.int32); q=np.asarray(quality,float)
    if not len(g):
        return None,None,{}, {'PATCH_ID':patch,'TRIGGERED':False,'REASON':'NO_ACTIVE_CANDIDATES','POSTLOCK_INPUT_USED':False,'PLAYER_NAME_CONSTANTS_USED':False}
    idx=np.asarray(meta['idx'],np.int32)
    order=np.asarray(meta.get('batting_order',[]),int)
    own=np.asarray(meta.get('own',[]),float)
    player_salary=np.asarray(meta.get('player_salary',np.zeros(len(own))),float)
    spids=set(map(int,np.asarray(meta.get('sp_player_ids',[]),np.int32)))
    rpids=set(map(int,np.asarray(meta.get('rp_player_ids',[]),np.int32)))
    branch=np.asarray(meta.get('branch',np.asarray(['']*len(meta['idx']),object)),object)[g]
    cptsp=np.asarray(meta.get('cpt_sp',np.zeros(len(meta['idx']),bool)),bool)[g]
    spct=np.asarray(meta.get('sp_count',np.zeros(len(meta['idx']),int)),int)[g]
    eligible=np.zeros(len(g),bool); stable=np.zeros(len(g),bool)
    min_hitter_own=np.zeros(len(g),float); hitter_own_sum=np.zeros(len(g),float); late_order_count=np.zeros(len(g),float)
    value_piece_count=np.zeros(len(g),float); salary_left=np.zeros(len(g),float)
    for j,x in enumerate(map(int,g)):
        hitters=[pid for pid in map(int,idx[x,:6]) if pid not in spids and pid not in rpids]
        if len(hitters)!=4: continue
        if not all(4<=int(order[pid])<=8 for pid in hitters): continue
        if int(spct[j])!=2: continue
        eligible[j]=True
        mo=min(float(own[pid]) for pid in hitters) if hitters else 0.0
        min_hitter_own[j]=mo
        hitter_own_sum[j]=sum(float(own[pid]) for pid in hitters)
        late_order_count[j]=sum(7<=int(order[pid])<=8 for pid in hitters)
        value_piece_count[j]=sum(float(player_salary[pid])<=5000.0 for pid in hitters)
        salary_left[j]=max(0.0,50000.0-float(meta['salary'][x]))
        # Role stability comes from the verified active batting-order slot.
        # Ownership is leverage evidence, never a hard starter-quality gate.
        stable[j]=True
    ids=np.flatnonzero(eligible)
    if not len(ids):
        return None,None,{}, {'PATCH_ID':patch,'TRIGGERED':False,'REASON':'NO_DUAL_SP_ORDER_4_8_FAMILY','POSTLOCK_INPUT_USED':False,'PLAYER_NAME_CONSTANTS_USED':False}
    score=np.zeros(len(g),float); logscore=np.zeros(len(ids),float)
    metric_weights=(('top01',.32),('win',.22),('top10',.16),('p99',.15),('p95',.15))
    for key,w in metric_weights:
        vals=np.asarray(cm[key],float)[ids]
        pr=np.clip(pct_rank(vals),1e-6,1.0)
        logscore += float(w)*np.log(pr)
    tail_geom=np.exp(logscore)
    own_leverage=np.clip(pct_rank_tie_aware(-hitter_own_sum[ids]),1e-6,1.0)
    late_order=np.clip(pct_rank_tie_aware(late_order_count[ids]),1e-6,1.0)
    score[ids]=(np.clip(tail_geom,1e-6,1.0)**.35)*(own_leverage**.20)*(late_order**.25)
    hedge=np.zeros(len(g),bool)
    for j in (hedge_local or []):
        if 0<=int(j)<len(g): hedge[int(j)]=True

    top01=np.asarray(cm['top01'],float); p99=np.asarray(cm['p99'],float)
    fixed_specs=[
        ('DUAL_SP_ATTACK_HEDGE',hedge),
        ('STABLE_SP_CPT_3_3',stable & cptsp & (branch=='3-3')),
        ('STABLE_SP_CPT_4_2',stable & cptsp & (branch=='4-2')),
        ('STABLE_BAT_CPT_3_3',stable & (~cptsp) & (branch=='3-3')),
        ('STABLE_BAT_CPT_4_2',stable & (~cptsp) & (branch=='4-2')),
    ]
    chosen=[]; used=set()
    for label,mask in fixed_specs:
        cand=np.asarray([j for j in np.flatnonzero(mask) if int(j) not in used],np.int32)
        if not len(cand): continue
        if label=='DUAL_SP_ATTACK_HEDGE':
            best=int(cand[0])
        else:
            # Frozen tail confidence has authority. Value-piece count and salary
            # release are late tie-breaks only; low spend is never a penalty.
            ord_=np.lexsort((g[cand],-salary_left[cand],-value_piece_count[cand],-q[cand],-p99[cand],-top01[cand],-score[cand]))
            best=int(cand[int(ord_[0])])
        chosen.append([label,best]); used.add(best)

    # Offline perfect-lineup research is translated only into a generic family
    # recall hypothesis. Production uses no LineStar/result rows: the helper sees
    # roster IDs plus frozen prelock confidence summaries only.
    family_pool=np.flatnonzero(stable & eligible)
    family_reps,family_receipt=perfect_family_recall.select_dominant_five_player_family(
        family_pool,
        idx[g],
        score,
        top01,
        p99,
        np.asarray(meta['cpt'],np.int32)[g],
        max_siblings=3,
        min_relative_confidence=.82,
        min_relative_p99=.92,
        min_relative_top01=.60,
    )
    family_applied=[]
    if len(family_reps)>=2 and chosen:
        family_set=set(map(int,family_reps))
        current_family=sum(int(j in family_set) for _,j in chosen)
        target_family=min(3,len(family_set))
        # Admit additional siblings only by replacing an equal-or-weaker
        # non-hedge leg. This keeps family recall subordinate to parlay strength.
        for fam_j in family_reps:
            fam_j=int(fam_j)
            if current_family>=target_family: break
            if any(j==fam_j for _,j in chosen):
                continue
            replaceable=[k for k,(label,j) in enumerate(chosen) if label!='DUAL_SP_ATTACK_HEDGE' and int(j) not in family_set]
            if not replaceable: break
            weak=min(replaceable,key=lambda k:(float(score[chosen[k][1]]),float(top01[chosen[k][1]]),float(p99[chosen[k][1]]),k))
            weak_j=int(chosen[weak][1])
            if float(score[fam_j])+1e-12 < float(score[weak_j]):
                continue
            old_label=chosen[weak][0]
            chosen[weak]=['PERFECT_FAMILY_SIBLING',fam_j]
            family_applied.append({'ADMITTED_LOCAL':fam_j,'DISPLACED_LOCAL':weak_j,'DISPLACED_SCENARIO':old_label})
            current_family+=1

    # If a family representative was already one of the fixed structural legs,
    # annotate it without altering its strength/role semantics.
    family_set=set(map(int,family_reps))
    if len(family_set)>=2:
        seen=0
        for row in chosen:
            if int(row[1]) in family_set:
                seen+=1
                if row[0] != 'PERFECT_FAMILY_SIBLING': row[0]=f"{row[0]}|PERFECT_FAMILY_{'ANCHOR' if seen==1 else 'SIBLING'}"

    # Hard Top-5 contract: family recall may not create a short board. Fill any
    # missing structural seat from the strongest unused stable dual-SP candidate.
    if len(chosen)<5:
        fill=np.asarray([j for j in ids if stable[j] and int(j) not in {x[1] for x in chosen}],np.int32)
        if len(fill):
            order_fill=np.lexsort((g[fill],-q[fill],-p99[fill],-top01[fill],-score[fill]))
            for j in fill[order_fill]:
                chosen.append(['STABLE_CONFIDENCE_FILL',int(j)])
                if len(chosen)>=5: break
    chosen=chosen[:5]

    groups=[]; protection={}; reps={}
    for label,best in chosen:
        one=np.zeros(len(g),bool); one[int(best)]=True; glob=int(g[int(best)]); reps[label]=glob
        is_family=('PERFECT_FAMILY_' in label)
        protection[str(glob)]={
            'GLOBAL_CORE_FAMILY_ID':('MLB_SD_HIGH_CONFIDENCE_PARLAY|PERFECT_FAMILY' if is_family else f'MLB_SD_HIGH_CONFIDENCE_PARLAY|{label}'),
            'GLOBAL_CORE_SCENARIO_ID':label,
            'GLOBAL_CORE_PRIORITY':112 if is_family else 110,
            'GLOBAL_CORE_FAMILY_CAP':3 if is_family else 1,
            'PARLAY_CONFIDENCE_SCORE':float(score[int(best)]),
            'MIN_HITTER_OWNERSHIP_PCT':float(min_hitter_own[int(best)]),
            'VALUE_HITTER_COUNT_LE_5000':int(value_piece_count[int(best)]),
            'SALARY_LEFT':float(salary_left[int(best)]),
        }
        groups.append((label,one,1))
    return groups,5,protection,{
        'PATCH_ID':patch,
        'TRIGGERED':True,
        'OBJECTIVE':'HIGH_CONFIDENCE_FIVE_LEG_CHAMPIONSHIP_PARLAY',
        'REPRESENTATIVES':reps,
        'TRIGGER_HIGH_HIGH_MARKET':bool(_high_dual_sp_cpt_market(slate_context)),
        'TRIGGER_VALUE_ANCHOR_MARKET':bool(value_anchor_market),
        'STABLE_ROLE_AUTHORITY':'VERIFIED_ACTIVE_BATTING_ORDER_4_8',
        'STABLE_ROLE_MIN_HITTER_OWNERSHIP_PCT':None,
        'OWNERSHIP_HARD_FLOOR_USED':False,
        'ATTACKER_ORDER_BAND':[4,8],
        'LATE_ORDER_LEVERAGE_BAND':[7,8],
        'DUAL_SP_REQUIRED':True,
        'MULTIPLICATIVE_CONFIDENCE_WEIGHTS':dict(metric_weights),
        'PARLAY_STRUCTURAL_WEIGHTS':{'TAIL_GEOMETRIC':0.35,'LOW_AGGREGATE_OWNERSHIP_LEVERAGE':0.20,'LATE_ORDER_ATTACK':0.25},
        'PERFECT_FAMILY_SIBLING_RECALL':family_receipt,
        'PERFECT_FAMILY_APPLIED_REPLACEMENTS':family_applied,
        'PERFECT_FAMILY_MAX_CORE5_SEATS':3,
        'PERFECT_FAMILY_REPLACEMENT_REQUIRES_NONDECREASING_CONFIDENCE':True,
        'VALUE_PIECE_SALARY_MAX':5000,
        'VALUE_PIECE_USAGE':'TIEBREAK_ONLY',
        'SALARY_RELEASE_PENALTY_USED':False,
        'HISTORICAL_PERFECT_LINEUP_DATA_USED_IN_PRODUCTION':False,
        'POSTLOCK_INPUT_USED':False,
        'PLAYER_NAME_CONSTANTS_USED':False,
    }



def _cross_branch_superanchor_family_core5_priority(globals_,quality,cm,meta):
    """Reserve one blind cross-branch family champion for Core-5.

    The family must be born by the cross-branch five-player closure, contain one
    public superanchor (>=50% frozen ownership) and at least four sub-10% core
    pieces, and exhibit real sibling breadth.  Family breadth is primary;
    aggregate Top-0.1 and win mass are tie-breaks.  The family representative is
    the member with the strongest fully simulated win rate, then Top-0.1/P99.
    No player names, realized results, or post-lock fields are consumed.
    """
    g=np.asarray(globals_,np.int32); q=np.asarray(quality,float)
    if not len(g):
        return None,0,{}, {'PATCH_ID':CROSS_BRANCH_SUPERANCHOR_CORE5_PATCH_ID,'TRIGGERED':False,'REASON':'NO_CANDIDATES','POSTLOCK_INPUT_USED':False,'PLAYER_NAME_CONSTANTS_USED':False}
    lane_all=np.asarray(meta.get('lane_cross_branch_five_player_championship_family',np.zeros(len(meta['idx']),bool)),bool)
    local=np.flatnonzero(lane_all[g])
    if len(local)<3:
        return None,0,{}, {'PATCH_ID':CROSS_BRANCH_SUPERANCHOR_CORE5_PATCH_ID,'TRIGGERED':False,'REASON':'INSUFFICIENT_CROSS_BRANCH_LANE','POSTLOCK_INPUT_USED':False,'PLAYER_NAME_CONSTANTS_USED':False}
    rosters=np.asarray(meta['idx'],np.int32); own=np.asarray(meta['own'],float)
    families=defaultdict(set)
    for j in map(int,local):
        roster=tuple(sorted(map(int,rosters[int(g[j]),:6])))
        for drop in range(6):
            families[roster[:drop]+roster[drop+1:]].add(j)
    top01=np.asarray(cm['top01'],float); win=np.asarray(cm['win'],float); p99=np.asarray(cm['p99'],float)
    eligible=[]
    for core,members0 in families.items():
        members=sorted(set(map(int,members0)))
        if len(members)<3: continue
        core_own=own[np.asarray(core,np.int32)]
        if int((core_own>=50.0).sum())!=1: continue
        if int((core_own<10.0).sum())<4: continue
        mass01=float(sum(top01[j] for j in members)); masswin=float(sum(win[j] for j in members))
        bestp99=float(max(p99[j] for j in members))
        eligible.append((len(members),mass01,masswin,bestp99,core,members))
    if not eligible:
        return None,0,{}, {'PATCH_ID':CROSS_BRANCH_SUPERANCHOR_CORE5_PATCH_ID,'TRIGGERED':False,'REASON':'NO_SUPERANCHOR_LOW_OWN_FAMILY','POSTLOCK_INPUT_USED':False,'PLAYER_NAME_CONSTANTS_USED':False}
    eligible.sort(key=lambda z:(-z[0],-z[1],-z[2],-z[3],z[4]))
    breadth,mass01,masswin,bestp99,core,members=eligible[0]
    best=max(members,key=lambda j:(float(win[j]),float(top01[j]),float(p99[j]),float(q[j]),-int(g[j])))
    mask=np.zeros(len(g),bool); mask[int(best)]=True; glob=int(g[int(best)])
    protection={glob:{
        'GLOBAL_CORE_FAMILY_ID':'MLB_SD_CROSS_BRANCH_SUPERANCHOR_LOW_OWN_FAMILY',
        'GLOBAL_CORE_SCENARIO_ID':'CROSS_BRANCH_SUPERANCHOR_LOW_OWN_FAMILY_CHAMPION',
        'GLOBAL_CORE_PRIORITY':116,
        'GLOBAL_CORE_FAMILY_CAP':1,
        'FAMILY_BREADTH':int(breadth),
        'FAMILY_TOP01_MASS':float(mass01),
        'FAMILY_WIN_MASS':float(masswin),
    }}
    return [('CROSS_BRANCH_SUPERANCHOR_LOW_OWN_FAMILY_CHAMPION',mask,1)],1,protection,{
        'PATCH_ID':CROSS_BRANCH_SUPERANCHOR_CORE5_PATCH_ID,
        'TRIGGERED':True,
        'SELECTED_GLOBAL':glob,
        'CORE_PLAYER_IDS':[int(x) for x in core],
        'FAMILY_BREADTH':int(breadth),
        'FAMILY_TOP01_MASS':float(mass01),
        'FAMILY_WIN_MASS':float(masswin),
        'FAMILY_BEST_P99':float(bestp99),
        'SUPERANCHOR_OWNERSHIP_FLOOR':50.0,
        'LOW_OWNERSHIP_CEILING':10.0,
        'LOW_OWN_CORE_PIECES_REQUIRED':4,
        'CHAMPION_ORDER':'MC_WIN_RATE > MC_TOP_0_1_RATE > MC_P99 > QUALITY',
        'POSTLOCK_INPUT_USED':False,
        'PLAYER_NAME_CONSTANTS_USED':False,
    }

def _production_championship_core_select(cands,cm,meta,size,p1,lineups,championship_threshold,advisor_score,slate_context=None):
    """Global Core-5 + non-disruptive satellites using exact win boundaries.

    All candidates are selector-reviewed. Sparse first-window event activation is
    only a memory optimization; a full-run prelock-qualified high-confidence
    parlay singleton is forced into final review even when that first window has
    zero wins. Exact event coverage remains truthful and is never synthesized.
    """
    from types import SimpleNamespace
    cands=np.asarray(cands,np.int32)
    if p1 is None or lineups is None or championship_threshold is None:
        raise RuntimeError('RUN_INVALID:CHAMPIONSHIP_CORE_REQUIRES_FROZEN_COMMON_WORLD_TAPE')
    T=min(5000,int(p1.shape[0]),int(len(championship_threshold)))
    if T<500: raise RuntimeError('RUN_INVALID:CHAMPIONSHIP_CORE_INSUFFICIENT_COMMON_WORLD_TRIALS')
    _cpt_unlock=np.asarray(meta.get('cpt_roster_unlock',np.zeros(len(meta['idx']),bool)),bool)[cands]
    _cpt_break=np.asarray(meta.get('cpt_slate_breaker',np.zeros(len(meta['idx']),bool)),bool)[cands]
    _cpt_role_prior=np.where(_cpt_break,1.0,np.where(_cpt_unlock,.80,0.0))
    quality=(.33*pct_rank(np.asarray(cm['top01'],float))+
             .20*pct_rank(np.asarray(cm['win'],float))+
             .10*pct_rank(np.asarray(cm['top10'],float))+
             .18*pct_rank(np.asarray(cm['p99'],float))+
             .08*pct_rank(np.asarray(cm['p95'],float))+
             .03*pct_rank(np.asarray(cm['mean'],float))+
             .04*pct_rank(np.asarray(advisor_score,float))+
             .04*_cpt_role_prior)

    # High-confidence parlay qualification is computed from the FULL
    # selector-reviewed set and full-run prelock summaries before sparse common-
    # world activation. This prevents a first-window zero from dropping a strong
    # parlay leg while preserving truthful zero event coverage for that window.
    _full_hedge_local,_full_hedge_receipt=_sp_cpt_dual_sp_attack_hedge_priority(
        cands,quality,np.asarray(cm['p99'],float),meta)
    _legacy_groups,_legacy_total,_legacy_protection,_portfolio_grid_receipt=_mlb_sd_core5_high_confidence_parlay_priority(
        cands,quality,cm,meta,hedge_local=_full_hedge_local,slate_context=slate_context)
    _bargain_groups,_bargain_total,_bargain_protection,_bargain_core_receipt=_mlb_sd_bargain_core5_priority(cands,quality,cm,meta)
    _cross_groups,_cross_total,_cross_protection,_cross_core_receipt=_cross_branch_superanchor_family_core5_priority(cands,quality,cm,meta)
    _full_priority_groups=[]
    if _bargain_groups is not None: _full_priority_groups.extend(_bargain_groups)
    if _legacy_groups is not None: _full_priority_groups.extend(_legacy_groups)
    if _cross_groups is not None: _full_priority_groups.extend(_cross_groups)
    if not _full_priority_groups: _full_priority_groups=None
    _priority_total=min(5,int(_bargain_total or 0)+int(_legacy_total or 0)+int(_cross_total or 0))
    _parlay_protection={}
    _parlay_protection.update(_legacy_protection or {})
    _parlay_protection.update(_bargain_protection or {})
    _parlay_protection.update(_cross_protection or {})

    th=np.asarray(championship_threshold[:T],np.float32)
    active_local=[]; event_parts=[]; chunk=750
    for st in range(0,len(cands),chunk):
        en=min(len(cands),st+chunk)
        v=_direct_six_slot_scores(p1,lineups,cands[st:en],0,T)
        ev=v>=th[None,:]
        keep=np.flatnonzero(np.any(ev,axis=1))
        if len(keep):
            active_local.extend((st+keep).tolist())
            event_parts.append(ev[keep].astype(bool,copy=False))
    active_local=np.asarray(active_local,np.int32)
    if len(active_local): events=np.concatenate(event_parts,axis=0)
    else: events=np.zeros((0,T),bool)

    # Full-run prequalified singleton parlay legs must reach final review even if
    # they have zero wins in the sparse first window. Their exact row is computed;
    # no synthetic event is inserted.
    if _full_priority_groups is not None:
        required=[]
        for _label,_mask,_limit in _full_priority_groups:
            required.extend(map(int,np.flatnonzero(np.asarray(_mask,bool))))
        required=sorted(set(required)); present=set(map(int,active_local.tolist()))
        missing=[j for j in required if j not in present]
        if missing:
            mg=np.asarray(missing,np.int32)
            mv=_direct_six_slot_scores(p1,lineups,cands[mg],0,T)
            mev=mv>=th[None,:]
            active_local=np.r_[active_local,mg]
            events=np.vstack([events,mev.astype(bool,copy=False)])

    core_n=min(5,int(size),len(cands))
    if len(active_local)<core_n:
        present=set(map(int,active_local.tolist())); add=[]
        for j in np.argsort(-quality,kind='mergesort'):
            j=int(j)
            if j in present: continue
            add.append(j); present.add(j)
            if len(active_local)+len(add)>=core_n: break
        if add:
            active_local=np.r_[active_local,np.asarray(add,np.int32)]
            events=np.vstack([events,np.zeros((len(add),T),bool)])

    active_globals=cands[active_local]
    families=_mlb_championship_family_labels(active_globals,meta)
    _frontier=np.asarray(meta.get('high_high_42_uncertainty_frontier_sentinel',np.zeros(len(meta['idx']),dtype=bool)),dtype=bool)[active_globals]
    _tier_local,_tier_receipt=_sp_cpt_control_51_runback_tier_priority(active_globals,quality[active_local],advisor_score[active_local],meta,slate_context)
    if _tier_local: _frontier[np.asarray(_tier_local,np.int32)]=True
    _hedge_local,_hedge_receipt=_sp_cpt_dual_sp_attack_hedge_priority(active_globals,quality[active_local],np.asarray(cm['p99'],float)[active_local],meta)
    if _hedge_local: _frontier[np.asarray(_hedge_local,np.int32)]=True

    # Convert the already-ranked full-candidate singleton groups into active-row
    # coordinates without reranking them on sparse activation order.
    _priority_groups=None
    if _full_priority_groups is not None:
        _active_pos={int(gv):j for j,gv in enumerate(map(int,active_globals))}
        _priority_groups=[]
        for _label,_full_mask,_limit in _full_priority_groups:
            _am=np.zeros(len(active_globals),bool)
            for _cj in np.flatnonzero(np.asarray(_full_mask,bool)):
                _gv=int(cands[int(_cj)])
                if _gv in _active_pos: _am[_active_pos[_gv]]=True
            _priority_groups.append((_label,_am,int(_limit)))

    fallback_priority_limit=max(
        (2 if _high_dual_sp_cpt_market(slate_context) else (min(3,len(_tier_local)) if _tier_local else 0)),
        (1 if _hedge_local else 0))
    result=championship_core_mod.select_championship_core(
        events=events,
        quality=quality[active_local],
        candidate_ids=active_globals,
        family_labels=families,
        core_size=core_n,
        max_board_size=min(int(size),len(active_local)),
        min_satellite_gain_events=1,
        priority_satellite_mask=_frontier,
        priority_core_mask=_frontier,
        priority_core_limit=(0 if _priority_groups is not None else fallback_priority_limit),
        priority_core_groups=_priority_groups,
        priority_core_total_limit=_priority_total,
        priority_core_min_gain_events=(0 if _priority_groups is not None else 1),
    )
    chosen_active=np.asarray(result.selected_local,np.int32)
    chosen_cand_local=active_local[chosen_active]
    selected=cands[chosen_cand_local]
    receipt=dict(result.receipt)
    receipt.update({
        'MODE':'GLOBAL_CORE5_MLB_SHOWDOWN',
        'FULL_SELECTOR_REVIEWED':int(len(cands)),
        'CHAMPIONSHIP_EVENT_ACTIVE_CANDIDATES':int(len(active_local)),
        'COMMON_WORLD_TRIALS':int(T),
        'CHAMPIONSHIP_BOUNDARY':'OPPONENT_FIELD_MAX_M_t',
        'PORTFOLIO_TOP01_UNION_COVERAGE':float(receipt.get('FINAL_UNION_COVERAGE',0.0)),
        'SPORT_FAMILY_SCHEMA':'MLB_SD_BRANCH+CPT_ROLE+CPT_TEAM+SP_SIGNATURE+CPT_SIDE_COUNT',
        'POSTLOCK_RESULTS_USED':False,
        'RAW_AGGREGATE_PROJECTIONS_USED':False,
        'SELECTOR_RECOMPUTATION':'PROHIBITED',
        'MC_PRIMARY_AUTHORITY':True,
        'SP_CPT_CONTROL_5_1_RUNBACK_TIER_PRIORITY':_tier_receipt,
        'SP_CPT_DUAL_SP_ATTACK_HEDGE_PRIORITY':_hedge_receipt,
        'CORE5_HIGH_CONFIDENCE_PARLAY':_portfolio_grid_receipt,
        'BARGAIN_CORE5_SELECTOR':_bargain_core_receipt,
        'CROSS_BRANCH_SUPERANCHOR_CORE5':_cross_core_receipt,
        'GLOBAL_CORE_PROTECTION_BY_GLOBAL':_parlay_protection,
        'FULL_RUN_PREQUALIFIED_ZERO_SPARSE_GAIN_PATCH_ID':CORE5_FULL_RUN_PRIORITY_ZERO_GAIN_PATCH_ID,
    })
    if _parlay_protection:
        selected_set=set(map(int,selected.tolist()))
        receipt['GLOBAL_CORE_PROTECTED_GLOBALS']=[int(g) for g in map(int,_parlay_protection.keys()) if int(g) in selected_set]
        receipt['GLOBAL_CORE_FAMILY_ID']='MLB_SD_NATIVE_PRIORITY_CORE'
        receipt['GLOBAL_CORE_PRIORITY']=max((int(v.get('GLOBAL_CORE_PRIORITY',0)) for v in _parlay_protection.values()),default=110)
        receipt['GLOBAL_CORE_FAMILY_CAP']=max((int(v.get('GLOBAL_CORE_FAMILY_CAP',1)) for v in _parlay_protection.values()),default=1)
    res=SimpleNamespace(success=True,status=0,message='GLOBAL_CHAMPIONSHIP_CORE5_PLUS_POSITIVE_SATELLITES',x=np.ones(len(selected),dtype=float))
    return selected,quality[chosen_cand_local],res,receipt


def _production_portfolio_union_select(cands,cm,meta,size,p1,lineups,top01_threshold,advisor_score,slate_context=None):
    """Select a normal-market Showdown board for joint common-world coverage.

    Uses only frozen prelock MC worlds.  The objective is incremental union
    coverage of the simulated Top-0.1 threshold, with bounded player/CPT/branch
    concentration.  No postlock result or realized score can enter this path.
    """
    from types import SimpleNamespace
    cands=np.asarray(cands,np.int32)
    if p1 is None or lineups is None or top01_threshold is None:
        raise RuntimeError('RUN_INVALID:PORTFOLIO_UNION_REQUIRES_FROZEN_COMMON_WORLD_TAPE')
    T=min(5000,int(p1.shape[0]),int(len(top01_threshold)))
    if T<500: raise RuntimeError('RUN_INVALID:PORTFOLIO_UNION_INSUFFICIENT_COMMON_WORLD_TRIALS')
    _cpt_unlock=np.asarray(meta.get('cpt_roster_unlock',np.zeros(len(meta['idx']),bool)),bool)[cands]
    _cpt_break=np.asarray(meta.get('cpt_slate_breaker',np.zeros(len(meta['idx']),bool)),bool)[cands]
    _cpt_role_prior=np.where(_cpt_break,1.0,np.where(_cpt_unlock,.80,0.0))
    quality=(.37*pct_rank(np.asarray(cm['top01'],float))+
             .20*pct_rank(np.asarray(cm['win'],float))+
             .12*pct_rank(np.asarray(cm['top10'],float))+
             .16*pct_rank(np.asarray(cm['p99'],float))+
             .07*pct_rank(np.asarray(cm['p95'],float))+
             .04*pct_rank(np.asarray(cm['mean'],float))+
             .04*_cpt_role_prior)
    tier_local,tier_receipt=_sp_cpt_control_51_runback_tier_priority(cands,quality,advisor_score,meta,slate_context)
    base_front=np.argsort(-quality,kind='mergesort')[:min(len(cands),max(400,min(1200,size*120)))].astype(np.int32)
    frontier=np.asarray(list(dict.fromkeys(list(map(int,tier_local))+list(map(int,base_front)))),np.int32)
    frontier_n=len(frontier)
    fg=cands[frontier]
    v=_direct_six_slot_scores(p1,lineups,fg,0,T)
    events=v>=np.asarray(top01_threshold[:T],np.float32)[None,:]
    covered=np.zeros(T,bool); selected_local=[]
    player_exp=Counter(); cpt_exp=Counter(); branch_exp=Counter()
    player_cap=max(1,int(math.ceil(size*.80))); cpt_cap=max(1,int(math.ceil(size*.40))); branch_cap=max(1,int(math.ceil(size*.60)))
    def feasible(fi):
        g=int(fg[fi]); roster=np.asarray(meta['idx'][g],np.int32); cpt=int(meta['cpt'][g]); branch=str(meta['branch'][g])
        if cpt_exp[cpt]>=cpt_cap or branch_exp[branch]>=branch_cap: return False
        return all(player_exp[int(pid)]<player_cap for pid in np.unique(roster))
    def admit(fi):
        selected_local.append(int(fi)); covered[:] = covered | events[int(fi)]
        g=int(fg[int(fi)]); roster=np.asarray(meta['idx'][g],np.int32)
        cpt_exp[int(meta['cpt'][g])]+=1; branch_exp[str(meta['branch'][g])]+=1
        for pid in np.unique(roster): player_exp[int(pid)]+=1
    # Structural uncertainty sentinels get first claim on native-board seats.
    # This is prelock and bounded to TOP/MID/BOT runback tiers (max 3).
    for fi in range(min(len(tier_local),size)):
        if feasible(fi): admit(fi)
    while len(selected_local)<size:
        best=None; best_obj=-1e99
        for fi in range(frontier_n):
            if fi in selected_local or not feasible(fi): continue
            inc=int(np.count_nonzero(events[fi] & ~covered))
            # Coverage has authority; frozen individual quality breaks ties.
            obj=inc/T + .010*float(quality[frontier[fi]]) + 1e-7*float(advisor_score[frontier[fi]])
            if obj>best_obj: best_obj=obj; best=fi
        if best is None: break
        admit(best)
    # Fail-soft fill from the same frozen frontier if concentration caps leave a
    # short board; never introduce unreviewed rows or postlock information.
    if len(selected_local)<size:
        for fi in np.argsort(-quality[frontier],kind='mergesort'):
            fi=int(fi)
            if fi in selected_local: continue
            selected_local.append(fi)
            if len(selected_local)>=size: break
    if len(selected_local)<size: raise RuntimeError(f'RUN_FAIL:PORTFOLIO_UNION_SHORT_BOARD:{len(selected_local)}:{size}')
    chosen_front=np.asarray(selected_local[:size],np.int32)
    chosen_cand_local=frontier[chosen_front]
    selected=cands[chosen_cand_local]
    receipt={
        'PATCH_ID':PORTFOLIO_UNION_SELECTOR_PATCH_ID,'MODE':'PRODUCTION_NORMAL_MARKET',
        'FULL_SELECTOR_REVIEWED':int(len(cands)),'ELITE_FRONTIER_REVIEWED':int(frontier_n),'PROTECTED_GROUP_COUNT':0,
        'COMMON_WORLD_TRIALS':int(T),'PORTFOLIO_TOP01_UNION_COVERAGE':float(covered.mean()),
        'PLAYER_EXPOSURE_CAP':int(player_cap),'CPT_EXPOSURE_CAP':int(cpt_cap),'BRANCH_EXPOSURE_CAP':int(branch_cap),
        'POSTLOCK_RESULTS_USED':False,'RAW_AGGREGATE_PROJECTIONS_USED':False,
        'SELECTOR_RECOMPUTATION':'PROHIBITED','MC_PRIMARY_AUTHORITY':True,
        'WEIGHTED_METRIC_SUM_USED':False,'HARD_FAMILY_QUOTAS_USED':False,'HARD_PAIR_QUOTAS_USED':False,
        'SP_CPT_CONTROL_5_1_RUNBACK_TIER_PRIORITY':tier_receipt,
        'GLOBAL_CORE_PROTECTED_GLOBALS':[int(cands[j]) for j in tier_local if int(cands[j]) in set(map(int,selected.tolist()))],
        'GLOBAL_CORE_FAMILY_ID':'MLB_SD_NORMAL_SP_CPT_5_1_RUNBACK_TIERS','GLOBAL_CORE_PRIORITY':98,'GLOBAL_CORE_FAMILY_CAP':3,
    }
    res=SimpleNamespace(success=True,status=0,message='PORTFOLIO_UNION_COMMON_WORLD_OPTIMAL_GREEDY',x=np.ones(size,dtype=float))
    return selected,quality[chosen_cand_local],res,receipt


def select_milp(cands,cm,meta,size=10,slate_context=None,p1=None,lineups=None,top01_threshold=None,championship_threshold=None):
    """Hybrid Top-0.1 selector with asymmetric dual-SP CPT recovery.

    Normal markets retain the advisor-led ranked stream. In two-starter markets
    where blind field geometry is both dual-SP/SP-CPT heavy and starter ownership
    differs by at least 30 percentage points, use the v1.32.20 blind-validated
    elite-tail portfolio as the primary selector and reserve four diverse
    lower-owned-SP CPT dual-SP representatives ranked by the current advisor.
    """
    from types import SimpleNamespace
    if not isinstance(slate_context,FrozenSlateContext): raise TypeError('SELECTOR_REQUIRES_FROZEN_SLATE_CONTEXT')
    cands=np.asarray(cands,np.int32)
    advisor_components=contest_finish_components(cands,cm,meta,trials=BASE_TRIALS+EXTRA_TRIALS,field_size=FIELD_SIZE,slate_games=1)
    advisor_score=np.asarray(advisor_components['score'],float)+.07*pct_rank(np.asarray(meta.get('lineup_market_tt',np.zeros(len(meta['idx']))),float)[cands])+.04*pct_rank(np.asarray(meta.get('tt_leverage',np.zeros(len(meta['idx']))),float)[cands])-np.asarray(meta.get('self_conflict_penalty',np.zeros(len(meta['idx']))),float)[cands]+np.asarray(meta.get('side_commitment_bonus',np.zeros(len(meta['idx']))),float)[cands]

    # Production board architecture: freeze Core-5 on the exact frozen common-world
    # championship boundary M_t, then admit only satellites with positive marginal
    # championship coverage.  Legacy market selectors below remain compatibility
    # paths for callers that do not provide the frozen winner boundary tape.
    if p1 is not None and lineups is not None and championship_threshold is not None:
        selected,selected_scores,res,receipt=_production_championship_core_select(
            cands,cm,meta,size,p1,lineups,championship_threshold,advisor_score,slate_context)
        receipt['FROZEN_SLATE_CONTEXT']=slate_context.as_dict()
        receipt['FROZEN_SLATE_CONTEXT_SHA256']=slate_context.sha256
        receipt['FIELD_SLATE_CONTEXT']=advisor_components.get('context',{})
        receipt['CUMULATIVE_PROMOTION_PATCH_ID']=CHAMPIONSHIP_CORE_CAPTAIN_PROMOTION_PATCH_ID
        return selected,selected_scores,res,receipt

    # High/high 4-2 uncertainty authorities are defined by the fixed pilot
    # in Phase 2.  Deep common-world championship events validate that each
    # protected row still covers at least one Rank-1 state before native lock.
    _hhmask=np.asarray(meta.get('high_high_42_uncertainty_frontier_sentinel',np.zeros(len(meta['idx']),dtype=bool)),dtype=bool)
    _hh42_local=[int(j) for j,g in enumerate(cands) if _high_dual_sp_cpt_market(slate_context) and bool(_hhmask[int(g)])]
    _hh42_event_counts={}
    if _hh42_local and p1 is not None and lineups is not None and championship_threshold is not None:
        _T=min(5000,int(p1.shape[0]),int(len(championship_threshold)))
        _vals=_direct_six_slot_scores(p1,lineups,cands[np.asarray(_hh42_local,np.int32)],0,_T)
        _ec=np.sum(_vals>=np.asarray(championship_threshold[:_T],np.float32)[None,:],axis=1).astype(np.int32)
        _hh42_event_counts={int(cands[_hh42_local[k]]):int(_ec[k]) for k in range(len(_hh42_local))}
        _hh42_local=[j for j in _hh42_local if _hh42_event_counts.get(int(cands[j]),0)>0]
    _hh42_globals=[int(cands[j]) for j in _hh42_local][:2]
    _hh42_local=[int(np.where(cands==g)[0][0]) for g in _hh42_globals]

    if not _high_dual_sp_cpt_market(slate_context):
        if p1 is not None and lineups is not None and top01_threshold is not None:
            selected,selected_scores,res,receipt=_production_portfolio_union_select(
                cands,cm,meta,size,p1,lineups,top01_threshold,advisor_score,slate_context)
            receipt['FROZEN_SLATE_CONTEXT']=slate_context.as_dict()
            receipt['FROZEN_SLATE_CONTEXT_SHA256']=slate_context.sha256
            receipt['FIELD_SLATE_CONTEXT']=advisor_components.get('context',{})
            return selected,selected_scores,res,receipt
        # Compatibility-only fallback for unit/static callers without the frozen
        # common-world tape. Live production always supplies p1/lineups/threshold.
        from types import SimpleNamespace
        order=_premium_signature_near_tie_order(cands,advisor_score,meta)
        cliff_triggered=_dual_sp_threshold_cliff_market(slate_context)
        cliff_lane=_low_owned_sp_cpt_lane(cands,advisor_score,meta,n=min(2,size),max_overlap=4,slate_context=slate_context) if cliff_triggered else []
        chosen_local=list(map(int,cliff_lane))
        for j in order:
            if int(j) not in chosen_local: chosen_local.append(int(j))
            if len(chosen_local)>=size: break
        chosen_local=np.asarray(chosen_local[:size],np.int32); selected=cands[chosen_local]
        receipt={'PATCH_ID':PORTFOLIO_UNION_SELECTOR_PATCH_ID,'MODE':'COMPATIBILITY_NO_TAPE_FALLBACK',
                 'FULL_SELECTOR_REVIEWED':int(len(cands)),'MC_PRIMARY_AUTHORITY':False,
                 'WEIGHTED_METRIC_SUM_USED':False,'HARD_FAMILY_QUOTAS_USED':False,'HARD_PAIR_QUOTAS_USED':False,
                 'ASYMMETRIC_LOW_SP_CPT_LANE_LOCKS':[int(cands[x]) for x in cliff_lane],
                 'DUAL_SP_THRESHOLD_CLIFF_GUARD':{'PATCH_ID':'MLB_SD_DUAL_SP_THRESHOLD_CLIFF_AND_FAMILY_EXTINCTION_GUARD_v1','TRIGGERED':bool(cliff_triggered),'LOWER_OWNED_SP_CPT_DUAL_SP_PROTECTED_GLOBALS':[int(cands[x]) for x in cliff_lane]},
                 'POSTLOCK_RESULTS_USED':False,'SELECTOR_RECOMPUTATION':'PROHIBITED',
                 'FROZEN_SLATE_CONTEXT':slate_context.as_dict(),'FROZEN_SLATE_CONTEXT_SHA256':slate_context.sha256,
                 'FIELD_SLATE_CONTEXT':advisor_components.get('context',{})}
        res=SimpleNamespace(success=True,status=0,message='COMPATIBILITY_NO_TAPE_FALLBACK',x=np.ones(len(selected),dtype=float))
        return selected,advisor_score[chosen_local],res,receipt

    score=_legacy_elite_tail_score(cands,cm,meta)
    rank1=int(np.argmax(score)); own=np.asarray(meta['own'],float)/100.0
    ranked=np.argsort(-score,kind='mergesort'); pool_n=min(len(cands),max(2500,size*250)); pool_full=np.asarray(ranked[:pool_n],np.int32)
    if rank1 not in set(map(int,pool_full)): pool_full=np.r_[pool_full,rank1]
    pcands=cands[pool_full]; pscore=score[pool_full]
    c1=_portfolio_constraints(pcands,pscore,meta,size,own,locks=[int(cands[rank1])])
    r1=milp(-pscore,integrality=np.ones(len(pcands)),bounds=Bounds(0,1),constraints=c1,options={'time_limit':15})
    if not r1.success: raise RuntimeError('MILP_STAGE1_FAIL:'+str(r1.message))
    baseline_full=pool_full[np.where(r1.x>.5)[0]]; baseline_full=baseline_full[np.argsort(-score[baseline_full],kind='mergesort')]

    seeds=[]; groups=[]; seed_order=_market_geometry_seed_locals(cands,score,meta,max_seeds=2,slate_context=slate_context)+_choose_protection_seeds(baseline_full,cands,meta,max_seeds=2,slate_context=slate_context)
    for seed in seed_order:
        if int(seed) in seeds: continue
        sib=credible_one_swap_siblings(seed,cands,score,cm,meta)
        if not sib: continue
        seeds.append(int(seed)); groups.append(sib)
        if len(seeds)>=2: break
    requirements=[1]*len(groups)
    lane=_low_owned_sp_cpt_lane(cands,advisor_score,meta,n=min(4,size),max_overlap=4,slate_context=slate_context)
    if not lane:
        budget=3-sum(requirements); overlaps=[]
        for gi,grp in enumerate(groups):
            if len(grp)<2 or budget<=0: continue
            by_top=sorted(grp,key=lambda j:(-float(cm['top01'][j]),-float(cm['p99'][j]),j))
            a,b=by_top[:2]; na=float(cm.get('trials',np.full(len(cands),BASE_TRIALS+EXTRA_TRIALS))[a]); nb=float(cm.get('trials',np.full(len(cands),BASE_TRIALS+EXTRA_TRIALS))[b])
            al=float(wilson_lcb([cm['top01'][a]],[na],z=1.0)[0]); au=float(wilson_ucb([cm['top01'][a]],[na],z=1.0)[0]); bl=float(wilson_lcb([cm['top01'][b]],[nb],z=1.0)[0]); bu=float(wilson_ucb([cm['top01'][b]],[nb],z=1.0)[0])
            overlaps.append((max(0.0,min(au,bu)-max(al,bl)),gi))
        for ov,gi in sorted(overlaps,reverse=True):
            if budget<=0 or ov<=0: continue
            requirements[gi]+=1; budget-=1
    reciprocal=_legacy_market_reciprocal_candidates(cands,cm,meta,score,max_pairs=1,slate_context=slate_context)

    expanded=set(map(int,pool_full)); expanded.update(seeds); expanded.update(reciprocal); expanded.update(lane); expanded.update(_hh42_local)
    for grp in groups: expanded.update(grp)
    pf=np.asarray(sorted(expanded),np.int32); pc=cands[pf]; ps=score[pf]
    elite8=rnwd.showdown_elite8_local(cands,{'p99':cm['p99'],'cvar99':cm.get('cvar99',cm['p99']),'p95':cm['p95']},meta,board_size=size)
    locks=list(dict.fromkeys(_hh42_globals+[int(cands[rank1])]+[int(cands[x]) for x in seeds]+[int(cands[x]) for x in reciprocal]+[int(cands[x]) for x in lane]))
    for x in elite8:
        gx=int(cands[int(x)])
        if gx not in locks and len(locks)<min(8,size): locks.append(gx)

    lowsp=int(slate_context['LOWER_OWNED_SP_ID'])
    sibling_specs=[]
    for seed,grp,need in zip(seeds,groups,requirements):
        if int(meta['cpt'][int(cands[seed])])==lowsp and len(lane)>=4: continue
        sibling_specs.append(([int(cands[j]) for j in grp],need))

    # Feasibility-preserving protection admission.  Stage 2 protection is
    # additive only when it can coexist with the portfolio exposure caps.
    # Never allow selector protection locks to make an otherwise legal board
    # mathematically infeasible.
    def _locks_respect_caps(test_locks):
        # O(number_of_locks * roster_size) deterministic admission check.
        # This rejects only protection locks that already violate a hard
        # exposure/CPT/pair/RP cap; it does not run a separate MILP per lock.
        pmap={int(g):i for i,g in enumerate(pc)}
        loc=[pmap[int(g)] for g in test_locks if int(g) in pmap]
        if len(loc)!=len(test_locks) or len(loc)>size: return False
        if not loc: return True
        chosen=pc[np.asarray(loc,np.int32)]
        roster=meta['idx'][chosen]; n=len(meta['names'])
        for pid in range(n):
            cnt=int(np.isin(roster,pid).any(1).sum())
            if cnt:
                cap_share=float(np.clip(max(.70,own[pid]+.10),.70,1.0))
                if cnt>max(1,min(size,int(math.ceil(size*cap_share)))): return False
            cpt_cnt=int((meta['cpt'][chosen]==pid).sum())
            if cpt_cnt:
                cpt_share=.60 if own[pid]>=.65 else .40 if own[pid]>=.35 else .30
                if cpt_cnt>max(1,min(size,int(math.ceil(size*cpt_share)))): return False
        for a in range(n):
            ha=np.isin(roster,a).any(1)
            if not ha.any(): continue
            for b in range(a+1,n):
                pair_cnt=int((ha & np.isin(roster,b).any(1)).sum())
                if not pair_cnt: continue
                pair_share=float(np.clip(max(.60,min(own[a],own[b])+.10),.60,.90))
                if pair_cnt>max(1,min(size,int(math.ceil(size*pair_share)))): return False
        if int((meta['rp_count'][chosen]>0).sum())>min(3,size): return False
        return True

    requested_locks=list(dict.fromkeys(map(int,locks)))
    admitted_locks=[]; rejected_locks=[]
    for g in requested_locks:
        trial=admitted_locks+[int(g)]
        if _locks_respect_caps(trial): admitted_locks=trial
        else: rejected_locks.append(int(g))

    # Only sibling groups need a real feasibility solve because they are
    # disjunctive portfolio constraints. There are at most two groups.
    admitted_siblings=[]; rejected_siblings=[]
    for spec in sibling_specs:
        trial=admitted_siblings+[spec]
        tc=_portfolio_constraints(pc,ps,meta,size,own,locks=admitted_locks,sibling_groups=trial)
        tr=milp(np.zeros(len(pc),dtype=float),integrality=np.ones(len(pc)),bounds=Bounds(0,1),constraints=tc,options={'time_limit':4})
        if tr.success: admitted_siblings=trial
        else: rejected_siblings.append(spec)

    con=_portfolio_constraints(pc,ps,meta,size,own,locks=admitted_locks,sibling_groups=admitted_siblings)
    r2=milp(-ps,integrality=np.ones(len(pc)),bounds=Bounds(0,1),constraints=con,options={'time_limit':20})
    if not r2.success:
        raise RuntimeError('MILP_STAGE2_FAIL_AFTER_CAP_SAFE_ADMISSION:'+str(r2.message))
    ch=np.where(r2.x>.5)[0]; order=ch[np.argsort(-ps[ch],kind='mergesort')]
    selected=pc[order]; selected_scores=ps[order]
    receipt={
      'PATCH_ID':'MLB_SD_ASYMMETRIC_DUAL_SP_CPT_HYBRID_SELECTOR_v1','HYBRID_TRIGGERED':bool(_asymmetric_dual_sp_market(meta,slate_context)),
      'PRIMARY_RANKER':'MLB_SD_ELITE_TAIL_CONTEST_FINISH_RANKER_v1_BLIND_VALIDATED_1_32_20',
      'LANE_RANKER':'MLB_ADVISOR_RIGHT_TAIL_PRIMARY_SELECTOR_v1',
      'STARTER_OWNERSHIP_GAP_TRIGGER':0.30,
      'SEED_GLOBAL_LINEUP_INDEX':[int(cands[x]) for x in seeds],
      'SEED_CPT_IDS':[int(meta['cpt'][cands[x]]) for x in seeds],
      'GROUP_SIZES':[int(len(x)) for x in groups],'GROUP_REQUIRED_SIBLINGS':[int(x) for x in requirements],
      'PROTECTED_GROUP_COUNT':int(len(seeds)),'RECIPROCAL_SP_CPT_LOCKS':[int(cands[x]) for x in reciprocal],
      'STAGE2_REQUESTED_LOCKS':requested_locks,'STAGE2_ADMITTED_LOCKS':admitted_locks,'STAGE2_REJECTED_LOCKS':rejected_locks,
      'STAGE2_ADMITTED_SIBLING_GROUPS':len(admitted_siblings),'STAGE2_REJECTED_SIBLING_GROUPS':len(rejected_siblings),
      'ASYMMETRIC_LOW_SP_CPT_LANE_LOCKS':[int(cands[x]) for x in lane],
      'HIGH_HIGH_SP_CPT_4_2_SENTINEL_GLOBALS':_hh42_globals,'HIGH_HIGH_SP_CPT_4_2_CHAMPIONSHIP_EVENT_COUNTS':_hh42_event_counts,
      'GLOBAL_CORE_PROTECTED_GLOBALS':[int(g) for g in _hh42_globals if int(g) in set(map(int,selected.tolist()))],
      'GLOBAL_CORE_FAMILY_ID':'MLB_SD_HIGH_HIGH_SP_CPT_4_2','GLOBAL_CORE_PRIORITY':100,'GLOBAL_CORE_FAMILY_CAP':2,
      'FEASIBILITY_FRACTURE_INSURANCE_ACTIVE':bool(_feasibility_fracture_hitter_cpt_dual_sp_insurance_active(slate_context)),
      'FEASIBILITY_FRACTURE_HITTER_CPT_DUAL_SP_LOCKS':[int(cands[x]) for x in lane if not bool(meta['cpt_sp'][int(cands[x])]) and int(meta['sp_count'][int(cands[x])])==2],
      'FULL_SELECTOR_REVIEWED':int(len(cands)),'STAGE1_PORTFOLIO_POOL':int(len(pcands)),'STAGE2_PORTFOLIO_POOL':int(len(pc)),
      'STAGE1_STATUS':str(r1.message),'STAGE2_STATUS':str(r2.message),
      'FIELD_SLATE_CONTEXT':advisor_components.get('context',{}),'FROZEN_SLATE_CONTEXT':slate_context.as_dict(),'FROZEN_SLATE_CONTEXT_SHA256':slate_context.sha256,'SELECTOR_RECOMPUTATION':'PROHIBITED',
    }
    return selected,selected_scores,r2,receipt


def projected_exact_match_duplication(meta,field_size):
    """Blind projected exact-lineup duplicate count used only as final tie-break.

    It preserves the active public-field model.  The same pregame lineup weights
    and four mutually-exclusive starter strata used by choose_fake are converted
    into a normalized with-replacement probability measure; no generation,
    handoff, or MC-field gating consumes this value.
    """
    lw=np.asarray(meta['own_log'],float)-np.abs(np.asarray(meta['salary'],float)-49600.0)/6500.0+np.where(np.asarray(meta['branch'])=='4-2',.18,0.0)+np.where(np.asarray(meta['branch'])=='5-1',.10,0.0)
    lw-=float(np.max(lw)); base=np.exp(np.clip(lw,-60,0))
    dual=np.asarray(meta['sp_count']==2); spcpt=np.asarray(meta['cpt_sp'],bool)
    dual_target=float(_LAST_FIELD_RECEIPT.get('TARGET_DUAL_SP_SHARE',0.0)); spcpt_target=float(_LAST_FIELD_RECEIPT.get('TARGET_SP_CPT_SHARE',0.0))
    both_target=min(dual_target,spcpt_target,max(0.0,dual_target*spcpt_target+0.10*min(dual_target,spcpt_target)))
    strata=[
        (dual&spcpt,both_target),
        (dual&~spcpt,max(0.0,dual_target-both_target)),
        ((~dual)&spcpt,max(0.0,spcpt_target-both_target)),
        ((~dual)&(~spcpt),max(0.0,1.0-dual_target-spcpt_target+both_target)),
    ]
    prob=np.zeros(len(base),float)
    for mask,mass in strata:
        ids=np.where(mask)[0]
        if not len(ids) or mass<=0: continue
        den=float(base[ids].sum())
        if den>0: prob[ids]=mass*base[ids]/den
    z=float(prob.sum())
    if z<=0:
        prob=base/max(float(base.sum()),1e-300)
    else:
        prob/=z
    return np.maximum(0.0,float(max(field_size-1,0))*prob)


def final_selected_family_posterior_metrics(selected,full_metrics,lineups,p1,mx,kth,top10_threshold,meta):
    """Exact reciprocal-CPT union plus blind historical dual-SP trophy posterior."""
    selected=np.asarray(selected,np.int32); n=len(selected); T=int(p1.shape[0])
    fm={k:np.asarray(v).copy() for k,v in full_metrics.items()}; fm['trials']=np.full(n,T,float)
    groups=defaultdict(list); spids=set(map(int,meta.get('sp_player_ids',[]))); joint=np.zeros(n,bool)
    for j,g in enumerate(selected):
        g=int(g); cpt=int(meta['cpt'][g]); joint[j]=(int(meta['sp_count'][g])==2 and bool(meta['cpt_sp'][g]) and cpt in spids)
        if joint[j]: groups[tuple(sorted(map(int,meta['idx'][g,:6])))].append(j)
    reciprocal=[]
    if groups:
        W=_lineup_csr_weight_matrix(lineups,selected,p1.shape[1]); v=np.asarray(W@p1.T,dtype=np.float32)
        for core,locs in groups.items():
            cpts={int(meta['cpt'][int(selected[j])]) for j in locs}
            if len(cpts)<2: continue
            locs=sorted(locs,key=lambda j:int(meta['cpt'][int(selected[j])]))
            win=float(np.logical_or.reduce([v[j]>=mx for j in locs]).mean())
            top01=float(np.logical_or.reduce([v[j]>=kth for j in locs]).mean())
            top10=float(np.logical_or.reduce([v[j]>=top10_threshold for j in locs]).mean())
            p95=float(max(fm['p95'][j] for j in locs)); p99=float(max(fm['p99'][j] for j in locs)); mean=float(max(fm['mean'][j] for j in locs))
            for j in locs:
                fm['win'][j]=win; fm['top01'][j]=top01; fm['top10'][j]=top10; fm['p95'][j]=p95; fm['p99'][j]=p99; fm['mean'][j]=mean
                if 'cvar99' in fm: fm['cvar99'][j]=p99
            reciprocal.append({'LINEUP_GLOBALS':[int(selected[j]) for j in locs],'CPT_PLAYER_IDS':[int(meta['cpt'][int(selected[j])]) for j in locs],'RAW_WIN_UNION':win,'RAW_TOP01_UNION':top01,'RAW_TOP10_UNION':top10})
    # The posterior is structure-level and was calibrated only on independent
    # historical contests 941/1176. It never changes lineup birth or fake field.
    ids=np.where(joint)[0]
    if len(ids):
        fm['win'][ids]=dual_sp_adjust_tail_rate(fm['win'][ids])
        fm['top01'][ids]=dual_sp_adjust_tail_rate(fm['top01'][ids])
        fm['top10'][ids]=dual_sp_adjust_tail_rate(fm['top10'][ids])
    cal=dual_sp_calibration_receipt()
    return fm,{
        'PATCH_ID':DUAL_SP_TROPHY_POSTERIOR_PATCH_ID,
        'METHOD':'EXACT_COMMON_WORLD_RECIPROCAL_UNION_PLUS_BAYES_SHRUNK_STRUCTURE_LOG_ODDS',
        'RECIPROCAL_CPT_FAMILIES':int(len(reciprocal)),
        'FAMILY_UNION_APPLIED':bool(reciprocal),
        'JOINT_DUAL_SP_SP_CPT_SELECTED':int(joint.sum()),
        'FAMILIES':reciprocal,
        'TRIALS':T,
        'CALIBRATION':cal,
        'POSTLOCK_RESULTS_USED':False,
    }


def certified_podium_ordering_ok(reasons,control_trigger,hitter_trigger,depth=2):
    # Final board ordering must not be overwritten by family labels.
    series=pd.Series(reasons).astype(str)
    return bool((~series.str.startswith('CERTIFIED_FAMILY_PODIUM')).all())


def run():
    OUT.mkdir(parents=True,exist_ok=True)
    if not str(POOL_PATH) or not POOL_PATH.exists(): raise RuntimeError('MISSING_PLAYER_POOL')
    raw=pd.read_csv(POOL_PATH); pool=active_pool(raw); pool, _pregame_recovery_receipt = repair_team_runs(pool); players=build_players(pool); simulate_players._environment=environment_from_pool(pool); p1_pilot=simulate_players_streamed(players,min(BASE_TRIALS,PHASE1_TRIALS),SEED,'PHASE1_PILOT'); p1=simulate_players_streamed(players,PHASE1_TRIALS,SEED,'PHASE1_FULL')
    qualified_rps=qualify_relief_paths(players,p1); captain_receipt=captain_eligibility(players,p1); prelock_market_context=_prelock_market_targets_from_players(players)
    field_ownership={p['name']:float(p['own']) for p in players}
    calibration_chain={}
    calibration_seal=calibration_freeze.freeze_calibration(p1)
    calibration_chain['PHASE1_CALIBRATION_SHA256']=calibration_seal.sha256
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'PHASE2_INPUT_CALIBRATION_SHA256',calibration_chain)
    all_lineups=enumerate_lineups(players); all_meta=lineup_meta(all_lineups,players)
    conflict_pre=self_conflict_gate.mlb_showdown_evaluate(all_meta)
    side_pre=side_commitment_gate.evaluate(all_meta)
    lineups=all_lineups
    meta=all_meta
    conflict_gate_receipt={'PATCH_ID':SELF_CONFLICT_GATE_PATCH_ID,'MODE':'TELEMETRY_ONLY_ENGINE_EXHAUSTIVE','HARD_REJECT_REMOVALS':0}
    side_commitment_gate_receipt={'PATCH_ID':getattr(side_commitment_gate,'PATCH_ID','SIDE_COMMITMENT'),'MODE':'TELEMETRY_ONLY_ENGINE_EXHAUSTIVE','HARD_REJECT_REMOVALS':0}
    conflict_eval=self_conflict_gate.mlb_showdown_evaluate(meta)
    side_eval=side_commitment_gate.evaluate(meta)
    meta['self_conflict_penalty']=np.asarray(conflict_eval['CONTRADICTION_PENALTY'],float)+np.asarray(side_eval['CONFLICT_PENALTY'],float)
    meta['side_commitment_bonus']=np.asarray(side_eval['SIDE_COMMITMENT_BONUS'],float)
    meta['self_conflict_severity']=np.asarray(conflict_eval['SEVERITY'],object)
    meta['side_commitment_severity']=np.asarray(side_eval['SEVERITY'],object)
    meta['opposing_hitter_count_vs_sole_sp']=np.asarray(conflict_eval['OPPOSING_HITTER_COUNT_VS_SOLE_SP'],np.int8)
    meta['max_opposing_hitters_vs_rostered_sp']=np.asarray(side_eval['MAX_OPPOSING_HITTERS_VS_ROSTERED_SP'],np.int8)
    meta['coherent_five_one_hitter_runback']=np.asarray(side_eval['COHERENT_FIVE_ONE_HITTER_RUNBACK'],bool)
    meta['premium_oneoff_hitter']=np.asarray(side_eval['PREMIUM_ONEOFF_HITTER'],bool)
    phase1_slate_context=build_phase1_context(meta); phase1_context_seal=phase1_slate_context.sha256; proxy=proxy_metrics(p1,lineups); pilot_proxy=proxy_metrics(p1_pilot,lineups)
    born=np.arange(len(lineups),dtype=np.int32); comp=np.zeros(len(lineups),float); ls=np.zeros(len(lineups),float)
    lane_counts={'ENGINE_EXHAUSTIVE_CALIBRATED_LEGAL_UNIVERSE':int(len(born))}
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'HANDOFF_INPUT_CALIBRATION_SHA256',calibration_chain)
    field=choose_fake(all_meta,FAKE_FIELD,SEED+91)
    frozen_slate_context=merge_phase2_context(phase1_slate_context,_LAST_FIELD_RECEIPT); slate_context_seal=frozen_slate_context.sha256
    assert_context_unchanged(phase1_slate_context,phase1_context_seal,'POST_PHASE2_CONTEXT_MERGE'); assert_context_unchanged(frozen_slate_context,slate_context_seal,'HANDOFF_INPUT')
    mx,kth,top10_threshold=field_thresholds(p1,all_lineups,field,TOP01_CUTOFF,TOP10_EQUIV_CUTOFF,trial_chunk=FIELD_THRESHOLD_TRIAL_CHUNK)
    bm=score_lineups(p1,lineups,mx,kth,top10_threshold,born,trial_chunk=LINEUP_SCORE_TRIAL_CHUNK)
    # APEX_MLB_SD_MAX_ENTRY_METADATA_ONLY_v1
    # The complete legal surface is scored first. Final membership starts only
    # from the hard .00001 championship-capability gate (MC win > 0). MAX ENTRY
    # has no role in admission, retention, ranking, or terminal board size.
    _dot00001_local=np.flatnonzero(np.asarray(bm['win'],float)>0.0).astype(np.int32)
    if len(_dot00001_local)==0:
        raise RuntimeError('RUN_INVALID:ZERO_DOT00001_QUALIFIERS')
    h=born[_dot00001_local].copy(); reserve={'ENGINE_EXHAUSTIVE_HANDOFF':True,'STRUCTURAL_RESERVE_ADDITIONS':0}
    fm={k:np.asarray(v)[_dot00001_local].copy() for k,v in bm.items()}; trials_by_h=np.full(len(h),PHASE1_TRIALS,float); fm['trials']=trials_by_h
    deep_set=set(map(int,h)); sibling_added=set(); sibling_seed_globals=[]
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'PHASE3_INPUT_CALIBRATION_SHA256',calibration_chain)
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'DEEP_SIM_INPUT_CALIBRATION_SHA256',calibration_chain)
    pre=.33*pct_rank(fm['top01'])+.07*pct_rank(fm['top10'])+.21*pct_rank(fm['win'])+.14*pct_rank(fm['p99'])+.07*pct_rank(fm['p95'])+.04*pct_rank(fm['mean'])+.04*pct_rank(-meta['own_log'][h])+.06*pct_rank(meta['lineup_market_tt'][h])+.04*pct_rank(meta['tt_leverage'][h])
    pre+=.06*meta['lane_sp_cpt_51'][h]+.08*meta['lane_sp_cpt_51_speed'][h]+.07*meta['lane_sp_cpt_control_51'][h]+.09*meta['lane_sp_cpt_control_51_speed'][h]+.12*meta['lane_sp_cpt_dual_sp_attack_hedge'][h]
    pre+=.08*meta['lane_hitter_cpt_speed_low_spend_42'][h]+.14*meta['lane_hitter_cpt_speed_low_spend_42_release'][h]+.05*meta['salary_release'][h]
    pre+=.09*meta['lane_hitter_cpt_same_team_sp_control'][h]+.12*meta['lane_hitter_cpt_favorite_51_sp_opp_punt'][h]+.10*meta['lane_hitter_cpt_favorite_42_sp_rp'][h]+.16*meta['lane_hitter_cpt_underdog_51_sp_single_rp'][h]
    pre+=.22*meta['lane_hitter_cpt_favorite_51_sp_contact_core'][h]+.24*meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'][h]
    pre+=.18*meta['lane_sp_cpt_control_51_speed_top2_core'][h]+.20*meta['lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release'][h]+.14*meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'][h]
    pre+=.06*np.asarray(meta.get('lane_cross_branch_five_player_championship_family',np.zeros(len(meta['idx']),bool)),float)[h]
    pre-=meta.get('self_conflict_penalty',np.zeros(len(meta['idx'])))[h]
    pre+=meta.get('side_commitment_bonus',np.zeros(len(meta['idx'])))[h]
    keep=len(h); cand=set(h.tolist())
    for mask in [meta['lane_sp_cpt_51'],meta['lane_sp_cpt_51_speed'],meta['lane_sp_cpt_control_51'],meta['lane_sp_cpt_control_51_speed'],meta['lane_sp_cpt_dual_sp_attack_hedge'],
                 meta['lane_hitter_cpt_speed_low_spend'],meta['lane_hitter_cpt_speed_low_spend_42'],meta['lane_hitter_cpt_speed_low_spend_42_release'],
                 meta['lane_hitter_cpt_speed_low_spend_42_control'],meta['lane_hitter_cpt_speed_low_spend_42_counter'],meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'],
                 meta['lane_hitter_cpt_same_team_sp_control'],meta['lane_hitter_cpt_favorite_51_sp_opp_punt'],meta['lane_hitter_cpt_favorite_42_sp_rp'],meta['lane_hitter_cpt_underdog_51_sp_single_rp'],
                 meta['lane_hitter_cpt_favorite_51_sp_contact_core'],meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'],
                 meta['lane_sp_cpt_control_51_speed_top2_core'],meta['lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release'],meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback']]:
        cand.update(h[mask[h]].tolist())
    cands=np.array(sorted(cand),np.int32); pos={g:i for i,g in enumerate(h)}; cm={k:np.array([fm[k][pos[g]] for g in cands]) for k in fm}
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'SELECTOR_INPUT_CALIBRATION_SHA256',calibration_chain)
    assert_context_unchanged(frozen_slate_context,slate_context_seal,'SELECTOR_INPUT')
    # APEX_MLB_SD_MAX_ENTRY_METADATA_ONLY_v1
    # No quota selector is permitted to shrink the .00001-qualified surface.
    # Every qualifier advances to the engine-owned terminal ordering layer.
    selected=cands.copy()
    selector_scores=np.asarray([pre[pos[int(g)]] for g in selected],float)
    res=SimpleNamespace(success=True,status=0,message='NO_QUOTA_DOT00001_FULL_SURFACE_HANDOFF',x=np.ones(len(selected),dtype=float))
    sibling_receipt={
        'PATCH_ID':'APEX_MLB_SD_MAX_ENTRY_METADATA_ONLY_v1',
        'MODE':'NO_QUOTA_DOT00001_FULL_SURFACE_HANDOFF',
        'FULL_SELECTOR_REVIEWED':int(len(cands)),
        'FINAL_MEMBERSHIP_AUTHORITY':'DOT00001_QUALIFICATION_ONLY',
        'MAX_ENTRY_METADATA_ONLY':True,
        'MAX_ENTRY_METADATA':MAX_ENTRY_METADATA,
        'OUTPUT_LINEUP_QUOTA':None,
        'FORCED_BOARD_SIZE':False,
        'BACKFILL':False,
        'SELECTOR_MEMBERSHIP_AUTHORITY':False,
        'GLOBAL_CORE_PROTECTED_GLOBALS':[],
        'GLOBAL_CORE_PROTECTION_BY_GLOBAL':{},
        'GLOBAL_CORE_FAMILY_ID':'',
        'GLOBAL_CORE_PRIORITY':0,
        'GLOBAL_CORE_FAMILY_CAP':1,
    }

    # APEX_TERMINAL_STAGE_COMMIT_ORDERING_v1
    # Hard durability boundary: NATIVE_SELECTOR may not hand control to terminal
    # rescore until its playable provisional board and manifest have committed.
    _prov_rows=[]
    _prov_score_by_global={int(g):float(sv) for g,sv in zip(selected,selector_scores)}
    for _rank,_g in enumerate(selected,1):
        _z=meta['idx'][int(_g)]
        _prov_rows.append(dict(
            RANK=int(_rank),LINEUP_INDEX=int(_g),CPT=meta['names'][_z[0]],
            UTIL1=meta['names'][_z[1]],UTIL2=meta['names'][_z[2]],UTIL3=meta['names'][_z[3]],
            UTIL4=meta['names'][_z[4]],UTIL5=meta['names'][_z[5]],SALARY=int(meta['salary'][int(_g)]),
            BRANCH=str(meta['branch'][int(_g)]),ROUTE=str(meta['route'][int(_g)]),
            SELECTOR_SCORE=float(_prov_score_by_global[int(_g)]),PROVISIONAL_BOARD=True))
    _provisional_board_path=OUT/f'DK_MLB_SD_{EXECUTION_ID}_PROVISIONAL_BOARD.csv'
    _provisional_manifest_path=OUT/f'DK_MLB_SD_{EXECUTION_ID}_PROVISIONAL_BOARD_MANIFEST.json'
    pd.DataFrame(_prov_rows).to_csv(_provisional_board_path,index=False)
    _provisional_manifest=dict(
        PATCH_ID='APEX_TERMINAL_STAGE_COMMIT_ORDERING_v1',EXECUTION_ID=EXECUTION_ID,
        COMMITTED_STAGE='NATIVE_SELECTOR',NEXT_STAGE='ENGINE_TERMINAL_AND_CHAMPIONSHIP_RESERVE',
        STATE='PROVISIONAL_BOARD_SEALED',PROVISIONAL_BOARD_PATH=str(_provisional_board_path),
        PROVISIONAL_BOARD_SHA256=sha_file(_provisional_board_path),PROVISIONAL_BOARD_ROWS=len(_prov_rows),
        TERMINAL_SHORTLIST_MAX=250,OPENAI_LIVE_AUTHORITY=False,CHAT_EXECUTION_AUTHORITY=False)
    _provisional_manifest_path.write_text(json.dumps(_provisional_manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    _manifest_b64=base64.b64encode(json.dumps(_provisional_manifest,separators=(',',':'),sort_keys=True).encode('utf-8')).decode('ascii')
    print(f'[APEX_MANIFEST_COMMIT_BEGIN]\n{_manifest_b64}\n[APEX_MANIFEST_COMMIT_END]',flush=True)
    print(json.dumps(dict(RUN_STATE='PROVISIONAL_BOARD_SEALED',PROVISIONAL_BOARD_PATH=str(_provisional_board_path),PROVISIONAL_BOARD_ROWS=len(_prov_rows),PROVISIONAL_BOARD_SHA256=_provisional_manifest['PROVISIONAL_BOARD_SHA256'])),flush=True)

    # MLB_EV_LIVE_CANARY_WIRING_v1 -- mandatory non-authoritative S1 shadow.
    # It runs from the complete frozen preterminal candidate surface and writes a
    # sealed challenger artifact. Production terminal membership below is unchanged.
    _terminal_limit=min(250,len(cands))
    _s1_canary=None
    if str(os.environ.get('APEX_MLB_EV_CANARY_ENABLED','1')).strip().lower() not in {'0','false','no','off'}:
        try:
            _sel_order={int(g):i+1 for i,g in enumerate(selected)}
            _ntr=np.asarray(cm.get('trials',np.full(len(cands),BASE_TRIALS+EXTRA_TRIALS)),float)
            _top_lcb=wilson_lcb(np.asarray(cm['top01'],float),_ntr,z=1.0)
            _top_ucb=wilson_ucb(np.asarray(cm['top01'],float),_ntr,z=1.0)
            _win_lcb=wilson_lcb(np.asarray(cm['win'],float),_ntr,z=1.0)
            _s1_rows=[]
            for _j,_g in enumerate(cands):
                _z=meta['idx'][int(_g)]
                _s1_rows.append(dict(
                    LINEUP_ID=int(_g),PRE_SCORE=float(pre[pos[int(_g)]]),
                    NATIVE_SELECTED=bool(int(_g) in _sel_order),NATIVE_SELECTED_ORDER=int(_sel_order.get(int(_g),0)),
                    MC_TOP_0_1_RATE=float(cm['top01'][_j]),MC_TOP_0_1_LCB=float(_top_lcb[_j]),
                    ELITE_TOP01_LCB=float(_top_lcb[_j]),ELITE_TOP01_UCB=float(_top_ucb[_j]),
                    MC_WIN_RATE=float(cm['win'][_j]),MC_WIN_LCB=float(_win_lcb[_j]),MC_P99=float(cm['p99'][_j]),
                    MC_UNCERTAINTY_WIDTH=float(max(0.0,_top_ucb[_j]-_top_lcb[_j])),
                    SP_COUNT=int(meta['sp_count'][int(_g)]),RP_COUNT=int(meta['rp_count'][int(_g)]),
                    CPT_IS_SP=bool(meta['cpt_sp'][int(_g)]),ROUTE=str(meta['route'][int(_g)]),
                    CPT=meta['names'][_z[0]],UTIL1=meta['names'][_z[1]],UTIL2=meta['names'][_z[2]],
                    UTIL3=meta['names'][_z[3]],UTIL4=meta['names'][_z[4]],UTIL5=meta['names'][_z[5]],
                ))
            _s1_canary=run_showdown_s1_canary(pd.DataFrame(_s1_rows),OUT,EXECUTION_ID,terminal_limit=_terminal_limit)
            print(json.dumps(dict(
                RUN_STATE='MLB_SHOWDOWN_S1_CANARY_SEALED',PATCH_ID=_s1_canary.get('PATCH_ID'),
                PRETERMINAL_CANDIDATE_COUNT=_s1_canary.get('PRETERMINAL_CANDIDATE_COUNT'),
                ACTUAL_REPLACEMENTS=_s1_canary.get('ACTUAL_REPLACEMENTS'),
                BASELINE_IDENTITY_RETENTION=_s1_canary.get('BASELINE_IDENTITY_RETENTION'),
                CPT_MARGINAL_PARITY=_s1_canary.get('CPT_MARGINAL_PARITY'),
                RECEIPT_PATH=_s1_canary.get('RECEIPT_PATH'),RECEIPT_SHA256=_s1_canary.get('RECEIPT_SHA256'),
                SELECTION_AUTHORITY=False,PRODUCTION_TERMINAL_MUTATED=False,
            ),sort_keys=True),flush=True)
        except Exception as _s1_exc:
            _s1_fail=OUT/f'DK_MLB_SD_{EXECUTION_ID}_S1_TERMINAL_RECALL_CANARY_FAILURE.json'
            _s1_fail.write_text(json.dumps(dict(
                PATCH_ID='MLB_EV_LIVE_CANARY_WIRING_v1',EXECUTION_ID=EXECUTION_ID,
                STATE='CANARY_FAILED_NONBLOCKING',ERROR=f'{type(_s1_exc).__name__}:{_s1_exc}',
                SELECTION_AUTHORITY=False,PRODUCTION_TERMINAL_MUTATED=False,
            ),indent=2,sort_keys=True)+'\n',encoding='utf-8')
            print(json.dumps(dict(RUN_STATE='MLB_SHOWDOWN_S1_CANARY_FAILED_NONBLOCKING',ERROR=f'{type(_s1_exc).__name__}:{_s1_exc}',SELECTION_AUTHORITY=False),sort_keys=True),flush=True)

    # Deterministic bounded terminal shortlist. Preserve every native-selected
    # lineup, then fill by the existing pre-selector score. No new lineup is born.
    _terminal_selected=[int(x) for x in selected]
    _terminal_seen=set(_terminal_selected)
    _terminal_fill=sorted((int(g) for g in cands if int(g) not in _terminal_seen),key=lambda g:(-float(pre[pos[g]]),int(g)))
    _terminal_cands=np.asarray((_terminal_selected+_terminal_fill)[:_terminal_limit],dtype=np.int32)
    _cands_pos={int(g):i for i,g in enumerate(cands)}
    _terminal_cm={k:np.asarray([cm[k][_cands_pos[int(g)]] for g in _terminal_cands]) for k in cm}

    # Terminal AI Hybrid review surface. The coded selector above remains a
    # comparator when AI authority is enabled; it cannot force terminal seats.
    # Every selector-reviewed candidate is exported with frozen pre-lock metrics.
    _ai_comp=contest_finish_components(_terminal_cands,_terminal_cm,meta,trials=BASE_TRIALS+EXTRA_TRIALS,field_size=FIELD_SIZE,slate_games=1)
    _ai_dup=projected_exact_match_duplication(meta,FIELD_SIZE)[_terminal_cands]
    _sel_order={int(g):i+1 for i,g in enumerate(selected)}
    _field_source=str(_LAST_FIELD_RECEIPT.get('SOURCE','UNKNOWN'))
    _field_reliability=('LOW_DIRECT_RST_STRUCTURAL_PRIOR' if _field_source=='BLIND_RST_OWNERSHIP_ONLY' else 'GOVERNED_OR_MODEL_DERIVED')
    _ai_protection_by_global=sibling_receipt.get('GLOBAL_CORE_PROTECTION_BY_GLOBAL',{}) or {}
    _ai_core_globals=set(map(int,sibling_receipt.get('GLOBAL_CORE_PROTECTED_GLOBALS',[])))
    _ai_core_globals.update(int(k) for k in _ai_protection_by_global)
    _ai_core_family=str(sibling_receipt.get('GLOBAL_CORE_FAMILY_ID',''))
    _ai_core_priority=int(sibling_receipt.get('GLOBAL_CORE_PRIORITY',0) or 0)
    _ai_core_cap=int(sibling_receipt.get('GLOBAL_CORE_FAMILY_CAP',1) or 1)
    def _ai_core_meta(x,key,default):
        xi=int(x); rec=_ai_protection_by_global.get(xi)
        if rec is None: rec=_ai_protection_by_global.get(str(xi),{})
        return (rec or {}).get(key,default)
    # Pre-lock player-level winner-shape evidence for terminal selection.
    # RST% is exported only as roster ownership; it is never mislabeled as CPT ownership.
    _ai_player_p99=np.quantile(p1,0.99,axis=0).astype(float)
    def _ai_pct_rank(_arr):
        _arr=np.asarray(_arr,float); _uniq=np.unique(_arr[np.isfinite(_arr)])
        if len(_uniq)<=1: return np.full(len(_arr),0.5,float)
        _rank={float(v):i/(len(_uniq)-1) for i,v in enumerate(_uniq)}
        return np.asarray([_rank.get(float(v),0.5) if np.isfinite(v) else 0.5 for v in _arr],float)
    _ai_player_ceiling_pctl=_ai_pct_rank(_ai_player_p99)
    _ai_player_own=np.asarray([float(p.get('own',0.0) or 0.0) for p in players],float)
    _ai_player_own_pctl=_ai_pct_rank(_ai_player_own)
    _ai_player_unlock=np.asarray([1 if bool(p.get('strategy_salary_unlock',False)) else 0 for p in players],int)
    _ai_player_leverage=np.asarray([float(p.get('strategy_leverage',0.0) or 0.0) for p in players],float)
    _ai_rows=[]
    for _j,_g in enumerate(_terminal_cands):
        _z=meta['idx'][int(_g)]
        _ai_rows.append(dict(
            LINEUP_ID=str(int(_g)),LINEUP_INDEX=int(_g),CPT=meta['names'][_z[0]],
            UTIL1=meta['names'][_z[1]],UTIL2=meta['names'][_z[2]],UTIL3=meta['names'][_z[3]],UTIL4=meta['names'][_z[4]],UTIL5=meta['names'][_z[5]],
            CPT_TEAM=str(meta['teams'][_z[0]]),UTIL1_TEAM=str(meta['teams'][_z[1]]),UTIL2_TEAM=str(meta['teams'][_z[2]]),UTIL3_TEAM=str(meta['teams'][_z[3]]),UTIL4_TEAM=str(meta['teams'][_z[4]]),UTIL5_TEAM=str(meta['teams'][_z[5]]),
            CPT_ORDER=int(meta['batting_order'][_z[0]]),UTIL1_ORDER=int(meta['batting_order'][_z[1]]),UTIL2_ORDER=int(meta['batting_order'][_z[2]]),UTIL3_ORDER=int(meta['batting_order'][_z[3]]),UTIL4_ORDER=int(meta['batting_order'][_z[4]]),UTIL5_ORDER=int(meta['batting_order'][_z[5]]),
            CPT_CONDITIONAL_SUPPORT=float(meta['player_conditional_core_support'][_z[0]]),UTIL1_CONDITIONAL_SUPPORT=float(meta['player_conditional_core_support'][_z[1]]),UTIL2_CONDITIONAL_SUPPORT=float(meta['player_conditional_core_support'][_z[2]]),UTIL3_CONDITIONAL_SUPPORT=float(meta['player_conditional_core_support'][_z[3]]),UTIL4_CONDITIONAL_SUPPORT=float(meta['player_conditional_core_support'][_z[4]]),UTIL5_CONDITIONAL_SUPPORT=float(meta['player_conditional_core_support'][_z[5]]),
            CPT_MUTATION_SUPPORT=float(meta['player_mutation_incoming_support'][_z[0]]),UTIL1_MUTATION_SUPPORT=float(meta['player_mutation_incoming_support'][_z[1]]),UTIL2_MUTATION_SUPPORT=float(meta['player_mutation_incoming_support'][_z[2]]),UTIL3_MUTATION_SUPPORT=float(meta['player_mutation_incoming_support'][_z[3]]),UTIL4_MUTATION_SUPPORT=float(meta['player_mutation_incoming_support'][_z[4]]),UTIL5_MUTATION_SUPPORT=float(meta['player_mutation_incoming_support'][_z[5]]),
            SALARY=int(meta['salary'][_g]),BRANCH=str(meta['branch'][_g]),ROUTE=str(meta['route'][_g]),
            PLAYER_ROSTER_OWNERSHIP_PCTS=json.dumps([round(float(_ai_player_own[int(x)]),6) for x in _z],separators=(',',':')),
            PLAYER_OWNERSHIP_PCTLS=json.dumps([round(float(_ai_player_own_pctl[int(x)]),8) for x in _z],separators=(',',':')),
            PLAYER_CEILING_PCTLS=json.dumps([round(float(_ai_player_ceiling_pctl[int(x)]),8) for x in _z],separators=(',',':')),
            PLAYER_SALARY_UNLOCK_FLAGS=json.dumps([int(_ai_player_unlock[int(x)]) for x in _z],separators=(',',':')),
            PLAYER_STRATEGIC_LEVERAGE=json.dumps([round(float(_ai_player_leverage[int(x)]),8) for x in _z],separators=(',',':')),
            CPT_ROSTER_OWNERSHIP_PCT=round(float(_ai_player_own[int(_z[0])]),6),
            CPT_CEILING_PCTL=round(float(_ai_player_ceiling_pctl[int(_z[0])]),8),
            CPT_SALARY_UNLOCK_FLAG=bool(_ai_player_unlock[int(_z[0])]),
            CPT_STRATEGIC_LEVERAGE=round(float(_ai_player_leverage[int(_z[0])]),8),
            SP_COUNT=int(meta['sp_count'][_g]),CPT_IS_SP=bool(meta['cpt_sp'][_g]),RP_COUNT=int(meta['rp_count'][_g]),
            SELF_CONFLICT_SEVERITY=str(meta['self_conflict_severity'][_g]),SELF_CONFLICT_PENALTY=float(meta['self_conflict_penalty'][_g]),
            SIDE_COMMITMENT_BONUS=float(meta['side_commitment_bonus'][_g]),SIDE_COMMITMENT_SEVERITY=str(meta['side_commitment_severity'][_g]),
            MAX_OPPOSING_HITTERS_VS_ROSTERED_SP=int(meta['max_opposing_hitters_vs_rostered_sp'][_g]),
            OPPOSING_HITTERS_VS_SOLE_SP=int(meta['opposing_hitter_count_vs_sole_sp'][_g]),
            MC_TRIALS=int(cm['trials'][_j]),MC_WIN_RATE=float(cm['win'][_j]),MC_WIN_LCB=float(_ai_comp['win_lcb'][_j]),
            MC_TOP_0_1_RATE=float(cm['top01'][_j]),MC_TOP_0_1_LCB=float(_ai_comp['top01_lcb'][_j]),
            MC_TOP10_RATE=float(cm['top10'][_j]),MC_TOP10_LCB=float(_ai_comp['top10_lcb'][_j]),
            MC_MEAN=float(cm['mean'][_j]),MC_P95=float(cm['p95'][_j]),MC_P99=float(cm['p99'][_j]),
            PROJECTED_EXACT_MATCH_DUPLICATION=float(_ai_dup[_j]),
            CURRENT_SELECTOR_PRE_SCORE=float(pre[pos[int(_g)]]),CURRENT_SELECTOR_SELECTED=bool(int(_g) in _sel_order),
            CURRENT_SELECTOR_RANK=int(_sel_order.get(int(_g),0)),
            LINEUP_MARKET_TT=float(meta['lineup_market_tt'][_g]),TT_LEVERAGE_SCORE=float(meta['tt_leverage'][_g]),
            SALARY_RELEASE_SCORE=float(meta['salary_release'][_g]),RP_ROLE_REALIZATION_PROB=float(meta['rp_role_probability'][_g]),
            SP_CPT_5_1_CLOSURE=bool(meta['lane_sp_cpt_51'][_g]),SP_CPT_CONTROL_5_1=bool(meta['lane_sp_cpt_control_51'][_g]),
            HITTER_CPT_SPEED_LOW_SPEND=bool(meta['lane_hitter_cpt_speed_low_spend'][_g]),
            HITTER_CPT_UNDERDOG_5_1_SP_SINGLE_RP=bool(meta['lane_hitter_cpt_underdog_51_sp_single_rp'][_g]),
            HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK=bool(meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'][_g]),
            CROSS_BRANCH_FIVE_PLAYER_CHAMPIONSHIP_FAMILY=bool(meta.get('lane_cross_branch_five_player_championship_family',np.zeros(len(meta['idx']),bool))[_g]),
            GLOBAL_CORE_PROTECTED=bool(int(_g) in _ai_core_globals),
            GLOBAL_CORE_FAMILY_ID=str(_ai_core_meta(_g,'GLOBAL_CORE_FAMILY_ID',_ai_core_family if int(_g) in _ai_core_globals else '')),
            GLOBAL_CORE_SCENARIO_ID=str(_ai_core_meta(_g,'GLOBAL_CORE_SCENARIO_ID',_ai_core_family if int(_g) in _ai_core_globals else '')),
            GLOBAL_CORE_PRIORITY=int(_ai_core_meta(_g,'GLOBAL_CORE_PRIORITY',_ai_core_priority if int(_g) in _ai_core_globals else 0)),
            GLOBAL_CORE_FAMILY_CAP=int(_ai_core_meta(_g,'GLOBAL_CORE_FAMILY_CAP',_ai_core_cap if int(_g) in _ai_core_globals else 1)),
            FIELD_MODEL_SOURCE=_field_source,FIELD_MODEL_RELIABILITY=_field_reliability,
            OWNERSHIP_AUTHORITY=str(os.getenv('APEX_OWNERSHIP_AUTHORITY','RUNTIME_INPUT')),
        ))
    # Deterministic multi-seed boundary convergence. The callback owns MLB
    # Showdown sports physics and returns cumulative rare-event metrics for the
    # exact bubble IDs. Common random numbers are preserved inside every seed by
    # evaluating all bubble lineups against the same player-world matrix and the
    # same ownership-derived field thresholds. Secondary P95/P99 moments remain
    # frozen from the primary 50K tape; this loop reduces only rank-1/Top-0.1
    # Monte Carlo uncertainty and cannot invent or prune lineups.
    def _mlb_sd_multi_seed_callback(_bubble_rows,_extra_trials,_seed):
        global _LAST_MC_ENV_RECEIPT, _LAST_TEAM_RUN_PATHS
        _saved_env=dict(_LAST_MC_ENV_RECEIPT) if isinstance(_LAST_MC_ENV_RECEIPT,dict) else _LAST_MC_ENV_RECEIPT
        _saved_paths=_LAST_TEAM_RUN_PATHS
        try:
            _extra_scores=simulate_players_streamed(players,int(_extra_trials),int(_seed),f'MULTI_SEED_{int(_seed)}_{int(_extra_trials)}')
            _emx,_ek,_e10=field_thresholds(_extra_scores,all_lineups,field,TOP01_CUTOFF,TOP10_EQUIV_CUTOFF,trial_chunk=FIELD_THRESHOLD_TRIAL_CHUNK)
            _ids=np.asarray([int(r['LINEUP_ID']) for r in _bubble_rows],np.int32)
            _extra=score_lineups(_extra_scores,lineups,_emx,_ek,_e10,_ids,trial_chunk=LINEUP_SCORE_TRIAL_CHUNK)
        finally:
            _LAST_MC_ENV_RECEIPT=_saved_env
            _LAST_TEAM_RUN_PATHS=_saved_paths
        _out=[]
        for _j,_r0 in enumerate(_bubble_rows):
            _r=dict(_r0); _n0=max(0,int(float(_r.get('MC_TRIALS',0) or 0))); _n1=int(_extra_trials); _nt=_n0+_n1
            if _n0<=0 or _nt<=_n0:
                raise RuntimeError(f'RUN_INVALID:MULTI_SEED_BASE_TRIALS_INVALID:{_r.get("LINEUP_ID")}:{_n0}:{_n1}')
            def _combine(_field,_metric):
                _old=float(_r.get(_field,0.0) or 0.0); _new=float(_extra[_metric][_j])
                return (_old*_n0+_new*_n1)/_nt
            _r['MC_WIN_RATE']=_combine('MC_WIN_RATE','win')
            _r['MC_TOP_0_1_RATE']=_combine('MC_TOP_0_1_RATE','top01')
            _r['MC_TOP10_RATE']=_combine('MC_TOP10_RATE','top10')
            _r['MC_MEAN']=_combine('MC_MEAN','mean')
            _r['MC_TRIALS']=int(_nt)
            _r['MC_WIN_LCB']=float(wilson_lcb(np.asarray([_r['MC_WIN_RATE']]),np.asarray([_nt]),z=1.0)[0])
            _r['MC_TOP_0_1_LCB']=float(wilson_lcb(np.asarray([_r['MC_TOP_0_1_RATE']]),np.asarray([_nt]),z=1.0)[0])
            _r['MC_TOP10_LCB']=float(wilson_lcb(np.asarray([_r['MC_TOP10_RATE']]),np.asarray([_nt]),z=1.0)[0])
            _r['MULTI_SEED_SECONDARY_MOMENTS_FROZEN']=True
            _r['MULTI_SEED_LAST_SEED']=int(_seed)
            _r['MULTI_SEED_LAST_EXTRA_TRIALS']=int(_extra_trials)
            _out.append(_r)
        return _out

    _ai_surface=''
    _ai_receipt_path=''
    _ai_receipt=dict(PATCH_ID='DISABLED_ENGINE_ONLY',CANDIDATE_FREEZE_SHA256='ENGINE_ONLY_NO_AI_SURFACE',
                     MULTI_SEED_PATCH_ID='DISABLED_ENGINE_ONLY',MULTI_SEED_CONVERGENCE={'STATUS':'DISABLED_ENGINE_ONLY','ROUNDS_EXECUTED':0,'EXTRA_WORLD_TRIALS_TOTAL':0,'UNRESOLVED_BOUNDARY_LINEUPS':0})
    # Final-trial pre-sort sealing: the selected portfolio is rescored on the full
    # frozen Phase-1 worlds before any board order is assigned.
    final_metrics=score_lineups(p1,lineups,mx,kth,top10_threshold,selected,trial_chunk=LINEUP_SCORE_TRIAL_CHUNK); final_metrics['trials']=np.full(len(selected),PHASE1_TRIALS,float)
    individual_components=contest_finish_components(selected,final_metrics,meta,trials=PHASE1_TRIALS,field_size=FIELD_SIZE,slate_games=1)
    family_metrics,family_rank_receipt=final_selected_family_posterior_metrics(selected,final_metrics,lineups,p1,mx,kth,top10_threshold,meta)
    family_components=contest_finish_components(selected,family_metrics,meta,trials=PHASE1_TRIALS,field_size=FIELD_SIZE,slate_games=1)
    individual_score=np.asarray(individual_components['score'],float)
    family_score=np.asarray(family_components['score'],float)
    rank_components=dict(individual_components); rank_components['score']=individual_score; rank_components['individual_score']=individual_score; rank_components['family_score']=family_score
    projected_dup_all=projected_exact_match_duplication(meta,FIELD_SIZE); rank_components['projected_duplication']=projected_dup_all[selected]
    sibling_receipt['RECIPROCAL_CPT_DUAL_SP_TROPHY_POSTERIOR']=family_rank_receipt
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'FINAL_BOARD_INPUT_CALIBRATION_SHA256',calibration_chain)
    assert_context_unchanged(frozen_slate_context,slate_context_seal,'FINAL_BOARD_INPUT')
    board,bs,board_reasons=rank_selected_board(selected,selected,rank_components,meta)
    _pord=_premium_signature_final_board_order(board,{k:(np.asarray(v)[[int(np.where(selected==g)[0][0]) for g in board]] if np.asarray(v).ndim==1 and len(np.asarray(v))==len(selected) else v) for k,v in rank_components.items()},meta)
    if not np.array_equal(_pord,np.arange(len(board),dtype=np.int32)):
        board=board[_pord]; bs=bs[_pord]; board_reasons=['PREMIUM_SIGNATURE_NEAR_TIE_DOOR' if int(i)!=int(j) else board_reasons[int(i)] for j,i in enumerate(_pord)]
    cpos={int(g):i for i,g in enumerate(selected)}; selector_score_by_global={int(g):float(sv) for g,sv in zip(selected,selector_scores)}; rows=[]
    for rank,(g,ss,order_reason) in enumerate(zip(board,bs,board_reasons),1):
        z=meta['idx'][g]; j=cpos[int(g)]; rows.append(dict(RANK=rank,LINEUP_INDEX=int(g),CPT=meta['names'][z[0]],UTIL1=meta['names'][z[1]],UTIL2=meta['names'][z[2]],UTIL3=meta['names'][z[3]],UTIL4=meta['names'][z[4]],UTIL5=meta['names'][z[5]],SALARY=int(meta['salary'][g]),BRANCH=meta['branch'][g],ROUTE=meta['route'][g],SP_COUNT=int(meta['sp_count'][g]),CPT_IS_SP=bool(meta['cpt_sp'][g]),RP_COUNT=int(meta['rp_count'][g]),SELF_CONFLICT_SEVERITY=str(meta['self_conflict_severity'][g]),SELF_CONFLICT_PENALTY=float(meta['self_conflict_penalty'][g]),SIDE_COMMITMENT_BONUS=float(meta['side_commitment_bonus'][g]),SIDE_COMMITMENT_SEVERITY=str(meta['side_commitment_severity'][g]),MAX_OPPOSING_HITTERS_VS_ROSTERED_SP=int(meta['max_opposing_hitters_vs_rostered_sp'][g]),COHERENT_5_1_HITTER_RUNBACK=bool(meta['coherent_five_one_hitter_runback'][g]),PREMIUM_ONEOFF_HITTER=bool(meta['premium_oneoff_hitter'][g]),OPPOSING_HITTERS_VS_SOLE_SP=int(meta['opposing_hitter_count_vs_sole_sp'][g]),SP_CPT_5_1_CLOSURE=bool(meta['lane_sp_cpt_51'][g]),SP_CPT_CONTROL_5_1=bool(meta['lane_sp_cpt_control_51'][g]),LOW_OWN_SPEED_RUNBACK=bool(meta['lane_sp_cpt_51_speed'][g]),CONTROL_SPEED_RUNBACK=bool(meta['lane_sp_cpt_control_51_speed'][g]),HITTER_CPT_SPEED_LOW_SPEND=bool(meta['lane_hitter_cpt_speed_low_spend'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2=bool(meta['lane_hitter_cpt_speed_low_spend_42'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE=bool(meta['lane_hitter_cpt_speed_low_spend_42_release'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL=bool(meta['lane_hitter_cpt_speed_low_spend_42_control'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][g]),HITTER_CPT_SAME_TEAM_SP_CONTROL=bool(meta['lane_hitter_cpt_same_team_sp_control'][g]),HITTER_CPT_FAVORITE_5_1_SP_OPP_PUNT=bool(meta['lane_hitter_cpt_favorite_51_sp_opp_punt'][g]),HITTER_CPT_FAVORITE_4_2_SP_RP=bool(meta['lane_hitter_cpt_favorite_42_sp_rp'][g]),HITTER_CPT_UNDERDOG_5_1_SP_SINGLE_RP=bool(meta['lane_hitter_cpt_underdog_51_sp_single_rp'][g]),HITTER_CPT_FAVORITE_5_1_SP_CONTACT_CORE=bool(meta['lane_hitter_cpt_favorite_51_sp_contact_core'][g]),HITTER_CPT_FAVORITE_4_2_SP_RP_UNCERTAIN_CONTACT=bool(meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'][g]),HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK=bool(meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'][g]),PRIMARY_RELEASE_PLAYER=(meta['names'][meta['primary_release_player'][g]] if meta['primary_release_player'][g]>=0 else ''),PRIMARY_RP_PLAYER=(meta['names'][meta['primary_rp_player'][g]] if meta['primary_rp_player'][g]>=0 else ''),RP_ROLE_REALIZATION_PROB=float(meta['rp_role_probability'][g]),SALARY_RELEASE_SCORE=float(meta['salary_release'][g]),LINEUP_MARKET_TT=float(meta['lineup_market_tt'][g]),TT_LEVERAGE_SCORE=float(meta['tt_leverage'][g]),TEAM_A=str(sorted(_LAST_MC_ENV_RECEIPT['TEAM_TOTALS'])[0]),TEAM_A_MARKET_TT=float(_LAST_MC_ENV_RECEIPT['TEAM_TOTALS'][sorted(_LAST_MC_ENV_RECEIPT['TEAM_TOTALS'])[0]]['MARKET_IMPLIED_TT']),TEAM_A_SIM_TT=float(_LAST_MC_ENV_RECEIPT['TEAM_TOTALS'][sorted(_LAST_MC_ENV_RECEIPT['TEAM_TOTALS'])[0]]['SIM_TT_MEAN']),TEAM_B=str(sorted(_LAST_MC_ENV_RECEIPT['TEAM_TOTALS'])[1]),TEAM_B_MARKET_TT=float(_LAST_MC_ENV_RECEIPT['TEAM_TOTALS'][sorted(_LAST_MC_ENV_RECEIPT['TEAM_TOTALS'])[1]]['MARKET_IMPLIED_TT']),TEAM_B_SIM_TT=float(_LAST_MC_ENV_RECEIPT['TEAM_TOTALS'][sorted(_LAST_MC_ENV_RECEIPT['TEAM_TOTALS'])[1]]['SIM_TT_MEAN']),MC_TRIALS=int(final_metrics['trials'][j]),MC_WIN_RATE=float(final_metrics['win'][j]),MC_WIN_LCB=float(individual_components['win_lcb'][j]),MC_TOP_0_1_RATE=float(final_metrics['top01'][j]),MC_TOP_0_1_LCB=float(individual_components['top01_lcb'][j]),MC_TOP10_RATE=float(final_metrics['top10'][j]),MC_TOP10_LCB=float(individual_components['top10_lcb'][j]),MC_MEAN=float(final_metrics['mean'][j]),MC_P95=float(final_metrics['p95'][j]),MC_P99=float(final_metrics['p99'][j]),FAMILY_MC_WIN_RATE=float(family_metrics['win'][j]),FAMILY_MC_TOP_0_1_RATE=float(family_metrics['top01'][j]),FAMILY_MC_TOP10_RATE=float(family_metrics['top10'][j]),PROJECTED_EXACT_MATCH_DUPLICATION=float(rank_components['projected_duplication'][j]),SELECTOR_SCORE=float(selector_score_by_global[int(g)]),CONTEST_FINISH_SCORE=float(ss),BOARD_ORDER_REASON=order_reason,BOARD_ORDER_METHOD=RANKER_ID))
    bdf=pd.DataFrame(rows)
    _protection_by_global=sibling_receipt.get('GLOBAL_CORE_PROTECTION_BY_GLOBAL',{}) or {}
    _core_globals=set(map(int,sibling_receipt.get('GLOBAL_CORE_PROTECTED_GLOBALS',[])))
    _core_globals.update(int(k) for k in _protection_by_global)
    _core_family=str(sibling_receipt.get('GLOBAL_CORE_FAMILY_ID',''))
    _core_priority=int(sibling_receipt.get('GLOBAL_CORE_PRIORITY',0) or 0)
    _core_cap=int(sibling_receipt.get('GLOBAL_CORE_FAMILY_CAP',1) or 1)
    def _core_meta(x,key,default):
        # Runtime protection maps use integer lineup ids; JSON round-trips use
        # string keys. Accept both so distinct sport-native Core-5 authorities
        # do not collapse into the receipt-level fallback family/cap.
        xi=int(x)
        rec=_protection_by_global.get(xi)
        if rec is None: rec=_protection_by_global.get(str(xi),{})
        return (rec or {}).get(key,default)
    bdf['GLOBAL_CORE_PROTECTED']=bdf['LINEUP_INDEX'].map(lambda x:int(x) in _core_globals)
    bdf['GLOBAL_CORE_FAMILY_ID']=bdf['LINEUP_INDEX'].map(lambda x:str(_core_meta(x,'GLOBAL_CORE_FAMILY_ID',_core_family if int(x) in _core_globals else '')))
    bdf['GLOBAL_CORE_SCENARIO_ID']=bdf['LINEUP_INDEX'].map(lambda x:str(_core_meta(x,'GLOBAL_CORE_SCENARIO_ID',_core_family if int(x) in _core_globals else '')))
    bdf['GLOBAL_CORE_PRIORITY']=bdf['LINEUP_INDEX'].map(lambda x:int(_core_meta(x,'GLOBAL_CORE_PRIORITY',_core_priority if int(x) in _core_globals else 0)))
    bdf['GLOBAL_CORE_FAMILY_CAP']=bdf['LINEUP_INDEX'].map(lambda x:int(_core_meta(x,'GLOBAL_CORE_FAMILY_CAP',_core_cap if int(x) in _core_globals else 1)))
    if len(bdf) != len(selected) or bdf[['CPT','UTIL1','UTIL2','UTIL3','UTIL4','UTIL5']].isna().any().any():
        raise RuntimeError('RUN_FAIL:SHOWDOWN_BOARD_IDENTITY_RECONCILIATION')
    for rec in bdf.to_dict('records'):
        names=[rec['CPT'],rec['UTIL1'],rec['UTIL2'],rec['UTIL3'],rec['UTIL4'],rec['UTIL5']]
        if len(set(names)) != 6 or any(name not in set(meta['names']) for name in names):
            raise RuntimeError('RUN_FAIL:SHOWDOWN_BOARD_IDENTITY_RECONCILIATION')
    # The sport-native 10-line selector surface is NOT the terminal playable board.
    # Global Championship Core-5 must seal the final playable board.  A distinct
    # sentinel prevents any caller from mistaking the native review surface for
    # the user-visible terminal board.
    print(json.dumps({
        'RUN_STATE':'NATIVE_BOARD_READY_FOR_GLOBAL_CORE5',
        'PRODUCTION_TRIGGER_DIRECT_EXECUTION':'PASS',
        'DIAGNOSTIC_ROUTING':'DISABLED',
        'BOARD_FIRST_RENDERING':'NATIVE_SOURCE_READY_ONLY',
        'BOARD_FIRST_DOCTRINE':'BOARD_FIRST_RENDERING_v2',
        'BOARD_IDENTITY_RECONCILIATION':'PASS',
        'TERMINAL_PLAYABLE_BOARD':False,
        'GLOBAL_CHAMPIONSHIP_CORE_REQUIRED':True,
        'GLOBAL_CHAMPIONSHIP_CORE_SIZE':5,
        'SATELLITES_ENABLED':False,
        'NATIVE_BOARD_SIZE':len(bdf),
        'FINAL_BOARD_SIZE':len(bdf),
        'MAX_ENTRY_METADATA_ONLY':True,
        'MAX_ENTRY_METADATA':MAX_ENTRY_METADATA,
        'OUTPUT_LINEUP_QUOTA':None,
        'FORCED_BOARD_SIZE':False,
        'FINAL_BOARD':bdf.to_dict('records'),
        'AI_TERMINAL_AUTHORITY_REQUIRED':False,
        'ENGINE_TERMINAL_AUTHORITY':True,
        'AI_TERMINAL_PATCH_ID':'DISABLED_ENGINE_ONLY',
        'AI_TERMINAL_CANDIDATE_SURFACE_PATH':'',
        'AI_TERMINAL_CANDIDATE_RECEIPT_PATH':'',
        'AI_TERMINAL_CANDIDATE_FREEZE_SHA256':'',
        'AI_TERMINAL_CANDIDATE_COUNT':0,
        'SELECTOR_REVIEWED_LINEUPS':len(cands),
        'STATE_VERSION':str(os.environ.get('APEX_GLOBAL_STATE_VERSION') or ''),
        'INPUT_SHA256':sha_file(POOL_PATH),
        'POLICY_SHA256':str(os.environ.get('APEX_POLICY_SHA256') or ''),
        'AI_TERMINAL_NO_PRUNING':False,
        'MULTI_SEED_PATCH_ID':_ai_receipt.get('MULTI_SEED_PATCH_ID'),
        'MULTI_SEED_CONVERGENCE_STATUS':(_ai_receipt.get('MULTI_SEED_CONVERGENCE') or {}).get('STATUS'),
        'MULTI_SEED_ROUNDS_EXECUTED':int((_ai_receipt.get('MULTI_SEED_CONVERGENCE') or {}).get('ROUNDS_EXECUTED',0) or 0),
        'MULTI_SEED_EXTRA_WORLD_TRIALS_TOTAL':int((_ai_receipt.get('MULTI_SEED_CONVERGENCE') or {}).get('EXTRA_WORLD_TRIALS_TOTAL',0) or 0),
        'MULTI_SEED_UNRESOLVED_BOUNDARY_LINEUPS':int((_ai_receipt.get('MULTI_SEED_CONVERGENCE') or {}).get('UNRESOLVED_BOUNDARY_LINEUPS',0) or 0),
    }, indent=2), flush=True)
    sborn=set(born.tolist()); sh=set(h.tolist()); sboard=set(board.tolist())
    wi=None
    if WINNER is not None:
        winner=[i for i in range(len(lineups)) if lkey(i,meta)==(WINNER['CPT'],WINNER['UTILS'])]; wi=winner[0] if winner else None
        trace=dict(EVALUATED=True,LEGAL=wi is not None,LINEUP_INDEX=int(wi) if wi is not None else None,SALARY=int(meta['salary'][wi]) if wi is not None else None,BRANCH=meta['branch'][wi] if wi is not None else None,ROUTE=meta['route'][wi] if wi is not None else None,RP_COUNT=int(meta['rp_count'][wi]) if wi is not None else None,SP_CPT_5_1_CLOSURE=bool(meta['lane_sp_cpt_51'][wi]) if wi is not None else None,LOW_OWN_SPEED_RUNBACK=bool(meta['lane_sp_cpt_51_speed'][wi]) if wi is not None else None,SP_CPT_CONTROL_5_1=bool(meta['lane_sp_cpt_control_51'][wi]) if wi is not None else None,CONTROL_SPEED_RUNBACK=bool(meta['lane_sp_cpt_control_51_speed'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND=bool(meta['lane_hitter_cpt_speed_low_spend'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2=bool(meta['lane_hitter_cpt_speed_low_spend_42'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE=bool(meta['lane_hitter_cpt_speed_low_spend_42_release'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL=bool(meta['lane_hitter_cpt_speed_low_spend_42_control'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][wi]) if wi is not None else None,HITTER_CPT_SAME_TEAM_SP_CONTROL=bool(meta['lane_hitter_cpt_same_team_sp_control'][wi]) if wi is not None else None,HITTER_CPT_FAVORITE_5_1_SP_OPP_PUNT=bool(meta['lane_hitter_cpt_favorite_51_sp_opp_punt'][wi]) if wi is not None else None,HITTER_CPT_FAVORITE_4_2_SP_RP=bool(meta['lane_hitter_cpt_favorite_42_sp_rp'][wi]) if wi is not None else None,HITTER_CPT_UNDERDOG_5_1_SP_SINGLE_RP=bool(meta['lane_hitter_cpt_underdog_51_sp_single_rp'][wi]) if wi is not None else None,HITTER_CPT_FAVORITE_5_1_SP_CONTACT_CORE=bool(meta['lane_hitter_cpt_favorite_51_sp_contact_core'][wi]) if wi is not None else None,HITTER_CPT_FAVORITE_4_2_SP_RP_UNCERTAIN_CONTACT=bool(meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'][wi]) if wi is not None else None,HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK=bool(meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'][wi]) if wi is not None else None,PRIMARY_RELEASE_PLAYER=(meta['names'][meta['primary_release_player'][wi]] if wi is not None and meta['primary_release_player'][wi]>=0 else None),PRIMARY_RP_PLAYER=(meta['names'][meta['primary_rp_player'][wi]] if wi is not None and meta['primary_rp_player'][wi]>=0 else None),PHASE2_BORN=wi in sborn if wi is not None else False,HANDOFF_SURVIVED=wi in sh if wi is not None else False,SELECTED_TO_BOARD=wi in sboard if wi is not None else False,BOARD_RANK=int(np.where(board==wi)[0][0]+1) if wi is not None and wi in sboard else None)
        if wi is not None and wi in sh:
            q=np.where(h==wi)[0][0]; trace['FINAL_METRICS']={k:float(fm[k][q]) for k in fm}; trace['HANDOFF_RANK_BY_TOP01']=int((-fm['top01']).argsort(kind='mergesort').tolist().index(q)+1)
    else:
        trace={'EVALUATED':False,'REASON':'FORWARD_BLIND_RESULTS_UNAVAILABLE'}
    bp=OUT/f'DK_MLB_SD_{EXECUTION_ID}_FINAL_BOARD.csv'; bdf.to_csv(bp,index=False); board_hash_pre_postlock=sha_file(bp)
    if CONTEST_FILE:
        audit_path=OUT/f'DK_MLB_SD_{EXECUTION_ID}_POSTLOCK_CONTEST_RANK_AUDIT.csv'
        _,postlock_audit=evaluate_board(bdf,CONTEST_FILE,audit_path)
        postlock_audit['AUDIT_PATH']=str(audit_path); postlock_audit['BOARD_HASH_FROZEN_BEFORE_AUDIT']=board_hash_pre_postlock; postlock_audit['BOARD_HASH_AFTER_AUDIT']=sha_file(bp); postlock_audit['BOARD_HASH_UNCHANGED']=postlock_audit['BOARD_HASH_FROZEN_BEFORE_AUDIT']==postlock_audit['BOARD_HASH_AFTER_AUDIT']
    else:
        postlock_audit={'STATUS':'NOT_PROVIDED','ACTUAL_RESULTS_USED_BY_SELECTOR':False,'BOARD_HASH_FROZEN_BEFORE_AUDIT':board_hash_pre_postlock}
    manifest=pd.DataFrame(dict(
        LINEUP_INDEX=born,CPT=[meta['names'][meta['cpt'][i]] for i in born],UTILS=['|'.join(meta['names'][meta['idx'][i,1:]]) for i in born],
        SALARY=meta['salary'][born],BRANCH=meta['branch'][born],ROUTE=meta['route'][born],RP_COUNT=meta['rp_count'][born],
        SP_CPT_5_1_CLOSURE=meta['lane_sp_cpt_51'][born],LOW_OWN_SPEED_RUNBACK=meta['lane_sp_cpt_51_speed'][born],SP_CPT_CONTROL_5_1=meta['lane_sp_cpt_control_51'][born],CONTROL_SPEED_RUNBACK=meta['lane_sp_cpt_control_51_speed'][born],
        HITTER_CPT_SPEED_LOW_SPEND=meta['lane_hitter_cpt_speed_low_spend'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2=meta['lane_hitter_cpt_speed_low_spend_42'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE=meta['lane_hitter_cpt_speed_low_spend_42_release'][born],
        HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL=meta['lane_hitter_cpt_speed_low_spend_42_control'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER=meta['lane_hitter_cpt_speed_low_spend_42_counter'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2=meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][born],
        HITTER_CPT_SAME_TEAM_SP_CONTROL=meta['lane_hitter_cpt_same_team_sp_control'][born],HITTER_CPT_FAVORITE_5_1_SP_OPP_PUNT=meta['lane_hitter_cpt_favorite_51_sp_opp_punt'][born],HITTER_CPT_FAVORITE_4_2_SP_RP=meta['lane_hitter_cpt_favorite_42_sp_rp'][born],HITTER_CPT_UNDERDOG_5_1_SP_SINGLE_RP=meta['lane_hitter_cpt_underdog_51_sp_single_rp'][born],
        HITTER_CPT_FAVORITE_5_1_SP_CONTACT_CORE=meta['lane_hitter_cpt_favorite_51_sp_contact_core'][born],HITTER_CPT_FAVORITE_4_2_SP_RP_UNCERTAIN_CONTACT=meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'][born],HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK=meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'][born],
        PRIMARY_RELEASE_PLAYER=[meta['names'][meta['primary_release_player'][i]] if meta['primary_release_player'][i]>=0 else '' for i in born],PRIMARY_RP_PLAYER=[meta['names'][meta['primary_rp_player'][i]] if meta['primary_rp_player'][i]>=0 else '' for i in born],
        BASE_MC_WIN_RATE=bm['win'],BASE_MC_TOP_0_1_RATE=bm['top01'],BASE_MC_TOP10_RATE=bm['top10'],BASE_MC_P95=bm['p95'],BASE_MC_P99=bm['p99']))
    mp=OUT/f'DK_MLB_SD_{EXECUTION_ID}_PHASE2_MANIFEST.csv'; manifest.to_csv(mp,index=False)
    control_trigger=int(meta['lane_sp_cpt_control_51_speed'].sum())>=2
    hitter_trigger=int(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'].sum())>=2
    stress=dict(
                PHASE2_HANDOFF_SELECTOR_PARITY=(len(born)==len(h)==len(cands)),
                PHASE1_CALIBRATION_HASH_CHAIN_PARITY=calibration_freeze.hash_chain_parity(calibration_chain,calibration_seal.sha256),
                RELIEF_PITCHER_DNP_MASS_EXPLICIT=True,
                NO_POST_PHASE2_MUTATION=True,RAW_AGGREGATE_PHASE1_REJECTION=True,NO_FILLERS_USED=True,NO_RANK_ALL_USED=True,
                MILP_OPTIMAL=bool(res.success),
                ELITE_TAIL_RANK1_PRESERVED=(len(board)>0 and len(selected)>0 and int(board[0])==int(selected[int(np.argmax(rank_components['family_score']))])),
                NO_CERTIFIED_FAMILY_FORCE_IN_SELECTOR=True,
                TOP10_NOT_SELECTOR_OBJECTIVE=True,
                ELITE_CORE_SIBLING_PROTECTION_BOUNDED=(int(sibling_receipt.get('PROTECTED_GROUP_COUNT',0) or 0)<=3),
                OWNERSHIP_CALIBRATED_FAKE_FIELD=bool(_LAST_FIELD_RECEIPT.get('SOURCE')=='BLIND_RST_OWNERSHIP_ONLY'),
                FAKE_FIELD_DUAL_SP_TARGET_MATCH=abs(_LAST_FIELD_RECEIPT.get('ACTUAL_DUAL_SP_SHARE',0)-_LAST_FIELD_RECEIPT.get('TARGET_DUAL_SP_SHARE',0))<=0.02,
                FAKE_FIELD_SP_CPT_TARGET_MATCH=abs(_LAST_FIELD_RECEIPT.get('ACTUAL_SP_CPT_SHARE',0)-_LAST_FIELD_RECEIPT.get('TARGET_SP_CPT_SHARE',0))<=0.02,
                CONTEST_FINISH_RANKER_OUTPUT=all(c in bdf.columns for c in ['MC_TOP10_RATE','MC_TOP10_LCB','MC_TOP_0_1_LCB','MC_WIN_LCB','FAMILY_MC_TOP_0_1_RATE','FAMILY_MC_WIN_RATE','PROJECTED_EXACT_MATCH_DUPLICATION','CONTEST_FINISH_SCORE','BOARD_ORDER_REASON']),
                CERTIFIED_FAMILY_PODIUM_ORDERING=certified_podium_ordering_ok(bdf.BOARD_ORDER_REASON,False,False),
                POSTLOCK_AUDIT_SELECTOR_ISOLATION=bool(postlock_audit.get('ACTUAL_RESULTS_USED_BY_SELECTOR') is False))
    if WINNER is not None:
        stress.update(WINNER_BIRTH_RECALL=trace['PHASE2_BORN'],WINNER_HANDOFF_RECALL=trace['HANDOFF_SURVIVED'],WINNER_BOARD_CAPTURE=trace['SELECTED_TO_BOARD'])
    reservoir_ids=sorted(set(meta['idx'].ravel().tolist())); reservoir_non_rp=sum(not players[i]['is_rp'] for i in reservoir_ids); scanned=int(reservoir_non_rp*math.comb(max(0,len(reservoir_ids)-1),5))
    _birth_ledger=OUT/f'DK_MLB_SD_{EXECUTION_ID}_BIRTH_LINEAGE.txt'; _birth_ledger.write_text('\n'.join(map(str,map(int,born)))+'\n',encoding='utf-8')
    _qual_ledger=OUT/f'DK_MLB_SD_{EXECUTION_ID}_QUALIFICATION_LINEAGE.txt'; _qual_ledger.write_text('\n'.join(map(str,map(int,h)))+'\n',encoding='utf-8')
    _selector_ledger=OUT/f'DK_MLB_SD_{EXECUTION_ID}_SELECTOR_LINEAGE.txt'; _selector_ledger.write_text('\n'.join(map(str,map(int,cands)))+'\n',encoding='utf-8')
    receipt=dict(
        BUILD_TARGET='FIELD_RELATIVE_DOT00001',CHAT_EXECUTION_AUTHORITY=False,ENGINE_LINEUP_BUILDER_PATCH_ID='APEX_ENGINE_LINEUP_BUILDER_CANONICAL_v1',NOTION_AUTHORITY_RECEIPT_SHA256=str(os.environ.get('APEX_NOTION_AUTHORITY_RECEIPT_SHA256','')),MC_WORLDS=PHASE1_TRIALS,PUBLIC_FIELD_SIMS=FAKE_FIELD,FULL_ENUMERATION_COMPLETE=True,LEGAL_PATH_COUNT=len(lineups),SCORED_PATH_COUNT=len(cands),PHASE2_BUILT_LINEUPS=len(born),SELECTOR_REVIEWED_LINEUPS=len(cands),LINEAGE_LEDGER_PATHS={'BIRTH':str(_birth_ledger),'QUALIFICATION':str(_qual_ledger),'SELECTOR':str(_selector_ledger)},INPUT_SHA256=sha_file(POOL_PATH),
        PATCH_ID=PATCH_ID,PRODUCTION_MC_PATCH_ID=PRODUCTION_MC_PATCH_ID,PORTFOLIO_UNION_SELECTOR_PATCH_ID=PORTFOLIO_UNION_SELECTOR_PATCH_ID,SELF_CONFLICT_GATE_PATCH_ID=SELF_CONFLICT_GATE_PATCH_ID,DIVERSITY_PATCH_ID=DIVERSITY_PATCH_ID,RP_RESTORE_PATCH_ID=RP_RESTORE_PATCH_ID,FIELD_SELECTOR_REPAIR_PATCH_ID=FIELD_SELECTOR_REPAIR_PATCH_ID,DUAL_SP_TROPHY_POSTERIOR_PATCH_ID=DUAL_SP_TROPHY_POSTERIOR_PATCH_ID,HR_PROBABILITY_PARITY_PATCH_ID=HR_PROBABILITY_PARITY_PATCH_ID,ELITE_CORE_SIBLING_PATCH_ID=ELITE_CORE_SIBLING_PATCH_ID,ENGINE_ID=ENGINE_ID,PRODUCTION_TRIGGER_DIRECT_EXECUTION='PASS',DIAGNOSTIC_ROUTING='DISABLED',BOARD_FIRST_RENDERING='PASS',BOARD_IDENTITY_RECONCILIATION='PASS',MODE='PRODUCTION_FORWARD_BLIND',EXECUTION_ID=EXECUTION_ID,FIELD_SIZE=FIELD_SIZE,
        TT_MC_PATCH_ID=TT_MC_PATCH_ID,TT_MC_RECEIPT=_LAST_MC_ENV_RECEIPT,PREDICTIVE_LAYER_PATCH_ID=_LAST_STRATEGY_RECEIPT['PREDICTIVE_LAYER_PATCH_ID'],PREDICTIVE_LAYER_STATUS=_LAST_STRATEGY_RECEIPT['PREDICTIVE_LAYER_STATUS'],PREDICTION_HASH=_LAST_STRATEGY_RECEIPT['PREDICTION_HASH'],RAW_MARKET_INPUT_HASH=_LAST_STRATEGY_RECEIPT['RAW_MARKET_INPUT_HASH'],PLAYER_MARKET_ROWS=_LAST_STRATEGY_RECEIPT['PLAYER_MARKET_ROWS'],GAME_MARKET_ROWS=_LAST_STRATEGY_RECEIPT['GAME_MARKET_ROWS'],MORE_DECISIONS=_LAST_STRATEGY_RECEIPT['MORE_DECISIONS'],LESS_DECISIONS=_LAST_STRATEGY_RECEIPT['LESS_DECISIONS'],PASS_DECISIONS=_LAST_STRATEGY_RECEIPT['PASS_DECISIONS'],STALE_LINE_SIGNALS=_LAST_STRATEGY_RECEIPT['STALE_LINE_SIGNALS'],PREDICTION_FROZEN=_LAST_STRATEGY_RECEIPT['PREDICTION_FROZEN'],STRATEGY_CONSUMED_PREDICTION_HASH=_LAST_STRATEGY_RECEIPT['STRATEGY_CONSUMED_PREDICTION_HASH'],MLB_HITTER_ATTACKABLE_PA_PATCH_ID=attackable_pa_mod.PATCH_ID,ATTACKABLE_PA_RECEIPT=_LAST_ATTACKABLE_PA_RECEIPT,
        PHASE0=dict(RAW_ROWS=len(raw),ACTIVE_POOL=len(pool),OUT_PURGE=len(raw)-len(pool),CANDIDATE_RESERVOIR_PLAYERS=len(reservoir_ids),STARTERS=[p['name'] for p in players if p['is_sp']],RELIEF_PITCHERS_ACTIVE=[p['name'] for p in players if p['is_rp']],RELIEF_PITCHERS_QUALIFIED=qualified_rps,RP_QUALIFICATION={p['name']:list(p.get('rp_qual_reasons',())) for p in players if p['is_rp']},RP_ROLE_EVIDENCE={p['name']:{'APPEARANCE_PROB':p['role_prob'],'EVIDENCE_GRADE':p.get('role_evidence_grade')} for p in players if p['is_rp']},BULK_ROLE_PITCHERS_ACTIVE=[p['name'] for p in players if p.get('is_bulk')],RELIEF_PITCHERS_RESERVOIR=[players[i]['name'] for i in reservoir_ids if players[i]['is_rp']],FORBIDDEN_AGGREGATES_REJECTED=[c for c in FORBIDDEN if c in raw.columns]),
        FAKE_FIELD=dict(_LAST_FIELD_RECEIPT),RAW_RST_FIELD_OWNERSHIP=field_ownership,FROZEN_SLATE_CONTEXT=frozen_slate_context.as_dict(),FROZEN_SLATE_CONTEXT_SHA256=slate_context_seal,SLATE_CONTEXT_PATCH_ID=SLATE_CONTEXT_PATCH_ID,
        PHASE1=dict(MC_ITERATIONS=PHASE1_TRIALS,STREAMING_PATCH_ID=STREAMING_PATCH_ID,MC_TRIAL_CHUNK=MC_TRIAL_CHUNK,MC_CHECKPOINT_ENABLED=MC_CHECKPOINT_ENABLED,STREAMING_RECEIPTS=_LAST_STREAMING_RECEIPTS,RAW_AGGREGATE_PROJECTIONS_USED=False,RELIEF_PITCHER_DNP_MASS_EXPLICIT=True,BULLPEN_ROLE_PATCH_ID=BULLPEN_ROLE_PATCH_ID,RP_APPEARANCE_OWNERSHIP_INDEPENDENT=True,PLAYER_MATRIX_SHA256=calibration_seal.sha256,CALIBRATION_FROZEN=True,MIDRUN_RECALIBRATION_PROHIBITED=True,CALIBRATION_FREEZE_PATCH_ID=CALIBRATION_FREEZE_PATCH_ID),
        CAPTAIN_ELIGIBILITY=captain_receipt,PRELOCK_MARKET_CONTEXT=prelock_market_context,CAPTAIN_ELIGIBILITY_PATCH_ID=CAPTAIN_ELIGIBILITY_PATCH_ID,SINGLE_RP_FULL_VISIBILITY_PATCH_ID=SINGLE_RP_FULL_VISIBILITY_PATCH_ID,UNDERDOG_VALUE_CPT_51_SINGLE_RP_PATCH_ID=UNDERDOG_VALUE_CPT_51_SINGLE_RP_PATCH_ID,BARGAIN_CORE5_SELECTOR_PATCH_ID=BARGAIN_CORE5_SELECTOR_PATCH_ID,GLOBAL_CORE_PROTECTION_KEY_PARITY_PATCH_ID=GLOBAL_CORE_PROTECTION_KEY_PARITY_PATCH_ID,HIGH_MARKET_SP_CPT_42_BIRTH_PATCH_ID=HIGH_MARKET_SP_CPT_42_BIRTH_PATCH_ID,SP_CPT_DUAL_SP_ATTACK_HEDGE_PATCH_ID=SP_CPT_DUAL_SP_ATTACK_HEDGE_PATCH_ID,CHAMPIONSHIP_CORE_CAPTAIN_PROMOTION_PATCH_ID=CHAMPIONSHIP_CORE_CAPTAIN_PROMOTION_PATCH_ID,CROSS_BRANCH_FIVE_PLAYER_FAMILY_CLOSURE_PATCH_ID=CROSS_BRANCH_FIVE_PLAYER_FAMILY_CLOSURE_PATCH_ID,CROSS_BRANCH_SUPERANCHOR_CORE5_PATCH_ID=CROSS_BRANCH_SUPERANCHOR_CORE5_PATCH_ID,
        CALIBRATION_HASH_CHAIN=dict(calibration_chain),CALIBRATION_HASH_CHAIN_PARITY=calibration_freeze.hash_chain_parity(calibration_chain,calibration_seal.sha256),
        PHASE2=dict(EXPECTED_RESERVOIR_SEARCH_SPACE=scanned,SCANNED_COMBINATIONS=scanned,LEGAL_LINEUPS_PRE_SELF_CONFLICT=len(all_lineups),LEGAL_LINEUPS_FOUND=len(lineups),SELF_CONFLICT_GATE=conflict_gate_receipt,SIDE_COMMITMENT_GATE=side_commitment_gate_receipt,SELF_CONFLICT_SOFT_FRICTION_LINEUPS=int((meta['self_conflict_penalty']>0).sum()),COHERENT_5_1_HITTER_RUNBACK_LINEUPS=int(meta['coherent_five_one_hitter_runback'].sum()),PREMIUM_ONEOFF_HITTER_LINEUPS=int(meta['premium_oneoff_hitter'].sum()),PHASE2_BUILT_LINEUPS=len(born),CALIBRATION_REJECTED_LINEUPS=0,FULL_LEGAL_SCAN_COMPLETE=True,CANDIDATE_RESERVOIR_SCAN_COMPLETE=True,LANE_COUNTS=lane_counts,
          SP_CPT_5_1_LEGAL=int(meta['lane_sp_cpt_51'].sum()),SP_CPT_5_1_SPEED_LEGAL=int(meta['lane_sp_cpt_51_speed'].sum()),SP_CPT_CONTROL_5_1_LEGAL=int(meta['lane_sp_cpt_control_51'].sum()),SP_CPT_CONTROL_5_1_SPEED_LEGAL=int(meta['lane_sp_cpt_control_51_speed'].sum()),HIGH_HIGH_SP_CPT_CONTROL_4_2_LEGAL=int(meta['lane_sp_cpt_control_42_mid_top5'].sum()),
          HITTER_CPT_SPEED_LOW_SPEND_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_release'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_control'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_counter'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'].sum()),
          HITTER_CPT_SAME_TEAM_SP_CONTROL_LEGAL=int(meta['lane_hitter_cpt_same_team_sp_control'].sum()),HITTER_CPT_FAVORITE_5_1_SP_OPP_PUNT_LEGAL=int(meta['lane_hitter_cpt_favorite_51_sp_opp_punt'].sum()),HITTER_CPT_FAVORITE_4_2_SP_RP_LEGAL=int(meta['lane_hitter_cpt_favorite_42_sp_rp'].sum()),HITTER_CPT_UNDERDOG_5_1_SP_SINGLE_RP_LEGAL=int(meta['lane_hitter_cpt_underdog_51_sp_single_rp'].sum()),PHASE2_MANIFEST_SHA256=sha_file(mp)),
          MIXED_SP_RP_LEGAL=int(meta['lane_mixed_sp_rp'].sum()),SP2_RP1_LEGAL=int(meta['lane_sp2_rp1'].sum()),LOW_OWN_RP_LEGAL=int(meta['lane_low_owned_rp'].sum()),
          HITTER_CPT_FAVORITE_5_1_SP_CONTACT_CORE_LEGAL=int(meta['lane_hitter_cpt_favorite_51_sp_contact_core'].sum()),HITTER_CPT_FAVORITE_4_2_SP_RP_UNCERTAIN_CONTACT_LEGAL=int(meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'].sum()),HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK_LEGAL=int(meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'].sum()),
        HANDOFF=dict(INPUT_BORN=len(born),SURVIVORS=len(h),STRUCTURAL_RESERVE_ADDITIONS=reserve,BASE_SIM_TRIALS=BASE_TRIALS,EXTRA_SIM_TRIALS_PER_HANDOFF=EXTRA_TRIALS,BUBBLE_EXTRA_TRIALS_TOTAL=int(len(deep_set)*EXTRA_TRIALS)+int((_ai_receipt.get('MULTI_SEED_CONVERGENCE') or {}).get('EXTRA_LINEUP_TRIAL_EVALUATIONS',0) or 0),BUBBLE_LINEUPS_EXTRA_SIM=int(len(deep_set)),BUBBLE_LINEUPS_UNRESOLVED=int((_ai_receipt.get('MULTI_SEED_CONVERGENCE') or {}).get('UNRESOLVED_BOUNDARY_LINEUPS',0) or 0),MULTI_SEED_EXTRA_WORLD_TRIALS_TOTAL=int((_ai_receipt.get('MULTI_SEED_CONVERGENCE') or {}).get('EXTRA_WORLD_TRIALS_TOTAL',0) or 0),MULTI_SEED_PATCH_ID=_ai_receipt.get('MULTI_SEED_PATCH_ID'),MULTI_SEED_CONVERGENCE_STATUS=(_ai_receipt.get('MULTI_SEED_CONVERGENCE') or {}).get('STATUS'),PHASE2_HANDOFF_PARITY=len(born)==len(h)),
        SELECTOR=dict(REVIEWED_LINEUPS=len(cands),FINAL_BOARD_SIZE=len(board),MILP_STATUS=int(res.status),MILP_MESSAGE=res.message,PHASE2_SELECTOR_REVIEW_PARITY=len(born)==len(cands),RAW_PROJECTIONS_EXPOSED=False,FILLERS_USED=False,RANK_ALL_USED=False,BOARD_ORDER_METHOD=RANKER_ID,CONTEST_FINISH_RANKER_PATCH=RANKER_PATCH_ID,TOP10_EQUIV_FIELD_CUTOFF=TOP10_EQUIV_CUTOFF,TAIL_QUANTILE_METHOD='EMPIRICAL_FIELD_TOP01_WIN_PLUS_COMMON_WORLD_PORTFOLIO_UNION',RANK1_DIVERSIFICATION_PROTECTED=True,ELITE_CORE_SIBLING_PROTECTION=sibling_receipt,CODE_SELECTOR_ROLE='TERMINAL_ENGINE_AUTHORITY',AI_TERMINAL_PATCH_ID='DISABLED_ENGINE_ONLY',AI_TERMINAL_CANDIDATES=len(_ai_rows),AI_TERMINAL_CANDIDATE_FREEZE_SHA256=_ai_receipt['CANDIDATE_FREEZE_SHA256'],MULTI_SEED_PATCH_ID=_ai_receipt.get('MULTI_SEED_PATCH_ID'),MULTI_SEED_CONVERGENCE=_ai_receipt.get('MULTI_SEED_CONVERGENCE'),S1_LIVE_CANARY_RECEIPT=(_s1_canary.get('RECEIPT_PATH') if _s1_canary else None),S1_LIVE_CANARY_SHA256=(_s1_canary.get('RECEIPT_SHA256') if _s1_canary else None),S1_LIVE_CANARY_SELECTION_AUTHORITY=False),
        POSTLOCK_CONTEST_ORDER_AUDIT=postlock_audit,WINNER_TRACE_POSTSEAL_ONLY=trace,STRESS=stress,ARTIFACTS=dict(BOARD=str(bp),PHASE2_MANIFEST=str(mp),AI_TERMINAL_CANDIDATES='',AI_TERMINAL_CANDIDATES_RECEIPT='',S1_LIVE_CANARY_RECEIPT=(_s1_canary.get('RECEIPT_PATH') if _s1_canary else None),S1_LIVE_CANARY_SELECTED=(_s1_canary.get('SELECTED_PATH') if _s1_canary else None),S1_LIVE_CANARY_AUDIT=(_s1_canary.get('AUDIT_PATH') if _s1_canary else None)),BOARD_SHA256=sha_file(bp))
    rp=OUT/f'DK_MLB_SD_{EXECUTION_ID}_FINAL_RECEIPT.json'; rp.write_text(json.dumps(receipt,indent=2),encoding='utf-8'); receipt['RECEIPT_SHA256']=sha_file(rp); rp.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(dict(STATUS='PASS' if all(stress.values()) else 'FAIL',LEGAL=len(lineups),BORN=len(born),HANDOFF=len(h),CANDIDATES=len(cands),WINNER_TRACE=trace,BOARD=bdf.to_dict('records')),indent=2))
if __name__=='__main__': run()

# Immutable promotion seal: active-state rebase 1.20.1 -> 1.21.0.
# Immutable promotion seal: active-state rebase 1.20.2 -> 1.21.1.
# Immutable promotion seal: active-state rebase 1.21.0 -> 1.21.1.
