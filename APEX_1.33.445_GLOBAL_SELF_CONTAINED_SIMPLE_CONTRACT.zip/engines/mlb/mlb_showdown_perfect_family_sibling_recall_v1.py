from __future__ import annotations

from collections import defaultdict
from itertools import combinations
from typing import Any, Dict, Iterable, List, Sequence, Tuple
import math
import numpy as np

PATCH_ID = 'MLB_SD_PERFECT_FAMILY_SIBLING_RECALL_v1'


def _roster_key(row: Sequence[int]) -> Tuple[int, ...]:
    return tuple(sorted(map(int, row)))


def select_dominant_five_player_family(
    candidate_local_ids: Sequence[int],
    rosters: np.ndarray,
    confidence: Sequence[float],
    top01: Sequence[float],
    p99: Sequence[float],
    cpt_ids: Sequence[int],
    *,
    max_siblings: int = 2,
    min_relative_confidence: float = 0.82,
    min_relative_p99: float = 0.92,
    min_relative_top01: float = 0.60,
) -> Tuple[List[int], Dict[str, Any]]:
    """Return up to two high-confidence siblings from the strongest 5-player core.

    This is an identity-free, prelock-only family recall helper.  A family is a
    five-player intersection shared by multiple legal Showdown lineups.  It can
    represent either a CPT-role sibling on the same six-player roster or a
    one-player secondary swap around a stable five-player championship core.

    Family breadth alone never earns a seat.  The second sibling must remain
    close to the family's best member on the frozen prelock confidence, P99 and
    Top-0.1 metrics.  The caller may impose an additional board-level replacement
    floor so family concentration can never weaken the five-leg parlay.
    """
    ids = [int(x) for x in candidate_local_ids]
    if len(ids) < 2:
        return [], {
            'PATCH_ID': PATCH_ID,
            'TRIGGERED': False,
            'REASON': 'INSUFFICIENT_CANDIDATES',
            'POSTLOCK_INPUT_USED': False,
            'PLAYER_NAME_CONSTANTS_USED': False,
        }

    r = np.asarray(rosters, dtype=np.int32)
    conf = np.asarray(confidence, dtype=float)
    t01 = np.asarray(top01, dtype=float)
    p = np.asarray(p99, dtype=float)
    cpt = np.asarray(cpt_ids, dtype=np.int32)

    families: Dict[Tuple[int, ...], List[int]] = defaultdict(list)
    for j in ids:
        roster = tuple(sorted(map(int, r[j, :6])))
        if len(set(roster)) != 6:
            continue
        for core in combinations(roster, 5):
            families[tuple(core)].append(j)

    evaluated = []
    for core, members0 in families.items():
        members = sorted(set(map(int, members0)), key=lambda j: (-float(conf[j]), -float(t01[j]), -float(p[j]), j))
        if len(members) < 2:
            continue
        best = members[0]
        qualified = [best]
        best_conf = max(float(conf[best]), 1e-12)
        best_t01 = max(float(t01[best]), 1e-12)
        best_p99 = max(float(p[best]), 1e-12)
        for j in members[1:]:
            if float(conf[j]) + 1e-12 < float(min_relative_confidence) * best_conf:
                continue
            if float(p[j]) + 1e-12 < float(min_relative_p99) * best_p99:
                continue
            if float(t01[j]) + 1e-12 < float(min_relative_top01) * best_t01:
                continue
            qualified.append(int(j))
        if len(qualified) < 2:
            continue

        # Require a real sibling relationship: CPT uncertainty or a one-piece
        # secondary swap.  Duplicate rows do not create family evidence.
        best_roster = _roster_key(r[best, :6])
        variant = [j for j in qualified[1:] if int(cpt[j]) != int(cpt[best]) or _roster_key(r[j, :6]) != best_roster]
        if not variant:
            continue
        variant = sorted(variant, key=lambda j: (-float(conf[j]), -float(t01[j]), -float(p[j]), j))
        second = int(variant[0])
        family_confidence = math.sqrt(max(float(conf[best]), 1e-12) * max(float(conf[second]), 1e-12))
        ordered_family = [int(best)] + [int(j) for j in variant]
        evaluated.append((family_confidence, min(float(t01[best]), float(t01[second])), min(float(p[best]), float(p[second])), len(qualified), core, ordered_family, qualified))

    if not evaluated:
        return [], {
            'PATCH_ID': PATCH_ID,
            'TRIGGERED': False,
            'REASON': 'NO_HIGH_CONFIDENCE_FIVE_PLAYER_SIBLING_FAMILY',
            'POSTLOCK_INPUT_USED': False,
            'PLAYER_NAME_CONSTANTS_USED': False,
        }

    evaluated.sort(key=lambda x: (-x[0], -x[1], -x[2], -x[3], x[4]))
    fam_conf, fam_t01, fam_p99, breadth, core, ordered_family, qualified = evaluated[0]
    chosen = list(map(int, ordered_family[: max(1, int(max_siblings))]))
    return chosen, {
        'PATCH_ID': PATCH_ID,
        'TRIGGERED': True,
        'CORE_PLAYER_IDS': [int(x) for x in core],
        'QUALIFIED_SIBLING_COUNT': int(breadth),
        'SELECTED_LOCAL_IDS': list(chosen),
        'FAMILY_CONFIDENCE_GEOMEAN': float(fam_conf),
        'FAMILY_WORST_TOP01': float(fam_t01),
        'FAMILY_WORST_P99': float(fam_p99),
        'MAX_SIBLINGS': int(max_siblings),
        'MIN_RELATIVE_CONFIDENCE': float(min_relative_confidence),
        'MIN_RELATIVE_P99': float(min_relative_p99),
        'MIN_RELATIVE_TOP01': float(min_relative_top01),
        'FAMILY_DEFINITION': 'FIVE_PLAYER_INTERSECTION_CPT_OR_ONE_PIECE_SIBLING',
        'POSTLOCK_INPUT_USED': False,
        'PLAYER_NAME_CONSTANTS_USED': False,
    }
