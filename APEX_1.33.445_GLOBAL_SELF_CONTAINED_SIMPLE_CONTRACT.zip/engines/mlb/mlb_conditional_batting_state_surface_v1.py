from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence
import math
import numpy as np

PATCH_ID = "MLB_CONDITIONAL_BATTING_STATE_SURFACE_v1"
EVENTS = ("BB", "HBP", "K", "1B", "2B", "3B", "HR", "OUT")
EVENT_INDEX = {x: i for i, x in enumerate(EVENTS)}

DEFAULT_DK_RULES = {
    "1B": 3.0, "2B": 5.0, "3B": 8.0, "HR": 10.0,
    "BB": 2.0, "HBP": 2.0, "R": 2.0, "RBI": 2.0,
}
DEFAULT_ADVANCEMENT = {
    "SINGLE_R2_SCORE": 0.60,
    "SINGLE_R1_TO_3": 0.30,
    "DOUBLE_R1_SCORE": 0.55,
}


class MLBStateError(RuntimeError):
    pass


@dataclass(frozen=True)
class MLBTeamBattingSurface:
    player_fpts: np.ndarray      # trials x hitters
    team_runs: np.ndarray        # trials
    plate_appearances: np.ndarray  # trials x hitters
    event_counts: np.ndarray     # trials x hitters x events
    receipt: dict


def _prob_matrix(base_event_probabilities: np.ndarray) -> np.ndarray:
    p = np.asarray(base_event_probabilities, dtype=np.float64)
    if p.ndim != 2 or p.shape[1] != len(EVENTS) or p.shape[0] < 1:
        raise MLBStateError(f"EVENT_PROBABILITY_SHAPE_INVALID:{p.shape}")
    if np.any(~np.isfinite(p)) or np.any(p < 0):
        raise MLBStateError("INVALID_EVENT_PROBABILITIES")
    s = p.sum(axis=1)
    if np.any(s <= 0):
        raise MLBStateError("ZERO_EVENT_PROBABILITY_ROW")
    return p / s[:, None]


def _force_walk(bases: list[int], batter: int) -> tuple[list[int], list[int]]:
    # bases = [first, second, third], -1 empty. Return new bases, scoring runner ids.
    b1, b2, b3 = bases
    scored: list[int] = []
    if b1 != -1 and b2 != -1 and b3 != -1:
        scored.append(b3); b3 = b2; b2 = b1; b1 = batter
    elif b1 != -1 and b2 != -1:
        b3 = b2; b2 = b1; b1 = batter
    elif b1 != -1:
        b2 = b1; b1 = batter
    else:
        b1 = batter
    return [b1, b2, b3], scored


def _transition_hit(
    bases: list[int], batter: int, event: str, rng: np.random.Generator, advancement: Mapping[str, float]
) -> tuple[list[int], list[int]]:
    b1, b2, b3 = bases
    scored: list[int] = []
    if event == "HR":
        scored.extend([x for x in (b1, b2, b3) if x != -1]); scored.append(batter)
        return [-1, -1, -1], scored
    if event == "3B":
        scored.extend([x for x in (b1, b2, b3) if x != -1])
        return [-1, -1, batter], scored
    if event == "2B":
        if b3 != -1: scored.append(b3)
        if b2 != -1: scored.append(b2)
        new3 = -1
        if b1 != -1:
            if rng.random() < float(advancement["DOUBLE_R1_SCORE"]): scored.append(b1)
            else: new3 = b1
        return [-1, batter, new3], scored
    if event == "1B":
        if b3 != -1: scored.append(b3)
        new3 = -1
        if b2 != -1:
            if rng.random() < float(advancement["SINGLE_R2_SCORE"]): scored.append(b2)
            else: new3 = b2
        if b1 != -1:
            if new3 == -1 and rng.random() < float(advancement["SINGLE_R1_TO_3"]): new3 = b1
            else:
                # First-to-second is guaranteed under this event abstraction.
                pass
        new2 = b1 if b1 != -1 and new3 != b1 else -1
        return [batter, new2, new3], scored
    raise MLBStateError(f"UNSUPPORTED_HIT_EVENT:{event}")


def simulate_team_batting_surface(
    *,
    base_event_probabilities: np.ndarray,
    trials: int,
    seed: int,
    team_latent: np.ndarray | None = None,
    event_sensitivity: Sequence[float] | None = None,
    dk_rules: Mapping[str, float] | None = None,
    advancement: Mapping[str, float] | None = None,
    innings_outs: int = 27,
    max_team_pa: int = 90,
) -> MLBTeamBattingSurface:
    """Sequential MLB batting state simulator.

    One PA produces one baseball event. Runs/RBI are consequences of base/out state,
    not independent samples. Shared `team_latent` shifts every hitter inside a trial,
    creating natural teammate covariance before DraftKings scoring is applied.
    Salary, ownership, leverage, duplication and payouts are intentionally absent.
    """
    p0 = _prob_matrix(base_event_probabilities)
    n_hitters = p0.shape[0]
    if trials <= 0 or innings_outs <= 0 or max_team_pa <= 0:
        raise MLBStateError("INVALID_SIMULATION_SIZE")
    rng = np.random.default_rng(int(seed))
    rules = dict(DEFAULT_DK_RULES); rules.update(dict(dk_rules or {}))
    adv = dict(DEFAULT_ADVANCEMENT); adv.update(dict(advancement or {}))
    for k in DEFAULT_ADVANCEMENT:
        v = float(adv[k])
        if not (0.0 <= v <= 1.0): raise MLBStateError(f"INVALID_ADVANCEMENT_PROBABILITY:{k}")
    if team_latent is None:
        latent = rng.standard_t(df=5.0, size=int(trials)).astype(np.float64)
    else:
        latent = np.asarray(team_latent, dtype=np.float64)
        if latent.shape != (int(trials),) or np.any(~np.isfinite(latent)):
            raise MLBStateError("TEAM_LATENT_SHAPE_INVALID")
    if event_sensitivity is None:
        # Positive latent = stronger team offensive environment: more XBH/H, fewer outs/K.
        sens = np.array([0.05, 0.00, -0.08, 0.10, 0.14, 0.10, 0.20, -0.10], dtype=np.float64)
    else:
        sens = np.asarray(tuple(event_sensitivity), dtype=np.float64)
        if sens.shape != (len(EVENTS),) or np.any(~np.isfinite(sens)):
            raise MLBStateError("EVENT_SENSITIVITY_INVALID")

    fpts = np.zeros((trials, n_hitters), dtype=np.float32)
    pa = np.zeros((trials, n_hitters), dtype=np.int16)
    event_counts = np.zeros((trials, n_hitters, len(EVENTS)), dtype=np.int16)
    team_runs = np.zeros(trials, dtype=np.int16)

    for t in range(trials):
        outs = 0; batter = 0; bases = [-1, -1, -1]; pa_total = 0
        # Shared environment alters logits, then each hitter retains their native rates.
        logits_shift = latent[t] * sens
        adjp = p0 * np.exp(logits_shift[None, :])
        adjp /= adjp.sum(axis=1, keepdims=True)
        while outs < innings_outs:
            if pa_total >= max_team_pa:
                raise MLBStateError(f"MAX_TEAM_PA_EXCEEDED:{t}:{pa_total}")
            u = rng.random()
            eidx = int(np.searchsorted(np.cumsum(adjp[batter]), u, side="right"))
            eidx = min(eidx, len(EVENTS) - 1)
            ev = EVENTS[eidx]
            pa[t, batter] += 1; event_counts[t, batter, eidx] += 1; pa_total += 1
            if ev in ("K", "OUT"):
                outs += 1
            elif ev in ("BB", "HBP"):
                fpts[t, batter] += float(rules.get(ev, 0.0))
                bases, scored = _force_walk(bases, batter)
                if scored:
                    # Bases-loaded walk/HBP RBI belongs to batter.
                    fpts[t, batter] += len(scored) * float(rules.get("RBI", 0.0))
                    for runner in scored: fpts[t, runner] += float(rules.get("R", 0.0))
                    team_runs[t] += len(scored)
            else:
                fpts[t, batter] += float(rules.get(ev, 0.0))
                bases, scored = _transition_hit(bases, batter, ev, rng, adv)
                if scored:
                    # HR includes batter among scored runners; all runs on the play count as RBI.
                    fpts[t, batter] += len(scored) * float(rules.get("RBI", 0.0))
                    for runner in scored: fpts[t, runner] += float(rules.get("R", 0.0))
                    team_runs[t] += len(scored)
            batter = (batter + 1) % n_hitters

    receipt = {
        "PATCH_ID": PATCH_ID,
        "TRIALS": int(trials),
        "HITTERS": int(n_hitters),
        "OUTS_PER_TEAM_GAME": int(innings_outs),
        "EVENTS": list(EVENTS),
        "SEQUENTIAL_BASE_OUT_STATE": True,
        "RUN_RBI_INDEPENDENT_SAMPLING": False,
        "SHARED_TEAM_LATENT": True,
        "FANTASY_POINTS_EMERGENT_FROM_MICRO_EVENTS": True,
        "SALARY_USED_IN_SPORTS_GENERATOR": False,
        "OWNERSHIP_USED_IN_SPORTS_GENERATOR": False,
        "CONTEST_ECONOMICS_USED_IN_SPORTS_GENERATOR": False,
        "POSTLOCK_RESULTS_USED": False,
    }
    return MLBTeamBattingSurface(fpts, team_runs, pa, event_counts, receipt)
