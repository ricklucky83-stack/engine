from __future__ import annotations
import argparse, hashlib, itertools, json, math, os, time
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
from numba import njit
from mlb_showdown_contest_finish_ranker_v1 import PATCH_ID as RANKER_PATCH_ID, RANKER_ID, contest_finish_components, rank_selected_board, wilson_ucb, wilson_lcb
from mlb_showdown_bullpen_role_model_v1 import PATCH_ID as BULLPEN_ROLE_PATCH_ID, estimate_relief_role
from mlb_showdown_slate_context_v1 import FrozenSlateContext, build_phase1_context, merge_phase2_context, assert_context_unchanged, PATCH_ID as SLATE_CONTEXT_PATCH_ID
from mlb_showdown_postlock_board_rank_evaluator_v1 import evaluate_board
from mlb_showdown_dual_sp_trophy_posterior_v1 import PATCH_ID as DUAL_SP_TROPHY_POSTERIOR_PATCH_ID, adjust_tail_rate as dual_sp_adjust_tail_rate, calibration_receipt as dual_sp_calibration_receipt
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix

import importlib.util as _strategy_importlib_util
_STRATEGY_PATH = Path(__file__).resolve().parents[2] / "engines" / "common" / "apex_global_sports_strategy_layer_v1.py"
_strategy_spec = _strategy_importlib_util.spec_from_file_location("apex_global_sports_strategy_layer_v1", _STRATEGY_PATH)
if _strategy_spec is None or _strategy_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_SPORTS_STRATEGY_LAYER_UNAVAILABLE")
global_strategy = _strategy_importlib_util.module_from_spec(_strategy_spec)
_strategy_spec.loader.exec_module(global_strategy)
GLOBAL_SPORTS_STRATEGIST_PATCH_ID = global_strategy.PATCH_ID
_LAST_STRATEGY_RECEIPT = {}

_CALIBRATION_FREEZE_PATH = Path(__file__).resolve().parents[2] / "engines" / "common" / "apex_phase1_calibration_freeze_v1.py"
_calibration_spec = _strategy_importlib_util.spec_from_file_location("apex_phase1_calibration_freeze_v1", _CALIBRATION_FREEZE_PATH)
if _calibration_spec is None or _calibration_spec.loader is None:
    raise RuntimeError("RUN_INVALID:PHASE1_CALIBRATION_FREEZE_CONTRACT_UNAVAILABLE")
calibration_freeze = _strategy_importlib_util.module_from_spec(_calibration_spec)
calibration_freeze.__package__ = ""
sys_modules = __import__('sys').modules
sys_modules[_calibration_spec.name] = calibration_freeze
_calibration_spec.loader.exec_module(calibration_freeze)
CALIBRATION_FREEZE_PATCH_ID = calibration_freeze.PATCH_ID

POOL_PATH=Path(os.environ.get('APEX_PLAYER_POOL',''))
OUT=Path(os.environ.get('APEX_OUTPUT_DIR','/mnt/data'))
FIELD_SIZE=int(os.environ.get('APEX_FIELD_SIZE','1604'))
EXECUTION_ID=str(os.environ.get('APEX_EXECUTION_ID',FIELD_SIZE))
BOARD_SIZE=int(os.environ.get('APEX_BOARD_SIZE','10'))
FAKE_FIELD=int(math.ceil(FIELD_SIZE*3.4))
TOP01_CUTOFF=max(1,math.ceil(FAKE_FIELD*.001))
TOP10_EQUIV_CUTOFF=max(1,min(FAKE_FIELD,math.ceil(10*FAKE_FIELD/max(FIELD_SIZE,1))))
SEED=int(os.environ.get('APEX_SEED',str((FIELD_SIZE*10000+17)%(2**32-1))))
PHASE1_TRIALS=int(os.environ.get('APEX_PHASE1_TRIALS','50000'))
BASE_TRIALS=int(os.environ.get('APEX_BASE_TRIALS','10000'))
EXTRA_TRIALS=int(os.environ.get('APEX_EXTRA_TRIALS','40000'))
ROLE_COMPLETE_PATCH_ID='MLB_SD_ROLE_COMPLETE_PARITY_TAIL_SHADOW_v1.0'
PATCH_ID='MLB_SD_HIGH_CAPACITY_BULK_PREMIUM_SIGNATURE_SELECTOR_v1'
DIVERSITY_PATCH_ID='MLB_SD_SP_CPT_CONTROL_5_1_DIVERSE_SIBLING_CLOSURE_v2.3'
ENGINE_ID='APEX_MLB_SHOWDOWN_RAW_POOL_RUNTIME_v1.8.5_ELITE_CORE_SIBLING_PRESERVATION'
RP_RESTORE_PATCH_ID='MLB_SD_ELITE_DUAL_RP_CONDITIONAL_RECALL_v1_SHADOW'
FIELD_SELECTOR_REPAIR_PATCH_ID='MLB_SD_OWNERSHIP_CALIBRATED_FIELD_AND_ELITE_TAIL_SELECTOR_v1'
HR_PROBABILITY_PARITY_PATCH_ID='MLB_SD_CLASSIC_HR_GAME_TO_PA_PARITY_v1'
ELITE_CORE_SIBLING_PATCH_ID='MLB_SD_ELITE_CORE_ONE_SWAP_SIBLING_PRESERVATION_v1'
POSTSEAL_WINNER_JSON=os.environ.get('APEX_POSTSEAL_WINNER_JSON')
CONTEST_FILE=os.environ.get('APEX_CONTEST_FILE')
if os.environ.get('APEX_EXECUTION_MODE', 'PRODUCTION') == 'PRODUCTION' and (POSTSEAL_WINNER_JSON or CONTEST_FILE):
    raise RuntimeError('RUN_INVALID_DIAGNOSTIC_INPUT_ON_PRODUCTION_TRIGGER')
WINNER=json.loads(POSTSEAL_WINNER_JSON) if POSTSEAL_WINNER_JSON else None
if WINNER:
    WINNER={'CPT':str(WINNER['CPT']),'UTILS':tuple(sorted(map(str,WINNER['UTILS'])))}
_LAST_FIELD_RECEIPT={}
FORBIDDEN=['FPTS','AVG FPTS','L10 FPTS','L14 FPTS','L30 FPTS','L7 FPTS','L5 FPTS','L3 FPTS','VAL']

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def num(x,d=0.0):
    try:
        if isinstance(x,str):
            x=x.replace('%','').replace(',','').strip()
            if x in {'','-','nan','None'}: return d
        v=float(x); return v if np.isfinite(v) else d
    except Exception: return d

def pct_rank(x):
    x=np.asarray(x); o=np.argsort(x,kind='mergesort'); z=np.empty(len(x),float); z[o]=np.linspace(0,1,len(x)); return z

def active_pool(raw):
    hitters=raw.LINEUP.astype(str).str.fullmatch(r'[1-9]')
    opp=set(raw.loc[hitters,'Opp Pitcher'].dropna().astype(str).str.strip())
    starters=(raw.LINEUP.astype(str).str.upper()=='SP') & raw.PLAYER.astype(str).isin(opp)
    # The raw provider labels all pitchers as SP. Preserve the legacy salary-tier
    # relief path, and also admit anonymous historical bulk-workload pitchers so
    # high-capacity followers are not silently deleted before Phase 1.
    pitcher=(raw.LINEUP.astype(str).str.upper()=='SP')
    games=raw.get('G',pd.Series(0,index=raw.index)).map(num).clip(lower=1)
    innings=raw.get('IP',pd.Series(0,index=raw.index)).map(num)
    ipg=innings/games
    bulk_role=pitcher & (~starters) & (raw['RST%'].map(num)>0) & (innings>=20) & (games>=5) & (ipg>=3.0)
    relief=pitcher & (~starters) & (raw['RST%'].map(num)>0) & ((raw.SAL.map(num)<=5000) | bulk_role)
    keep=hitters|starters|relief
    p=raw.loc[keep].copy()
    p['_APEX_BULK_ROLE']=bulk_role.loc[p.index].astype(bool).to_numpy()
    p['_APEX_IPG']=ipg.loc[p.index].astype(float).to_numpy()
    p=p.reset_index(drop=True)
    if len(p)<8: raise RuntimeError('ACTIVE_POOL_TOO_SMALL')
    if p.TEAM.nunique()!=2: raise RuntimeError('SHOWDOWN_TWO_TEAM_GATE_FAIL')
    if p.PLAYER.duplicated().any(): raise RuntimeError('DUPLICATE_ACTIVE_PLAYER')
    return p

def build_players(pool):
    global _LAST_STRATEGY_RECEIPT
    out=[]
    strategy_features=global_strategy.build_strategy_features(pool, sport="MLB", mode="SHOWDOWN")
    _LAST_STRATEGY_RECEIPT=dict(strategy_features.receipt)
    for i,r in pool.iterrows():
        pitcher=str(r.LINEUP).upper()=='SP'
        sp=pitcher and num(r.get('O/U K'),0)>0 and num(r.get('O/U ER'),0)>0
        rp=pitcher and not sp
        own=max(.01,num(r['RST%'],.01)); own_fraction=own/100 if own>1 else own
        games=max(1.0,num(r.get('G'),1.0))
        bulk_role=bool(r.get('_APEX_BULK_ROLE',False)) if rp else False
        ipg=max(0.0,num(r.get('IP'),0.0)/games) if pitcher else 0.0
        bulk_ipg=max(0.0,num(r.get('_APEX_IPG'),0.0)) if bulk_role else 0.0
        role_est=estimate_relief_role(r, games=games, ipg=ipg, bulk_role=bulk_role, bulk_ipg=bulk_ipg) if rp else None
        role_prob=float(role_est.appearance_probability) if role_est is not None else 1.0
        role_evidence_grade=str(role_est.evidence_grade) if role_est is not None else 'STARTER_OR_HITTER'
        order_i=10 if pitcher else int(str(r.LINEUP))
        team_runs=max(.1,num(r['T Runs'],4))
        iso_v=float(np.clip(num(r.get('ISO'),.14),.01,.6))
        barrel=float(np.clip(num(r.get('Barrel %'),6.0)/100.0,0.0,.28))
        hard=float(np.clip(num(r.get('Hard%'),34.0)/100.0,.15,.65))
        hr_pct=num(r.get('HR%'),0.0); hr_pct=hr_pct/100.0 if hr_pct>1 else hr_pct
        pa_hint=float(np.clip(4.15+(5-order_i)*.055,3.2,5.3)) if not pitcher else 1.0
        stat_game_hr=float(np.clip(.025+.58*iso_v+.85*barrel+.08*(hard-.34),.01,.42)*(team_runs/4.5)**.42) if not pitcher else 0.0
        game_hr=float(np.clip(.50*hr_pct+.50*stat_game_hr,.005,.45)) if not pitcher else 0.0
        hr_pa=float(np.clip(1.0-(1.0-game_hr)**(1.0/max(pa_hint,3.2)),.001,.13)) if not pitcher else .001
        out.append(dict(idx=i,name=str(r.PLAYER).strip(),team=str(r.TEAM).strip(),opp=str(r.OPP).strip(),
          salary=int(num(r.SAL)),own=own,is_sp=sp,is_rp=rp,is_bulk=bulk_role,ipg=ipg,bulk_ipg=bulk_ipg,rp_qualified=(not rp),rp_qual_reasons=(),order=order_i,games=games,role_prob=role_prob,role_evidence_grade=role_evidence_grade,
          team_runs=team_runs,winp=np.clip(num(r['Win %'],50)/100,.01,.99),game_total=max(1,num(r['O/U'],8)),
          hrp=hr_pa,hr_game_prob=game_hr,avg=np.clip(num(r.AVG,.24),.05,.7),obp=np.clip(num(r.OBP,.31),.06,.8),
          iso=iso_v,bbp=np.clip(num(r['BB%'],8)/100,0,.35),kp=np.clip(num(r['K%'],22)/100,.02,.55),
          speed=max(0,num(r.Speed,20)),sb=max(0,num(r.SB,0)),ou_er=max(.5,num(r['O/U ER'],2.8)),ou_k=max(.5,num(r['O/U K'],4.5)),
          era=np.clip(num(r.get('ERA'),4.2),1.5,8),k9=np.clip(num(r.get('K/9'),8.5),3,14),bb9=np.clip(num(r.get('BB/9'),3.2),.5,7),hr9=np.clip(num(r.get('HR/9'),1.2),.2,3),
          strategy_opportunity=float(strategy_features.opportunity_score[i]),strategy_credibility=float(strategy_features.role_credibility[i]),strategy_salary_unlock=bool(strategy_features.salary_unlock[i]),strategy_leverage=float(strategy_features.strategic_leverage[i])))
    return out

def simulate_players(players,trials,seed):
    rng=np.random.default_rng(seed); n=len(players); s=np.zeros((trials,n),np.float32)
    teams=sorted({p['team'] for p in players})
    tl={t:rng.normal(0,1,trials).astype(np.float32) for t in teams}
    gl=rng.normal(0,1,trials).astype(np.float32)
    for p in players:
        i=p['idx']; t=p['team']; lat=tl[t]; ol=tl.get(p['opp'],-lat)
        if p['is_sp']:
            # Showdown covariance repair: opposing offense can coexist with SP fantasy
            # production through innings/strikeouts, so do not let one team latent
            # simultaneously crush K and inflate ER too aggressively. Couple the
            # starter win path to his own-team vs opponent game script instead of
            # sampling the win bonus independently of team offense.
            km=p['ou_k']*np.exp(.04*(-ol)+.04*gl); em=p['ou_er']*np.exp(.08*ol+.05*gl)
            ip=np.clip(rng.normal(5.65+.35*(p['winp']-.5)-.10*ol,.85,trials),2,8.5)
            k=rng.poisson(np.clip(km,.2,12)).astype(np.float32); er=rng.poisson(np.clip(em,.2,9)).astype(np.float32)
            h=rng.poisson(np.clip(4.7+.45*em,1,12)).astype(np.float32); bb=rng.poisson(np.clip(1.7+.12*em,.2,6)).astype(np.float32)
            base_logit=np.log(p['winp']/(1.0-p['winp']))
            wp=1.0/(1.0+np.exp(-(base_logit+.22*lat-.18*ol)))
            w=(rng.random(trials)<wp).astype(np.float32); qs=((ip>=6)&(er<=3)).astype(np.float32)
            s[:,i]=(2.25*ip+2*k-2*er-.6*h-.6*bb+4*w+2.5*qs).astype(np.float32)
        elif p['is_rp']:
            appeared=rng.random(trials)<p['role_prob']
            game_factor=np.clip(1.15-.12*np.exp(.16*ol+.08*gl),.55,1.25)
            outs=np.where(appeared,np.clip(rng.poisson(3.0*game_factor),1,9),0)
            ip=outs/3.0
            k=rng.poisson(p['k9']*ip/9.0).astype(np.float32)
            er=rng.poisson(p['era']*ip/9.0*np.clip(np.exp(.16*ol+.08*gl),.35,3)).astype(np.float32)
            h=rng.poisson(np.clip(8.2+p['hr9'],5,13)*ip/9.0*np.clip(np.exp(.12*ol),.4,2.5)).astype(np.float32)
            bb=rng.poisson(p['bb9']*ip/9.0).astype(np.float32)
            w=((rng.random(trials)<(p['winp']*.16))&appeared).astype(np.float32)
            s[:,i]=np.where(appeared,2.25*ip+2*k-2*er-.6*h-.6*bb+4*w,0).astype(np.float32)
        else:
            pa=np.clip(np.rint(rng.normal(np.clip(4.15+(5-p['order'])*.055+.10*lat,3.2,5.3),.45,trials)),3,6).astype(np.int16)
            contact=np.clip(p['avg']*(1+.12*lat+.04*gl),.05,.72); hp=np.clip(p['hrp']*(1+.30*lat+.10*gl),.001,.48); bp=np.clip(p['bbp']*(1+.10*lat),0,.35)
            hr=rng.binomial(pa,hp).astype(np.float32); rem=np.maximum(pa-hr.astype(np.int16),0)
            nh=rng.binomial(rem,np.clip((contact-hp)/(1-hp+1e-6),0,.75)).astype(np.float32)
            xbf=np.clip(p['iso']/(p['avg']+.05),.03,.7); d=rng.binomial(nh.astype(np.int16),np.clip(.20+.28*xbf,.1,.5)).astype(np.float32)
            tr=rng.binomial(np.maximum((nh-d).astype(np.int16),0),np.clip(.015+.003*p['speed'],.01,.12)).astype(np.float32); sing=np.maximum(nh-d-tr,0)
            walk=rng.binomial(pa,bp).astype(np.float32); ob=sing+d+tr+hr+walk
            rr=np.clip((p['team_runs']/9)*(1.25-.055*(p['order']-1))*(1+.16*lat),.02,1.3)
            rb=np.clip((p['team_runs']/9)*(.82+.045*(p['order']-1))*(1+.18*lat),.02,1.3)
            runs=rng.poisson(np.clip(rr+.11*ob,.01,3.5)).astype(np.float32); rbi=rng.poisson(np.clip(rb+.20*(d+tr+hr)+.06*sing,.01,4)).astype(np.float32)
            speed_tail=(p['speed']/28)**2*(.10+.020*p['sb']); steals=rng.poisson(np.clip(speed_tail*(1+.12*lat),0,.8)).astype(np.float32)
            eruption=(rng.random(trials)<np.clip((p['speed']/30)**3*(p['sb']/30)*.10,0,.06)).astype(np.float32)
            s[:,i]=(3*sing+5*d+8*tr+10*hr+2*walk+2*runs+2*rbi+5*steals+5*eruption).astype(np.float32)
    return s

def qualify_relief_paths(players,p1):
    """Restore the user-mandated MLB SD RP contract before lineup birth.

    RPs are conditional, not banned. A nonzero-role sub-$5K RP must carry at
    least one independently supported ceiling/usage path. This is player-level
    Phase-1 calibration and never uses aggregate FPTS projections.
    """
    starters={p['team']:p for p in players if p['is_sp']}
    qualified=[]
    for p in players:
        if not p['is_rp']:
            p['rp_qualified']=True; p['rp_qual_reasons']=(); continue
        x=np.asarray(p1[:,p['idx']],float)
        nz=x[np.abs(x)>1e-9]
        p95=float(np.quantile(x,.95))
        cond_p95=float(np.quantile(nz,.95)) if len(nz) else 0.0
        mult_threshold=2.5*(p['salary']/1000.0)
        one_ip=bool(p.get('ipg',0.0)>=1.0)
        lam=max(0.0,p['k9']*max(.75,p.get('ipg',0.0))/9.0)
        p2k=float(1.0-math.exp(-lam)*(1.0+lam))
        k_spike=bool(p2k>=.20 and p['role_prob']>=.25)
        win_hold=bool(p['games']>=30 and p['role_prob']>=.28 and p['winp']>=.52)
        st=starters.get(p['team'])
        early_hook=bool(st is not None and (st['ou_er']>=3.2 or (st['game_total']>=8.5 and st['winp']<.55)))
        tail=bool(p95>=mult_threshold or cond_p95>=mult_threshold)
        reasons=[]
        if tail: reasons.append('P95_2P5X')
        if one_ip: reasons.append('ONE_PLUS_IP')
        if k_spike: reasons.append('K_SPIKE_2PLUS')
        if win_hold: reasons.append('WIN_HOLD_ROLE')
        if early_hook: reasons.append('EARLY_HOOK')
        p['rp_p95']=p95; p['rp_cond_p95']=cond_p95; p['rp_p2k']=p2k
        p['rp_qualified']=bool(reasons); p['rp_qual_reasons']=tuple(reasons)
        if p['rp_qualified']: qualified.append(p['name'])
    return qualified

@njit(cache=False)
def _enumerate_showdown_numba(eligible, captains, sal, rp, dual_rp_ok, team_code):
    ne=len(eligible); nc=len(captains)
    # Exact upper bound: for each captain choose 5 from all other eligible rows.
    max_rows=nc*((ne-1)*(ne-2)*(ne-3)*(ne-4)*(ne-5)//120)
    out=np.empty((max_rows,7),np.int32); k=0
    for ci in range(nc):
        c=captains[ci]; cs=sal[c]*3//2
        for a0 in range(ne-4):
            i0=eligible[a0]
            if i0==c: continue
            for a1 in range(a0+1,ne-3):
                i1=eligible[a1]
                if i1==c: continue
                for a2 in range(a1+1,ne-2):
                    i2=eligible[a2]
                    if i2==c: continue
                    for a3 in range(a2+1,ne-1):
                        i3=eligible[a3]
                        if i3==c: continue
                        for a4 in range(a3+1,ne):
                            i4=eligible[a4]
                            if i4==c: continue
                            rp_n=rp[i0]+rp[i1]+rp[i2]+rp[i3]+rp[i4]
                            if rp_n > 2: continue
                            if rp_n == 2 and dual_rp_ok[i0]+dual_rp_ok[i1]+dual_rp_ok[i2]+dual_rp_ok[i3]+dual_rp_ok[i4] != 2: continue
                            salary=cs+sal[i0]+sal[i1]+sal[i2]+sal[i3]+sal[i4]
                            if salary<40000 or salary>50000: continue
                            t0=team_code[c]
                            same=(team_code[i0]==t0)+(team_code[i1]==t0)+(team_code[i2]==t0)+(team_code[i3]==t0)+(team_code[i4]==t0)
                            if same==5: continue
                            out[k,0]=c; out[k,1]=i0; out[k,2]=i1; out[k,3]=i2; out[k,4]=i3; out[k,5]=i4; out[k,6]=salary; k+=1
    return out[:k].copy()

def enumerate_lineups(players):
    teams=np.array([p['team'] for p in players]); sal=np.array([p['salary'] for p in players],np.int32); rp=np.array([p['is_rp'] for p in players],np.int8)
    dual_rp_ok=np.array([int(p['is_rp'] and p.get('rp_qualified',False) and all(tag in p.get('rp_qual_reasons',()) for tag in ('P95_2P5X','ONE_PLUS_IP','K_SPIKE_2PLUS','WIN_HOLD_ROLE')) and p.get('role_prob',0.0)>=.28) for p in players],np.int8)
    uniq={t:i for i,t in enumerate(sorted(set(teams.tolist())))}; team_code=np.array([uniq[t] for t in teams],np.int8)
    rp_keep=set()
    for team in sorted(set(teams)):
        ids=[i for i,p in enumerate(players) if p['is_rp'] and p['team']==team and p.get('rp_qualified',False)]
        ids.sort(key=lambda i:(-players[i]['role_prob'],-players[i]['games'],-players[i]['own'],players[i]['name']))
        rp_keep.update(ids[:4])
        rp_keep.update(i for i in ids if dual_rp_ok[i])
    eligible=np.array([i for i,p in enumerate(players) if not p['is_rp'] or i in rp_keep],np.int32)
    captains=np.array([i for i in eligible if not players[i]['is_rp']],np.int32)
    return _enumerate_showdown_numba(eligible,captains,sal,rp,dual_rp_ok,team_code)

def lineup_meta(lineups,players):
    names=np.array([p['name'] for p in players],object); teams=np.array([p['team'] for p in players],object); sp=np.array([p['is_sp'] for p in players],np.int8); rp=np.array([p['is_rp'] for p in players],np.int8); bulk=np.array([p.get('is_bulk',False) for p in players],np.int8); bulk_ipg=np.array([p.get('bulk_ipg',0.0) for p in players],float); elite_rp=np.array([int(p['is_rp'] and p.get('rp_qualified',False) and all(tag in p.get('rp_qual_reasons',()) for tag in ('P95_2P5X','ONE_PLUS_IP','K_SPIKE_2PLUS','WIN_HOLD_ROLE')) and p.get('role_prob',0.0)>=.28) for p in players],np.int8)
    own=np.array([p['own'] for p in players],float); speed=np.array([p['speed'] for p in players],float); sb=np.array([p['sb'] for p in players],float)
    sal=np.array([p['salary'] for p in players],np.int32); order=np.array([p['order'] for p in players],np.int16); team_runs=np.array([p['team_runs'] for p in players],float); role_prob=np.array([p['role_prob'] for p in players],float)
    strategy_leverage=np.array([p['strategy_leverage'] for p in players],float); strategy_unlock=np.array([p['strategy_salary_unlock'] for p in players],bool)
    idx=lineups[:,:6]; cpt=idx[:,0]; spct=sp[idx].sum(1); rpct=rp[idx].sum(1); elite_rpct=elite_rp[idx].sum(1); cptsp=sp[cpt].astype(bool); branch=[]; route=[]
    low_speed=np.zeros(len(lineups),bool); cpt_team_count=np.zeros(len(lineups),np.int8); same_team_release=np.zeros(len(lineups),bool)
    release_player_count=np.zeros(len(lineups),np.int8); primary_release_player=np.full(len(lineups),-1,np.int16); opponent_top2_count=np.zeros(len(lineups),np.int8)
    same_team_sp_count=np.zeros(len(lineups),np.int8); same_team_top2_count=np.zeros(len(lineups),np.int8); same_team_top5_count=np.zeros(len(lineups),np.int8); opponent_punt_count=np.zeros(len(lineups),np.int8); opponent_speed_count=np.zeros(len(lineups),np.int8); hitter_power_count=np.zeros(len(lineups),np.int8); primary_rp_player=np.full(len(lineups),-1,np.int16); rp_role_probability=np.zeros(len(lineups),float)
    same_team_bulk_count=np.zeros(len(lineups),np.int8); primary_bulk_player=np.full(len(lineups),-1,np.int16); bulk_role_probability=np.zeros(len(lineups),float); bulk_capacity_ipg=np.zeros(len(lineups),float); same_team_top4_consecutive3=np.zeros(len(lineups),bool); opponent_premium_top2=np.zeros(len(lineups),bool); primary_same_team_premium_hitter=np.full(len(lineups),-1,np.int16)
    hitter_team_median_salary={t:float(np.median(sal[(teams==t)&(sp==0)&(rp==0)])) for t in set(teams)}
    for j,row in enumerate(idx):
        tc=Counter(teams[row]); b='-'.join(map(str,sorted(tc.values(),reverse=True))); branch.append(b)
        route.append('DUAL_SP_ANCHOR' if spct[j]==2 else 'BRIDGE_1SP' if spct[j]==1 else 'BALANCED_33_BAT' if b=='3-3' else 'BATS_OFFCENTER')
        cteam=teams[cpt[j]]; cpt_team_count[j]=sum(teams[q]==cteam for q in row)
        same_team_sp_count[j]=sum(sp[q] and teams[q]==cteam for q in row)
        same_team_top2_count[j]=sum((not sp[q]) and (not rp[q]) and teams[q]==cteam and order[q]<=2 for q in row[1:])
        same_team_top5_count[j]=sum((not sp[q]) and (not rp[q]) and teams[q]==cteam and order[q]<=5 for q in row[1:])
        low_speed[j]=any(teams[q]!=cteam and speed[q]>=25 and sb[q]>=3 and own[q]<=5 for q in row)
        release=[q for q in row[1:] if (not sp[q]) and teams[q]==cteam and own[q]<=2.0 and sal[q]<=6000 and order[q]<=6]
        release_player_count[j]=len(release); same_team_release[j]=bool(release)
        if release: primary_release_player[j]=min(release,key=lambda q:(own[q],sal[q],order[q],q))
        opponent_top2_count[j]=sum((not sp[q]) and teams[q]!=cteam and order[q]<=2 for q in row[1:])
        opponent_punt_count[j]=sum((not sp[q]) and (not rp[q]) and teams[q]!=cteam and (order[q]>=8 or sal[q]<=4000) for q in row[1:])
        opponent_speed_count[j]=sum((not sp[q]) and (not rp[q]) and teams[q]!=cteam and speed[q]>=25 for q in row[1:])
        hitter_power_count[j]=sum((not sp[q]) and (not rp[q]) and players[q]['hrp']>=.20 for q in row)
        rps=[q for q in row[1:] if rp[q]]
        if rps:
            primary_rp_player[j]=rps[0]; rp_role_probability[j]=role_prob[rps[0]]
        bulks=[q for q in row[1:] if bulk[q] and teams[q]==cteam]
        if bulks:
            q=max(bulks,key=lambda x:(bulk_ipg[x],role_prob[x],x))
            same_team_bulk_count[j]=len(bulks); primary_bulk_player[j]=q; bulk_role_probability[j]=role_prob[q]; bulk_capacity_ipg[j]=bulk_ipg[q]
        same_orders=sorted(order[q] for q in row[1:] if (not sp[q]) and (not rp[q]) and teams[q]==cteam and order[q]<=4)
        same_team_top4_consecutive3[j]=any(all(x in same_orders for x in range(k,k+3)) for k in (1,2))
        same_hitters=[q for q in row[1:] if (not sp[q]) and (not rp[q]) and teams[q]==cteam]
        if same_hitters:
            primary_same_team_premium_hitter[j]=max(same_hitters,key=lambda q:(sal[q],-order[q],own[q],-q))
        opp_hitters=[q for q in row[1:] if (not sp[q]) and (not rp[q]) and teams[q]!=cteam]
        opponent_premium_top2[j]=any(order[q]<=2 and sal[q]>=hitter_team_median_salary[teams[q]] for q in opp_hitters)
    branch=np.array(branch,object); route=np.array(route,object)
    lane=(cptsp)&(spct==1)&(branch=='5-1'); lane_speed=lane&low_speed
    lane_control=lane&(cpt_team_count==5); lane_control_speed=lane_control&low_speed; lane_damage=lane&(cpt_team_count==1)
    cpt_speed_tail=(~cptsp)&(speed[cpt]>=25)&(sb[cpt]>=3)&(own[cpt]<=5)
    lane_hitter_cpt_speed_low_spend=(cpt_speed_tail)&(spct==1)&(lineups[:,6]<=47000)
    lane_hitter_cpt_speed_low_spend_42=lane_hitter_cpt_speed_low_spend&(branch=='4-2')
    lane_hitter_cpt_speed_low_spend_42_release=lane_hitter_cpt_speed_low_spend_42&same_team_release
    lane_hitter_cpt_speed_low_spend_42_control=lane_hitter_cpt_speed_low_spend_42_release&(cpt_team_count==4)
    lane_hitter_cpt_speed_low_spend_42_counter=lane_hitter_cpt_speed_low_spend_42_release&(cpt_team_count==2)
    lane_hitter_cpt_speed_low_spend_42_counter_top2=lane_hitter_cpt_speed_low_spend_42_counter&(opponent_top2_count>=2)
    lane_sp_cpt_control_51_speed_top2_core=lane_control_speed&(same_team_top2_count>=2)
    primary_release_order=np.array([order[q] if q>=0 else 99 for q in primary_release_player],np.int16)
    lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release=lane_hitter_cpt_speed_low_spend_42_counter_top2&(primary_release_order<=4)
    cpt_favorite=team_runs[cpt]>np.array([max(team_runs[teams!=teams[q]]) for q in cpt])
    cpt_value_order=(order[cpt]>=4)&(order[cpt]<=7)
    lane_hitter_cpt_same_team_sp_control=(~cptsp)&(spct==1)&(same_team_sp_count==1)&(cpt_team_count>=4)&cpt_favorite&cpt_value_order
    lane_hitter_cpt_favorite_51_sp_opp_punt=lane_hitter_cpt_same_team_sp_control&(branch=='5-1')&(opponent_punt_count>=1)&(lineups[:,6]>=47000)
    lane_mixed_sp_rp=(rpct==1)&(spct>=1)
    lane_sp2_rp1=(rpct==1)&(spct==2)
    rp_own=np.array([own[q] if q>=0 else 100.0 for q in primary_rp_player],float)
    lane_low_owned_rp=lane_mixed_sp_rp&(rp_own<=5.0)
    lane_hitter_cpt_favorite_42_sp_rp=lane_hitter_cpt_same_team_sp_control&(branch=='4-2')&(rpct==1)&(lineups[:,6]>=46000)
    lane_hitter_cpt_favorite_51_sp_contact_core=lane_hitter_cpt_favorite_51_sp_opp_punt&(same_team_top5_count>=3)&(hitter_power_count==0)&(lineups[:,6]>=47500)
    rp_reservoir=sorted(set(idx[rp[idx].astype(bool)].tolist()))
    min_rp_role={t:min((role_prob[q] for q in rp_reservoir if teams[q]==t),default=1.0) for t in set(teams)}
    rp_low_role=np.array([primary_rp_player[j]>=0 and role_prob[primary_rp_player[j]]<=min_rp_role[teams[primary_rp_player[j]]]+1e-12 for j in range(len(lineups))],bool)
    # The sixth batting slot is a distinct lineup-turnover captain path: it is
    # late enough to carry duplication leverage while retaining four-plus PA
    # upside. Close all calibrated siblings around the lowest-realization RP.
    lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact=lane_hitter_cpt_favorite_42_sp_rp&rp_low_role&(order[cpt]==6)&(same_team_top5_count==1)&(opponent_top2_count>=1)&(opponent_speed_count>=1)&(hitter_power_count==0)&(lineups[:,6]>=48000)&(lineups[:,6]<=49500)
    cpt_below_team_median=np.array([sal[cpt[j]]<=hitter_team_median_salary[teams[cpt[j]]] for j in range(len(lineups))],bool)
    cpt_moderate_leverage=(own[cpt]>=2.0)&(own[cpt]<=25.0)
    lane_hitter_cpt_bulk_51_middle_core_premium_runback=(~cptsp)&(branch=='5-1')&(cpt_team_count==5)&(same_team_bulk_count==1)&(bulk_capacity_ipg>=3.0)&(order[cpt]>=4)&(order[cpt]<=8)&cpt_below_team_median&cpt_moderate_leverage&same_team_top4_consecutive3&opponent_premium_top2&(lineups[:,6]>=47500)
    ownlog=np.log(np.clip(own[idx]/100,1e-7,1)).sum(1)+np.where(cptsp,-1.0,-.55)
    strategy_score=strategy_leverage[idx].sum(1)+.5*strategy_leverage[cpt]
    strategy_unlock_count=strategy_unlock[idx].sum(1)
    salary_release=np.clip((47000-lineups[:,6])/7000,0,1)
    return dict(names=names,teams=teams,idx=idx,cpt=cpt,salary=lineups[:,6],branch=branch,route=route,sp_count=spct,rp_count=rpct,elite_rp_count=elite_rpct,cpt_sp=cptsp,cpt_team_count=cpt_team_count,same_team_sp_count=same_team_sp_count,
                lane_sp_cpt_51=lane,lane_sp_cpt_51_speed=lane_speed,lane_sp_cpt_control_51=lane_control,lane_sp_cpt_control_51_speed=lane_control_speed,
                lane_sp_cpt_damage_15=lane_damage,lane_speed=low_speed,own_log=ownlog,own=own,speed=speed,sb=sb,
                cpt_speed_tail=cpt_speed_tail,same_team_release=same_team_release,release_player_count=release_player_count,primary_release_player=primary_release_player,opponent_top2_count=opponent_top2_count,salary_release=salary_release,
                lane_hitter_cpt_speed_low_spend=lane_hitter_cpt_speed_low_spend,
                lane_hitter_cpt_speed_low_spend_42=lane_hitter_cpt_speed_low_spend_42,
                lane_hitter_cpt_speed_low_spend_42_release=lane_hitter_cpt_speed_low_spend_42_release,
                lane_hitter_cpt_speed_low_spend_42_control=lane_hitter_cpt_speed_low_spend_42_control,
                lane_hitter_cpt_speed_low_spend_42_counter=lane_hitter_cpt_speed_low_spend_42_counter,
                lane_hitter_cpt_speed_low_spend_42_counter_top2=lane_hitter_cpt_speed_low_spend_42_counter_top2,
                same_team_top2_count=same_team_top2_count,same_team_top5_count=same_team_top5_count,opponent_punt_count=opponent_punt_count,opponent_speed_count=opponent_speed_count,hitter_power_count=hitter_power_count,primary_release_order=primary_release_order,primary_rp_player=primary_rp_player,rp_role_probability=rp_role_probability,rp_low_role=rp_low_role,
                lane_sp_cpt_control_51_speed_top2_core=lane_sp_cpt_control_51_speed_top2_core,
                lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release=lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release,
                lane_hitter_cpt_same_team_sp_control=lane_hitter_cpt_same_team_sp_control,
                lane_hitter_cpt_favorite_51_sp_opp_punt=lane_hitter_cpt_favorite_51_sp_opp_punt,
                lane_mixed_sp_rp=lane_mixed_sp_rp,lane_sp2_rp1=lane_sp2_rp1,lane_low_owned_rp=lane_low_owned_rp,
                lane_hitter_cpt_favorite_42_sp_rp=lane_hitter_cpt_favorite_42_sp_rp,
                lane_hitter_cpt_favorite_51_sp_contact_core=lane_hitter_cpt_favorite_51_sp_contact_core,
                lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact=lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact,
                same_team_bulk_count=same_team_bulk_count,primary_bulk_player=primary_bulk_player,bulk_role_probability=bulk_role_probability,bulk_capacity_ipg=bulk_capacity_ipg,same_team_top4_consecutive3=same_team_top4_consecutive3,opponent_premium_top2=opponent_premium_top2,primary_same_team_premium_hitter=primary_same_team_premium_hitter,cpt_below_team_median=cpt_below_team_median,cpt_moderate_leverage=cpt_moderate_leverage,lane_hitter_cpt_bulk_51_middle_core_premium_runback=lane_hitter_cpt_bulk_51_middle_core_premium_runback,
                strategy_score=strategy_score,strategy_unlock_count=strategy_unlock_count,global_strategy_patch_id=GLOBAL_SPORTS_STRATEGIST_PATCH_ID,sp_player_ids=np.where(sp.astype(bool))[0].astype(np.int32),rp_player_ids=np.where(rp.astype(bool))[0].astype(np.int32))

def proxy_metrics(p1,lineups):
    mu=p1.mean(0).astype(float); cov=np.cov(p1,rowvar=False).astype(float)
    W=np.zeros((len(lineups),p1.shape[1]),np.float32); r=np.arange(len(lineups))[:,None]; W[r,lineups[:,:6]]=1.; W[np.arange(len(lineups)),lineups[:,0]]=.5+W[np.arange(len(lineups)),lineups[:,0]]
    mean=W@mu; var=np.einsum('ij,jk,ik->i',W,cov,W,optimize=True); sd=np.sqrt(np.maximum(var,1e-6)); p95=mean+1.645*sd; p99=mean+2.326*sd
    return dict(mean=mean,p95=p95,p99=p99,win=pct_rank(mean+2.75*sd),top01=pct_rank(mean+2.30*sd),top10=pct_rank(mean+2.05*sd))

def choose_fake(meta,count,seed):
    """Ownership-calibrated public-field sampler using blind starter RST%."""
    global _LAST_FIELD_RECEIPT
    lw=meta['own_log']-np.abs(meta['salary']-49600)/6500+np.where(meta['branch']=='4-2',.18,0)+np.where(meta['branch']=='5-1',.10,0)
    lw-=lw.max(); w=np.exp(np.clip(lw,-60,0)); w/=w.sum()
    rng=np.random.default_rng(seed); total=min(int(count),len(w))
    sp_ids=np.asarray(meta.get('sp_player_ids',[]),dtype=np.int32)
    sp_owns=np.sort(np.asarray(meta['own'],float)[sp_ids]/100.0)[::-1] if len(sp_ids) else np.array([],float)
    second=float(sp_owns[1]) if len(sp_owns)>=2 else 0.0; first=float(sp_owns[0]) if len(sp_owns)>=1 else 0.0
    dual_target=float(np.clip(0.20+0.55*second,0.20,0.75)) if len(sp_owns)>=2 else 0.0
    spcpt_target=float(np.clip(0.25+0.45*((first+second)/2.0),0.25,0.75)) if len(sp_owns)>=2 else float(np.clip(0.20+0.40*first,0.20,0.65))
    dual=np.asarray(meta['sp_count']==2); spcpt=np.asarray(meta['cpt_sp'],bool)
    both_target=min(dual_target,spcpt_target,max(0.0,dual_target*spcpt_target+0.10*min(dual_target,spcpt_target)))
    quotas=[
        (dual & spcpt, int(round(total*both_target)), 'DUAL_SP_CPT_SP'),
        (dual & ~spcpt, int(round(total*max(0.0,dual_target-both_target))), 'DUAL_SP_HITTER_CPT'),
        (~dual & spcpt, int(round(total*max(0.0,spcpt_target-both_target))), 'NONDUAL_SP_CPT'),
    ]
    chosen=[]; chosen_set=set(); strata={}
    def sample_mask(mask,n,label):
        if n<=0: strata[label]=0; return
        ids=np.where(mask)[0]
        if chosen_set: ids=np.array([i for i in ids if int(i) not in chosen_set],dtype=np.int32)
        if not len(ids): strata[label]=0; return
        n=min(int(n),len(ids)); ww=w[ids]; ww=ww/ww.sum(); pick=rng.choice(ids,n,replace=False,p=ww)
        chosen.extend(map(int,pick)); chosen_set.update(map(int,pick)); strata[label]=int(n)
    for mask,n,label in quotas: sample_mask(mask,n,label)
    rest=total-len(chosen)
    if rest>0:
        neutral=(~dual)&(~spcpt)
        sample_mask(neutral,rest,'NEUTRAL')
        rest=total-len(chosen)
    if rest>0:
        remaining=np.array([i for i in range(len(w)) if i not in chosen_set],dtype=np.int32)
        ww=w[remaining]; ww=ww/ww.sum(); pick=rng.choice(remaining,min(rest,len(remaining)),replace=False,p=ww)
        chosen.extend(map(int,pick)); strata['OVERFLOW']=int(len(pick))
    arr=np.asarray(chosen[:total],np.int32)
    _LAST_FIELD_RECEIPT={
        'FAKE_FIELD_SIZE':int(len(arr)),'STARTER_OWNERSHIP_TOP2':[first,second],
        'TARGET_DUAL_SP_SHARE':dual_target,'TARGET_SP_CPT_SHARE':spcpt_target,
        'ACTUAL_DUAL_SP_SHARE':float(dual[arr].mean()) if len(arr) else 0.0,
        'ACTUAL_SP_CPT_SHARE':float(spcpt[arr].mean()) if len(arr) else 0.0,
        'STRATA_COUNTS':strata,'SOURCE':'BLIND_RST_OWNERSHIP_ONLY'
    }
    return arr

def _lineup_csr_weight_matrix(lineups,ids,nplayers):
    """FAST_PATH sparse roster matrix: 1.5 CPT + five 1.0 UTIL weights."""
    ids=np.asarray(ids,np.int32); lu=np.asarray(lineups[ids,:6],np.int32); m=len(ids)
    rr=np.repeat(np.arange(m,dtype=np.int32),6); cc=lu.reshape(-1); dd=np.ones(m*6,np.float32); dd[::6]=1.5
    return csr_matrix((dd,(rr,cc)),shape=(m,int(nplayers)),dtype=np.float32)

def field_thresholds(scores,lineups,field_idx,topk,top10k,trial_chunk=2000):
    T=scores.shape[0]; mx=np.empty(T,np.float32); kth=np.empty(T,np.float32); top10=np.empty(T,np.float32)
    fw=_lineup_csr_weight_matrix(lineups,field_idx,scores.shape[1]); k1=len(field_idx)-topk; k10=len(field_idx)-top10k
    for ts in range(0,T,trial_chunk):
        te=min(T,ts+trial_chunk); fs=np.asarray(fw@scores[ts:te].T,dtype=np.float32)  # field x trial
        mx[ts:te]=fs.max(0)
        kth[ts:te]=np.partition(fs,k1,axis=0)[k1]
        top10[ts:te]=np.partition(fs,k10,axis=0)[k10]
    return mx,kth,top10

def score_lineups(scores,lineups,mx,kth,top10_threshold,ids,trial_chunk=2000):
    """FAST_PATH streaming scorer.

    Field-relative win/Top-0.1 rates are empirical common-world tail metrics.
    P95/P99 remain moment summaries for secondary tie-breaking so the full
    Phase-2 review set does not allocate an O(lineups*trials) tail matrix.
    """
    ids=np.asarray(ids,np.int32); n=len(ids); T=int(scores.shape[0]); w=_lineup_csr_weight_matrix(lineups,ids,scores.shape[1])
    sm=np.zeros(n,np.float64); ss=np.zeros(n,np.float64); wc=np.zeros(n,np.int64); c01=np.zeros(n,np.int64); c10=np.zeros(n,np.int64)
    for ts in range(0,T,trial_chunk):
        te=min(T,ts+trial_chunk); v=np.asarray(w@scores[ts:te].T,dtype=np.float32)
        sm+=v.sum(1,dtype=np.float64); vd=v.astype(np.float64); ss+=(vd*vd).sum(1)
        wc+=(v>=np.asarray(mx[ts:te])[None,:]).sum(1)
        c01+=(v>=np.asarray(kth[ts:te])[None,:]).sum(1)
        c10+=(v>=np.asarray(top10_threshold[ts:te])[None,:]).sum(1)
    mean=sm/max(T,1); var=np.maximum(ss/max(T,1)-mean*mean,0.0); sd=np.sqrt(var)
    p95=mean+1.645*sd; p99=mean+2.326*sd
    return dict(mean=mean,p95=p95,p99=p99,cvar99=p99.copy(),win=wc/max(T,1),top01=c01/max(T,1),top10=c10/max(T,1))

def phase2_birth(pm,meta):
    comp=.32*pct_rank(pm['top01'])+.19*pct_rank(pm['win'])+.19*pct_rank(pm['p99'])+.11*pct_rank(pm['p95'])+.08*pct_rank(pm['mean'])+.06*pct_rank(-meta['own_log'])+.05*pct_rank(meta['strategy_score'])
    selected=set(np.where(comp>=np.quantile(comp,.97))[0]); lanes=defaultdict(set); lanes['GLOBAL_CALIBRATED_TAIL'].update(selected)
    def add(mask,score,k,name,all_rows=False):
        ids=np.where(mask)[0]
        if not len(ids): return
        best=ids if all_rows else ids[np.argpartition(-score[ids],min(k,len(ids))-1)[:min(k,len(ids))]]
        selected.update(best.tolist()); lanes[name].update(best.tolist())
    for b in sorted(set(meta['branch'])): add(meta['branch']==b,comp,max(120,int((meta['branch']==b).sum()*.03)),f'BRANCH_{b}')
    for r in sorted(set(meta['route'])): add(meta['route']==r,comp,max(120,int((meta['route']==r).sum()*.04)),f'ROUTE_{r}')
    add(meta['sp_count']==2,comp,max(2200,int((meta['sp_count']==2).sum()*.12)),'DUAL_SP_MARKET_ANCHOR_CLOSURE')
    add((~meta['cpt_sp'])&(meta['sp_count']>=1),comp,3000,'HITTER_CPT_SP_BRIDGE')
    add(meta['salary']<=47000,comp,1700,'LOW_SPEND_ELITE_TAIL')
    add(meta['strategy_unlock_count']>=1,comp,1800,'GLOBAL_STRATEGY_SALARY_UNLOCK')
    ls=.28*pct_rank(pm['top01'])+.18*pct_rank(pm['win'])+.17*pct_rank(pm['p99'])+.12*pct_rank(pm['p95'])+.10*pct_rank(-meta['own_log'])+.15*meta['lane_speed']
    add(meta['lane_sp_cpt_51'],ls,0,'SP_CPT_5_1_ONE_SP_SIBLING_CLOSURE',True)
    add(meta['lane_sp_cpt_51_speed'],ls,0,'SP_CPT_5_1_LOW_OWN_SPEED_RUNBACK',True)
    add(meta['lane_sp_cpt_control_51'],ls,0,'SP_CPT_CONTROL_5_1_SAME_TEAM_4BAT_CLOSURE',True)
    add(meta['lane_sp_cpt_control_51_speed'],ls,0,'SP_CPT_CONTROL_5_1_LOW_OWN_SPEED_RUNBACK',True)
    add(meta['lane_speed'],ls,512,'LOW_OWN_SPEED_ERUPTION_TAIL')
    hs=.25*pct_rank(pm['top01'])+.18*pct_rank(pm['win'])+.18*pct_rank(pm['p99'])+.12*pct_rank(pm['p95'])+.10*pct_rank(-meta['own_log'])+.09*meta['salary_release']+.08*meta['same_team_release']
    add(meta['lane_hitter_cpt_speed_low_spend'],hs,640,'HITTER_CPT_SPEED_LOW_SPEND_TAIL')
    add(meta['lane_hitter_cpt_speed_low_spend_42'],hs,640,'HITTER_CPT_SPEED_LOW_SPEND_4_2_SIBLINGS')
    add(meta['lane_hitter_cpt_speed_low_spend_42_release'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_SALARY_RELEASE_CLOSURE',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_control'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL_ORIENTATION',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_counter'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_ORIENTATION',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2_CORE',True)
    role_hs=.27*pct_rank(pm['top01'])+.18*pct_rank(pm['win'])+.17*pct_rank(pm['p99'])+.11*pct_rank(pm['p95'])+.17*pct_rank(-meta['own_log'])+.10*pct_rank(meta['salary_release'])
    add(meta['lane_hitter_cpt_same_team_sp_control'],role_hs,1400,'HITTER_CPT_SAME_TEAM_SP_CONTROL_RESERVOIR')
    add(meta['lane_hitter_cpt_favorite_51_sp_opp_punt'],role_hs,0,'HITTER_CPT_FAVORITE_5_1_SP_OPP_PUNT_CLOSURE',True)
    add(meta['lane_hitter_cpt_favorite_42_sp_rp'],role_hs,0,'HITTER_CPT_FAVORITE_4_2_SP_RP_CLOSURE',True)
    add(meta['lane_hitter_cpt_favorite_51_sp_contact_core'],role_hs,0,'HITTER_CPT_FAVORITE_5_1_SP_CONTACT_CORE_CLOSURE',True)
    add(meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'],role_hs,0,'HITTER_CPT_FAVORITE_4_2_SP_RP_UNCERTAIN_CONTACT_SIBLING_CLOSURE',True)
    add(meta['lane_mixed_sp_rp'],role_hs,12,'MIXED_SP_RP_SCOUT_DEPTH')
    add(meta['lane_sp2_rp1'],role_hs,8,'MIXED_ARM_ARCHETYPE_DEPTH_SP2_RP1')
    add(meta['lane_low_owned_rp'],role_hs,3,'BULLPEN_LOW_OWN_ANTIDUPE_DEPTH')
    add(meta['lane_sp_cpt_control_51_speed_top2_core'],ls,0,'SP_CPT_CONTROL_5_1_SPEED_TOP2_CORE_CLOSURE',True)
    add(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release'],hs,0,'HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2_EARLY_RELEASE_CLOSURE',True)
    add(meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'],role_hs,0,'HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK_CLOSURE',True)
    elite_rp_score=.34*pct_rank(pm['top01'])+.24*pct_rank(pm['p99'])+.18*pct_rank(pm['win'])+.12*pct_rank(pm['p95'])+.12*pct_rank(meta['salary'])
    for elite_n,label in [(1,'ELITE_SINGLE_RP_TAIL_RECALL'),(2,'ELITE_DUAL_RP_TAIL_RECALL')]:
        mask=(meta['elite_rp_count']==elite_n)
        add(mask,elite_rp_score,max(120,int(mask.sum()*.03)),label)
    return np.array(sorted(selected),np.int32),comp,ls,{k:len(v) for k,v in lanes.items()}

def handoff(born,bm,meta):
    sc=.31*pct_rank(bm['top01'])+.17*pct_rank(bm['top10'])+.21*pct_rank(bm['win'])+.16*pct_rank(bm['p99'])+.08*pct_rank(bm['p95'])+.03*pct_rank(bm['mean'])+.04*pct_rank(-meta['own_log'][born])
    sc+=.07*meta['lane_sp_cpt_51'][born]+.10*meta['lane_sp_cpt_51_speed'][born]+.05*meta['lane_speed'][born]
    sc+=.08*meta['lane_hitter_cpt_speed_low_spend_42'][born]+.13*meta['lane_hitter_cpt_speed_low_spend_42_release'][born]+.04*meta['salary_release'][born]
    k=min(1650,len(born)); sel=set(born[np.argpartition(-sc,k-1)[:k]].tolist()); reserve={}; pos={g:i for i,g in enumerate(born)}
    specs=[
      ('SP_CPT_5_1',meta['lane_sp_cpt_51'],220,False),('SP_CPT_5_1_SPEED',meta['lane_sp_cpt_51_speed'],0,True),
      ('SP_CPT_CONTROL_5_1',meta['lane_sp_cpt_control_51'],220,False),('SP_CPT_CONTROL_5_1_SPEED',meta['lane_sp_cpt_control_51_speed'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND',meta['lane_hitter_cpt_speed_low_spend'],240,False),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2',meta['lane_hitter_cpt_speed_low_spend_42'],384,False),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE',meta['lane_hitter_cpt_speed_low_spend_42_release'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL',meta['lane_hitter_cpt_speed_low_spend_42_control'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER',meta['lane_hitter_cpt_speed_low_spend_42_counter'],0,True),
      ('HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2',meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'],0,True),
      ('LOW_OWN_SPEED',meta['lane_speed'],120,False),('DUAL_SP',meta['sp_count']==2,96,False),('NO_SP',meta['sp_count']==0,96,False),('3_3',meta['branch']=='3-3',96,False)]
    for name,mask,k,all_rows in specs:
        ids=np.array([g for g in born if mask[g]],np.int32)
        if len(ids):
            best=ids if all_rows else ids[np.argpartition(-np.array([sc[pos[x]] for x in ids]),min(k,len(ids))-1)[:min(k,len(ids))]]
            before=len(sel); sel.update(best.tolist()); reserve[name]=len(sel)-before
        else: reserve[name]=0
    for p in range(len(meta['names'])):
        mask_without=~np.isin(meta['idx'][born],p).any(1); ids=born[mask_without]
        if len(ids):
            loc=np.where(mask_without)[0]; kk=min(96,len(ids)); best=ids[np.argpartition(-sc[loc],kk-1)[:kk]]
            before=len(sel); sel.update(best.tolist()); reserve[f'WITHOUT_PLAYER_ID_{p}']=len(sel)-before
        else: reserve[f'WITHOUT_PLAYER_ID_{p}']=0
    # Global state v1.19 requires Phase 2, handoff, and selector-review set
    # parity. Keep the surface accounting for diagnostics, but do not cull a
    # calibration-qualified Phase 2 lineup before independent evaluation.
    reserve['PHASE2_PARITY_RESTORED']=int(len(born)-len(sel))
    return born.copy(),reserve

def diverse_family_reps(cands,score,meta,mask,n=3,max_overlap=4,max_non_cpt_exposure=2):
    ids=np.where(mask)[0]
    ranked=ids[np.argsort(-score[ids],kind='mergesort')]
    eligible_rosters=[set(meta['idx'][cands[j]].tolist()) for j in ids]
    mandatory_spine=set.intersection(*eligible_rosters) if eligible_rosters else set()
    base_cap=max(int(max_overlap),len(mandatory_spine))
    max_cap=min(5,int(meta['idx'].shape[1])-1)
    for effective_overlap_cap in range(base_cap,max_cap+1):
        chosen=[]; counts=Counter()
        for j in ranked:
            g=cands[j]; roster=set(meta['idx'][g].tolist()); cpt=int(meta['cpt'][g])
            if any(p!=cpt and p not in mandatory_spine and counts[p]>=max_non_cpt_exposure for p in roster):
                continue
            if all(len(roster & set(meta['idx'][cands[k]].tolist()))<=effective_overlap_cap for k in chosen):
                chosen.append(int(j))
                for p in roster:
                    if p!=cpt and p not in mandatory_spine: counts[p]+=1
                if len(chosen)>=n: return chosen
    raise RuntimeError(f'DIVERSE_FAMILY_REP_UNSATISFIABLE:{len(chosen)}/{n}')

def best_by_signature_reps(cands,score,meta,mask,signatures,n=2,max_overlap=5):
    ids=np.where(mask)[0]
    groups=defaultdict(list)
    for j in ids: groups[int(signatures[j])].append(int(j))
    reps=[]
    for sig,js in groups.items(): reps.append(max(js,key=lambda j:(score[j],-j)))
    ranked=sorted(reps,key=lambda j:(-score[j],j))
    chosen=[]
    for j in ranked:
        roster=set(meta['idx'][cands[j]].tolist())
        if all(len(roster & set(meta['idx'][cands[k]].tolist()))<=max_overlap for k in chosen):
            chosen.append(j)
            if len(chosen)>=n: break
    if len(chosen)<n: raise RuntimeError(f'SIGNATURE_REP_UNSATISFIABLE:{len(chosen)}/{n}')
    return chosen

def credible_one_swap_siblings(seed_local,cands,score,cm,meta,top01_ratio=.25,p99_ratio=.90):
    """Hedge the seed's most fragile hitter slot with one-UTIL alternatives.

    Fragility is defined from the sealed source ownership signal: the
    lowest-owned non-pitcher UTIL in the elite seed. All other four UTILs and
    the CPT are held fixed. This prevents arbitrary family diversification.
    """
    seed_local=int(seed_local); g=int(cands[seed_local]); cpt=int(meta['cpt'][g])
    utils=list(map(int,meta['idx'][g,1:6])); spids=set(map(int,meta.get('sp_player_ids',[]))); rpids=set(map(int,meta.get('rp_player_ids',[])))
    hitters=[q for q in utils if q not in spids and q not in rpids]
    if not hitters: return []
    own=np.asarray(meta['own'],float); fragile=min(hitters,key=lambda q:(own[q],q)); keep=set(utils)-{fragile}
    seed_top=float(cm['top01'][seed_local]); seed_p99=float(cm['p99'][seed_local]); out=[]
    for j,g2 in enumerate(cands):
        if j==seed_local or int(meta['cpt'][g2])!=cpt: continue
        u2=set(map(int,meta['idx'][g2,1:6]))
        if fragile in u2 or len(u2)!=5 or not keep.issubset(u2): continue
        if float(cm['top01'][j])+1e-12 < top01_ratio*max(seed_top,1e-12): continue
        if float(cm['p99'][j])+1e-12 < p99_ratio*max(seed_p99,1e-12): continue
        out.append(int(j))
    return sorted(out,key=lambda j:(-score[j],j))

def _portfolio_constraints(pcands,pscore,meta,size,own,locks=(),sibling_groups=()):
    rows=[np.ones(len(pcands))]; lb=[size]; ub=[size]
    pmap={int(g):i for i,g in enumerate(pcands)}
    for g in locks:
        if int(g) not in pmap: continue
        v=np.zeros(len(pcands)); v[pmap[int(g)]]=1.; rows.append(v); lb.append(1); ub.append(1)
    for item in sibling_groups:
        if isinstance(item,tuple): globals_group,required=item
        else: globals_group,required=item,1
        mapped=[pmap[int(g)] for g in globals_group if int(g) in pmap]
        if not mapped: continue
        required=min(int(required),len(mapped))
        v=np.zeros(len(pcands)); v[np.asarray(mapped,np.int32)]=1.; rows.append(v); lb.append(required); ub.append(len(mapped))
    n=len(meta['names']); roster=meta['idx'][pcands]
    for p in range(n):
        has=np.isin(roster,p).any(1).astype(float)
        if has.sum():
            cap_share=float(np.clip(max(.70,own[p]+.10),.70,1.0)); cap=max(1,min(size,int(math.ceil(size*cap_share))))
            rows.append(has); lb.append(0); ub.append(cap)
        cp=(meta['cpt'][pcands]==p).astype(float)
        if cp.sum():
            cpt_share=.60 if own[p]>=.65 else .40 if own[p]>=.35 else .30
            cap=max(1,min(size,int(math.ceil(size*cpt_share))))
            rows.append(cp); lb.append(0); ub.append(cap)
    for a in range(n):
        ha=np.isin(roster,a).any(1)
        if not ha.any(): continue
        for b in range(a+1,n):
            v=(ha & np.isin(roster,b).any(1)).astype(float)
            if not v.any(): continue
            pair_share=float(np.clip(max(.60,min(own[a],own[b])+.10),.60,.90)); cap=max(1,min(size,int(math.ceil(size*pair_share))))
            rows.append(v); lb.append(0); ub.append(cap)
    rp_any=(meta['rp_count'][pcands]>0).astype(float); rows.append(rp_any); lb.append(0); ub.append(min(3,size))
    return LinearConstraint(csr_matrix(np.vstack(rows)),lb,ub)

def _high_dual_sp_cpt_market(slate_context=None):
    src=slate_context if slate_context is not None else _LAST_FIELD_RECEIPT
    return float(src.get('TARGET_DUAL_SP_SHARE',0.0))>=0.50 and float(src.get('TARGET_SP_CPT_SHARE',0.0))>=0.50

def _market_geometry_seed_locals(cands,score,meta,max_seeds=2,slate_context=None):
    """Top individual dual-SP/SP-CPT seed per starter CPT in a market that demands it."""
    if not _high_dual_sp_cpt_market(slate_context): return []
    cands=np.asarray(cands,np.int32); score=np.asarray(score,float)
    mask=np.asarray(meta['cpt_sp'][cands],bool)&(np.asarray(meta['sp_count'][cands])==2)
    ids=np.where(mask)[0]; reps=[]
    if not len(ids): return reps
    for cpt in sorted(set(map(int,meta['cpt'][cands[ids]]))):
        z=ids[meta['cpt'][cands[ids]]==cpt]
        if len(z): reps.append(int(z[np.argmax(score[z])]))
    reps=sorted(reps,key=lambda j:(-score[j],j))
    return reps[:max_seeds]

def reciprocal_sp_cpt_local(candidate_local,cands,meta):
    """Same six-player roster with the other confirmed starter moved to CPT."""
    j=int(candidate_local); cands=np.asarray(cands,np.int32); g=int(cands[j]); row=list(map(int,meta['idx'][g,:6])); cpt=int(row[0])
    spids=set(map(int,meta.get('sp_player_ids',[]))); sps=[q for q in row if q in spids]
    if len(sps)!=2 or cpt not in spids: return None
    other=sps[0] if sps[1]==cpt else sps[1]; roster=set(row)
    for k,g2 in enumerate(cands):
        if int(meta['cpt'][int(g2)])==other and set(map(int,meta['idx'][int(g2),:6]))==roster:
            return int(k)
    return None

def market_reciprocal_candidates(cands,cm,meta,max_pairs=1,slate_context=None):
    """Blind reciprocal CPT hedge around the best credible sibling of top dual-SP seeds."""
    if not _high_dual_sp_cpt_market(slate_context): return []
    comp=contest_finish_components(cands,cm,meta,trials=BASE_TRIALS+EXTRA_TRIALS); score=np.asarray(comp['score'],float); out=[]
    for seed in _market_geometry_seed_locals(cands,score,meta,max_seeds=max_pairs,slate_context=slate_context):
        sib=credible_one_swap_siblings(seed,cands,score,cm,meta)
        if not sib: continue
        best=max(sib,key=lambda j:(float(cm['top01'][j]),float(cm['p99'][j]),score[j],-j))
        rec=reciprocal_sp_cpt_local(best,cands,meta)
        if rec is None: continue
        if float(cm['top01'][rec])+1e-12 < .20*max(float(cm['top01'][best]),1e-12): continue
        if float(cm['p99'][rec])+1e-12 < .90*max(float(cm['p99'][best]),1e-12): continue
        out.append(int(rec))
    return list(dict.fromkeys(out))[:max_pairs]

def _choose_protection_seeds(chosen_full_locals,cands,meta,max_seeds=3,slate_context=None):
    """Choose seed cores from the stage-1 portfolio using blind field geometry."""
    chosen=list(map(int,chosen_full_locals)); out=[]; used=set()
    src=slate_context if slate_context is not None else _LAST_FIELD_RECEIPT
    high_sp_cpt=float(src.get('TARGET_SP_CPT_SHARE',0.0))>=0.50
    if high_sp_cpt:
        # In starter-CPT-heavy fields, prioritize the distinct confirmed starter
        # captain cores; hitter-CPT rows remain eligible but need no forced hedge.
        for j in chosen:
            g=int(cands[j]); cpt=int(meta['cpt'][g])
            if not bool(meta['cpt_sp'][g]) or cpt in used: continue
            out.append(j); used.add(cpt)
            if len(out)>=min(2,max_seeds): return out
    for j in chosen:
        g=int(cands[j]); cpt=int(meta['cpt'][g])
        if cpt in used: continue
        out.append(j); used.add(cpt)
        if len(out)>=max_seeds: break
    return out

def baseline_portfolio_seed_locals(cands,cm,meta,size=10,max_seeds=3,slate_context=None):
    """Stage-1 blind portfolio seeds used only to allocate sibling extra trials."""
    cands=np.asarray(cands,np.int32); comp=contest_finish_components(cands,cm,meta,trials=BASE_TRIALS); score=np.asarray(comp['score'],float)
    rank1=int(np.argmax(score)); own=np.asarray(meta['own'],float)/100.0; ranked=np.argsort(-score,kind='mergesort')
    pool_full=np.asarray(ranked[:min(len(cands),max(2500,size*250))],np.int32)
    if rank1 not in set(map(int,pool_full)): pool_full=np.r_[pool_full,rank1]
    pcands=cands[pool_full]; pscore=score[pool_full]
    con=_portfolio_constraints(pcands,pscore,meta,size,own,locks=[int(cands[rank1])])
    res=milp(-pscore,integrality=np.ones(len(pcands)),bounds=Bounds(0,1),constraints=con,options={'time_limit':10})
    if not res.success: return []
    chosen=pool_full[np.where(res.x>.5)[0]]; chosen=chosen[np.argsort(-score[chosen],kind='mergesort')]
    seeds=[]
    seed_order=_market_geometry_seed_locals(cands,score,meta,max_seeds=min(2,max_seeds),slate_context=slate_context) + _choose_protection_seeds(chosen,cands,meta,max_seeds=max_seeds,slate_context=slate_context)
    for j in seed_order:
        if int(j) in seeds: continue
        if credible_one_swap_siblings(j,cands,score,cm,meta): seeds.append(int(j))
        if len(seeds)>=max_seeds: break
    return seeds

def _legacy_elite_tail_score(cands,cm,meta):
    """v1.32.20 blind-validated contest-finish score; no post-lock inputs."""
    cands=np.asarray(cands,np.int32)
    trial_n=np.asarray(cm.get('trials',np.full(len(cands),BASE_TRIALS+EXTRA_TRIALS)),float)
    top01_lcb=wilson_lcb(np.asarray(cm['top01'],float),trial_n,z=1.0)
    win_lcb=wilson_lcb(np.asarray(cm['win'],float),trial_n,z=1.0)
    return (
        .46*pct_rank(top01_lcb)
        + .30*pct_rank(win_lcb)
        + .14*pct_rank(np.asarray(cm['p99'],float))
        + .07*pct_rank(np.asarray(cm['p95'],float))
        + .03*pct_rank(-np.asarray(meta['own_log'][cands],float))
    )


def _asymmetric_dual_sp_market(meta, slate_context=None):
    if slate_context is not None:
        if not isinstance(slate_context,FrozenSlateContext): raise TypeError('SELECTOR_REQUIRES_FROZEN_SLATE_CONTEXT')
        return (
            int(slate_context.get('CONFIRMED_STARTERS',0))==2
            and _high_dual_sp_cpt_market(slate_context)
            and float(slate_context.get('STARTER_OWNERSHIP_GAP',0.0))>=0.30
        )
    if not _high_dual_sp_cpt_market(): return False
    spids=list(map(int,meta.get('sp_player_ids',[])))
    if len(spids)!=2: return False
    own=sorted((float(meta['own'][i])/100.0 for i in spids),reverse=True)
    return (own[0]-own[1])>=0.30


def _low_owned_sp_cpt_lane(cands,advisor_score,meta,n=4,max_overlap=4,slate_context=None):
    """Blind diversity closure for strongly asymmetric two-starter Showdown markets."""
    if not _asymmetric_dual_sp_market(meta,slate_context): return []
    if slate_context is not None:
        low=int(slate_context['LOWER_OWNED_SP_ID'])
    else:
        spids=list(map(int,meta.get('sp_player_ids',[])))
        low=min(spids,key=lambda i:(float(meta['own'][i]),i))
    ids=np.where((meta['cpt'][cands]==low)&(meta['sp_count'][cands]==2))[0]
    ranked=ids[np.argsort(-advisor_score[ids],kind='mergesort')]
    out=[]
    for j in ranked:
        roster=set(map(int,meta['idx'][int(cands[j]),:6]))
        if all(len(roster & set(map(int,meta['idx'][int(cands[k]),:6])))<=max_overlap for k in out):
            out.append(int(j))
        if len(out)>=int(n): break
    return out[:n]


def _legacy_market_reciprocal_candidates(cands,cm,meta,score,max_pairs=1,slate_context=None):
    if not _high_dual_sp_cpt_market(slate_context): return []
    out=[]
    for seed in _market_geometry_seed_locals(cands,score,meta,max_seeds=max_pairs,slate_context=slate_context):
        sib=credible_one_swap_siblings(seed,cands,score,cm,meta)
        if not sib: continue
        best=max(sib,key=lambda j:(float(cm['top01'][j]),float(cm['p99'][j]),score[j],-j))
        rec=reciprocal_sp_cpt_local(best,cands,meta)
        if rec is None: continue
        if float(cm['top01'][rec])+1e-12 < .20*max(float(cm['top01'][best]),1e-12): continue
        if float(cm['p99'][rec])+1e-12 < .90*max(float(cm['p99'][best]),1e-12): continue
        out.append(int(rec))
    return list(dict.fromkeys(out))[:max_pairs]


def select_milp(cands,cm,meta,size=10,slate_context=None):
    """Hybrid Top-0.1 selector with asymmetric dual-SP CPT recovery.

    Normal markets retain the advisor-led ranked stream. In two-starter markets
    where blind field geometry is both dual-SP/SP-CPT heavy and starter ownership
    differs by at least 30 percentage points, use the v1.32.20 blind-validated
    elite-tail portfolio as the primary selector and reserve four diverse
    lower-owned-SP CPT dual-SP representatives ranked by the current advisor.
    """
    from types import SimpleNamespace
    if not isinstance(slate_context,FrozenSlateContext): raise TypeError('SELECTOR_REQUIRES_FROZEN_SLATE_CONTEXT')
    cands=np.asarray(cands,np.int32)
    advisor_components=contest_finish_components(cands,cm,meta,trials=BASE_TRIALS+EXTRA_TRIALS,field_size=FIELD_SIZE,slate_games=1)
    advisor_score=np.asarray(advisor_components['score'],float)

    if not _high_dual_sp_cpt_market(slate_context):
        order=np.argsort(-advisor_score,kind='mergesort')
        if len(order)<size: raise RuntimeError(f'RUN_FAIL:INSUFFICIENT_SELECTOR_ROWS:{len(order)}:{size}')
        chosen_local=order[:size]; selected=cands[chosen_local]
        receipt={
          'PATCH_ID':'MLB_SD_ASYMMETRIC_DUAL_SP_CPT_HYBRID_SELECTOR_v1',
          'HYBRID_TRIGGERED':False,'PROTECTED_GROUP_COUNT':0,'SEED_GLOBAL_LINEUP_INDEX':[],'SEED_CPT_IDS':[],
          'GROUP_SIZES':[],'GROUP_REQUIRED_SIBLINGS':[],'FRAGILE_UTIL_PLAYER':[],
          'RECIPROCAL_SP_CPT_LOCKS':[],'ASYMMETRIC_LOW_SP_CPT_LANE_LOCKS':[],
          'FULL_SELECTOR_REVIEWED':int(len(cands)),'STAGE1_PORTFOLIO_POOL':int(len(cands)),'STAGE2_PORTFOLIO_POOL':int(len(cands)),
          'STAGE1_STATUS':'ADVISOR_PRIMARY_TAIL_RANKED_STREAM','STAGE2_STATUS':'NO_HARD_PORTFOLIO_OVERRIDE',
          'WEIGHTED_METRIC_SUM_USED':False,'HARD_FAMILY_QUOTAS_USED':False,'HARD_PAIR_QUOTAS_USED':False,
          'FIELD_SLATE_CONTEXT':advisor_components.get('context',{}),'FROZEN_SLATE_CONTEXT':slate_context.as_dict(),'FROZEN_SLATE_CONTEXT_SHA256':slate_context.sha256,'SELECTOR_RECOMPUTATION':'PROHIBITED',
        }
        res=SimpleNamespace(success=True,status=0,message='ADVISOR_PRIMARY_TAIL_RANKED_STREAM',x=np.ones(len(selected),dtype=float))
        return selected,advisor_score[chosen_local],res,receipt

    score=_legacy_elite_tail_score(cands,cm,meta)
    rank1=int(np.argmax(score)); own=np.asarray(meta['own'],float)/100.0
    ranked=np.argsort(-score,kind='mergesort'); pool_n=min(len(cands),max(2500,size*250)); pool_full=np.asarray(ranked[:pool_n],np.int32)
    if rank1 not in set(map(int,pool_full)): pool_full=np.r_[pool_full,rank1]
    pcands=cands[pool_full]; pscore=score[pool_full]
    c1=_portfolio_constraints(pcands,pscore,meta,size,own,locks=[int(cands[rank1])])
    r1=milp(-pscore,integrality=np.ones(len(pcands)),bounds=Bounds(0,1),constraints=c1,options={'time_limit':15})
    if not r1.success: raise RuntimeError('MILP_STAGE1_FAIL:'+str(r1.message))
    baseline_full=pool_full[np.where(r1.x>.5)[0]]; baseline_full=baseline_full[np.argsort(-score[baseline_full],kind='mergesort')]

    seeds=[]; groups=[]; seed_order=_market_geometry_seed_locals(cands,score,meta,max_seeds=2,slate_context=slate_context)+_choose_protection_seeds(baseline_full,cands,meta,max_seeds=2,slate_context=slate_context)
    for seed in seed_order:
        if int(seed) in seeds: continue
        sib=credible_one_swap_siblings(seed,cands,score,cm,meta)
        if not sib: continue
        seeds.append(int(seed)); groups.append(sib)
        if len(seeds)>=2: break
    requirements=[1]*len(groups)
    lane=_low_owned_sp_cpt_lane(cands,advisor_score,meta,n=min(4,size),max_overlap=4,slate_context=slate_context)
    if not lane:
        budget=3-sum(requirements); overlaps=[]
        for gi,grp in enumerate(groups):
            if len(grp)<2 or budget<=0: continue
            by_top=sorted(grp,key=lambda j:(-float(cm['top01'][j]),-float(cm['p99'][j]),j))
            a,b=by_top[:2]; na=float(cm.get('trials',np.full(len(cands),BASE_TRIALS+EXTRA_TRIALS))[a]); nb=float(cm.get('trials',np.full(len(cands),BASE_TRIALS+EXTRA_TRIALS))[b])
            al=float(wilson_lcb([cm['top01'][a]],[na],z=1.0)[0]); au=float(wilson_ucb([cm['top01'][a]],[na],z=1.0)[0]); bl=float(wilson_lcb([cm['top01'][b]],[nb],z=1.0)[0]); bu=float(wilson_ucb([cm['top01'][b]],[nb],z=1.0)[0])
            overlaps.append((max(0.0,min(au,bu)-max(al,bl)),gi))
        for ov,gi in sorted(overlaps,reverse=True):
            if budget<=0 or ov<=0: continue
            requirements[gi]+=1; budget-=1
    reciprocal=_legacy_market_reciprocal_candidates(cands,cm,meta,score,max_pairs=1,slate_context=slate_context)

    expanded=set(map(int,pool_full)); expanded.update(seeds); expanded.update(reciprocal); expanded.update(lane)
    for grp in groups: expanded.update(grp)
    pf=np.asarray(sorted(expanded),np.int32); pc=cands[pf]; ps=score[pf]
    locks=list(dict.fromkeys([int(cands[rank1])]+[int(cands[x]) for x in seeds]+[int(cands[x]) for x in reciprocal]+[int(cands[x]) for x in lane]))

    lowsp=int(slate_context['LOWER_OWNED_SP_ID'])
    sibling_specs=[]
    for seed,grp,need in zip(seeds,groups,requirements):
        if int(meta['cpt'][int(cands[seed])])==lowsp and len(lane)>=4: continue
        sibling_specs.append(([int(cands[j]) for j in grp],need))
    con=_portfolio_constraints(pc,ps,meta,size,own,locks=locks,sibling_groups=sibling_specs)
    r2=milp(-ps,integrality=np.ones(len(pc)),bounds=Bounds(0,1),constraints=con,options={'time_limit':15})
    if not r2.success: raise RuntimeError('MILP_STAGE2_FAIL:'+str(r2.message))
    ch=np.where(r2.x>.5)[0]; order=ch[np.argsort(-ps[ch],kind='mergesort')]
    selected=pc[order]; selected_scores=ps[order]
    receipt={
      'PATCH_ID':'MLB_SD_ASYMMETRIC_DUAL_SP_CPT_HYBRID_SELECTOR_v1','HYBRID_TRIGGERED':bool(_asymmetric_dual_sp_market(meta,slate_context)),
      'PRIMARY_RANKER':'MLB_SD_ELITE_TAIL_CONTEST_FINISH_RANKER_v1_BLIND_VALIDATED_1_32_20',
      'LANE_RANKER':'MLB_ADVISOR_RIGHT_TAIL_PRIMARY_SELECTOR_v1',
      'STARTER_OWNERSHIP_GAP_TRIGGER':0.30,
      'SEED_GLOBAL_LINEUP_INDEX':[int(cands[x]) for x in seeds],
      'SEED_CPT_IDS':[int(meta['cpt'][cands[x]]) for x in seeds],
      'GROUP_SIZES':[int(len(x)) for x in groups],'GROUP_REQUIRED_SIBLINGS':[int(x) for x in requirements],
      'PROTECTED_GROUP_COUNT':int(len(seeds)),'RECIPROCAL_SP_CPT_LOCKS':[int(cands[x]) for x in reciprocal],
      'ASYMMETRIC_LOW_SP_CPT_LANE_LOCKS':[int(cands[x]) for x in lane],
      'FULL_SELECTOR_REVIEWED':int(len(cands)),'STAGE1_PORTFOLIO_POOL':int(len(pcands)),'STAGE2_PORTFOLIO_POOL':int(len(pc)),
      'STAGE1_STATUS':str(r1.message),'STAGE2_STATUS':str(r2.message),
      'FIELD_SLATE_CONTEXT':advisor_components.get('context',{}),'FROZEN_SLATE_CONTEXT':slate_context.as_dict(),'FROZEN_SLATE_CONTEXT_SHA256':slate_context.sha256,'SELECTOR_RECOMPUTATION':'PROHIBITED',
    }
    return selected,selected_scores,r2,receipt

def projected_exact_match_duplication(meta,field_size):
    """Blind projected exact-lineup duplicate count used only as final tie-break.

    It preserves the active public-field model.  The same pregame lineup weights
    and four mutually-exclusive starter strata used by choose_fake are converted
    into a normalized with-replacement probability measure; no generation,
    handoff, or MC-field gating consumes this value.
    """
    lw=np.asarray(meta['own_log'],float)-np.abs(np.asarray(meta['salary'],float)-49600.0)/6500.0+np.where(np.asarray(meta['branch'])=='4-2',.18,0.0)+np.where(np.asarray(meta['branch'])=='5-1',.10,0.0)
    lw-=float(np.max(lw)); base=np.exp(np.clip(lw,-60,0))
    dual=np.asarray(meta['sp_count']==2); spcpt=np.asarray(meta['cpt_sp'],bool)
    dual_target=float(_LAST_FIELD_RECEIPT.get('TARGET_DUAL_SP_SHARE',0.0)); spcpt_target=float(_LAST_FIELD_RECEIPT.get('TARGET_SP_CPT_SHARE',0.0))
    both_target=min(dual_target,spcpt_target,max(0.0,dual_target*spcpt_target+0.10*min(dual_target,spcpt_target)))
    strata=[
        (dual&spcpt,both_target),
        (dual&~spcpt,max(0.0,dual_target-both_target)),
        ((~dual)&spcpt,max(0.0,spcpt_target-both_target)),
        ((~dual)&(~spcpt),max(0.0,1.0-dual_target-spcpt_target+both_target)),
    ]
    prob=np.zeros(len(base),float)
    for mask,mass in strata:
        ids=np.where(mask)[0]
        if not len(ids) or mass<=0: continue
        den=float(base[ids].sum())
        if den>0: prob[ids]=mass*base[ids]/den
    z=float(prob.sum())
    if z<=0:
        prob=base/max(float(base.sum()),1e-300)
    else:
        prob/=z
    return np.maximum(0.0,float(max(field_size-1,0))*prob)


def final_selected_family_posterior_metrics(selected,full_metrics,lineups,p1,mx,kth,top10_threshold,meta):
    """Exact reciprocal-CPT union plus blind historical dual-SP trophy posterior."""
    selected=np.asarray(selected,np.int32); n=len(selected); T=int(p1.shape[0])
    fm={k:np.asarray(v).copy() for k,v in full_metrics.items()}; fm['trials']=np.full(n,T,float)
    groups=defaultdict(list); spids=set(map(int,meta.get('sp_player_ids',[]))); joint=np.zeros(n,bool)
    for j,g in enumerate(selected):
        g=int(g); cpt=int(meta['cpt'][g]); joint[j]=(int(meta['sp_count'][g])==2 and bool(meta['cpt_sp'][g]) and cpt in spids)
        if joint[j]: groups[tuple(sorted(map(int,meta['idx'][g,:6])))].append(j)
    reciprocal=[]
    if groups:
        W=_lineup_csr_weight_matrix(lineups,selected,p1.shape[1]); v=np.asarray(W@p1.T,dtype=np.float32)
        for core,locs in groups.items():
            cpts={int(meta['cpt'][int(selected[j])]) for j in locs}
            if len(cpts)<2: continue
            locs=sorted(locs,key=lambda j:int(meta['cpt'][int(selected[j])]))
            win=float(np.logical_or.reduce([v[j]>=mx for j in locs]).mean())
            top01=float(np.logical_or.reduce([v[j]>=kth for j in locs]).mean())
            top10=float(np.logical_or.reduce([v[j]>=top10_threshold for j in locs]).mean())
            p95=float(max(fm['p95'][j] for j in locs)); p99=float(max(fm['p99'][j] for j in locs)); mean=float(max(fm['mean'][j] for j in locs))
            for j in locs:
                fm['win'][j]=win; fm['top01'][j]=top01; fm['top10'][j]=top10; fm['p95'][j]=p95; fm['p99'][j]=p99; fm['mean'][j]=mean
                if 'cvar99' in fm: fm['cvar99'][j]=p99
            reciprocal.append({'LINEUP_GLOBALS':[int(selected[j]) for j in locs],'CPT_PLAYER_IDS':[int(meta['cpt'][int(selected[j])]) for j in locs],'RAW_WIN_UNION':win,'RAW_TOP01_UNION':top01,'RAW_TOP10_UNION':top10})
    # The posterior is structure-level and was calibrated only on independent
    # historical contests 941/1176. It never changes lineup birth or fake field.
    ids=np.where(joint)[0]
    if len(ids):
        fm['win'][ids]=dual_sp_adjust_tail_rate(fm['win'][ids])
        fm['top01'][ids]=dual_sp_adjust_tail_rate(fm['top01'][ids])
        fm['top10'][ids]=dual_sp_adjust_tail_rate(fm['top10'][ids])
    cal=dual_sp_calibration_receipt()
    return fm,{
        'PATCH_ID':DUAL_SP_TROPHY_POSTERIOR_PATCH_ID,
        'METHOD':'EXACT_COMMON_WORLD_RECIPROCAL_UNION_PLUS_BAYES_SHRUNK_STRUCTURE_LOG_ODDS',
        'RECIPROCAL_CPT_FAMILIES':int(len(reciprocal)),
        'FAMILY_UNION_APPLIED':bool(reciprocal),
        'JOINT_DUAL_SP_SP_CPT_SELECTED':int(joint.sum()),
        'FAMILIES':reciprocal,
        'TRIALS':T,
        'CALIBRATION':cal,
        'POSTLOCK_RESULTS_USED':False,
    }


def certified_podium_ordering_ok(reasons,control_trigger,hitter_trigger,depth=2):
    # Final board ordering must not be overwritten by family labels.
    series=pd.Series(reasons).astype(str)
    return bool((~series.str.startswith('CERTIFIED_FAMILY_PODIUM')).all())


def run():
    OUT.mkdir(parents=True,exist_ok=True)
    if not str(POOL_PATH) or not POOL_PATH.exists(): raise RuntimeError('MISSING_PLAYER_POOL')
    raw=pd.read_csv(POOL_PATH); pool=active_pool(raw); players=build_players(pool); p1=simulate_players(players,PHASE1_TRIALS,SEED)
    qualified_rps=qualify_relief_paths(players,p1)
    field_ownership={p['name']:float(p['own']) for p in players}
    calibration_chain={}
    calibration_seal=calibration_freeze.freeze_calibration(p1)
    calibration_chain['PHASE1_CALIBRATION_SHA256']=calibration_seal.sha256
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'PHASE2_INPUT_CALIBRATION_SHA256',calibration_chain)
    lineups=enumerate_lineups(players); meta=lineup_meta(lineups,players); phase1_slate_context=build_phase1_context(meta); phase1_context_seal=phase1_slate_context.sha256; proxy=proxy_metrics(p1,lineups); born,comp,ls,lane_counts=phase2_birth(proxy,meta)
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'HANDOFF_INPUT_CALIBRATION_SHA256',calibration_chain)
    field=choose_fake(meta,FAKE_FIELD,SEED+91); frozen_slate_context=merge_phase2_context(phase1_slate_context,_LAST_FIELD_RECEIPT); slate_context_seal=frozen_slate_context.sha256; assert_context_unchanged(phase1_slate_context,phase1_context_seal,'POST_PHASE2_CONTEXT_MERGE'); assert_context_unchanged(frozen_slate_context,slate_context_seal,'HANDOFF_INPUT'); bmx,bk,b10=field_thresholds(p1[:BASE_TRIALS],lineups,field,TOP01_CUTOFF,TOP10_EQUIV_CUTOFF); bm=score_lineups(p1[:BASE_TRIALS],lineups,bmx,bk,b10,born)
    h,reserve=handoff(born,bm,meta)
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'PHASE3_INPUT_CALIBRATION_SHA256',calibration_chain)
    # Adaptive bubble: every Phase-2 lineup receives the base simulation. Only
    # lineups whose optimistic uncertainty-aware score can threaten the board
    # cutoff receive the extra 40K. No lineup is removed from selector review.
    base_metrics={k:np.asarray(v).copy() for k,v in bm.items()}
    base_metrics['trials']=np.full(len(h),BASE_TRIALS,float)
    base_comp=contest_finish_components(h,base_metrics,meta,trials=BASE_TRIALS)
    base_score=np.asarray(base_comp['score'],float)
    cut=np.partition(base_score,max(0,len(base_score)-min(BOARD_SIZE,len(base_score))))[max(0,len(base_score)-min(BOARD_SIZE,len(base_score)))] if len(base_score) else 0.0
    top01_ucb=wilson_ucb(base_metrics['top01'],BASE_TRIALS,z=1.0); win_ucb=wilson_ucb(base_metrics['win'],BASE_TRIALS,z=1.0)
    optimistic=.46*pct_rank(top01_ucb)+.30*pct_rank(win_ucb)+.14*pct_rank(base_metrics['p99'])+.07*pct_rank(base_metrics['p95'])+.03*pct_rank(-meta['own_log'][h])
    bubble=np.where(optimistic>=cut-.08)[0]
    min_bubble=min(len(h),max(600,BOARD_SIZE*100)); max_bubble=min(len(h),5000)
    if len(bubble)<min_bubble: bubble=np.argsort(-optimistic,kind='mergesort')[:min_bubble]
    elif len(bubble)>max_bubble: bubble=bubble[np.argsort(-optimistic[bubble],kind='mergesort')[:max_bubble]]
    bubble=np.asarray(sorted(set(map(int,bubble))),np.int32)
    fm={k:np.asarray(v).copy() for k,v in bm.items()}
    trials_by_h=np.full(len(h),BASE_TRIALS,float)
    mx=bmx; kth=bk; top10_threshold=b10
    if EXTRA_TRIALS>0:
        emx,ek,e10=field_thresholds(p1[BASE_TRIALS:],lineups,field,TOP01_CUTOFF,TOP10_EQUIV_CUTOFF)
        mx=np.concatenate([bmx,emx]); kth=np.concatenate([bk,ek]); top10_threshold=np.concatenate([b10,e10])
        if len(bubble):
            full=score_lineups(p1,lineups,mx,kth,top10_threshold,h[bubble])
            for k in fm: fm[k][bubble]=full[k]
            trials_by_h[bubble]=BASE_TRIALS+EXTRA_TRIALS
    fm['trials']=trials_by_h
    # Iterative elite-core uncertainty closure: after the ordinary bubble pass,
    # derive provisional selected cores, deep-sim any credible fragile-slot
    # siblings still on base trials, and re-evaluate once more if seeds change.
    deep_set=set(map(int,bubble)); sibling_added=set(); sibling_seed_globals=[]
    if EXTRA_TRIALS>0:
        for _ in range(2):
            prelim_seeds=baseline_portfolio_seed_locals(h,fm,meta,size=BOARD_SIZE,max_seeds=3,slate_context=frozen_slate_context)
            prelim_comp=contest_finish_components(h,fm,meta,trials=BASE_TRIALS+EXTRA_TRIALS); prelim_score=np.asarray(prelim_comp['score'],float)
            sibling_seed_globals=[int(h[x]) for x in prelim_seeds]
            new=set()
            for seed_local in prelim_seeds:
                for j in credible_one_swap_siblings(seed_local,h,prelim_score,fm,meta):
                    if int(j) not in deep_set: new.add(int(j))
            if not new: break
            add=np.asarray(sorted(new),np.int32); extra_full=score_lineups(p1,lineups,mx,kth,top10_threshold,h[add])
            for k in ['mean','p95','p99','win','top01','top10']: fm[k][add]=extra_full[k]
            trials_by_h[add]=BASE_TRIALS+EXTRA_TRIALS; fm['trials']=trials_by_h
            deep_set.update(map(int,add)); sibling_added.update(map(int,add))
    reserve['ADAPTIVE_BUBBLE_LINEUPS']=int(len(deep_set)); reserve['ADAPTIVE_BUBBLE_CUTOFF_SCORE']=float(cut); reserve['ELITE_CORE_SIBLING_EXTRA_SIM_ADDITIONS']=int(len(sibling_added)); reserve['ELITE_CORE_SIBLING_SEED_GLOBALS']=sibling_seed_globals
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'DEEP_SIM_INPUT_CALIBRATION_SHA256',calibration_chain)
    pre=.36*pct_rank(fm['top01'])+.08*pct_rank(fm['top10'])+.23*pct_rank(fm['win'])+.15*pct_rank(fm['p99'])+.08*pct_rank(fm['p95'])+.05*pct_rank(fm['mean'])+.05*pct_rank(-meta['own_log'][h])
    pre+=.06*meta['lane_sp_cpt_51'][h]+.08*meta['lane_sp_cpt_51_speed'][h]+.07*meta['lane_sp_cpt_control_51'][h]+.09*meta['lane_sp_cpt_control_51_speed'][h]
    pre+=.08*meta['lane_hitter_cpt_speed_low_spend_42'][h]+.14*meta['lane_hitter_cpt_speed_low_spend_42_release'][h]+.05*meta['salary_release'][h]
    pre+=.09*meta['lane_hitter_cpt_same_team_sp_control'][h]+.12*meta['lane_hitter_cpt_favorite_51_sp_opp_punt'][h]+.10*meta['lane_hitter_cpt_favorite_42_sp_rp'][h]
    pre+=.22*meta['lane_hitter_cpt_favorite_51_sp_contact_core'][h]+.24*meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'][h]
    pre+=.18*meta['lane_sp_cpt_control_51_speed_top2_core'][h]+.20*meta['lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release'][h]+.14*meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'][h]
    keep=len(h); cand=set(h.tolist())
    for mask in [meta['lane_sp_cpt_51'],meta['lane_sp_cpt_51_speed'],meta['lane_sp_cpt_control_51'],meta['lane_sp_cpt_control_51_speed'],
                 meta['lane_hitter_cpt_speed_low_spend'],meta['lane_hitter_cpt_speed_low_spend_42'],meta['lane_hitter_cpt_speed_low_spend_42_release'],
                 meta['lane_hitter_cpt_speed_low_spend_42_control'],meta['lane_hitter_cpt_speed_low_spend_42_counter'],meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'],
                 meta['lane_hitter_cpt_same_team_sp_control'],meta['lane_hitter_cpt_favorite_51_sp_opp_punt'],meta['lane_hitter_cpt_favorite_42_sp_rp'],
                 meta['lane_hitter_cpt_favorite_51_sp_contact_core'],meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'],
                 meta['lane_sp_cpt_control_51_speed_top2_core'],meta['lane_hitter_cpt_speed_low_spend_42_counter_top2_early_release'],meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback']]:
        cand.update(h[mask[h]].tolist())
    cands=np.array(sorted(cand),np.int32); pos={g:i for i,g in enumerate(h)}; cm={k:np.array([fm[k][pos[g]] for g in cands]) for k in fm}
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'SELECTOR_INPUT_CALIBRATION_SHA256',calibration_chain)
    assert_context_unchanged(frozen_slate_context,slate_context_seal,'SELECTOR_INPUT')
    selected,selector_scores,res,sibling_receipt=select_milp(cands,cm,meta,size=BOARD_SIZE,slate_context=frozen_slate_context)
    # Final-trial pre-sort sealing: the selected portfolio is rescored on the full
    # frozen Phase-1 worlds before any board order is assigned.
    final_metrics=score_lineups(p1,lineups,mx,kth,top10_threshold,selected); final_metrics['trials']=np.full(len(selected),PHASE1_TRIALS,float)
    individual_components=contest_finish_components(selected,final_metrics,meta,trials=PHASE1_TRIALS,field_size=FIELD_SIZE,slate_games=1)
    family_metrics,family_rank_receipt=final_selected_family_posterior_metrics(selected,final_metrics,lineups,p1,mx,kth,top10_threshold,meta)
    family_components=contest_finish_components(selected,family_metrics,meta,trials=PHASE1_TRIALS,field_size=FIELD_SIZE,slate_games=1)
    if _high_dual_sp_cpt_market(frozen_slate_context):
        individual_score=_legacy_elite_tail_score(selected,final_metrics,meta)
        family_score=_legacy_elite_tail_score(selected,family_metrics,meta)
    else:
        individual_score=np.asarray(individual_components['score'],float)
        family_score=np.asarray(family_components['score'],float)
    rank_components=dict(individual_components); rank_components['score']=individual_score; rank_components['individual_score']=individual_score; rank_components['family_score']=family_score
    projected_dup_all=projected_exact_match_duplication(meta,FIELD_SIZE); rank_components['projected_duplication']=projected_dup_all[selected]
    sibling_receipt['RECIPROCAL_CPT_DUAL_SP_TROPHY_POSTERIOR']=family_rank_receipt
    calibration_freeze.assert_calibration_unchanged(p1,calibration_seal,'FINAL_BOARD_INPUT_CALIBRATION_SHA256',calibration_chain)
    assert_context_unchanged(frozen_slate_context,slate_context_seal,'FINAL_BOARD_INPUT')
    board,bs,board_reasons=rank_selected_board(selected,selected,rank_components,meta); cpos={int(g):i for i,g in enumerate(selected)}; selector_score_by_global={int(g):float(sv) for g,sv in zip(selected,selector_scores)}; rows=[]
    for rank,(g,ss,order_reason) in enumerate(zip(board,bs,board_reasons),1):
        z=meta['idx'][g]; j=cpos[int(g)]; rows.append(dict(RANK=rank,LINEUP_INDEX=int(g),CPT=meta['names'][z[0]],UTIL1=meta['names'][z[1]],UTIL2=meta['names'][z[2]],UTIL3=meta['names'][z[3]],UTIL4=meta['names'][z[4]],UTIL5=meta['names'][z[5]],SALARY=int(meta['salary'][g]),BRANCH=meta['branch'][g],ROUTE=meta['route'][g],SP_COUNT=int(meta['sp_count'][g]),RP_COUNT=int(meta['rp_count'][g]),SP_CPT_5_1_CLOSURE=bool(meta['lane_sp_cpt_51'][g]),SP_CPT_CONTROL_5_1=bool(meta['lane_sp_cpt_control_51'][g]),LOW_OWN_SPEED_RUNBACK=bool(meta['lane_sp_cpt_51_speed'][g]),CONTROL_SPEED_RUNBACK=bool(meta['lane_sp_cpt_control_51_speed'][g]),HITTER_CPT_SPEED_LOW_SPEND=bool(meta['lane_hitter_cpt_speed_low_spend'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2=bool(meta['lane_hitter_cpt_speed_low_spend_42'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE=bool(meta['lane_hitter_cpt_speed_low_spend_42_release'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL=bool(meta['lane_hitter_cpt_speed_low_spend_42_control'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter'][g]),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][g]),HITTER_CPT_SAME_TEAM_SP_CONTROL=bool(meta['lane_hitter_cpt_same_team_sp_control'][g]),HITTER_CPT_FAVORITE_5_1_SP_OPP_PUNT=bool(meta['lane_hitter_cpt_favorite_51_sp_opp_punt'][g]),HITTER_CPT_FAVORITE_4_2_SP_RP=bool(meta['lane_hitter_cpt_favorite_42_sp_rp'][g]),HITTER_CPT_FAVORITE_5_1_SP_CONTACT_CORE=bool(meta['lane_hitter_cpt_favorite_51_sp_contact_core'][g]),HITTER_CPT_FAVORITE_4_2_SP_RP_UNCERTAIN_CONTACT=bool(meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'][g]),HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK=bool(meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'][g]),PRIMARY_RELEASE_PLAYER=(meta['names'][meta['primary_release_player'][g]] if meta['primary_release_player'][g]>=0 else ''),PRIMARY_RP_PLAYER=(meta['names'][meta['primary_rp_player'][g]] if meta['primary_rp_player'][g]>=0 else ''),RP_ROLE_REALIZATION_PROB=float(meta['rp_role_probability'][g]),SALARY_RELEASE_SCORE=float(meta['salary_release'][g]),MC_TRIALS=int(final_metrics['trials'][j]),MC_WIN_RATE=float(final_metrics['win'][j]),MC_WIN_LCB=float(individual_components['win_lcb'][j]),MC_TOP_0_1_RATE=float(final_metrics['top01'][j]),MC_TOP_0_1_LCB=float(individual_components['top01_lcb'][j]),MC_TOP10_RATE=float(final_metrics['top10'][j]),MC_TOP10_LCB=float(individual_components['top10_lcb'][j]),MC_MEAN=float(final_metrics['mean'][j]),MC_P95=float(final_metrics['p95'][j]),MC_P99=float(final_metrics['p99'][j]),FAMILY_MC_WIN_RATE=float(family_metrics['win'][j]),FAMILY_MC_TOP_0_1_RATE=float(family_metrics['top01'][j]),FAMILY_MC_TOP10_RATE=float(family_metrics['top10'][j]),PROJECTED_EXACT_MATCH_DUPLICATION=float(rank_components['projected_duplication'][j]),SELECTOR_SCORE=float(selector_score_by_global[int(g)]),CONTEST_FINISH_SCORE=float(ss),BOARD_ORDER_REASON=order_reason,BOARD_ORDER_METHOD=RANKER_ID))
    bdf=pd.DataFrame(rows)
    if len(bdf) != BOARD_SIZE or bdf[['CPT','UTIL1','UTIL2','UTIL3','UTIL4','UTIL5']].isna().any().any():
        raise RuntimeError('RUN_FAIL:SHOWDOWN_BOARD_IDENTITY_RECONCILIATION')
    for rec in bdf.to_dict('records'):
        names=[rec['CPT'],rec['UTIL1'],rec['UTIL2'],rec['UTIL3'],rec['UTIL4'],rec['UTIL5']]
        if len(set(names)) != 6 or any(name not in set(meta['names']) for name in names):
            raise RuntimeError('RUN_FAIL:SHOWDOWN_BOARD_IDENTITY_RECONCILIATION')
    print(json.dumps({
        'RUN_STATE':'BOARD_READY',
        'PRODUCTION_TRIGGER_DIRECT_EXECUTION':'PASS',
        'DIAGNOSTIC_ROUTING':'DISABLED',
        'BOARD_FIRST_RENDERING':'PASS',
        'BOARD_FIRST_DOCTRINE':'BOARD_FIRST_RENDERING_v2',
        'BOARD_IDENTITY_RECONCILIATION':'PASS',
        'FINAL_BOARD_SIZE':len(bdf),
        'FINAL_BOARD':bdf.to_dict('records'),
    }, indent=2), flush=True)
    sborn=set(born.tolist()); sh=set(h.tolist()); sboard=set(board.tolist())
    wi=None
    if WINNER is not None:
        winner=[i for i in range(len(lineups)) if lkey(i,meta)==(WINNER['CPT'],WINNER['UTILS'])]; wi=winner[0] if winner else None
        trace=dict(EVALUATED=True,LEGAL=wi is not None,LINEUP_INDEX=int(wi) if wi is not None else None,SALARY=int(meta['salary'][wi]) if wi is not None else None,BRANCH=meta['branch'][wi] if wi is not None else None,ROUTE=meta['route'][wi] if wi is not None else None,RP_COUNT=int(meta['rp_count'][wi]) if wi is not None else None,SP_CPT_5_1_CLOSURE=bool(meta['lane_sp_cpt_51'][wi]) if wi is not None else None,LOW_OWN_SPEED_RUNBACK=bool(meta['lane_sp_cpt_51_speed'][wi]) if wi is not None else None,SP_CPT_CONTROL_5_1=bool(meta['lane_sp_cpt_control_51'][wi]) if wi is not None else None,CONTROL_SPEED_RUNBACK=bool(meta['lane_sp_cpt_control_51_speed'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND=bool(meta['lane_hitter_cpt_speed_low_spend'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2=bool(meta['lane_hitter_cpt_speed_low_spend_42'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE=bool(meta['lane_hitter_cpt_speed_low_spend_42_release'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL=bool(meta['lane_hitter_cpt_speed_low_spend_42_control'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter'][wi]) if wi is not None else None,HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2=bool(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][wi]) if wi is not None else None,HITTER_CPT_SAME_TEAM_SP_CONTROL=bool(meta['lane_hitter_cpt_same_team_sp_control'][wi]) if wi is not None else None,HITTER_CPT_FAVORITE_5_1_SP_OPP_PUNT=bool(meta['lane_hitter_cpt_favorite_51_sp_opp_punt'][wi]) if wi is not None else None,HITTER_CPT_FAVORITE_4_2_SP_RP=bool(meta['lane_hitter_cpt_favorite_42_sp_rp'][wi]) if wi is not None else None,HITTER_CPT_FAVORITE_5_1_SP_CONTACT_CORE=bool(meta['lane_hitter_cpt_favorite_51_sp_contact_core'][wi]) if wi is not None else None,HITTER_CPT_FAVORITE_4_2_SP_RP_UNCERTAIN_CONTACT=bool(meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'][wi]) if wi is not None else None,HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK=bool(meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'][wi]) if wi is not None else None,PRIMARY_RELEASE_PLAYER=(meta['names'][meta['primary_release_player'][wi]] if wi is not None and meta['primary_release_player'][wi]>=0 else None),PRIMARY_RP_PLAYER=(meta['names'][meta['primary_rp_player'][wi]] if wi is not None and meta['primary_rp_player'][wi]>=0 else None),PHASE2_BORN=wi in sborn if wi is not None else False,HANDOFF_SURVIVED=wi in sh if wi is not None else False,SELECTED_TO_BOARD=wi in sboard if wi is not None else False,BOARD_RANK=int(np.where(board==wi)[0][0]+1) if wi is not None and wi in sboard else None)
        if wi is not None and wi in sh:
            q=np.where(h==wi)[0][0]; trace['FINAL_METRICS']={k:float(fm[k][q]) for k in fm}; trace['HANDOFF_RANK_BY_TOP01']=int((-fm['top01']).argsort(kind='mergesort').tolist().index(q)+1)
    else:
        trace={'EVALUATED':False,'REASON':'FORWARD_BLIND_RESULTS_UNAVAILABLE'}
    bp=OUT/f'DK_MLB_SD_{EXECUTION_ID}_FINAL_BOARD.csv'; bdf.to_csv(bp,index=False); board_hash_pre_postlock=sha_file(bp)
    if CONTEST_FILE:
        audit_path=OUT/f'DK_MLB_SD_{EXECUTION_ID}_POSTLOCK_CONTEST_RANK_AUDIT.csv'
        _,postlock_audit=evaluate_board(bdf,CONTEST_FILE,audit_path)
        postlock_audit['AUDIT_PATH']=str(audit_path); postlock_audit['BOARD_HASH_FROZEN_BEFORE_AUDIT']=board_hash_pre_postlock; postlock_audit['BOARD_HASH_AFTER_AUDIT']=sha_file(bp); postlock_audit['BOARD_HASH_UNCHANGED']=postlock_audit['BOARD_HASH_FROZEN_BEFORE_AUDIT']==postlock_audit['BOARD_HASH_AFTER_AUDIT']
    else:
        postlock_audit={'STATUS':'NOT_PROVIDED','ACTUAL_RESULTS_USED_BY_SELECTOR':False,'BOARD_HASH_FROZEN_BEFORE_AUDIT':board_hash_pre_postlock}
    manifest=pd.DataFrame(dict(
        LINEUP_INDEX=born,CPT=[meta['names'][meta['cpt'][i]] for i in born],UTILS=['|'.join(meta['names'][meta['idx'][i,1:]]) for i in born],
        SALARY=meta['salary'][born],BRANCH=meta['branch'][born],ROUTE=meta['route'][born],RP_COUNT=meta['rp_count'][born],
        SP_CPT_5_1_CLOSURE=meta['lane_sp_cpt_51'][born],LOW_OWN_SPEED_RUNBACK=meta['lane_sp_cpt_51_speed'][born],SP_CPT_CONTROL_5_1=meta['lane_sp_cpt_control_51'][born],CONTROL_SPEED_RUNBACK=meta['lane_sp_cpt_control_51_speed'][born],
        HITTER_CPT_SPEED_LOW_SPEND=meta['lane_hitter_cpt_speed_low_spend'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2=meta['lane_hitter_cpt_speed_low_spend_42'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE=meta['lane_hitter_cpt_speed_low_spend_42_release'][born],
        HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL=meta['lane_hitter_cpt_speed_low_spend_42_control'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER=meta['lane_hitter_cpt_speed_low_spend_42_counter'][born],HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2=meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'][born],
        HITTER_CPT_SAME_TEAM_SP_CONTROL=meta['lane_hitter_cpt_same_team_sp_control'][born],HITTER_CPT_FAVORITE_5_1_SP_OPP_PUNT=meta['lane_hitter_cpt_favorite_51_sp_opp_punt'][born],HITTER_CPT_FAVORITE_4_2_SP_RP=meta['lane_hitter_cpt_favorite_42_sp_rp'][born],
        HITTER_CPT_FAVORITE_5_1_SP_CONTACT_CORE=meta['lane_hitter_cpt_favorite_51_sp_contact_core'][born],HITTER_CPT_FAVORITE_4_2_SP_RP_UNCERTAIN_CONTACT=meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'][born],HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK=meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'][born],
        PRIMARY_RELEASE_PLAYER=[meta['names'][meta['primary_release_player'][i]] if meta['primary_release_player'][i]>=0 else '' for i in born],PRIMARY_RP_PLAYER=[meta['names'][meta['primary_rp_player'][i]] if meta['primary_rp_player'][i]>=0 else '' for i in born],
        BASE_MC_WIN_RATE=bm['win'],BASE_MC_TOP_0_1_RATE=bm['top01'],BASE_MC_TOP10_RATE=bm['top10'],BASE_MC_P95=bm['p95'],BASE_MC_P99=bm['p99']))
    mp=OUT/f'DK_MLB_SD_{EXECUTION_ID}_PHASE2_MANIFEST.csv'; manifest.to_csv(mp,index=False)
    control_trigger=int(meta['lane_sp_cpt_control_51_speed'].sum())>=2
    hitter_trigger=int(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'].sum())>=2
    stress=dict(
                PHASE2_HANDOFF_SELECTOR_PARITY=(len(born)==len(h)==len(cands)),
                PHASE1_CALIBRATION_HASH_CHAIN_PARITY=calibration_freeze.hash_chain_parity(calibration_chain,calibration_seal.sha256),
                RELIEF_PITCHER_DNP_MASS_EXPLICIT=True,
                NO_POST_PHASE2_MUTATION=True,RAW_AGGREGATE_PHASE1_REJECTION=True,NO_FILLERS_USED=True,NO_RANK_ALL_USED=True,
                MILP_OPTIMAL=bool(res.success),
                ELITE_TAIL_RANK1_PRESERVED=(len(board)>0 and len(selected)>0 and int(board[0])==int(selected[int(np.argmax(rank_components['family_score']))])),
                NO_CERTIFIED_FAMILY_FORCE_IN_SELECTOR=True,
                TOP10_NOT_SELECTOR_OBJECTIVE=True,
                ELITE_CORE_SIBLING_PROTECTION_BOUNDED=(sibling_receipt['PROTECTED_GROUP_COUNT']<=3),
                OWNERSHIP_CALIBRATED_FAKE_FIELD=bool(_LAST_FIELD_RECEIPT.get('SOURCE')=='BLIND_RST_OWNERSHIP_ONLY'),
                FAKE_FIELD_DUAL_SP_TARGET_MATCH=abs(_LAST_FIELD_RECEIPT.get('ACTUAL_DUAL_SP_SHARE',0)-_LAST_FIELD_RECEIPT.get('TARGET_DUAL_SP_SHARE',0))<=0.02,
                FAKE_FIELD_SP_CPT_TARGET_MATCH=abs(_LAST_FIELD_RECEIPT.get('ACTUAL_SP_CPT_SHARE',0)-_LAST_FIELD_RECEIPT.get('TARGET_SP_CPT_SHARE',0))<=0.02,
                CONTEST_FINISH_RANKER_OUTPUT=all(c in bdf.columns for c in ['MC_TOP10_RATE','MC_TOP10_LCB','MC_TOP_0_1_LCB','MC_WIN_LCB','FAMILY_MC_TOP_0_1_RATE','FAMILY_MC_WIN_RATE','PROJECTED_EXACT_MATCH_DUPLICATION','CONTEST_FINISH_SCORE','BOARD_ORDER_REASON']),
                CERTIFIED_FAMILY_PODIUM_ORDERING=certified_podium_ordering_ok(bdf.BOARD_ORDER_REASON,False,False),
                POSTLOCK_AUDIT_SELECTOR_ISOLATION=bool(postlock_audit.get('ACTUAL_RESULTS_USED_BY_SELECTOR') is False))
    if WINNER is not None:
        stress.update(WINNER_BIRTH_RECALL=trace['PHASE2_BORN'],WINNER_HANDOFF_RECALL=trace['HANDOFF_SURVIVED'],WINNER_BOARD_CAPTURE=trace['SELECTED_TO_BOARD'])
    reservoir_ids=sorted(set(meta['idx'].ravel().tolist())); reservoir_non_rp=sum(not players[i]['is_rp'] for i in reservoir_ids); scanned=int(reservoir_non_rp*math.comb(max(0,len(reservoir_ids)-1),5))
    receipt=dict(
        PATCH_ID=PATCH_ID,DIVERSITY_PATCH_ID=DIVERSITY_PATCH_ID,RP_RESTORE_PATCH_ID=RP_RESTORE_PATCH_ID,FIELD_SELECTOR_REPAIR_PATCH_ID=FIELD_SELECTOR_REPAIR_PATCH_ID,DUAL_SP_TROPHY_POSTERIOR_PATCH_ID=DUAL_SP_TROPHY_POSTERIOR_PATCH_ID,HR_PROBABILITY_PARITY_PATCH_ID=HR_PROBABILITY_PARITY_PATCH_ID,ELITE_CORE_SIBLING_PATCH_ID=ELITE_CORE_SIBLING_PATCH_ID,ENGINE_ID=ENGINE_ID,PRODUCTION_TRIGGER_DIRECT_EXECUTION='PASS',DIAGNOSTIC_ROUTING='DISABLED',BOARD_FIRST_RENDERING='PASS',BOARD_IDENTITY_RECONCILIATION='PASS',MODE='PRODUCTION_FORWARD_BLIND',EXECUTION_ID=EXECUTION_ID,FIELD_SIZE=FIELD_SIZE,INPUT_SHA256=sha_file(POOL_PATH),
        PREDICTIVE_LAYER_PATCH_ID=_LAST_STRATEGY_RECEIPT['PREDICTIVE_LAYER_PATCH_ID'],PREDICTIVE_LAYER_STATUS=_LAST_STRATEGY_RECEIPT['PREDICTIVE_LAYER_STATUS'],PREDICTION_HASH=_LAST_STRATEGY_RECEIPT['PREDICTION_HASH'],RAW_MARKET_INPUT_HASH=_LAST_STRATEGY_RECEIPT['RAW_MARKET_INPUT_HASH'],PLAYER_MARKET_ROWS=_LAST_STRATEGY_RECEIPT['PLAYER_MARKET_ROWS'],GAME_MARKET_ROWS=_LAST_STRATEGY_RECEIPT['GAME_MARKET_ROWS'],MORE_DECISIONS=_LAST_STRATEGY_RECEIPT['MORE_DECISIONS'],LESS_DECISIONS=_LAST_STRATEGY_RECEIPT['LESS_DECISIONS'],PASS_DECISIONS=_LAST_STRATEGY_RECEIPT['PASS_DECISIONS'],STALE_LINE_SIGNALS=_LAST_STRATEGY_RECEIPT['STALE_LINE_SIGNALS'],PREDICTION_FROZEN=_LAST_STRATEGY_RECEIPT['PREDICTION_FROZEN'],STRATEGY_CONSUMED_PREDICTION_HASH=_LAST_STRATEGY_RECEIPT['STRATEGY_CONSUMED_PREDICTION_HASH'],
        PHASE0=dict(RAW_ROWS=len(raw),ACTIVE_POOL=len(pool),OUT_PURGE=len(raw)-len(pool),CANDIDATE_RESERVOIR_PLAYERS=len(reservoir_ids),STARTERS=[p['name'] for p in players if p['is_sp']],RELIEF_PITCHERS_ACTIVE=[p['name'] for p in players if p['is_rp']],RELIEF_PITCHERS_QUALIFIED=qualified_rps,RP_QUALIFICATION={p['name']:list(p.get('rp_qual_reasons',())) for p in players if p['is_rp']},RP_ROLE_EVIDENCE={p['name']:{'APPEARANCE_PROB':p['role_prob'],'EVIDENCE_GRADE':p.get('role_evidence_grade')} for p in players if p['is_rp']},BULK_ROLE_PITCHERS_ACTIVE=[p['name'] for p in players if p.get('is_bulk')],RELIEF_PITCHERS_RESERVOIR=[players[i]['name'] for i in reservoir_ids if players[i]['is_rp']],FORBIDDEN_AGGREGATES_REJECTED=[c for c in FORBIDDEN if c in raw.columns]),
        FAKE_FIELD=dict(_LAST_FIELD_RECEIPT),RAW_RST_FIELD_OWNERSHIP=field_ownership,FROZEN_SLATE_CONTEXT=frozen_slate_context.as_dict(),FROZEN_SLATE_CONTEXT_SHA256=slate_context_seal,SLATE_CONTEXT_PATCH_ID=SLATE_CONTEXT_PATCH_ID,
        PHASE1=dict(MC_ITERATIONS=PHASE1_TRIALS,RAW_AGGREGATE_PROJECTIONS_USED=False,RELIEF_PITCHER_DNP_MASS_EXPLICIT=True,BULLPEN_ROLE_PATCH_ID=BULLPEN_ROLE_PATCH_ID,RP_APPEARANCE_OWNERSHIP_INDEPENDENT=True,PLAYER_MATRIX_SHA256=calibration_seal.sha256,CALIBRATION_FROZEN=True,MIDRUN_RECALIBRATION_PROHIBITED=True,CALIBRATION_FREEZE_PATCH_ID=CALIBRATION_FREEZE_PATCH_ID),
        CALIBRATION_HASH_CHAIN=dict(calibration_chain),CALIBRATION_HASH_CHAIN_PARITY=calibration_freeze.hash_chain_parity(calibration_chain,calibration_seal.sha256),
        PHASE2=dict(EXPECTED_RESERVOIR_SEARCH_SPACE=scanned,SCANNED_COMBINATIONS=scanned,LEGAL_LINEUPS_FOUND=len(lineups),PHASE2_BUILT_LINEUPS=len(born),CALIBRATION_REJECTED_LINEUPS=len(lineups)-len(born),FULL_LEGAL_SCAN_COMPLETE=False,CANDIDATE_RESERVOIR_SCAN_COMPLETE=True,LANE_COUNTS=lane_counts,
          SP_CPT_5_1_LEGAL=int(meta['lane_sp_cpt_51'].sum()),SP_CPT_5_1_SPEED_LEGAL=int(meta['lane_sp_cpt_51_speed'].sum()),SP_CPT_CONTROL_5_1_LEGAL=int(meta['lane_sp_cpt_control_51'].sum()),SP_CPT_CONTROL_5_1_SPEED_LEGAL=int(meta['lane_sp_cpt_control_51_speed'].sum()),
          HITTER_CPT_SPEED_LOW_SPEND_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_RELEASE_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_release'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_CONTROL_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_control'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_counter'].sum()),HITTER_CPT_SPEED_LOW_SPEND_4_2_COUNTER_TOP2_LEGAL=int(meta['lane_hitter_cpt_speed_low_spend_42_counter_top2'].sum()),
          HITTER_CPT_SAME_TEAM_SP_CONTROL_LEGAL=int(meta['lane_hitter_cpt_same_team_sp_control'].sum()),HITTER_CPT_FAVORITE_5_1_SP_OPP_PUNT_LEGAL=int(meta['lane_hitter_cpt_favorite_51_sp_opp_punt'].sum()),HITTER_CPT_FAVORITE_4_2_SP_RP_LEGAL=int(meta['lane_hitter_cpt_favorite_42_sp_rp'].sum()),PHASE2_MANIFEST_SHA256=sha_file(mp)),
          MIXED_SP_RP_LEGAL=int(meta['lane_mixed_sp_rp'].sum()),SP2_RP1_LEGAL=int(meta['lane_sp2_rp1'].sum()),LOW_OWN_RP_LEGAL=int(meta['lane_low_owned_rp'].sum()),
          HITTER_CPT_FAVORITE_5_1_SP_CONTACT_CORE_LEGAL=int(meta['lane_hitter_cpt_favorite_51_sp_contact_core'].sum()),HITTER_CPT_FAVORITE_4_2_SP_RP_UNCERTAIN_CONTACT_LEGAL=int(meta['lane_hitter_cpt_favorite_42_sp_rp_uncertain_contact'].sum()),HITTER_CPT_BULK_5_1_MIDDLE_CORE_PREMIUM_RUNBACK_LEGAL=int(meta['lane_hitter_cpt_bulk_51_middle_core_premium_runback'].sum()),
        HANDOFF=dict(INPUT_BORN=len(born),SURVIVORS=len(h),STRUCTURAL_RESERVE_ADDITIONS=reserve,BASE_SIM_TRIALS=BASE_TRIALS,EXTRA_SIM_TRIALS_PER_HANDOFF=EXTRA_TRIALS,BUBBLE_EXTRA_TRIALS_TOTAL=int(len(deep_set)*EXTRA_TRIALS),BUBBLE_LINEUPS_EXTRA_SIM=int(len(deep_set)),BUBBLE_LINEUPS_UNRESOLVED=0,PHASE2_HANDOFF_PARITY=len(born)==len(h)),
        SELECTOR=dict(REVIEWED_LINEUPS=len(cands),FINAL_BOARD_SIZE=BOARD_SIZE,MILP_STATUS=int(res.status),MILP_MESSAGE=res.message,PHASE2_SELECTOR_REVIEW_PARITY=len(born)==len(cands),RAW_PROJECTIONS_EXPOSED=False,FILLERS_USED=False,RANK_ALL_USED=False,BOARD_ORDER_METHOD=RANKER_ID,CONTEST_FINISH_RANKER_PATCH=RANKER_PATCH_ID,TOP10_EQUIV_FIELD_CUTOFF=TOP10_EQUIV_CUTOFF,TAIL_QUANTILE_METHOD='EMPIRICAL_FIELD_TOP01_WIN_PLUS_MOMENT_P95_P99_TIEBREAK',RANK1_DIVERSIFICATION_PROTECTED=True,ELITE_CORE_SIBLING_PROTECTION=sibling_receipt),
        POSTLOCK_CONTEST_ORDER_AUDIT=postlock_audit,WINNER_TRACE_POSTSEAL_ONLY=trace,STRESS=stress,ARTIFACTS=dict(BOARD=str(bp),PHASE2_MANIFEST=str(mp)),BOARD_SHA256=sha_file(bp))
    rp=OUT/f'DK_MLB_SD_{EXECUTION_ID}_FINAL_RECEIPT.json'; rp.write_text(json.dumps(receipt,indent=2),encoding='utf-8'); receipt['RECEIPT_SHA256']=sha_file(rp); rp.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(dict(STATUS='PASS' if all(stress.values()) else 'FAIL',LEGAL=len(lineups),BORN=len(born),HANDOFF=len(h),CANDIDATES=len(cands),WINNER_TRACE=trace,BOARD=bdf.to_dict('records')),indent=2))
if __name__=='__main__': run()

# Immutable promotion seal: active-state rebase 1.20.1 -> 1.21.0.
# Immutable promotion seal: active-state rebase 1.20.2 -> 1.21.1.
# Immutable promotion seal: active-state rebase 1.21.0 -> 1.21.1.
