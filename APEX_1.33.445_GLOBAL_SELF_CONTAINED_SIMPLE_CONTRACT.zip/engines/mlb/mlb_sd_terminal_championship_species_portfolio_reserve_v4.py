from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import numpy as np
import pandas as pd

PATCH_ID='MLB_SD_INDIVIDUAL_CONFIDENCE_THEN_MARGINAL_DIVERSITY_PORTFOLIO_GATE_v1'
BOARD_SIZE=5
CROSS_WORLD_TRIAD_SEATS=3
BALANCED_RESERVE_SEATS=2
HITTER_CPT_ONE_SP_RESERVE_SEATS=1
MARGINAL_DIVERSITY_OVERLAP_SLACK=1
EXTREME_CONCENTRATION_SHARE=0.80
INDIVIDUAL_CONFIDENCE_FLOOR_PCTL=0.98
BASELINE_TOP01_FRACTION_MIN=0.40
BASELINE_WIN_FRACTION_MIN=0.35
BASELINE_P99_FRACTION_MIN=0.90

@dataclass(frozen=True)
class ReserveResult:
    selected_ids: tuple[int,...]
    receipt: dict[str,Any]


def _playerset(row: pd.Series) -> frozenset[str]:
    return frozenset(str(row[x]).casefold() for x in ('CPT','UTIL1','UTIL2','UTIL3','UTIL4','UTIL5'))


def _overlap(a: pd.Series,b: pd.Series) -> int:
    return len(_playerset(a)&_playerset(b))


def _pct_rank(s: pd.Series) -> pd.Series:
    x=pd.to_numeric(s,errors='coerce').replace([np.inf,-np.inf],np.nan)
    if x.notna().sum() <= 1:
        return pd.Series(np.ones(len(x),dtype=float),index=x.index)
    return x.rank(pct=True,method='average').fillna(0.0).astype(float)


def _attach_individual_confidence(rows:pd.DataFrame)->pd.DataFrame:
    d=rows.copy()
    required=('MC_TOP_0_1_RATE','MC_WIN_RATE','MC_P99')
    for c in required:
        if c not in d:
            raise ValueError(f'INDIVIDUAL_CONFIDENCE_METRIC_MISSING:{c}')
        d[c]=pd.to_numeric(d[c],errors='coerce').fillna(0.0)
    d['IND_TOP01_PCTL']=_pct_rank(d['MC_TOP_0_1_RATE'])
    d['IND_WIN_PCTL']=_pct_rank(d['MC_WIN_RATE'])
    d['IND_P99_PCTL']=_pct_rank(d['MC_P99'])
    pct=d[['IND_TOP01_PCTL','IND_WIN_PCTL','IND_P99_PCTL']].clip(1e-12,1.0)
    d['INDIVIDUAL_CONFIDENCE_ROBUST_PCTL']=pct.min(axis=1)
    d['INDIVIDUAL_CONFIDENCE_GMEAN_PCTL']=np.exp(np.log(pct).mean(axis=1))
    d['INDIVIDUAL_PERCENTILE_PASS']=(d['INDIVIDUAL_CONFIDENCE_ROBUST_PCTL']>=INDIVIDUAL_CONFIDENCE_FLOOR_PCTL)
    d['INDIVIDUAL_CONFIDENCE_PASS']=d['INDIVIDUAL_PERCENTILE_PASS']
    return d




def _apply_baseline_relative_gate(d:pd.DataFrame, baseline_board:pd.DataFrame)->tuple[pd.DataFrame,dict[str,float]]:
    out=d.copy()
    ids=baseline_board['LINEUP_INDEX'].astype(int).tolist()
    base=out[out['LINEUP_ID'].astype(int).isin(ids)]
    if len(base)!=len(set(ids)):
        missing=sorted(set(ids)-set(base['LINEUP_ID'].astype(int).tolist()))
        raise ValueError(f'BASELINE_LINEUP_METRICS_MISSING:{missing}')
    floors={
        'TOP01':float(pd.to_numeric(base['MC_TOP_0_1_RATE'],errors='coerce').fillna(0).min()),
        'WIN':float(pd.to_numeric(base['MC_WIN_RATE'],errors='coerce').fillna(0).min()),
        'P99':float(pd.to_numeric(base['MC_P99'],errors='coerce').fillna(0).min()),
    }
    out['BASELINE_RELATIVE_TOP01_PASS']=out['MC_TOP_0_1_RATE'] >= floors['TOP01']*BASELINE_TOP01_FRACTION_MIN
    out['BASELINE_RELATIVE_WIN_PASS']=out['MC_WIN_RATE'] >= floors['WIN']*BASELINE_WIN_FRACTION_MIN
    out['BASELINE_RELATIVE_P99_PASS']=out['MC_P99'] >= floors['P99']*BASELINE_P99_FRACTION_MIN
    out['BASELINE_RELATIVE_PASS']=out[['BASELINE_RELATIVE_TOP01_PASS','BASELINE_RELATIVE_WIN_PASS','BASELINE_RELATIVE_P99_PASS']].all(axis=1)
    out['INDIVIDUAL_CONFIDENCE_PASS']=out['INDIVIDUAL_PERCENTILE_PASS'] & out['BASELINE_RELATIVE_PASS']
    return out,floors

def _baseline_stats(board: pd.DataFrame)->dict[str,Any]:
    cpt=board['CPT'].astype(str); branch=board['BRANCH'].astype(str); sp=pd.to_numeric(board['SP_COUNT'],errors='coerce').fillna(9)
    cpt_is_sp=board.get('CPT_IS_SP',pd.Series([False]*len(board),index=board.index)).astype(bool)
    return {
        'SAME_CPT_SHARE':float(cpt.value_counts(normalize=True).max()) if len(cpt) else 0.0,
        'FIVE_ONE_SHARE':float((branch=='5-1').mean()) if len(branch) else 0.0,
        'ZERO_SP_COUNT':int((sp==0).sum()),
        'HITTER_CPT_ONE_SP_COUNT':int(((sp==1)&(~cpt_is_sp)).sum()),
    }


def _attach_recurrence(rows:pd.DataFrame, telemetry:dict[str,np.ndarray])->pd.DataFrame:
    ids=np.asarray(telemetry['candidate_ids'],dtype=np.int64)
    rec=np.asarray(telemetry['recurrence'],dtype=np.int16)
    mr=np.asarray(telemetry['minrank'],dtype=np.int16)
    if mr.shape[0]!=5: raise ValueError('RECURRENCE_WINDOW_COUNT_MUST_BE_5')
    t=pd.DataFrame({'LINEUP_ID':ids,'WORLD_COVERAGE_COUNT':rec})
    for i in range(5): t[f'WORLD_{i+1}_LOCAL_RANK']=mr[i]
    if 'added_mask' in telemetry:
        t['CROSS_WORLD_ADDED']=np.asarray(telemetry['added_mask'],dtype=bool)
    else:
        t['CROSS_WORLD_ADDED']=False
    out=rows.merge(t,on='LINEUP_ID',how='left')
    out['WORLD_COVERAGE_COUNT']=out['WORLD_COVERAGE_COUNT'].fillna(0).astype(np.int16)
    out['CROSS_WORLD_ADDED']=out['CROSS_WORLD_ADDED'].fillna(False).astype(bool)
    for i in range(5): out[f'WORLD_{i+1}_LOCAL_RANK']=out[f'WORLD_{i+1}_LOCAL_RANK'].fillna(99).astype(np.int16)
    out['CPT_ROLE_EVIDENCE']=pd.to_numeric(out['CPT_CONDITIONAL_SUPPORT'],errors='coerce').fillna(0)*pd.to_numeric(out['CPT_STRATEGIC_LEVERAGE'],errors='coerce').fillna(0)
    out=_attach_individual_confidence(out)
    if 'CPT_IS_SP' not in out:
        out['CPT_IS_SP']=False
    out['CPT_IS_SP']=out['CPT_IS_SP'].fillna(False).astype(bool)
    return out


def _best_confidence_rows(d:pd.DataFrame)->pd.DataFrame:
    cols=['AI_PLAYERSET_CANONICAL','INDIVIDUAL_CONFIDENCE_PASS','INDIVIDUAL_CONFIDENCE_ROBUST_PCTL','INDIVIDUAL_CONFIDENCE_GMEAN_PCTL','MC_TOP_0_1_RATE','MC_WIN_RATE','MC_P99','PROJECTED_EXACT_MATCH_DUPLICATION','LINEUP_ID']
    asc=[True,False,False,False,False,False,False,True,True]
    return d.sort_values(cols,ascending=asc,kind='mergesort').drop_duplicates('AI_PLAYERSET_CANONICAL')


def _family_table(rows:pd.DataFrame)->pd.DataFrame:
    d=rows.copy()
    if 'AI_PLAYERSET_CANONICAL' not in d:
        d['AI_PLAYERSET_CANONICAL']=d[['CPT','UTIL1','UTIL2','UTIL3','UTIL4','UTIL5']].astype(str).apply(lambda r:'|'.join(sorted(x.casefold() for x in r)),axis=1)
    d['REC4']=(d['WORLD_COVERAGE_COUNT']>=4).astype(np.int8)
    numeric=['MC_TOP_0_1_RATE','MC_WIN_RATE','MC_P99','AI_LINEUP_CONDITIONAL_SUPPORT_SUM','AI_MARKET_TAIL_SUPPORT_PCTL','PROJECTED_EXACT_MATCH_DUPLICATION','SP_COUNT']
    for c in numeric:
        d[c]=pd.to_numeric(d[c],errors='coerce')
    g=d.groupby('AI_PLAYERSET_CANONICAL',sort=False,observed=True)
    agg=g.agg(
        N_ORIENT=('LINEUP_ID','count'),
        MAX_REC=('WORLD_COVERAGE_COUNT','max'),SUM_REC=('WORLD_COVERAGE_COUNT','sum'),REC4_ORIENT=('REC4','sum'),
        ANY_CROSS_WORLD_ADDED=('CROSS_WORLD_ADDED','max'),
        SUM_TOP01=('MC_TOP_0_1_RATE','sum'),MAX_TOP01=('MC_TOP_0_1_RATE','max'),MAX_WIN=('MC_WIN_RATE','max'),MAX_P99=('MC_P99','max'),
        MAX_SUPPORT=('AI_LINEUP_CONDITIONAL_SUPPORT_SUM','max'),MAX_MARKET_TAIL=('AI_MARKET_TAIL_SUPPORT_PCTL','max'),MIN_DUP=('PROJECTED_EXACT_MATCH_DUPLICATION','min'),
        SP_COUNT_MIN=('SP_COUNT','min'),SP_COUNT_MAX=('SP_COUNT','max'),
        INDIVIDUAL_PASS_ORIENT=('INDIVIDUAL_CONFIDENCE_PASS','sum'),
        MAX_INDIVIDUAL_CONFIDENCE=('INDIVIDUAL_CONFIDENCE_ROBUST_PCTL','max'),
        MAX_INDIVIDUAL_GMEAN=('INDIVIDUAL_CONFIDENCE_GMEAN_PCTL','max'),
    ).reset_index()
    mins=[]
    for i in range(5): mins.append(g[f'WORLD_{i+1}_LOCAL_RANK'].min().rename(f'FAM_W{i+1}_BEST_RANK'))
    m=pd.concat(mins,axis=1).reset_index(); agg=agg.merge(m,on='AI_PLAYERSET_CANONICAL',how='left')
    a=agg[[f'FAM_W{i}_BEST_RANK' for i in range(1,6)]].to_numpy()
    agg['FAMILY_RANK1_COV']=(a<=1).sum(axis=1); agg['FAMILY_TOP2_COV']=(a<=2).sum(axis=1)

    role=d.sort_values(['AI_PLAYERSET_CANONICAL','CPT_ROLE_EVIDENCE','CPT_CONDITIONAL_SUPPORT','CPT_MUTATION_SUPPORT','CPT','LINEUP_ID'],ascending=[True,False,False,False,True,True],kind='mergesort').drop_duplicates('AI_PLAYERSET_CANONICAL')
    role=role[['AI_PLAYERSET_CANONICAL','CPT','BRANCH','ROUTE','CPT_ROLE_EVIDENCE']].rename(columns={'CPT':'BEST_ROLE_CPT','BRANCH':'BRANCH_MODE','ROUTE':'ROUTE_MODE','CPT_ROLE_EVIDENCE':'BEST_ROLE_SCORE'})

    conf=_best_confidence_rows(d)
    conf=conf[['AI_PLAYERSET_CANONICAL','LINEUP_ID','CPT','BRANCH','ROUTE','CPT_IS_SP','SP_COUNT','INDIVIDUAL_CONFIDENCE_ROBUST_PCTL','INDIVIDUAL_CONFIDENCE_GMEAN_PCTL','MC_TOP_0_1_RATE','MC_WIN_RATE','MC_P99']].rename(columns={
        'LINEUP_ID':'BEST_CONF_LINEUP_ID','CPT':'BEST_CONF_CPT','BRANCH':'BEST_CONF_BRANCH','ROUTE':'BEST_CONF_ROUTE','CPT_IS_SP':'BEST_CONF_CPT_IS_SP','SP_COUNT':'BEST_CONF_SP_COUNT',
        'INDIVIDUAL_CONFIDENCE_ROBUST_PCTL':'BEST_CONF_ROBUST_PCTL','INDIVIDUAL_CONFIDENCE_GMEAN_PCTL':'BEST_CONF_GMEAN_PCTL','MC_TOP_0_1_RATE':'BEST_CONF_TOP01','MC_WIN_RATE':'BEST_CONF_WIN','MC_P99':'BEST_CONF_P99'})
    return agg.merge(role,on='AI_PLAYERSET_CANONICAL',how='left').merge(conf,on='AI_PLAYERSET_CANONICAL',how='left')


def _cross_world_triad(fam:pd.DataFrame)->pd.DataFrame:
    e=fam[(fam['INDIVIDUAL_PASS_ORIENT']>=1)&(fam['ANY_CROSS_WORLD_ADDED'])&(fam['SP_COUNT_MIN']==0)&(fam['FAMILY_RANK1_COV']==5)&(fam['FAMILY_TOP2_COV']==5)&(fam['REC4_ORIENT']>=1)].copy()
    return e.sort_values(['BEST_CONF_ROBUST_PCTL','BEST_CONF_GMEAN_PCTL','REC4_ORIENT','SUM_TOP01','SUM_REC','MAX_P99','AI_PLAYERSET_CANONICAL'],ascending=[False,False,False,False,False,False,True],kind='mergesort').head(CROSS_WORLD_TRIAD_SEATS)


def _balanced_reserve(fam:pd.DataFrame)->pd.DataFrame:
    e=fam[(fam['INDIVIDUAL_PASS_ORIENT']>=1)&(fam['SP_COUNT_MIN']==0)&(fam['FAMILY_RANK1_COV']==5)&(fam['FAMILY_TOP2_COV']==5)&(fam['BRANCH_MODE']=='3-3')].copy()
    if e.empty: return e
    lanes=e.groupby('BEST_CONF_CPT',as_index=False).agg(BEST_CONF_ROBUST_PCTL=('BEST_CONF_ROBUST_PCTL','max'),BEST_CONF_GMEAN_PCTL=('BEST_CONF_GMEAN_PCTL','max'),MAX_SUM_TOP01=('SUM_TOP01','max'))
    lanes=lanes.sort_values(['BEST_CONF_ROBUST_PCTL','BEST_CONF_GMEAN_PCTL','MAX_SUM_TOP01','BEST_CONF_CPT'],ascending=[False,False,False,True],kind='mergesort').head(BALANCED_RESERVE_SEATS)
    picks=[]
    for cpt in lanes['BEST_CONF_CPT']:
        s=e[e['BEST_CONF_CPT']==cpt].copy()
        s=s.sort_values(['BEST_CONF_ROBUST_PCTL','BEST_CONF_GMEAN_PCTL','SUM_TOP01','MAX_P99','SUM_REC','AI_PLAYERSET_CANONICAL'],ascending=[False,False,False,False,False,True],kind='mergesort')
        picks.append(s.iloc[0])
    return pd.DataFrame(picks)


def _attach_baseline_overlap(rows:pd.DataFrame, baseline_board:pd.DataFrame, full_rows:pd.DataFrame)->pd.DataFrame:
    out=rows.copy()
    if baseline_board.empty:
        out['BASELINE_MAX_PLAYER_OVERLAP']=0
        out['BASELINE_AVG_PLAYER_OVERLAP']=0.0
        return out
    ids=baseline_board['LINEUP_INDEX'].astype(int).tolist()
    base=full_rows[full_rows['LINEUP_ID'].astype(int).isin(ids)].copy()
    if len(base)!=len(set(ids)):
        missing=sorted(set(ids)-set(base['LINEUP_ID'].astype(int).tolist()))
        raise ValueError(f'BASELINE_LINEUP_PLAYERS_MISSING:{missing}')
    bsets=[_playerset(r) for _,r in base.iterrows()]
    max_ov=[]; avg_ov=[]
    for _,r in out.iterrows():
        s=_playerset(r); ovs=[len(s & b) for b in bsets]
        max_ov.append(int(max(ovs) if ovs else 0)); avg_ov.append(float(np.mean(ovs) if ovs else 0.0))
    out['BASELINE_MAX_PLAYER_OVERLAP']=np.asarray(max_ov,np.int8)
    out['BASELINE_AVG_PLAYER_OVERLAP']=np.asarray(avg_ov,float)
    return out


def _hitter_cpt_one_sp_lane(rows:pd.DataFrame, baseline_board:pd.DataFrame)->pd.DataFrame:
    e=rows[(rows['INDIVIDUAL_CONFIDENCE_PASS'])&(pd.to_numeric(rows['SP_COUNT'],errors='coerce').fillna(9)==1)&(~rows['CPT_IS_SP'])].copy()
    if e.empty: return e
    e=_attach_baseline_overlap(e,baseline_board,rows)
    min_max=int(e['BASELINE_MAX_PLAYER_OVERLAP'].min())
    # Controlled diversification acts only after the individual-confidence gate.
    # Prefer the near-minimum-overlap tier when it exists, but never hard-delete
    # the entire lane if the slate structurally requires more overlap.
    overlap_cap=(min_max + MARGINAL_DIVERSITY_OVERLAP_SLACK) if min_max<=3 else min_max
    diverse=e[e['BASELINE_MAX_PLAYER_OVERLAP']<=overlap_cap].copy()
    if not diverse.empty:
        e=diverse
    e['MARGINAL_DIVERSITY_OVERLAP_CAP']=int(overlap_cap)
    e=e.sort_values(['INDIVIDUAL_CONFIDENCE_ROBUST_PCTL','INDIVIDUAL_CONFIDENCE_GMEAN_PCTL','BASELINE_MAX_PLAYER_OVERLAP','BASELINE_AVG_PLAYER_OVERLAP','MC_TOP_0_1_RATE','MC_WIN_RATE','MC_P99','PROJECTED_EXACT_MATCH_DUPLICATION','LINEUP_ID'],ascending=[False,False,True,True,False,False,False,True,True],kind='mergesort')
    return e.head(HITTER_CPT_ONE_SP_RESERVE_SEATS)


def select(rows:pd.DataFrame, baseline_board:pd.DataFrame, telemetry:dict[str,np.ndarray], board_size:int=BOARD_SIZE)->ReserveResult:
    if board_size!=5: raise ValueError('THIS_POLICY_IS_DEFINED_FOR_TOP5_ONLY')
    d=_attach_recurrence(rows,telemetry); d,baseline_metric_floors=_apply_baseline_relative_gate(d,baseline_board); fam=_family_table(d); st=_baseline_stats(baseline_board)
    reserve_ids=[]; lane_ids=[]; triad_ids=[]; balanced_ids=[]

    # Highest authority: a structurally missing hitter-CPT + one-SP-UTIL lane may
    # receive one seat only when a terminal candidate has already cleared the
    # standalone championship-confidence gate. Recurrence is irrelevant here.
    if st['HITTER_CPT_ONE_SP_COUNT']==0:
        lane=_hitter_cpt_one_sp_lane(d,baseline_board)
        lane_ids=[int(x) for x in lane['LINEUP_ID'].tolist()]
        reserve_ids.extend(lane_ids)

    # Recurrence is downstream of individual confidence. A recurrent family with
    # weak standalone Top-0.1 / win / P99 evidence is not eligible to displace a
    # stronger baseline lineup merely because it appears in more pilot worlds.
    remaining=max(0,board_size-len(reserve_ids))
    if remaining and st['ZERO_SP_COUNT']<=1 and st['FIVE_ONE_SHARE']<EXTREME_CONCENTRATION_SHARE:
        tri=_cross_world_triad(fam).head(remaining)
        triad_ids=[int(x) for x in tri['BEST_CONF_LINEUP_ID'].tolist()]
        reserve_ids.extend(x for x in triad_ids if x not in reserve_ids)
    remaining=max(0,board_size-len(reserve_ids))
    if remaining and st['SAME_CPT_SHARE']>=EXTREME_CONCENTRATION_SHARE and st['FIVE_ONE_SHARE']>=EXTREME_CONCENTRATION_SHARE:
        bal=_balanced_reserve(fam).head(remaining)
        balanced_ids=[int(x) for x in bal['BEST_CONF_LINEUP_ID'].tolist()]
        reserve_ids.extend(x for x in balanced_ids if x not in reserve_ids)

    selected=[]
    for x in reserve_ids:
        if x not in selected and len(selected)<board_size: selected.append(x)
    for x in baseline_board['LINEUP_INDEX'].astype(int).tolist():
        if x not in selected and len(selected)<board_size: selected.append(x)
    if len(selected)!=board_size: raise RuntimeError(f'PORTFOLIO_SHORT_BOARD:{len(selected)}')

    by=d.set_index('LINEUP_ID')
    chosen=by.loc[selected]
    ovs=[]
    for i in range(len(chosen)):
        for j in range(i+1,len(chosen)): ovs.append(_overlap(chosen.iloc[i],chosen.iloc[j]))
    inserted=[x for x in selected if x not in baseline_board['LINEUP_INDEX'].astype(int).tolist()]
    inserted_gate={str(int(x)):bool(by.loc[int(x),'INDIVIDUAL_CONFIDENCE_PASS']) for x in inserted}
    receipt={
        'PATCH_ID':PATCH_ID,'STATUS':'PASS','BOARD_SIZE':board_size,'BASELINE':st,
        'INDIVIDUAL_CONFIDENCE_FLOOR_PCTL':INDIVIDUAL_CONFIDENCE_FLOOR_PCTL,
        'BASELINE_RELATIVE_FLOORS':baseline_metric_floors,
        'BASELINE_RELATIVE_MIN_FRACTIONS':{'MC_TOP_0_1_RATE':BASELINE_TOP01_FRACTION_MIN,'MC_WIN_RATE':BASELINE_WIN_FRACTION_MIN,'MC_P99':BASELINE_P99_FRACTION_MIN},
        'INDIVIDUAL_CONFIDENCE_METRICS':['MC_TOP_0_1_RATE','MC_WIN_RATE','MC_P99'],
        'RECURRENCE_AUTHORITY':'TIEBREAK_AND_DIVERSIFICATION_ONLY_AFTER_INDIVIDUAL_CONFIDENCE_PASS','MARGINAL_DIVERSITY_AUTHORITY':'ONLY_AFTER_INDIVIDUAL_CONFIDENCE_PASS',
        'HITTER_CPT_ONE_SP_RESERVE_IDS':lane_ids,'MARGINAL_DIVERSITY_OVERLAP_SLACK':MARGINAL_DIVERSITY_OVERLAP_SLACK,'MARGINAL_DIVERSITY_OVERLAP_CAP':(int(lane['MARGINAL_DIVERSITY_OVERLAP_CAP'].iloc[0]) if len(lane) and 'MARGINAL_DIVERSITY_OVERLAP_CAP' in lane else None),'HITTER_CPT_ONE_SP_SELECTED_MAX_BASELINE_OVERLAP':(int(lane['BASELINE_MAX_PLAYER_OVERLAP'].iloc[0]) if len(lane) and 'BASELINE_MAX_PLAYER_OVERLAP' in lane else None),'HITTER_CPT_ONE_SP_SELECTED_AVG_BASELINE_OVERLAP':(float(lane['BASELINE_AVG_PLAYER_OVERLAP'].iloc[0]) if len(lane) and 'BASELINE_AVG_PLAYER_OVERLAP' in lane else None),'CROSS_WORLD_TRIAD_IDS':triad_ids,'BALANCED_RESERVE_IDS':balanced_ids,'SELECTED_IDS':selected,
        'INSERTED_IDS':inserted,'INSERTED_INDIVIDUAL_CONFIDENCE_PASS':inserted_gate,
        'ALL_INSERTED_ROWS_CLEAR_INDIVIDUAL_GATE':all(inserted_gate.values()) if inserted_gate else True,
        'MAX_PAIRWISE_PLAYER_OVERLAP':max(ovs) if ovs else 0,'AVG_PAIRWISE_PLAYER_OVERLAP':float(np.mean(ovs)) if ovs else 0.0,
        'POSTLOCK_RESULTS_USED':False,'PLAYER_NAME_CONSTANTS_USED':False,'CONTEST_RANK_USED':False,
        'CROSS_WORLD_ADDED_PROVENANCE_REQUIRED':True,'FAMILY_WORLD_COVERAGE_REQUIRED':True,
        'BASELINE_REPLACEMENT_OCCURRED':bool(selected!=baseline_board['LINEUP_INDEX'].astype(int).tolist()),
        'CALLER_CONTROLS_PRODUCTION_MUTATION':True,
    }
    return ReserveResult(tuple(selected),receipt)
