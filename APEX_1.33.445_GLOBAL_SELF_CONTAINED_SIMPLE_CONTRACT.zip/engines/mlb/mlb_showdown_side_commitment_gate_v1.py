from __future__ import annotations
import numpy as np

PATCH_ID='MLB_SD_SIDE_COMMITMENT_AND_OPPOSING_SP_CONFLICT_v1'
DOCTRINE_ID='MLB_SHOWDOWN_SIDE_COMMITMENT_AND_OPPOSING_SP_CONFLICT_v1'
DUAL_SP_ATTACK_HEDGE_PATCH_ID='MLB_SD_SP_CPT_DUAL_SP_ATTACK_HEDGE_RECALL_v1'

class SideCommitmentGateError(RuntimeError):
    pass

def evaluate(meta:dict)->dict:
    """Vectorized MLB Showdown game-script coherence layer.

    Core rule: diversify game scripts across lineups, not by forcing one lineup
    to require a starter and a concentrated opposing stack to both hit their
    tournament ceilings.  The gate is structural only and uses pre-lock slate
    metadata already present in the runtime.
    """
    idx=np.asarray(meta['idx'],dtype=np.int32)
    if idx.ndim!=2 or idx.shape[1]!=6:
        raise SideCommitmentGateError('SIDE_COMMITMENT_IDX_MUST_BE_Nx6')
    teams=np.asarray(meta['teams'],dtype=object)
    nplayers=len(teams)
    sp_ids=np.asarray(meta.get('sp_player_ids',[]),dtype=np.int32)
    rp_ids=np.asarray(meta.get('rp_player_ids',[]),dtype=np.int32)
    branch=np.asarray(meta['branch'],dtype=object)
    sp_count=np.asarray(meta['sp_count'],dtype=np.int8)
    if len(branch)!=len(idx) or len(sp_count)!=len(idx):
        raise SideCommitmentGateError('SIDE_COMMITMENT_META_LENGTH_MISMATCH')

    is_sp=np.zeros(nplayers,dtype=bool); is_rp=np.zeros(nplayers,dtype=bool)
    if sp_ids.size: is_sp[sp_ids]=True
    if rp_ids.size: is_rp[rp_ids]=True
    row_is_sp=is_sp[idx]
    row_is_hitter=~(row_is_sp|is_rp[idx])
    row_teams=teams[idx]

    # For each lineup slot, count opposing hitters only when that slot is a SP.
    # Shape N x 6 and fully vectorized; no per-lineup Python loop.
    slot_opp_hitter_count=(row_is_hitter[:,:,None] & (row_teams[:,:,None]!=row_teams[:,None,:])).sum(axis=1,dtype=np.int16)
    slot_opp_hitter_count=np.where(row_is_sp,slot_opp_hitter_count,0).astype(np.int8,copy=False)
    max_opp_hitters=slot_opp_hitter_count.max(axis=1).astype(np.int8,copy=False)

    # Team-size matrix lets us identify the lone 5-1 runback without assuming
    # that the captain belongs to the five-man side.
    team_size_by_slot=(row_teams[:,:,None]==row_teams[:,None,:]).sum(axis=1,dtype=np.int16).astype(np.int8,copy=False)
    minority_slot=(team_size_by_slot==1)
    minority_is_sp=(minority_slot & row_is_sp).any(axis=1)
    minority_is_hitter=(minority_slot & row_is_hitter).any(axis=1)
    branch_51=(branch=='5-1')

    # The exact contradiction discussed by the user: 5 pieces on one side with
    # the lone opposing player being the SP attacked by four hitters.  This
    # remains true when the five-man side also contains its own SP (dual-SP 5-1).
    # CAR_SHOP_REPAIR_V1: a minority-side SP captain paired with the opposing
    # starter is a coherent dual-SP hedge even when four majority-side hitters
    # attack the captain.  The historical hard ban deleted the contest-winning
    # phenotype before Phase 2.  Preserve strong friction, but do not hard-ban
    # this identity-free structure.
    cpt_is_sp=row_is_sp[:,0]
    minority_is_cpt=minority_slot[:,0]
    dual=(sp_count==2)
    dual_sp_attack_hedge=branch_51 & minority_is_sp & minority_is_cpt & cpt_is_sp & dual & (max_opp_hitters==4)
    hard_51_opp_sp=branch_51 & minority_is_sp & (max_opp_hitters>=4) & (~dual_sp_attack_hedge)
    hard_any_five_vs_sp=(max_opp_hitters>=5)
    one_sp_five_opposing_hitters=(sp_count==1) & (max_opp_hitters>=5)
    hard=hard_51_opp_sp | hard_any_five_vs_sp

    penalty=np.zeros(len(idx),dtype=np.float64)
    # 4-2 and the dual-SP 5-1 attack hedge can coexist with a SP through K/HR
    # outcomes, but they must clear substantial friction.
    penalty=np.where((~hard)&(max_opp_hitters==4),0.24,penalty)
    penalty=np.where((~hard)&(max_opp_hitters==3),np.maximum(penalty,0.10),penalty)

    # Dual-SP is not banned. When both offenses carry strong pre-lock run
    # environments, however, require additional tail evidence before the hedge
    # can beat a coherent one-side construction.
    team_runs=np.asarray(meta.get('team_runs',np.zeros(nplayers)),dtype=np.float64)
    if len(team_runs)!=nplayers:
        raise SideCommitmentGateError('SIDE_COMMITMENT_TEAM_RUNS_LENGTH_MISMATCH')
    row_sp_runs=np.where(row_is_sp,team_runs[idx],np.inf)
    dual=(sp_count==2)
    min_sp_team_runs=row_sp_runs.min(axis=1)
    dual_both_good=dual & (min_sp_team_runs>=4.35)
    dual_both_elite=dual & (min_sp_team_runs>=4.75)
    penalty += np.where((~hard)&dual_both_good,0.06,0.0)
    penalty += np.where((~hard)&dual_both_elite,0.06,0.0)

    # Coherent 5-1: lone opponent is a hitter, not the pitcher being attacked.
    # Simulations still decide which hitter; this bonus only rewards the cleaner
    # joint script.  Premium one-offs get a small additional preference.
    coherent_51=branch_51 & minority_is_hitter & (~minority_is_sp)
    bonus=np.where(coherent_51,0.06,0.0).astype(np.float64)
    player_salary=np.asarray(meta.get('player_salary',np.zeros(nplayers)),dtype=np.float64)
    batting_order=np.asarray(meta.get('batting_order',np.full(nplayers,99)),dtype=np.int16)
    if len(player_salary)!=nplayers or len(batting_order)!=nplayers:
        raise SideCommitmentGateError('SIDE_COMMITMENT_PLAYER_META_LENGTH_MISMATCH')
    safe_minority=np.argmax(minority_slot,axis=1).astype(np.int32,copy=False)
    minority_player=idx[np.arange(len(idx)),safe_minority]
    premium_oneoff=coherent_51 & ((player_salary[minority_player]>=8000)|(batting_order[minority_player]<=3))
    bonus += np.where(premium_oneoff,0.04,0.0)

    severity=np.full(len(idx),'NONE',object)
    severity[(max_opp_hitters==3)&(~hard)]='MODERATE_CONFLICT'
    severity[(max_opp_hitters==4)&(~hard)]='STRONG_CONFLICT'
    severity[dual_both_good&(~hard)]='DUAL_SP_STRONG_OFFENSE_FRICTION'
    severity[dual_both_elite&(~hard)]='DUAL_SP_ELITE_OFFENSE_FRICTION'
    severity[coherent_51&(~hard)]='COHERENT_5_1_SIDE_COMMITMENT'
    severity[premium_oneoff&(~hard)]='COHERENT_5_1_PREMIUM_HITTER_RUNBACK'
    severity[hard]='HARD_REJECT_OPPOSING_SP_STACK_CONTRADICTION'

    return {
        'PATCH_ID':PATCH_ID,
        'DOCTRINE_ID':DOCTRINE_ID,
        'DUAL_SP_ATTACK_HEDGE_PATCH_ID':DUAL_SP_ATTACK_HEDGE_PATCH_ID,
        'HARD_REJECT':hard,
        'CONFLICT_PENALTY':penalty,
        'SIDE_COMMITMENT_BONUS':bonus,
        'MAX_OPPOSING_HITTERS_VS_ROSTERED_SP':max_opp_hitters,
        'FIVE_ONE_OPPOSING_SP_CONFLICT':hard_51_opp_sp,
        'ONE_SP_FIVE_OPPOSING_HITTERS':one_sp_five_opposing_hitters,
        'DUAL_SP_ATTACK_HEDGE_5_1':dual_sp_attack_hedge,
        'COHERENT_FIVE_ONE_HITTER_RUNBACK':coherent_51,
        'PREMIUM_ONEOFF_HITTER':premium_oneoff,
        'DUAL_SP_BOTH_GOOD_OFFENSES':dual_both_good,
        'DUAL_SP_BOTH_ELITE_OFFENSES':dual_both_elite,
        'SEVERITY':severity,
        'RULES':{
            '5_1_LONE_OPPOSING_SP_FACING_4PLUS_HITTERS':'HARD_REJECT_EXCEPT_MINORITY_SP_CPT_DUAL_SP_HEDGE',
            '5_1_MINORITY_SP_CPT_DUAL_SP_FACING_4_HITTERS':'ALLOW_WITH_STRONG_FRICTION',
            'ANY_ROSTERED_SP_FACING_5_HITTERS':'HARD_REJECT_NO_EXCEPTION',
            'ONE_SP_PLUS_5_OPPOSING_HITTERS':'HARD_REJECT_NO_EXCEPTION',
            'ROSTERED_SP_FACING_4_HITTERS_OUTSIDE_5_1':'STRONG_CONFLICT_PENALTY',
            'ROSTERED_SP_FACING_3_HITTERS':'MODERATE_CONFLICT_PENALTY',
            'DUAL_SP_WHEN_BOTH_OFFENSES_STRONG':'CONDITIONAL_FRICTION_NOT_BAN',
            '5_1_LONE_OPPOSING_HITTER':'SIDE_COMMITMENT_BONUS',
            '5_1_PREMIUM_ONEOFF_HITTER':'ADDITIONAL_SIDE_COMMITMENT_BONUS',
        },
        'PERFORMANCE':{
            'IMPLEMENTATION':'VECTORIZED_NUMPY_BROADCAST_MASK',
            'PYTHON_PER_LINEUP_LOOP':False,
            'EXTRA_MONTE_CARLO_PASSES':0,
            'EXTRA_FIELD_SIMULATION_PASSES':0,
            'POSTLOCK_INPUT_USED':False,
        },
    }

def apply_hard_gate(lineups,meta,evaluation):
    hard=np.asarray(evaluation['HARD_REJECT'],dtype=bool)
    if len(hard)!=len(lineups):
        raise SideCommitmentGateError('SIDE_COMMITMENT_MASK_LENGTH_MISMATCH')
    keep=~hard
    return np.asarray(lineups)[keep],{
        'PATCH_ID':PATCH_ID,
        'INPUT_LINEUPS':int(len(lineups)),
        'HARD_REJECTED_LINEUPS':int(hard.sum()),
        'SURVIVING_LINEUPS':int(keep.sum()),
        'FIVE_ONE_OPPOSING_SP_CONFLICT_REJECTS':int(np.asarray(evaluation['FIVE_ONE_OPPOSING_SP_CONFLICT'],bool).sum()),
        'PERFORMANCE_IMPLEMENTATION':'VECTORIZED_NUMPY_BROADCAST_MASK',
        'EXTRA_MONTE_CARLO_PASSES':0,
        'POSTLOCK_INPUT_USED':False,
    }
