#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from collections import Counter
from pathlib import Path
from typing import Iterable

import pandas as pd

EVALUATOR_ID = "MLB_CLASSIC_POSTLOCK_CONTEST_MATCHER_v1"
PATCH_ID = "MLB_CLASSIC_POSTLOCK_SLATE_COMPATIBILITY_AND_SLOT_ORDER_GATE_v1"
IDENTITY_PATCH_ID = "MLB_CLASSIC_POSTLOCK_NAME_SUFFIX_CANONICALIZATION_v1"
NICKNAME_IDENTITY_PATCH_ID = "MLB_POSTLOCK_NICKNAME_IDENTITY_RECONCILIATION_v1"
MLB_POSTLOCK_IDENTITY_ALIASES = {"kike hernandez": "enrique hernandez", "kik hernandez": "enrique hernandez"}
SLOT_COLUMNS = ("P1", "P2", "C", "1B", "2B", "3B", "SS", "OF1", "OF2", "OF3")
EXPECTED_SLOT_COUNTS = Counter({"P": 2, "C": 1, "1B": 1, "2B": 1, "3B": 1, "SS": 1, "OF": 3})
MIN_CONTEST_PLAYER_COVERAGE = 0.85


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def normalize_name(value: object) -> str:
    text = re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()
    return re.sub(r"\s+", " ", text)


def identity_name(value: object) -> str:
    """Canonical player identity for postlock cross-source matching only.

    Providers inconsistently include trailing generational suffixes. Strip only
    trailing Jr/Sr/II/III/IV tokens for identity comparison while preserving
    visible/parser names and every production player-pool field.
    """
    text = normalize_name(value)
    tokens = text.split()
    suffixes = {"jr", "sr", "ii", "iii", "iv"}
    while tokens and tokens[-1] in suffixes:
        tokens.pop()
    ident = " ".join(tokens)
    return MLB_POSTLOCK_IDENTITY_ALIASES.get(ident, ident)


def identity_set(values: Iterable[object], source: str) -> set[str]:
    aliases: dict[str, set[str]] = {}
    for value in values:
        raw = normalize_name(value)
        ident = identity_name(value)
        if not raw or not ident:
            continue
        aliases.setdefault(ident, set()).add(raw)
    collisions = {k: sorted(v) for k, v in aliases.items() if len(v) > 1}
    if collisions:
        detail = json.dumps(collisions, sort_keys=True, separators=(",", ":"))
        raise RuntimeError(f"POSTLOCK_IDENTITY_CANONICALIZATION_COLLISION:{source}:{detail}")
    return set(aliases)


def contest_frame(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as z:
            members = sorted(n for n in z.namelist() if n.lower().endswith(".csv"))
            if not members:
                raise ValueError("NO_CSV_MEMBER")
            with z.open(members[0]) as f:
                return pd.read_csv(f)
    return pd.read_csv(path)


def parse_classic_lineup(value: object, known_players: set[str] | None = None) -> list[str]:
    """Parse a DK MLB Classic lineup independent of export slot ordering.

    Slot-like tokens can occur inside player names (for example a trailing "C").
    When a contest player universe is available, use it to disambiguate marker
    candidates rather than assuming every slot-looking token is a marker.
    """
    text = re.sub(r"\s+", " ", str(value)).strip()
    tokens = [m.group(0) for m in re.finditer(r"\S+", text)]
    if not tokens or tokens[0].upper() not in EXPECTED_SLOT_COUNTS:
        return []
    marker_positions = [i for i, token in enumerate(tokens) if token.upper() in EXPECTED_SLOT_COUNTS]
    if len(marker_positions) < 10:
        return []
    solutions: list[list[str]] = []

    def recurse(selected: list[int], counts: Counter[str], names: list[str]) -> None:
        if len(solutions) > 1 and known_players is None:
            return
        current = selected[-1]
        slot = tokens[current].upper()
        if len(selected) == 10:
            if counts != EXPECTED_SLOT_COUNTS:
                return
            name = normalize_name(" ".join(tokens[current + 1:]))
            if not name or (known_players is not None and name not in known_players):
                return
            final_names = names + [name]
            if len(set(final_names)) == 10:
                solutions.append(final_names)
            return
        for nxt in marker_positions:
            if nxt <= current + 1:
                continue
            next_slot = tokens[nxt].upper()
            if counts[next_slot] >= EXPECTED_SLOT_COUNTS[next_slot]:
                continue
            name = normalize_name(" ".join(tokens[current + 1:nxt]))
            if not name or (known_players is not None and name not in known_players):
                continue
            next_counts = counts.copy()
            next_counts[next_slot] += 1
            recurse(selected + [nxt], next_counts, names + [name])

    first_slot = tokens[0].upper()
    recurse([0], Counter({first_slot: 1}), [])
    if known_players is not None:
        return solutions[0] if solutions else []
    return solutions[0] if len(solutions) == 1 else []

def winner_keys_from_frame(frame: pd.DataFrame) -> list[str]:
    if not {"Rank", "Lineup"}.issubset(frame.columns):
        raise ValueError("MISSING_RANK_OR_LINEUP")
    rank = pd.to_numeric(frame["Rank"].astype(str).str.extract(r"(\d+)", expand=False), errors="coerce")
    if not rank.notna().any():
        raise ValueError("NO_NUMERIC_RANK")
    top = frame.loc[rank.eq(rank.min()), "Lineup"].dropna().astype(str).drop_duplicates()
    known_players = {normalize_name(x) for x in frame.get("Player", pd.Series(dtype=str)).dropna() if normalize_name(x)}
    keys = []
    for value in top:
        names = parse_classic_lineup(value, known_players=known_players or None)
        if names:
            keys.append("|".join(sorted(identity_name(name) for name in names)))
    if not keys:
        raise RuntimeError("WINNER_PLAYER_SET_NOT_IDENTIFIABLE")
    return sorted(set(keys))


def winner_keys(path: Path) -> list[str]:
    return winner_keys_from_frame(contest_frame(path))


def pool_player_names(path: Path) -> set[str]:
    frame = pd.read_csv(path, usecols=lambda c: str(c) == "PLAYER")
    if "PLAYER" not in frame.columns:
        raise ValueError("PLAYER_POOL_MISSING_PLAYER_COLUMN")
    return identity_set(frame["PLAYER"].dropna(), "PLAYER_POOL")


def contest_player_names(frame: pd.DataFrame) -> set[str]:
    if "Player" not in frame.columns:
        raise ValueError("CONTEST_MISSING_PLAYER_COLUMN")
    return identity_set(frame["Player"].dropna(), "CONTEST")


def pool_contest_compatibility(player_pool: Path, contest: Path) -> dict:
    frame = contest_frame(contest)
    winners = winner_keys_from_frame(frame)
    pool_names = pool_player_names(player_pool)
    contest_names = contest_player_names(frame)
    if not pool_names or len(contest_names) < 10:
        raise RuntimeError("POOL_OR_CONTEST_PLAYER_UNIVERSE_EMPTY")
    overlap = pool_names & contest_names
    union = pool_names | contest_names
    winner_names = {name for key in winners for name in key.split("|") if name}
    winner_overlap = winner_names & pool_names
    contest_coverage = len(overlap) / len(contest_names)
    jaccard = len(overlap) / len(union) if union else 0.0
    winner_coverage = len(winner_overlap) / len(winner_names) if winner_names else 0.0
    missing = sorted(winner_names - pool_names)
    reasons: list[str] = []
    if contest_coverage < MIN_CONTEST_PLAYER_COVERAGE:
        reasons.append(f"CONTEST_PLAYER_COVERAGE_{contest_coverage:.6f}_LT_{MIN_CONTEST_PLAYER_COVERAGE:.2f}")
    if winner_coverage < 1.0:
        reasons.append(f"WINNER_POOL_COVERAGE_{winner_coverage:.6f}_LT_1.00")
    passed = not reasons
    return {
        "WINNER_LINEUP_KEYS": winners,
        "POOL_PLAYER_COUNT": len(pool_names),
        "CONTEST_PLAYER_COUNT": len(contest_names),
        "POOL_CONTEST_PLAYER_OVERLAP": len(overlap),
        "CONTEST_PLAYER_COVERAGE": contest_coverage,
        "PLAYER_JACCARD": jaccard,
        "WINNER_POOL_COVERAGE": winner_coverage,
        "WINNER_PLAYERS_MISSING_FROM_POOL": missing,
        "POOL_CONTEST_COMPATIBILITY_PASS": passed,
        "MATCH_REJECT_REASONS": reasons,
    }


def pid_name(value: object) -> str:
    parts = str(value).split("|")
    return identity_name(parts[1] if len(parts) >= 2 else parts[0])


def manifest_keys(frame: pd.DataFrame) -> pd.Series:
    missing = [c for c in SLOT_COLUMNS if c not in frame.columns]
    if missing:
        raise ValueError(f"PHASE2_MANIFEST_MISSING_SLOT_COLUMNS:{','.join(missing)}")
    return frame.loc[:, SLOT_COLUMNS].apply(lambda r: "|".join(sorted(pid_name(x) for x in r)), axis=1)


def _lineup_ids_for_keys(manifest: pd.DataFrame, keys: Iterable[str]) -> pd.DataFrame:
    work = manifest.copy()
    work["PLAYER_SET_KEY"] = manifest_keys(work)
    return work.loc[work["PLAYER_SET_KEY"].isin(set(keys))].copy()


def evaluate(
    contest: Path,
    player_pool: Path,
    candidate_manifest: Path,
    candidate_board: Path,
    candidate_receipt: Path,
    output: Path,
    baseline_manifest: Path | None = None,
) -> dict:
    compat = pool_contest_compatibility(player_pool, contest)
    result = {
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "EVALUATOR_ID": EVALUATOR_ID,
        "PATCH_ID": PATCH_ID,
        "IDENTITY_PATCH_ID": IDENTITY_PATCH_ID,
        "POSTLOCK_ONLY": True,
        "PRODUCTION_SELECTOR_IMPORT": False,
        "CONTEST_SHA256": sha256(contest),
        "PLAYER_POOL_SHA256": sha256(player_pool),
        "CANDIDATE_MANIFEST_SHA256": sha256(candidate_manifest),
        "CANDIDATE_BOARD_SHA256": sha256(candidate_board),
        "CANDIDATE_RECEIPT_SHA256": sha256(candidate_receipt),
        "BASELINE_MANIFEST_SHA256": sha256(baseline_manifest) if baseline_manifest and baseline_manifest.exists() else None,
        **compat,
        "CAUSAL_CLASSIFICATION_ALLOWED": bool(compat["POOL_CONTEST_COMPATIBILITY_PASS"]),
        "MATCH_STATUS": "PASS" if compat["POOL_CONTEST_COMPATIBILITY_PASS"] else "REJECTED_POOL_CONTEST_MISMATCH",
        "PRODUCTION_MUTATED": False,
    }
    if not compat["POOL_CONTEST_COMPATIBILITY_PASS"]:
        result.update({
            "CANDIDATE_MATCHED_LINEUP_IDS": [],
            "BASELINE_MATCHED_LINEUP_IDS": [],
            "WINNER_BORN_CANDIDATE_PHASE2": None,
            "WINNER_BORN_BASELINE_PHASE2": None,
            "CANDIDATE_BIRTH_AND_BASELINE_MISS": None,
            "WINNER_REACHED_CANDIDATE_SELECTOR_REVIEW": None,
            "WINNER_SELECTED_TO_CANDIDATE_BOARD": None,
            "WINNER_CANDIDATE_BOARD_RANK": None,
            "MATCHED_BIRTH_SOURCES": [],
            "MATCHED_CLOSURE_TRANSITIONS": [],
            "CROSS_PATTERN_WINNER_BIRTH": None,
        })
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(result, indent=2) + "\n")
        return result

    winners = compat["WINNER_LINEUP_KEYS"]
    candidate = pd.read_csv(candidate_manifest)
    board = pd.read_csv(candidate_board)
    receipt = json.loads(candidate_receipt.read_text())
    matched = _lineup_ids_for_keys(candidate, winners).drop_duplicates("LINEUP_ID")
    ids = matched["LINEUP_ID"].astype(str).tolist()
    board_ids = set(board.get("LINEUP_ID", pd.Series(dtype=str)).astype(str))
    selected_ids = sorted(set(ids) & board_ids)
    parity = bool(receipt.get("PHASE2_HANDOFF_SELECTOR_PARITY")) and int(receipt.get("SELECTOR_REVIEWED_LINEUPS", -1)) == int(receipt.get("PHASE2_BUILT_LINEUPS", -2))
    baseline_ids: list[str] = []
    if baseline_manifest and baseline_manifest.exists():
        baseline = pd.read_csv(baseline_manifest)
        baseline_ids = _lineup_ids_for_keys(baseline, winners).drop_duplicates("LINEUP_ID")["LINEUP_ID"].astype(str).tolist()
    transitions = sorted({str(x) for x in matched.get("CLOSURE_TRANSITION", pd.Series(dtype=str)).dropna() if str(x)})
    birth_sources = sorted({str(x) for x in matched.get("BIRTH_SOURCE", pd.Series(dtype=str)).dropna() if str(x)})
    result.update({
        "CANDIDATE_MATCHED_LINEUP_IDS": ids,
        "BASELINE_MATCHED_LINEUP_IDS": baseline_ids,
        "WINNER_BORN_CANDIDATE_PHASE2": bool(ids),
        "WINNER_BORN_BASELINE_PHASE2": bool(baseline_ids),
        "CANDIDATE_BIRTH_AND_BASELINE_MISS": bool(ids and not baseline_ids),
        "WINNER_REACHED_CANDIDATE_SELECTOR_REVIEW": bool(ids and parity),
        "WINNER_SELECTED_TO_CANDIDATE_BOARD": bool(selected_ids),
        "WINNER_CANDIDATE_BOARD_RANK": int(board.loc[board["LINEUP_ID"].astype(str).isin(selected_ids)].index.min() + 1) if selected_ids else 0,
        "MATCHED_BIRTH_SOURCES": birth_sources,
        "MATCHED_CLOSURE_TRANSITIONS": transitions,
        "CROSS_PATTERN_WINNER_BIRTH": any(x in {"5-3_TO_5-2-1", "5-2-1_TO_5-1-1-1"} for x in transitions),
    })
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contest", required=True)
    parser.add_argument("--player-pool", required=True)
    parser.add_argument("--candidate-manifest", required=True)
    parser.add_argument("--candidate-board", required=True)
    parser.add_argument("--candidate-receipt", required=True)
    parser.add_argument("--baseline-manifest")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    result = evaluate(
        Path(args.contest), Path(args.player_pool), Path(args.candidate_manifest), Path(args.candidate_board),
        Path(args.candidate_receipt), Path(args.output),
        Path(args.baseline_manifest) if args.baseline_manifest else None,
    )
    print(json.dumps({k: result.get(k) for k in (
        "EXECUTION_STATE", "MATCH_STATUS", "POOL_CONTEST_COMPATIBILITY_PASS", "CAUSAL_CLASSIFICATION_ALLOWED",
        "WINNER_BORN_CANDIDATE_PHASE2", "WINNER_BORN_BASELINE_PHASE2",
        "CANDIDATE_BIRTH_AND_BASELINE_MISS", "WINNER_REACHED_CANDIDATE_SELECTOR_REVIEW",
        "WINNER_SELECTED_TO_CANDIDATE_BOARD",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
