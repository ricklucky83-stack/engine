from __future__ import annotations

from dataclasses import asdict, dataclass
from itertools import combinations
from typing import Iterable, Mapping, Sequence

PATCH_ID = "MLB_CLASSIC_DETERMINISTIC_FAMILY_SIBLING_CLOSURE_v1"


@dataclass(frozen=True)
class SiblingSwap:
    team: str
    removed_player_id: int
    added_player_id: int
    resulting_team_combo: tuple[int, ...]


@dataclass(frozen=True)
class ClosureTelemetry:
    patch_id: str
    base_families: int
    family_keys_closed: int
    sibling_attempts: int
    sibling_rows_added: int
    duplicate_rows_skipped: int
    salary_rows_rejected: int
    position_rows_rejected: int
    integrity_failures: int
    generation_seconds: float

    def to_receipt(self) -> dict[str, object]:
        return asdict(self)


def _one_swap_neighbors(universe: tuple[int, ...], combo: tuple[int, ...]) -> tuple[tuple[int, int, tuple[int, ...]], ...]:
    """Precompute deterministic Hamming-distance-one neighbors for one team combo."""
    combo_set = frozenset(combo)
    outsiders = tuple(i for i in universe if i not in combo_set)
    rows: list[tuple[int, int, tuple[int, ...]]] = []
    for removed in combo:
        retained = tuple(i for i in combo if i != removed)
        for added in outsiders:
            rows.append((removed, added, tuple(sorted((*retained, added)))))
    rows.sort(key=lambda row: (row[0], row[1], row[2]))
    return tuple(rows)


def build_neighbor_index(
    team_to_hitters: Mapping[str, Sequence[int]],
    sizes: Iterable[int] = (3, 5),
) -> dict[tuple[str, tuple[int, ...]], tuple[SiblingSwap, ...]]:
    """
    Build the entire one-swap neighborhood once. Runtime lookups are O(1),
    avoiding repeated combination construction inside the Phase 2 closure pass.
    """
    index: dict[tuple[str, tuple[int, ...]], tuple[SiblingSwap, ...]] = {}
    for team in sorted(team_to_hitters):
        universe = tuple(sorted(int(i) for i in team_to_hitters[team]))
        for size in sorted(set(int(k) for k in sizes)):
            if size <= 0 or size > len(universe):
                continue
            for combo in combinations(universe, size):
                index[(team, combo)] = tuple(
                    SiblingSwap(team, removed, added, resulting)
                    for removed, added, resulting in _one_swap_neighbors(universe, combo)
                )
    return index


def family_swaps(
    hitter_ids: Sequence[int],
    player_team: Mapping[int, str],
    neighbor_index: Mapping[tuple[str, tuple[int, ...]], Sequence[SiblingSwap]],
) -> tuple[SiblingSwap, ...]:
    groups: dict[str, list[int]] = {}
    for idx in hitter_ids:
        groups.setdefault(player_team[int(idx)], []).append(int(idx))
    out: list[SiblingSwap] = []
    for team in sorted(groups):
        combo = tuple(sorted(groups[team]))
        out.extend(neighbor_index.get((team, combo), ()))
    return tuple(out)


def apply_swap(hitter_ids: Sequence[int], swap: SiblingSwap) -> tuple[int, ...]:
    current = tuple(int(i) for i in hitter_ids)
    if swap.removed_player_id not in current or swap.added_player_id in current:
        raise ValueError("INVALID_SIBLING_SWAP")
    result = tuple(sorted(swap.added_player_id if i == swap.removed_player_id else i for i in current))
    if len(result) != len(current) or len(set(result)) != len(result):
        raise ValueError("INVALID_SIBLING_RESULT")
    return result


def validate_sibling(
    parent_hitters: Sequence[int],
    child_hitters: Sequence[int],
    player_team: Mapping[int, str],
) -> bool:
    parent = set(map(int, parent_hitters))
    child = set(map(int, child_hitters))
    if len(parent) != 8 or len(child) != 8:
        return False
    if len(parent & child) != 7:
        return False
    parent_counts: dict[str, int] = {}
    child_counts: dict[str, int] = {}
    for idx in parent:
        parent_counts[player_team[idx]] = parent_counts.get(player_team[idx], 0) + 1
    for idx in child:
        child_counts[player_team[idx]] = child_counts.get(player_team[idx], 0) + 1
    return parent_counts == child_counts == dict(sorted(parent_counts.items()))
