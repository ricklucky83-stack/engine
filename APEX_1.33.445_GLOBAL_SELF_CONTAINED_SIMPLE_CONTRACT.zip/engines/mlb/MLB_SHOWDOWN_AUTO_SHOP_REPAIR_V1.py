from __future__ import annotations
import argparse, json, math, re, unicodedata, zipfile, hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from numba import njit
from MLB_SD_NEIGHBORHOOD_DOOR_SELECTOR_V1 import PATCH_ID as NEIGHBORHOOD_DOOR_PATCH_ID, select_frozen_legal_universe

ELITE8_PATCH_ID='MLB_ELITE8_RNWD_CORE_v1'
ELITE_CORE_SLOTS=8
STRUCTURAL_RESERVE_SLOTS=2

ENGINE_ID='MLB_SHOWDOWN_AUTO_SHOP_REPAIR_V1'
PRIMARY_RANKER='NEIGHBORHOOD_ADMISSION_THEN_LOCAL_DOOR_SELECTION'
MC_PRIMARY_WEIGHT=0.0
COMPLEX_SELECTOR_ACTIVE=True
MILP_ACTIVE=False
FAMILY_ROUTER_ACTIVE=True


def num(x,d=0.0):
    try:
        if isinstance(x,str):
            x=x.replace('%','').replace(',','').strip()
            if x in {'','-','nan','None'}: return d
        v=float(x); return v if np.isfinite(v) else d
    except Exception: return d

def norm(s):
    s=unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower()
    s=re.sub(r'\b(jr|sr|ii|iii|iv|v)\b\.?','',s)
    return re.sub(r'[^a-z0-9]+','',s)

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def active_pool(raw:pd.DataFrame)->pd.DataFrame:
    hitters=raw['LINEUP'].astype(str).str.fullmatch(r'[1-9]')
    opp=set(raw.loc[hitters,'Opp Pitcher'].dropna().astype(str).str.strip())
    pitcher=raw['LINEUP'].astype(str).str.upper().eq('SP')
    starter=pitcher & raw['PLAYER'].astype(str).isin(opp)
    rp=pitcher & ~starter & (raw['RST%'].map(num)>0) & (raw['SAL'].map(num)<=5000)
    p=raw.loc[hitters|starter|rp].copy().reset_index(drop=True)
    p['_IS_STARTER']=p['PLAYER'].astype(str).isin(opp)
    p['_IS_PITCHER']=p['LINEUP'].astype(str).str.upper().eq('SP')
    p['_IS_RP']=p['_IS_PITCHER'] & ~p['_IS_STARTER']
    p['_SAL']=p['SAL'].map(num).astype(np.int32)
    p['_OWN']=p['RST%'].map(num).astype(float)
    # Only pre-lock provider columns. No result/contest input can enter this score.
    p['_DET']=p['FPTS'].map(num).astype(float)+0.35*p['L5 FPTS'].map(num).astype(float)
    if len(p)<8 or p['TEAM'].nunique()!=2 or p['PLAYER'].duplicated().any():
        raise RuntimeError('RUN_INVALID:ACTIVE_POOL')
    return p

@njit(cache=False)
def enumerate_numba(sal,team,rp):
    n=len(sal)
    max_rows=n*((n-1)*(n-2)*(n-3)*(n-4)*(n-5)//120)
    out=np.empty((max_rows,7),np.int32); k=0
    for c in range(n):
        if rp[c]: continue
        cs=sal[c]*3//2
        for a in range(n-4):
            if a==c: continue
            for b in range(a+1,n-3):
                if b==c: continue
                for d in range(b+1,n-2):
                    if d==c: continue
                    for e in range(d+1,n-1):
                        if e==c: continue
                        for f in range(e+1,n):
                            if f==c: continue
                            if rp[a]+rp[b]+rp[d]+rp[e]+rp[f]>2: continue
                            salary=cs+sal[a]+sal[b]+sal[d]+sal[e]+sal[f]
                            if salary<40000 or salary>50000: continue
                            tc=team[c]
                            same=(team[a]==tc)+(team[b]==tc)+(team[d]==tc)+(team[e]==tc)+(team[f]==tc)
                            if same==5: continue
                            out[k,0]=c;out[k,1]=a;out[k,2]=b;out[k,3]=d;out[k,4]=e;out[k,5]=f;out[k,6]=salary;k+=1
    return out[:k].copy()

def apply_elite8_board_authority(order:pd.DataFrame, board_size:int=10)->pd.DataFrame:
    """Elite 8 RNWD core + structural reserve board authority.

    The neighborhood/door selector remains the ranking engine. This terminal
    board gate preserves the first eight highest-quality RNWD representatives,
    then uses the remaining two slots for distinct structural neighborhoods
    before board seal. No Monte Carlo or post-lock inputs are introduced.
    """
    x=order.copy().reset_index(drop=True)
    if x.empty or board_size<=0: return x.iloc[:0].copy()
    board_size=min(int(board_size),len(x))
    core_target=min(ELITE_CORE_SLOTS,board_size)
    chosen=list(range(core_target))
    used=set(x.loc[chosen,'NEIGHBORHOOD_KEY'].astype(str).tolist()) if chosen else set()
    remaining=[i for i in range(core_target,len(x))]
    while remaining and len(chosen)<board_size:
        fresh=[i for i in remaining if str(x.at[i,'NEIGHBORHOOD_KEY']) not in used]
        pool=fresh if fresh else remaining
        i=min(pool,key=lambda j:(int(x.at[j,'SELECTOR_RANK']),j))
        chosen.append(int(i)); remaining.remove(i); used.add(str(x.at[i,'NEIGHBORHOOD_KEY']))
    out=x.iloc[chosen].copy().reset_index(drop=True)
    out['ELITE8_SLOT_TYPE']=['ELITE_CORE' if i<core_target else 'STRUCTURAL_RESERVE' for i in range(len(out))]
    out['ELITE8_BOARD_RANK']=np.arange(1,len(out)+1)
    out['ELITE8_PATCH_ID']=ELITE8_PATCH_ID
    return out

def build_order(pool:pd.DataFrame)->pd.DataFrame:
    names=pool['PLAYER'].astype(str).to_numpy(); teams=pool['TEAM'].astype(str).to_numpy()
    sal=pool['_SAL'].to_numpy(np.int32); det=pool['_DET'].to_numpy(float); own=pool['_OWN'].to_numpy(float)
    rp=pool['_IS_RP'].to_numpy(np.int8)
    tm={t:i for i,t in enumerate(sorted(set(teams.tolist())))}; team=np.array([tm[t] for t in teams],np.int8)
    arr=enumerate_numba(sal,team,rp); idx=arr[:,:6]
    score=1.5*det[idx[:,0]]+det[idx[:,1:]].sum(1)
    ownprod=np.prod(np.clip(own[idx]/100.0,1e-8,1.0),axis=1)
    # Deterministic score owns ranking. Salary and duplication only break exact ties.
    order=np.lexsort((ownprod,-arr[:,6],-score)); arr=arr[order];score=score[order];ownprod=ownprod[order]
    x=pd.DataFrame(arr,columns=['CPT_ID','U1_ID','U2_ID','U3_ID','U4_ID','U5_ID','SALARY'])
    x['ENGINE_SCORE']=score; x['OWN_PROD']=ownprod; x['ENGINE_RANK']=np.arange(1,len(x)+1)
    x['CPT']=[names[i] for i in x.CPT_ID]
    for j in range(1,6): x[f'UTIL{j}']=[names[i] for i in x[f'U{j}_ID']]
    return select_frozen_legal_universe(pool,x,score)

def parse_lineup(s):
    z=re.findall(r'(CPT|UTIL)\s+(.+?)(?=\s+(?:CPT|UTIL)\s+|$)',str(s)); c=None;u=[]
    for r,n in z:
        if r=='CPT': c=n.strip()
        else: u.append(n.strip())
    return c,u

def fp(c,u): return 'CPT:'+norm(c)+'|UTIL:'+'|'.join(sorted(norm(x) for x in u))

def attach_postlock_truth(order:pd.DataFrame, contest_zip:str):
    with zipfile.ZipFile(contest_zip) as z:
        member=[n for n in z.namelist() if n.lower().endswith('.csv')][0]
        st=pd.read_csv(z.open(member))
    truth={}
    for r in st[st['Lineup'].notna()].itertuples(index=False):
        c,u=parse_lineup(r.Lineup)
        if c is None or len(u)!=5: continue
        k=fp(c,u)
        q=truth.get(k)
        if q is None or int(r.Rank)<q[0]: truth[k]=(int(r.Rank),float(r.Points))
    keys=[fp(r.CPT,[r.UTIL1,r.UTIL2,r.UTIL3,r.UTIL4,r.UTIL5]) for r in order.itertuples(index=False)]
    actual_rank=np.array([truth.get(k,(-1,np.nan))[0] for k in keys],np.int32)
    actual_points=np.array([truth.get(k,(-1,np.nan))[1] for k in keys],float)
    field=len(st); unique=len(truth)
    winner=np.where(actual_rank==1)[0]
    top50=actual_rank[:50]
    def cap(p):
        cut=max(1,math.ceil(field*p)); den=sum(1 for r,_ in truth.values() if r<=cut); num=int(((top50>0)&(top50<=cut)).sum()); return f'{num}/{den}'
    metrics={'FIELD':field,'CONTEST_UNIQUE':unique,'WINNER_ENGINE_RANK':int(winner[0]+1) if len(winner) else -1,'TOP_0_1_CAPTURE_TOP50':cap(.001),'TOP_1_CAPTURE_TOP50':cap(.01),'TOP_5_CAPTURE_TOP50':cap(.05),'BEST_ACTUAL_RANK_TOP10':int(top50[:10][top50[:10]>0].min()) if np.any(top50[:10]>0) else None}
    return actual_rank,actual_points,metrics

def run(pool_path,outdir,contest=None):
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    raw=pd.read_csv(pool_path); pool=active_pool(raw); order=build_order(pool); board=apply_elite8_board_authority(order,10)
    metrics=None
    if contest:
        ar,ap,metrics=attach_postlock_truth(order,contest); order['POSTLOCK_ACTUAL_RANK']=ar;order['POSTLOCK_ACTUAL_POINTS']=ap
        bkeys=[fp(r.CPT,[r.UTIL1,r.UTIL2,r.UTIL3,r.UTIL4,r.UTIL5]) for r in board.itertuples(index=False)]
        omap={fp(r.CPT,[r.UTIL1,r.UTIL2,r.UTIL3,r.UTIL4,r.UTIL5]):(int(a),float(p)) for r,a,p in zip(order.itertuples(index=False),ar,ap)}
        board['POSTLOCK_ACTUAL_RANK']=[omap.get(k,(-1,np.nan))[0] for k in bkeys]; board['POSTLOCK_ACTUAL_POINTS']=[omap.get(k,(-1,np.nan))[1] for k in bkeys]
    order.head(50).to_csv(out/'AUTO_SHOP_TOP50.csv',index=False)
    board.to_csv(out/'AUTO_SHOP_BOARD10.csv',index=False)
    pool[['PLAYER','TEAM','LINEUP','SAL','FPTS','L5 FPTS','RST%','_IS_STARTER','_IS_RP','_DET']].to_csv(out/'ACTIVE_POOL.csv',index=False)
    receipt={'ENGINE_ID':ENGINE_ID,'EXECUTION_STATE':'TOOL_PROVEN_EXECUTED','INPUT_SHA256':sha256(pool_path),'PRIMARY_RANKER':PRIMARY_RANKER,'MC_PRIMARY_WEIGHT':MC_PRIMARY_WEIGHT,'COMPLEX_SELECTOR_ACTIVE':COMPLEX_SELECTOR_ACTIVE,'MILP_ACTIVE':MILP_ACTIVE,'FAMILY_ROUTER_ACTIVE':FAMILY_ROUTER_ACTIVE,'NEIGHBORHOOD_DOOR_SELECTOR':NEIGHBORHOOD_DOOR_PATCH_ID,'SELECTOR_ARCHITECTURE':'NEIGHBORHOOD_ADMISSION_THEN_LOCAL_DOOR_SELECTION','ELITE8_PATCH':ELITE8_PATCH_ID,'ELITE_CORE_SLOTS':min(ELITE_CORE_SLOTS,len(board)),'STRUCTURAL_RESERVE_SLOTS':max(0,len(board)-min(ELITE_CORE_SLOTS,len(board))),'FINAL_BOARD_AUTHORITY':'ELITE8_RNWD_CORE_PLUS_STRUCTURAL_RESERVE','RAW_ROWS':len(raw),'ACTIVE_POOL':len(pool),'LEGAL_LINEUPS':len(order),'BOARD_SIZE':10,'POSTLOCK_TRUTH_USED_FOR_RANKING':False,'POSTLOCK_EVALUATION':metrics,'PRODUCTION_PROMOTION':'ACTIVE_PRODUCTION_USER_DIRECTED'}
    (out/'AUTO_SHOP_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps(receipt,indent=2)); return receipt

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--pool',required=True);a.add_argument('--outdir',required=True);a.add_argument('--contest');x=a.parse_args();run(x.pool,x.outdir,x.contest)
