from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping, Sequence
import numpy as np
import mlb_advisor_tail_selector_v1 as advisor
import mlb_classic_historical_consensus_selector_v1 as historical
import mlb_classic_noninferior_trophy_portfolio_selector_v1 as parent
import mlb_right_neighborhood_wrong_door_authority_v1 as rnwd

PATCH_ID = "MLB_CLASSIC_NONINFERIOR_COMMON_WORLD_TOP01_PORTFOLIO_v1"
SELECTOR_MODE = "NONINFERIOR_TROPHY_FRONTIER_COMMON_WORLD_MARGINAL_TOP01_COVERAGE"
PRIMARY_OBJECTIVE = "TOP_0_1_PERCENT_BOARD_UNION_CAPTURE"
POSTLOCK_RESULTS_USED_BY_SELECTOR = False
HARD_PLAYER_EXPOSURE_CAP_USED = False
HARD_FAMILY_QUOTAS_USED = False
HARD_PITCHER_PAIR_QUOTAS_USED = False
WEIGHTED_METRIC_SUM_USED = False
StructuralIdentity = parent.StructuralIdentity

@dataclass(frozen=True)
class HybridSelection:
    positions: np.ndarray
    active_parent_positions: np.ndarray
    quality_tier: np.ndarray
    primary_delta: float
    lcb_delta: float
    frontier_size: int
    selected_tier_counts: tuple[tuple[int,int],...]
    unique_macro_spines: int
    unique_pitcher_pairs: int
    unique_stack_keys: int
    unique_families: int
    unique_salary_geometries: int
    max_pairwise_player_overlap: int
    active_parent_union_hits: int
    hybrid_union_hits: int
    marginal_hits_by_slot: tuple[int,...]
    common_worlds: int

_POP8=np.unpackbits(np.arange(256,dtype=np.uint8)[:,None],axis=1).sum(axis=1).astype(np.int16)

def _metric(metrics: Mapping[str,np.ndarray], key:str, n:int)->np.ndarray:
    if key not in metrics: return np.zeros(n,dtype=float)
    a=np.asarray(metrics[key],dtype=float)
    if len(a)!=n: raise RuntimeError(f"METRIC_LENGTH_MISMATCH:{key}:{len(a)}:{n}")
    return a

def _union_hits(bits: np.ndarray, positions: Sequence[int])->int:
    if bits.ndim!=2 or bits.dtype!=np.uint8: raise RuntimeError("TOP01_BITS_FORMAT_INVALID")
    cov=np.zeros(bits.shape[1],dtype=np.uint8)
    for j in positions: cov |= bits[int(j)]
    return int(_POP8[cov].sum())

def _gain_map(bits:np.ndarray, pool:list[int], covered:np.ndarray, batch:int=2048)->dict[int,int]:
    inv=np.bitwise_not(covered); out={}
    for st in range(0,len(pool),batch):
        ids=np.asarray(pool[st:st+batch],dtype=np.int64)
        gains=_POP8[np.bitwise_and(bits[ids],inv)].sum(axis=1).astype(np.int32)
        out.update((int(i),int(g)) for i,g in zip(ids,gains))
    return out

def select_portfolio(metrics:Mapping[str,np.ndarray], structures:Sequence[StructuralIdentity], *, top01_bits:np.ndarray, common_worlds:int, context:advisor.ContextProfile, board_size:int)->HybridSelection:
    for key in metrics:
        if str(key).upper() in parent.PROHIBITED_METRIC_NAMES:
            raise RuntimeError(f"PROHIBITED_SELECTOR_METRIC:{key}")
    # SUPERSEDED LEGACY PATH: RNWD authority retained only for rollback compatibility.
    pos, rnwd_receipt = rnwd.classic_positions(metrics, structures, board_size)
    sel_struct=[structures[int(i)] for i in pos]
    max_ov=0
    for a in range(len(sel_struct)):
        sa=set(sel_struct[a].players)
        for b in range(a): max_ov=max(max_ov,len(sa.intersection(sel_struct[b].players)))
    return HybridSelection(np.asarray(pos,dtype=np.int64),np.asarray(pos,dtype=np.int64),np.zeros(len(structures),dtype=np.int64),0.0,0.0,int(rnwd_receipt['CANDIDATE_COUNT']),((0,int(board_size)),),len({x.macro_spine_key for x in sel_struct}),len({x.pitcher_pair_key for x in sel_struct}),len({x.stack_key for x in sel_struct}),len({x.family_key for x in sel_struct}),len({x.salary_geometry_key for x in sel_struct}),int(max_ov),0,0,tuple(),int(common_worlds))

def _legacy_select_portfolio(metrics:Mapping[str,np.ndarray], structures:Sequence[StructuralIdentity], *, top01_bits:np.ndarray, common_worlds:int, context:advisor.ContextProfile, board_size:int)->HybridSelection:
    n=len(np.asarray(metrics['top01_rate']))
    if top01_bits.shape[0]!=n: raise RuntimeError(f"TOP01_BITS_ROW_MISMATCH:{top01_bits.shape[0]}:{n}")
    if top01_bits.dtype!=np.uint8: raise RuntimeError("TOP01_BITS_DTYPE_INVALID")
    expected_bytes=(int(common_worlds)+7)//8
    if top01_bits.shape[1]!=expected_bytes: raise RuntimeError(f"TOP01_BITS_WORLD_MISMATCH:{top01_bits.shape[1]}:{expected_bytes}")
    # Active parent remains the quality/governance baseline and control board.
    active=parent.select_portfolio(metrics,structures,context=context,board_size=board_size)
    tiers,primary_delta,lcb_delta=parent.quality_tiers(metrics,context=context)
    baseline=historical.ranking_order(metrics,context=context)
    base_rank=np.empty(n,dtype=np.int64); base_rank[baseline]=np.arange(n,dtype=np.int64)
    primary=_metric(metrics,'top01_rate',n); lcb=_metric(metrics,'top01_lcb',n); p99=_metric(metrics,'p99',n); cvar99=_metric(metrics,'cvar99',n); leverage=_metric(metrics,'leverage',n); chalk_fade=_metric(metrics,'chalk_failure_fade_edge',n)
    selected=[]; selected_struct=[]; remaining=set(range(n)); tier_counts=[]; gains_by_slot=[]; covered=np.zeros(top01_bits.shape[1],dtype=np.uint8)
    for tier in sorted(set(int(x) for x in tiers)):
        pool=[i for i in remaining if int(tiers[i])==tier]; cnt=0
        while pool and len(selected)<board_size:
            if not selected:
                i=min(pool,key=lambda j:(int(base_rank[j]), parent._stable_id_key(structures[j].lineup_id)))
                gain=int(_POP8[top01_bits[i]].sum())
            else:
                gains=_gain_map(top01_bits,pool,covered); best_gain=max(gains.values())
                tied=[j for j in pool if gains[j]==best_gain]
                used_macro={s.macro_spine_key for s in selected_struct}; used_pair={s.pitcher_pair_key for s in selected_struct}; used_stack={s.stack_key for s in selected_struct}; used_family={s.family_key for s in selected_struct}; used_salary={s.salary_geometry_key for s in selected_struct}
                def key(j:int):
                    s=structures[j]
                    return (-(1 if s.macro_spine_key not in used_macro else 0),-(1 if s.pitcher_pair_key not in used_pair else 0),-(1 if s.stack_key not in used_stack else 0),-(1 if s.family_key not in used_family else 0),-(1 if s.salary_geometry_key not in used_salary else 0),parent._max_overlap(s,selected_struct),-float(lcb[j]),-float(primary[j]),-float(cvar99[j]),-float(p99[j]),-float(leverage[j]),-float(chalk_fade[j]),int(base_rank[j]),parent._stable_id_key(s.lineup_id))
                i=min(tied,key=key); gain=gains[i]
            selected.append(int(i)); selected_struct.append(structures[i]); remaining.remove(i); pool.remove(i); cnt+=1; gains_by_slot.append(int(gain)); covered |= top01_bits[i]
        if cnt: tier_counts.append((tier,cnt))
        if len(selected)>=board_size: break
    if len(selected)!=board_size: raise RuntimeError(f"HYBRID_SELECTION_INCOMPLETE:{len(selected)}:{board_size}")
    max_ov=0
    for a in range(len(selected_struct)):
        sa=set(selected_struct[a].players)
        for b in range(a): max_ov=max(max_ov,len(sa.intersection(selected_struct[b].players)))
    hybrid_hits=int(_POP8[covered].sum()); parent_hits=_union_hits(top01_bits,active.positions)
    if hybrid_hits < parent_hits:
        # Fail closed to the active parent board if common-world union unexpectedly regresses.
        return HybridSelection(np.asarray(active.positions,dtype=np.int64),np.asarray(active.positions,dtype=np.int64),np.asarray(tiers,dtype=np.int64),primary_delta,lcb_delta,int(np.sum(tiers==0)),active.selected_tier_counts,active.unique_macro_spines,active.unique_pitcher_pairs,active.unique_stack_keys,active.unique_families,active.unique_salary_geometries,active.max_pairwise_player_overlap,parent_hits,parent_hits,tuple(),int(common_worlds))
    return HybridSelection(np.asarray(selected,dtype=np.int64),np.asarray(active.positions,dtype=np.int64),np.asarray(tiers,dtype=np.int64),primary_delta,lcb_delta,int(np.sum(tiers==0)),tuple(tier_counts),len({s.macro_spine_key for s in selected_struct}),len({s.pitcher_pair_key for s in selected_struct}),len({s.stack_key for s in selected_struct}),len({s.family_key for s in selected_struct}),len({s.salary_geometry_key for s in selected_struct}),int(max_ov),parent_hits,hybrid_hits,tuple(gains_by_slot),int(common_worlds))

def selector_receipt(sel:HybridSelection, context:advisor.ContextProfile, candidate_count:int)->dict[str,object]:
    return {'PATCH_ID':PATCH_ID,'SELECTOR_MODE':SELECTOR_MODE,'PRIMARY_OBJECTIVE':PRIMARY_OBJECTIVE,'CANDIDATE_COUNT':int(candidate_count),'COMMON_WORLDS':sel.common_worlds,'ACTIVE_PARENT_UNION_HITS':sel.active_parent_union_hits,'HYBRID_UNION_HITS':sel.hybrid_union_hits,'ACTIVE_PARENT_UNION_RATE':sel.active_parent_union_hits/sel.common_worlds,'HYBRID_UNION_RATE':sel.hybrid_union_hits/sel.common_worlds,'MARGINAL_HITS_BY_SLOT':list(sel.marginal_hits_by_slot),'NONINFERIOR_FRONTIER_SIZE':sel.frontier_size,'PRIMARY_NONINFERIORITY_DELTA':sel.primary_delta,'LCB_NONINFERIORITY_DELTA':sel.lcb_delta,'SELECTED_TIER_COUNTS':[list(x) for x in sel.selected_tier_counts],'UNIQUE_MACRO_SPINES_SELECTED':sel.unique_macro_spines,'UNIQUE_PITCHER_PAIRS_SELECTED':sel.unique_pitcher_pairs,'UNIQUE_STACK_KEYS_SELECTED':sel.unique_stack_keys,'MAX_PAIRWISE_PLAYER_OVERLAP':sel.max_pairwise_player_overlap,'PARENT_SELECTOR_PATCH_ID':parent.PATCH_ID,'POSTLOCK_RESULTS_USED_BY_SELECTOR':False,'HARD_PLAYER_EXPOSURE_CAP_USED':False,'HARD_FAMILY_QUOTAS_USED':False,'HARD_PITCHER_PAIR_QUOTAS_USED':False,'WEIGHTED_METRIC_SUM_USED':False,'FIELD_CONTEXT':context.as_dict()}
