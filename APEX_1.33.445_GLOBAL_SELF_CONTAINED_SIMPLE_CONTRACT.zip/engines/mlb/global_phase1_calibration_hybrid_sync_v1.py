from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Mapping, Sequence
import json

PATCH_ID = "GLOBAL_PHASE1_CALIBRATION_HYBRID_SYNC_v1"
SCOPE = "ALL_SPORTS_ALL_MODES_ALL_CONTESTS"

REQUIRED_PHASE1_KEYS = frozenset({
    "SLATE_FINGERPRINT",
    "CALIBRATION_FINGERPRINT",
    "PLAYER_POSTERIORS",
    "MATCH_OR_GAME_POSTERIORS",
    "TAIL_ARCHETYPE_POSTERIORS",
    "SCENARIO_CLUSTER_PROBABILITIES",
    "BRANCH_PROBABILITIES",
    "CPT_ROLE_POSTERIORS",
    "CORRELATION_MATRIX",
    "OWNERSHIP_PRIORS",
    "DUPLICATION_PRIORS",
    "WIN_PROBABILITY",
    "TOP_0_1_PROBABILITY",
    "TOP_1_PROBABILITY",
    "P95",
    "P99",
})

HASH_FIELDS = (
    "PHASE1_CALIBRATION_SHA256",
    "PHASE2_INPUT_CALIBRATION_SHA256",
    "PHASE3_INPUT_CALIBRATION_SHA256",
    "PHASE3_1_INPUT_CALIBRATION_SHA256",
    "PHASE3_95_INPUT_CALIBRATION_SHA256",
    "HYBRID_INPUT_CALIBRATION_SHA256",
)

class EngineIntegrityHalt(RuntimeError):
    pass

@dataclass(frozen=True)
class FrozenCalibration:
    payload: Mapping[str, object]
    calibration_sha256: str

def freeze_phase1_calibration(payload: Mapping[str, object]) -> FrozenCalibration:
    missing = REQUIRED_PHASE1_KEYS - set(payload)
    if missing:
        raise EngineIntegrityHalt(
            "ENGINE_INTEGRITY_HALT:MISSING_PHASE1_KEYS:"
            + ",".join(sorted(missing))
        )

    canonical = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    digest = sha256(canonical.encode()).hexdigest()
    return FrozenCalibration(payload=dict(payload), calibration_sha256=digest)

def build_hash_chain(calibration_sha256: str) -> Mapping[str, str]:
    if not calibration_sha256 or len(calibration_sha256) != 64:
        raise EngineIntegrityHalt(
            "ENGINE_INTEGRITY_HALT:INVALID_CALIBRATION_SHA256"
        )
    return {field: calibration_sha256 for field in HASH_FIELDS}

def validate_hash_chain(hash_chain: Mapping[str, str]) -> None:
    missing = set(HASH_FIELDS) - set(hash_chain)
    if missing:
        raise EngineIntegrityHalt(
            "ENGINE_INTEGRITY_HALT:MISSING_HASH_FIELDS:"
            + ",".join(sorted(missing))
        )

    values = [hash_chain[field] for field in HASH_FIELDS]
    if len(set(values)) != 1:
        raise EngineIntegrityHalt(
            "ENGINE_INTEGRITY_HALT:CALIBRATION_HASH_MISMATCH:"
            + "|".join(f"{field}={hash_chain[field]}" for field in HASH_FIELDS)
        )

def bind_downstream_phase(
    *,
    phase_name: str,
    frozen_calibration: FrozenCalibration,
    supplied_calibration_sha256: str,
) -> Mapping[str, object]:
    if supplied_calibration_sha256 != frozen_calibration.calibration_sha256:
        raise EngineIntegrityHalt(
            "ENGINE_INTEGRITY_HALT:"
            f"{phase_name}_CALIBRATION_HASH_MISMATCH"
        )
    return {
        "phase_name": phase_name,
        "calibration_sha256": frozen_calibration.calibration_sha256,
        "calibration_payload": frozen_calibration.payload,
    }

def build_hybrid_review_packet(
    *,
    candidate_rows: Sequence[Mapping[str, object]],
    frozen_calibration: FrozenCalibration,
    hybrid_input_calibration_sha256: str,
) -> Mapping[str, object]:
    validate_hash_chain(build_hash_chain(frozen_calibration.calibration_sha256))

    if hybrid_input_calibration_sha256 != frozen_calibration.calibration_sha256:
        raise EngineIntegrityHalt(
            "ENGINE_INTEGRITY_HALT:HYBRID_CALIBRATION_HASH_MISMATCH"
        )

    return {
        "patch_id": PATCH_ID,
        "candidate_count": len(candidate_rows),
        "calibration_sha256": frozen_calibration.calibration_sha256,
        "phase1_calibration": frozen_calibration.payload,
        "candidates": list(candidate_rows),
    }

def fail_closed_receipt(error: Exception) -> Mapping[str, object]:
    return {
        "RUN_STATE": "RUN_INVALID",
        "FINAL_BOARD_SIZE": 0,
        "FAILURE_CODE": str(error),
    }
