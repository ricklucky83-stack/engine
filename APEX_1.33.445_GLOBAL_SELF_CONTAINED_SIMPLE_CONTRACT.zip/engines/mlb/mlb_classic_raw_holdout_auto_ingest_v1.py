#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

PATCH_ID = "MLB_CLASSIC_RAW_HOLDOUT_AUTO_INGEST_AND_AUTONOMOUS_LOSO_TRIGGER_v1"
MODE = "MLB_CLASSIC"
ROSTER_SCHEMA = "DK_MLB_CLASSIC_2P_C_1B_2B_3B_SS_3OF"
POOL_REQUIRED = {"PLAYER", "POS", "LINEUP", "TEAM", "OPP", "SAL"}
CONTEST_REQUIRED = {"Rank", "Points", "Lineup", "Player", "Roster Position", "FPTS"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def normalize_name(value: object) -> str:
    text = re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()
    return re.sub(r"\s+", " ", text)


def _active_rows(frame: pd.DataFrame) -> pd.DataFrame:
    lineup = frame["LINEUP"].astype(str).str.strip().str.upper()
    return frame.loc[lineup.eq("SP") | lineup.str.fullmatch(r"[1-9]")].copy()


def is_classic_pool(path: Path) -> tuple[bool, str]:
    try:
        frame = pd.read_csv(path, nrows=1000)
        cols = set(frame.columns.astype(str))
        if not POOL_REQUIRED.issubset(cols):
            return False, "MISSING_MLB_CLASSIC_POOL_COLUMNS"
        pos = frame["POS"].astype(str)
        if pos.str.contains(r"CPTN|CPT", case=False, regex=True).any():
            return False, "SHOWDOWN_MULTIPLIER_POSITION_PRESENT"
        active = _active_rows(frame)
        lineup = active["LINEUP"].astype(str).str.strip().str.upper()
        pitcher_count = int(lineup.eq("SP").sum())
        hitter_count = int(lineup.str.fullmatch(r"[1-9]").sum())
        active_team_count = int(active["TEAM"].astype(str).replace("nan", "").loc[lambda s: s.ne("")].nunique())
        if pitcher_count < 2:
            return False, "LT_2_ACTIVE_STARTING_PITCHERS"
        if hitter_count < 8:
            return False, "LT_8_ACTIVE_HITTERS"
        if active_team_count < 3:
            return False, "LT_3_ACTIVE_TEAMS_NOT_MLB_CLASSIC"
        active_pos = "/".join(active["POS"].astype(str).tolist()).upper()
        for token in ("C", "1B", "2B", "3B", "SS", "OF"):
            if token not in active_pos:
                return False, f"MISSING_ACTIVE_POSITION_{token}"
        return True, "PASS"
    except Exception as exc:
        return False, f"READ_ERROR:{type(exc).__name__}:{exc}"


def _contest_frame(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as z:
            members = sorted(n for n in z.namelist() if n.lower().endswith(".csv"))
            if not members:
                raise ValueError("NO_CSV_MEMBER")
            with z.open(members[0]) as f:
                return pd.read_csv(f)
    return pd.read_csv(path)


def is_classic_contest(path: Path) -> tuple[bool, str, str | None]:
    try:
        member: str | None = None
        if path.suffix.lower() == ".zip":
            with zipfile.ZipFile(path) as z:
                members = sorted(n for n in z.namelist() if n.lower().endswith(".csv"))
                if not members:
                    return False, "NO_CSV_MEMBER", None
                member = members[0]
        frame = _contest_frame(path)
        cols = set(frame.columns.astype(str))
        if not CONTEST_REQUIRED.issubset(cols):
            return False, "MISSING_CONTEST_COLUMNS", member
        roster = frame["Roster Position"].dropna().astype(str)
        lineup = frame["Lineup"].dropna().astype(str)
        if roster.str.contains(r"CPT|FLEX|UTIL", case=False, regex=True).any():
            return False, "NON_CLASSIC_ROSTER_POSITION_PRESENT", member
        if lineup.str.contains(r"(?:^|\s)(?:CPT|FLEX|UTIL)\s", case=False, regex=True).any():
            return False, "NON_CLASSIC_LINEUP_TOKEN_PRESENT", member
        classic_lines = lineup.str.contains(r"(?:^|\s)P\s+", case=False, regex=True) & lineup.str.contains(
            r"(?:^|\s)(?:C|1B|2B|3B|SS|OF)\s+", case=False, regex=True
        )
        if not bool(classic_lines.any()):
            return False, "NO_MLB_CLASSIC_ENTRY_LINEUP", member
        if infer_field_size(path) is None:
            return False, "FIELD_SIZE_UNRESOLVED", member
        return True, "PASS", member
    except Exception as exc:
        return False, f"READ_ERROR:{type(exc).__name__}:{exc}", None


def pool_players(path: Path) -> set[str]:
    frame = pd.read_csv(path, usecols=lambda c: str(c) in {"PLAYER", "LINEUP"})
    if "LINEUP" in frame.columns:
        frame = _active_rows(frame.assign(POS="", TEAM="", OPP="", SAL=0)) if False else frame
    return {normalize_name(x) for x in frame["PLAYER"].dropna() if normalize_name(x)}


def contest_players(path: Path) -> set[str]:
    frame = _contest_frame(path)
    if "Player" not in frame.columns:
        return set()
    return {normalize_name(x) for x in frame["Player"].dropna() if normalize_name(x)}


def infer_field_size(path: Path) -> int | None:
    frame = _contest_frame(path)
    if "Rank" not in frame.columns:
        return None
    rank = pd.to_numeric(frame["Rank"].astype(str).str.extract(r"(\d+)", expand=False), errors="coerce")
    if not rank.notna().any():
        return None
    value = int(rank.max())
    return value if value > 0 else None


def field_band(field_size: int) -> str:
    if field_size <= 300:
        return "TIER_1_50_300"
    if field_size <= 3000:
        return "TIER_2_301_3000"
    return "TIER_3_3001_PLUS"


def slate_hash(pool_path: Path, players: set[str]) -> str:
    payload = f"{sha256(pool_path)}|{'|'.join(sorted(players))}|{ROSTER_SCHEMA}"
    return hashlib.sha256(payload.encode()).hexdigest()


def pair_hash(pool_digest: str, contest_digest: str) -> str:
    return hashlib.sha256(f"{pool_digest}|{contest_digest}|{MODE}|{ROSTER_SCHEMA}".encode()).hexdigest()


def _load_refs(path: Path | None) -> list[dict[str, Any]]:
    if not path or not path.exists():
        return []
    payload = json.loads(path.read_text())
    return list(payload.get("REFERENCES", payload.get("REFERENCED_CONTROLS", [])))


def _ref_names(ref: dict[str, Any]) -> tuple[str | None, str | None]:
    return (
        ref.get("POOL_FILE") or ref.get("POOL") or ref.get("PLAYER_POOL"),
        ref.get("CONTEST_FILE") or ref.get("CONTEST") or ref.get("CONTEST_STANDINGS"),
    )


def discover(root: Path, exclude: Path | None = None) -> tuple[list[Path], list[Path]]:
    pools: list[Path] = []
    contests: list[Path] = []
    exclude_resolved = exclude.resolve() if exclude else None
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name.startswith("."):
            continue
        if exclude_resolved is not None:
            try:
                path.resolve().relative_to(exclude_resolved)
                continue
            except ValueError:
                pass
        suffix = path.suffix.lower()
        if suffix == ".csv":
            ok, _ = is_classic_pool(path)
            if ok:
                pools.append(path)
                continue
        if suffix in {".zip", ".csv"}:
            ok, _, _ = is_classic_contest(path)
            if ok:
                contests.append(path)
    return pools, contests


def _score(pool_set: set[str], contest_set: set[str]) -> tuple[float, float, float]:
    if not pool_set or len(contest_set) < 10:
        return 0.0, 0.0, 0.0
    inter = len(pool_set & contest_set)
    coverage = inter / len(contest_set)
    jaccard = inter / len(pool_set | contest_set)
    return 0.75 * coverage + 0.25 * jaccard, coverage, jaccard


def _copy_immutable(source: Path, target: Path, expected_hash: str) -> str:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if sha256(target) != expected_hash:
            raise RuntimeError(f"IMMUTABLE_HASH_CONFLICT={target}")
        return "IDEMPOTENT_PRESENT"
    shutil.copy2(source, target)
    if sha256(target) != expected_hash:
        target.unlink(missing_ok=True)
        raise RuntimeError(f"COPY_HASH_MISMATCH={source}")
    return "COPIED"


def _as_set(values: Iterable[str] | None) -> set[str]:
    return {str(x).lower() for x in (values or []) if str(x).strip()}


def ingest(
    root: Path,
    vault: Path,
    receipt_path: Path,
    reference_ledger: Path | None = None,
    excluded_pool_hashes: Iterable[str] | None = None,
    excluded_contest_hashes: Iterable[str] | None = None,
    excluded_slate_hashes: Iterable[str] | None = None,
) -> dict[str, Any]:
    pools, contests = discover(root, vault)
    refs = _load_refs(reference_ledger)
    ref_pairs: dict[tuple[str | None, str | None], dict[str, Any]] = {_ref_names(r): r for r in refs}
    pool_sets = {p: pool_players(p) for p in pools}
    contest_sets = {p: contest_players(p) for p in contests}
    excluded_pool = _as_set(excluded_pool_hashes)
    excluded_contest = _as_set(excluded_contest_hashes)
    excluded_slate = _as_set(excluded_slate_hashes)
    matches: list[dict[str, Any]] = []
    ambiguous: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []

    for contest in contests:
        exact = [(pool, ref_pairs[(pool.name, contest.name)]) for pool in pools if (pool.name, contest.name) in ref_pairs]
        chosen: Path | None = None
        ref: dict[str, Any] | None = None
        method = ""
        score = coverage = jaccard = 0.0
        if len(exact) == 1:
            chosen, ref = exact[0]
            method = "EXACT_REFERENCE_FILENAME_PAIR"
            score = coverage = 1.0
        elif len(exact) > 1:
            ambiguous.append({"CONTEST_FILE": str(contest), "REASON": "MULTIPLE_EXACT_REFERENCE_POOLS"})
            continue
        else:
            candidates = sorted(
                [(*_score(pool_sets[pool], contest_sets[contest]), pool) for pool in pools],
                key=lambda x: (-x[0], str(x[3])),
            )
            if not candidates or candidates[0][1] < 0.85 or candidates[0][0] < 0.65:
                rejected.append({"CONTEST_FILE": str(contest), "REASON": "NO_CONFIDENT_POOL_MATCH"})
                continue
            if len(candidates) > 1 and candidates[0][0] - candidates[1][0] <= 0.02:
                ambiguous.append({
                    "CONTEST_FILE": str(contest), "REASON": "TOP_TWO_MATCH_SCORES_AMBIGUOUS",
                    "TOP_SCORE": candidates[0][0], "SECOND_SCORE": candidates[1][0],
                    "TOP_POOL": str(candidates[0][3]), "SECOND_POOL": str(candidates[1][3]),
                })
                continue
            score, coverage, jaccard, chosen = candidates[0]
            method = "PLAYER_UNIVERSE_COVERAGE_MATCH"
        if chosen is None:
            continue
        field = infer_field_size(contest) or (int(ref.get("FIELD_SIZE")) if ref and ref.get("FIELD_SIZE") else None)
        if field is None:
            rejected.append({"CONTEST_FILE": str(contest), "POOL_FILE": str(chosen), "REASON": "FIELD_SIZE_UNRESOLVED"})
            continue
        pool_digest = sha256(chosen)
        contest_digest = sha256(contest)
        slate_digest = slate_hash(chosen, pool_sets[chosen])
        pair_digest = pair_hash(pool_digest, contest_digest)
        exclusion_reasons = []
        if pool_digest.lower() in excluded_pool:
            exclusion_reasons.append("EXCLUDED_TARGET_POOL_SHA256")
        if contest_digest.lower() in excluded_contest:
            exclusion_reasons.append("EXCLUDED_TARGET_CONTEST_SHA256")
        if slate_digest.lower() in excluded_slate:
            exclusion_reasons.append("EXCLUDED_TARGET_SLATE_SHA256")
        control_eligible = not exclusion_reasons
        pair_dir = vault / slate_digest / contest_digest[:16]
        pool_target = pair_dir / "pool" / chosen.name
        contest_target = pair_dir / "contest" / contest.name
        pool_copy = _copy_immutable(chosen, pool_target, pool_digest)
        contest_copy = _copy_immutable(contest, contest_target, contest_digest)
        manifest = {
            "PATCH_ID": PATCH_ID,
            "STATUS": "BYTE_COMPLETE_RAW_PAIR_INGESTED",
            "INGESTED_AT_UTC": datetime.now(timezone.utc).isoformat(),
            "MODE": MODE,
            "ROSTER_SCHEMA": ROSTER_SCHEMA,
            "FIELD_SIZE": int(field),
            "FIELD_BAND": field_band(int(field)),
            "SLATE_SHA256": slate_digest,
            "PAIR_SHA256": pair_digest,
            "POOL_FILE": str(pool_target.relative_to(vault)),
            "CONTEST_FILE": str(contest_target.relative_to(vault)),
            "POOL_ORIGINAL_NAME": chosen.name,
            "CONTEST_ORIGINAL_NAME": contest.name,
            "POOL_SHA256": pool_digest,
            "CONTEST_SHA256": contest_digest,
            "MATCH_METHOD": method,
            "MATCH_SCORE": score,
            "CONTEST_PLAYER_COVERAGE": coverage,
            "PLAYER_JACCARD": jaccard,
            "POOL_PLAYER_COUNT": len(pool_sets[chosen]),
            "CONTEST_PLAYER_COUNT": len(contest_sets[contest]),
            "BLIND_CONTROL_ELIGIBLE": control_eligible,
            "CONTROL_EXCLUSION_REASONS": exclusion_reasons,
            "TARGET_SLATE_EXCLUDED": bool(exclusion_reasons),
            "PRODUCTION_SELECTOR_MUTATED": False,
        }
        manifest_path = pair_dir / "pair_manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
        matches.append({**manifest, "POOL_COPY": pool_copy, "CONTEST_COPY": contest_copy, "MANIFEST": str(manifest_path)})

    distinct_all = sorted({m["SLATE_SHA256"] for m in matches})
    distinct_eligible = sorted({m["SLATE_SHA256"] for m in matches if m["BLIND_CONTROL_ELIGIBLE"]})
    result = {
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "PATCH_ID": PATCH_ID,
        "ROOT_SCANNED": str(root),
        "VAULT": str(vault),
        "POOLS_DISCOVERED": len(pools),
        "CONTESTS_DISCOVERED": len(contests),
        "PAIRS_INGESTED_OR_PRESENT": len(matches),
        "DISTINCT_SLATES_IN_THIS_INGEST": len(distinct_all),
        "CONTROL_ELIGIBLE_DISTINCT_SLATES_IN_THIS_INGEST": len(distinct_eligible),
        "AMBIGUOUS_MATCHES": ambiguous,
        "REJECTED_MATCHES": rejected,
        "FAIL_CLOSED": bool(ambiguous),
        "PRODUCTION_SELECTOR_MUTATED": False,
        "PRODUCTION_BOARD_MUTATED": False,
        "AUTOMATIC_PRODUCTION_PROMOTION_ALLOWED": False,
        "MATCHES": matches,
    }
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    receipt_path.write_text(json.dumps(result, indent=2) + "\n")
    return result


def ingest_and_trigger(
    root: Path,
    vault: Path,
    receipt_path: Path,
    controller_output_dir: Path,
    reference_ledger: Path | None = None,
    excluded_pool_hashes: Iterable[str] | None = None,
    excluded_contest_hashes: Iterable[str] | None = None,
    excluded_slate_hashes: Iterable[str] | None = None,
    execute_loso: bool = False,
    candidate_engine_root: Path | None = None,
    baseline_engine_root: Path | None = None,
) -> dict[str, Any]:
    result = ingest(
        root, vault, receipt_path, reference_ledger,
        excluded_pool_hashes, excluded_contest_hashes, excluded_slate_hashes,
    )
    from mlb_classic_loso_controller_v1 import build_plan
    controller = build_plan(
        vault=vault,
        output_dir=controller_output_dir,
        execute=execute_loso,
        candidate_engine_root=candidate_engine_root,
        baseline_engine_root=baseline_engine_root,
    )
    result["LOSO_CONTROLLER"] = controller
    receipt_path.write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--vault", required=True)
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--controller-output-dir", required=True)
    parser.add_argument("--reference-ledger")
    parser.add_argument("--exclude-pool-sha256", action="append", default=[])
    parser.add_argument("--exclude-contest-sha256", action="append", default=[])
    parser.add_argument("--exclude-slate-sha256", action="append", default=[])
    parser.add_argument("--execute-loso", action="store_true")
    parser.add_argument("--candidate-engine-root")
    parser.add_argument("--baseline-engine-root")
    args = parser.parse_args()
    result = ingest_and_trigger(
        Path(args.root), Path(args.vault), Path(args.receipt), Path(args.controller_output_dir),
        Path(args.reference_ledger) if args.reference_ledger else None,
        args.exclude_pool_sha256, args.exclude_contest_sha256, args.exclude_slate_sha256,
        args.execute_loso,
        Path(args.candidate_engine_root) if args.candidate_engine_root else None,
        Path(args.baseline_engine_root) if args.baseline_engine_root else None,
    )
    summary = {k: result[k] for k in (
        "EXECUTION_STATE", "POOLS_DISCOVERED", "CONTESTS_DISCOVERED",
        "PAIRS_INGESTED_OR_PRESENT", "CONTROL_ELIGIBLE_DISTINCT_SLATES_IN_THIS_INGEST", "FAIL_CLOSED",
    )}
    summary["LOSO_READY"] = result["LOSO_CONTROLLER"]["LOSO_READY"]
    summary["LOSO_EXECUTED"] = result["LOSO_CONTROLLER"]["LOSO_EXECUTED"]
    print(json.dumps(summary, indent=2))
    return 2 if result["FAIL_CLOSED"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
