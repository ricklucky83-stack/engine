from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Any
import math
import numpy as np

PATCH_ID = "MLB_SHOWDOWN_BULLPEN_ROLE_EVIDENCE_MODEL_v1"


def _num(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        return x if np.isfinite(x) else default
    except Exception:
        return default


@dataclass(frozen=True)
class ReliefRoleEstimate:
    appearance_probability: float
    evidence_grade: str
    workload_adjustment: float
    direct_role_signal: float | None


def estimate_relief_role(row: Mapping[str, Any], *, games: float, ipg: float, bulk_role: bool, bulk_ipg: float) -> ReliefRoleEstimate:
    """Estimate P(appearance) independently of ownership and pitcher quality.

    Priority is explicit role/workload evidence when present. When the provider
    lacks recent bullpen workload/hierarchy fields, fall back transparently to
    season appearance frequency plus workload shape. ERA/K9/FIP and ownership
    never determine whether the pitcher appears; those belong to conditional
    performance and field modeling respectively.
    """
    direct = None
    for key in ("RP App%", "Relief App%", "Appearance %", "APP%"):
        if key in row:
            v = _num(row.get(key), -1.0)
            if v >= 0:
                direct = v / 100.0 if v > 1.0 else v
                break

    if direct is not None:
        p = float(np.clip(direct, 0.05, 0.85))
        grade = "DIRECT_ROLE_PROBABILITY"
    else:
        g = max(0.0, float(games))
        # 55 appearances / 162 team games => ~0.34 seasonal appearance rate.
        seasonal_frequency = float(np.clip(g / 162.0, 0.04, 0.62))
        # Longer multi-inning relievers generally appear less often but remain
        # viable because their conditional innings ceiling is larger.
        long_relief_discount = float(np.clip(1.06 - 0.10 * max(0.0, ipg - 1.0), 0.72, 1.08))
        p = seasonal_frequency * long_relief_discount
        grade = "FALLBACK_SEASON_USAGE_NO_RECENT_WORKLOAD"

    workload_adjustment = 1.0
    days_rest = None
    for key in ("Days Rest", "DAYS REST", "Rest Days"):
        if key in row:
            v = _num(row.get(key), -1.0)
            if v >= 0:
                days_rest = v
                break
    recent_pitches = None
    for key in ("Last Pitch Count", "L1 Pitches", "Recent Pitches", "Pitch Count"):
        if key in row:
            v = _num(row.get(key), -1.0)
            if v >= 0:
                recent_pitches = v
                break

    if days_rest is not None:
        workload_adjustment *= 0.58 if days_rest <= 0 else 0.82 if days_rest == 1 else 1.05 if days_rest >= 2 else 1.0
        grade = "RECENT_WORKLOAD_PLUS_SEASON_USAGE"
    if recent_pitches is not None:
        workload_adjustment *= float(np.clip(1.08 - recent_pitches / 80.0, 0.45, 1.08))
        grade = "RECENT_WORKLOAD_PLUS_SEASON_USAGE"

    if bulk_role:
        # Bulk path: lower frequency than a one-inning reliever, but do not
        # suppress a demonstrated multi-inning role below a credible floor.
        bulk_floor = float(np.clip(0.20 + 0.055 * max(0.0, bulk_ipg), 0.28, 0.50))
        p = max(p * 0.86, bulk_floor)

    p = float(np.clip(p * workload_adjustment, 0.08, 0.72))
    return ReliefRoleEstimate(p, grade, float(workload_adjustment), direct)
