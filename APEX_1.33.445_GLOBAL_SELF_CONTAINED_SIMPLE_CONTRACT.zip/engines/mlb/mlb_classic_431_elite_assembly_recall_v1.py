from __future__ import annotations

from dataclasses import asdict, dataclass
from itertools import permutations, product
from typing import Mapping, Sequence

PATCH_ID = "MLB_CLASSIC_431_ELITE_ASSEMBLY_RECALL_v1"
PATTERN = "4-3-1"
PRIMARY_DEPTH = 3
SECONDARY_DEPTH = 3
SINGLETON_DEPTH = 2
PITCHER_PAIR_DEPTH = 1


@dataclass(frozen=True)
class RecallConfig:
    primary_depth: int = PRIMARY_DEPTH
    secondary_depth: int = SECONDARY_DEPTH
    singleton_depth: int = SINGLETON_DEPTH
    pitcher_pair_depth: int = PITCHER_PAIR_DEPTH

    def to_receipt(self) -> dict[str, int]:
        return asdict(self)


def ordered_team_assignments(teams: Sequence[str]):
    """Deterministic (primary4, secondary3, singleton1) team assignments."""
    yield from permutations(tuple(sorted(map(str, teams))), 3)


def iter_elite_hitter_assemblies(
    combo_pool: Mapping[tuple[str, int], Sequence[tuple[tuple[int, ...], int, float]]],
    teams: Sequence[str],
    config: RecallConfig = RecallConfig(),
):
    """Enumerate a bounded deterministic elite 4-3-1 assembly lattice.

    This is additive recall only. It does not alter stochastic births, legal stack
    geometry, salary bounds, projection scoring, or downstream selection.
    """
    for primary, secondary, singleton in ordered_team_assignments(teams):
        p4 = combo_pool.get((primary, 4), ())[: config.primary_depth]
        p3 = combo_pool.get((secondary, 3), ())[: config.secondary_depth]
        p1 = combo_pool.get((singleton, 1), ())[: config.singleton_depth]
        for c4, c3, c1 in product(p4, p3, p1):
            hitters = tuple(sorted(tuple(c4[0]) + tuple(c3[0]) + tuple(c1[0])))
            if len(hitters) == 8 and len(set(hitters)) == 8:
                yield (primary, secondary, singleton), hitters
