from __future__ import annotations

"""Historical DraftKings NFL Showdown field-ledger certification.

Purpose
-------
Turn a post-lock DraftKings contest-standings export plus the frozen pre-lock player
pool into durable calibration evidence for *future* Showdown slates.  The ingest is
strictly evidentiary: it never changes live field weights and it never authorizes the
source contest (or a sibling contest from the same underlying game) to train itself.

Two certification levels are intentionally separate:
- ownership_summary_certified: the DK CPT/FLEX player ownership summary is complete
  enough to preserve actual marginal field ownership.
- structural_field_certified: every scored/parseable lineup can also be mapped to the
  frozen pre-lock salary/team/position frame, allowing salary-left, team-split,
  Captain-role, correlation-geometry, and duplication targets to be trusted.

A complete ownership ledger must not be mislabeled as a complete structural ledger.
"""

from dataclasses import dataclass, asdict
from datetime import date
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
import csv
import hashlib
import json
import math
import re
import unicodedata

import numpy as np
import pandas as pd

PATCH_ID = "NFL_SD_HISTORICAL_FIELD_LEDGER_CERTIFICATION_INGEST_v1"
SCHEMA_VERSION = "1.0"
# DraftKings exports round ownership to two decimals and may omit exact-zero rows.
# Allow at most 0.5 percentage points of missing/rounding mass PER roster seat.
OWNERSHIP_MASS_TOLERANCE_PER_SLOT = 0.005
EXPECTED_CPT_MASS = 1.0
EXPECTED_FLEX_MASS = 5.0
SHOWDOWN_ROSTER_SIZE = 6
SALARY_CAP = 50_000

_SLOT_RE = re.compile(r"(?:^|\s)(CPT|FLEX)\s+(.+?)(?=\s+(?:CPT|FLEX)\s+|$)", re.IGNORECASE)
_SUFFIX_RE = re.compile(r"\b(?:jr|sr|ii|iii|iv|v)\b\.?", re.IGNORECASE)


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _sha_json(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()


def normalize_name(value: Any) -> str:
    s = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode("ascii").lower()
    s = _SUFFIX_RE.sub(" ", s)
    s = s.replace("d/st", " ").replace("dst", " ")
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return " ".join(s.split())


def base_position(value: Any) -> str:
    s = str(value or "").upper().strip()
    return s.split("/")[0].strip() if s else "UNK"


def parse_percent(value: Any) -> float:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return float("nan")
    s = str(value).strip().replace("%", "")
    if not s:
        return float("nan")
    try:
        return float(s) / 100.0
    except ValueError:
        return float("nan")


def parse_lineup(lineup: Any) -> list[tuple[str, str]]:
    if lineup is None or (isinstance(lineup, float) and math.isnan(lineup)):
        return []
    text = str(lineup).strip()
    if not text:
        return []
    found = [(slot.upper(), name.strip()) for slot, name in _SLOT_RE.findall(text)]
    if len(found) != SHOWDOWN_ROSTER_SIZE:
        return []
    if found[0][0] != "CPT" or any(slot != "FLEX" for slot, _ in found[1:]):
        return []
    return found


def _pool_alias_map(pool: pd.DataFrame) -> tuple[dict[str, int], dict[str, list[int]]]:
    if "PLAYER" not in pool.columns:
        raise ValueError("HIST_FIELD_INGEST_POOL_PLAYER_COLUMN_MISSING")
    aliases: dict[str, list[int]] = {}
    for i, row in pool.reset_index(drop=True).iterrows():
        raw = str(row["PLAYER"]).strip()
        candidates = {normalize_name(raw)}
        if base_position(row.get("POS")) == "DST":
            # Team defenses are frequently rendered by DK as just the nickname.
            parts = normalize_name(raw).split()
            if parts:
                candidates.add(parts[-1])
        for key in candidates:
            if key:
                aliases.setdefault(key, []).append(int(i))
    unique = {k: v[0] for k, v in aliases.items() if len(set(v)) == 1}
    ambiguous = {k: sorted(set(v)) for k, v in aliases.items() if len(set(v)) > 1}
    return unique, ambiguous


def _map_name(name: str, unique: Mapping[str, int], ambiguous: Mapping[str, Sequence[int]]) -> int | None:
    key = normalize_name(name)
    if key in ambiguous:
        return None
    return unique.get(key)


def infer_underlying_game_id(pool: pd.DataFrame, contest_date: str) -> str:
    if "TEAM" not in pool.columns:
        raise ValueError("HIST_FIELD_INGEST_POOL_TEAM_COLUMN_MISSING")
    teams = sorted({str(x).strip().upper() for x in pool["TEAM"].dropna() if str(x).strip()})
    if len(teams) != 2:
        raise ValueError(f"HIST_FIELD_INGEST_EXPECTED_TWO_TEAMS:{teams}")
    return f"{str(contest_date)[:10]}__{teams[0]}__{teams[1]}"


@dataclass(frozen=True)
class OwnershipCertification:
    certified: bool
    cpt_mass: float
    flex_mass: float
    cpt_mass_error: float
    flex_mass_error: float
    unique_players: int
    duplicate_player_slot_rows: int
    invalid_percent_rows: int
    reason: str


@dataclass(frozen=True)
class StructuralCertification:
    certified: bool
    entry_rows_total: int
    lineup_rows_parseable: int
    lineup_rows_unparseable: int
    lineup_rows_fully_mapped: int
    lineup_rows_unmapped: int
    ownership_players_total: int
    ownership_players_mapped_to_pool: int
    ownership_players_unmapped_to_pool: int
    unmapped_ownership_cpt_mass: float
    unmapped_ownership_flex_mass: float
    reason: str


def extract_ownership_ledger(standings: pd.DataFrame) -> tuple[pd.DataFrame, OwnershipCertification]:
    required = {"Player", "Roster Position", "%Drafted"}
    missing = required - set(standings.columns)
    if missing:
        raise ValueError(f"HIST_FIELD_INGEST_STANDINGS_OWNERSHIP_COLUMNS_MISSING:{sorted(missing)}")
    s = standings.loc[standings["Player"].notna(), ["Player", "Roster Position", "%Drafted"]].copy()
    s["slot"] = s["Roster Position"].astype(str).str.strip().str.upper()
    s = s[s["slot"].isin(["CPT", "FLEX"])].copy()
    s["own"] = s["%Drafted"].map(parse_percent)
    invalid = int((~np.isfinite(s["own"].to_numpy(float))).sum())
    dup = int(s.duplicated(subset=["Player", "slot"], keep=False).sum())
    cpt_mass = float(s.loc[s.slot == "CPT", "own"].sum(skipna=True))
    flex_mass = float(s.loc[s.slot == "FLEX", "own"].sum(skipna=True))
    cpt_err = abs(cpt_mass - EXPECTED_CPT_MASS)
    flex_err = abs(flex_mass - EXPECTED_FLEX_MASS)
    mass_ok = (
        cpt_err <= OWNERSHIP_MASS_TOLERANCE_PER_SLOT * 1
        and flex_err <= OWNERSHIP_MASS_TOLERANCE_PER_SLOT * 5
    )
    certified = bool(len(s) > 0 and invalid == 0 and dup == 0 and mass_ok)
    reason = "PASS" if certified else (
        f"INVALID_PERCENT_ROWS={invalid};DUPLICATE_PLAYER_SLOT_ROWS={dup};"
        f"CPT_MASS_ERROR={cpt_err:.8f};FLEX_MASS_ERROR={flex_err:.8f}"
    )

    # Pivot to one row per player; absent CPT rows are exact/rounded zeros in DK's
    # ownership summary when the overall CPT mass check passes.
    piv = s.pivot(index="Player", columns="slot", values="own").fillna(0.0).reset_index()
    if "CPT" not in piv.columns:
        piv["CPT"] = 0.0
    if "FLEX" not in piv.columns:
        piv["FLEX"] = 0.0
    piv = piv.rename(columns={"CPT": "ACTUAL_CPT_OWN", "FLEX": "ACTUAL_FLEX_OWN"})
    piv["ACTUAL_TOTAL_OWN"] = piv["ACTUAL_CPT_OWN"] + piv["ACTUAL_FLEX_OWN"]
    piv["NORMALIZED_PLAYER"] = piv["Player"].map(normalize_name)
    piv = piv[["Player", "NORMALIZED_PLAYER", "ACTUAL_CPT_OWN", "ACTUAL_FLEX_OWN", "ACTUAL_TOTAL_OWN"]].sort_values(
        ["ACTUAL_TOTAL_OWN", "Player"], ascending=[False, True], kind="stable"
    ).reset_index(drop=True)
    cert = OwnershipCertification(certified, cpt_mass, flex_mass, cpt_err, flex_err, int(piv.shape[0]), dup, invalid, reason)
    return piv, cert


def _lineup_identity(indices: Sequence[int]) -> str:
    cpt = int(indices[0])
    flex = sorted(int(x) for x in indices[1:])
    return "CPT:" + str(cpt) + "|FLEX:" + ",".join(map(str, flex))


def _lineup_features(indices: Sequence[int], pool: pd.DataFrame) -> dict[str, Any]:
    idx = np.asarray(indices, dtype=np.int32)
    sal = pd.to_numeric(pool["SAL"], errors="coerce").to_numpy(float)
    teams = pool["TEAM"].astype(str).str.upper().to_numpy(object)
    pos = pool["POS"].map(base_position).to_numpy(object)
    team_total = pd.to_numeric(pool.get("TM Score", pd.Series(np.nan, index=pool.index)), errors="coerce").to_numpy(float)

    lineup_salary = int(round(1.5 * sal[idx[0]])) + int(np.sum(sal[idx[1:]]))
    left = SALARY_CAP - lineup_salary
    t = teams[idx]
    cpt_team = t[0]
    same = int(np.sum(t == cpt_team))
    max_team = max(same, SHOWDOWN_ROSTER_SIZE - same)
    p = pos[idx]

    tt = team_total[idx]
    fav_side_count = None
    cpt_fav = None
    if np.isfinite(tt).all():
        mx = float(np.max(tt))
        fav = tt >= mx - 1e-9
        fav_side_count = int(np.sum(fav))
        cpt_fav = bool(tt[0] >= mx - 1e-9)

    same_team_flex_pos = p[1:][t[1:] == cpt_team]
    opp_flex_pos = p[1:][t[1:] != cpt_team]
    return {
        "salary": lineup_salary,
        "salary_left": left,
        "max_team": max_team,
        "cpt_same_team_count": same,
        "cpt_position": str(p[0]),
        "qb_count": int(np.sum(p == "QB")),
        "rb_count": int(np.sum(p == "RB")),
        "dst_count": int(np.sum(p == "DST")),
        "k_count": int(np.sum(p == "K")),
        "fav_side_count": fav_side_count,
        "cpt_favorite_side": cpt_fav,
        "cpt_qb_same_team_passcatchers": int(np.sum(np.isin(same_team_flex_pos, ["WR", "TE"])) if p[0] == "QB" else 0),
        "cpt_wrte_same_team_qb": bool(np.any(same_team_flex_pos == "QB")) if p[0] in {"WR", "TE"} else False,
        "rb_dst_same_team_pair": bool(any(p[a] == "RB" and p[b] == "DST" and t[a] == t[b] for a in range(6) for b in range(a + 1, 6))),
        "k_dst_same_team_pair": bool(any(p[a] == "K" and p[b] == "DST" and t[a] == t[b] for a in range(6) for b in range(a + 1, 6))),
        "cpt_qb_opp_dst": bool(p[0] == "QB" and np.any((p[1:] == "DST") & (t[1:] != cpt_team))),
        "opp_flex_count": int(len(opp_flex_pos)),
    }


def _structural_targets(field: pd.DataFrame) -> dict[str, float]:
    if field.empty:
        return {}
    weights = pd.to_numeric(field.get("entry_count", pd.Series(1, index=field.index)), errors="coerce").fillna(0).to_numpy(float)
    if float(weights.sum()) <= 0:
        return {}
    mean = lambda mask: float(np.average(np.asarray(mask, dtype=bool).astype(float), weights=weights))
    out = {
        "SALARY_LEFT_LE_500": mean(field.salary_left <= 500),
        "SALARY_LEFT_LE_1000": mean(field.salary_left <= 1000),
        "SALARY_LEFT_1001_2500": mean((field.salary_left > 1000) & (field.salary_left <= 2500)),
        "SALARY_LEFT_GT_2500": mean(field.salary_left > 2500),
        "TEAM_SPLIT_3_3": mean(field.max_team == 3),
        "TEAM_SPLIT_4_2": mean(field.max_team == 4),
        "TEAM_SPLIT_5_1": mean(field.max_team == 5),
        "CPT_SAME_TEAM_3": mean(field.cpt_same_team_count == 3),
        "CPT_SAME_TEAM_4": mean(field.cpt_same_team_count == 4),
        "CPT_SAME_TEAM_5": mean(field.cpt_same_team_count == 5),
        "QB_COUNT_2": mean(field.qb_count == 2),
        "RB_COUNT_GE2": mean(field.rb_count >= 2),
        "DST_COUNT_GE1": mean(field.dst_count >= 1),
        "K_OR_DST_COUNT_GE2": mean((field.dst_count + field.k_count) >= 2),
        "CPT_QB": mean(field.cpt_position == "QB"),
        "CPT_RB": mean(field.cpt_position == "RB"),
        "CPT_WR_TE": mean(field.cpt_position.isin(["WR", "TE"])),
        "CPT_DST_K": mean(field.cpt_position.isin(["DST", "K"])),
        "CPT_QB_WITH_SAME_TEAM_PASSCATCHER_GE1": mean(field.cpt_qb_same_team_passcatchers >= 1),
        "CPT_QB_WITH_SAME_TEAM_PASSCATCHER_GE2": mean(field.cpt_qb_same_team_passcatchers >= 2),
        "CPT_WR_TE_WITH_SAME_TEAM_QB": mean(field.cpt_wrte_same_team_qb),
        "RB_DST_SAME_TEAM_PAIR": mean(field.rb_dst_same_team_pair),
        "K_DST_SAME_TEAM_PAIR": mean(field.k_dst_same_team_pair),
        "CPT_QB_OPP_DST": mean(field.cpt_qb_opp_dst),
    }
    if field.fav_side_count.notna().all() and field.cpt_favorite_side.notna().all():
        out.update({
            "CPT_FAVORITE_SIDE": mean(field.cpt_favorite_side),
            "FAVORITE_SIDE_5": mean(field.fav_side_count == 5),
            "FAVORITE_SIDE_4": mean(field.fav_side_count == 4),
            "FAVORITE_SIDE_3": mean(field.fav_side_count == 3),
        })
    return out


def certify_structural_field(standings: pd.DataFrame, pool: pd.DataFrame, ownership: pd.DataFrame) -> tuple[pd.DataFrame, StructuralCertification, dict[str, Any]]:
    required_pool = {"PLAYER", "TEAM", "POS", "SAL"}
    missing = required_pool - set(pool.columns)
    if missing:
        raise ValueError(f"HIST_FIELD_INGEST_POOL_STRUCTURAL_COLUMNS_MISSING:{sorted(missing)}")
    p = pool.reset_index(drop=True).copy()
    unique, ambiguous = _pool_alias_map(p)

    own_map = []
    unmapped_cpt = 0.0
    unmapped_flex = 0.0
    for _, r in ownership.iterrows():
        idx = _map_name(str(r["Player"]), unique, ambiguous)
        own_map.append(idx)
        if idx is None:
            unmapped_cpt += float(r["ACTUAL_CPT_OWN"])
            unmapped_flex += float(r["ACTUAL_FLEX_OWN"])
    own_total = len(ownership)
    own_mapped = sum(x is not None for x in own_map)

    if "Lineup" not in standings.columns:
        raise ValueError("HIST_FIELD_INGEST_STANDINGS_LINEUP_COLUMN_MISSING")
    entry_rows = standings.loc[standings["Lineup"].notna()].copy()
    # Lossless compaction: parse each unique lineup only once, carrying its exact
    # multiplicity into every structural target and duplication statistic.
    grouped = (entry_rows.groupby("Lineup", sort=False, dropna=False)
               .agg(entry_count=("Lineup", "size"), rank=("Rank", "min") if "Rank" in entry_rows.columns else ("Lineup", "size"),
                    points=("Points", "max") if "Points" in entry_rows.columns else ("Lineup", "size"))
               .reset_index())
    out_rows: list[dict[str, Any]] = []
    parseable = unparseable = mapped = unmapped = 0
    for _, r in grouped.iterrows():
        count = int(r["entry_count"])
        parsed = parse_lineup(r["Lineup"])
        if not parsed:
            unparseable += count
            continue
        parseable += count
        idxs: list[int] = []
        ok = True
        for _, name in parsed:
            idx = _map_name(name, unique, ambiguous)
            if idx is None:
                ok = False
                break
            idxs.append(int(idx))
        if not ok or len(set(idxs)) != 6:
            unmapped += count
            continue
        mapped += count
        feat = _lineup_features(idxs, p)
        out_rows.append({
            "lineup_identity": _lineup_identity(idxs),
            "entry_count": count,
            "rank": r.get("rank"),
            "points": r.get("points"),
            **feat,
        })

    field = pd.DataFrame(out_rows)
    certified = bool(
        len(entry_rows) > 0
        and parseable == len(entry_rows)
        and mapped == len(entry_rows)
        and own_mapped == own_total
    )
    if certified:
        reason = "PASS"
    else:
        reason = (
            f"ENTRY_ROWS={len(entry_rows)};PARSEABLE={parseable};UNPARSEABLE={unparseable};"
            f"MAPPED={mapped};UNMAPPED={unmapped};OWNERSHIP_PLAYERS_MAPPED={own_mapped}/{own_total}"
        )
    cert = StructuralCertification(
        certified=certified,
        entry_rows_total=int(len(entry_rows)),
        lineup_rows_parseable=int(parseable),
        lineup_rows_unparseable=int(unparseable),
        lineup_rows_fully_mapped=int(mapped),
        lineup_rows_unmapped=int(unmapped),
        ownership_players_total=int(own_total),
        ownership_players_mapped_to_pool=int(own_mapped),
        ownership_players_unmapped_to_pool=int(own_total - own_mapped),
        unmapped_ownership_cpt_mass=float(unmapped_cpt),
        unmapped_ownership_flex_mass=float(unmapped_flex),
        reason=reason,
    )
    targets = _structural_targets(field)
    duplicate = {}
    if not field.empty:
        counts = pd.to_numeric(field["entry_count"], errors="coerce").fillna(0).astype(int)
        mapped_entries = int(counts.sum())
        duplicate = {
            "MAPPED_FIELD_ENTRIES": mapped_entries,
            "UNIQUE_MAPPED_LINEUPS": int(len(field)),
            "MAX_DUPLICATES_ONE_LINEUP": int(counts.max()),
            "SINGLETON_LINEUPS": int((counts == 1).sum()),
            "ENTRIES_IN_DUPLICATED_LINEUPS": int(counts[counts > 1].sum()),
            "DUPLICATED_ENTRY_SHARE": float(counts[counts > 1].sum() / max(mapped_entries, 1)),
        }
    return field, cert, {"STRUCTURAL_TARGETS": targets, "DUPLICATION_PROFILE": duplicate}

def _atomic_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(path)


def _atomic_csv(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(tmp, index=False)
    tmp.replace(path)


def ingest_historical_field(
    *,
    standings_path: str | Path,
    pool_path: str | Path,
    contest_id: str,
    contest_date: str,
    output_dir: str | Path,
    entry_class: str = "UNKNOWN",
) -> dict[str, Any]:
    standings_path = Path(standings_path)
    pool_path = Path(pool_path)
    outdir = Path(output_dir)
    standings = pd.read_csv(standings_path, low_memory=False)
    pool = pd.read_csv(pool_path, low_memory=False)
    underlying_game_id = infer_underlying_game_id(pool, contest_date)

    ownership, own_cert = extract_ownership_ledger(standings)
    field, struct_cert, struct = certify_structural_field(standings, pool, ownership)

    # Attach frozen pool attributes when available; this is supplementary and never
    # required for ownership-summary certification.
    unique, ambiguous = _pool_alias_map(pool.reset_index(drop=True))
    attrs = []
    for _, r in ownership.iterrows():
        idx = _map_name(str(r["Player"]), unique, ambiguous)
        if idx is None:
            attrs.append({"POOL_MAPPED": False, "POOL_PLAYER": "", "TEAM": "", "POS": "", "SAL": np.nan, "TM_SCORE": np.nan})
        else:
            pr = pool.reset_index(drop=True).iloc[int(idx)]
            attrs.append({
                "POOL_MAPPED": True,
                "POOL_PLAYER": str(pr.get("PLAYER", "")),
                "TEAM": str(pr.get("TEAM", "")),
                "POS": base_position(pr.get("POS")),
                "SAL": pd.to_numeric(pd.Series([pr.get("SAL")]), errors="coerce").iloc[0],
                "TM_SCORE": pd.to_numeric(pd.Series([pr.get("TM Score")]), errors="coerce").iloc[0],
            })
    ownership = pd.concat([ownership.reset_index(drop=True), pd.DataFrame(attrs)], axis=1)

    base = f"contest_{contest_id}"
    own_path = outdir / f"{base}_ownership_ledger.csv"
    struct_path = outdir / f"{base}_structural_constraints.json"
    prov_path = outdir / f"{base}_provenance.json"
    partial_path = outdir / f"{base}_mapped_field_geometry.csv"

    _atomic_csv(own_path, ownership)
    _atomic_csv(partial_path, field)
    structural_payload = {
        "PATCH_ID": PATCH_ID,
        "SCHEMA_VERSION": SCHEMA_VERSION,
        "CONTEST_ID": str(contest_id),
        "CONTEST_DATE": str(contest_date)[:10],
        "UNDERLYING_GAME_ID": underlying_game_id,
        "ENTRY_CLASS": str(entry_class),
        "STRUCTURAL_FIELD_CERTIFIED": bool(struct_cert.certified),
        **struct,
    }
    _atomic_json(struct_path, structural_payload)

    provenance = {
        "PATCH_ID": PATCH_ID,
        "SCHEMA_VERSION": SCHEMA_VERSION,
        "CONTEST_ID": str(contest_id),
        "CONTEST_DATE": str(contest_date)[:10],
        "UNDERLYING_GAME_ID": underlying_game_id,
        "ENTRY_CLASS": str(entry_class),
        "STANDINGS_SHA256": sha256_file(standings_path),
        "POOL_SHA256": sha256_file(pool_path),
        "OWNERSHIP_SUMMARY_CERTIFICATION": asdict(own_cert),
        "STRUCTURAL_FIELD_CERTIFICATION": asdict(struct_cert),
        "OWNERSHIP_LEDGER_SHA256": sha256_file(own_path),
        "STRUCTURAL_CONSTRAINTS_SHA256": sha256_file(struct_path),
        "MAPPED_FIELD_GEOMETRY_SHA256": sha256_file(partial_path),
        "ELIGIBLE_AS_TRAINING_FOR_SAME_CONTEST": False,
        "ELIGIBLE_AS_TRAINING_FOR_SAME_UNDERLYING_GAME": False,
        "ELIGIBLE_ONLY_FOR_TARGET_DATE_AFTER": str(contest_date)[:10],
        "POSTLOCK_SOURCE": True,
        "FORWARD_INPUT_TO_SOURCE_CONTEST": False,
    }
    provenance["PROVENANCE_SHA256"] = _sha_json(provenance)
    _atomic_json(prov_path, provenance)
    return provenance


def update_registry(registry_path: str | Path, provenance_files: Iterable[str | Path]) -> dict[str, Any]:
    """Build a deterministic registry; sibling contest IDs collapse by game for gates."""
    entries = []
    for p in provenance_files:
        obj = json.loads(Path(p).read_text(encoding="utf-8"))
        entries.append({
            "contest_id": str(obj["CONTEST_ID"]),
            "contest_date": str(obj["CONTEST_DATE"]),
            "underlying_game_id": str(obj["UNDERLYING_GAME_ID"]),
            "ownership_summary_certified": bool(obj["OWNERSHIP_SUMMARY_CERTIFICATION"]["certified"]),
            "structural_field_certified": bool(obj["STRUCTURAL_FIELD_CERTIFICATION"]["certified"]),
            "provenance_sha256": str(obj["PROVENANCE_SHA256"]),
        })
    entries.sort(key=lambda x: (x["contest_date"], x["underlying_game_id"], x["contest_id"]))
    own_games = sorted({e["underlying_game_id"] for e in entries if e["ownership_summary_certified"]})
    struct_games = sorted({e["underlying_game_id"] for e in entries if e["structural_field_certified"]})
    reg = {
        "PATCH_ID": PATCH_ID,
        "SCHEMA_VERSION": SCHEMA_VERSION,
        "ENTRIES": entries,
        "CERTIFIED_OWNERSHIP_DISTINCT_GAMES": own_games,
        "CERTIFIED_OWNERSHIP_DISTINCT_GAME_COUNT": len(own_games),
        "CERTIFIED_STRUCTURAL_DISTINCT_GAMES": struct_games,
        "CERTIFIED_STRUCTURAL_DISTINCT_GAME_COUNT": len(struct_games),
        "SIBLING_CONTESTS_COUNT_ONCE_PER_UNDERLYING_GAME": True,
    }
    reg["REGISTRY_SHA256"] = _sha_json(reg)
    _atomic_json(Path(registry_path), reg)
    return reg


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--standings", required=True)
    ap.add_argument("--pool", required=True)
    ap.add_argument("--contest-id", required=True)
    ap.add_argument("--contest-date", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--entry-class", default="UNKNOWN")
    args = ap.parse_args()
    print(json.dumps(ingest_historical_field(
        standings_path=args.standings,
        pool_path=args.pool,
        contest_id=args.contest_id,
        contest_date=args.contest_date,
        output_dir=args.output_dir,
        entry_class=args.entry_class,
    ), indent=2, sort_keys=True))
