from __future__ import annotations

import argparse
import hashlib
import importlib.util
import itertools
import json
import math
import os
import sys
from dataclasses import dataclass
from pathlib import Path

_STATE_ROOT_FOR_IMPORTS = Path(__file__).resolve().parents[2]
if str(_STATE_ROOT_FOR_IMPORTS) not in sys.path:
    sys.path.insert(0, str(_STATE_ROOT_FOR_IMPORTS))
from typing import Any, Iterable, Sequence

import numpy as np
import pandas as pd
from engines.common.mandatory_prebuild_roster_gate_v1 import gate_receipt, require_prebuild_roster_check
from engines.nfl import nfl_showdown_frozen_calibration_hybrid_selector_v1 as hybrid_selector
from engines.common import right_neighborhood_door_selector_v1 as rn_door
from engines.common import apex_contest_derived_ownership_v1 as ownership_bridge
from engines.common import apex_global_contest_order_intelligence_v3 as global_order
from engines.common import apex_conditional_family_ordinal_head_v1 as exact_head
from engines.nfl import nfl_sd_mc_signal_hybrid_terminal_order_v1 as mc_signal_terminal
from engines.nfl import nfl_showdown_nflverse_prelock_role_v1 as nflverse_role
from engines.nfl import nfl_showdown_public_field_joint_model_v1 as joint_field_model
from engines.nfl import nfl_showdown_mc_reliability_ledger_v1 as mc_reliability_ledger
from engines.common import apex_football_multi_path_red_zone_intelligence_v1 as football_intel
from engines.common import apex_global_championship_head_policy_v1 as championship_head_policy
from engines.common import apex_entry_limit_game_theory_v1 as entry_limit_game


ENGINE_ID = "APEX_NFL_SHOWDOWN_RAW_POOL_RUNTIME_v1"
SPORT = "NFL"
MODE = "SHOWDOWN"
HANDOFF_PATCH_ID = "HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1"
DOCTRINE_ID = "NFL_SHOWDOWN_REGULAR_SEASON_ROLE_CORRELATION_CALIBRATION_v1"
POSITION_TEAM_CLOSURE_PATCH_ID = "NFL_SHOWDOWN_POSITION_TEAM_CLOSURE_NO_RETRUNCATION_v1"
OWNERSHIP_CONTRACT_PATCH_ID = "NFL_SHOWDOWN_INTERNAL_CPT_FLEX_OWNERSHIP_CONTRACT_v2"
GEOMETRY_BIRTH_PATCH_ID = "NFL_SHOWDOWN_GEOMETRY_ROLE_COMPLETION_BIRTH_v1"
RED_ZONE_INGESTION_PATCH_ID = "NFL_SHOWDOWN_PRELOCK_RED_ZONE_ROLE_INGESTION_v1"
NFLVERSE_PRELOCK_ROLE_PATCH_ID = nflverse_role.PATCH_ID
OWNERSHIP_ROUTE_INVARIANT_PATCH_ID = "APEX_NFL_SD_OWNERSHIP_ROUTE_INVARIANT_v1"
DEFENSIVE_WORLD_PATCH_ID = "NFL_SD_DEFENSIVE_LOW_SCORE_WORLD_PRESERVATION_v1"
DEFENSIVE_BALANCED_RESERVE_PATCH_ID = "NFL_SD_DEFENSIVE_BALANCED_3_3_DST_UTILITY_RESERVE_v1"
SUBTHRESHOLD_POSITIVE_ROLE_PATCH_ID = "NFL_SHOWDOWN_SUBTHRESHOLD_POSITIVE_ROLE_HIGH_UNCERTAINTY_TAIL_v1"
TOP5_PARLAY_POLICY_ID = championship_head_policy.PATCH_ID
CONTEST_CLASS_PORTFOLIO_PATCH_ID = "NFL_SD_CONTEST_CLASS_MARGINAL_WORLD_COVERAGE_v1"
PORTFOLIO_VECTOR_SELECTOR_PATCH_ID = "NFL_SD_150MAX_VECTOR_PORTFOLIO_SELECT_v1"
SINGLE_ENTRY_CHAMPIONSHIP_HEAD_PATCH_ID = "NFL_SD_SINGLE_ENTRY_TOP01_GLOBAL_ORDER_HEAD_v1"
EXTREME_SCRIPT_CLOSURE_PATCH_ID = "NFL_SD_EXTREME_SPLIT_K_DST_LOCAL_CLOSURE_v1"
PROJECTION_PRESERVING_SHRINKAGE_PATCH_ID = "NFL_SD_REGULAR_SEASON_PROJECTION_PRESERVING_SHRINKAGE_v1"
ORDINAL_WORLD_POSTERIOR_PATCH_ID = "NFL_SD_CROSS_WORLD_ORDINAL_POSTERIOR_v1"
GLOBAL_MC_SIGNAL_DOCTRINE_PATCH_ID = "APEX_GLOBAL_MC_METRICS_SIGNAL_NOT_TRUTH_v1"
MC_SIGNAL_TERMINAL_ORDER_PATCH_ID = mc_signal_terminal.PATCH_ID
CROSS_WORLD_CORE4_HANDOFF_PATCH_ID = "NFL_SD_CROSS_WORLD_CORE4_SIGNAL_HANDOFF_v1"
TERMINAL_FAMILY_CONSENSUS_ORDER_PATCH_ID = "NFL_SD_STABLE_TAIL_FAMILY_CONSENSUS_ORDER_v2"
FOOTBALL_MULTI_PATH_RED_ZONE_PATCH_ID = football_intel.PATCH_ID
TD_EVENT_TAIL_PATCH_ID = "NFL_SHOWDOWN_PRELOCK_TD_EVENT_TAIL_v1"
CAPTAIN_SIBLING_HEAD_PATCH_ID = "NFL_SD_CHAMPIONSHIP_FAMILY_CPT_SIBLING_HEAD_v2"
ONE_MUTATION_HEAD_PATCH_ID = "NFL_SD_CHAMPIONSHIP_FAMILY_ONE_MUTATION_HEAD_v2"
TWO_LANE_HEAD_PATCH_ID = "NFL_SD_CHAMPIONSHIP_FAMILY_TWO_LANE_HEAD_v1"
TOP0050_HEAD_PATCH_ID = "NFL_SD_CHAMPIONSHIP_TOP0050_HEAD_v1"
TWO_FAMILY_HEAD_PATCH_ID = "NFL_SD_TWO_FAMILY_CHAMPIONSHIP_HEAD_v1"
EXTREME_CPT_COMPLETION_PATCH_ID = "NFL_SD_EXTREME_TAIL_CPT_CORE5_COMPLETION_v1"
TD_EVENT_DOMINANT_ONSLAUGHT_RESERVE_PATCH_ID = "NFL_SD_TD_EVENT_DOMINANT_ONSLAUGHT_RESERVE_v1"
PHASE2_CHAMPIONSHIP_COMMON_WORLD_RESERVE_PATCH_ID = "NFL_SD_PHASE2_CHAMPIONSHIP_COMMON_WORLD_RESERVE_v1"
PHASE2_CALIBRATION_QUALIFIED_STREAM_PATCH_ID = "NFL_SD_PHASE2_CALIBRATION_QUALIFIED_STREAM_v1"
MC_LATENT_VARIANCE_NORMALIZATION_PATCH_ID = "NFL_SD_MC_LATENT_VARIANCE_NORMALIZATION_v1"
PUBLIC_FIELD_UNIVERSE_DECOUPLING_PATCH_ID = "NFL_SD_PUBLIC_FIELD_UNIVERSE_DECOUPLING_v1"
PUBLIC_FIELD_JOINT_DEPENDENCE_PATCH_ID = joint_field_model.PATCH_ID
TEAM_EVENT_NATIVE_WORLD_PATCH_ID = "NFL_SD_TEAM_EVENT_NATIVE_WORLD_v1"
MC_RELIABILITY_LEDGER_PATCH_ID = mc_reliability_ledger.PATCH_ID
SALARY_MAX = 50_000
SALARY_MIN = 40_000
ROSTER_SIZE = 6
MAX_TEAM = 5

ROOT = Path(__file__).resolve().parents[2]
_STRATEGY_PATH = ROOT / "engines" / "common" / "apex_global_sports_strategy_layer_v1.py"
_spec = importlib.util.spec_from_file_location("apex_global_sports_strategy_layer_v1_nfl", _STRATEGY_PATH)
if _spec is None or _spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_SPORTS_STRATEGY_LAYER_UNAVAILABLE")
strategy_mod = importlib.util.module_from_spec(_spec)
sys.modules.setdefault(_spec.name, strategy_mod)
_spec.loader.exec_module(strategy_mod)


def _stable_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def _array_hash(a: np.ndarray) -> str:
    x = np.ascontiguousarray(a)
    return hashlib.sha256(x.view(np.uint8)).hexdigest()


def _pct(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    n = values.size
    if n == 0:
        return np.asarray([], dtype=np.float64)
    order = np.argsort(values, kind="stable")
    out = np.empty(n, dtype=np.float64)
    sorted_v = values[order]
    i = 0
    while i < n:
        j = i + 1
        while j < n and sorted_v[j] == sorted_v[i]:
            j += 1
        out[order[i:j]] = ((i + j - 1) / 2.0 + 0.5) / n
        i = j
    return out



def _capped_normalize(weights: np.ndarray, target: float, cap: float, floor: float = 0.0005) -> np.ndarray:
    """Deterministically normalize weights to an exact mass with per-player floor/cap."""
    w = np.maximum(np.asarray(weights, dtype=np.float64), 0.0).copy()
    n = len(w)
    min_mass = n * float(floor)
    if n == 0 or target < min_mass - 1e-9 or target > n * cap + 1e-9:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_OWNERSHIP_NORMALIZATION_INFEASIBLE")
    out = np.full(n, float(floor), dtype=np.float64)
    free = np.ones(n, dtype=bool)
    remaining = float(target) - min_mass
    capacity = float(cap) - float(floor)
    for _ in range(n + 2):
        idx = np.flatnonzero(free)
        if not len(idx) or remaining <= 1e-14:
            break
        base = np.maximum(w[idx], 1e-12)
        vals = base * (remaining / max(base.sum(), 1e-12))
        hit = vals >= capacity
        if not np.any(hit):
            out[idx] += vals
            remaining = 0.0
            break
        hit_idx = idx[hit]
        out[hit_idx] = cap
        free[hit_idx] = False
        remaining -= capacity * len(hit_idx)
    if remaining > 1e-8:
        idx = np.flatnonzero(free)
        if not len(idx):
            raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_OWNERSHIP_NORMALIZATION_EXHAUSTED")
        out[idx] += remaining / len(idx)
    diff = float(target) - float(out.sum())
    if abs(diff) > 1e-10:
        idx = np.flatnonzero((out > floor + 1e-9) & (out < cap - 1e-9))
        if not len(idx):
            idx = np.flatnonzero(out < cap - 1e-9)
        if not len(idx):
            raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_OWNERSHIP_MASS_CORRECTION_FAILED")
        out[idx[np.argmax(out[idx])]] += diff
    if abs(float(out.sum()) - float(target)) > 2e-7:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_OWNERSHIP_MASS_PARITY_FAILED")
    return out.astype(np.float32)


def _bounded_normalize(weights: np.ndarray, target: float, upper: np.ndarray, floor: float = 0.0) -> np.ndarray:
    """Normalize to target with player-specific upper bounds (used for CPT <= total inclusion)."""
    w=np.maximum(np.asarray(weights,dtype=np.float64),0.0)
    upper=np.maximum(np.asarray(upper,dtype=np.float64),float(floor))
    n=len(w)
    if len(upper)!=n or n==0 or target < n*floor-1e-9 or target > float(upper.sum())+1e-9:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_BOUNDED_OWNERSHIP_INFEASIBLE")
    out=np.full(n,float(floor),dtype=np.float64)
    remaining=float(target)-float(out.sum())
    free=np.ones(n,dtype=bool)
    for _ in range(n+3):
        idx=np.flatnonzero(free)
        if remaining<=1e-12: break
        if not len(idx): raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_BOUNDED_OWNERSHIP_EXHAUSTED")
        base=np.maximum(w[idx],1e-12); add=base*(remaining/base.sum()); room=upper[idx]-out[idx]
        hit=add>=room-1e-15
        if not np.any(hit): out[idx]+=add; remaining=0.0; break
        hidx=idx[hit]; consumed=float(room[hit].sum()); out[hidx]=upper[hidx]; free[hidx]=False; remaining-=consumed
    if remaining>1e-8:
        idx=np.flatnonzero(free)
        if not len(idx): raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_BOUNDED_OWNERSHIP_REMAINDER")
        room=upper[idx]-out[idx]
        if float(room.sum()) < remaining-1e-8: raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_BOUNDED_OWNERSHIP_CAPACITY")
        add=np.minimum(room,remaining/len(idx)); out[idx]+=add; remaining=float(target)-float(out.sum())
        if remaining>1e-8:
            for j in idx:
                d=min(float(upper[j]-out[j]),remaining); out[j]+=d; remaining-=d
                if remaining<=1e-10: break
    diff=float(target)-float(out.sum())
    if abs(diff)>1e-9:
        idx=np.flatnonzero((out>floor+1e-12)&(out<upper-1e-12))
        if not len(idx): idx=np.flatnonzero(out<upper-1e-12)
        if not len(idx): raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_BOUNDED_OWNERSHIP_CORRECTION")
        out[idx[0]]+=diff
    if np.any(out>upper+2e-7) or abs(float(out.sum())-float(target))>2e-7:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_BOUNDED_OWNERSHIP_PARITY")
    return out.astype(np.float32)


def _role_consistent_ownership_contract(df: pd.DataFrame, p99: np.ndarray, strategy: Any) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Repair Showdown roster ownership only when the uploaded vector violates slot-mass/role consistency.

    RST% remains a prior.  Post-lock ownership is never used.  When the six-slot inclusion
    mass is materially invalid, a generic role-capacity prior is blended in and the result
    is capped/normalized to exactly six expected roster slots.  Captain ownership is then
    derived separately from repaired roster ownership plus frozen Phase-1 tail/opportunity.
    """
    prior_col = "RW_RST_PRIOR" if "RW_RST_PRIOR" in df.columns else ("PROVIDER_RST_RAW" if "PROVIDER_RST_RAW" in df.columns else "RST%")
    raw = np.maximum(0.0, pd.to_numeric(df[prior_col],errors="coerce").fillna(0.0).to_numpy(np.float64)) / 100.0
    pos = df["POS_BASE"].astype(str).to_numpy(object)
    status = df["ROLE_STATUS"].astype(str).to_numpy(object)
    snap = df["SNAPS"].to_numpy(np.float64) / 100.0
    route = df["ROUTES"].to_numpy(np.float64) / 100.0
    target = df["TARGETS"].to_numpy(np.float64) / 20.0
    carry = df["CARRIES"].to_numpy(np.float64) / 25.0

    cap = np.zeros(len(df), dtype=np.float64)
    qb = pos == "QB"; rb = pos == "RB"; pc = np.isin(pos, ["WR", "TE"]); k = pos == "K"; dst = pos == "DST"
    cap[qb] = snap[qb]
    cap[rb] = 0.45 * snap[rb] + 0.42 * carry[rb] + 0.13 * target[rb]
    cap[pc] = 0.35 * snap[pc] + 0.40 * route[pc] + 0.25 * target[pc]
    cap[k | dst] = 1.0
    other = ~(qb | rb | pc | k | dst)
    cap[other] = np.maximum.reduce((snap[other], route[other], target[other], carry[other])) if np.any(other) else np.asarray([], dtype=float)
    cap = np.clip(cap, 0.0, 1.0)

    active = ~np.isin(status, ["OUT", "IR", "DNP", "REST", "CONFIRMED_OUT"])
    material = active & (((qb | rb | pc) & (cap >= 0.10)) | k | dst)
    zero_material = material & (raw <= 0.0025)
    # A large raw prior attached to a materially reduced role is also inconsistent.
    # This is a generic pre-lock role-capacity check; no player/team identities are used.
    high_raw_low_role = active & (raw >= 0.15) & (((qb) & (cap < 0.25)) | ((rb | pc) & (cap < 0.12)))
    raw_mass = float(raw.sum())
    mass_error = abs(raw_mass - float(ROSTER_SIZE)) / float(ROSTER_SIZE)
    repair_required = bool(mass_error > 0.10 or np.any(zero_material) or np.any(high_raw_low_role))

    # Position-aware, result-blind regular-season role-capacity prior used only to repair malformed ownership mass.
    # Skill weights remain current-role proportional. No player/team constants.
    role_prior = np.full(len(df), 0.01, dtype=np.float64)
    role_prior[qb] = 1.40 * np.maximum(cap[qb], 0.02)
    role_prior[rb] = 0.55 * np.maximum(cap[rb], 0.02)
    role_prior[pc] = 0.55 * np.maximum(cap[pc], 0.02)
    role_prior[k] = 0.75
    role_prior[dst] = 0.75
    role_prior[~active] = 0.0005
    tail = _pct(np.asarray(p99, dtype=np.float64))
    opp = np.asarray(strategy.opportunity_score, dtype=np.float64)
    opp = np.clip(opp, 0.0, None)
    if len(opp) and float(opp.max()) > 0:
        opp = opp / float(opp.max())
    # Internal field model is always authoritative. Provider RST contributes only a
    # reliability-damped prior and can never become the final vector by itself.
    internal_weight = role_prior * (0.72 + 0.42 * tail) * (0.78 + 0.22 * opp)
    internal_norm = _capped_normalize(internal_weight, float(ROSTER_SIZE), 0.98)
    reliability = np.ones(len(df), dtype=np.float64)
    reliability[qb] = np.clip(cap[qb] / 0.45, 0.03, 1.0) ** 2
    reliability[rb | pc] = np.clip(cap[rb | pc] / 0.30, 0.05, 1.0) ** 2
    reliability[~active] = 0.01
    raw_reliable = raw * reliability
    if float(raw_reliable.sum()) > 1e-12:
        provider_norm = _capped_normalize(np.maximum(raw_reliable,0.0005), float(ROSTER_SIZE), 0.98)
    else:
        provider_norm = internal_norm.copy()
    conflict = 1.0 if (np.any(zero_material) or np.any(high_raw_low_role)) else 0.0
    provider_weight = float(np.clip(0.50 * (1.0 - min(1.0,mass_error)) - 0.15 * conflict, 0.15, 0.50))
    blended = provider_weight * provider_norm.astype(np.float64) + (1.0-provider_weight) * internal_norm.astype(np.float64)
    roster = _capped_normalize(blended, float(ROSTER_SIZE), 0.98)
    mode = "INTERNAL_ROLE_TAIL_OPPORTUNITY_AUTHORITY_PLUS_RELIABILITY_DAMPED_PROVIDER_PRIOR"

    cpt_weight = roster.astype(np.float64) * (0.55 + 0.75 * tail) * (0.75 + 0.25 * opp)
    captain = _bounded_normalize(cpt_weight, 1.0, roster.astype(np.float64), floor=0.0)
    flex = (roster.astype(np.float64) - captain.astype(np.float64)).astype(np.float32)
    if np.any(flex < -2e-7) or abs(float(flex.sum())-5.0)>2e-6:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_FLEX_OWNERSHIP_MASS_PARITY_FAILED")
    receipt = {
        "PATCH_ID": OWNERSHIP_CONTRACT_PATCH_ID,
        "ROUTE_INVARIANT_PATCH_ID": OWNERSHIP_ROUTE_INVARIANT_PATCH_ID,
        "PROVIDER_PRIOR_COLUMN": prior_col,
        "PROVIDER_PRIOR_AUTHORITY": False,
        "RAW_RST_MASS": raw_mass,
        "TARGET_ROSTER_MASS": float(ROSTER_SIZE),
        "RAW_RST_MASS_ERROR_FRACTION": float(mass_error),
        "ROLE_CONSISTENCY_ZERO_MATERIAL_COUNT": int(np.count_nonzero(zero_material)),
        "ROLE_CONSISTENCY_ZERO_MATERIAL_PLAYERS": df.loc[zero_material, "PLAYER"].astype(str).tolist(),
        "ROLE_CONSISTENCY_HIGH_RAW_LOW_ROLE_COUNT": int(np.count_nonzero(high_raw_low_role)),
        "ROLE_CONSISTENCY_HIGH_RAW_LOW_ROLE_PLAYERS": df.loc[high_raw_low_role, "PLAYER"].astype(str).tolist(),
        "RELIABILITY_DAMPED_RAW_MASS": float(raw_reliable.sum()),
        "REPAIR_REQUIRED": repair_required,
        "ADJUSTMENT_MODE": mode,
        "NORMALIZED_ROSTER_MASS": float(np.asarray(roster, dtype=np.float64).sum()),
        "NORMALIZED_CAPTAIN_MASS": float(np.asarray(captain, dtype=np.float64).sum()),
        "NORMALIZED_FLEX_MASS": float(np.asarray(flex, dtype=np.float64).sum()),
        "PROVIDER_PRIOR_BLEND_WEIGHT": provider_weight,
        "RAW_POSTLOCK_OWNERSHIP_USED": False,
        "CAPTAIN_FLEX_SEMANTICS": "SEPARATE_CAPTAIN_MASS_1_PLUS_ROSTER_INCLUSION_MASS_6",
        "ROSTER_OWNERSHIP_HASH": _array_hash(roster),
        "CAPTAIN_OWNERSHIP_HASH": _array_hash(captain),
        "FLEX_OWNERSHIP_HASH": _array_hash(flex),
        "DEFENSIVE_WORLD_PATCH_ID": DEFENSIVE_WORLD_PATCH_ID,
        "DST_CPT_HARD_PRUNE": False,
        "DUAL_DST_HARD_PRUNE": False,
        "FORCED_DEFENSE_EXPOSURE": False,
    }
    return roster, captain, flex, receipt


def _wilson(success: np.ndarray, trials: np.ndarray | int, z: float = 1.96) -> tuple[np.ndarray, np.ndarray]:
    s = np.asarray(success, dtype=np.float64)
    n = np.asarray(trials, dtype=np.float64)
    p = np.divide(s, n, out=np.zeros_like(s), where=n > 0)
    den = 1.0 + z * z / n
    center = (p + z * z / (2.0 * n)) / den
    half = z * np.sqrt(np.maximum(0.0, p * (1.0 - p) / n + z * z / (4.0 * n * n))) / den
    return np.maximum(0.0, center - half), np.minimum(1.0, center + half)


def _pos_base(raw: str) -> str:
    return str(raw).split("/")[0].strip().upper()


@dataclass(frozen=True)
class Config:
    field_size: int
    seed: int
    player_trials: int = 50_000
    base_trials: int = 10_000
    extra_batch_trials: int = 10_000
    max_trials: int = 50_000
    phase2_keep: int = 20_000
    base_global_keep: int = 14_000
    family_keep: int = 70
    closure_keep_per_macro: int = 30
    closure_macro_count: int = 64
    phase2_min_keep: int = 20_000
    phase2_global_lane_keep: int = 10_000
    phase2_common_world_trials: int = 512
    phase2_common_world_primary_rank: int = 600
    phase2_common_world_secondary_rank: int = 100
    phase2_common_world_chunk: int = 2_048
    cpt_pool_size: int = 22
    flex_pool_size: int = 19
    regular_season_pass_catcher_team_keep: int = 4
    regular_season_rb_team_keep: int = 3
    selector_primary_tie_width: float = 0.001
    bubble_cap: int = 96
    board_size: int = 10
    player_exposure_cap: int = 7
    captain_exposure_cap: int = 2
    script_exposure_cap: int = 5
    test_mode: bool = False

    def validate(self) -> None:
        if self.field_size <= 0:
            raise RuntimeError("RUN_INVALID:INVALID_FIELD_SIZE")
        if not self.test_mode and self.base_trials < 10_000:
            raise RuntimeError("ENGINE_INTEGRITY_HALT:BASE_SIM_TRIALS_LT_10000")
        if self.max_trials < self.base_trials or self.extra_batch_trials <= 0:
            raise RuntimeError("RUN_INVALID:INVALID_ADAPTIVE_SIM_CONFIG")


@dataclass
class Calibration:
    frame: pd.DataFrame
    ids: np.ndarray
    pos: np.ndarray
    team: np.ndarray
    salary: np.ndarray
    role_snap: np.ndarray
    role_routes: np.ndarray
    role_targets: np.ndarray
    role_carries: np.ndarray
    role_uncertainty: np.ndarray
    strategy: Any
    mu: np.ndarray
    sigma: np.ndarray
    p95: np.ndarray
    p99: np.ndarray
    ownership: np.ndarray
    captain_ownership: np.ndarray
    flex_ownership: np.ndarray
    ownership_receipt: dict[str, Any]
    correlation: np.ndarray
    covariance: np.ndarray
    phase1_hash: str
    shared_metric_bundle_id: str
    prediction_hash: str
    role_evidence_hash: str
    market_evidence_hash: str
    role_evidence_payload: dict[str, Any]
    market_evidence_payload: dict[str, Any]
    out_names: list[str]
    zero_role_names: list[str]
    player_sim_matrix_hash: str


def _load_json(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        raise RuntimeError(f"RUN_INVALID:EVIDENCE_FILE_MISSING:{p}")
    return json.loads(p.read_text(encoding="utf-8"))


HARD_ROLE_STATUSES = {"OUT", "IR", "DNP", "REST", "CONFIRMED_OUT", "DOUBTFUL"}
UNCERTAIN_REGULAR_SEASON_STATUSES = {"QUESTIONABLE", "DOUBTFUL", "DNP", "ACTIVE_UNCERTAIN", "UNKNOWN", "UNCONFIRMED"}


def _production_role_eligibility(name: str, pos: str, ev: dict[str, Any]) -> tuple[bool, str]:
    """Regular-season role gate using current, source-backed opportunity evidence.

    Final hard exclusions come from the prebuild roster/inactive gate. Injury designations such
    as QUESTIONABLE/DOUBTFUL/DNP increase uncertainty but do not erase a player who still has
    positive current role evidence. Live production never invents regular-season-style rotation priors.
    """
    if pos in {"K", "DST"}:
        return True, "TEAM_OR_SPECIALIST_UNIT"
    if not ev:
        return False, "ROLE_EVIDENCE_MISSING"
    if not str(ev.get("source_ref") or "").strip():
        return False, "ROLE_SOURCE_MISSING"
    st = str(ev.get("status", "UNCONFIRMED")).strip().upper()
    if st in {"OUT", "IR", "CONFIRMED_OUT"}:
        return False, f"STATUS_{st}"
    ss = float(ev.get("snap_share", 0.0) or 0.0)
    rr = float(ev.get("route_share", 0.0) or 0.0)
    tt = float(ev.get("target_share", 0.0) or 0.0)
    cc = float(ev.get("carry_share", 0.0) or 0.0)
    if pos == "QB": meaningful = ss >= 0.20
    elif pos == "RB": meaningful = ss >= 0.15 or cc >= 0.10 or tt >= 0.05
    elif pos in {"WR", "TE"}: meaningful = ss >= 0.15 or rr >= 0.15 or tt >= 0.05
    else: meaningful = max(ss, rr, tt, cc) > 0.0
    if not meaningful:
        positive_role = max(ss, rr, tt, cc) > 0.0
        if positive_role and st in {"ACTIVE", "AVAILABLE", "ACTIVATED", "PROMOTED", "RETURNED", "REINSTATED", "QUESTIONABLE"}:
            return True, "SUBTHRESHOLD_POSITIVE_ROLE_RETAINED"
        return False, "NO_MEANINGFUL_ROLE_EVIDENCE"
    return True, "VERIFIED_CURRENT_ROLE"

def _reconcile_role_evidence_with_availability(role_evidence: dict[str, Any], roster_gate: Any) -> dict[str, Any]:
    payload = json.loads(json.dumps(role_evidence))
    players = payload.get("players", {})
    if not isinstance(players, dict):
        raise RuntimeError("RUN_INVALID:ROLE_EVIDENCE_PLAYERS_INVALID")
    gate_out = set(roster_gate.out_players)
    latest_status = dict(getattr(roster_gate, "nfl_latest_status_by_player", {}) or {})
    unresolved_status = set(getattr(roster_gate, "nfl_unresolved_hard_out_candidates", ()) or ())
    forced_active_uncertain: list[str] = []
    forced_out: list[str] = []
    status_uncertain: list[str] = []
    status_confirmed: list[str] = []
    for name, raw in list(players.items()):
        ev = raw if isinstance(raw, dict) else {}
        st = str(ev.get("status", "ACTIVE")).strip().upper()
        if st in {"OUT", "IR", "CONFIRMED_OUT"} and name not in gate_out:
            ev["status"] = "ACTIVE_UNCERTAIN"
            ev["role_uncertainty"] = max(float(ev.get("role_uncertainty", 0.0) or 0.0), 0.70)
            ev["AVAILABILITY_RECONCILED"] = "STALE_OR_UNPROVEN_ROLE_OUT_RELEASED"
            players[name] = ev
            forced_active_uncertain.append(name)
    for name, latest in latest_status.items():
        ev = players.get(name, {})
        if not isinstance(ev, dict): ev = {}
        st = str(latest).strip().upper()
        if st in {"OUT", "IR", "CONFIRMED_OUT"}:
            ev["status"] = st
            ev["availability_confirmed"] = False
            ev["AVAILABILITY_RECONCILED"] = f"LATEST_OFFICIAL_STATUS_{st}"
            players[name] = ev
        elif st in UNCERTAIN_REGULAR_SEASON_STATUSES:
            ev["status"] = st
            ev["availability_confirmed"] = None
            ev["role_uncertainty"] = max(float(ev.get("role_uncertainty", 0.25) or 0.25), 0.45 if st == "QUESTIONABLE" else 0.60)
            ev["AVAILABILITY_RECONCILED"] = f"LATEST_OFFICIAL_STATUS_{st}_UNCERTAINTY_ONLY"
            players[name] = ev
            status_uncertain.append(name)
        elif st in {"ACTIVE", "AVAILABLE", "ACTIVATED", "REINSTATED", "PROMOTED", "RETURNED"}:
            ev["availability_confirmed"] = True
            ev["AVAILABILITY_RECONCILED"] = f"LATEST_OFFICIAL_STATUS_{st}"
            players[name] = ev
            status_confirmed.append(name)
    for name in sorted(unresolved_status - set(latest_status)):
        ev = players.get(name, {})
        if not isinstance(ev, dict): ev = {}
        ev["status"] = "UNCONFIRMED"
        ev["availability_confirmed"] = None
        ev["role_uncertainty"] = max(float(ev.get("role_uncertainty", 0.25) or 0.25), 0.70)
        ev["AVAILABILITY_RECONCILED"] = "UNRESOLVED_OFFICIAL_STATUS_UNCERTAINTY_ONLY"
        players[name] = ev
        status_uncertain.append(name)
    for name in sorted(gate_out):
        ev = players.get(name, {})
        if not isinstance(ev, dict): ev = {}
        forced_out.append(name)
        ev.update({
            "status": "OUT", "snap_share": 0.0, "route_share": 0.0,
            "target_share": 0.0, "carry_share": 0.0,
            "role_uncertainty": min(float(ev.get("role_uncertainty", 0.02) or 0.02), 0.05),
            "AVAILABILITY_RECONCILED": "GATE_VERIFIED_HARD_OUT",
        })
        players[name] = ev
    payload["players"] = players
    payload["availability_reconciliation"] = {
        "PATCH_ID": "NFL_REGULAR_SEASON_CURRENT_ROLE_AVAILABILITY_v1",
        "SEASON_STAGE": "REGULAR_SEASON",
        "ROLE_EVIDENCE_FORCED_ACTIVE_UNCERTAIN": sorted(forced_active_uncertain),
        "ROLE_EVIDENCE_FORCED_OUT": sorted(forced_out),
        "GATE_OUT_PLAYERS": sorted(gate_out),
        "UNRESOLVED_HARD_OUT_CANDIDATES": sorted(unresolved_status),
        "LATEST_STATUS_BY_PLAYER": latest_status,
        "CURRENT_STATUS_UNCERTAIN": sorted(set(status_uncertain)),
        "CURRENT_STATUS_CONFIRMED_AVAILABLE": sorted(set(status_confirmed)),
        "POSTLOCK_RESULTS_USED": False,
        "PLAYER_NAME_FORWARD_LOGIC": False,
    }
    return payload

def _synthetic_test_default_role(pos: str) -> tuple[float, float, float, float, float]:
    """Test-fixture priors only; never used by live production."""
    if pos == "QB": return 0.70, 0.00, 0.00, 0.04, 0.30
    if pos == "RB": return 0.50, 0.18, 0.12, 0.34, 0.25
    if pos == "WR": return 0.62, 0.56, 0.24, 0.01, 0.25
    if pos == "TE": return 0.58, 0.45, 0.18, 0.01, 0.25
    if pos == "K": return 1.00, 0.00, 0.00, 0.00, 0.08
    if pos == "DST": return 1.00, 0.00, 0.00, 0.00, 0.12
    return 0.0, 0.0, 0.0, 0.0, 0.85

def _prepare_frame(pool: str | Path, role_evidence: dict[str, Any], market_evidence: dict[str, Any], allow_synthetic_role_priors: bool = False) -> tuple[pd.DataFrame, list[str], list[str]]:
    # Direct player-file execution begins from the raw CSV. Ownership authority is
    # established in _load_calibration only after hard OUT/role purge so the active
    # six-slot field closes to exactly 600% without any external preprocessing step.
    df = pd.read_csv(pool)
    required = {"PLAYER", "POS", "TEAM", "SAL", "FPTS", "Ceil", "Floor", "RST%"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise RuntimeError("RUN_INVALID:NFL_POOL_FIELDS_MISSING:" + ",".join(missing))
    if df.empty or df["PLAYER"].astype(str).duplicated().any():
        raise RuntimeError("RUN_INVALID:NFL_POOL_EMPTY_OR_DUPLICATE_PLAYER")
    df = df.copy()
    df["POS_BASE"] = df["POS"].map(_pos_base)
    players = role_evidence.get("players", {})
    if not isinstance(players, dict):
        raise RuntimeError("RUN_INVALID:ROLE_EVIDENCE_PLAYERS_INVALID")

    status = []
    snap, routes, targets, carries, role_unc = [], [], [], [], []
    out_names, zero_role = [], []
    role_gate_reason = []
    for _, row in df.iterrows():
        name = str(row["PLAYER"])
        pos = str(row["POS_BASE"])
        base = _synthetic_test_default_role(pos)
        ev = players.get(name, {}) or {}
        eligible, reason = (True, "SYNTHETIC_TEST_MODE") if allow_synthetic_role_priors else _production_role_eligibility(name, pos, ev)
        role_gate_reason.append(reason)
        if not allow_synthetic_role_priors and not eligible:
            raw_status = str(ev.get("status", "UNCONFIRMED")).strip().upper()
            if raw_status in HARD_ROLE_STATUSES:
                st = raw_status; s = r = t = c = 0.0; u = 0.05; out_names.append(name)
            else:
                st = "ROLE_UNVERIFIED"; s = r = t = c = 0.0; u = 0.85
        else:
            st = str(ev.get("status", "ACTIVE")).strip().upper()
            if allow_synthetic_role_priors:
                s = float(ev.get("snap_share", base[0])); r = float(ev.get("route_share", base[1]))
                t = float(ev.get("target_share", base[2])); c = float(ev.get("carry_share", base[3])); u = float(ev.get("role_uncertainty", base[4]))
            else:
                s = float(ev.get("snap_share", 0.0) or 0.0); r = float(ev.get("route_share", 0.0) or 0.0)
                t = float(ev.get("target_share", 0.0) or 0.0); c = float(ev.get("carry_share", 0.0) or 0.0); u = float(ev.get("role_uncertainty", 0.25) or 0.25)
                if reason == "SUBTHRESHOLD_POSITIVE_ROLE_RETAINED":
                    u = max(u, 0.65)
            if st in HARD_ROLE_STATUSES:
                s = r = t = c = 0.0; out_names.append(name)
            elif st == "EXPECTED_REST":
                s *= 0.25; r *= 0.25; t *= 0.25; c *= 0.25; u = max(u, 0.50)
        if max(s, r, t, c) <= 0.0 and pos not in {"K", "DST"}: zero_role.append(name)
        status.append(st)
        snap.append(np.clip(s, 0.0, 1.0)); routes.append(np.clip(r, 0.0, 1.0)); targets.append(max(0.0, t)); carries.append(max(0.0, c)); role_unc.append(np.clip(u, 0.02, 0.85))
    df["ROLE_STATUS"] = status
    df["SNAPS"] = np.asarray(snap) * 100.0
    df["ROUTES"] = np.asarray(routes) * 100.0
    df["TARGETS"] = np.asarray(targets) * 20.0
    df["CARRIES"] = np.asarray(carries) * 25.0
    df["ROLE_UNCERTAINTY"] = role_unc
    df["ROLE_GATE_REASON"] = role_gate_reason

    # Optional explicit pre-lock red-zone role evidence travels with the same
    # player-keyed role payload.  Missing fields remain absent/zero and are never
    # backfilled from realized touchdowns or post-lock results.
    rz_key_map = {
        "RZ Targets": ("rz_targets", "red_zone_targets"),
        "RZ Rush Att": ("rz_rush_attempts", "red_zone_rush_attempts"),
        "Inside10 Targets": ("inside10_targets", "rz10_targets"),
        "Inside10 Rush Att": ("inside10_rush_attempts", "rz10_rush_attempts"),
        "Inside5 Rush Att": ("inside5_rush_attempts", "rz5_rush_attempts", "goal_line_carries"),
        "End Zone Targets": ("end_zone_targets", "endzone_targets"),
        "RZ Target Share": ("rz_target_share", "red_zone_target_share"),
        "RZ Rush Share": ("rz_rush_share", "red_zone_rush_share"),
        "Goal Line Share": ("goal_line_share",),
        "RZ Pass Att": ("rz_pass_attempts", "red_zone_pass_attempts"),
        "RZ QB Rush Att": ("qb_rz_rush_attempts", "rz_qb_rush_attempts"),
    }
    rz_supplied = False
    for out_col, keys in rz_key_map.items():
        vals = []
        any_key = False
        for name in df["PLAYER"].astype(str):
            ev = players.get(name, {}) or {}
            val = 0.0
            for key in keys:
                if key in ev and ev.get(key) is not None:
                    try: val = float(ev.get(key) or 0.0)
                    except Exception: val = 0.0
                    any_key = True
                    break
            vals.append(max(0.0, val))
        if any_key:
            df[out_col] = vals
            rz_supplied = True
    df["PRELOCK_RED_ZONE_EVIDENCE_SUPPLIED"] = bool(rz_supplied)
    df["RED_ZONE_INGESTION_PATCH_ID"] = RED_ZONE_INGESTION_PATCH_ID
    # Optional player-keyed prelock sidecar is a fallback/complement to the nflverse
    # role payload. Positive embedded/nflverse values remain authoritative.
    df, rz_sidecar_receipt = football_intel.merge_red_zone_evidence(df, pool_path=pool)
    df.attrs["RED_ZONE_EVIDENCE_RECEIPT"] = rz_sidecar_receipt

    # Current game market evidence is allowed to update the pre-lock snapshot; opening
    # values remain separately retained so prediction-first movement is frozen.
    if market_evidence:
        if "current_total" in market_evidence:
            df["O/U"] = float(market_evidence["current_total"])
        if "open_total" in market_evidence:
            df["OPEN_LINE"] = float(market_evidence["open_total"])
        if "snapshot_age_minutes" in market_evidence:
            df["MARKET_SNAPSHOT_AGE_MINUTES"] = float(market_evidence["snapshot_age_minutes"])
        if "market_disagreement" in market_evidence:
            df["MARKET_DISAGREEMENT"] = float(market_evidence["market_disagreement"])
    df["PROJECTION_MARKET_STATUS"] = "RAW_MODEL"
    df = football_intel.derive_player_features(df, pos_col="POS_BASE")
    return df, sorted(set(out_names)), sorted(set(zero_role))


def _phase1_player_parameters(df: pd.DataFrame, strategy: Any) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    pos = df["POS_BASE"].astype(str).to_numpy(object)
    snap = df["SNAPS"].to_numpy(float) / 100.0
    route = df["ROUTES"].to_numpy(float) / 100.0
    target = df["TARGETS"].to_numpy(float) / 20.0
    carry = df["CARRIES"].to_numpy(float) / 25.0
    proj = np.maximum(0.0, df["FPTS"].to_numpy(float))
    ceil = np.maximum(proj, df["Ceil"].to_numpy(float))
    team_total = df.get("TM Score", pd.Series(np.full(len(df), 17.0))).to_numpy(float)
    env = np.clip((team_total - 13.0) / 12.0, 0.0, 1.0)
    opp = np.asarray(strategy.opportunity_score, dtype=float)
    predictive = np.asarray(strategy.predictive_features.dfs_upside_score, dtype=float)

    role_mu = np.zeros(len(df), dtype=np.float64)
    role_sigma_floor = np.zeros(len(df), dtype=np.float64)
    for p, base, sig in [("QB", 15.5, 5.2), ("RB", 10.0, 5.5), ("WR", 10.5, 5.8), ("TE", 8.5, 4.8), ("K", 7.0, 3.3), ("DST", 6.0, 4.2)]:
        m = pos == p
        if p == "QB":
            cap = snap[m]
        elif p == "RB":
            cap = 0.45 * snap[m] + 0.42 * carry[m] + 0.13 * target[m]
        elif p in {"WR", "TE"}:
            cap = 0.35 * snap[m] + 0.40 * route[m] + 0.25 * target[m]
        else:
            cap = np.ones(np.count_nonzero(m))
        role_mu[m] = base * np.clip(cap, 0.0, 1.15)
        role_sigma_floor[m] = sig

    # Current role remains the validity gate, but a verified positive projection is the
    # central regular-season mean rather than being collapsed toward fixed positional
    # role centers. Reliable role evidence permits bounded shrinkage; uncertain role
    # evidence preserves more of the source projection. Zero-role players still fail
    # closed below.
    role_unc = df["ROLE_UNCERTAINTY"].to_numpy(float)
    role_shrink = np.clip(0.10 + 0.25 * (1.0 - role_unc), 0.10, 0.35)
    mu = (1.0 - role_shrink) * proj + role_shrink * role_mu
    tail_prior = np.maximum(ceil, mu)
    sigma = np.maximum.reduce((role_sigma_floor * (0.45 + role_unc), np.maximum(1.1, mu * (0.38 + 0.35 * role_unc)), (tail_prior - mu) / 1.35))
    mu, sigma = football_intel.soft_adjust_mean_sigma(mu, sigma, df, sport="NFL")
    zero_role = (snap <= 0.0) & (route <= 0.0) & (target <= 0.0) & (carry <= 0.0) & ~np.isin(pos, ["K", "DST"])
    mu[zero_role] = 0.0
    sigma[zero_role] = 0.05
    return mu.astype(np.float32), sigma.astype(np.float32), role_mu.astype(np.float32)


def _american_implied_prob(value: Any) -> float:
    try:
        if value is None:
            return 0.0
        text=str(value).strip().replace(",","")
        if not text or text in {"-","nan","None"}:
            return 0.0
        x=float(text)
    except Exception:
        return 0.0
    if not math.isfinite(x) or x == 0.0:
        return 0.0
    return float(100.0/(x+100.0) if x>0 else (-x)/((-x)+100.0))


def _td_event_parameters(df: pd.DataFrame, sigma: np.ndarray) -> tuple[np.ndarray,np.ndarray]:
    """Prelock zero-mean touchdown-event tail calibration.

    Anytime-TD market odds determine event frequency. Historical/current red-zone
    opportunity only controls how much of the generic Gaussian variance is replaced
    by discrete TD skew. The adjustment preserves each player's mean and approximately
    preserves total variance, so this is a tail-shape repair rather than projection inflation.
    """
    if "1+ TD" not in df.columns:
        return np.zeros(len(df),dtype=np.float32),np.zeros(len(df),dtype=np.float32)
    p=np.asarray([_american_implied_prob(x) for x in df["1+ TD"].tolist()],dtype=np.float64)
    p=np.clip(p,0.0,0.90)
    lam=np.where(p>0.0,-np.log(np.maximum(1.0-p,1e-9)),0.0)
    rz=pd.to_numeric(df.get("RED_ZONE_OPPORTUNITY",pd.Series(np.zeros(len(df)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    mp=pd.to_numeric(df.get("MULTI_PATH_CEILING",pd.Series(np.zeros(len(df)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    role_u=pd.to_numeric(df.get("ROLE_UNCERTAINTY",pd.Series(np.full(len(df),0.35))),errors="coerce").fillna(0.35).to_numpy(np.float64)
    # Current market owns frequency; role/RZ evidence controls discrete-tail confidence.
    raw_scale=np.clip(0.52 + 0.36*np.sqrt(np.clip(rz,0,1)) + 0.12*np.clip(mp,0,1) - 0.08*np.clip(role_u,0,1),0.45,0.95)
    raw_scale=np.where(lam>0.0,raw_scale,0.0)
    # Replace, do not stack, at most 45% of existing Gaussian variance.
    sig=np.asarray(sigma,dtype=np.float64)
    raw_var=36.0*lam*raw_scale*raw_scale
    var_budget=np.maximum(0.0,0.45*sig*sig)
    scale_cap=np.sqrt(np.divide(var_budget,36.0*np.maximum(lam,1e-12),out=np.zeros_like(lam),where=lam>0))
    scale=np.where(lam>0,np.minimum(raw_scale,scale_cap),0.0)
    return lam.astype(np.float32),scale.astype(np.float32)


def _team_event_native_component(cal_base: dict[str, Any], trials: int, seed: int) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Build a centered team-event fantasy component without changing player means.

    The prelock anytime-TD market remains the scorer-frequency authority.  Same-team
    discrete scorer counts are driven by shared offense/pass/rush intensity worlds,
    then football scoring ledgers couple receiving touchdowns to the primary passer,
    team touchdowns to PAT opportunity, and opponent touchdowns to DST points-allowed
    pressure.  The resulting component is centered and variance-budgeted per player;
    no realized result or player-name rule enters the world.
    """
    mu = np.asarray(cal_base["mu"], dtype=np.float32)
    sigma = np.asarray(cal_base["sigma"], dtype=np.float32)
    td_lambda = np.asarray(cal_base.get("td_event_lambda", np.zeros(len(mu))), dtype=np.float64)
    td_scale = np.asarray(cal_base.get("td_event_scale", np.zeros(len(mu))), dtype=np.float64)
    pos = np.asarray(cal_base["pos"], dtype=object)
    team = np.asarray(cal_base["team"], dtype=object)
    n = len(mu)
    raw = np.zeros((n, trials), dtype=np.float64)
    base_budget = 36.0 * np.maximum(td_lambda, 0.0) * np.maximum(td_scale, 0.0) ** 2
    requested_budget = base_budget.copy()
    rng = np.random.default_rng(int(seed) ^ 0x7EA4E17)
    teams = list(dict.fromkeys(team.tolist()))
    team_total: dict[str, np.ndarray] = {}
    team_expected: dict[str, float] = {}
    team_pass_weighted: dict[str, np.ndarray] = {}
    pass_event_total = 0
    scorer_event_total = 0

    # Reuse the production latent-factor magnitudes as log-intensity sensitivities.
    # The -0.5*variance term gives E[intensity_multiplier]=1 exactly for Gaussian
    # event worlds, so the prelock market lambda remains the marginal mean frequency.
    for t in teams:
        idx = np.flatnonzero(team == t)
        off_z = rng.standard_normal(trials)
        pass_z = rng.standard_normal(trials)
        rush_z = rng.standard_normal(trials)
        counts_by_player: dict[int, np.ndarray] = {}
        total = np.zeros(trials, dtype=np.int32)
        expected_total = 0.0
        pass_weighted = np.zeros(trials, dtype=np.float64)
        for i in idx.tolist():
            lam = float(max(0.0, td_lambda[i]))
            esc = float(max(0.0, td_scale[i]))
            p = str(pos[i])
            if lam <= 0.0 or esc <= 0.0 or p not in {"QB", "RB", "WR", "TE"}:
                continue
            if p in {"WR", "TE"}:
                latent = 0.19 * off_z + 0.32 * pass_z
                lv = 0.19**2 + 0.32**2
            elif p == "RB":
                latent = 0.23 * off_z + 0.28 * rush_z
                lv = 0.23**2 + 0.28**2
            else:  # QB anytime-TD market represents scorer/rushing tail, not pass TDs.
                latent = 0.22 * off_z + 0.28 * rush_z
                lv = 0.22**2 + 0.28**2
            mult = np.exp(latent - 0.5 * lv)
            cnt = rng.poisson(lam=np.maximum(0.0, lam * mult), size=trials).astype(np.int32)
            counts_by_player[i] = cnt
            total += cnt
            expected_total += lam
            delta = cnt.astype(np.float64) - lam
            raw[i] += 6.0 * esc * delta
            scorer_event_total += int(cnt.sum())
            if p in {"WR", "TE"}:
                pass_weighted += esc * delta
                pass_event_total += int(cnt.sum())
        team_total[str(t)] = total
        team_expected[str(t)] = float(expected_total)
        team_pass_weighted[str(t)] = pass_weighted

        # Credit the primary QB with the same shared receiving-TD ledger.  A 4-point
        # passing score is paired with the receiver's scaled 6-point scorer event.
        qbs = idx[pos[idx] == "QB"]
        if len(qbs):
            qb = int(qbs[int(np.argmax(mu[qbs]))])
            pass_raw = 4.0 * pass_weighted
            raw[qb] += pass_raw
            pass_var = float(np.var(pass_raw))
            requested_budget[qb] += max(0.0, pass_var)

        # PAT scoring is a true same-team event ledger.  This replaces Gaussian
        # kicker variance rather than adding projection or total variance.
        ks = idx[pos[idx] == "K"]
        if len(ks):
            kicker = int(ks[int(np.argmax(mu[ks]))])
            pat = total.astype(np.float64) - float(expected_total)
            raw[kicker] += pat
            requested_budget[kicker] += max(0.0, float(np.var(pat)))

    # Opponent team touchdown environment is a monotone points-allowed pressure for
    # DST.  One centered fantasy point per opponent TD is deliberately conservative;
    # the per-player variance cap below prevents this structural coupling from
    # changing the Phase-1 marginal sigma contract.
    if len(teams) == 2:
        a, b = str(teams[0]), str(teams[1])
        for own, opp in ((a, b), (b, a)):
            idx = np.flatnonzero(team == own)
            own_delta = team_total.get(own, np.zeros(trials, dtype=np.int32)).astype(np.float64) - float(team_expected.get(own, 0.0))
            opp_delta = team_total.get(opp, np.zeros(trials, dtype=np.int32)).astype(np.float64) - float(team_expected.get(opp, 0.0))
            net_delta = own_delta - opp_delta

            # Running-back championship tails respond to the same centered scoring
            # differential that defines a favorable game-control world.  This only
            # reshapes the RB's already-budgeted TD-event variance; it does not add
            # a new marginal variance allowance.
            for rb in idx[pos[idx] == "RB"].tolist():
                esc = float(max(0.0, td_scale[rb]))
                if esc > 0.0:
                    raw[int(rb)] += esc * net_delta

            dsts = idx[pos[idx] == "DST"]
            if len(dsts):
                dst = int(dsts[int(np.argmax(mu[dsts]))])
                # DST receives a centered game-control/points-allowed response: own
                # scoring pressure helps while opponent scoring hurts.  One fantasy
                # point per net TD is a conservative structural proxy; the universal
                # 45% event-variance ceiling keeps the Phase-1 sigma unchanged.
                dst_raw = net_delta
                raw[dst] += dst_raw
                requested_budget[dst] += max(0.0, float(np.var(dst_raw)))

    # Exact sample-centering guarantees this layer cannot shift player projections.
    raw -= raw.mean(axis=1, keepdims=True)
    component = np.zeros_like(raw, dtype=np.float32)
    target_budget = np.zeros(n, dtype=np.float64)
    raw_var = raw.var(axis=1)
    for i in range(n):
        if raw_var[i] <= 1e-12 or sigma[i] <= 0.0:
            continue
        # Preserve at least 55% of target marginal variance in the continuous
        # component. Existing TD-event logic used the same 45% discrete ceiling.
        cap = 0.45 * float(sigma[i]) ** 2
        budget = min(max(float(base_budget[i]), float(requested_budget[i])), cap)
        if budget <= 0.0:
            continue
        component[i] = (raw[i] * math.sqrt(budget / float(raw_var[i]))).astype(np.float32)
        target_budget[i] = budget

    receipt = {
        "PATCH_ID": TEAM_EVENT_NATIVE_WORLD_PATCH_ID,
        "TEAM_COUNT": int(len(teams)),
        "SCORER_EVENTS": int(scorer_event_total),
        "PASS_CATCHER_EVENTS": int(pass_event_total),
        "QB_RECEIVER_SHARED_TD_LEDGER": "PASS",
        "KICKER_PAT_SHARED_LEDGER": "PASS",
        "DST_OPPONENT_TD_DIRECTION": "PASS",
        "MARGINAL_EVENT_MEAN_SHIFT_MAX": float(np.max(np.abs(component.mean(axis=1)))) if n else 0.0,
        "MAX_EVENT_VARIANCE_SHARE": float(np.max(np.divide(target_budget, np.maximum(np.asarray(sigma, dtype=np.float64) ** 2, 1e-12)))) if n else 0.0,
        "PLAYER_NAME_LOGIC": False,
        "POSTLOCK_INPUT_USED": False,
    }
    return component, target_budget.astype(np.float32), receipt


def _simulate_players(cal_base: dict[str, Any], trials: int, seed: int, *, return_event_receipt: bool = False):
    mu = np.asarray(cal_base["mu"], dtype=np.float32)
    sigma = np.asarray(cal_base["sigma"], dtype=np.float32)
    pos = np.asarray(cal_base["pos"], dtype=object)
    team = np.asarray(cal_base["team"], dtype=object)
    n = len(mu)
    rng = np.random.default_rng(seed)
    game_z = rng.standard_normal(trials, dtype=np.float32)
    teams = list(dict.fromkeys(team.tolist()))
    team_off = {t: rng.standard_normal(trials, dtype=np.float32) for t in teams}
    team_pass = {t: rng.standard_normal(trials, dtype=np.float32) for t in teams}
    team_rush = {t: rng.standard_normal(trials, dtype=np.float32) for t in teams}
    ind = rng.standard_normal((n, trials), dtype=np.float32)
    event_component, event_budget, event_receipt = _team_event_native_component(cal_base, trials, seed)
    out = np.empty((n, trials), dtype=np.float32)
    for i in range(n):
        t = team[i]
        p = pos[i]
        # Phase-1 sigma remains the intended marginal standard deviation. The event
        # layer consumes a bounded share of that variance; the remainder stays in the
        # unit-normalized continuous factor draw.
        if p == "QB":
            latent = 0.20 * game_z + 0.22 * team_off[t] + 0.28 * team_pass[t]
            z_var = 0.78**2 + 0.20**2 + 0.22**2 + 0.28**2
        elif p in {"WR", "TE"}:
            latent = 0.18 * game_z + 0.19 * team_off[t] + 0.32 * team_pass[t]
            z_var = 0.78**2 + 0.18**2 + 0.19**2 + 0.32**2
        elif p == "RB":
            latent = 0.16 * game_z + 0.23 * team_off[t] + 0.28 * team_rush[t]
            z_var = 0.78**2 + 0.16**2 + 0.23**2 + 0.28**2
        elif p == "K":
            latent = 0.15 * game_z + 0.28 * team_off[t]
            z_var = 0.78**2 + 0.15**2 + 0.28**2
        elif p == "DST":
            opp_t = teams[1] if len(teams) == 2 and teams[0] == t else teams[0]
            latent = -0.18 * game_z - 0.28 * team_off[opp_t] + 0.18 * team_rush[t]
            z_var = 0.78**2 + 0.18**2 + 0.28**2 + 0.18**2
        else:
            latent = 0.15 * game_z + 0.20 * team_off[t]
            z_var = 0.78**2 + 0.15**2 + 0.20**2
        z = (0.78 * ind[i] + latent) / np.float32(math.sqrt(z_var))
        cont_var = max(float(sigma[i]) * float(sigma[i]) - float(event_budget[i]), 0.55 * float(sigma[i]) * float(sigma[i]))
        vals = mu[i] + math.sqrt(max(cont_var, 0.0)) * z + event_component[i]
        if p == "DST":
            vals = np.maximum(-4.0, vals)
        else:
            vals = np.maximum(0.0, vals)
        out[i] = vals
    return (out, event_receipt) if return_event_receipt else out


def _pool_prelock_context(pool: str | Path) -> tuple[str | None, list[int]]:
    try:
        df = pd.read_csv(pool, nrows=64)
    except Exception:
        return None, []
    if "Time (ET)" not in df.columns:
        return None, []
    ts = pd.to_datetime(df["Time (ET)"], errors="coerce").dropna()
    if ts.empty:
        return None, []
    as_of = ts.min()
    year = int(as_of.year)
    return str(as_of), [year - 1, year]


def _load_calibration(pool: str | Path, role_evidence_path: str | Path, market_evidence_path: str | Path | None, cfg: Config, roster_gate: Any | None = None, nflverse_config: dict[str, Any] | None = None) -> Calibration:
    role_ev = _load_json(role_evidence_path)
    nv = dict(role_ev.get("nflverse_prelock", {}) or {})
    if nflverse_config:
        nv.update({k:v for k,v in nflverse_config.items() if v is not None})
    if bool(nv.get("enabled", False)):
        auto_as_of, auto_seasons = _pool_prelock_context(pool)
        as_of = nv.get("as_of") or auto_as_of
        seasons = nv.get("seasons") or auto_seasons
        cache_dir = nv.get("cache_dir")
        if not as_of or not seasons or not cache_dir:
            role_ev["nflverse_prelock_receipt"] = {
                "PATCH_ID": NFLVERSE_PRELOCK_ROLE_PATCH_ID,
                "STATUS": "CONFIG_INCOMPLETE",
                "POSTLOCK_TARGET_GAME_USED": False,
            }
        else:
            if bool(nv.get("refresh", False)):
                nflverse_role.refresh_cache(cache_dir, seasons)
            role_ev, _ = nflverse_role.enrich_role_evidence(
                role_ev, pool, cache_dir=cache_dir, as_of=as_of, seasons=seasons,
                lookback_games=int(nv.get("lookback_games", nflverse_role.DEFAULT_LOOKBACK_GAMES)),
                decay=float(nv.get("decay", nflverse_role.DEFAULT_DECAY)),
            )
    if roster_gate is not None:
        role_ev = _reconcile_role_evidence_with_availability(role_ev, roster_gate)
    market_ev = _load_json(market_evidence_path)
    df, out_names, zero_role = _prepare_frame(pool, role_ev, market_ev, allow_synthetic_role_priors=cfg.test_mode)
    # Hard purge confirmed non-participants before any Phase-1 calculation.
    active = ~df["ROLE_STATUS"].isin(["OUT", "IR", "DNP", "REST", "CONFIRMED_OUT", "DOUBTFUL", "ROLE_UNVERIFIED"])
    df = df.loc[active].reset_index(drop=True)
    # Internal ownership bridge lives inside the sport runtime: raw player file ->
    # hard OUT/role purge -> active-pool internal ownership -> phase 1/2/field sims.
    df = ownership_bridge.derive_expected_ownership(df, sport="NFL", mode="SHOWDOWN", field_size=cfg.field_size, roster_size=ROSTER_SIZE)
    if len(df) < 6 or df["TEAM"].nunique() != 2:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_ACTIVE_POOL_INFEASIBLE")
    if not np.all((df["SAL"].astype(int) > 0) & (df["SAL"].astype(int) <= SALARY_MAX)):
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_INVALID_SALARY")

    strategy = strategy_mod.build_strategy_features(df, sport=SPORT, mode=MODE)
    mu, sigma, _ = _phase1_player_parameters(df, strategy)
    td_event_lambda, td_event_scale = _td_event_parameters(df, sigma)
    df["TD_EVENT_LAMBDA"] = td_event_lambda
    df["TD_EVENT_SCALE"] = td_event_scale
    df["TD_EVENT_TAIL_PATCH_ID"] = TD_EVENT_TAIL_PATCH_ID
    ids = np.arange(len(df), dtype=np.int32)
    pos = df["POS_BASE"].astype(str).to_numpy(object)
    team = df["TEAM"].astype(str).to_numpy(object)
    salary = df["SAL"].astype(int).to_numpy(np.int32)
    base = {"mu": mu, "sigma": sigma, "pos": pos, "team": team, "td_event_lambda":td_event_lambda, "td_event_scale":td_event_scale}
    sims = _simulate_players(base, cfg.player_trials, cfg.seed ^ 0x51A7E)
    p95 = np.quantile(sims, 0.95, axis=1).astype(np.float32)
    p99 = np.quantile(sims, 0.99, axis=1).astype(np.float32)
    covariance = np.cov(sims.astype(np.float64)).astype(np.float32)
    std = np.sqrt(np.maximum(np.diag(covariance), 1e-8))
    correlation = covariance / np.maximum(np.outer(std, std), 1e-8)
    correlation = np.clip(correlation, -1.0, 1.0).astype(np.float32)
    own, captain_own, flex_own, ownership_receipt = _role_consistent_ownership_contract(df, p99, strategy)
    role_hash = _stable_hash(role_ev)
    market_hash = _stable_hash(market_ev)
    phase1_payload = {
        "ids": ids.tolist(), "mu": np.round(mu, 6).tolist(), "sigma": np.round(sigma, 6).tolist(),
        "p95": np.round(p95, 6).tolist(), "p99": np.round(p99, 6).tolist(),
        "role_evidence_hash": role_hash, "market_evidence_hash": market_hash,
        "prediction_hash": strategy.receipt["PREDICTION_HASH"], "player_trials": cfg.player_trials,
    }
    phase1_hash = _stable_hash(phase1_payload)
    shared = {
        "PLAYER_ID_ORDER_HASH": _array_hash(ids),
        "CORRELATION_MATRIX_HASH": _array_hash(correlation),
        "COVARIANCE_MATRIX_HASH": _array_hash(covariance),
        "OWNERSHIP_VECTOR_HASH": _array_hash(own),
        "CAPTAIN_OWNERSHIP_VECTOR_HASH": _array_hash(captain_own),
        "FLEX_OWNERSHIP_VECTOR_HASH": _array_hash(flex_own),
        "OWNERSHIP_CONTRACT_HASH": _stable_hash(ownership_receipt),
        "CEILING_VECTOR_HASH": _array_hash(p99),
        "CEILING_DEFINITION_HASH": _stable_hash({"PERCENTILES": [95, 99], "METHOD": "PHASE1_MC", "TRIALS": cfg.player_trials}),
        "STACK_FEATURES_HASH": _stable_hash({"NFL_SHOWDOWN": "QB_PASS_CATCHER_RB_DST_K_GAME_ENV_ROTATION"}),
        "METRIC_SCALING_HASH": _stable_hash({"TOP01": "RATE", "WIN": "RATE", "P95": "RAW", "P99": "RAW"}),
        "ROLE_STATUS_STATE_HASH": _stable_hash(df[["PLAYER", "ROLE_STATUS", "SNAPS", "ROUTES", "TARGETS", "CARRIES"]].to_dict("records")),
        "BASE_SIM_TRIALS_HASH": _stable_hash(cfg.base_trials),
    }
    shared_id = _stable_hash(shared)
    return Calibration(
        frame=df, ids=ids, pos=pos, team=team, salary=salary,
        role_snap=df["SNAPS"].to_numpy(float)/100.0, role_routes=df["ROUTES"].to_numpy(float)/100.0,
        role_targets=df["TARGETS"].to_numpy(float)/20.0, role_carries=df["CARRIES"].to_numpy(float)/25.0,
        role_uncertainty=df["ROLE_UNCERTAINTY"].to_numpy(float), strategy=strategy, mu=mu, sigma=sigma, p95=p95, p99=p99,
        ownership=own, captain_ownership=captain_own, flex_ownership=flex_own, ownership_receipt=ownership_receipt, correlation=correlation, covariance=covariance, phase1_hash=phase1_hash,
        shared_metric_bundle_id=shared_id, prediction_hash=strategy.receipt["PREDICTION_HASH"],
        role_evidence_hash=role_hash, market_evidence_hash=market_hash, role_evidence_payload=role_ev, market_evidence_payload=market_ev, out_names=out_names, zero_role_names=zero_role,
        player_sim_matrix_hash=_array_hash(sims),
    )


def _legal_scan_count(cal: Calibration) -> int:
    n = len(cal.ids)
    total = 0
    for c in range(n):
        same = int(np.count_nonzero(cal.team == cal.team[c])) - 1
        total += math.comb(n - 1, 5) - (math.comb(same, 5) if same >= 5 else 0)
    return int(total)


def _structural_lineup_features(rows: np.ndarray, cal: Calibration) -> dict[str, np.ndarray]:
    cpt = rows[:, 0]
    teams = cal.team[rows]
    pos = cal.pos[rows]
    cpt_team = cal.team[cpt]
    same_cpt_team = (teams == cpt_team[:, None]).sum(axis=1).astype(np.int8)
    qb_count = (pos == "QB").sum(axis=1).astype(np.int8)
    dst_count = (pos == "DST").sum(axis=1).astype(np.int8)
    k_count = (pos == "K").sum(axis=1).astype(np.int8)
    rb_count = (pos == "RB").sum(axis=1).astype(np.int8)
    pass_count = np.isin(pos, ["WR", "TE"]).sum(axis=1).astype(np.int8)
    skill_count = (rb_count + pass_count).astype(np.int8)
    stability_count = (qb_count + k_count).astype(np.int8)
    cpt_pos_code_map = {"QB":0,"RB":1,"WR":2,"TE":3,"K":4,"DST":5}
    cpt_pos_code = np.asarray([cpt_pos_code_map.get(str(x), 6) for x in cal.pos[cpt]], dtype=np.int8)
    macro = cpt_pos_code.astype(np.int32) * 100 + same_cpt_team.astype(np.int32) * 10 + np.minimum(qb_count, 4).astype(np.int32)
    family = (macro.astype(np.int64) * 10000 + np.minimum(dst_count, 2).astype(np.int64) * 1000 + np.minimum(rb_count, 6).astype(np.int64) * 100 + np.minimum(k_count, 6).astype(np.int64) * 10 + np.minimum(pass_count, 6).astype(np.int64))
    return {"same_cpt_team":same_cpt_team,"qb_count":qb_count,"dst_count":dst_count,"k_count":k_count,"rb_count":rb_count,"pass_count":pass_count,"skill_count":skill_count,"stability_count":stability_count,"cpt_pos_code":cpt_pos_code,"macro":macro,"family":family}


def _lineup_calibration_score(rows: np.ndarray, cal: Calibration) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    f = _structural_lineup_features(rows, cal)
    cpt = rows[:, 0]
    base = cal.p99[rows].sum(axis=1).astype(np.float64) + 0.5 * cal.p99[cpt]
    p95 = cal.p95[rows].sum(axis=1).astype(np.float64) + 0.5 * cal.p95[cpt]
    opportunity = np.asarray(cal.strategy.opportunity_score, dtype=float)
    leverage = np.asarray(cal.strategy.strategic_leverage, dtype=float)
    role = opportunity[rows].sum(axis=1) + 0.35 * opportunity[cpt]
    lev = leverage[rows].sum(axis=1)
    pos = cal.pos[rows]
    teams = cal.team[rows]

    synergy = np.zeros(len(rows), dtype=np.float64)
    for slot in range(6):
        qmask = pos[:, slot] == "QB"
        if not np.any(qmask): continue
        qt = teams[:, slot]
        same_pass = ((teams == qt[:,None]) & np.isin(pos,["WR","TE"])).sum(axis=1)
        synergy += qmask * np.minimum(same_pass, 3) * 0.65
    for slot in range(6):
        dmask = pos[:, slot] == "DST"
        if np.any(dmask):
            dt = teams[:, slot]
            same_rb = ((teams == dt[:,None]) & (pos == "RB")).sum(axis=1)
            opp_qb = ((teams != dt[:,None]) & (pos == "QB")).sum(axis=1)
            synergy += dmask * (0.45 * np.minimum(same_rb,2) - 0.60 * np.minimum(opp_qb,2))
    synergy += -0.30 * np.maximum(0, f["rb_count"] - 3)
    split_bonus = np.where(f["same_cpt_team"] == 3, 0.70, np.where(f["same_cpt_team"] == 4, 0.45, 0.12))

    multi = pd.to_numeric(cal.frame.get("MULTI_PATH_CEILING", pd.Series(np.zeros(len(cal.frame)))), errors="coerce").fillna(0.0).to_numpy(float)
    rz = pd.to_numeric(cal.frame.get("RED_ZONE_OPPORTUNITY", pd.Series(np.zeros(len(cal.frame)))), errors="coerce").fillna(0.0).to_numpy(float)
    path_support = multi[rows].sum(axis=1) + 0.35 * multi[cpt]
    rz_support = rz[rows].sum(axis=1) + 0.55 * rz[cpt]
    salary = ((cal.salary[cpt].astype(np.int64) * 3) // 2) + cal.salary[rows[:,1:]].sum(axis=1)
    remainder = SALARY_MAX - salary
    # Salary-left is geometry, not a spend-max mandate. Around $1k receives a small
    # robustness prior while both $0 and very large leftovers remain fully legal.
    salary_geometry = np.clip(1.0 - np.abs(remainder - 1000.0) / 1800.0, 0.0, 1.0)

    score = (0.58 * base + 0.22 * p95 + 2.4 * role + 0.8 * lev + 1.6 * synergy + split_bonus
             + 1.05 * path_support + 1.55 * rz_support + 0.70 * salary_geometry)
    f = dict(f)
    f.update({
        "multi_path_support": path_support.astype(np.float32),
        "red_zone_support": rz_support.astype(np.float32),
        "salary_remainder": remainder.astype(np.int32),
        "salary_geometry": salary_geometry.astype(np.float32),
    })
    return score, f

def _candidate_player_scores(cal: Calibration) -> tuple[np.ndarray, np.ndarray]:
    p99r = _pct(cal.p99); p95r = _pct(cal.p95)
    opp = np.asarray(cal.strategy.opportunity_score, dtype=float)
    lev = np.asarray(cal.strategy.strategic_leverage, dtype=float)
    pred = np.asarray(cal.strategy.predictive_features.dfs_upside_score, dtype=float)
    role_nonzero = np.maximum.reduce((cal.role_snap, cal.role_routes, cal.role_targets, cal.role_carries))
    multi = pd.to_numeric(cal.frame.get("MULTI_PATH_CEILING", pd.Series(np.zeros(len(cal.frame)))), errors="coerce").fillna(0.0).to_numpy(float)
    rz = pd.to_numeric(cal.frame.get("RED_ZONE_OPPORTUNITY", pd.Series(np.zeros(len(cal.frame)))), errors="coerce").fillna(0.0).to_numpy(float)
    # Multi-path/RZ are birth evidence, not hard roster rules. We rebalance rather
    # than stack bonuses on top of the legacy 1.0 total score.
    flex = 0.38*p99r + 0.20*p95r + 0.18*opp + 0.08*pred + 0.05*lev + 0.05*multi + 0.06*rz
    cpt = 0.43*p99r + 0.21*p95r + 0.15*opp + 0.06*pred + 0.03*lev + 0.05*multi + 0.07*rz
    flex = np.where((role_nonzero > 0.01) | np.isin(cal.pos,["K","DST"]), flex, -1e6)
    cpt = np.where((role_nonzero > 0.04) | np.isin(cal.pos,["K","DST"]), cpt, -1e6)
    return cpt, flex

def _top_unique_indices(scores: np.ndarray, count: int, extra_groups: Iterable[tuple[np.ndarray, int]] = ()) -> np.ndarray:
    take = set(np.argsort(scores, kind="stable")[-min(count, len(scores)):].tolist())
    for mask, k in extra_groups:
        idx = np.flatnonzero(mask)
        if idx.size:
            take.update(idx[np.argsort(scores[idx], kind="stable")[-min(k, idx.size):]].tolist())
    out = np.asarray(sorted(take, key=lambda i: (-scores[i], i)), dtype=np.int32)
    return out


def _regular_season_flex_pool(cal: Calibration, flex_score: np.ndarray, captain: int, cfg: Config) -> tuple[np.ndarray, int, int]:
    """Global score frontier plus current-role position/team closure, with no retruncation."""
    base = np.argsort(flex_score, kind="stable")[-min(cfg.flex_pool_size, len(flex_score)):]
    base_set = set(map(int, base.tolist()))
    required: set[int] = set()
    role_pc_added: set[int] = set()
    for t in np.unique(cal.team):
        idx = np.flatnonzero(cal.team == t)
        if idx.size:
            order = idx[np.argsort(flex_score[idx], kind="stable")[::-1]]
            required.update(map(int, order[:min(3, len(order))].tolist()))
        for p in ["QB", "RB", "WR", "TE", "K", "DST"]:
            idx = np.flatnonzero((cal.team == t) & (cal.pos == p))
            if idx.size:
                order = idx[np.argsort(flex_score[idx], kind="stable")[::-1]]
                # Showdown FLEX birth is geometry-aware: viable 3-RB constructions must
                # not be made impossible by a two-RB-per-team pre-prune.  RB3 is admitted
                # to the FLEX closure only; this is a birth lane, never a forced selection.
                keep = 1 if p == "QB" else (int(cfg.regular_season_rb_team_keep) if p == "RB" else 2)
                required.update(map(int, order[:min(keep, len(order))].tolist()))
        pc = np.flatnonzero((cal.team == t) & np.isin(cal.pos, ["WR", "TE"]))
        if pc.size:
            role_score = 0.45 * cal.role_routes[pc] + 0.35 * cal.role_targets[pc] + 0.20 * cal.role_snap[pc]
            order = pc[np.argsort(role_score, kind="stable")[::-1]]
            chosen = set(map(int, order[:min(int(cfg.regular_season_pass_catcher_team_keep), len(order))].tolist()))
            role_pc_added.update(chosen)
            required.update(chosen)
        # Scoring-zone tail closure: retain a bounded pair of skill players per team
        # when exact prelock RZ evidence supports them. This is birth preservation,
        # never a final-board force.
        skill = np.flatnonzero((cal.team == t) & np.isin(cal.pos, ["RB","WR","TE"]))
        if skill.size and "RED_ZONE_OPPORTUNITY" in cal.frame.columns:
            rz = pd.to_numeric(cal.frame["RED_ZONE_OPPORTUNITY"], errors="coerce").fillna(0.0).to_numpy(float)
            multi = pd.to_numeric(cal.frame.get("MULTI_PATH_CEILING", pd.Series(np.zeros(len(cal.frame)))), errors="coerce").fillna(0.0).to_numpy(float)
            positive = skill[rz[skill] > 0.0]
            if positive.size:
                tail_score = 0.70 * rz[positive] + 0.30 * multi[positive]
                order = positive[np.argsort(tail_score, kind="stable")[::-1]]
                required.update(map(int, order[:min(2, len(order))].tolist()))
    merged_set = (base_set | required) - {int(captain)}
    merged = np.asarray(sorted(merged_set, key=lambda i: (-float(flex_score[i]), i)), dtype=np.int32)
    return merged, int(len(required - base_set)), int(len(role_pc_added - base_set))

def _generate_candidates(cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, Any]]:
    cpt_score, flex_score = _candidate_player_scores(cal)
    cpt_base = np.argsort(cpt_score, kind="stable")[-min(cfg.cpt_pool_size, len(cpt_score)):]
    cpt_required: set[int] = set()
    for t in np.unique(cal.team):
        idx = np.flatnonzero(cal.team == t)
        if idx.size:
            order = idx[np.argsort(cpt_score[idx], kind="stable")[::-1]]
            cpt_required.update(map(int, order[:min(3, len(order))].tolist()))
        for p in ["QB", "RB", "WR", "TE", "K", "DST"]:
            idx = np.flatnonzero((cal.team == t) & (cal.pos == p))
            if idx.size:
                order = idx[np.argsort(cpt_score[idx], kind="stable")[::-1]]
                keep = 1 if p == "QB" else 2
                cpt_required.update(map(int, order[:min(keep, len(order))].tolist()))
    cpt_set = set(map(int, cpt_base.tolist())) | cpt_required
    cpt_pool = np.asarray(sorted(cpt_set, key=lambda i: (-float(cpt_score[i]), i)), dtype=np.int32)

    rows_parts: list[np.ndarray] = []
    position_team_closure_additions = int(len(cpt_set - set(map(int, cpt_base.tolist()))))
    role_pass_catcher_closure_additions = 0
    flex_certified_additions = 0
    for c in cpt_pool:
        flex_pool, certified_added, role_pc_added = _regular_season_flex_pool(cal, flex_score, int(c), cfg)
        position_team_closure_additions += int(certified_added)
        flex_certified_additions += int(certified_added)
        role_pass_catcher_closure_additions += int(role_pc_added)
        if flex_pool.size < 5: continue
        comb = np.fromiter((x for tup in itertools.combinations(flex_pool.tolist(), 5) for x in tup), dtype=np.int32)
        if comb.size == 0: continue
        comb = comb.reshape(-1, 5)
        ccol = np.full((len(comb), 1), int(c), dtype=np.int32)
        r = np.concatenate([ccol, comb], axis=1)
        team_counts = (cal.team[r] == cal.team[c]).sum(axis=1)
        salary = ((cal.salary[c] * 3) // 2) + cal.salary[comb].sum(axis=1)
        keep = (team_counts <= MAX_TEAM) & (salary >= SALARY_MIN) & (salary <= SALARY_MAX)
        if np.any(keep): rows_parts.append(r[keep])
    if not rows_parts:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_ZERO_CALIBRATED_CANDIDATES")
    rows = np.unique(np.concatenate(rows_parts, axis=0), axis=0)
    score, feat = _lineup_calibration_score(rows, cal)
    return rows, {
        "score": score, **feat, "cpt_pool": cpt_pool,
        "cpt_base_size": int(len(cpt_base)), "cpt_certified_size": int(len(cpt_pool)),
        "position_team_closure_additions": int(position_team_closure_additions),
        "flex_certified_additions": int(flex_certified_additions),
        "role_pass_catcher_closure_additions": int(role_pass_catcher_closure_additions),
    }

def _select_top_by_group(group: np.ndarray, score: np.ndarray, per_group: int) -> np.ndarray:
    chosen: list[np.ndarray] = []
    for g in np.unique(group):
        idx = np.flatnonzero(group == g)
        if idx.size <= per_group: chosen.append(idx)
        else:
            local = np.argpartition(score[idx], -per_group)[-per_group:]
            chosen.append(idx[local])
    return np.unique(np.concatenate(chosen)) if chosen else np.asarray([], dtype=np.int32)


def _phase2_common_world_recurrence(
    candidate_rows: np.ndarray,
    source_idx: np.ndarray,
    cal: Calibration,
    cfg: Config,
) -> tuple[np.ndarray, np.ndarray]:
    """Cheap, deterministic common-world screen for structural Phase-2 reserves.

    The screen is player-name blind and uses only the frozen prelock calibration surface.
    It streams candidates in physical chunks and tracks each world's top-N rows without
    materializing the full candidate-by-world score matrix.
    """
    source_idx = np.asarray(source_idx, dtype=np.int32)
    n = len(candidate_rows)
    primary = np.zeros(n, dtype=np.int32)
    secondary = np.zeros(n, dtype=np.int32)
    if source_idx.size == 0 or int(cfg.phase2_common_world_trials) <= 0:
        return primary, secondary

    trials = int(cfg.phase2_common_world_trials)
    k_primary = min(int(cfg.phase2_common_world_primary_rank), int(source_idx.size))
    k_secondary = min(int(cfg.phase2_common_world_secondary_rank), k_primary)
    if k_primary <= 0:
        return primary, secondary

    base = {
        "mu": cal.mu,
        "sigma": cal.sigma,
        "pos": cal.pos,
        "team": cal.team,
        "td_event_lambda": pd.to_numeric(
            cal.frame.get("TD_EVENT_LAMBDA", pd.Series(np.zeros(len(cal.frame)))), errors="coerce"
        ).fillna(0.0).to_numpy(np.float32),
        "td_event_scale": pd.to_numeric(
            cal.frame.get("TD_EVENT_SCALE", pd.Series(np.zeros(len(cal.frame)))), errors="coerce"
        ).fillna(0.0).to_numpy(np.float32),
    }
    sims = _simulate_players(base, trials, int(cfg.seed) ^ 0xC011A)
    best_scores = np.full((k_primary, trials), -np.inf, dtype=np.float32)
    best_idx = np.full((k_primary, trials), -1, dtype=np.int32)
    chunk_size = max(128, int(cfg.phase2_common_world_chunk))

    for start in range(0, int(source_idx.size), chunk_size):
        chunk = source_idx[start:start + chunk_size]
        scores = _score_rows(candidate_rows[chunk], sims).astype(np.float32, copy=False)
        local_k = min(k_primary, len(chunk))
        if local_k <= 0:
            continue
        local_pos = np.argpartition(scores, -local_k, axis=0)[-local_k:]
        local_scores = np.take_along_axis(scores, local_pos, axis=0)
        local_idx = chunk[local_pos]
        merged_scores = np.concatenate([best_scores, local_scores], axis=0)
        merged_idx = np.concatenate([best_idx, local_idx], axis=0)
        keep_pos = np.argpartition(merged_scores, -k_primary, axis=0)[-k_primary:]
        best_scores = np.take_along_axis(merged_scores, keep_pos, axis=0)
        best_idx = np.take_along_axis(merged_idx, keep_pos, axis=0)

    valid = best_idx >= 0
    if np.any(valid):
        primary += np.bincount(best_idx[valid], minlength=n).astype(np.int32)
    if k_secondary > 0:
        sec_pos = np.argpartition(best_scores, -k_secondary, axis=0)[-k_secondary:]
        sec_idx = np.take_along_axis(best_idx, sec_pos, axis=0)
        sec_valid = sec_idx >= 0
        if np.any(sec_valid):
            secondary += np.bincount(sec_idx[sec_valid], minlength=n).astype(np.int32)
    return primary, secondary


def _phase2(candidate_rows: np.ndarray, cmeta: dict[str, Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, np.ndarray], dict[str,int]]:
    score = np.asarray(cmeta["score"], dtype=float)
    all_idx = np.arange(len(score), dtype=np.int32)
    requested_keep = int(cfg.phase2_keep)
    legacy_effective_keep = requested_keep if cfg.test_mode else max(requested_keep, int(cfg.phase2_min_keep))
    legacy_effective_keep = min(legacy_effective_keep, len(all_idx))
    if legacy_effective_keep <= 0:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_ZERO_PHASE2_CAPACITY")

    # Lane A remains a bounded deterministic scalar frontier. Lane B is now the
    # complete calibration-qualified structural union. The old hard Phase-2 cap
    # is retained only as a diagnostic receipt; it no longer deletes qualified
    # rows. This makes qualification -> MC a 1:1 membership handoff.
    global_lane_k = min(
        int(cfg.phase2_global_lane_keep), int(cfg.base_global_keep), legacy_effective_keep, len(all_idx)
    )
    if cfg.test_mode:
        global_lane_k = min(global_lane_k, max(1, legacy_effective_keep // 2))
    global_idx = (
        all_idx[np.argpartition(score, -global_lane_k)[-global_lane_k:]]
        if global_lane_k else np.asarray([], dtype=np.int32)
    )

    family_all = np.asarray(cmeta["family"])
    family_idx = _select_top_by_group(family_all, score, cfg.family_keep) if len(all_idx) else np.asarray([], dtype=np.int32)
    macro = np.asarray(cmeta["macro"])
    macro_idx = _select_top_by_group(macro, score, cfg.closure_keep_per_macro) if len(all_idx) else np.asarray([], dtype=np.int32)
    structural_all = np.unique(np.concatenate([family_idx, macro_idx]))
    global_set = set(map(int, global_idx.tolist()))
    structural_source = np.asarray([i for i in structural_all.tolist() if int(i) not in global_set], dtype=np.int32)

    # Recurrence remains useful evidence, but is no longer an irreversible
    # membership gate. MC/selector layers may use it for prioritization,
    # stability, and tie-breaks after every qualified row has been retained.
    primary_occ, secondary_occ = _phase2_common_world_recurrence(candidate_rows, structural_source, cal, cfg)
    chosen = np.unique(np.concatenate([global_idx, structural_source]))
    if chosen.size == 0:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_ZERO_PHASE2_QUALIFIED_UNION")

    # Membership is frozen before ordering. Ordering is compute/display
    # convenience only and cannot add/remove a qualified row.
    order = chosen[np.argsort(score[chosen], kind="stable")[::-1]]
    rows = candidate_rows[order]
    salary = ((cal.salary[rows[:,0]] * 3) // 2) + cal.salary[rows[:,1:]].sum(axis=1)
    keys = ["score","same_cpt_team","qb_count","dst_count","k_count","rb_count","pass_count","skill_count","stability_count","cpt_pos_code","macro","family"]
    pmeta = {k: np.asarray(cmeta[k])[order] for k in keys}
    pmeta["salary"] = salary.astype(np.int32)
    pmeta["phase2_index"] = np.arange(len(rows), dtype=np.int32)
    pmeta["phase2_common_world_primary_occurrence"] = primary_occ[order].astype(np.int32)
    pmeta["phase2_common_world_secondary_occurrence"] = secondary_occ[order].astype(np.int32)

    chosen_set = set(map(int, chosen.tolist()))
    family_survivors = len(chosen_set.intersection(map(int, family_idx.tolist())))
    macro_survivors = len(chosen_set.intersection(map(int, macro_idx.tolist())))
    receipt = {
        "PHASE2_CHAMPIONSHIP_RESERVE_PATCH_ID": PHASE2_CHAMPIONSHIP_COMMON_WORLD_RESERVE_PATCH_ID,
        "PHASE2_CALIBRATION_QUALIFIED_STREAM_PATCH_ID": PHASE2_CALIBRATION_QUALIFIED_STREAM_PATCH_ID,
        "PHASE2_REQUESTED_KEEP": requested_keep,
        "PHASE2_EFFECTIVE_KEEP": int(legacy_effective_keep),
        "PHASE2_HARD_CAP_ENFORCED": False,
        "BASE_CALIBRATION_QUALIFIED_LINEUPS": int(len(global_idx)),
        "BASE_CALIBRATION_GLOBAL_LANE": int(len(global_idx)),
        "CHAMPIONSHIP_STRUCTURAL_POOL": int(len(structural_source)),
        "CHAMPIONSHIP_COMMON_WORLD_RESERVE_ADDITIONS": int(len(structural_source)),
        "COMMON_WORLD_SCREEN_TRIALS": int(cfg.phase2_common_world_trials),
        "COMMON_WORLD_PRIMARY_RANK": int(min(cfg.phase2_common_world_primary_rank, max(0, len(structural_source)))),
        "COMMON_WORLD_SECONDARY_RANK": int(min(cfg.phase2_common_world_secondary_rank, max(0, len(structural_source)))),
        "FAMILY_RESERVE_SURVIVORS": int(family_survivors),
        "MACRO_RESERVE_SURVIVORS": int(macro_survivors),
        "CALIBRATED_SIBLING_CLOSURE_ADDITIONS": int(len(structural_source)),
        "REGULAR_SEASON_ROLE_PASS_CATCHER_CLOSURE_ADDITIONS": int(cmeta.get("role_pass_catcher_closure_additions", 0)),
        "CERTIFIED_POSITION_TEAM_CLOSURE_ADDITIONS": int(cmeta.get("position_team_closure_additions", 0)),
        "CERTIFIED_POSITION_TEAM_CLOSURE_RETRUNCATION_COUNT": 0,
        "PHASE2_STREAM_AND_CHUCK_STATUS": "CALIBRATION_QUALIFIED_UNION__NO_DESTRUCTIVE_RETRUNCATION",
        "BOUNDED_FRONTIER_LIMITS": {"LEGACY_PHASE2_KEEP_DIAGNOSTIC_ONLY": int(legacy_effective_keep)},
        "QUALIFIED_SURVIVOR_DELETION_ALLOWED_FALSE": True,
        "PHASE2_QUALIFIED_UNION_LINEUPS": int(len(rows)),
        "PHASE2_BUILT_LINEUPS": int(len(rows)),
    }
    return rows, pmeta, receipt

def _score_rows(rows: np.ndarray, sims: np.ndarray) -> np.ndarray:
    # rows[:,0] is CPT and receives 1.5x fantasy scoring.
    return sims[rows[:,1:]].sum(axis=1) + 1.5 * sims[rows[:,0]]


def _public_field_indices(rows: np.ndarray, cal: Calibration, field_size: int, seed: int, *, return_receipt: bool = False):
    flex_own = np.clip(cal.flex_ownership, 0.0005, 0.98)
    cpt_own = np.clip(cal.captain_ownership, 0.0005, 0.65)
    role = np.asarray(cal.strategy.opportunity_score,dtype=float)
    team_total = pd.to_numeric(cal.frame.get("TM Score", pd.Series(np.nan, index=cal.frame.index)), errors="coerce").to_numpy(float)
    w, joint_receipt = joint_field_model.production_identity_joint_weights(
        rows, cpt_own, flex_own, role_score=role, team=cal.team, salary=cal.salary, position=cal.pos,
        team_total=(team_total if np.isfinite(team_total).all() else None),
    )
    rng = np.random.default_rng(seed ^ 0xF13D)
    idx = rng.choice(len(rows), size=int(field_size), replace=True, p=w).astype(np.int32)
    return (idx, joint_receipt) if return_receipt else idx


def _field_thresholds(field_rows: np.ndarray, sims: np.ndarray, top01_n: int, top0100_n: int | None = None, top0050_n: int | None = None, batch: int = 128) -> tuple[np.ndarray,np.ndarray,np.ndarray,np.ndarray,np.ndarray]:
    """Exact sampled-field thresholds using duplicate-compressed chunk/stream evaluation.

    The public field is sampled with replacement, so many of the `field_rows` are
    duplicates.  Rescoring every duplicate across every world is pure redundant
    work.  Compress to unique lineups + multiplicities, then for each world only
    inspect the top K unique scores, where K=max(10, top01_n).  Because every
    unique lineup has multiplicity >=1, the weighted Kth order statistic must lie
    within the top K unique scores.  This preserves exact field thresholds while
    materially reducing live runtime and memory pressure.
    """
    trials = int(sims.shape[1])
    if len(field_rows) <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:PUBLIC_FIELD_EMPTY")
    top01_rank = max(1, min(int(top01_n), int(len(field_rows))))
    top0100_rank = max(1, min(int(top0100_n if top0100_n is not None else top01_rank), int(len(field_rows))))
    top0050_rank = max(1, min(int(top0050_n if top0050_n is not None else top0100_rank), int(len(field_rows))))
    top10_rank = max(1, min(10, int(len(field_rows))))
    keep_rank = max(top01_rank, top0100_rank, top0050_rank, top10_rank)
    unique_rows, counts = np.unique(np.asarray(field_rows, dtype=np.int32), axis=0, return_counts=True)
    counts = np.asarray(counts, dtype=np.int32)
    k_unique = min(int(keep_rank), int(len(unique_rows)))
    win = np.empty(trials, dtype=np.float32)
    top10 = np.empty(trials, dtype=np.float32)
    top01 = np.empty(trials, dtype=np.float32)
    top0100 = np.empty(trials, dtype=np.float32)
    top0050 = np.empty(trials, dtype=np.float32)
    for w0 in range(0, trials, int(batch)):
        w1 = min(trials, w0 + int(batch))
        sc = _score_rows(unique_rows, sims[:, w0:w1])
        if k_unique < len(unique_rows):
            idx = np.argpartition(sc, -k_unique, axis=0)[-k_unique:]
            vals = np.take_along_axis(sc, idx, axis=0)
            cnt = counts[idx]
        else:
            vals = sc
            cnt = np.broadcast_to(counts[:, None], vals.shape)
        order = np.argsort(vals, axis=0)[::-1]
        vals = np.take_along_axis(vals, order, axis=0)
        cnt = np.take_along_axis(cnt, order, axis=0)
        cum = np.cumsum(cnt, axis=0)
        cols = np.arange(w1 - w0)
        def _weighted_rank(rank: int) -> np.ndarray:
            hit = cum >= int(rank)
            pos = np.argmax(hit, axis=0)
            return vals[pos, cols]
        win[w0:w1] = vals[0]
        top10[w0:w1] = _weighted_rank(top10_rank)
        top01[w0:w1] = _weighted_rank(top01_rank)
        top0100[w0:w1] = _weighted_rank(top0100_rank)
        top0050[w0:w1] = _weighted_rank(top0050_rank)
    return win, top10, top01, top0100, top0050


def _ordinal_world_evidence(rows: np.ndarray, field_rows: np.ndarray, sims: np.ndarray, field_size: int, max_worlds: int = 256) -> dict[str,np.ndarray]:
    """Deterministic cross-world ordinal posterior against the sampled public field.

    Uses an evenly spaced subset of already-generated base worlds, so it adds no
    postlock information and no extra simulation randomness. Contest rank is 1 plus
    the number of sampled-field entries with a strictly higher score.
    """
    n=int(len(rows)); trials=int(sims.shape[1]); fs=int(field_size)
    if n<=0 or trials<=0 or len(field_rows)<=0 or fs<=0:
        z=np.full(n,np.nan,dtype=np.float64)
        return {"expected_rank":z.copy(),"median_rank":z.copy(),"rank_p90":z.copy(),
                "pairwise_strength":z.copy(),"world_breadth":z.copy(),"rank_stability":z.copy(),
                "ordinal_world_count":np.array([0],dtype=np.int32),"_rank_matrix":np.empty((n,0),dtype=np.int16)}
    k=min(int(max_worlds),trials)
    world_idx=np.linspace(0,trials-1,num=k,dtype=np.int32) if k<trials else np.arange(trials,dtype=np.int32)
    sub=sims[:,world_idx]
    field_scores=_score_rows(field_rows,sub)
    sorted_field=np.sort(field_scores,axis=0)
    ranks=np.empty((n,k),dtype=np.int16 if fs<32767 else np.int32)
    batch=512
    for start in range(0,n,batch):
        stop=min(n,start+batch)
        cand=_score_rows(rows[start:stop],sub)
        rr=np.empty_like(cand,dtype=np.int32)
        for j in range(k):
            right=np.searchsorted(sorted_field[:,j],cand[:,j],side="right")
            rr[:,j]=1 + fs - right
        ranks[start:stop]=rr.astype(ranks.dtype,copy=False)
    rf=ranks.astype(np.float32)
    expected=rf.mean(axis=1)
    median=np.median(rf,axis=1)
    p90=np.quantile(rf,0.90,axis=1)
    pairwise=(1.0-(rf-1.0)/max(1.0,float(fs))).mean(axis=1)
    top1=max(1,int(math.ceil(fs*0.01)))
    breadth=(rf<=top1).mean(axis=1)
    q25=np.quantile(rf,0.25,axis=1); q75=np.quantile(rf,0.75,axis=1)
    stability=np.clip(1.0-(q75-q25)/max(1.0,float(fs)),0.0,1.0)
    return {"expected_rank":expected.astype(np.float32),"median_rank":median.astype(np.float32),
            "rank_p90":p90.astype(np.float32),"pairwise_strength":pairwise.astype(np.float32),
            "world_breadth":breadth.astype(np.float32),"rank_stability":stability.astype(np.float32),
            "ordinal_world_count":np.array([k],dtype=np.int32),"_rank_matrix":ranks}


def _evaluate(rows: np.ndarray, sims: np.ndarray, thresholds: tuple[np.ndarray,np.ndarray,np.ndarray,np.ndarray,np.ndarray], batch: int = 224) -> dict[str,np.ndarray]:
    win_t, top10_t, top01_t, top0100_t, top0050_t = thresholds
    n = len(rows); trials = sims.shape[1]
    win = np.zeros(n,dtype=np.int32); top10=np.zeros(n,dtype=np.int32); top01=np.zeros(n,dtype=np.int32); top0100=np.zeros(n,dtype=np.int32); top0050=np.zeros(n,dtype=np.int32)
    mean=np.zeros(n,dtype=np.float32); p95=np.zeros(n,dtype=np.float32); p99=np.zeros(n,dtype=np.float32)
    k95=max(0,int(math.ceil(.95*trials))-1); k99=max(0,int(math.ceil(.99*trials))-1)
    for start in range(0,n,batch):
        r=rows[start:start+batch]
        sc=_score_rows(r,sims)
        sl=slice(start,start+len(r))
        win[sl]=(sc>=win_t).sum(axis=1)
        top10[sl]=(sc>=top10_t).sum(axis=1)
        top01[sl]=(sc>=top01_t).sum(axis=1)
        top0100[sl]=(sc>=top0100_t).sum(axis=1)
        top0050[sl]=(sc>=top0050_t).sum(axis=1)
        mean[sl]=sc.mean(axis=1)
        part=np.partition(sc,(k95,k99),axis=1)
        p95[sl]=part[:,k95]; p99[sl]=part[:,k99]
    return {"win_count":win,"top10_count":top10,"top01_count":top01,"top0100_count":top0100,"top0050_count":top0050,"mean":mean,"p95":p95,"p99":p99,"trials":np.full(n,trials,dtype=np.int32)}


def _simulate_phase2(rows: np.ndarray, cal: Calibration, cfg: Config, public_field_rows: np.ndarray | None = None) -> dict[str, Any]:
    if public_field_rows is None:
        if not cfg.test_mode:
            raise RuntimeError("ENGINE_INTEGRITY_HALT:PUBLIC_FIELD_SOURCE_REQUIRED_PRE_PHASE2")
        public_field_rows = rows
    base = {"mu":cal.mu,"sigma":cal.sigma,"pos":cal.pos,"team":cal.team,"td_event_lambda":pd.to_numeric(cal.frame.get("TD_EVENT_LAMBDA",pd.Series(np.zeros(len(cal.frame)))),errors="coerce").fillna(0.0).to_numpy(np.float32),"td_event_scale":pd.to_numeric(cal.frame.get("TD_EVENT_SCALE",pd.Series(np.zeros(len(cal.frame)))),errors="coerce").fillna(0.0).to_numpy(np.float32)}
    field_source = np.asarray(public_field_rows, dtype=np.int32)
    if field_source.ndim != 2 or field_source.shape[1] != ROSTER_SIZE or len(field_source) <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:PUBLIC_FIELD_SOURCE_INVALID")
    field_source_hash = _array_hash(field_source)
    field_idx, public_field_joint_receipt = _public_field_indices(field_source, cal, cfg.field_size, cfg.seed, return_receipt=True)
    field_rows = field_source[field_idx]
    top01_n=max(1,int(math.ceil(cfg.field_size*0.001)))
    top0100_n=max(1,int(math.ceil(cfg.field_size*0.0001)))
    top0050_n=max(1,int(math.ceil(cfg.field_size*0.00005)))
    sims,event_world_receipt=_simulate_players(base,cfg.base_trials,cfg.seed ^ 0xB453,return_event_receipt=True)
    thresholds=_field_thresholds(field_rows,sims,top01_n,top0100_n,top0050_n)
    metrics=_evaluate(rows,sims,thresholds)
    ordinal_world=_ordinal_world_evidence(rows,field_rows,sims,cfg.field_size,max_worlds=256)
    metrics.update({k:v for k,v in ordinal_world.items() if k not in {"ordinal_world_count","_rank_matrix"}})
    n=len(rows)
    trials=metrics["trials"].copy(); top01=metrics["top01_count"].copy(); top0100=metrics["top0100_count"].copy(); top0050=metrics["top0050_count"].copy(); top10=metrics["top10_count"].copy(); win=metrics["win_count"].copy()

    rates=top01/trials
    cutoff_target=max(cfg.board_size*5,int(math.ceil(n*.01)))
    cutoff_target=min(max(1,cutoff_target),n)
    cutoff_idx=np.argsort(rates,kind="stable")[-cutoff_target]
    lcb,ucb=_wilson(top01,trials)
    cutoff_l=float(lcb[cutoff_idx]); cutoff_u=float(ucb[cutoff_idx]); cutoff_rate=float(rates[cutoff_idx])
    overlap=(ucb>=cutoff_l)&(lcb<=cutoff_u)
    bubble=np.flatnonzero(overlap)
    if bubble.size>cfg.bubble_cap:
        dist=np.abs(rates[bubble]-cutoff_rate)
        tail=-_pct(metrics["p99"])[bubble]*1e-6
        bubble=bubble[np.argsort(dist+tail,kind="stable")[:cfg.bubble_cap]]
    extra_total=0
    unresolved=bubble.copy()
    batch_no=0
    while unresolved.size and int(trials[unresolved].max()) < cfg.max_trials:
        batch_no += 1
        batch_trials=min(cfg.extra_batch_trials, cfg.max_trials-int(trials[unresolved].min()))
        if batch_trials<=0: break
        exsims=_simulate_players(base,batch_trials,(cfg.seed ^ 0xB453)+batch_no*104729)
        exthr=_field_thresholds(field_rows,exsims,top01_n,top0100_n,top0050_n)
        ev=_evaluate(rows[unresolved],exsims,exthr)
        top01[unresolved]+=ev["top01_count"]; top0100[unresolved]+=ev["top0100_count"]; top0050[unresolved]+=ev["top0050_count"]; top10[unresolved]+=ev["top10_count"]; win[unresolved]+=ev["win_count"]
        trials[unresolved]+=batch_trials; extra_total += int(len(unresolved)*batch_trials)
        # Cutoff boundary is recomputed from the updated rates. Non-bubble candidates keep base trials.
        rates=top01/trials
        cutoff_idx=np.argsort(rates,kind="stable")[-cutoff_target]
        lcb,ucb=_wilson(top01,trials)
        cutoff_l=float(lcb[cutoff_idx]); cutoff_u=float(ucb[cutoff_idx])
        fail=ucb[unresolved] < cutoff_l
        pas=lcb[unresolved] > cutoff_u
        maxed=trials[unresolved] >= cfg.max_trials
        keep=~(fail|pas|maxed)
        unresolved=unresolved[keep]
    lcb,ucb=_wilson(top01,trials)
    top0100_lcb,top0100_ucb=_wilson(top0100,trials)
    top0050_lcb,top0050_ucb=_wilson(top0050,trials)
    metrics.update({
        "win_count":win,"top10_count":top10,"top01_count":top01,"top0100_count":top0100,"top0050_count":top0050,"trials":trials,
        "win_rate":win/trials,"top10_rate":top10/trials,"top01_rate":top01/trials,"top0100_rate":top0100/trials,"top0050_rate":top0050/trials,
        "top01_lcb":lcb,"top01_ucb":ucb,"top0100_lcb":top0100_lcb,"top0100_ucb":top0100_ucb,"top0050_lcb":top0050_lcb,"top0050_ucb":top0050_ucb,
    })
    return {
        "metrics":metrics,"field_idx":field_idx,"top01_n":top01_n,"top0100_n":top0100_n,"top0050_n":top0050_n,
        "bubble_found":int(len(bubble)),"bubble_unresolved":int(len(unresolved)),"extra_total":int(extra_total),
        "cutoff_lcb":float(cutoff_l),"cutoff_ucb":float(cutoff_u),"fake_field_size":int(len(field_idx)),
        "ordinal_world_count":int(ordinal_world["ordinal_world_count"][0]),
        "ordinal_rank_matrix":ordinal_world["_rank_matrix"],
        "base_sims":sims,
        "public_field_patch_id":PUBLIC_FIELD_UNIVERSE_DECOUPLING_PATCH_ID,
        "public_field_source":"PRE_PHASE2_CALIBRATED_CANDIDATE_UNIVERSE",
        "public_field_source_lineups":int(len(field_source)),
        "public_field_source_hash":field_source_hash,
        "public_field_phase2_conditioned":bool(public_field_rows is rows),
        "public_field_joint_dependence_receipt":public_field_joint_receipt,
        "team_event_native_world_patch_id":TEAM_EVENT_NATIVE_WORLD_PATCH_ID,
        "team_event_native_world_receipt":event_world_receipt,
    }



def _can_add_with_caps(candidate: int, kept: list[int], rows: np.ndarray, pmeta: dict[str, np.ndarray], cal: Calibration, cfg: Config) -> bool:
    player_counts = np.zeros(len(cal.ids), dtype=np.int16)
    cpt_counts = np.zeros(len(cal.ids), dtype=np.int16)
    script_counts: dict[int, int] = {}
    for i in kept:
        row = rows[int(i)]
        player_counts[row] += 1
        cpt_counts[row[0]] += 1
        script = int(pmeta["same_cpt_team"][int(i)])
        script_counts[script] = script_counts.get(script, 0) + 1
    row = rows[int(candidate)]
    script = int(pmeta["same_cpt_team"][int(candidate)])
    return bool(
        not np.any(player_counts[row] >= cfg.player_exposure_cap)
        and cpt_counts[row[0]] < cfg.captain_exposure_cap
        and script_counts.get(script, 0) < cfg.script_exposure_cap
    )

def _defensive_balanced_reserve_indices(rows: np.ndarray, pmeta: dict[str,np.ndarray], cal: Calibration, cfg: Config) -> np.ndarray:
    """Bounded, player-name-blind reserve for balanced defensive Showdown worlds.

    Eligibility always remains open elsewhere; this only reserves up to two terminal seats
    on 20+ entry boards when the prelock total is in the defensive/medium environment
    (<=47). Shape: WR CPT, 3-3 split, exactly one QB, two RBs split one per team,
    same-team DST with the CPT, no kicker. Ranking is frozen prelock calibration score.
    """
    if int(cfg.board_size) < 20 or len(rows) <= 0:
        return np.empty(0, dtype=np.int32)
    total = float(pd.to_numeric(cal.frame.get("O/U", pd.Series([99.0])), errors="coerce").dropna().iloc[0]) if len(cal.frame) else 99.0
    if total > 47.0:
        return np.empty(0, dtype=np.int32)
    score = np.asarray(pmeta.get("score", np.zeros(len(rows))), dtype=np.float64)
    out = []
    for i, row in enumerate(rows):
        ps = cal.pos[row]
        teams = cal.team[row]
        cpt_team = cal.team[row[0]]
        if str(cal.pos[row[0]]) != "WR":
            continue
        if int(np.sum(ps == "QB")) != 1 or int(np.sum(ps == "RB")) != 2 or int(np.sum(ps == "DST")) != 1 or int(np.sum(ps == "K")) != 0:
            continue
        if int(np.sum(teams == cpt_team)) != 3:
            continue
        dst_slot = np.flatnonzero(ps == "DST")
        qb_slot = np.flatnonzero(ps == "QB")
        if len(dst_slot) != 1 or len(qb_slot) != 1:
            continue
        if teams[dst_slot[0]] != cpt_team or teams[qb_slot[0]] == cpt_team:
            continue
        rb_teams = set(teams[ps == "RB"].tolist())
        if rb_teams != set(cal.frame["TEAM"].astype(str).unique().tolist()):
            continue
        out.append(i)
    if not out:
        return np.empty(0, dtype=np.int32)
    arr = np.asarray(out, dtype=np.int32)
    order = np.lexsort((arr, -score[arr]))
    return arr[order[:min(2, len(arr))]]


def _defensive_balanced_neighbor_door_indices(
    rows: np.ndarray, roots: np.ndarray, pmeta: dict[str,np.ndarray], cal: Calibration, *, max_doors: int = 8
) -> np.ndarray:
    """Prelock-only local ordinal neighborhood around certified defensive roots.

    Multiple roots define a consensus player core.  A candidate door must keep the
    CPT and the full consensus core, then alter exactly one secondary player.
    We keep only the strongest prelock representative per position/team mutation
    door so terminal ranks 2..N explore distinct nearby championship paths instead
    of unrelated high-MC rows or repeated same-door clones.
    """
    roots=np.asarray(roots,dtype=np.int32).reshape(-1)
    if len(roots)<2:
        return np.empty(0,dtype=np.int32)
    root_rows=rows[roots]
    consensus=set(map(int,root_rows[0].tolist()))
    for rr in root_rows[1:]:
        consensus.intersection_update(map(int,rr.tolist()))
    if not consensus:
        return np.empty(0,dtype=np.int32)
    cpt=int(root_rows[0,0])
    score=np.asarray(pmeta.get("score",np.zeros(len(rows))),dtype=np.float64)
    root_set=set(map(int,roots.tolist()))
    root_variable=set()
    for rr in root_rows:
        root_variable.update(set(map(int,rr.tolist()))-consensus)
    root_variable_positions={str(cal.pos[j]) for j in root_variable}
    door_best={}
    for i,row in enumerate(rows):
        if i in root_set or int(row[0])!=cpt:
            continue
        rset=set(map(int,row.tolist()))
        if not consensus.issubset(rset):
            continue
        added=sorted(rset-consensus)
        if len(added)!=1:
            continue
        a=int(added[0])
        # Door identity is role class first, not player identity.  The first local
        # ordinal cycle therefore covers distinct structural mutations instead of
        # spending ranks 3/4/5 on clones of the role door already represented by
        # the certified roots.
        key=str(cal.pos[a])
        prev=door_best.get(key)
        if prev is None or (float(score[i]),-i)>(float(score[prev]),-prev):
            door_best[key]=int(i)
    novel=[]; repeated=[]
    for i in door_best.values():
        added_player=next(iter(set(map(int,rows[i].tolist()))-consensus))
        (repeated if str(cal.pos[added_player]) in root_variable_positions else novel).append(int(i))
    novel.sort(key=lambda i:(-float(score[i]),int(i)))
    repeated.sort(key=lambda i:(-float(score[i]),int(i)))
    # Adjacent elite ranks use new role doors first.  Repeated root-role doors stay
    # outside the protected neighborhood tier and can re-enter later through the
    # ordinary global order score.
    reps=novel[:max(0,int(max_doors))]
    return np.asarray(reps,dtype=np.int32)


def _resolve_native_portfolio_budget(field_size: int) -> tuple[int, dict[str, Any]]:
    raw_max = os.environ.get("APEX_MAX_ENTRIES")
    raw_user = os.environ.get("APEX_USER_ENTRIES")
    if raw_max not in (None, ""):
        profile = entry_limit_game.build_entry_limit_profile(field_size=int(field_size), max_entries=raw_max, user_entries=raw_user)
        return int(profile.our_entry_budget), {
            "PATCH_ID": "NFL_SD_MAX_ENTRY_NATIVE_PORTFOLIO_v1",
            "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
            "CONTEST_MAX_ENTRIES": int(profile.contest_max_entries),
            "USER_ENTRY_BUDGET": int(profile.our_entry_budget),
            "REGIME": str(profile.regime),
            "SOURCE": "APEX_MAX_ENTRIES/APEX_USER_ENTRIES",
        }
    return 10, {
        "PATCH_ID": "NFL_SD_MAX_ENTRY_NATIVE_PORTFOLIO_v1",
        "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
        "SOURCE": "LEGACY_EXPLICIT_CONFIG_OR_TEST_DEFAULT",
        "USER_ENTRY_BUDGET": 10,
    }


def _effective_portfolio_caps(cfg: Config, target: int) -> tuple[int, int, int]:
    """Scale portfolio caps to requested entry count instead of using small-board absolutes."""
    target=max(1,int(target))
    if target <= 10:
        return int(cfg.player_exposure_cap), int(cfg.captain_exposure_cap), int(cfg.script_exposure_cap)
    player_cap=max(int(cfg.player_exposure_cap), int(math.ceil(0.90*target)))
    captain_cap=max(int(cfg.captain_exposure_cap), int(math.ceil(0.30*target)))
    script_cap=max(int(cfg.script_exposure_cap), int(math.ceil(0.50*target)))
    return min(target,player_cap),min(target,captain_cap),min(target,script_cap)


def _extreme_special_teams_closure_indices(
    rows: np.ndarray,
    pmeta: dict[str,np.ndarray],
    cal: Calibration,
    global_score: np.ndarray,
    top01_rate: np.ndarray,
    p99: np.ndarray,
    target: int,
) -> np.ndarray:
    """Bounded player-name-blind closure for extreme 1-5/5-1 K+DST game scripts.

    Large multi-entry portfolios need explicit representation of low-scoring / defensive
    worlds without hardcoding any team or player.  For the highest-ceiling captain roots,
    preserve a few local variants from both extreme team-split directions when a kicker
    and defense are jointly present.  This is membership coverage only; postlock outcomes
    are never consumed.
    """
    target=int(target)
    if target < 20 or len(rows)==0:
        return np.empty(0,dtype=np.int32)
    cpt_count=min(5,max(1,int(math.ceil(target/20.0))))
    variants=3 if target>=40 else 1
    max_seats=min(target,max(2,int(math.ceil(0.35*target))))
    cpts=np.unique(rows[:,0])
    cpt_quality=np.asarray(cal.p99,dtype=np.float64)
    cpts=sorted((int(x) for x in cpts),key=lambda x:(-float(cpt_quality[x]),x))[:cpt_count]
    score=np.asarray(global_score,dtype=np.float64)
    t01=np.asarray(top01_rate,dtype=np.float64)
    tail=np.asarray(p99,dtype=np.float64)
    same=np.asarray(pmeta['same_cpt_team'],dtype=np.int16)
    out=[]
    for cpt in cpts:
        for split in (1,5):
            candidates=[]
            for i,row in enumerate(rows):
                if int(row[0])!=cpt or int(same[i])!=split:
                    continue
                ps=cal.pos[row]
                if not (np.any(ps=='DST') and np.any(ps=='K')):
                    continue
                candidates.append(i)
            if not candidates:
                continue
            arr=np.asarray(candidates,dtype=np.int32)
            # Global score owns the root; championship rate and tail break close ties.
            order=np.lexsort((arr,-tail[arr],-t01[arr],-score[arr]))
            out.extend(int(x) for x in arr[order[:variants]])
            if len(out)>=max_seats:
                break
        if len(out)>=max_seats:
            break
    # stable unique
    seen=set(); uniq=[]
    for i in out:
        if i not in seen:
            seen.add(i); uniq.append(i)
    return np.asarray(uniq[:max_seats],dtype=np.int32)


def _td_event_dominant_onslaught_reserve_indices(
    rows: np.ndarray,
    pmeta: dict[str,np.ndarray],
    cal: Calibration,
    target: int,
) -> tuple[np.ndarray,dict[str,Any]]:
    """Bounded prelock reserve for a dominant TD-event Captain onslaught family.

    This lane is player-name blind and uses only frozen prelock market/role/ownership
    evidence. It exists to prevent a dominant touchdown-event captain family from
    being erased when median/global MC ranks compress that captain's asymmetric tail.
    It is deliberately narrow: large-board only, requires a dominant skill-position
    TD-event captain, 5-1 same-team geometry, same-team QB + DST, and exactly one
    opposing skill-position bring-back. It does not consume postlock outcomes.
    """
    target=int(target)
    receipt={
        "PATCH_ID":TD_EVENT_DOMINANT_ONSLAUGHT_RESERVE_PATCH_ID,
        "ACTIVE":False,
        "SELECTED_PHASE2_INDICES":[],
        "POSTLOCK_INPUT_USED":False,
        "PLAYER_NAME_LOGIC":False,
        "MEMBERSHIP_MUTATION":"BOUNDED_PROTECTED_RESERVE_ONLY",
    }
    if target < 20 or len(rows)==0:
        receipt["REASON"]="TARGET_TOO_SMALL_OR_EMPTY"
        return np.empty(0,dtype=np.int32),receipt
    frame=cal.frame
    if "TD_EVENT_LAMBDA" not in frame.columns:
        receipt["REASON"]="TD_EVENT_MARKET_UNAVAILABLE"
        return np.empty(0,dtype=np.int32),receipt
    lam=pd.to_numeric(frame["TD_EVENT_LAMBDA"],errors="coerce").fillna(0.0).to_numpy(np.float64)
    mp=pd.to_numeric(frame.get("MULTI_PATH_CEILING",pd.Series(np.zeros(len(frame)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    pos=np.asarray(cal.pos,dtype=object); team=np.asarray(cal.team,dtype=object)
    cpts=np.unique(rows[:,0]).astype(np.int32,copy=False)
    eligible_cpts=np.asarray([int(i) for i in cpts if str(pos[int(i)]) in {"RB","WR","TE"} and float(lam[int(i)])>0.0],dtype=np.int32)
    if not len(eligible_cpts):
        receipt["REASON"]="NO_SKILL_TD_EVENT_CAPTAIN"
        return np.empty(0,dtype=np.int32),receipt
    cap_event=lam[eligible_cpts]*(0.70+0.30*np.clip(mp[eligible_cpts],0.0,1.0))
    order=np.lexsort((eligible_cpts,-cap_event))
    ranked=eligible_cpts[order]
    top=int(ranked[0]); top_score=float(cap_event[order[0]])
    second_score=float(cap_event[order[1]]) if len(ranked)>1 else 0.0
    dominance=float(top_score/max(second_score,1e-12)) if second_score>0 else float("inf")
    receipt.update({
        "DOMINANT_CAPTAIN_INDEX":top,
        "DOMINANT_CAPTAIN_POSITION":str(pos[top]),
        "DOMINANT_TD_EVENT_LAMBDA":float(lam[top]),
        "DOMINANT_MULTI_PATH":float(mp[top]),
        "DOMINANCE_RATIO":dominance,
        "DOMINANCE_MIN":1.25,
        "TD_EVENT_LAMBDA_MIN":0.35,
    })
    if float(lam[top]) < 0.35 or dominance < 1.25:
        receipt["REASON"]="NO_DOMINANT_TD_EVENT_CAPTAIN"
        return np.empty(0,dtype=np.int32),receipt

    same=np.asarray(pmeta["same_cpt_team"],dtype=np.int16)
    cpt_team=team[top]
    cand=[]
    for raw in np.flatnonzero((rows[:,0]==top)&(same==5)):
        i=int(raw); row=rows[i]
        same_flex=row[1:][team[row[1:]]==cpt_team]
        opp_flex=row[1:][team[row[1:]]!=cpt_team]
        if len(opp_flex)!=1:
            continue
        if not np.any(pos[same_flex]=="QB") or not np.any(pos[same_flex]=="DST"):
            continue
        if str(pos[int(opp_flex[0])]) not in {"RB","WR","TE"}:
            continue
        cand.append(i)
    if not cand:
        receipt["REASON"]="NO_QUALIFIED_5_1_QB_DST_BRINGBACK_FAMILY"
        return np.empty(0,dtype=np.int32),receipt
    arr=np.asarray(cand,dtype=np.int32)
    event_line=np.sum(lam[rows[arr]],axis=1)+0.5*lam[rows[arr,0]]
    multipath_line=np.sum(mp[rows[arr]],axis=1)+0.5*mp[rows[arr,0]]
    calibration=np.asarray(pmeta.get("score",np.zeros(len(rows))),dtype=np.float64)[arr]
    flex_own=np.clip(np.asarray(getattr(cal,"flex_ownership",cal.ownership),dtype=np.float64),0.0005,0.98)
    cpt_own=np.clip(np.asarray(getattr(cal,"captain_ownership",np.asarray(cal.ownership,dtype=float)/6.0),dtype=np.float64),0.0005,0.65)
    logown=np.log(cpt_own[rows[arr,0]])+np.log(flex_own[rows[arr,1:]]).sum(axis=1)
    # Local ranks are intentional: this is a structural-family reserve, so a global
    # percentile cannot erase the family again. Existing calibration remains a bounded
    # 10% signal rather than admission authority.
    family_score=(
        0.55*_pct(event_line) +
        0.25*_pct(multipath_line) +
        0.10*_pct(calibration) +
        0.10*(1.0-_pct(logown))
    )
    reserve_n=min(len(arr),max(2,min(6,int(math.ceil(target/40.0)))))
    pick_order=np.lexsort((arr,-family_score))
    selected=arr[pick_order[:reserve_n]]
    receipt.update({
        "ACTIVE":bool(len(selected)),
        "QUALIFIED_FAMILY_ROWS":int(len(arr)),
        "RESERVE_SEATS":int(reserve_n),
        "SELECTED_PHASE2_INDICES":[int(i) for i in selected.tolist()],
        "SCORE_WEIGHTS":{"TD_EVENT":0.55,"MULTI_PATH":0.25,"CALIBRATION":0.10,"LEVERAGE":0.10},
        "GEOMETRY":"5_1__CPT_TEAM_QB_PLUS_DST__ONE_OPP_SKILL_BRINGBACK",
    })
    return selected,receipt

def _marginal_world_portfolio_select(
    rows: np.ndarray,
    pmeta: dict[str,np.ndarray],
    metrics: dict[str,np.ndarray],
    base_quality: np.ndarray,
    protected: np.ndarray,
    target: int,
    player_cap: int,
    captain_cap: int,
    script_cap: int,
) -> np.ndarray:
    """Greedy marginal world coverage under hard scaled exposure constraints.

    Performance contract: keep the exact qualified candidate surface and exact portfolio
    semantics while vectorizing repeated eligibility/score checks. Never reduce Phase-2
    membership, use First-N, or restore a hard Top-K admission cap to make 150-max fit.
    """
    n=len(rows); target=int(target)
    same=np.asarray(pmeta['same_cpt_team'],dtype=np.int16)
    chosen=[]
    chosen_mask=np.zeros(n,dtype=bool)
    player_counts=np.zeros(int(rows.max())+1 if rows.size else 0,dtype=np.int16)
    cpt_counts=np.zeros_like(player_counts)

    # Precompute static row geometry once. The legacy implementation rebuilt these
    # values for every candidate on every portfolio seat, which becomes quadratic-ish
    # Python work at 150-max scale.
    pos=np.asarray(metrics['_pos'],dtype=object)
    row_pos=pos[rows]
    has_dst=np.any(row_pos=='DST',axis=1)
    has_k=np.any(row_pos=='K',axis=1)
    pattern_code=(same.astype(np.int32)*4 + has_dst.astype(np.int32)*2 + has_k.astype(np.int32))
    max_script=max(8,int(np.max(same))+2 if len(same) else 8)
    max_pattern=max(32,int(np.max(pattern_code))+2 if len(pattern_code) else 32)
    script_counts=np.zeros(max_script,dtype=np.int16)
    pattern_counts=np.zeros(max_pattern,dtype=np.int16)

    head_n=championship_head_policy.head_size(target)

    def can_add_scalar(i:int, seat:int)->bool:
        if int(seat) <= head_n:
            return True
        row=rows[i]; script=int(same[i])
        return bool(
            not np.any(player_counts[row]>=player_cap)
            and cpt_counts[row[0]]<captain_cap
            and script_counts[script]<script_cap
        )

    def add(i:int)->None:
        row=rows[i]; script=int(same[i]); pat=int(pattern_code[i])
        chosen.append(i); chosen_mask[i]=True
        player_counts[row]+=1; cpt_counts[row[0]]+=1
        script_counts[script]+=1; pattern_counts[pat]+=1

    # Preserve bounded structural closure first, subject to the same hard portfolio caps.
    for raw in protected:
        i=int(raw)
        if not chosen_mask[i] and can_add_scalar(i, len(chosen)+1):
            add(i)
        if len(chosen)>=target:
            return np.asarray(chosen[:target],dtype=np.int32)

    q=np.asarray(base_quality,dtype=np.float64)
    # This is a terminal scoring working set only, not Phase-2 membership authority.
    # It preserves the legacy target*160 breadth exactly while eliminating repeated
    # Python candidate scans.
    pool_n=min(n,max(4000,target*160))
    pool=np.argsort(q,kind='stable')[-pool_n:][::-1].astype(np.int32,copy=False)
    pool_rows=rows[pool]
    pool_cpt=pool_rows[:,0]
    pool_script=same[pool].astype(np.int32,copy=False)
    pool_pattern=pattern_code[pool].astype(np.int32,copy=False)
    pool_q=q[pool]

    while len(chosen)<target:
        seat=len(chosen)+1
        eligible=~chosen_mask[pool]

        if seat <= head_n:
            scores=np.where(eligible,pool_q,-np.inf)
        else:
            # Vectorized exact equivalent of legacy can_add() + marginal score.
            counts=player_counts[pool_rows]
            eligible &= np.all(counts < player_cap,axis=1)
            eligible &= cpt_counts[pool_cpt] < captain_cap
            eligible &= script_counts[pool_script] < script_cap
            if not np.any(eligible):
                raise RuntimeError(
                    f"ENGINE_INTEGRITY_FAILURE:NFL_SHOWDOWN_PORTFOLIO_CONSTRAINT_INFEASIBLE:{len(chosen)}:{target}:"
                    f"P{player_cap}:C{captain_cap}:S{script_cap}"
                )
            denom=max(1,len(chosen))
            saturation=np.mean(counts,axis=1,dtype=np.float64)/float(denom)
            split_bonus=1.0/np.sqrt(1.0+script_counts[pool_script].astype(np.float64))
            cpt_bonus=1.0/np.sqrt(1.0+cpt_counts[pool_cpt].astype(np.float64))
            pattern_bonus=1.0/np.sqrt(1.0+pattern_counts[pool_pattern].astype(np.float64))
            load=np.max(counts,axis=1).astype(np.float64)/float(max(1,player_cap))
            scores=(
                pool_q + 0.045*split_bonus + 0.030*cpt_bonus + 0.030*pattern_bonus
                - 0.070*saturation - 0.025*load
            )
            scores=np.where(eligible,scores,-np.inf)

        best_score=float(np.max(scores))
        if not np.isfinite(best_score):
            raise RuntimeError(
                f"ENGINE_INTEGRITY_FAILURE:NFL_SHOWDOWN_PORTFOLIO_CONSTRAINT_INFEASIBLE:{len(chosen)}:{target}:"
                f"P{player_cap}:C{captain_cap}:S{script_cap}"
            )
        # Legacy tie contract: when scores tie, choose the smallest Phase-2 index.
        ties=pool[scores==best_score]
        best=int(np.min(ties))
        add(best)

    return np.asarray(chosen,dtype=np.int32)



def _board_family_consensus_evidence(
    chosen: np.ndarray,
    rows: np.ndarray,
    metrics: dict[str, np.ndarray],
    *,
    min_board_size: int = 40,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Stable-tail/family context for a frozen terminal board.

    This evidence is discovery/shrinkage context and an exact-score tie-break only;
    it is never standalone terminal authority. This is not raw-MC authority. Every MC-derived neighbor channel is converted to
    a within-board percentile before aggregation. The signal rewards qualified
    construction families that repeatedly carry strong relative tail evidence while
    preserving frozen membership.
    """
    chosen=np.asarray(chosen,dtype=np.int32)
    m=int(len(chosen))
    if m == 0:
        return np.asarray([],dtype=np.float64), {
            "PATCH_ID":TERMINAL_FAMILY_CONSENSUS_ORDER_PATCH_ID,
            "ACTIVE":False,"REASON":"EMPTY_BOARD","MEMBERSHIP_MUTATION":False,
            "FAMILY_CONSENSUS_ROLE":"DISCOVERY_PRIOR_SHRINKAGE_AND_EXACT_SCORE_TIEBREAK_ONLY","TERMINAL_AUTHORITY":False,
            "RAW_MC_LITERAL_AUTHORITY":False,
        }
    if m < int(min_board_size):
        return np.zeros(m,dtype=np.float64), {
            "PATCH_ID":TERMINAL_FAMILY_CONSENSUS_ORDER_PATCH_ID,
            "ACTIVE":False,"REASON":f"BOARD_LT_{int(min_board_size)}",
            "MEMBERSHIP_MUTATION":False,
            "FAMILY_CONSENSUS_ROLE":"DISCOVERY_PRIOR_SHRINKAGE_AND_EXACT_SCORE_TIEBREAK_ONLY","TERMINAL_AUTHORITY":False,
            "RAW_MC_LITERAL_AUTHORITY":False,
        }

    board_rows=np.asarray(rows[chosen],dtype=np.int32)
    top01=np.asarray(metrics["top01_rate"],dtype=np.float64)[chosen]
    p95=np.asarray(metrics["p95"],dtype=np.float64)[chosen]
    p99=np.asarray(metrics["p99"],dtype=np.float64)[chosen]
    conf=np.asarray(metrics["global_order_confidence"],dtype=np.float64)[chosen]

    overlap=np.zeros((m,m),dtype=np.int8)
    sets=[set(map(int,r.tolist())) for r in board_rows]
    for i in range(m):
        si=sets[i]
        for j in range(i+1,m):
            v=len(si.intersection(sets[j]))
            overlap[i,j]=overlap[j,i]=v

    supports: dict[int,np.ndarray]={}
    neighbor_counts: dict[int,np.ndarray]={}
    for k in (3,4,5):
        max_top01=np.empty(m,dtype=np.float64)
        max_p95=np.empty(m,dtype=np.float64)
        max_p99=np.empty(m,dtype=np.float64)
        mean_conf=np.empty(m,dtype=np.float64)
        counts=np.zeros(m,dtype=np.int32)
        for i in range(m):
            neigh=np.flatnonzero((overlap[i] >= int(k)) & (np.arange(m) != i))
            counts[i]=int(len(neigh))
            if len(neigh):
                max_top01[i]=float(np.max(top01[neigh]))
                max_p95[i]=float(np.max(p95[neigh]))
                max_p99[i]=float(np.max(p99[neigh]))
                mean_conf[i]=float(np.mean(conf[neigh]))
            else:
                max_top01[i]=float(top01[i])
                max_p95[i]=float(p95[i])
                max_p99[i]=float(p99[i])
                mean_conf[i]=float(conf[i])
        # MC values are SIGNAL, never literal probability authority.
        supports[k]=(_pct(max_top01)+_pct(max_p95)+_pct(max_p99)+_pct(mean_conf))/4.0
        neighbor_counts[k]=counts

    family_score=0.90*supports[3] + 0.10*supports[5]
    backbone_breadth=_pct(neighbor_counts[3].astype(np.float64))
    score=0.975*family_score + 0.025*backbone_breadth
    receipt={
        "PATCH_ID":TERMINAL_FAMILY_CONSENSUS_ORDER_PATCH_ID,
        "ACTIVE":True,
        "MEMBERSHIP_MUTATION":False,
        "BOARD_SIZE":m,
        "FAMILY_CONSENSUS_ROLE":"DISCOVERY_PRIOR_SHRINKAGE_AND_EXACT_SCORE_TIEBREAK_ONLY","TERMINAL_AUTHORITY":False,
        "MC_METRICS_ROLE":"SIGNAL_NOT_TRUTH",
        "RAW_MC_LITERAL_AUTHORITY":False,
        "COMPARISON_SCOPE":"WITHIN_SLATE_BOARD_ONLY",
        "WEIGHTS":{"FAMILY_EVIDENCE":0.975,"BACKBONE_RECURRENCE_BREADTH":0.025,
                   "FAMILY_OVERLAP_3":0.90,"FAMILY_OVERLAP_4":0.00,"FAMILY_OVERLAP_5":0.10},
        "CHANNELS":["NEIGHBOR_MAX_TOP01_PCTL","NEIGHBOR_MAX_P95_PCTL","NEIGHBOR_MAX_P99_PCTL",
                    "NEIGHBOR_MEAN_GLOBAL_ORDER_CONFIDENCE_PCTL","OVERLAP3_NEIGHBOR_COUNT_PCTL"],
        "PLAYER_NAME_LOGIC":False,
        "POSTLOCK_INPUT_USED":False,
        "OVERLAP3_NEIGHBOR_COUNT_MIN":int(neighbor_counts[3].min()),
        "OVERLAP3_NEIGHBOR_COUNT_MAX":int(neighbor_counts[3].max()),
        "OVERLAP5_NEIGHBOR_COUNT_MIN":int(neighbor_counts[5].min()),
        "OVERLAP5_NEIGHBOR_COUNT_MAX":int(neighbor_counts[5].max()),
    }
    return np.asarray(score,dtype=np.float64),receipt


def _board_stable_tail_family_context(
    chosen: np.ndarray, rows: np.ndarray, metrics: dict[str,np.ndarray], global_confidence: np.ndarray
) -> tuple[np.ndarray,dict[str,Any]]:
    """Compatibility/public adapter name for context-only family evidence."""
    payload=dict(metrics)
    payload["global_order_confidence"]=np.asarray(global_confidence,dtype=np.float64)
    return _board_family_consensus_evidence(chosen,rows,payload)


def _family_aware_terminal_order(
    family_score: np.ndarray,
    global_signal_score: np.ndarray,
    protected_mask: np.ndarray,
) -> np.ndarray:
    """Return a membership-preserving order with bounded protected head first."""
    family_score=np.asarray(family_score,dtype=np.float64)
    global_signal_score=np.asarray(global_signal_score,dtype=np.float64)
    protected_mask=np.asarray(protected_mask,dtype=bool)
    n=len(family_score)
    if len(global_signal_score)!=n or len(protected_mask)!=n:
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:NFL_SD_FAMILY_ORDER_LENGTH_MISMATCH")
    local=np.arange(n,dtype=np.int32)
    def _order(ix: np.ndarray) -> np.ndarray:
        if len(ix)==0:
            return ix.astype(np.int32)
        return ix[np.lexsort((ix,-global_signal_score[ix],-family_score[ix]))].astype(np.int32)
    order=np.concatenate([_order(np.flatnonzero(protected_mask)),_order(np.flatnonzero(~protected_mask))]).astype(np.int32)
    if not np.array_equal(np.sort(order),local):
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:NFL_SD_TERMINAL_ORDER_MEMBERSHIP_MUTATION")
    return order


def _board_cross_world_core4_support(
    rows: np.ndarray,
    chosen: np.ndarray,
    rank_matrix: np.ndarray,
    pmeta: dict[str,np.ndarray],
    cal: Calibration,
    cfg: Config,
) -> tuple[np.ndarray,np.ndarray,np.ndarray,list[str]]:
    """Cross-world recurrent Core-4 evidence on the already-frozen board.

    For each common world, take the best 20% of frozen board rows by simulated
    contest rank, enumerate identity-only four-player cores, and count in how many
    distinct worlds each core survives.  A lineup receives its strongest and
    second-strongest Core-4 world breadth.  No realized results are consumed.

    The protected mask is a bounded NFL Showdown adapter only: on low-total large
    boards, at most three structurally coherent 1-5/5-1 one-QB K+DST rows from the
    two strongest recurrent core families may receive AI-Hybrid front context.
    Membership never changes here.
    """
    chosen=np.asarray(chosen,dtype=np.int32)
    b=int(len(chosen))
    ranks=np.asarray(rank_matrix)
    primary=np.zeros(b,dtype=np.float64)
    secondary=np.zeros(b,dtype=np.float64)
    protected=np.zeros(b,dtype=bool)
    family_ids=[""]*b
    if b<=0 or ranks.ndim!=2 or ranks.shape[0] != len(rows) or ranks.shape[1] < 2:
        return primary,secondary,protected,family_ids
    k=int(ranks.shape[1])
    board_ranks=ranks[chosen]
    top_n=max(1,min(b,int(math.ceil(0.20*b))))
    core_world_counts: dict[tuple[int,...],int] = {}
    # Distinct-world recurrence: each core contributes at most once per world.
    for w in range(k):
        col=board_ranks[:,w]
        if top_n>=b:
            top_local=np.arange(b,dtype=np.int32)
        else:
            top_local=np.argpartition(col,top_n-1)[:top_n]
        seen:set[tuple[int,...]]=set()
        for local in top_local.tolist():
            phase_idx=int(chosen[int(local)])
            players=sorted(set(map(int,rows[phase_idx].tolist())))
            if len(players)!=6:
                continue
            for core in itertools.combinations(players,4):
                seen.add(tuple(core))
        for core in seen:
            core_world_counts[core]=core_world_counts.get(core,0)+1
    row_best_core:list[tuple[int,...]|None]=[]
    for local,phase_idx in enumerate(chosen.tolist()):
        players=sorted(set(map(int,rows[int(phase_idx)].tolist())))
        vals=[]
        if len(players)==6:
            for core in itertools.combinations(players,4):
                vals.append((core_world_counts.get(tuple(core),0)/k,tuple(core)))
        vals.sort(key=lambda x:(-x[0],x[1]))
        if vals:
            primary[local]=float(vals[0][0]); row_best_core.append(vals[0][1])
            if len(vals)>1: secondary[local]=float(vals[1][0])
        else:
            row_best_core.append(None)

    # Global doctrine applies on every board; protection is bounded sport-mode context.
    total = float(pd.to_numeric(cal.frame.get("O/U", pd.Series([99.0])), errors="coerce").dropna().iloc[0]) if len(cal.frame) else 99.0
    if b < 20 or total > 42.0:
        return primary,secondary,protected,family_ids
    eligible=[]
    for local,phase_idx in enumerate(chosen.tolist()):
        i=int(phase_idx)
        if int(pmeta['same_cpt_team'][i]) not in (1,5):
            continue
        if int(pmeta['qb_count'][i]) != 1 or int(pmeta['k_count'][i]) < 1 or int(pmeta['dst_count'][i]) < 1:
            continue
        core=row_best_core[local]
        if core is None or primary[local] <= 0:
            continue
        eligible.append(local)
    if not eligible:
        return primary,secondary,protected,family_ids

    # Global head rule: select the strongest recurrent eligible rows directly.
    # Do not force a second family into the protected head solely for diversity.
    selected=sorted(eligible,key=lambda local:(-primary[local],-secondary[local],int(chosen[local])))[:3]
    for local in selected:
        core=row_best_core[local]
        family_ids[local]="NFL_SD_CORE4_" + (hashlib.sha256(repr(core).encode()).hexdigest()[:8] if core is not None else "FILL")
    for local in selected[:3]:
        protected[int(local)]=True
    return primary,secondary,protected,family_ids


def _championship_family_strength_head(
    rows: np.ndarray,
    sim: dict[str,Any],
    cal: Calibration,
    ownprod: np.ndarray,
    global_order_score: np.ndarray,
) -> tuple[list[int],dict[str,Any]]:
    """Rank exact six-player NFL Showdown families using prelock championship evidence.

    Family A is the strongest exact six-player set. Family B is eligible only when
    it is independently championship-grade AND is not merely a 5-of-6 mutation of
    Family A (<=4 shared identities). This is multi-path winner protection, not
    generic diversification. Raw MC values are converted to within-slate percentiles.
    """
    n=len(rows)
    receipt={
        "PATCH_ID":TWO_FAMILY_HEAD_PATCH_ID,"ACTIVE":False,"FAMILY_COUNT":0,
        "SELECTED_FAMILY_ANCHORS":[],"FAMILY_B_QUALIFIED":False,
        "FAMILY_B_MIN_STRENGTH_RATIO":0.88,"MAX_SHARED_PLAYERS_A_B":3,
        "POSTLOCK_INPUT_USED":False,"PLAYER_NAME_LOGIC":False,
    }
    if n<=0:
        receipt["REASON"]="EMPTY_PHASE2"
        return [],receipt
    m=sim.get("metrics",{})
    def arr(name,default=0.0):
        return np.asarray(m.get(name,np.full(n,default)),dtype=np.float64)
    p005=_pct(arr("top0050_rate")); p010=_pct(arr("top0100_rate")); p01=_pct(arr("top01_rate"))
    pair=_pct(arr("pairwise_strength")); breadth=_pct(arr("world_breadth")); stability=_pct(arr("rank_stability"))
    p99=_pct(arr("p99")); go=_pct(np.asarray(global_order_score,dtype=np.float64))
    lev=1.0-_pct(np.asarray(ownprod,dtype=np.float64))
    rz=pd.to_numeric(cal.frame.get("RED_ZONE_OPPORTUNITY",pd.Series(np.zeros(len(cal.frame)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    mp=pd.to_numeric(cal.frame.get("MULTI_PATH_CEILING",pd.Series(np.zeros(len(cal.frame)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    role_player=_pct(0.55*rz+0.45*mp)
    rz_player=_pct(rz)
    fam: dict[frozenset[int],list[int]]={}
    for i,row in enumerate(rows):
        key=frozenset(map(int,row.tolist()))
        if len(key)==6:
            fam.setdefault(key,[]).append(int(i))
    if not fam:
        receipt["REASON"]="NO_EXACT_SIX_FAMILIES"
        return [],receipt
    scored=[]
    for key,members in fam.items():
        idx=np.asarray(members,dtype=np.int32)
        # Family breadth rewards multiple independently strong role permutations but
        # sqrt damping prevents six mediocre Captain swaps from beating one elite family.
        narrow=float(0.55*np.max(p005[idx])+0.25*np.mean(np.sort(p005[idx])[-min(3,len(idx)):])+0.20*np.max(p010[idx]))
        pair_s=float(np.mean(np.sort(pair[idx])[-min(2,len(idx)):]))
        breadth_s=float(np.mean(np.sort(breadth[idx])[-min(2,len(idx)):]))
        stability_s=float(np.mean(np.sort(stability[idx])[-min(2,len(idx)):]))
        tail_s=float(np.max(p99[idx])); go_s=float(np.max(go[idx])); lev_s=float(np.max(lev[idx]))
        ids=np.asarray(sorted(key),dtype=np.int32)
        role_s=float(np.mean(role_player[ids])) if len(ids) else 0.0
        weak_rz=float(np.mean(np.sort(rz_player[ids])[:min(2,len(ids))])) if len(ids) else 0.0
        weak_role=float(np.mean(np.sort(role_player[ids])[:min(2,len(ids))])) if len(ids) else 0.0
        sibling_depth=min(1.0,len(idx)/3.0)
        score=(0.30*narrow+0.14*pair_s+0.12*breadth_s+0.10*stability_s+0.10*tail_s+
               0.10*go_s+0.06*role_s+0.04*lev_s+0.04*sibling_depth)
        anchor=int(idx[np.lexsort((idx,-go[idx],-p005[idx]))][0])
        scored.append((float(score),key,anchor,{"NARROW_TAIL":narrow,"PAIRWISE":pair_s,"WORLD_BREADTH":breadth_s,
            "RANK_STABILITY":stability_s,"P99":tail_s,"GLOBAL_ORDER":go_s,"ROLE_SUPPORT":role_s,"WEAK_LINK_RED_ZONE":weak_rz,"WEAK_LINK_ROLE":weak_role,
            "LEVERAGE":lev_s,"SIBLING_DEPTH":sibling_depth,"MEMBER_COUNT":int(len(idx))}))
    scored.sort(key=lambda x:(-x[0],x[2]))
    receipt["FAMILY_COUNT"]=len(scored)
    a=scored[0]; selected=[a[2]]
    rank_matrix=np.asarray(sim.get("ordinal_rank_matrix",np.empty((0,0))),dtype=np.float64)
    top005_cut=max(1,int(sim.get("top0050_n",1))); top010_cut=max(1,int(sim.get("top0100_n",top005_cut)))
    a_members=np.asarray(fam[a[1]],dtype=np.int32)
    a_best=(np.min(rank_matrix[a_members],axis=0) if rank_matrix.ndim==2 and rank_matrix.shape[0]==n and rank_matrix.shape[1]>0 else np.asarray([],dtype=np.float64))
    receipt["FAMILY_A"]={"ANCHOR":a[2],"STRENGTH":a[0],"EVIDENCE":a[3]}
    b_pick=None
    for b in scored[1:]:
        shared=len(a[1].intersection(b[1]))
        ratio=b[0]/max(a[0],1e-12)
        e=b[3]
        independent=(shared<=3)
        role_ratio=e["ROLE_SUPPORT"]/max(float(a[3]["ROLE_SUPPORT"]),1e-12)
        weak_rz_ratio=e["WEAK_LINK_RED_ZONE"]/max(float(a[3]["WEAK_LINK_RED_ZONE"]),1e-12)
        leverage_ratio=e["LEVERAGE"]/max(float(a[3]["LEVERAGE"]),1e-12)
        marginal005=marginal010=0
        if a_best.size:
            b_members=np.asarray(fam[b[1]],dtype=np.int32)
            b_best=np.min(rank_matrix[b_members],axis=0)
            marginal005=int(np.sum((b_best<=top005_cut) & (a_best>top005_cut)))
            marginal010=int(np.sum((b_best<=top010_cut) & (a_best>top010_cut)))
        floors=(e["NARROW_TAIL"]>=0.60 and e["PAIRWISE"]>=0.50 and e["WORLD_BREADTH"]>=0.45 and e["RANK_STABILITY"]>=0.45 and role_ratio>=0.92 and weak_rz_ratio>=0.75 and leverage_ratio>=0.60 and marginal005>=2 and marginal010>=2)
        if independent and ratio>=0.88 and floors:
            b_pick=(b,shared,ratio,marginal005,marginal010); break
    if b_pick is not None:
        b,shared,ratio,marginal005,marginal010=b_pick; selected.append(b[2])
        receipt["FAMILY_B_QUALIFIED"]=True
        receipt["FAMILY_B"]={"ANCHOR":b[2],"STRENGTH":b[0],"STRENGTH_RATIO_TO_A":ratio,"ROLE_SUPPORT_RATIO_TO_A":float(b[3]["ROLE_SUPPORT"])/max(float(a[3]["ROLE_SUPPORT"]),1e-12),"WEAK_LINK_RED_ZONE_RATIO_TO_A":float(b[3]["WEAK_LINK_RED_ZONE"])/max(float(a[3]["WEAK_LINK_RED_ZONE"]),1e-12),"LEVERAGE_RATIO_TO_A":float(b[3]["LEVERAGE"])/max(float(a[3]["LEVERAGE"]),1e-12),"SHARED_PLAYERS_WITH_A":shared,"MARGINAL_TOP0050_WORLDS_VS_A":int(marginal005),"MARGINAL_TOP0100_WORLDS_VS_A":int(marginal010),"EVIDENCE":b[3]}
    else:
        receipt["FAMILY_B"]={"QUALIFIED":False}
    receipt["SELECTED_FAMILY_ANCHORS"]=[int(i) for i in selected]
    receipt["ACTIVE"]=bool(len(selected)>=1)
    receipt["FAMILY_STRENGTH_WEIGHTS"]={"NARROW_TAIL":0.30,"PAIRWISE":0.14,"WORLD_BREADTH":0.12,"RANK_STABILITY":0.10,"P99":0.10,"GLOBAL_ORDER":0.10,"ROLE_SUPPORT":0.06,"LEVERAGE":0.04,"SIBLING_DEPTH":0.04}
    receipt["FAMILY_B_FLOORS"]={"STRENGTH_RATIO_TO_A":0.88,"NARROW_TAIL":0.60,"PAIRWISE":0.50,"WORLD_BREADTH":0.45,"RANK_STABILITY":0.45,"ROLE_SUPPORT_RATIO_TO_A":0.92,"WEAK_LINK_RED_ZONE_RATIO_TO_A":0.75,"LEVERAGE_RATIO_TO_A":0.60,"MIN_MARGINAL_TOP0050_WORLDS_VS_A":2,"MIN_MARGINAL_TOP0100_WORLDS_VS_A":2,"MAX_SHARED_PLAYERS":3}
    return selected,receipt

def _championship_captain_sibling_head(
    rows: np.ndarray,
    anchor_idx: int,
    sim: dict[str,Any],
    cal: Calibration,
    selector_score: np.ndarray,
    target: int,
) -> tuple[np.ndarray,dict[str,Any]]:
    """Bounded same-six Captain-role completion for the strongest championship family.

    This is not generic diversification. The player set is frozen to the anchor's six
    identities. Common-world simulations estimate which legal Captain role leads that
    exact family in upper-tail worlds. Alternates require both nontrivial posterior
    support and independent prelock red-zone/multi-path evidence.
    """
    target=int(target)
    if target < 2 or len(rows)==0 or anchor_idx<0 or anchor_idx>=len(rows):
        return np.empty(0,dtype=np.int32),{"PATCH_ID":CAPTAIN_SIBLING_HEAD_PATCH_ID,"ACTIVE":False,"REASON":"INELIGIBLE_TARGET_OR_ANCHOR","POSTLOCK_INPUT_USED":False}
    anchor_set=frozenset(map(int,rows[int(anchor_idx)].tolist()))
    sib=[]
    for i,row in enumerate(rows):
        if frozenset(map(int,row.tolist()))==anchor_set:
            sib.append(int(i))
    if len(sib)<2:
        return np.asarray([int(anchor_idx)],dtype=np.int32),{"PATCH_ID":CAPTAIN_SIBLING_HEAD_PATCH_ID,"ACTIVE":False,"REASON":"NO_LEGAL_CPT_SIBLINGS","POSTLOCK_INPUT_USED":False}
    sims=np.asarray(sim.get("base_sims"),dtype=np.float32)
    if sims.ndim!=2 or sims.shape[0]!=len(cal.ids) or sims.shape[1]<100:
        return np.asarray([int(anchor_idx)],dtype=np.int32),{"PATCH_ID":CAPTAIN_SIBLING_HEAD_PATCH_ID,"ACTIVE":False,"REASON":"COMMON_WORLD_SIM_UNAVAILABLE","POSTLOCK_INPUT_USED":False}
    sib_arr=np.asarray(sib,dtype=np.int32)
    scores=np.stack([_score_rows(rows[i:i+1],sims)[0] for i in sib_arr],axis=0)
    best_local=np.argmax(scores,axis=0)
    best_score=np.max(scores,axis=0)
    post=np.zeros(len(sib_arr),dtype=np.float64)
    tail_parts=[]
    for q,w in ((0.90,0.25),(0.95,0.35),(0.99,0.40)):
        threshold=float(np.quantile(best_score,q))
        mask=best_score>=threshold
        part=np.asarray([np.mean(best_local[mask]==j) if np.any(mask) else 0.0 for j in range(len(sib_arr))],dtype=np.float64)
        post += float(w)*part
        tail_parts.append((q,int(mask.sum()),part))
    rz=pd.to_numeric(cal.frame.get("RED_ZONE_OPPORTUNITY",pd.Series(np.zeros(len(cal.frame)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    mp=pd.to_numeric(cal.frame.get("MULTI_PATH_CEILING",pd.Series(np.zeros(len(cal.frame)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    sel=np.asarray(selector_score,dtype=np.float64)
    qualified=[]
    for j,i in enumerate(sib_arr.tolist()):
        cpt=int(rows[i,0])
        if i==int(anchor_idx):
            qualified.append((i,j))
            continue
        if float(post[j]) < 0.010:
            continue
        if float(sel[i]) < 0.80:
            continue
        if not (float(rz[cpt]) >= 0.05 or float(mp[cpt]) >= 0.45):
            continue
        qualified.append((i,j))
    # Championship-head two-lane policy. Keep the strongest common-world Captain
    # sibling plus one independently qualified extreme-tail Captain sibling. The
    # second lane is not generic diversification: it must already clear posterior
    # and selector gates, then wins on role-tail per sqrt(projected CPT ownership).
    # This prevents three near-identical median-probability Captain swaps from
    # consuming the entire Top-5 head while preserving a legitimate long-tail door.
    alt=[x for x in qualified if x[0]!=int(anchor_idx)]
    alt.sort(key=lambda x:(-float(post[x[1]]),-float(sel[x[0]]),int(x[0])))
    prob_pick=alt[:1]
    if hasattr(cal,"captain_ownership"):
        cpt_own=np.clip(np.asarray(cal.captain_ownership,dtype=np.float64),0.0005,0.65)
    elif hasattr(cal,"ownership"):
        cpt_own=np.clip(np.asarray(cal.ownership,dtype=np.float64)/6.0,0.0005,0.65)
    else:
        cpt_own=np.full(len(cal.frame),1.0/6.0,dtype=np.float64)
    unc=np.asarray(getattr(cal,"role_uncertainty",np.zeros(len(cal.frame))),dtype=np.float64)
    sal=np.maximum(np.asarray(getattr(cal,"salary",np.full(len(cal.frame),10000)),dtype=np.float64),500.0)
    role_tail=(0.45*rz+0.35*mp+0.20*unc)*np.sqrt(10000.0/sal)
    tail_eff=role_tail/np.sqrt(np.maximum(cpt_own,0.005))
    used={int(i) for i,_ in prob_pick}
    tail_pool=[x for x in alt if int(x[0]) not in used]
    tail_pool.sort(key=lambda x:(-float(tail_eff[int(rows[x[0],0])]),-float(post[x[1]]),-float(sel[x[0]]),int(x[0])))
    tail_pick=tail_pool[:1] if target>=3 else []
    keep=[int(anchor_idx)] + [int(i) for i,_ in prob_pick] + [int(i) for i,_ in tail_pick]
    receipt={
        "PATCH_ID":CAPTAIN_SIBLING_HEAD_PATCH_ID,"ACTIVE":len(keep)>1,
        "TWO_LANE_POLICY_ID":TWO_LANE_HEAD_PATCH_ID,
        "ANCHOR_PHASE2_INDEX":int(anchor_idx),"SIBLING_ROWS":int(len(sib_arr)),
        "RESERVED_PHASE2_INDICES":keep,"POSTLOCK_INPUT_USED":False,"PLAYER_NAME_LOGIC":False,
        "POSTERIOR_THRESHOLD":0.010,"SELECTOR_SCORE_FLOOR":0.80,
        "PROBABILITY_LANE_PHASE2_INDICES":[int(i) for i,_ in prob_pick],
        "EXTREME_TAIL_LANE_PHASE2_INDICES":[int(i) for i,_ in tail_pick],
        "EXTREME_TAIL_SCORE":"ROLE_TAIL_PER_SQRT_PROJECTED_CPT_OWNERSHIP",
        "CPT_POSTERIOR":[{"PHASE2_INDEX":int(i),"CPT":str(cal.frame.iloc[int(rows[i,0])]["PLAYER"]),"POSTERIOR":float(post[j]),"SELECTOR_SCORE":float(sel[i]),"RED_ZONE":float(rz[int(rows[i,0])]),"MULTI_PATH":float(mp[int(rows[i,0])]),"TAIL_EFFICIENCY":float(tail_eff[int(rows[i,0])])} for j,i in enumerate(sib_arr.tolist())],
    }
    return np.asarray(keep,dtype=np.int32),receipt



def _championship_extreme_cpt_completion_head(
    rows: np.ndarray,
    extreme_idx: int,
    already_reserved: np.ndarray,
    sim: dict[str,Any],
    cal: Calibration,
    pmeta: dict[str,np.ndarray],
    target: int,
) -> tuple[np.ndarray,dict[str,Any]]:
    """Reserve one same-CPT 5-of-6 completion around the extreme-tail Captain lane.

    Top 0.0050% is too sparse for raw simulated rates to be literal authority. This
    lane therefore uses those rates only as weak signals and asks a structural
    question: once an independently-qualified extreme-tail Captain is identified,
    is there a one-player completion that preserves the same five-player championship
    core while improving premium role strength and salary geometry?  No postlock
    identity or player-name rule is used.
    """
    target=int(target); extreme_idx=int(extreme_idx)
    reserved=np.asarray(already_reserved,dtype=np.int32)
    receipt={
        "PATCH_ID":EXTREME_CPT_COMPLETION_PATCH_ID,"OBJECTIVE_PATCH_ID":TOP0050_HEAD_PATCH_ID,
        "ACTIVE":False,"EXTREME_CPT_PHASE2_INDEX":extreme_idx,"SELECTED_PHASE2_INDICES":[],
        "CANDIDATE_COUNT":0,"POSTLOCK_INPUT_USED":False,"PLAYER_NAME_LOGIC":False,
        "PRIMARY_TARGET_PERCENT":0.0050,"SECONDARY_TARGET_PERCENT":0.0100,"FALLBACK_TARGET_PERCENT":0.1000,
        "MEMBERSHIP_RULE":"EXTREME_CPT_SAME_CPT_5_OF_6_PRELOCK_COMPLETION",
    }
    if target<5 or len(rows)==0 or extreme_idx<0 or extreme_idx>=len(rows) or len(reserved)>=target:
        receipt["REASON"]="INELIGIBLE_TARGET_OR_HEAD_ALREADY_FULL"; return np.empty(0,dtype=np.int32),receipt
    extreme_row=np.asarray(rows[extreme_idx],dtype=np.int32)
    extreme_set=frozenset(map(int,extreme_row.tolist())); cpt=int(extreme_row[0]); reserved_set=set(map(int,reserved.tolist()))
    cand=[]; removed=[]; added=[]
    for i,row in enumerate(rows):
        if i==extreme_idx or i in reserved_set or int(row[0])!=cpt: continue
        rset=frozenset(map(int,row.tolist()))
        if rset==extreme_set or len(extreme_set.intersection(rset))<5: continue
        rem=list(extreme_set-rset); add=list(rset-extreme_set)
        if len(rem)!=1 or len(add)!=1: continue
        cand.append(int(i)); removed.append(int(rem[0])); added.append(int(add[0]))
    if not cand:
        receipt["REASON"]="NO_SAME_CPT_5_OF_6_COMPLETION"; return np.empty(0,dtype=np.int32),receipt
    cand_arr=np.asarray(cand,dtype=np.int32)
    rz=pd.to_numeric(cal.frame.get("RED_ZONE_OPPORTUNITY",pd.Series(np.zeros(len(cal.frame)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    mp=pd.to_numeric(cal.frame.get("MULTI_PATH_CEILING",pd.Series(np.zeros(len(cal.frame)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    unc=np.asarray(getattr(cal,"role_uncertainty",np.zeros(len(cal.frame))),dtype=np.float64)
    salary=np.maximum(np.asarray(cal.salary,dtype=np.float64),500.0)
    player_tail=(0.50*rz+0.30*mp+0.20*unc)*np.sqrt(10000.0/salary)
    player_strength=_pct(np.asarray(cal.mu,dtype=np.float64)+0.35*np.asarray(cal.sigma,dtype=np.float64)+1.50*rz+0.80*mp)
    retained_tail=np.zeros(len(cand),dtype=np.float64); retained_rz=np.zeros(len(cand),dtype=np.float64)
    add_strength=np.zeros(len(cand),dtype=np.float64); geometry=np.zeros(len(cand),dtype=np.float64)
    for j,(i,add) in enumerate(zip(cand,added)):
        rset=frozenset(map(int,rows[i].tolist())); retained=np.asarray(sorted(extreme_set.intersection(rset)),dtype=np.int32)
        retained_tail[j]=float(player_tail[retained].sum()); retained_rz[j]=float(rz[retained].sum()); add_strength[j]=float(player_strength[int(add)])
        row_salary=float(np.asarray(pmeta.get("salary",np.zeros(len(rows))),dtype=np.float64)[i])
        remainder=50000.0-row_salary; geometry[j]=float(np.clip(1.0-abs(remainder-1000.0)/3000.0,0.0,1.0))
    m=sim.get("metrics",{})
    t005=np.asarray(m.get("top0050_rate",m.get("top01_rate",np.zeros(len(rows)))),dtype=np.float64)[cand_arr]
    t010=np.asarray(m.get("top0100_rate",m.get("top01_rate",np.zeros(len(rows)))),dtype=np.float64)[cand_arr]
    rt=_pct(retained_tail); rr=_pct(retained_rz); aa=_pct(add_strength); gg=_pct(geometry); p005=_pct(t005); p010=_pct(t010)
    score=0.30*rt+0.20*rr+0.25*aa+0.15*gg+0.05*p005+0.05*p010
    order=np.argsort(-score,kind="stable")
    best=int(order[0])
    # Require a genuinely premium added role and coherent retained core; otherwise no forced seat.
    if float(add_strength[best])<0.55 or float(rt[best])<0.50 or float(rr[best])<0.50:
        receipt.update({"REASON":"NO_PRELOCK_QUALITY_QUALIFIER","CANDIDATE_COUNT":int(len(cand))}); return np.empty(0,dtype=np.int32),receipt
    selected=np.asarray([int(cand_arr[best])],dtype=np.int32)
    receipt.update({
        "ACTIVE":True,"CANDIDATE_COUNT":int(len(cand)),"SELECTED_PHASE2_INDICES":[int(selected[0])],
        "SELECTED_EVIDENCE":{
            "SCORE":float(score[best]),"RETAINED_ROLE_TAIL_PCTL":float(rt[best]),"RETAINED_RED_ZONE_PCTL":float(rr[best]),
            "ADDED_PLAYER_STRENGTH_PCTL":float(aa[best]),"SALARY_GEOMETRY_PCTL":float(gg[best]),
            "TOP0050_SIGNAL_PCTL":float(p005[best]),"TOP0100_SIGNAL_PCTL":float(p010[best]),
        },
        "CHANNEL_WEIGHTS":{"RETAINED_ROLE_TAIL":0.30,"RETAINED_RED_ZONE":0.20,"ADDED_PLAYER_STRENGTH":0.25,"SALARY_GEOMETRY":0.15,"TOP0050_SIGNAL":0.05,"TOP0100_SIGNAL":0.05},
    })
    return selected,receipt


def _championship_one_mutation_head(
    rows: np.ndarray,
    anchor_idx: int,
    already_reserved: np.ndarray,
    sim: dict[str,Any],
    cal: Calibration,
    ownprod: np.ndarray,
    target: int,
) -> tuple[np.ndarray,dict[str,Any]]:
    """Reserve up to two strong 5-of-6 neighbors of the championship anchor family.

    This runs before membership freeze and only when the same-six Captain sibling
    lane does not fill the complete Top-5 head.  Candidates must preserve at least
    five identities from the anchor, must not be same-six duplicates, and are ranked
    by independent prelock evidence: simulated Top-0.1 support, ownership leverage,
    red-zone opportunity, and salary-aware role-tail support.  No postlock result or
    player-name rule is consumed.
    """
    target=int(target)
    anchor_idx=int(anchor_idx)
    reserved=np.asarray(already_reserved,dtype=np.int32)
    receipt={
        "PATCH_ID":ONE_MUTATION_HEAD_PATCH_ID,"ACTIVE":False,
        "ANCHOR_PHASE2_INDEX":anchor_idx,"SELECTED_PHASE2_INDICES":[],
        "CANDIDATE_COUNT":0,"POSTLOCK_INPUT_USED":False,"PLAYER_NAME_LOGIC":False,
        "MEMBERSHIP_RULE":"ANCHOR_5_OF_6_MULTI_EVIDENCE_ONE_MUTATION",
    }
    if target < 5 or len(rows)==0 or anchor_idx<0 or anchor_idx>=len(rows) or len(reserved)>=target:
        receipt["REASON"]="INELIGIBLE_TARGET_OR_HEAD_ALREADY_FULL"
        return np.empty(0,dtype=np.int32),receipt
    anchor_set=frozenset(map(int,rows[anchor_idx].tolist()))
    same_six={i for i,row in enumerate(rows) if frozenset(map(int,row.tolist()))==anchor_set}
    reserved_set=set(map(int,reserved.tolist()))
    cand=[]
    for i,row in enumerate(rows):
        if i in reserved_set or i in same_six:
            continue
        if len(anchor_set.intersection(map(int,row.tolist()))) < 5:
            continue
        cand.append(int(i))
    if not cand:
        receipt["REASON"]="NO_5_OF_6_NEIGHBOR"
        return np.empty(0,dtype=np.int32),receipt
    cand_arr=np.asarray(cand,dtype=np.int32)
    m=sim.get("metrics",{})
    top01=_pct(np.asarray(m.get("top01_rate",np.zeros(len(rows))),dtype=np.float64))
    leverage=1.0-_pct(np.asarray(ownprod,dtype=np.float64))
    rz=pd.to_numeric(cal.frame.get("RED_ZONE_OPPORTUNITY",pd.Series(np.zeros(len(cal.frame)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    mp=pd.to_numeric(cal.frame.get("MULTI_PATH_CEILING",pd.Series(np.zeros(len(cal.frame)))),errors="coerce").fillna(0.0).to_numpy(np.float64)
    unc=np.asarray(getattr(cal,"role_uncertainty",np.zeros(len(cal.frame))),dtype=np.float64)
    sal=np.maximum(np.asarray(cal.salary,dtype=np.float64),500.0)
    player_tail=(0.55*rz+0.25*mp+0.20*unc)*np.sqrt(10000.0/sal)
    rz_line=np.zeros(len(rows),dtype=np.float64)
    tail_line=np.zeros(len(rows),dtype=np.float64)
    for i,row in enumerate(rows):
        ids=np.asarray(row,dtype=np.int32); cpt=int(ids[0])
        rz_line[i]=float(np.sum(rz[ids])+0.5*rz[cpt])
        tail_line[i]=float(np.sum(player_tail[ids])+0.5*player_tail[cpt])
    rz_pct=_pct(rz_line); tail_pct=_pct(tail_line)
    score=0.50*top01+0.20*leverage+0.15*tail_pct+0.15*rz_pct
    # Each channel must have nontrivial support. This prevents one noisy model from
    # buying a championship-head seat by itself.
    eligible=[i for i in cand if top01[i]>=0.60 and leverage[i]>=0.40 and tail_pct[i]>=0.70 and rz_pct[i]>=0.55]
    if not eligible:
        receipt.update({"REASON":"NO_MULTI_EVIDENCE_QUALIFIER","CANDIDATE_COUNT":int(len(cand))})
        return np.empty(0,dtype=np.int32),receipt
    eligible.sort(key=lambda i:(-float(score[i]),-float(top01[i]),-float(leverage[i]),int(i)))
    need=max(0,target-len(reserved))
    selected=np.asarray(eligible[:min(need,2)],dtype=np.int32)
    receipt.update({
        "ACTIVE":bool(len(selected)),"CANDIDATE_COUNT":int(len(cand)),
        "QUALIFIED_COUNT":int(len(eligible)),"SELECTED_PHASE2_INDICES":[int(i) for i in selected.tolist()],
        "CHANNEL_WEIGHTS":{"TOP01_PCTL":0.50,"LEVERAGE_PCTL":0.20,"ROLE_TAIL_PCTL":0.15,"RED_ZONE_PCTL":0.15},
        "CHANNEL_FLOORS":{"TOP01_PCTL":0.60,"LEVERAGE_PCTL":0.40,"ROLE_TAIL_PCTL":0.70,"RED_ZONE_PCTL":0.55},
        "SELECTED_EVIDENCE":[{"PHASE2_INDEX":int(i),"SCORE":float(score[i]),"TOP01_PCTL":float(top01[i]),"LEVERAGE_PCTL":float(leverage[i]),"ROLE_TAIL_PCTL":float(tail_pct[i]),"RED_ZONE_PCTL":float(rz_pct[i])} for i in selected.tolist()],
    })
    return selected,receipt

def _select(rows: np.ndarray, pmeta: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray,dict[str,np.ndarray],str]:
    m=sim["metrics"]; n=len(rows)
    top01p=_pct(m["top01_rate"]); winp=_pct(m["win_rate"]); top10p=_pct(m["top10_rate"]); p95p=_pct(m["p95"]); p99p=_pct(m["p99"])
    flex_own=np.clip(getattr(cal,"flex_ownership",cal.ownership),0.0005,0.98)
    cpt_own=np.clip(getattr(cal,"captain_ownership",np.asarray(cal.ownership,dtype=float)/6.0),0.0005,0.65)
    logown=np.log(cpt_own[rows[:,0]])+np.log(flex_own[rows[:,1:]]).sum(axis=1)
    ownprod=np.exp(np.clip(logown,-50,0))
    leverage=1.0-_pct(ownprod)
    strict=((top01p>=.99)|(winp>=.99))&(p95p>=.99)&(p99p>=.985)&(top10p>=.90)
    selector_metrics={
        "top01_rate":np.asarray(m["top01_rate"],dtype=np.float64),
        "top01_lcb":np.asarray(m["top01_lcb"],dtype=np.float64),
        "win_rate":np.asarray(m["win_rate"],dtype=np.float64),
        "p99":np.asarray(m["p99"],dtype=np.float64),
        "p95":np.asarray(m["p95"],dtype=np.float64),
        "top10_rate":np.asarray(m["top10_rate"],dtype=np.float64),
        "leverage":np.asarray(leverage,dtype=np.float64),
    }
    plan=hybrid_selector.HybridRankingPlan(
        primary_metric="top01_rate",
        tiebreak_metrics=("top01_lcb","win_rate","p99","p95","top10_rate","leverage"),
        primary_tie_width=float(cfg.selector_primary_tie_width),
    )
    legacy_order,rn_receipt=rn_door.neighborhood_door_order(np.asarray(pmeta["family"]),selector_metrics,{"top01_rate":.26,"top01_lcb":.12,"win_rate":.16,"p99":.18,"p95":.10,"top10_rate":.08,"leverage":.10})
    if n <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:NFL_SHOWDOWN_ZERO_PHASE3_SURVIVORS")
    target=min(int(cfg.board_size),n)
    reserve=_defensive_balanced_reserve_indices(rows,pmeta,cal,cfg)

    # The prior defensive-balanced family remains a bounded coverage feature only.
    # It no longer receives tier-first terminal order authority on unrelated slates.
    adapter_tier=np.zeros(n,dtype=np.int8)
    top_neighborhood_support=global_order.derive_root_neighborhood_support(rows,reserve,role_sensitive_prefix=1,max_depth=2)
    neighbor_doors=_defensive_balanced_neighbor_door_indices(rows,reserve,pmeta,cal,max_doors=8)
    if len(neighbor_doors): adapter_tier[neighbor_doors]=1
    if len(reserve): adapter_tier[reserve]=2
    adapter_order_score=np.asarray(pmeta.get("score",np.zeros(n)),dtype=np.float64).copy()
    if len(reserve): adapter_order_score[reserve]=np.asarray(m["top01_rate"],dtype=np.float64)[reserve]
    go=global_order.rank_surface(
        {
            "top01_lcb":selector_metrics["top01_lcb"],
            "top01_ucb":np.asarray(m.get("top01_ucb",selector_metrics["top01_lcb"]),dtype=np.float64),
            "win_rate":selector_metrics["win_rate"],
            "p99":selector_metrics["p99"],
            "p95":selector_metrics["p95"],
        },
        sport="NFL",mode="SHOWDOWN",
        sport_native_score=np.asarray(pmeta.get("score",np.zeros(n)),dtype=np.float64),
        expected_rank=np.asarray(m.get("expected_rank",np.full(n,np.nan)),dtype=np.float64),
        median_rank=np.asarray(m.get("median_rank",np.full(n,np.nan)),dtype=np.float64),
        rank_p90=np.asarray(m.get("rank_p90",np.full(n,np.nan)),dtype=np.float64),
        pairwise_strength=np.asarray(m.get("pairwise_strength",np.full(n,np.nan)),dtype=np.float64),
        world_breadth=np.asarray(m.get("world_breadth",np.full(n,np.nan)),dtype=np.float64),
        rank_stability=np.asarray(m.get("rank_stability",np.full(n,np.nan)),dtype=np.float64),
        projected_duplication=np.asarray(ownprod,dtype=np.float64),
        adapter_priority_tier=adapter_tier,
        adapter_priority_score=adapter_order_score,
        top_neighborhood_support=top_neighborhood_support,
        adapter_id=DEFENSIVE_BALANCED_RESERVE_PATCH_ID,
        adapter_live_authority=False,
    )
    full_order=np.asarray(go.order,dtype=np.int32)

    extreme=_extreme_special_teams_closure_indices(
        rows,pmeta,cal,np.asarray(go.order_score,dtype=np.float64),
        np.asarray(m["top01_rate"],dtype=np.float64),np.asarray(m["p99"],dtype=np.float64),target,
    )
    protected=np.concatenate([np.asarray(reserve,dtype=np.int32),np.asarray(extreme,dtype=np.int32)]) if (len(reserve) or len(extreme)) else np.empty(0,dtype=np.int32)
    if len(protected):
        _,first=np.unique(protected,return_index=True); protected=protected[np.sort(first)]

    td_event_onslaught_reserve,td_event_onslaught_receipt=_td_event_dominant_onslaught_reserve_indices(
        rows,pmeta,cal,target
    )
    if len(td_event_onslaught_reserve):
        protected=np.concatenate([np.asarray(protected,dtype=np.int32),td_event_onslaught_reserve])
        _,first=np.unique(protected,return_index=True); protected=protected[np.sort(first)]

    # Contest-class objective: single-entry is a championship decision, not a
    # diversified portfolio. Build a bounded Top-0.1-first shortlist using the
    # existing hybrid selector and let GLOBAL ORDER break the final choice.
    # Leverage and diversification have no terminal authority when target == 1.
    single_entry_receipt={
        "PATCH_ID":SINGLE_ENTRY_CHAMPIONSHIP_HEAD_PATCH_ID,
        "ACTIVE":False,
        "SHORTLIST_SIZE":0,
        "SHORTLIST_PHASE2_INDICES":[],
        "SELECTED_PHASE2_INDEX":None,
        "MEMBERSHIP_RULE":"TOP01_PRIMARY_SHORTLIST_THEN_GLOBAL_ORDER",
        "DIVERSIFICATION_APPLIED":False,
        "LEVERAGE_TERMINAL_AUTHORITY":False,
        "POSTLOCK_INPUT_USED":False,
        "PLAYER_NAME_LOGIC":False,
    }
    player_cap,captain_cap,script_cap=_effective_portfolio_caps(cfg,target)
    family_strength_receipt={"PATCH_ID":TWO_FAMILY_HEAD_PATCH_ID,"ACTIVE":False,"REASON":"SINGLE_ENTRY_OR_NOT_EVALUATED","POSTLOCK_INPUT_USED":False}
    sibling_head_receipt={"PATCH_ID":CAPTAIN_SIBLING_HEAD_PATCH_ID,"ACTIVE":False,"REASON":"SINGLE_ENTRY_OR_NOT_EVALUATED","POSTLOCK_INPUT_USED":False}
    extreme_cpt_completion_receipt={"PATCH_ID":EXTREME_CPT_COMPLETION_PATCH_ID,"ACTIVE":False,"REASON":"SINGLE_ENTRY_OR_NOT_EVALUATED","POSTLOCK_INPUT_USED":False}
    one_mutation_head_receipt={"PATCH_ID":ONE_MUTATION_HEAD_PATCH_ID,"ACTIVE":False,"REASON":"SINGLE_ENTRY_OR_NOT_EVALUATED","POSTLOCK_INPUT_USED":False}
    if target == 1:
        hybrid_order=np.asarray(hybrid_selector.ranking_order(plan,selector_metrics),dtype=np.int32)
        shortlist=hybrid_order[:min(5,len(hybrid_order))]
        go_rank=np.asarray(go.order_rank,dtype=np.int32)
        selected=int(min(shortlist.tolist(),key=lambda i:(int(go_rank[int(i)]),int(i))))
        chosen=np.asarray([selected],dtype=np.int32)
        single_entry_receipt.update({
            "ACTIVE":True,
            "SHORTLIST_SIZE":int(len(shortlist)),
            "SHORTLIST_PHASE2_INDICES":[int(i) for i in shortlist.tolist()],
            "SELECTED_PHASE2_INDEX":selected,
            "SHORTLIST_HYBRID_RANKS":list(range(1,len(shortlist)+1)),
            "SHORTLIST_GLOBAL_ORDER_RANKS":[int(go_rank[int(i)]) for i in shortlist.tolist()],
            "SELECTED_GLOBAL_ORDER_RANK":int(go_rank[selected]),
            "SELECTED_TOP01_RATE":float(np.asarray(m["top01_rate"],dtype=np.float64)[selected]),
        })
    else:
        base_quality=(
            0.25*top01p + 0.10*winp + 0.10*top10p + 0.20*p99p + 0.10*p95p +
            0.15*np.asarray(go.order_score,dtype=np.float64) + 0.10*leverage
        )
        helper_metrics={"_pos":cal.pos}
        family_anchors,family_strength_receipt=_championship_family_strength_head(
            rows,sim,cal,ownprod,np.asarray(go.order_score,dtype=np.float64)
        )
        anchor_idx=int(family_anchors[0]) if family_anchors else int(np.asarray(go.order,dtype=np.int32)[0])
        # Family A can own up to three championship-head seats. Family B, when it
        # independently qualifies, can own up to two. This is not diversification:
        # both families must independently clear the same prelock championship gates.
        family_b_anchor=int(family_anchors[1]) if len(family_anchors)>1 else None
        a_target=min(target,3 if family_b_anchor is not None else target)
        sibling_head,sibling_head_receipt=_championship_captain_sibling_head(
            rows,anchor_idx,sim,cal,_pct(np.asarray(go.order_score,dtype=np.float64)),a_target
        )
        if len(sibling_head):
            protected=np.concatenate([sibling_head,np.asarray(protected,dtype=np.int32)])
            _,_first=np.unique(protected,return_index=True); protected=protected[np.sort(_first)]
        if family_b_anchor is not None and len(protected)<target:
            b_head,b_receipt=_championship_captain_sibling_head(
                rows,family_b_anchor,sim,cal,_pct(np.asarray(go.order_score,dtype=np.float64)),2
            )
            if len(b_head):
                room=max(0,target-len(protected))
                protected=np.concatenate([np.asarray(protected,dtype=np.int32),np.asarray(b_head[:room],dtype=np.int32)])
                _,_first=np.unique(protected,return_index=True); protected=protected[np.sort(_first)]
            family_strength_receipt["FAMILY_B_HEAD_RECEIPT"]=b_receipt
        extreme_lane=[int(i) for i in sibling_head_receipt.get("EXTREME_TAIL_LANE_PHASE2_INDICES",[])]
        if extreme_lane and len(protected)<target:
            extreme_completion,extreme_cpt_completion_receipt=_championship_extreme_cpt_completion_head(
                rows,extreme_lane[0],np.asarray(protected,dtype=np.int32),sim,cal,pmeta,target
            )
            if len(extreme_completion):
                protected=np.concatenate([np.asarray(protected,dtype=np.int32),extreme_completion])
                _,_first=np.unique(protected,return_index=True); protected=protected[np.sort(_first)]
        mutation_head,one_mutation_head_receipt=_championship_one_mutation_head(
            rows,anchor_idx,np.asarray(protected,dtype=np.int32),sim,cal,ownprod,target
        )
        if len(mutation_head):
            protected=np.concatenate([np.asarray(protected,dtype=np.int32),mutation_head])
            _,_first=np.unique(protected,return_index=True); protected=protected[np.sort(_first)]
        chosen=_marginal_world_portfolio_select(
            rows,pmeta,helper_metrics,base_quality,protected,target,player_cap,captain_cap,script_cap
        )
    if len(chosen) != target:
        raise RuntimeError(f"ENGINE_INTEGRITY_FAILURE:NFL_SHOWDOWN_NONEMPTY_BOARD_CARDINALITY:{len(chosen)}:{target}")

    # Membership is frozen above. Terminal order now applies the GLOBAL doctrine:
    # MC metrics remain relative signals; cross-world recurrence/pairwise/breadth/
    # stability are primary, with bounded AI-Hybrid structural context.
    core4_primary,core4_secondary,core4_protected,core4_family=_board_cross_world_core4_support(
        rows,chosen,np.asarray(sim.get("ordinal_rank_matrix",np.empty((0,0),dtype=np.int16))),pmeta,cal,cfg
    )
    terminal_rows=[]
    for local,phase_idx in enumerate(chosen.tolist()):
        i=int(phase_idx)
        terminal_rows.append({
            "RANK":i,
            "GLOBAL_CORE_PROTECTED":bool(core4_protected[local]),
            "GLOBAL_CORE_PRIORITY":100 if bool(core4_protected[local]) else 0,
            "RECURRENCE":float(core4_primary[local]),
            "CROSS_WORLD_CORE4_SUPPORT":float(core4_primary[local]),
            "CROSS_WORLD_CORE4_SECONDARY_SUPPORT":float(core4_secondary[local]),
            "PAIRWISE_STRENGTH":float(m["pairwise_strength"][i]),
            "WORLD_BREADTH":float(m["world_breadth"][i]),
            "RANK_STABILITY":float(m["rank_stability"][i]),
            "P_TOP10":float(m["top10_rate"][i]),
            "WIN_RATE":float(m["win_rate"][i]),
            "TOP01_RATE":float(m["top01_rate"][i]),
            "TOP10_RATE":float(m["top10_rate"][i]),
            "P95":float(m["p95"][i]),
            "P99":float(m["p99"][i]),
            "EXPECTED_RANK":float(m["expected_rank"][i]),
            "MEDIAN_RANK":float(m["median_rank"][i]),
            "RANK_P90":float(m["rank_p90"][i]),
            "STRUCT_PCT":float(pmeta.get("score",np.zeros(n))[i]),
            "TN_BLEND":float(top_neighborhood_support[i]),
        })
    # First pass computes the global doctrine score with no dependency on protection.
    # Protection itself is then decided by Hybrid Eyes: a row must be both a
    # recurrent structural tail and strong under the multi-signal doctrine.  This
    # prevents recurrence alone from forcing a weak row into the terminal head.
    _,mc_signal_probe_receipt,mc_signal_probe_tel=mc_signal_terminal.order_rows(
        terminal_rows,stability_higher_is_better=True
    )
    probe_score=np.asarray(mc_signal_probe_tel["signal_score"],dtype=np.float64)
    structural_eligible=[]
    for local,phase_idx in enumerate(chosen.tolist()):
        i=int(phase_idx)
        if float(core4_primary[local]) <= 0.0:
            continue
        if int(pmeta["same_cpt_team"][i]) not in (1,5):
            continue
        if int(pmeta["qb_count"][i]) != 1 or int(pmeta["k_count"][i]) < 1 or int(pmeta["dst_count"][i]) < 1:
            continue
        structural_eligible.append(int(local))
    # Cross-world recurrence is already a primary channel inside probe_score.
    # Rank eligible rows by the complete doctrine score, with recurrence as a
    # deterministic tie-break.  Bound Captain concentration at two protected
    # seats so the Top-5 remains a portfolio rather than one fragile script.
    selected_signal=[]
    cpt_counts: dict[int,int]={}
    for local in sorted(structural_eligible,key=lambda j:(-float(probe_score[j]),-float(core4_primary[j]),-float(core4_secondary[j]),int(chosen[j]))):
        cpt=int(rows[int(chosen[local]),0])
        if cpt_counts.get(cpt,0) >= 2:
            continue
        selected_signal.append(local)
        cpt_counts[cpt]=cpt_counts.get(cpt,0)+1
        if len(selected_signal) >= int(mc_signal_terminal.MAX_PROTECTED_FRONT):
            break
    core4_protected=np.zeros(len(chosen),dtype=bool)
    core4_family=["" for _ in range(len(chosen))]
    for seat,local in enumerate(selected_signal,1):
        core4_protected[int(local)]=True
        core4_family[int(local)]=f"NFL_SD_MC_SIGNAL_CORE4_{seat}"
        terminal_rows[int(local)]["GLOBAL_CORE_PROTECTED"]=True
        terminal_rows[int(local)]["GLOBAL_CORE_PRIORITY"]=100
    for local in range(len(terminal_rows)):
        if not core4_protected[local]:
            terminal_rows[local]["GLOBAL_CORE_PROTECTED"]=False
            terminal_rows[local]["GLOBAL_CORE_PRIORITY"]=0
    # Existing 1.33.312 family/MC order is retained as the deterministic fallback
    # for low-world test modes. In normal production, the exact-role common-world
    # posterior owns only the bounded head after membership is frozen.
    _,mc_signal_receipt,mc_signal_tel=mc_signal_terminal.order_rows(
        terminal_rows,stability_higher_is_better=True
    )
    family_score,family_receipt=_board_family_consensus_evidence(
        chosen,rows,{**m,"global_order_confidence":np.asarray(go.order_confidence,dtype=np.float64)}
    )
    family_receipt["FAMILY_CONSENSUS_ROLE"]="DISCOVERY_PRIOR_SHRINKAGE_AND_EXACT_SCORE_TIEBREAK_ONLY"
    family_receipt["TERMINAL_AUTHORITY"]=False
    fallback_order=_family_aware_terminal_order(family_score,probe_score,core4_protected)
    mc_signal_receipt["PROTECTION_SELECTION"]="CROSS_WORLD_RECURRENCE_PLUS_GLOBAL_MC_SIGNAL_HYBRID"
    mc_signal_receipt["PROTECTION_CANDIDATES"]=int(len(structural_eligible))
    mc_signal_receipt["PROBE_PATCH_ID"]=mc_signal_probe_receipt.get("PATCH_ID")
    mc_signal_receipt["TERMINAL_FAMILY_CONSENSUS_PATCH_ID"]=family_receipt.get("PATCH_ID")
    mc_signal_receipt["FAMILY_CONSENSUS_ROLE"]=family_receipt.get("FAMILY_CONSENSUS_ROLE")
    mc_signal_receipt["FAMILY_CONTEXT_TERMINAL_AUTHORITY"]=False
    mc_signal_receipt["RAW_MC_LITERAL_AUTHORITY"]=False

    # Rebase all board-local telemetry to the 1.33.312 fallback order first.
    chosen=chosen[fallback_order] if len(chosen) else chosen
    core4_primary=core4_primary[fallback_order] if len(core4_primary) else core4_primary
    core4_secondary=core4_secondary[fallback_order] if len(core4_secondary) else core4_secondary
    core4_protected=core4_protected[fallback_order] if len(core4_protected) else core4_protected
    core4_family=[core4_family[j] for j in fallback_order]
    family_context=np.asarray(family_score,dtype=np.float64)[fallback_order]
    mc_signal_score_board=np.asarray(mc_signal_tel["signal_score"],dtype=np.float64)[fallback_order]
    mc_signal_disagreement_board=np.asarray(mc_signal_tel["disagreement"],dtype=np.float64)[fallback_order]
    terminal_family_consensus_score_board=np.asarray(family_score,dtype=np.float64)[fallback_order]

    head_result=None
    final_head_receipt={"PATCH_ID":exact_head.PATCH_ID,"LIVE_HEAD_AUTHORITY_READY":False,"REASON":"NO_BOARD"}
    if len(chosen) == 1:
        final_head_receipt={
            "PATCH_ID":exact_head.PATCH_ID,
            "LIVE_HEAD_AUTHORITY_READY":False,
            "REASON":"SINGLE_ENTRY_PREMEMBERSHIP_HEAD_ALREADY_APPLIED",
            "COMMON_WORLDS":int(cfg.base_trials),
            "LINEUPS":1,
            "MEMBERSHIP_MUTATION_ALLOWED":False,
            "POSTLOCK_INPUT_USED":False,
        }
    elif len(chosen) > 1:
        score_tape=_score_rows(rows[chosen],np.asarray(sim["base_sims"],dtype=np.float32)).T
        head_result=exact_head.evaluate_exact_role_common_world_head(
            score_tape,
            family_ids=np.asarray(pmeta["family"])[chosen],
            family_context_score=family_context,
            base_order_score=-np.arange(len(chosen),dtype=np.float64),
            head_size=min(15,len(chosen)),
            min_live_worlds=exact_head.MIN_LIVE_COMMON_WORLDS,
            target_worlds=exact_head.TARGET_COMMON_WORLDS,
        )
        final_head_receipt=dict(head_result.receipt)
        if bool(head_result.receipt.get("LIVE_HEAD_AUTHORITY_READY",False)):
            local_order,_head_size=global_order.apply_exact_role_head_order(
                np.arange(len(chosen),dtype=np.int32),
                head_result.head_score,
                family_context_score=family_context,
                head_rerank_size=min(15,len(chosen)),
            )
            chosen=chosen[local_order]
            core4_primary=core4_primary[local_order]
            core4_secondary=core4_secondary[local_order]
            core4_protected=core4_protected[local_order]
            core4_family=[core4_family[j] for j in local_order]
            family_context=family_context[local_order]
            mc_signal_score_board=mc_signal_score_board[local_order]
            mc_signal_disagreement_board=mc_signal_disagreement_board[local_order]
            terminal_family_consensus_score_board=terminal_family_consensus_score_board[local_order]
            from dataclasses import replace as _dc_replace
            head_result=_dc_replace(
                head_result,
                head_score=head_result.head_score[local_order],
                p_rank1=head_result.p_rank1[local_order],p_top3=head_result.p_top3[local_order],
                p_top5=head_result.p_top5[local_order],p_top10=head_result.p_top10[local_order],
                expected_rank=head_result.expected_rank[local_order],median_rank=head_result.median_rank[local_order],
                rank_p90=head_result.rank_p90[local_order],rank_std=head_result.rank_std[local_order],
                pairwise_strength=head_result.pairwise_strength[local_order],
                pairwise_margin_mean=head_result.pairwise_margin_mean[local_order],
                p_sibling_best=head_result.p_sibling_best[local_order],
                rank_stability=head_result.rank_stability[local_order],
                rank_uncertainty_width=head_result.rank_uncertainty_width[local_order],
                order=np.arange(len(chosen),dtype=np.int32),
            )

    # Broadcast board-only exact-role telemetry back to Phase-2 indexing.
    _nan=np.full(n,np.nan,dtype=np.float64)
    exact_head_score=_nan.copy(); pbr1=_nan.copy(); pbr3=_nan.copy(); pbr5=_nan.copy(); pbr10=_nan.copy()
    expbr=_nan.copy(); medbr=_nan.copy(); p90br=_nan.copy(); pairbr=_nan.copy(); sibbr=_nan.copy(); stabbr=_nan.copy(); uncbr=_nan.copy(); famctx_full=_nan.copy()
    final_head_rank=np.zeros(n,dtype=np.int32)
    if len(chosen):
        famctx_full[chosen]=family_context
        final_head_rank[chosen]=np.arange(1,len(chosen)+1,dtype=np.int32)
    if len(chosen) and head_result is not None:
        exact_head_score[chosen]=head_result.head_score; pbr1[chosen]=head_result.p_rank1; pbr3[chosen]=head_result.p_top3
        pbr5[chosen]=head_result.p_top5; pbr10[chosen]=head_result.p_top10; expbr[chosen]=head_result.expected_rank
        medbr[chosen]=head_result.median_rank; p90br[chosen]=head_result.rank_p90; pairbr[chosen]=head_result.pairwise_strength
        sibbr[chosen]=head_result.p_sibling_best; stabbr[chosen]=head_result.rank_stability; uncbr[chosen]=head_result.rank_uncertainty_width
    _go_receipt=dict(go.receipt)
    _go_receipt.update({
        "EXACT_ROLE_COMMON_WORLD_HEAD_CHANNEL_ACTIVE":bool(final_head_receipt.get("LIVE_HEAD_AUTHORITY_READY",False)),
        "EXACT_ROLE_COMMON_WORLD_HEAD_LIVE_AUTHORITY":bool(final_head_receipt.get("LIVE_HEAD_AUTHORITY_READY",False)),
        "BOARD_COMMON_WORLD_HEAD_RECEIPT":final_head_receipt,
        "NFL_SD_FAMILY_CONTEXT_RECEIPT":family_receipt,
        "two_family_championship_head_receipt":family_strength_receipt,
        "FAMILY_CONTEXT_TERMINAL_AUTHORITY":False,
        "MC_METRICS_ROLE":"SIGNAL_NOT_TRUTH",
        "RAW_MC_LITERAL_AUTHORITY":False,
    })
    ordinal=np.zeros(n,dtype=np.float64)
    if n: ordinal[full_order]=(n-np.arange(n,dtype=np.float64))/n
    state="NONEMPTY_PHASE3_BOARD_COMPLETE_CONTEST_CLASS"
    selector_receipt=hybrid_selector.selector_receipt(plan,n,cal.phase1_hash)
    selector_receipt["SINGLE_ENTRY_CHAMPIONSHIP_HEAD"]=single_entry_receipt
    metrics={
        **{k:np.asarray(v) for k,v in m.items()},"top01_percentile":top01p,"win_percentile":winp,"top10_percentile":top10p,
        "p95_percentile":p95p,"p99_percentile":p99p,"ownership_product":ownprod,"leverage":leverage,"selector_score":ordinal,
        "strict_eligible":np.flatnonzero(strict),"chosen":chosen,"selector_receipt":selector_receipt,
        "final_board_target":np.array([target],dtype=np.int32),"portfolio_preference_relaxation":np.array([0],dtype=np.int8),
        "right_neighborhood_receipt":rn_receipt,
        "two_family_championship_head_receipt":family_strength_receipt,
        "captain_sibling_head_receipt":sibling_head_receipt,
        "extreme_cpt_completion_receipt":extreme_cpt_completion_receipt,
        "one_mutation_head_receipt":one_mutation_head_receipt,
        "legacy_rank_order":np.asarray(legacy_order,dtype=np.int32),
        "native_rank_order":np.asarray(full_order,dtype=np.int32),
        "global_order_score":np.asarray(go.order_score,dtype=np.float64),
        "global_order_rank":np.asarray(go.order_rank,dtype=np.int32),
        "global_order_confidence":np.asarray(go.order_confidence,dtype=np.float64),
        "global_order_receipt":_go_receipt,
        "exact_role_head_score":exact_head_score,
        "p_board_rank_1":pbr1,"p_board_rank_top3":pbr3,"p_board_rank_top5":pbr5,"p_board_rank_top10":pbr10,
        "expected_board_rank":expbr,"median_board_rank":medbr,"board_rank_p90":p90br,
        "board_pairwise_strength":pairbr,"p_sibling_best":sibbr,"board_rank_stability":stabbr,"board_rank_uncertainty_width":uncbr,
        "family_context_score":famctx_full,"final_head_order_rank":final_head_rank,
        "defensive_balanced_reserve_indices":np.asarray(reserve,dtype=np.int32),
        "defensive_balanced_reserve_count":np.array([len(reserve)],dtype=np.int32),
        "extreme_script_closure_indices":np.asarray(extreme,dtype=np.int32),
        "extreme_script_closure_count":np.array([len(extreme)],dtype=np.int32),
        "td_event_onslaught_reserve_indices":np.asarray(td_event_onslaught_reserve,dtype=np.int32),
        "td_event_onslaught_reserve_receipt":td_event_onslaught_receipt,
        "portfolio_player_cap":np.array([player_cap],dtype=np.int32),
        "portfolio_captain_cap":np.array([captain_cap],dtype=np.int32),
        "portfolio_script_cap":np.array([script_cap],dtype=np.int32),
        "global_top_neighborhood_support":np.asarray(top_neighborhood_support,dtype=np.float64),
        "global_top_neighborhood_door_indices":np.asarray(neighbor_doors,dtype=np.int32),
        "mc_signal_terminal_receipt":mc_signal_receipt,
        "mc_signal_terminal_score_board":mc_signal_score_board,
        "mc_signal_terminal_disagreement_board":mc_signal_disagreement_board,
        "terminal_family_consensus_score_board":terminal_family_consensus_score_board,
        "terminal_family_consensus_order_receipt":family_receipt,
        "cross_world_core4_support_board":np.asarray(core4_primary,dtype=np.float64),
        "cross_world_core4_secondary_support_board":np.asarray(core4_secondary,dtype=np.float64),
        "cross_world_core4_protected_board":np.asarray(core4_protected,dtype=bool),
        "cross_world_core4_family_board":list(core4_family),
    }
    return rows[chosen] if chosen.size else np.empty((0,6),dtype=np.int32),metrics,state

def _ai_ranker_diagnostic(rows: np.ndarray, metrics: dict[str,np.ndarray], pmeta: dict[str,np.ndarray], cal: Calibration, cfg: Config) -> dict[str,Any]:
    """Freeze the AI/ranker surface for diagnostics without changing selection.

    This is strictly prelock telemetry. It records native rank order before protected
    reserve/portfolio overrides, the terminal board order after those overrides, and
    where protected reserve rows sat in the native ranker. Postlock contest truth may
    be joined later by a diagnostic grader but is never consumed here.
    """
    n=int(len(rows))
    order=np.asarray(metrics.get("native_rank_order",np.arange(n,dtype=np.int32)),dtype=np.int32)
    chosen=np.asarray(metrics.get("chosen",np.empty(0,dtype=np.int32)),dtype=np.int32)
    reserve=np.asarray(metrics.get("defensive_balanced_reserve_indices",np.empty(0,dtype=np.int32)),dtype=np.int32)
    native_rank=np.full(n,-1,dtype=np.int32)
    if n:
        native_rank[order]=np.arange(1,n+1,dtype=np.int32)

    def row_payload(idx:int, display_rank:int|None=None) -> dict[str,Any]:
        row=rows[int(idx)]
        names=cal.frame.iloc[row]["PLAYER"].astype(str).tolist()
        salary=int((cal.salary[row[0]]*3)//2+cal.salary[row[1:]].sum())
        payload={
            "PHASE2_INDEX":int(idx),
            "NATIVE_RANK":int(native_rank[int(idx)]) if n else -1,
            "CPT":names[0],
            "FLEX":names[1:],
            "SALARY":salary,
            "TOP01_RATE":float(metrics["top01_rate"][idx]),
            "WIN_RATE":float(metrics["win_rate"][idx]),
            "P95":float(metrics["p95"][idx]),
            "P99":float(metrics["p99"][idx]),
            "LEVERAGE":float(metrics["leverage"][idx]),
            "SELECTOR_SCORE":float(metrics["selector_score"][idx]),
            "FAMILY":int(pmeta["family"][idx]),
        }
        if display_rank is not None:
            payload["FINAL_BOARD_RANK"]=int(display_rank)
        return payload

    top5=[row_payload(int(i)) for i in order[:min(5,len(order))]]
    final5=[row_payload(int(i),j) for j,i in enumerate(chosen[:min(5,len(chosen))],1)]
    reserves=[row_payload(int(i)) for i in reserve]
    return {
        "PATCH_ID":"APEX_AI_RANKER_DIAGNOSTIC_SURFACE_v1",
        "STATUS":"PASS",
        "POSTLOCK_INPUT_USED":False,
        "AI_AUTHORITY":str(metrics.get("selector_receipt",{}).get("AI_AUTHORITY","RANK_SORT_COMPARE_TIEBREAK_PORTFOLIO_SELECT_ONLY")),
        "SELECTOR_MODE":str(metrics.get("selector_receipt",{}).get("SELECTOR_MODE","CODE_AI_HYBRID")),
        "PRIMARY_OBJECTIVE":str(metrics.get("selector_receipt",{}).get("SELECTOR_PRIMARY_OBJECTIVE","TOP_0_1_PERCENT_BOARD_CAPTURE")),
        "GLOBAL_ORDER_OBJECTIVE":global_order.ORDERING_OBJECTIVE,
        "NATIVE_RANKER_TOP5":top5,
        "FINAL_BOARD_TOP5":final5,
        "PROTECTED_RESERVE_NATIVE_RANKS":[int(native_rank[int(i)]) for i in reserve] if n else [],
        "PROTECTED_RESERVE_ROWS":reserves,
        "DIAGNOSTIC_REQUIRED_FIELDS":[
            "AI_AUTHORITY","SELECTOR_MODE","NATIVE_RANKER_TOP5","FINAL_BOARD_TOP5",
            "PROTECTED_RESERVE_NATIVE_RANKS","POSTLOCK_GRADED_TOP5","WINNER_NATIVE_RANK",
            "WINNER_FINAL_BOARD_RANK","TOP01_CAPTURE_BY_RANK_BUCKET"
        ],
    }

def _write_outputs(board: np.ndarray, rows: np.ndarray, metrics: dict[str,np.ndarray], pmeta: dict[str,np.ndarray], cal: Calibration, cfg: Config,
                   phase2_receipt: dict[str,int], sim: dict[str,Any], legal_scan: int, board_path: str|Path, receipt_path: str|Path) -> tuple[pd.DataFrame,dict[str,Any]]:
    chosen=np.asarray(metrics["chosen"],dtype=np.int32)
    board_records=[]
    for rank,(row,idx) in enumerate(zip(board,chosen),1):
        names=cal.frame.iloc[row]["PLAYER"].astype(str).tolist()
        teams=cal.frame.iloc[row]["TEAM"].astype(str).tolist()
        pos=cal.frame.iloc[row]["POS_BASE"].astype(str).tolist()
        salary=int((cal.salary[row[0]]*3)//2+cal.salary[row[1:]].sum())
        board_records.append({
            "RANK":rank,"CPT":names[0],"CPT_POS":pos[0],"CPT_TEAM":teams[0],"FLEX1":names[1],"FLEX2":names[2],"FLEX3":names[3],"FLEX4":names[4],"FLEX5":names[5],
            "SALARY":salary,"TEAM_SPLIT_CPT_TEAM":int(pmeta["same_cpt_team"][idx]),"TOP0050_RATE":float(metrics.get("top0050_rate",metrics["top01_rate"])[idx]),"TOP0100_RATE":float(metrics.get("top0100_rate",metrics["top01_rate"])[idx]),"TOP01_RATE":float(metrics["top01_rate"][idx]),"WIN_RATE":float(metrics["win_rate"][idx]),
            "TOP10_RATE":float(metrics["top10_rate"][idx]),"P95":float(metrics["p95"][idx]),"P99":float(metrics["p99"][idx]),"SELECTOR_SCORE":float(metrics["selector_score"][idx]),
            "GLOBAL_ORDER_SCORE":float(metrics["global_order_score"][idx]),"GLOBAL_ORDER_RANK":int(metrics["global_order_rank"][idx]),"GLOBAL_ORDER_CONFIDENCE":float(metrics["global_order_confidence"][idx]),
            "MC_SIGNAL_TERMINAL_SCORE":float(np.asarray(metrics.get("mc_signal_terminal_score_board",np.full(len(chosen),np.nan)))[rank-1]),
            "TERMINAL_FAMILY_CONSENSUS_SCORE":float(np.asarray(metrics.get("terminal_family_consensus_score_board",np.full(len(chosen),np.nan)))[rank-1]),
            "EXACT_ROLE_HEAD_SCORE":float(metrics["exact_role_head_score"][idx]) if np.isfinite(metrics["exact_role_head_score"][idx]) else None,
            "P_BOARD_RANK_1":float(metrics["p_board_rank_1"][idx]) if np.isfinite(metrics["p_board_rank_1"][idx]) else None,
            "P_BOARD_RANK_TOP3":float(metrics["p_board_rank_top3"][idx]) if np.isfinite(metrics["p_board_rank_top3"][idx]) else None,
            "P_BOARD_RANK_TOP5":float(metrics["p_board_rank_top5"][idx]) if np.isfinite(metrics["p_board_rank_top5"][idx]) else None,
            "P_BOARD_RANK_TOP10":float(metrics["p_board_rank_top10"][idx]) if np.isfinite(metrics["p_board_rank_top10"][idx]) else None,
            "EXPECTED_BOARD_RANK":float(metrics["expected_board_rank"][idx]) if np.isfinite(metrics["expected_board_rank"][idx]) else None,
            "MEDIAN_BOARD_RANK":float(metrics["median_board_rank"][idx]) if np.isfinite(metrics["median_board_rank"][idx]) else None,
            "BOARD_RANK_P90":float(metrics["board_rank_p90"][idx]) if np.isfinite(metrics["board_rank_p90"][idx]) else None,
            "BOARD_PAIRWISE_STRENGTH":float(metrics["board_pairwise_strength"][idx]) if np.isfinite(metrics["board_pairwise_strength"][idx]) else None,
            "P_SIBLING_BEST":float(metrics["p_sibling_best"][idx]) if np.isfinite(metrics["p_sibling_best"][idx]) else None,
            "FAMILY_CONTEXT_SCORE":float(metrics["family_context_score"][idx]) if np.isfinite(metrics["family_context_score"][idx]) else None,
            "FINAL_HEAD_ORDER_RANK":int(metrics["final_head_order_rank"][idx]),
            "MC_SIGNAL_DISAGREEMENT":float(np.asarray(metrics.get("mc_signal_terminal_disagreement_board",np.full(len(chosen),np.nan)))[rank-1]),
            "CROSS_WORLD_CORE4_SUPPORT":float(np.asarray(metrics.get("cross_world_core4_support_board",np.zeros(len(chosen))))[rank-1]),
            "CROSS_WORLD_CORE4_SECONDARY_SUPPORT":float(np.asarray(metrics.get("cross_world_core4_secondary_support_board",np.zeros(len(chosen))))[rank-1]),
            "GLOBAL_CORE_PROTECTED":bool(np.asarray(metrics.get("cross_world_core4_protected_board",np.zeros(len(chosen),dtype=bool)))[rank-1]),
            "GLOBAL_CORE_FAMILY_ID":str((metrics.get("cross_world_core4_family_board") or [""]*len(chosen))[rank-1]),
        })
    board_df=pd.DataFrame(board_records)
    Path(board_path).parent.mkdir(parents=True,exist_ok=True); board_df.to_csv(board_path,index=False)
    phase2_hash=_array_hash(rows)
    phase2_identity_ledger = [[str(cal.ids[j]) for j in row] for row in rows.tolist()]
    phase2_identity_blob = json.dumps(phase2_identity_ledger,separators=(",",":"),ensure_ascii=False).encode("utf-8")
    phase2_identity_hash = hashlib.sha256(phase2_identity_blob).hexdigest()
    receipt={
        "RUN_STATE":"TOOL_PROVEN_EXECUTED","ENGINE_ID":ENGINE_ID,"SPORT":SPORT,"MODE":MODE,"SEASON_STAGE":"REGULAR_SEASON","FIELD_SIZE":cfg.field_size,
        "DOCTRINE_ID":DOCTRINE_ID,
        "PROJECTION_PRESERVING_SHRINKAGE_PATCH_ID":PROJECTION_PRESERVING_SHRINKAGE_PATCH_ID,
        "CONTEST_CLASS_PORTFOLIO_PATCH_ID":CONTEST_CLASS_PORTFOLIO_PATCH_ID,
        "PORTFOLIO_VECTOR_SELECTOR_PATCH_ID":PORTFOLIO_VECTOR_SELECTOR_PATCH_ID,
        "EXTREME_SCRIPT_CLOSURE_PATCH_ID":EXTREME_SCRIPT_CLOSURE_PATCH_ID,
        "ORDINAL_WORLD_POSTERIOR_PATCH_ID":ORDINAL_WORLD_POSTERIOR_PATCH_ID,
        "GLOBAL_MC_SIGNAL_DOCTRINE_PATCH_ID":GLOBAL_MC_SIGNAL_DOCTRINE_PATCH_ID,
        "MC_METRICS_ROLE":"SIGNAL_NOT_TRUTH",
        "RAW_MC_LITERAL_AUTHORITY":False,
        "MC_SIGNAL_TERMINAL_ORDER_PATCH_ID":MC_SIGNAL_TERMINAL_ORDER_PATCH_ID,
        "TERMINAL_FAMILY_CONSENSUS_ORDER_PATCH_ID":TERMINAL_FAMILY_CONSENSUS_ORDER_PATCH_ID,
        "TERMINAL_FAMILY_CONSENSUS_ORDER":metrics.get("terminal_family_consensus_order_receipt",{}),
        "GLOBAL_CONDITIONAL_FAMILY_ORDINAL_HEAD_PATCH_ID":exact_head.PATCH_ID,
        "GLOBAL_CONDITIONAL_FAMILY_ORDINAL_HEAD":metrics.get("global_order_receipt",{}).get("BOARD_COMMON_WORLD_HEAD_RECEIPT",{}),
        "FAMILY_CONTEXT_TERMINAL_AUTHORITY":False,
        "CROSS_WORLD_CORE4_HANDOFF_PATCH_ID":CROSS_WORLD_CORE4_HANDOFF_PATCH_ID,
        "FAST_PATH_DOCTRINE_ID":"APEX_FAST_PATH_ENGINE_EXECUTION_v2","FAST_PATH_METHODS":["VECTORIZED_NUMPY_PANDAS","BOUNDED_CALIBRATION_FAMILY_ENUMERATION","STREAMING_FIXED_MEMORY_FIELD_SIM","PARTIAL_SELECTION_ARGPARTITION"],
        "SLOW_FALLBACK":False,"STRUCTURAL_FEASIBILITY_PRECHECK":"PASS","PREDICTIVE_LAYER":"APEX_GLOBAL_PREDICTIVE_MARKET_LAYER_v1",
        "PREDICTION_HASH":cal.prediction_hash,"ROLE_EVIDENCE_HASH":cal.role_evidence_hash,"MARKET_EVIDENCE_HASH":cal.market_evidence_hash,
        "ROLE_EVIDENCE_SNAPSHOT":cal.role_evidence_payload,"MARKET_EVIDENCE_SNAPSHOT":cal.market_evidence_payload,
        "ACTIVE_POOL":int(len(cal.frame)),"OUT_PURGE":cal.out_names,"ZERO_ROLE_SUPPRESSED":cal.zero_role_names,
        "LEGAL_SCAN_LINEUPS":int(legal_scan),**phase2_receipt,"PHASE3_CANDIDATE_LINEUPS":int(len(rows)),"HANDOFF_SURVIVORS":int(len(rows)),"SELECTOR_REVIEWED_LINEUPS":int(len(rows)),
        "POST_PHASE2_MUTATION_COUNT":0,"POST_PHASE1_RECALIBRATION_COUNT":0,"PHASE1_MC_TRIALS":int(cfg.player_trials),"PHASE1_CALIBRATION_HASH":cal.phase1_hash,
        "PHASE2_CALIBRATION_HASH":cal.phase1_hash,"PHASE3_CALIBRATION_HASH":cal.phase1_hash,"HANDOFF_CALIBRATION_HASH":cal.phase1_hash,
        "SELECTOR_INPUT_CALIBRATION_HASH":cal.phase1_hash,"FINAL_BOARD_CALIBRATION_HASH":cal.phase1_hash,"CALIBRATION_PARITY":"PASS",
        "PLAYER_SIMULATION_MATRIX_HASH":cal.player_sim_matrix_hash,
        "PHASE2_IDENTITY_LEDGER":phase2_identity_ledger,"PHASE2_IDENTITY_LEDGER_ROWS":int(len(phase2_identity_ledger)),"PHASE2_IDENTITY_LEDGER_SHA256":phase2_identity_hash,
        "REGULAR_SEASON_ROLE_MODEL":"SNAP_ROUTE_TARGET_CARRY_CURRENT_STATUS",
        "REGULAR_SEASON_PASS_CATCHER_TEAM_KEEP":int(cfg.regular_season_pass_catcher_team_keep),"REGULAR_SEASON_RB_TEAM_KEEP":int(cfg.regular_season_rb_team_keep),"GEOMETRY_BIRTH_PATCH_ID":GEOMETRY_BIRTH_PATCH_ID,"RED_ZONE_INGESTION_PATCH_ID":RED_ZONE_INGESTION_PATCH_ID,"FOOTBALL_MULTI_PATH_RED_ZONE_PATCH_ID":FOOTBALL_MULTI_PATH_RED_ZONE_PATCH_ID,"NFLVERSE_PRELOCK_ROLE_PATCH_ID":NFLVERSE_PRELOCK_ROLE_PATCH_ID,"NFLVERSE_PRELOCK_RECEIPT":cal.role_evidence_payload.get("nflverse_prelock_receipt",{}),"RED_ZONE_SIDECAR_RECEIPT":cal.frame.attrs.get("RED_ZONE_EVIDENCE_RECEIPT",{}),"MULTI_PATH_NONZERO_PLAYERS":int((pd.to_numeric(cal.frame.get("MULTI_PATH_CEILING",0),errors="coerce").fillna(0)>0).sum()) if "MULTI_PATH_CEILING" in cal.frame.columns else 0,"RED_ZONE_NONZERO_PLAYERS":int((pd.to_numeric(cal.frame.get("RED_ZONE_OPPORTUNITY",0),errors="coerce").fillna(0)>0).sum()) if "RED_ZONE_OPPORTUNITY" in cal.frame.columns else 0,"TD_EVENT_TAIL_PATCH_ID":TD_EVENT_TAIL_PATCH_ID,"TEAM_EVENT_NATIVE_WORLD_PATCH_ID":TEAM_EVENT_NATIVE_WORLD_PATCH_ID,"TEAM_EVENT_NATIVE_WORLD_RECEIPT":sim.get("team_event_native_world_receipt",{}),"MC_LATENT_VARIANCE_NORMALIZATION_PATCH_ID":MC_LATENT_VARIANCE_NORMALIZATION_PATCH_ID,"TD_EVENT_MARKET_PLAYERS":int((pd.to_numeric(cal.frame.get("TD_EVENT_LAMBDA",0),errors="coerce").fillna(0)>0).sum()) if "TD_EVENT_LAMBDA" in cal.frame.columns else 0,"TD_EVENT_MAX_LAMBDA":float(pd.to_numeric(cal.frame.get("TD_EVENT_LAMBDA",pd.Series([0.0])),errors="coerce").fillna(0.0).max()) if len(cal.frame) else 0.0,"CAPTAIN_SIBLING_HEAD_PATCH_ID":CAPTAIN_SIBLING_HEAD_PATCH_ID,"TWO_LANE_HEAD_PATCH_ID":TWO_LANE_HEAD_PATCH_ID,"TOP0050_HEAD_PATCH_ID":TOP0050_HEAD_PATCH_ID,"TWO_FAMILY_HEAD_PATCH_ID":TWO_FAMILY_HEAD_PATCH_ID,"TWO_FAMILY_HEAD_RECEIPT":metrics.get("two_family_championship_head_receipt",{}),"TOP0050_TARGET_RANK":int(sim.get("top0050_n",0)),"TOP0100_TARGET_RANK":int(sim.get("top0100_n",0)),"CAPTAIN_SIBLING_HEAD_RECEIPT":metrics.get("captain_sibling_head_receipt",{}),"EXTREME_CPT_COMPLETION_PATCH_ID":EXTREME_CPT_COMPLETION_PATCH_ID,"TD_EVENT_DOMINANT_ONSLAUGHT_RESERVE_PATCH_ID":TD_EVENT_DOMINANT_ONSLAUGHT_RESERVE_PATCH_ID,"EXTREME_CPT_COMPLETION_RECEIPT":metrics.get("extreme_cpt_completion_receipt",{}),"ONE_MUTATION_HEAD_PATCH_ID":ONE_MUTATION_HEAD_PATCH_ID,"ONE_MUTATION_HEAD_RECEIPT":metrics.get("one_mutation_head_receipt",{}),
        "POSITION_TEAM_CLOSURE_PATCH_ID":POSITION_TEAM_CLOSURE_PATCH_ID,"OWNERSHIP_CONTRACT_PATCH_ID":OWNERSHIP_CONTRACT_PATCH_ID,
        "OWNERSHIP_ROUTE_INVARIANT_PATCH_ID":OWNERSHIP_ROUTE_INVARIANT_PATCH_ID,"OWNERSHIP_ROUTE_INVARIANT_STATUS":"PASS",
        "DEFENSIVE_BALANCED_RESERVE_PATCH_ID":DEFENSIVE_BALANCED_RESERVE_PATCH_ID,
        "DEFENSIVE_BALANCED_RESERVE_COUNT":int(np.asarray(metrics.get("defensive_balanced_reserve_count",np.array([0])))[0]),
        "TOP5_PARLAY_POLICY_ID":TOP5_PARLAY_POLICY_ID,
        "CONTEST_CLASS_PORTFOLIO_PATCH_ID":CONTEST_CLASS_PORTFOLIO_PATCH_ID,
        "EXTREME_SCRIPT_CLOSURE_PATCH_ID":EXTREME_SCRIPT_CLOSURE_PATCH_ID,
        "EXTREME_SCRIPT_CLOSURE_COUNT":int(np.asarray(metrics.get("extreme_script_closure_count",np.array([0])))[0]),
        "PORTFOLIO_PLAYER_CAP":int(np.asarray(metrics.get("portfolio_player_cap",np.array([cfg.player_exposure_cap])))[0]),
        "PORTFOLIO_CAPTAIN_CAP":int(np.asarray(metrics.get("portfolio_captain_cap",np.array([cfg.captain_exposure_cap])))[0]),
        "PORTFOLIO_SCRIPT_CAP":int(np.asarray(metrics.get("portfolio_script_cap",np.array([cfg.script_exposure_cap])))[0]),
        "PORTFOLIO_OBJECTIVE":"CHAMPIONSHIP_HEAD_THEN_MARGINAL_WORLD_COVERAGE",
        "TOP5_PORTFOLIO_OBJECTIVE":"CHAMPIONSHIP_NEIGHBORHOOD_NO_BLIND_DIVERSIFICATION",
        "CHAMPIONSHIP_HEAD_POLICY_ID":championship_head_policy.PATCH_ID,
        "DIVERSIFICATION_START_SEAT":championship_head_policy.DIVERSIFICATION_START_SEAT,
        "DIVERSIFICATION_APPLIED_INSIDE_HEAD":False,
        "SUBTHRESHOLD_POSITIVE_ROLE_PATCH_ID":SUBTHRESHOLD_POSITIVE_ROLE_PATCH_ID,
        "PUBLIC_FIELD_OWNERSHIP_CONTRACT":cal.ownership_receipt,
        "PUBLIC_FIELD_UNIVERSE_DECOUPLING_PATCH_ID":PUBLIC_FIELD_UNIVERSE_DECOUPLING_PATCH_ID,
        "PUBLIC_FIELD_SOURCE":str(sim.get("public_field_source","UNKNOWN")),
        "PUBLIC_FIELD_ELIGIBLE_LINEUPS":int(sim.get("public_field_source_lineups",0)),
        "PUBLIC_FIELD_SOURCE_SHA256":str(sim.get("public_field_source_hash","")),
        "PUBLIC_FIELD_PHASE2_CONDITIONED":bool(sim.get("public_field_phase2_conditioned",True)),
        "PUBLIC_FIELD_JOINT_DEPENDENCE_PATCH_ID":PUBLIC_FIELD_JOINT_DEPENDENCE_PATCH_ID,
        "PUBLIC_FIELD_JOINT_DEPENDENCE":joint_field_model.installed_shadow_receipt(),
        "PUBLIC_FIELD_JOINT_DEPENDENCE_RUN_RECEIPT":sim.get("public_field_joint_dependence_receipt", {}),
        "PHASE2_FREEZE_HASH":phase2_hash,"PHASE3_INPUT_HASH":phase2_hash,"HANDOFF_INPUT_HASH":phase2_hash,"SELECTOR_INPUT_HASH":phase2_hash,"HANDOFF_METRIC_PARITY_CHECK":"PASS",
        "SHARED_METRIC_BUNDLE_ID":cal.shared_metric_bundle_id,"HANDOFF_PATCH_ID":HANDOFF_PATCH_ID,"BASE_SIM_TRIALS":int(cfg.base_trials),"ORDINAL_WORLD_TRIALS":int(sim.get("ordinal_world_count",0)),"FAKE_FIELD_LINEUPS":int(sim["fake_field_size"]),
        "BUBBLE_LINEUPS_FOUND":int(sim["bubble_found"]),"BUBBLE_EXTRA_TRIALS_TOTAL":int(sim["extra_total"]),"BUBBLE_LINEUPS_UNRESOLVED":int(sim["bubble_unresolved"]),
        "SELECTOR_REVIEWED_STRICT_ELIGIBLE":int(len(metrics["strict_eligible"])),**metrics["selector_receipt"],"RIGHT_NEIGHBORHOOD_DOOR_SELECTOR":metrics.get("right_neighborhood_receipt"),"FAMILY_STRUCTURE_PRESERVED":True,
        "GLOBAL_ORDER_INTELLIGENCE":metrics.get("global_order_receipt"),
        "GLOBAL_ORDER_INTELLIGENCE_PATCH_ID":global_order.PATCH_ID,
        "GLOBAL_ORDER_MEMBERSHIP_MUTATION":False,
        "MC_SIGNAL_TERMINAL_ORDER":metrics.get("mc_signal_terminal_receipt"),
        "MC_SIGNAL_TERMINAL_MEMBERSHIP_MUTATION":False,
        "AI_RANKER_DIAGNOSTIC":_ai_ranker_diagnostic(rows,metrics,pmeta,cal,cfg),
        "FINAL_BOARD_SIZE":int(len(board_df)),"FINAL_SALARY_RECOMPUTE":board_df["SALARY"].astype(int).tolist() if len(board_df) else [],
        "BOARD_LEGALITY":"PASS" if (len(board_df) and board_df["SALARY"].between(SALARY_MIN,SALARY_MAX).all()) else "FAIL",
        "SELECTOR_STATE":"NONEMPTY_PHASE3_BOARD_COMPLETE",
        "FINAL_BOARD_TARGET":int(np.asarray(metrics.get("final_board_target",np.array([min(cfg.board_size,len(rows))])))[0]),
        "NONEMPTY_BOARD_POLICY":"APEX_GLOBAL_NONEMPTY_PRODUCTION_BOARD_v1",
        "PORTFOLIO_PREFERENCE_RELAXATION":bool(int(np.asarray(metrics.get("portfolio_preference_relaxation",np.array([0])))[0])),
        "EXECUTION_STATE":"TOOL_PROVEN_EXECUTED",
    }
    Path(receipt_path).write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
    return board_df,receipt

def _ownership_route_receipt_from_frame(df: pd.DataFrame) -> dict[str,Any]:
    required={"RST%","RW_RST_PRIOR","APEX_OWNERSHIP_AUTHORITY","APEX_OWNERSHIP_ROUTE_PATCH_ID"}
    missing=sorted(required-set(df.columns))
    if missing:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_OWNERSHIP_ROUTE_INVARIANT_MISSING:"+",".join(missing))
    mass=float(pd.to_numeric(df["RST%"],errors="coerce").fillna(0.0).sum())
    authority=set(df["APEX_OWNERSHIP_AUTHORITY"].astype(str))
    patch=set(df["APEX_OWNERSHIP_ROUTE_PATCH_ID"].astype(str))
    if abs(mass-600.0)>1e-5:
        raise RuntimeError(f"RUN_INVALID:NFL_SHOWDOWN_OWNERSHIP_ROUTE_INVARIANT_MASS:{mass}")
    if authority!={"NFL_SD_COMMON_INTERNAL_BOOTSTRAP_600_MASS"}:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_OWNERSHIP_ROUTE_INVARIANT_AUTHORITY")
    if patch!={OWNERSHIP_ROUTE_INVARIANT_PATCH_ID}:
        raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_OWNERSHIP_ROUTE_INVARIANT_PATCH")
    return {"PATCH_ID":OWNERSHIP_ROUTE_INVARIANT_PATCH_ID,"STATUS":"PASS","BRIDGE_MASS":mass,"AUTHORITY":"NFL_SD_COMMON_INTERNAL_BOOTSTRAP_600_MASS","DIRECT_RAW_PLAYER_FILE_EXECUTION":True}


def run(pool: str|Path, field_size: int, role_evidence: str|Path, market_evidence: str|Path|None, board_path: str|Path, receipt_path: str|Path,
        seed: int|None=None, config: Config|None=None, availability_receipt: str|Path|None=None, execution_id: str|int|None=None,
        nflverse_cache_dir: str|Path|None=None, nflverse_as_of: str|None=None, nflverse_seasons: Sequence[int]|None=None, nflverse_refresh: bool=False) -> tuple[pd.DataFrame,dict[str,Any]]:
    if config is None:
        native_budget, _native_budget_receipt = _resolve_native_portfolio_budget(int(field_size))
        cfg=Config(field_size=int(field_size),seed=int(seed if seed is not None else field_size),board_size=int(native_budget))
    else:
        cfg=config
        _native_budget_receipt={"PATCH_ID":"NFL_SD_MAX_ENTRY_NATIVE_PORTFOLIO_v1","SOURCE":"EXPLICIT_CONFIG","USER_ENTRY_BUDGET":int(cfg.board_size)}
    cfg.validate()
    resolved_execution_id=str(execution_id if execution_id is not None else field_size)
    roster_gate=require_prebuild_roster_check(availability_receipt,sport="NFL",mode="SHOWDOWN",pool_path=pool,execution_id=resolved_execution_id,field_size=field_size)
    nv_cfg={"enabled": bool(nflverse_cache_dir), "cache_dir": str(nflverse_cache_dir) if nflverse_cache_dir is not None else None, "as_of": nflverse_as_of, "seasons": list(nflverse_seasons) if nflverse_seasons is not None else None, "refresh": bool(nflverse_refresh)} if nflverse_cache_dir is not None else None
    cal=_load_calibration(pool,role_evidence,market_evidence,cfg,roster_gate,nflverse_config=nv_cfg)
    ownership_route_receipt=_ownership_route_receipt_from_frame(cal.frame)
    if set(cal.out_names) != set(roster_gate.out_players):
        raise RuntimeError("RUN_INVALID:NFL_ROLE_EVIDENCE_ROSTER_GATE_OUT_PARITY_MISMATCH")
    legal_scan=_legal_scan_count(cal)
    candidates,cmeta=_generate_candidates(cal,cfg)
    phase2,pmeta,p2rec=_phase2(candidates,cmeta,cal,cfg)
    if not len(phase2): raise RuntimeError("RUN_INVALID:NFL_SHOWDOWN_PHASE2_ZERO")
    phase2_hash=_array_hash(phase2)
    sim=_simulate_phase2(phase2,cal,cfg,public_field_rows=candidates)
    _receipt_path=Path(receipt_path)
    _reliability_path=_receipt_path.with_name(_receipt_path.stem+".mc_reliability_surface.npz")
    _reliability_meta_path=_receipt_path.with_name(_receipt_path.stem+".mc_reliability_surface.json")
    reliability_surface_receipt=mc_reliability_ledger.freeze_prelock_surface(
        phase2,pmeta,sim["metrics"],cal,field_size=cfg.field_size,seed=cfg.seed,
        execution_id=resolved_execution_id,output_path=_reliability_path,metadata_path=_reliability_meta_path,
        public_field_source_hash=str(sim.get("public_field_source_hash","")),
    )
    board,metrics,state=_select(phase2,pmeta,sim,cal,cfg)
    board_df,receipt=_write_outputs(board,phase2,metrics,pmeta,cal,cfg,p2rec,sim,legal_scan,board_path,receipt_path)
    receipt["SELECTOR_STATE"]=state
    receipt["NATIVE_PORTFOLIO_BUDGET"]=_native_budget_receipt
    receipt["PREBUILD_ROSTER_CHECK"]=gate_receipt(roster_gate)
    receipt["OWNERSHIP_ROUTE_INVARIANT"]=ownership_route_receipt
    receipt["MC_RELIABILITY_LEDGER_PATCH_ID"]=MC_RELIABILITY_LEDGER_PATCH_ID
    receipt["MC_RELIABILITY_PRELOCK_SURFACE"]=reliability_surface_receipt
    Path(receipt_path).write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
    if receipt["PHASE2_FREEZE_HASH"] != phase2_hash or receipt["POST_PHASE2_MUTATION_COUNT"] != 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:PHASE2_PARITY_DRIFT")
    return board_df,receipt


def _args()->argparse.Namespace:
    ap=argparse.ArgumentParser()
    ap.add_argument("--pool",required=True); ap.add_argument("--field-size",required=True,type=int)
    ap.add_argument("--role-evidence",required=True); ap.add_argument("--market-evidence")
    ap.add_argument("--availability-receipt",required=True); ap.add_argument("--execution-id",required=True)
    ap.add_argument("--board",required=True); ap.add_argument("--receipt",required=True); ap.add_argument("--seed",type=int)
    ap.add_argument("--nflverse-cache-dir"); ap.add_argument("--nflverse-as-of"); ap.add_argument("--nflverse-seasons",nargs="*",type=int); ap.add_argument("--nflverse-refresh",action="store_true")
    return ap.parse_args()


def main()->int:
    a=_args()
    try:
        board,receipt=run(a.pool,a.field_size,a.role_evidence,a.market_evidence,a.board,a.receipt,a.seed,availability_receipt=a.availability_receipt,execution_id=a.execution_id,nflverse_cache_dir=a.nflverse_cache_dir,nflverse_as_of=a.nflverse_as_of,nflverse_seasons=a.nflverse_seasons,nflverse_refresh=a.nflverse_refresh)
        print(json.dumps({k:receipt[k] for k in ["ENGINE_ID","ACTIVE_POOL","OUT_PURGE","LEGAL_SCAN_LINEUPS","PHASE2_BUILT_LINEUPS","BASE_SIM_TRIALS","BUBBLE_EXTRA_TRIALS_TOTAL","BUBBLE_LINEUPS_UNRESOLVED","HANDOFF_SURVIVORS","SELECTOR_REVIEWED_LINEUPS","FINAL_BOARD_SIZE","EXECUTION_STATE"]},indent=2))
        if len(board): print(board.to_string(index=False))
        return 0
    except Exception as exc:
        print(json.dumps({"RUN_STATE":"RUN_INVALID","ENGINE_ID":ENGINE_ID,"FINAL_BOARD_SIZE":0,"ENGINE_SUBSTITUTION":False,"FAILURE_CODE":f"{type(exc).__name__}:{exc}"},indent=2))
        return 1


if __name__=="__main__": raise SystemExit(main())
