from __future__ import annotations

import argparse
import hashlib
import heapq
import importlib.util
import itertools
import json
import math
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

_STATE_ROOT_FOR_IMPORTS = Path(__file__).resolve().parents[2]
if str(_STATE_ROOT_FOR_IMPORTS) not in sys.path:
    sys.path.insert(0, str(_STATE_ROOT_FOR_IMPORTS))

from engines.common.mandatory_prebuild_roster_gate_v1 import gate_receipt, require_prebuild_roster_check
from engines.nfl import nfl_classic_frozen_calibration_hybrid_selector_v1 as hybrid_selector
from engines.nfl import nfl_classic_world_native_birth_v1 as world_birth
from engines.nfl import nfl_classic_historical_field_ranker_v1 as historical_ranker
from engines.common import right_neighborhood_door_selector_v1 as rn_door
from engines.common import apex_entry_limit_game_theory_v1 as entry_limit_game

ENGINE_ID = "APEX_NFL_CLASSIC_RAW_POOL_RUNTIME_v1"
SPORT = "NFL"
MODE = "CLASSIC"
DOCTRINE_ID = "NFL_CLASSIC_REGULAR_SEASON_ROLE_CORRELATION_CALIBRATION_v1"
HANDOFF_PATCH_ID = "HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1"
NFL_CLASSIC_CHAMPIONSHIP_REPAIR_ID = "NFL_CLASSIC_CHAMPIONSHIP_CONSTRUCTION_TAIL_STRATEGY_v1"
NFL_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_PATCH_ID = "NFL_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_v1"
SALARY_MAX = 50_000
SALARY_MIN = 48_000
ROSTER_SIZE = 9

ROOT = Path(__file__).resolve().parents[2]
_STRATEGY_PATH = ROOT / "engines" / "common" / "apex_global_sports_strategy_layer_v1.py"
_spec = importlib.util.spec_from_file_location("apex_global_sports_strategy_layer_v1_nfl_classic", _STRATEGY_PATH)
if _spec is None or _spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_SPORTS_STRATEGY_LAYER_UNAVAILABLE")
strategy_mod = importlib.util.module_from_spec(_spec)
sys.modules.setdefault(_spec.name, strategy_mod)
_spec.loader.exec_module(strategy_mod)


def _stable_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def _array_hash(a: np.ndarray) -> str:
    x = np.ascontiguousarray(a)
    return hashlib.sha256(x.view(np.uint8)).hexdigest()


def _pct(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    n = values.size
    if n == 0:
        return np.asarray([], dtype=np.float64)
    order = np.argsort(values, kind="stable")
    out = np.empty(n, dtype=np.float64)
    sorted_v = values[order]
    i = 0
    while i < n:
        j = i + 1
        while j < n and sorted_v[j] == sorted_v[i]:
            j += 1
        out[order[i:j]] = ((i + j - 1) / 2.0 + 0.5) / n
        i = j
    return out


def _wilson(success: np.ndarray, trials: np.ndarray | int, z: float = 1.96) -> tuple[np.ndarray, np.ndarray]:
    s = np.asarray(success, dtype=np.float64)
    n = np.asarray(trials, dtype=np.float64)
    p = np.divide(s, n, out=np.zeros_like(s), where=n > 0)
    den = 1.0 + z * z / n
    center = (p + z * z / (2.0 * n)) / den
    half = z * np.sqrt(np.maximum(0.0, p * (1.0 - p) / n + z * z / (4.0 * n * n))) / den
    return np.maximum(0.0, center - half), np.minimum(1.0, center + half)


def _pos_base(raw: str) -> str:
    return str(raw).split("/")[0].strip().upper()


def _game_key(team: str, opp: str) -> str:
    a, b = sorted((str(team).upper(), str(opp).upper()))
    return f"{a}@{b}"



def _to_float(value: Any) -> float:
    try:
        if value is None:
            return float("nan")
        text = str(value).strip().replace(",", "")
        if not text or text in {"-", "nan", "None"}:
            return float("nan")
        return float(text)
    except Exception:
        return float("nan")


def _american_implied_prob(value: Any) -> float:
    x = _to_float(value)
    if not math.isfinite(x) or x == 0:
        return float("nan")
    return float(100.0 / (x + 100.0) if x > 0 else (-x) / ((-x) + 100.0))


def _position_percentile(values: np.ndarray, pos: np.ndarray) -> np.ndarray:
    out = np.zeros(len(values), dtype=np.float64)
    for p in np.unique(pos):
        idx = np.flatnonzero(pos == p)
        if not len(idx):
            continue
        v = np.asarray(values[idx], dtype=float)
        finite = np.isfinite(v)
        if finite.any():
            fill = float(np.nanmin(v[finite])) - 1.0
            vv = np.where(finite, v, fill)
            out[idx] = _pct(vv)
    return out


def _attach_pool_native_market_features(df: pd.DataFrame) -> pd.DataFrame:
    """Use player-level sportsbook opportunity already frozen in the player file.

    This is not a postlock signal and does not replace source-backed availability. It gives
    Week-1/early-season role and tail calibration a football-native prior when historical
    current-season box-score columns are sparse or zero.
    """
    out = df.copy()
    pos = out["POS_BASE"].astype(str).to_numpy(object)
    def col(name: str) -> np.ndarray:
        if name not in out.columns:
            return np.full(len(out), np.nan, dtype=np.float64)
        return np.asarray([_to_float(x) for x in out[name].tolist()], dtype=np.float64)
    psyd, ruyd, reyd, rec = col("O/U PSYD"), col("O/U RUYD"), col("O/U REYD"), col("O/U REC")
    td1 = np.asarray([_american_implied_prob(x) for x in out.get("1+ TD", pd.Series([np.nan] * len(out))).tolist()], dtype=np.float64)
    td2 = np.asarray([_american_implied_prob(x) for x in out.get("2+ TD", pd.Series([np.nan] * len(out))).tolist()], dtype=np.float64)
    raw = np.zeros(len(out), dtype=np.float64)
    confidence = np.zeros(len(out), dtype=np.float64)
    for i, p in enumerate(pos):
        if p == "QB":
            parts = [(psyd[i], 300.0, .58), (ruyd[i], 70.0, .22), (td1[i], 1.0, .20)]
        elif p == "RB":
            parts = [(ruyd[i], 105.0, .44), (reyd[i], 65.0, .18), (rec[i], 6.5, .16), (td1[i], 1.0, .18), (td2[i], 1.0, .04)]
        elif p in {"WR", "TE"}:
            parts = [(reyd[i], 105.0, .48), (rec[i], 8.0, .27), (td1[i], 1.0, .21), (td2[i], 1.0, .04)]
        else:
            parts = []
        got = [(v, scale, w) for v, scale, w in parts if math.isfinite(v)]
        if got:
            sw = sum(w for _, _, w in got)
            raw[i] = sum(w * max(0.0, v / scale) for v, scale, w in got) / max(sw, 1e-9)
            confidence[i] = min(1.0, len(got) / max(1, len(parts)))
    pct = _position_percentile(raw, pos)
    # No-prop rows do not get artificial percentile authority.
    pct = np.where(confidence > 0.0, pct, 0.0)
    out["MARKET_OPPORTUNITY_RAW"] = raw
    out["MARKET_OPPORTUNITY"] = pct
    out["MARKET_ROLE_CONFIDENCE"] = confidence
    out["MARKET_TD1_PROB"] = np.nan_to_num(td1, nan=0.0)
    out["MARKET_TD2_PROB"] = np.nan_to_num(td2, nan=0.0)
    out["MARKET_PASS_YDS"] = np.nan_to_num(psyd, nan=0.0)
    out["MARKET_RUSH_YDS"] = np.nan_to_num(ruyd, nan=0.0)
    out["MARKET_REC_YDS"] = np.nan_to_num(reyd, nan=0.0)
    out["MARKET_REC"] = np.nan_to_num(rec, nan=0.0)
    return out


def _resolve_native_portfolio_budget(field_size: int) -> tuple[int, dict[str, Any]]:
    """Resolve NFL Classic native playable membership from MAX ENTRY / USER ENTRIES."""
    import os
    raw_max = os.environ.get("APEX_MAX_ENTRIES")
    raw_user = os.environ.get("APEX_USER_ENTRIES")
    if raw_max not in (None, ""):
        profile = entry_limit_game.build_entry_limit_profile(
            field_size=int(field_size), max_entries=raw_max, user_entries=raw_user
        )
        return int(profile.our_entry_budget), {
            "PATCH_ID": NFL_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_PATCH_ID,
            "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
            "CONTEST_MAX_ENTRIES": int(profile.contest_max_entries),
            "USER_ENTRY_BUDGET": int(profile.our_entry_budget),
            "REGIME": str(profile.regime),
            "SOURCE": "APEX_MAX_ENTRIES/APEX_USER_ENTRIES",
        }
    return 10, {
        "PATCH_ID": NFL_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_PATCH_ID,
        "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
        "SOURCE": "LEGACY_EXPLICIT_CONFIG_OR_TEST_DEFAULT",
        "USER_ENTRY_BUDGET": 10,
    }


def _scaled_portfolio_caps(cfg: "Config", target: int) -> tuple[int, int, int, int]:
    """Preserve the original 10-seat NFL exposure geometry at larger entry budgets."""
    target = max(1, int(target))
    base = 10
    return (
        max(1, int(math.ceil((float(cfg.player_exposure_cap) / base) * target))),
        max(1, int(math.ceil((float(cfg.qb_exposure_cap) / base) * target))),
        max(1, int(math.ceil((float(cfg.dst_exposure_cap) / base) * target))),
        max(1, int(math.ceil((float(cfg.family_exposure_cap) / base) * target))),
    )


@dataclass(frozen=True)
class Config:
    field_size: int
    seed: int
    player_trials: int = 50_000
    base_trials: int = 10_000
    extra_batch_trials: int = 10_000
    max_trials: int = 50_000
    phase2_keep: int = 20_000
    candidate_global_keep: int = 16_000
    family_keep: int = 180
    qb_family_keep: int = 180
    fill_beam_width: int = 8
    fill_pool_rb: int = 32
    fill_pool_wr: int = 48
    fill_pool_te: int = 32
    fill_pool_dst: int = 16
    seed_pass_catchers: int = 2
    seed_rbs: int = 1
    seed_bringbacks: int = 2
    closure_per_salary_keep: int = 10
    closure_final_keep: int = 8_000
    closure_pool_rb: int = 36
    closure_pool_wr: int = 46
    closure_pool_te: int = 34
    projection_phase2_keep: int = 6_000
    tail_phase2_keep: int = 6_000
    market_phase2_keep: int = 3_000
    selector_primary_tie_width: float = 0.001
    bubble_cap: int = 96
    board_size: int = 10
    player_exposure_cap: int = 7
    qb_exposure_cap: int = 3
    dst_exposure_cap: int = 3
    family_exposure_cap: int = 4
    max_pairwise_overlap: int = 7
    fake_field_multiplier: float = 1.0
    test_mode: bool = False

    def validate(self) -> None:
        if self.field_size <= 0:
            raise RuntimeError("RUN_INVALID:INVALID_FIELD_SIZE")
        if not self.test_mode and self.player_trials < 50_000:
            raise RuntimeError("ENGINE_INTEGRITY_HALT:PHASE1_MC_TRIALS_LT_50000")
        if not self.test_mode and self.base_trials < 10_000:
            raise RuntimeError("ENGINE_INTEGRITY_HALT:BASE_SIM_TRIALS_LT_10000")
        if self.max_trials < self.base_trials or self.extra_batch_trials <= 0:
            raise RuntimeError("RUN_INVALID:INVALID_ADAPTIVE_SIM_CONFIG")
        if self.phase2_keep <= 0 or self.board_size <= 0:
            raise RuntimeError("RUN_INVALID:INVALID_PORTFOLIO_CONFIG")


@dataclass
class Calibration:
    frame: pd.DataFrame
    ids: np.ndarray
    pos: np.ndarray
    team: np.ndarray
    opp: np.ndarray
    game: np.ndarray
    salary: np.ndarray
    role_snap: np.ndarray
    role_routes: np.ndarray
    role_targets: np.ndarray
    role_carries: np.ndarray
    role_uncertainty: np.ndarray
    strategy: Any
    mu: np.ndarray
    sigma: np.ndarray
    p95: np.ndarray
    p99: np.ndarray
    ownership: np.ndarray
    correlation: np.ndarray
    covariance: np.ndarray
    phase1_hash: str
    shared_metric_bundle_id: str
    prediction_hash: str
    role_evidence_hash: str
    market_evidence_hash: str
    role_evidence_payload: dict[str, Any]
    market_evidence_payload: dict[str, Any]
    out_names: list[str]
    zero_role_names: list[str]
    player_sim_matrix_hash: str


def _load_json(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        raise RuntimeError(f"RUN_INVALID:EVIDENCE_FILE_MISSING:{p}")
    return json.loads(p.read_text(encoding="utf-8"))


HARD_ROLE_STATUSES = {"OUT", "IR", "DNP", "REST", "CONFIRMED_OUT", "DOUBTFUL"}
UNCERTAIN_REGULAR_SEASON_STATUSES = {"QUESTIONABLE", "DOUBTFUL", "DNP", "ACTIVE_UNCERTAIN", "UNKNOWN", "UNCONFIRMED"}
SYNTHETIC_TEST_EVIDENCE_MODES = {"SYNTHETIC_TEST_ROLE_PRIORS", "TEST_SYNTHETIC_ROLE_PRIORS", "TEST_FIXTURE"}


def _production_role_eligibility(name: str, pos: str, ev: dict[str, Any], evidence_mode: str) -> tuple[bool, str]:
    """Regular-season role gate using current, source-backed opportunity evidence."""
    if evidence_mode in SYNTHETIC_TEST_EVIDENCE_MODES:
        return True, "SYNTHETIC_TEST_MODE"
    if pos == "DST":
        return True, "DST_TEAM_UNIT"
    if not ev:
        return False, "ROLE_EVIDENCE_MISSING"
    if not str(ev.get("source_ref") or "").strip():
        return False, "ROLE_SOURCE_MISSING"
    st = str(ev.get("status", "UNCONFIRMED")).strip().upper()
    if st in {"OUT", "IR", "CONFIRMED_OUT"}:
        return False, f"STATUS_{st}"
    s = float(ev.get("snap_share", 0.0) or 0.0)
    r = float(ev.get("route_share", 0.0) or 0.0)
    t = float(ev.get("target_share", 0.0) or 0.0)
    c = float(ev.get("carry_share", 0.0) or 0.0)
    if pos == "QB": meaningful = s >= 0.20
    elif pos == "RB": meaningful = s >= 0.15 or c >= 0.10 or t >= 0.05
    elif pos in {"WR", "TE"}: meaningful = s >= 0.15 or r >= 0.15 or t >= 0.05
    else: meaningful = max(s, r, t, c) > 0.0
    if not meaningful:
        return False, "NO_MEANINGFUL_ROLE_EVIDENCE"
    return True, "VERIFIED_CURRENT_ROLE"

def _reconcile_role_evidence_with_availability(role_evidence: dict[str, Any], roster_gate: Any) -> dict[str, Any]:
    payload = json.loads(json.dumps(role_evidence))
    players = payload.get("players", {})
    if not isinstance(players, dict):
        raise RuntimeError("RUN_INVALID:ROLE_EVIDENCE_PLAYERS_INVALID")
    gate_out = set(roster_gate.out_players)
    latest_status = dict(getattr(roster_gate, "nfl_latest_status_by_player", {}) or {})
    unresolved_status = set(getattr(roster_gate, "nfl_unresolved_hard_out_candidates", ()) or ())
    forced_active_uncertain: list[str] = []
    forced_out: list[str] = []
    status_uncertain: list[str] = []
    status_confirmed: list[str] = []
    for name, raw in list(players.items()):
        ev = raw if isinstance(raw, dict) else {}
        st = str(ev.get("status", "ACTIVE")).strip().upper()
        if st in {"OUT", "IR", "CONFIRMED_OUT"} and name not in gate_out:
            ev["status"] = "ACTIVE_UNCERTAIN"
            ev["role_uncertainty"] = max(float(ev.get("role_uncertainty", 0.0) or 0.0), 0.70)
            ev["AVAILABILITY_RECONCILED"] = "STALE_OR_UNPROVEN_ROLE_OUT_RELEASED"
            players[name] = ev
            forced_active_uncertain.append(name)
    for name, latest in latest_status.items():
        ev = players.get(name, {})
        if not isinstance(ev, dict): ev = {}
        st = str(latest).strip().upper()
        if st in {"OUT", "IR", "CONFIRMED_OUT"}:
            ev["status"] = st
            ev["availability_confirmed"] = False
            ev["AVAILABILITY_RECONCILED"] = f"LATEST_OFFICIAL_STATUS_{st}"
            players[name] = ev
        elif st in UNCERTAIN_REGULAR_SEASON_STATUSES:
            ev["status"] = st
            ev["availability_confirmed"] = None
            ev["role_uncertainty"] = max(float(ev.get("role_uncertainty", 0.25) or 0.25), 0.45 if st == "QUESTIONABLE" else 0.60)
            ev["AVAILABILITY_RECONCILED"] = f"LATEST_OFFICIAL_STATUS_{st}_UNCERTAINTY_ONLY"
            players[name] = ev
            status_uncertain.append(name)
        elif st in {"ACTIVE", "AVAILABLE", "ACTIVATED", "REINSTATED", "PROMOTED", "RETURNED"}:
            ev["availability_confirmed"] = True
            ev["AVAILABILITY_RECONCILED"] = f"LATEST_OFFICIAL_STATUS_{st}"
            players[name] = ev
            status_confirmed.append(name)
    for name in sorted(unresolved_status - set(latest_status)):
        ev = players.get(name, {})
        if not isinstance(ev, dict): ev = {}
        ev["status"] = "UNCONFIRMED"
        ev["availability_confirmed"] = None
        ev["role_uncertainty"] = max(float(ev.get("role_uncertainty", 0.25) or 0.25), 0.70)
        ev["AVAILABILITY_RECONCILED"] = "UNRESOLVED_OFFICIAL_STATUS_UNCERTAINTY_ONLY"
        players[name] = ev
        status_uncertain.append(name)
    for name in sorted(gate_out):
        ev = players.get(name, {})
        if not isinstance(ev, dict): ev = {}
        forced_out.append(name)
        ev.update({
            "status": "OUT", "snap_share": 0.0, "route_share": 0.0,
            "target_share": 0.0, "carry_share": 0.0,
            "role_uncertainty": min(float(ev.get("role_uncertainty", 0.02) or 0.02), 0.05),
            "AVAILABILITY_RECONCILED": "GATE_VERIFIED_HARD_OUT",
        })
        players[name] = ev
    payload["players"] = players
    payload["availability_reconciliation"] = {
        "PATCH_ID": "NFL_REGULAR_SEASON_CURRENT_ROLE_AVAILABILITY_v1",
        "SEASON_STAGE": "REGULAR_SEASON",
        "ROLE_EVIDENCE_FORCED_ACTIVE_UNCERTAIN": sorted(forced_active_uncertain),
        "ROLE_EVIDENCE_FORCED_OUT": sorted(forced_out),
        "GATE_OUT_PLAYERS": sorted(gate_out),
        "UNRESOLVED_HARD_OUT_CANDIDATES": sorted(unresolved_status),
        "LATEST_STATUS_BY_PLAYER": latest_status,
        "CURRENT_STATUS_UNCERTAIN": sorted(set(status_uncertain)),
        "CURRENT_STATUS_CONFIRMED_AVAILABLE": sorted(set(status_confirmed)),
        "POSTLOCK_RESULTS_USED": False,
        "PLAYER_NAME_FORWARD_LOGIC": False,
    }
    return payload

def _synthetic_test_default_role(pos: str) -> tuple[float, float, float, float, float]:
    """Test-fixture priors only; never used by live production."""
    if pos == "QB": return 0.70, 0.00, 0.00, 0.04, 0.30
    if pos == "RB": return 0.50, 0.18, 0.12, 0.34, 0.25
    if pos == "WR": return 0.62, 0.56, 0.24, 0.01, 0.25
    if pos == "TE": return 0.58, 0.45, 0.18, 0.01, 0.25
    if pos == "DST": return 1.00, 0.00, 0.00, 0.00, 0.12
    return 0.0, 0.0, 0.0, 0.0, 0.85

def _prepare_frame(pool: str | Path, role_evidence: dict[str, Any], market_evidence: dict[str, Any]) -> tuple[pd.DataFrame, list[str], list[str]]:
    df = pd.read_csv(pool)
    required = {"PLAYER", "POS", "TEAM", "OPP", "SAL", "FPTS", "Ceil", "Floor", "RST%"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise RuntimeError("RUN_INVALID:NFL_CLASSIC_POOL_FIELDS_MISSING:" + ",".join(missing))
    if df.empty or df["PLAYER"].astype(str).duplicated().any():
        raise RuntimeError("RUN_INVALID:NFL_CLASSIC_POOL_EMPTY_OR_DUPLICATE_PLAYER")
    df = df.copy()
    df["POS_BASE"] = df["POS"].map(_pos_base)
    df = df[df["POS_BASE"].isin(["QB", "RB", "WR", "TE", "DST"])].reset_index(drop=True)
    if df.empty:
        raise RuntimeError("RUN_INVALID:NFL_CLASSIC_NO_ELIGIBLE_POSITIONS")
    df["TEAM"] = df["TEAM"].astype(str).str.upper().str.strip()
    df["OPP"] = df["OPP"].astype(str).str.upper().str.strip()
    df["GAME_KEY"] = [_game_key(t, o) for t, o in zip(df["TEAM"], df["OPP"])]

    players = role_evidence.get("players", {})
    if not isinstance(players, dict):
        raise RuntimeError("RUN_INVALID:ROLE_EVIDENCE_PLAYERS_INVALID")
    evidence_mode = str(role_evidence.get("evidence_mode", "UNSPECIFIED")).upper()
    if evidence_mode in {"RAW_PROJECTION_ONLY", "AGGREGATE_PROJECTION_ONLY", "FPTS_ONLY"}:
        raise RuntimeError("RUN_INVALID:RAW_AGGREGATE_PROJECTION_PHASE1_PROHIBITED")

    status, snap, routes, targets, carries, role_unc = [], [], [], [], [], []
    out_names, zero_role = [], []
    role_gate_reason = []
    production_mode = evidence_mode not in SYNTHETIC_TEST_EVIDENCE_MODES
    for _, row in df.iterrows():
        name = str(row["PLAYER"])
        pos = str(row["POS_BASE"])
        base = _synthetic_test_default_role(pos)
        ev = players.get(name, {}) or {}
        eligible, gate_reason = _production_role_eligibility(name, pos, ev, evidence_mode)
        role_gate_reason.append(gate_reason)
        if production_mode and not eligible:
            raw_status = str(ev.get("status", "UNCONFIRMED")).strip().upper()
            if raw_status in {"OUT", "IR", "CONFIRMED_OUT"}:
                st = raw_status
                s = r = t = c = 0.0
                u = min(float(ev.get("role_uncertainty", 0.05) or 0.05), 0.05)
                out_names.append(name)
            else:
                st = "ROLE_UNVERIFIED"
                s = r = t = c = 0.0
                u = 0.85
        else:
            st = str(ev.get("status", "ACTIVE")).strip().upper()
            # Generic priors are permitted only in explicit synthetic test modes.
            if production_mode:
                s = float(ev.get("snap_share", 0.0) or 0.0)
                r = float(ev.get("route_share", 0.0) or 0.0)
                t = float(ev.get("target_share", 0.0) or 0.0)
                c = float(ev.get("carry_share", 0.0) or 0.0)
                u = float(ev.get("role_uncertainty", 0.25) or 0.25)
            else:
                s = float(ev.get("snap_share", base[0]))
                r = float(ev.get("route_share", base[1]))
                t = float(ev.get("target_share", base[2]))
                c = float(ev.get("carry_share", base[3]))
                u = float(ev.get("role_uncertainty", base[4]))
            if st in HARD_ROLE_STATUSES:
                s = r = t = c = 0.0
                out_names.append(name)
            elif st == "EXPECTED_REST":
                s *= 0.25; r *= 0.25; t *= 0.25; c *= 0.25; u = max(u, 0.50)
        if max(s, r, t, c) <= 0.0 and pos != "DST":
            zero_role.append(name)
        status.append(st)
        snap.append(np.clip(s, 0.0, 1.0)); routes.append(np.clip(r, 0.0, 1.0))
        targets.append(max(0.0, t)); carries.append(max(0.0, c)); role_unc.append(np.clip(u, 0.02, 0.85))
    df["ROLE_STATUS"] = status
    df["SNAPS"] = np.asarray(snap) * 100.0
    df["ROUTES"] = np.asarray(routes) * 100.0
    df["TARGETS"] = np.asarray(targets) * 20.0
    df["CARRIES"] = np.asarray(carries) * 25.0
    df["ROLE_UNCERTAINTY"] = role_unc
    df["ROLE_GATE_REASON"] = role_gate_reason

    # Market evidence may provide team-specific current/open totals. Pool market columns remain frozen inputs otherwise.
    teams_ev = market_evidence.get("teams", {}) if isinstance(market_evidence, dict) else {}
    if isinstance(teams_ev, dict) and teams_ev:
        tm_score = df.get("TM Score", pd.Series(np.full(len(df), 20.0), index=df.index)).astype(float).to_numpy()
        ou = df.get("O/U", pd.Series(np.full(len(df), 40.0), index=df.index)).astype(float).to_numpy()
        for i, t in enumerate(df["TEAM"].astype(str)):
            ev = teams_ev.get(t, {}) or {}
            if "implied_total" in ev: tm_score[i] = float(ev["implied_total"])
            if "game_total" in ev: ou[i] = float(ev["game_total"])
        df["TM Score"] = tm_score; df["O/U"] = ou
    df = _attach_pool_native_market_features(df)
    df["PROJECTION_MARKET_STATUS"] = "RAW_MODEL_PLUS_POOL_NATIVE_PLAYER_MARKET_PRIOR"
    return df, sorted(set(out_names)), sorted(set(zero_role))


def _phase1_player_parameters(df: pd.DataFrame, strategy: Any) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    pos = df["POS_BASE"].astype(str).to_numpy(object)
    snap = df["SNAPS"].to_numpy(float) / 100.0
    route = df["ROUTES"].to_numpy(float) / 100.0
    target = df["TARGETS"].to_numpy(float) / 20.0
    carry = df["CARRIES"].to_numpy(float) / 25.0
    proj = np.maximum(0.0, df["FPTS"].to_numpy(float))
    ceil = np.maximum(proj, df["Ceil"].to_numpy(float))
    team_total = df.get("TM Score", pd.Series(np.full(len(df), 20.0))).to_numpy(float)
    env = np.clip((team_total - 14.0) / 14.0, 0.0, 1.0)
    opp_score = np.asarray(strategy.opportunity_score, dtype=float)
    predictive = np.asarray(strategy.predictive_features.dfs_upside_score, dtype=float)
    market_opp = df.get("MARKET_OPPORTUNITY", pd.Series(np.zeros(len(df)))).to_numpy(float)
    market_conf = df.get("MARKET_ROLE_CONFIDENCE", pd.Series(np.zeros(len(df)))).to_numpy(float)
    td1 = df.get("MARKET_TD1_PROB", pd.Series(np.zeros(len(df)))).to_numpy(float)

    role_mu = np.zeros(len(df), dtype=np.float64)
    role_sigma_floor = np.zeros(len(df), dtype=np.float64)
    role_concentration = np.zeros(len(df), dtype=np.float64)
    for p, base, sig in [("QB", 19.0, 6.8), ("RB", 12.0, 6.8), ("WR", 11.5, 7.0), ("TE", 9.5, 5.8), ("DST", 7.0, 5.2)]:
        m = pos == p
        if p == "QB":
            cap = 0.86 * snap[m] + 0.14 * np.minimum(1.0, carry[m] * 2.5)
            conc = np.minimum(1.0, 0.82 * snap[m] + 0.18 * np.minimum(1.0, carry[m] * 3.0))
        elif p == "RB":
            cap = 0.40 * snap[m] + 0.45 * carry[m] + 0.15 * target[m]
            conc = np.minimum(1.0, 0.58 * carry[m] + 0.24 * target[m] + 0.18 * snap[m])
        elif p in {"WR", "TE"}:
            cap = 0.31 * snap[m] + 0.43 * route[m] + 0.26 * target[m]
            conc = np.minimum(1.0, 0.50 * target[m] + 0.32 * route[m] + 0.18 * snap[m])
        else:
            cap = np.ones(np.count_nonzero(m)); conc = np.ones(np.count_nonzero(m)) * .5
        # Market role only supplements current role; it never overrides an OUT/zero-role gate.
        mc = market_conf[m]
        cap = (1.0 - 0.28 * mc) * cap + (0.28 * mc) * market_opp[m]
        role_mu[m] = base * np.clip(cap, 0.0, 1.18)
        role_sigma_floor[m] = sig
        role_concentration[m] = conc

    # Current role owns the baseline, but a healthy player with a strong frozen projection/market
    # cannot be crushed into a noncompetitive mean solely because Week-1 historical role is sparse.
    role_blend = np.clip(0.58 + 0.10 * opp_score + 0.06 * predictive + 0.06 * env - 0.10 * market_conf, 0.52, 0.78)
    mu0 = role_blend * role_mu + (1.0 - role_blend) * proj
    market_floor = proj * (0.88 + 0.06 * market_conf)
    mu = np.maximum(mu0, market_floor)
    # Modest football-native TD prior; capped and only active when a player-level market exists.
    mu += np.minimum(1.5, 0.9 * td1 * market_conf)

    tail_prior = np.maximum(ceil, mu)
    role_unc = df["ROLE_UNCERTAINTY"].to_numpy(float)
    concentration_mult = 1.0 + 0.34 * np.clip(role_concentration - 0.45, 0.0, 0.55) + 0.12 * market_conf
    sigma = np.maximum.reduce((
        role_sigma_floor * (0.62 + role_unc) * concentration_mult,
        np.maximum(1.5, mu * (0.43 + 0.38 * role_unc)),
        (tail_prior - mu) / 1.05,
    ))
    zero_role = (snap <= 0.0) & (route <= 0.0) & (target <= 0.0) & (carry <= 0.0) & (pos != "DST")
    mu[zero_role] = 0.0
    sigma[zero_role] = 0.05
    return mu.astype(np.float32), sigma.astype(np.float32), role_mu.astype(np.float32)

def _simulate_players(cal_base: dict[str, Any], trials: int, seed: int) -> np.ndarray:
    mu = np.asarray(cal_base["mu"], dtype=np.float32)
    sigma = np.asarray(cal_base["sigma"], dtype=np.float32)
    pos = np.asarray(cal_base["pos"], dtype=object)
    team = np.asarray(cal_base["team"], dtype=object)
    opp = np.asarray(cal_base["opp"], dtype=object)
    game = np.asarray(cal_base["game"], dtype=object)
    n = len(mu)
    rng = np.random.default_rng(seed)
    games = list(dict.fromkeys(game.tolist()))
    teams = list(dict.fromkeys(team.tolist()))
    # Normalized Student-t factors create empirically appropriate football tail thickness while
    # preserving unit marginal variance. Correlation is imposed by shared football factors.
    def tfac(shape, df=7):
        return (rng.standard_t(df, size=shape) / math.sqrt(df / (df - 2.0))).astype(np.float32)
    game_z = {g: tfac(trials, 7) for g in games}
    team_off = {t: tfac(trials, 7) for t in teams}
    team_pass = {t: tfac(trials, 6) for t in teams}
    team_rush = {t: tfac(trials, 7) for t in teams}
    ind = tfac((n, trials), 7)
    out = np.empty((n, trials), dtype=np.float32)
    for i in range(n):
        t, o, g, p = team[i], opp[i], game[i], pos[i]
        opp_off = team_off.get(o, np.zeros(trials, dtype=np.float32))
        if p == "QB": coeff = (0.18, 0.22, 0.30, 0.0); latent = coeff[0]*game_z[g]+coeff[1]*team_off[t]+coeff[2]*team_pass[t]
        elif p in {"WR", "TE"}: coeff = (0.17, 0.18, 0.33, 0.0); latent = coeff[0]*game_z[g]+coeff[1]*team_off[t]+coeff[2]*team_pass[t]
        elif p == "RB": coeff = (0.15, 0.22, 0.30, 0.05); latent = coeff[0]*game_z[g]+coeff[1]*team_off[t]+coeff[2]*team_rush[t]+coeff[3]*team_pass[t]
        elif p == "DST": coeff = (-0.16, -0.31, 0.14, 0.0); latent = coeff[0]*game_z[g]+coeff[1]*opp_off+coeff[2]*team_rush[t]
        else: coeff = (0.12, 0.15, 0.0, 0.0); latent = coeff[0]*game_z[g]+coeff[1]*team_off[t]
        lv = float(sum(c*c for c in coeff))
        iw = math.sqrt(max(0.28, 1.0 - lv))
        z = np.float32(iw) * ind[i] + latent
        vals = mu[i] + sigma[i] * z
        out[i] = np.maximum(-4.0 if p == "DST" else 0.0, vals)
    return out

def _validate_classic_feasibility(df: pd.DataFrame) -> None:
    counts = df["POS_BASE"].value_counts().to_dict()
    req = {"QB": 1, "RB": 2, "WR": 3, "TE": 1, "DST": 1}
    missing = [p for p, n in req.items() if int(counts.get(p, 0)) < n]
    if missing:
        raise RuntimeError("RUN_INVALID:NFL_CLASSIC_POSITION_POOL_INFEASIBLE:" + ",".join(missing))
    skill = int(counts.get("RB", 0) + counts.get("WR", 0) + counts.get("TE", 0))
    if skill < 7 or df["TEAM"].nunique() < 2:
        raise RuntimeError("RUN_INVALID:NFL_CLASSIC_ACTIVE_POOL_INFEASIBLE")


def _load_calibration(pool: str | Path, role_evidence_path: str | Path, market_evidence_path: str | Path | None, cfg: Config, roster_gate: Any | None = None) -> Calibration:
    role_ev = _load_json(role_evidence_path)
    if roster_gate is not None:
        role_ev = _reconcile_role_evidence_with_availability(role_ev, roster_gate)
    market_ev = _load_json(market_evidence_path)
    df, out_names, zero_role = _prepare_frame(pool, role_ev, market_ev)
    active = ~df["ROLE_STATUS"].isin(["OUT", "IR", "DNP", "REST", "CONFIRMED_OUT", "DOUBTFUL", "ROLE_UNVERIFIED"])
    df = df.loc[active].reset_index(drop=True)
    _validate_classic_feasibility(df)
    if not np.all((df["SAL"].astype(int) > 0) & (df["SAL"].astype(int) <= SALARY_MAX)):
        raise RuntimeError("RUN_INVALID:NFL_CLASSIC_INVALID_SALARY")

    strategy = strategy_mod.build_strategy_features(df, sport=SPORT, mode=MODE)
    mu, sigma, _ = _phase1_player_parameters(df, strategy)
    ids = np.arange(len(df), dtype=np.int32)
    pos = df["POS_BASE"].astype(str).to_numpy(object)
    team = df["TEAM"].astype(str).to_numpy(object)
    opp = df["OPP"].astype(str).to_numpy(object)
    game = df["GAME_KEY"].astype(str).to_numpy(object)
    salary = df["SAL"].astype(int).to_numpy(np.int32)
    base = {"mu": mu, "sigma": sigma, "pos": pos, "team": team, "opp": opp, "game": game}
    sims = _simulate_players(base, cfg.player_trials, cfg.seed ^ 0xC1A551C)
    p95 = np.quantile(sims, 0.95, axis=1).astype(np.float32)
    p99 = np.quantile(sims, 0.99, axis=1).astype(np.float32)
    covariance = np.cov(sims.astype(np.float64)).astype(np.float32)
    std = np.sqrt(np.maximum(np.diag(covariance), 1e-8))
    correlation = covariance / np.maximum(np.outer(std, std), 1e-8)
    correlation = np.clip(correlation, -1.0, 1.0).astype(np.float32)
    own = np.maximum(0.0, df["RST%"].to_numpy(float)) / 100.0
    own = np.where(own > 0.0, own, 0.0025).astype(np.float32)
    role_hash = _stable_hash(role_ev); market_hash = _stable_hash(market_ev)
    phase1_payload = {
        "ids": ids.tolist(), "mu": np.round(mu, 6).tolist(), "sigma": np.round(sigma, 6).tolist(),
        "p95": np.round(p95, 6).tolist(), "p99": np.round(p99, 6).tolist(),
        "role_evidence_hash": role_hash, "market_evidence_hash": market_hash,
        "prediction_hash": strategy.receipt["PREDICTION_HASH"], "player_trials": cfg.player_trials,
        "multi_game_latent_model": "VARIANCE_PRESERVING_HEAVY_TAIL_GAME_TEAM_PASS_RUSH_DST_v2",
    }
    phase1_hash = _stable_hash(phase1_payload)
    shared = {
        "PLAYER_ID_ORDER_HASH": _array_hash(ids),
        "CORRELATION_MATRIX_HASH": _array_hash(correlation),
        "COVARIANCE_MATRIX_HASH": _array_hash(covariance),
        "OWNERSHIP_VECTOR_HASH": _array_hash(own),
        "CEILING_VECTOR_HASH": _array_hash(p99),
        "CEILING_DEFINITION_HASH": _stable_hash({"PERCENTILES": [95, 99], "METHOD": "PHASE1_MC", "TRIALS": cfg.player_trials}),
        "STACK_FEATURES_HASH": _stable_hash({"NFL_CLASSIC": "QB_PASS_CATCHER_BRINGBACK_DST_ANTI_CORRELATION_MULTI_GAME"}),
        "METRIC_SCALING_HASH": _stable_hash({"TOP01": "RATE", "WIN": "RATE", "P95": "RAW", "P99": "RAW"}),
        "ROLE_STATUS_STATE_HASH": _stable_hash(df[["PLAYER", "ROLE_STATUS", "SNAPS", "ROUTES", "TARGETS", "CARRIES"]].to_dict("records")),
        "BASE_SIM_TRIALS_HASH": _stable_hash(cfg.base_trials),
    }
    shared_id = _stable_hash(shared)
    return Calibration(
        frame=df, ids=ids, pos=pos, team=team, opp=opp, game=game, salary=salary,
        role_snap=df["SNAPS"].to_numpy(float) / 100.0, role_routes=df["ROUTES"].to_numpy(float) / 100.0,
        role_targets=df["TARGETS"].to_numpy(float) / 20.0, role_carries=df["CARRIES"].to_numpy(float) / 25.0,
        role_uncertainty=df["ROLE_UNCERTAINTY"].to_numpy(float), strategy=strategy,
        mu=mu, sigma=sigma, p95=p95, p99=p99, ownership=own, correlation=correlation, covariance=covariance,
        phase1_hash=phase1_hash, shared_metric_bundle_id=shared_id, prediction_hash=strategy.receipt["PREDICTION_HASH"],
        role_evidence_hash=role_hash, market_evidence_hash=market_hash, role_evidence_payload=role_ev,
        market_evidence_payload=market_ev, out_names=out_names, zero_role_names=zero_role,
        player_sim_matrix_hash=_array_hash(sims),
    )


def _salary_combo_counts(values: Iterable[int], kmax: int) -> list[dict[int, int]]:
    dp: list[dict[int, int]] = [{0: 1}] + [dict() for _ in range(kmax)]
    for raw in values:
        sal = int(raw)
        for k in range(kmax, 0, -1):
            prev = list(dp[k - 1].items())
            cur = dp[k]
            for s, c in prev:
                ns = s + sal
                if ns <= SALARY_MAX:
                    cur[ns] = cur.get(ns, 0) + c
    return dp


def _convolve_counts(parts: list[dict[int, int]]) -> int:
    total = {0: 1}
    for part in parts:
        nxt: dict[int, int] = {}
        for a, ca in total.items():
            for b, cb in part.items():
                s = a + b
                if s <= SALARY_MAX:
                    nxt[s] = nxt.get(s, 0) + ca * cb
        total = nxt
    return int(sum(c for s, c in total.items() if SALARY_MIN <= s <= SALARY_MAX))


def _legal_scan_count_for_frame(df: pd.DataFrame) -> int:
    groups = {p: df.loc[df["POS_BASE"] == p, "SAL"].astype(int).tolist() for p in ["QB", "RB", "WR", "TE", "DST"]}
    dps = {p: _salary_combo_counts(v, 4) for p, v in groups.items()}
    patterns = [(3, 3, 1), (2, 4, 1), (2, 3, 2)]
    total = 0
    for rb, wr, te in patterns:
        total += _convolve_counts([dps["QB"][1], dps["RB"][rb], dps["WR"][wr], dps["TE"][te], dps["DST"][1]])
    # Classic requires athletes from at least two teams. Subtract same-team lineups exactly.
    same_team = 0
    for _, sub in df.groupby("TEAM"):
        sg = {p: sub.loc[sub["POS_BASE"] == p, "SAL"].astype(int).tolist() for p in ["QB", "RB", "WR", "TE", "DST"]}
        sd = {p: _salary_combo_counts(v, 4) for p, v in sg.items()}
        for rb, wr, te in patterns:
            same_team += _convolve_counts([sd["QB"][1], sd["RB"][rb], sd["WR"][wr], sd["TE"][te], sd["DST"][1]])
    return int(max(0, total - same_team))


def _legal_scan_count(cal: Calibration) -> int:
    return _legal_scan_count_for_frame(cal.frame)


def _player_birth_score(cal: Calibration) -> np.ndarray:
    p99p = _pct(cal.p99); p95p = _pct(cal.p95)
    opp = np.asarray(cal.strategy.opportunity_score, dtype=float)
    lev = np.asarray(cal.strategy.strategic_leverage, dtype=float)
    role_cap = np.where(cal.pos == "QB", cal.role_snap,
                np.where(cal.pos == "RB", 0.45 * cal.role_snap + 0.40 * cal.role_carries + 0.15 * cal.role_targets,
                np.where(np.isin(cal.pos, ["WR", "TE"]), 0.35 * cal.role_snap + 0.40 * cal.role_routes + 0.25 * cal.role_targets, 1.0)))
    return (0.52 * p99p + 0.18 * p95p + 0.14 * opp + 0.08 * lev + 0.08 * role_cap).astype(np.float64)


def _top_position_pool(cal: Calibration, pos: str, score: np.ndarray, cap: int) -> np.ndarray:
    idx = np.flatnonzero(cal.pos == pos)
    if idx.size <= cap:
        return idx[np.argsort(score[idx], kind="stable")[::-1]]
    top = idx[np.argpartition(score[idx], -cap)[-cap:]]
    return top[np.argsort(score[top], kind="stable")[::-1]]


def _rank_team_pool(cal: Calibration, score: np.ndarray, team: str, positions: tuple[str, ...], keep: int) -> np.ndarray:
    idx = np.flatnonzero((cal.team == team) & np.isin(cal.pos, positions))
    if idx.size == 0: return np.asarray([], dtype=np.int32)
    order = idx[np.argsort(score[idx], kind="stable")[::-1]]
    return order[:keep].astype(np.int32)


FAMILY_CODES = {
    "QB_1PASS_BRING1": 1,
    "QB_2PASS_BRING1": 2,
    "QB_2PASS_NO_BRING": 3,
    "QB_PASS_RB_BRING1": 4,
    "QB_RB_DST_LEVERAGE": 5,
    "QB_1PASS_NO_BRING": 6,
    "QB_NAKED": 7,
    "QB_RB_GROUND_NO_BRING": 8,
    "QUALITY_PROJECTION_CLOSURE": 91,
    "QUALITY_TAIL_CLOSURE": 92,
    "QUALITY_MARKET_CLOSURE": 93,
    "QUALITY_WORLD_PERTURB": 94,
    "WORLD_NATIVE_OPTIMAL": 95,
    "WORLD_RECURRENT_CORE_CLOSURE": 96,
}


def _generate_seeds(cal: Calibration, score: np.ndarray, cfg: Config) -> list[tuple[int, tuple[int, ...]]]:
    seeds: list[tuple[int, tuple[int, ...]]] = []
    qbs = _top_position_pool(cal, "QB", score, max(64, int(np.count_nonzero(cal.pos == "QB"))))
    for qb in qbs:
        t, o = str(cal.team[qb]), str(cal.opp[qb])
        pc = _rank_team_pool(cal, score, t, ("WR", "TE"), cfg.seed_pass_catchers)
        rb = _rank_team_pool(cal, score, t, ("RB",), cfg.seed_rbs)
        bring = _rank_team_pool(cal, score, o, ("RB", "WR", "TE"), cfg.seed_bringbacks)
        dst = _rank_team_pool(cal, score, t, ("DST",), 1)
        seeds.append((FAMILY_CODES["QB_NAKED"], (int(qb),)))
        for p in pc:
            seeds.append((FAMILY_CODES["QB_1PASS_NO_BRING"], (int(qb), int(p))))
            for b in bring:
                seeds.append((FAMILY_CODES["QB_1PASS_BRING1"], (int(qb), int(p), int(b))))
        for a, b in itertools.combinations(pc.tolist(), 2):
            seeds.append((FAMILY_CODES["QB_2PASS_NO_BRING"], (int(qb), int(a), int(b))))
            for br in bring:
                seeds.append((FAMILY_CODES["QB_2PASS_BRING1"], (int(qb), int(a), int(b), int(br))))
        for p in pc:
            for r in rb:
                for br in bring:
                    seeds.append((FAMILY_CODES["QB_PASS_RB_BRING1"], (int(qb), int(p), int(r), int(br))))
        for r in rb:
            seeds.append((FAMILY_CODES["QB_RB_GROUND_NO_BRING"], (int(qb), int(r))))
        if dst.size:
            for r in rb:
                seeds.append((FAMILY_CODES["QB_RB_DST_LEVERAGE"], (int(qb), int(r), int(dst[0]))))
    # deterministic identity dedupe only
    seen = set(); out = []
    for fam, seed in seeds:
        key = (fam, tuple(sorted(seed)))
        if key in seen: continue
        seen.add(key); out.append((fam, seed))
    return out


def _pair_increment(candidate: int, selected: tuple[int, ...], cal: Calibration) -> float:
    if not selected:
        return 0.0
    p, t, o = str(cal.pos[candidate]), str(cal.team[candidate]), str(cal.opp[candidate])
    inc = 0.0
    # Positive correlation is already represented in simulated worlds. Construction should not
    # repeatedly pay a stack bonus and drive every lineup into one game. Keep only a tiny bounded
    # coherence term plus hard anti-correlation pressure.
    corrs = []
    for j in selected:
        pj, tj = str(cal.pos[j]), str(cal.team[j])
        corrs.append(float(np.clip(cal.correlation[candidate, j], -0.35, 0.55)))
        if p == "DST" and o == tj and pj in {"QB", "WR", "TE"}: inc -= 0.55
        if pj == "DST" and str(cal.opp[j]) == t and p in {"QB", "WR", "TE"}: inc -= 0.55
    if corrs:
        inc += 0.035 * float(np.mean(corrs))
    return inc

def _pattern_counts(code: int) -> dict[str, int]:
    if code == 0: return {"QB": 1, "RB": 3, "WR": 3, "TE": 1, "DST": 1}
    if code == 1: return {"QB": 1, "RB": 2, "WR": 4, "TE": 1, "DST": 1}
    return {"QB": 1, "RB": 2, "WR": 3, "TE": 2, "DST": 1}


def _canonical_row(selected: tuple[int, ...], pattern: int, cal: Calibration) -> np.ndarray:
    by = {p: sorted([int(i) for i in selected if cal.pos[int(i)] == p]) for p in ["QB", "RB", "WR", "TE", "DST"]}
    if pattern == 0:
        row = [by["QB"][0], by["RB"][0], by["RB"][1], by["WR"][0], by["WR"][1], by["WR"][2], by["TE"][0], by["RB"][2], by["DST"][0]]
    elif pattern == 1:
        row = [by["QB"][0], by["RB"][0], by["RB"][1], by["WR"][0], by["WR"][1], by["WR"][2], by["TE"][0], by["WR"][3], by["DST"][0]]
    else:
        row = [by["QB"][0], by["RB"][0], by["RB"][1], by["WR"][0], by["WR"][1], by["WR"][2], by["TE"][0], by["TE"][1], by["DST"][0]]
    return np.asarray(row, dtype=np.int32)


def _complete_seed(seed: tuple[int, ...], family: int, pattern: int, cal: Calibration, score: np.ndarray, pools: dict[str, np.ndarray], cfg: Config) -> list[np.ndarray]:
    target = _pattern_counts(pattern)
    counts = {p: sum(1 for i in seed if cal.pos[i] == p) for p in target}
    if any(counts[p] > target[p] for p in target): return []
    if len(set(seed)) != len(seed): return []
    states: list[tuple[tuple[int, ...], int, float]] = [(tuple(seed), int(cal.salary[list(seed)].sum()), float(score[list(seed)].sum()))]
    slots: list[str] = []
    for p in ["RB", "WR", "TE", "DST"]:
        slots.extend([p] * (target[p] - counts[p]))
    # QB always exists in every seed; if future seed policy changes, fill it first.
    slots = ["QB"] * (target["QB"] - counts["QB"]) + slots
    for p in slots:
        expanded: dict[tuple[int, ...], tuple[int, float]] = {}
        for chosen, sal, val in states:
            chosen_set = set(chosen)
            for c in pools[p]:
                ci = int(c)
                if ci in chosen_set: continue
                nsal = sal + int(cal.salary[ci])
                if nsal > SALARY_MAX: continue
                nchosen = tuple(sorted((*chosen, ci)))
                nval = val + float(score[ci]) + _pair_increment(ci, chosen, cal)
                prev = expanded.get(nchosen)
                if prev is None or nval > prev[1]: expanded[nchosen] = (nsal, nval)
        if not expanded: return []
        ranked = sorted(((k, v[0], v[1]) for k, v in expanded.items()), key=lambda x: (-x[2], x[0]))
        if len(ranked) <= cfg.fill_beam_width:
            states = ranked
        else:
            # Preserve salary geometry instead of one global score beam. This keeps multiple
            # complete-lineup doors alive until DST/late-position closure.
            by_bucket: dict[int, list[tuple[tuple[int, ...], int, float]]] = {}
            for item in ranked:
                bucket = int(item[1] // 500)
                by_bucket.setdefault(bucket, [])
                if len(by_bucket[bucket]) < max(2, cfg.fill_beam_width // 16):
                    by_bucket[bucket].append(item)
            protected = [x for b in sorted(by_bucket) for x in by_bucket[b]]
            seen = {x[0] for x in protected}
            for item in ranked:
                if len(protected) >= cfg.fill_beam_width: break
                if item[0] not in seen:
                    protected.append(item); seen.add(item[0])
            states = protected[:cfg.fill_beam_width]
    out = []
    for chosen, sal, _ in states:
        if len(chosen) != ROSTER_SIZE or not (SALARY_MIN <= sal <= SALARY_MAX): continue
        teams = {str(cal.team[i]) for i in chosen}
        if len(teams) < 2: continue
        out.append(_canonical_row(chosen, pattern, cal))
    return out


def _structural_lineup_features(rows: np.ndarray, cal: Calibration) -> dict[str, np.ndarray]:
    qbs = rows[:, 0]; dsts = rows[:, 8]
    teams = cal.team[rows]; pos = cal.pos[rows]; games = cal.game[rows]
    qb_team = cal.team[qbs]; qb_opp = cal.opp[qbs]
    same_pass = (((teams == qb_team[:, None]) & np.isin(pos, ["WR", "TE"]))).sum(axis=1).astype(np.int8)
    bring = (((teams == qb_opp[:, None]) & np.isin(pos, ["RB", "WR", "TE"]))).sum(axis=1).astype(np.int8)
    same_rb = (((teams == qb_team[:, None]) & (pos == "RB"))).sum(axis=1).astype(np.int8)
    dst_vs_qb = (cal.team[dsts] == qb_opp).astype(np.int8)
    dst_same_qb = (cal.team[dsts] == qb_team).astype(np.int8)
    team_count = np.asarray([len(set(x.tolist())) for x in teams], dtype=np.int8)
    game_count = np.asarray([len(set(x.tolist())) for x in games], dtype=np.int8)
    max_game_count = np.asarray([max(np.unique(x, return_counts=True)[1]) for x in games], dtype=np.int8)
    qb_game_count = np.asarray([(x == cal.game[q]).sum() for x, q in zip(games, qbs)], dtype=np.int8)
    family = (np.minimum(same_pass, 3).astype(np.int64) * 100000 + np.minimum(bring, 3).astype(np.int64) * 10000 + np.minimum(same_rb, 2).astype(np.int64) * 1000 + np.minimum(max_game_count, 9).astype(np.int64) * 10 + dst_vs_qb.astype(np.int64))
    macro = (np.minimum(same_pass, 3).astype(np.int32) * 1000 + np.minimum(bring, 3).astype(np.int32) * 100 + np.minimum(max_game_count,9).astype(np.int32))
    return {"same_pass": same_pass, "bringback": bring, "same_rb": same_rb, "dst_vs_qb": dst_vs_qb, "dst_same_qb": dst_same_qb, "team_count": team_count, "game_count": game_count, "max_game_count": max_game_count, "qb_game_count": qb_game_count, "family": family, "macro": macro}

def _lineup_calibration_score(rows: np.ndarray, cal: Calibration) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    f = _structural_lineup_features(rows, cal)
    base = cal.p99[rows].sum(axis=1).astype(np.float64)
    p95 = cal.p95[rows].sum(axis=1).astype(np.float64)
    raw_proj = cal.frame["FPTS"].to_numpy(float)[rows].sum(axis=1)
    market = cal.frame.get("MARKET_OPPORTUNITY", pd.Series(np.zeros(len(cal.frame)))).to_numpy(float)[rows].sum(axis=1)
    opportunity = np.asarray(cal.strategy.opportunity_score, dtype=float)
    leverage = np.asarray(cal.strategy.strategic_leverage, dtype=float)
    role = opportunity[rows].sum(axis=1); lev = leverage[rows].sum(axis=1)
    # Structural stacks are candidate families, not repeated score bonuses. Mild reward only.
    synergy = 0.45 * np.minimum(f["same_pass"], 2) + 0.20 * np.minimum(f["bringback"], 1) + 0.10 * np.minimum(f["same_rb"], 1) + 0.12 * f["dst_same_qb"] - 3.4 * f["dst_vs_qb"]
    # Mean pair correlation avoids the former O(n^2) cumulative reward for stuffing one game.
    corr_sum = np.zeros(len(rows), dtype=np.float64); pairs = 0
    for k in range(rows.shape[1]):
        for j in range(k + 1, rows.shape[1]):
            corr_sum += np.clip(cal.correlation[rows[:, k], rows[:, j]], -0.35, 0.55); pairs += 1
    mean_corr = corr_sum / max(1, pairs)
    mg = f["max_game_count"].astype(float)
    concentration_penalty = 2.0 * np.maximum(0.0, mg - 5.0) ** 1.65
    # Prefer distributed but coherent lineups; do not ban legitimate 5-player shootouts.
    distribution_bonus = 0.30 * np.clip(f["game_count"].astype(float) - 2.0, 0.0, 4.0)
    score = 0.72 * base + 0.22 * p95 + 0.58 * raw_proj + 0.65 * role + 0.20 * market + 0.15 * lev + synergy + 0.65 * mean_corr + distribution_bonus - concentration_penalty
    f["raw_projection"] = raw_proj.astype(np.float32)
    f["market_quality"] = market.astype(np.float32)
    f["mean_pair_corr"] = mean_corr.astype(np.float32)
    f["concentration_penalty"] = concentration_penalty.astype(np.float32)
    return score, f

def _multi_authority_position_pool(cal: Calibration, pos: str, birth: np.ndarray, cap: int) -> np.ndarray:
    idx = np.flatnonzero(cal.pos == pos)
    if not len(idx): return idx.astype(np.int32)
    raw = cal.frame["FPTS"].to_numpy(float)
    market = cal.frame.get("MARKET_OPPORTUNITY", pd.Series(np.zeros(len(cal.frame)))).to_numpy(float)
    authorities = [birth, raw, cal.p99, market]
    chosen: set[int] = set()
    each = max(8, int(math.ceil(cap / 2)))
    for a in authorities:
        order = idx[np.argsort(np.asarray(a)[idx], kind="stable")[::-1]]
        chosen.update(int(x) for x in order[:each])
    # Team-local closure under multiple independent authorities.
    for t in np.unique(cal.team[idx]):
        tidx = idx[cal.team[idx] == t]
        for a in authorities:
            order = tidx[np.argsort(np.asarray(a)[tidx], kind="stable")[::-1]]
            chosen.update(int(x) for x in order[:4])
    arr = np.asarray(sorted(chosen), dtype=np.int32)
    # keep bounded but never below requested cap; sort by best authority rank proxy.
    combo = .35*_pct(birth[arr]) + .25*_pct(raw[arr]) + .25*_pct(cal.p99[arr]) + .15*_pct(market[arr])
    order = arr[np.argsort(combo, kind="stable")[::-1]]
    hard_cap = max(cap, int(math.ceil(cap * 1.6)))
    return order[:hard_cap].astype(np.int32)




_NFL_CLASSIC_CALIBRATED_NO_BRING_FAMILIES = frozenset({
    FAMILY_CODES["QB_1PASS_NO_BRING"],
    FAMILY_CODES["QB_NAKED"],
    FAMILY_CODES["QB_RB_GROUND_NO_BRING"],
})


def _build_calibration_qualified_seed_family_plan(cal: Calibration, cfg: Config) -> dict[str, Any]:
    """Qualify the orphaned no-bring family seeds from Phase-1 player/role calibration.

    This is a bounded calibrated-family closure, not a raw legal-lineup lattice.  The
    family seeds are scored only with prelock Phase-1 tail/role/opportunity channels,
    qualified across several fixed calibration views, and completed from bounded
    Phase-1-ranked position pools.
    """
    score = _player_birth_score(cal)
    pools = {
        "QB": _top_position_pool(cal, "QB", score, max(24, min(40, int(np.count_nonzero(cal.pos == "QB"))))),
        "RB": _top_position_pool(cal, "RB", score, int(cfg.fill_pool_rb)),
        "WR": _top_position_pool(cal, "WR", score, int(cfg.fill_pool_wr)),
        "TE": _top_position_pool(cal, "TE", score, int(cfg.fill_pool_te)),
        "DST": _top_position_pool(cal, "DST", score, int(cfg.fill_pool_dst)),
    }
    # Preserve team-local role paths without opening an unbounded raw lattice.
    for pos in ["RB", "WR", "TE", "DST"]:
        extra: list[int] = []
        for team in np.unique(cal.team):
            extra.extend(_rank_team_pool(cal, score, str(team), (pos,), 3 if pos != "DST" else 1).tolist())
        if extra:
            pools[pos] = np.unique(np.concatenate([pools[pos], np.asarray(extra, dtype=np.int32)])).astype(np.int32)
            pools[pos] = pools[pos][np.argsort(score[pools[pos]], kind="stable")[::-1]]

    # Same QB admission discipline already used by the production CFB Classic
    # calibration-first adapter: strongest Phase-1 QB per team plus genuinely active
    # rotation QBs.  Backup-only raw-pool QBs do not qualify merely by existing.
    qualified_qbs: set[int] = set()
    for team in np.unique(cal.team):
        q = np.flatnonzero((cal.team == team) & (cal.pos == "QB"))
        if len(q):
            qualified_qbs.add(int(q[np.argmax(score[q])]))
    for q in np.flatnonzero((cal.pos == "QB") & (cal.role_snap >= 0.75)):
        qualified_qbs.add(int(q))

    raw_seeds = [
        (int(fam), tuple(int(x) for x in seed))
        for fam, seed in _generate_seeds(cal, score, cfg)
        if int(fam) in _NFL_CLASSIC_CALIBRATED_NO_BRING_FAMILIES
    ]
    role_qualified: list[tuple[int, tuple[int, ...]]] = []
    for fam, seed in raw_seeds:
        qbs = [int(x) for x in seed if str(cal.pos[int(x)]) == "QB"]
        if qbs and all(q in qualified_qbs for q in qbs):
            role_qualified.append((fam, seed))
    if not role_qualified:
        return {
            "score": score,
            "pools": pools,
            "seeds": [],
            "receipt": {
                "PATCH_ID": "NFL_CLASSIC_CALIBRATED_SEED_FAMILY_REACHABILITY_v1",
                "GLOBAL_FAST_PATH_CALIBRATION_BIRTH_GATE_ID": "APEX_GLOBAL_FAST_PATH_CALIBRATION_QUALIFIED_BIRTH_HARD_GATE_v1",
                "CALIBRATION_QUALIFIED_BIRTH_PLAN": True,
                "RAW_SEEDS_VISIBILITY_ONLY": int(len(raw_seeds)),
                "ROLE_QUALIFIED_SEEDS": 0,
                "CALIBRATION_QUALIFIED_SEEDS": 0,
                "QUALIFIED_QBS": int(len(qualified_qbs)),
                "UNQUALIFIED_CANDIDATE_BIRTHS": 0,
                "FULL_LEGAL_UNIVERSE_ENUMERATED": False,
                "PRE_PHASE2_RAW_LATTICE_MATERIALIZED": False,
                "FAMILY_RECEIPT": {},
            },
        }

    opportunity = np.asarray(cal.strategy.opportunity_score, dtype=np.float64)
    leverage = np.asarray(cal.strategy.strategic_leverage, dtype=np.float64)
    feats = np.empty((len(role_qualified), 6), dtype=np.float64)
    for i, (_, seed) in enumerate(role_qualified):
        ids = np.asarray(seed, dtype=np.int32)
        corr = 0.0
        for a in range(len(ids)):
            for b in range(a + 1, len(ids)):
                corr += float(np.clip(cal.correlation[int(ids[a]), int(ids[b])], -0.35, 0.55))
        feats[i] = (
            float(cal.p99[ids].sum()),
            float(cal.p95[ids].sum()),
            float(opportunity[ids].sum()),
            float(leverage[ids].sum()),
            float(score[ids].sum()),
            corr,
        )
    pct_feats = np.column_stack([_pct(feats[:, j]) for j in range(feats.shape[1])])
    # Fixed predeclared calibration views.  These are copied from the production
    # CFB calibration-qualified birth-plan mechanism; no slate-truth fitting occurs.
    weights = np.asarray([
        [.34, .18, .16, .08, .18, .06],
        [.26, .24, .18, .08, .18, .06],
        [.30, .16, .20, .12, .16, .06],
        [.24, .18, .16, .16, .20, .06],
        [.28, .18, .14, .10, .18, .12],
    ], dtype=np.float64)
    world_scores = pct_feats @ weights.T

    family_groups: dict[int, list[int]] = {}
    qb_family_groups: dict[tuple[int, int], list[int]] = {}
    for i, (fam, seed) in enumerate(role_qualified):
        family_groups.setdefault(int(fam), []).append(i)
        for q in seed:
            if str(cal.pos[int(q)]) == "QB":
                qb_family_groups.setdefault((int(fam), int(q)), []).append(i)

    admitted: set[int] = set()
    family_receipt: dict[str, Any] = {}
    for fam, idxs in sorted(family_groups.items()):
        n = len(idxs)
        depth = min(n, max(8, int(math.ceil(math.sqrt(max(1, n)) * math.log(max(2, n)) * 0.65))))
        idxa = np.asarray(idxs, dtype=np.int32)
        ranks = np.empty((n, len(weights)), dtype=np.int32)
        for wi in range(len(weights)):
            order = np.argsort(world_scores[idxa, wi], kind="stable")[::-1]
            rr = np.empty(n, dtype=np.int32)
            rr[order] = np.arange(1, n + 1)
            ranks[:, wi] = rr
        recurrence = (ranks <= depth).sum(axis=1)
        avg_rank = ranks.mean(axis=1)
        peak = world_scores[idxa].max(axis=1)
        order = sorted(range(n), key=lambda j: (-int(recurrence[j]), float(avg_rank[j]), -float(peak[j]), int(idxa[j])))
        chosen = [idxs[j] for j in order if int(recurrence[j]) >= 2]
        if len(chosen) < depth:
            chosen = [idxs[j] for j in order[:depth]]
        admitted.update(chosen)
        family_receipt[str(fam)] = {
            "RAW_SEEDS": int(n),
            "WORLD_DEPTH": int(depth),
            "QUALIFIED_SEEDS": int(len(chosen)),
        }

    # Preserve at least the strongest two calibrated routes per QB/family so a deep
    # global family cannot erase a qualified structural path before completion.
    for _, idxs in sorted(qb_family_groups.items()):
        idxa = np.asarray(idxs, dtype=np.int32)
        agg = world_scores[idxa].mean(axis=1)
        k = min(len(idxs), 2)
        admitted.update(idxa[np.argsort(agg, kind="stable")[::-1][:k]].tolist())

    selected = [role_qualified[i] for i in sorted(admitted)]
    receipt = {
        "PATCH_ID": "NFL_CLASSIC_CALIBRATED_SEED_FAMILY_REACHABILITY_v1",
        "GLOBAL_FAST_PATH_CALIBRATION_BIRTH_GATE_ID": "APEX_GLOBAL_FAST_PATH_CALIBRATION_QUALIFIED_BIRTH_HARD_GATE_v1",
        "PHASE1_MC_BEFORE_CANDIDATE_BIRTH": True,
        "CALIBRATION_QUALIFIED_BIRTH_PLAN": True,
        "TARGET_FAMILIES": sorted(int(x) for x in _NFL_CLASSIC_CALIBRATED_NO_BRING_FAMILIES),
        "RAW_SEEDS_VISIBILITY_ONLY": int(len(raw_seeds)),
        "ROLE_QUALIFIED_SEEDS": int(len(role_qualified)),
        "CALIBRATION_QUALIFIED_SEEDS": int(len(selected)),
        "QUALIFIED_QBS": int(len(qualified_qbs)),
        "UNQUALIFIED_CANDIDATE_BIRTHS": 0,
        "FULL_LEGAL_UNIVERSE_ENUMERATED": False,
        "PRE_PHASE2_RAW_LATTICE_MATERIALIZED": False,
        "WORLD_BLOCKS": int(len(weights)),
        "FAMILY_RECEIPT": family_receipt,
    }
    return {"score": score, "pools": pools, "seeds": selected, "receipt": receipt}


def _calibrated_seed_family_closure(cal: Calibration, cfg: Config) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Complete only Phase-1-qualified no-bring family seeds into legal siblings."""
    plan = _build_calibration_qualified_seed_family_plan(cal, cfg)
    score = np.asarray(plan["score"], dtype=np.float64)
    pools = {k: np.asarray(v, dtype=np.int32) for k, v in dict(plan["pools"]).items()}
    seeds = list(plan["seeds"])
    rows: list[np.ndarray] = []
    codes: list[int] = []
    generated_by_family: dict[str, int] = {}
    structural_kept_by_family: dict[str, int] = {}
    for fam, seed in seeds:
        generated = 0
        kept = 0
        for pattern in range(3):
            for row in _complete_seed(seed, int(fam), pattern, cal, score, pools, cfg):
                generated += 1
                feat = _structural_lineup_features(np.asarray(row, dtype=np.int32)[None, :], cal)
                same_pass = int(feat["same_pass"][0])
                bring = int(feat["bringback"][0])
                same_rb = int(feat["same_rb"][0])
                if int(fam) == FAMILY_CODES["QB_1PASS_NO_BRING"]:
                    ok = same_pass >= 1 and bring == 0
                elif int(fam) == FAMILY_CODES["QB_NAKED"]:
                    ok = same_pass == 0 and bring == 0
                elif int(fam) == FAMILY_CODES["QB_RB_GROUND_NO_BRING"]:
                    ok = same_rb >= 1 and bring == 0
                else:
                    ok = False
                if not ok:
                    continue
                rows.append(np.asarray(row, dtype=np.int32))
                codes.append(int(fam))
                kept += 1
        key = str(int(fam))
        generated_by_family[key] = generated_by_family.get(key, 0) + int(generated)
        structural_kept_by_family[key] = structural_kept_by_family.get(key, 0) + int(kept)

    receipt = dict(plan["receipt"])
    receipt["CALIBRATED_FAMILY_CLOSURE_GENERATED_BY_FAMILY"] = generated_by_family
    receipt["CALIBRATED_FAMILY_CLOSURE_STRUCTURAL_KEPT_BY_FAMILY"] = structural_kept_by_family
    if not rows:
        receipt["CALIBRATED_FAMILY_CLOSURE_ADDITIONS"] = 0
        return np.empty((0, ROSTER_SIZE), dtype=np.int32), np.empty(0, dtype=np.int16), receipt
    arr = np.vstack(rows).astype(np.int32)
    code_arr = np.asarray(codes, dtype=np.int16)
    _, first = np.unique(arr, axis=0, return_index=True)
    first = np.sort(first)
    arr = arr[first]
    code_arr = code_arr[first]
    receipt["CALIBRATED_FAMILY_CLOSURE_ADDITIONS"] = int(len(arr))
    return arr, code_arr, receipt


def _top_component_buckets(indices: np.ndarray, k: int, cal: Calibration, objective: np.ndarray, keep: int) -> dict[int, list[tuple[float, tuple[int, ...]]]]:
    buckets: dict[int, list[tuple[float, tuple[int, ...]]]] = {}
    if k == 0: return {0: [(0.0, tuple())]}
    if len(indices) < k: return {}
    for comb in itertools.combinations([int(x) for x in indices.tolist()], k):
        sal = int(cal.salary[list(comb)].sum())
        if sal >= SALARY_MAX: continue
        sc = float(np.asarray(objective)[list(comb)].sum())
        lst = buckets.setdefault(sal, [])
        lst.append((sc, comb))
    for sal, lst in list(buckets.items()):
        lst.sort(key=lambda x: (-x[0], x[1]))
        buckets[sal] = lst[:keep]
    return buckets


def _kbest_pair(a: list[tuple[float, tuple[int, ...]]], b: list[tuple[float, tuple[int, ...]]], keep: int) -> list[tuple[float, tuple[int, ...]]]:
    # Lists are already sorted. Small K makes a bounded cross product faster and deterministic.
    cand = []
    for sa, ia in a[:keep]:
        for sb, ib in b[:keep]:
            cand.append((sa + sb, ia + ib))
    cand.sort(key=lambda x: (-x[0], x[1]))
    out=[]; seen=set()
    for x in cand:
        ids=tuple(sorted(x[1]))
        if ids in seen: continue
        seen.add(ids); out.append(x)
        if len(out) >= keep: break
    return out


def _merge_component_states(states: dict[tuple[int, int], list[tuple[float, tuple[int, ...]]]], comp: dict[int, list[tuple[float, tuple[int, ...]]]], keep: int) -> dict[tuple[int, int], list[tuple[float, tuple[int, ...]]]]:
    out: dict[tuple[int, int], list[tuple[float, tuple[int, ...]]]] = {}
    for (qb, sal0), a in states.items():
        for sal1, b in comp.items():
            ns = sal0 + sal1
            if ns > SALARY_MAX: continue
            key=(qb,ns)
            merged=_kbest_pair(a,b,keep)
            if not merged: continue
            if key in out: out[key]=_kbest_pair(out[key], merged, keep)
            else: out[key]=merged
    return out


def _closure_position_pool(cal: Calibration, pos: str, birth: np.ndarray, cap: int) -> np.ndarray:
    idx=np.flatnonzero(cal.pos==pos)
    if len(idx)<=cap: return idx.astype(np.int32)
    raw=cal.frame["FPTS"].to_numpy(float); market=cal.frame.get("MARKET_OPPORTUNITY",pd.Series(np.zeros(len(cal.frame)))).to_numpy(float)
    combo=.30*_pct(birth[idx])+.28*_pct(raw[idx])+.28*_pct(cal.p99[idx])+.14*_pct(market[idx])
    # team-local starter doors are represented in the scoring authorities and then bounded here.
    return idx[np.argsort(combo,kind="stable")[::-1][:cap]].astype(np.int32)


def _merge_salary_buckets(a: dict[int,list[tuple[float,tuple[int,...]]]], b: dict[int,list[tuple[float,tuple[int,...]]]], keep: int, max_salary: int=SALARY_MAX) -> dict[int,list[tuple[float,tuple[int,...]]]]:
    out: dict[int,list[tuple[float,tuple[int,...]]]]={}
    for sa,la in a.items():
        for sb,lb in b.items():
            ns=sa+sb
            if ns>max_salary: continue
            vals=[]
            for xa,ia in la[:keep]:
                for xb,ib in lb[:keep]: vals.append((xa+xb,ia+ib))
            if not vals: continue
            if ns in out: vals.extend(out[ns])
            vals.sort(key=lambda x:(-x[0],x[1])); seen=set(); z=[]
            for v,ids in vals:
                key=tuple(sorted(ids))
                if key in seen: continue
                seen.add(key); z.append((v,ids))
                if len(z)>=keep: break
            out[ns]=z
    return out


def _quality_closure(cal: Calibration, cfg: Config, birth: np.ndarray, objective: np.ndarray, family_code: int) -> list[np.ndarray]:
    """Fast deterministic complete-roster safety closure by exact salary."""
    qbs=_closure_position_pool(cal,"QB",birth,max(24,min(40,int(np.count_nonzero(cal.pos=="QB")))))
    rb=_closure_position_pool(cal,"RB",birth,min(int(cfg.closure_pool_rb),42))
    wr=_closure_position_pool(cal,"WR",birth,min(int(cfg.closure_pool_wr),52))
    te=_closure_position_pool(cal,"TE",birth,min(int(cfg.closure_pool_te),40))
    dst=_closure_position_pool(cal,"DST",birth,min(16,int(np.count_nonzero(cal.pos=="DST"))))
    keep=max(4,min(24,int(cfg.closure_per_salary_keep)))
    obj=np.asarray(objective,dtype=float)
    qd: dict[tuple[int,int],list[tuple[float,tuple[int,...]]]]={}
    for q in qbs:
        for d in dst:
            sal=int(cal.salary[int(q)]+cal.salary[int(d)])
            qd.setdefault((int(q),sal),[]).append((float(obj[int(q)]+obj[int(d)]),(int(q),int(d))))
    for k,v in qd.items(): v.sort(key=lambda x:(-x[0],x[1])); qd[k]=v[:keep]
    rows=[]
    for pat in range(3):
        cnt=_pattern_counts(pat)
        rb_b=_top_component_buckets(rb,cnt["RB"],cal,obj,keep)
        wr_b=_top_component_buckets(wr,cnt["WR"],cal,obj,keep)
        te_b=_top_component_buckets(te,cnt["TE"],cal,obj,keep)
        rt=_merge_salary_buckets(rb_b,te_b,keep,max_salary=43000)
        base: dict[tuple[int,int],list[tuple[float,tuple[int,...]]]]={}
        for (q,qs),lq in qd.items():
            for rs,lr in rt.items():
                ns=qs+rs
                if ns>=SALARY_MAX: continue
                vals=[]
                for a,ia in lq:
                    for b,ib in lr: vals.append((a+b,ia+ib))
                key=(q,ns)
                if key in base: vals.extend(base[key])
                vals.sort(key=lambda x:(-x[0],x[1])); base[key]=vals[:keep]
        for (q,bs),lb in base.items():
            for final_sal in range(SALARY_MIN,SALARY_MAX+1,100):
                ws=final_sal-bs; lw=wr_b.get(ws)
                if not lw: continue
                vals=[]
                for a,ia in lb:
                    for b,ib in lw: vals.append((a+b,ia+ib))
                vals.sort(key=lambda x:(-x[0],x[1]))
                for _,ids in vals[:keep]:
                    if len(ids)!=ROSTER_SIZE or len(set(ids))!=ROSTER_SIZE: continue
                    if len(set(str(cal.team[i]) for i in ids))<2: continue
                    rows.append(_canonical_row(tuple(ids),pat,cal))
    if not rows: return []
    arr=np.vstack(rows).astype(np.int32); _,first=np.unique(arr,axis=0,return_index=True); arr=arr[np.sort(first)]
    vals=obj[arr].sum(axis=1); order=np.argsort(vals,kind="stable")[::-1]
    return [arr[i] for i in order[:min(int(cfg.closure_final_keep),len(order))]]


def _generate_candidates(cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    """World-native + quality perturb candidate birth. No fixed-width partial-roster beam authority."""
    worlds = 120 if cfg.test_mode else 10_000
    quality_rows, quality_receipt = world_birth.discover_quality_rows(cal, cfg.seed, worlds=(120 if cfg.test_mode else 2_500))
    world_rows, world_receipt = world_birth.discover_world_rows(cal, _simulate_players, _pct, cfg.seed, worlds=worlds)
    closure_rows, closure_receipt = world_birth.recurrent_core_closure(
        world_rows, cal, _pct, _pattern_counts, _canonical_row,
        max_cores=(20 if cfg.test_mode else 140), min_frequency=(2 if cfg.test_mode else 4),
    )
    seed_family_rows, seed_family_source, seed_family_receipt = _calibrated_seed_family_closure(cal, cfg)

    # Independent complete-roster safety doors. These closures existed in the runtime
    # but were previously unreachable from candidate generation. Keep them independent
    # from the world-native lanes so projection, tail, and market authorities each have
    # a deterministic legal-roster path into the born surface.
    birth = _player_birth_score(cal)
    raw_projection = cal.frame["FPTS"].to_numpy(float)
    market_opportunity = cal.frame.get(
        "MARKET_OPPORTUNITY", pd.Series(np.zeros(len(cal.frame)))
    ).to_numpy(float)
    projection_closure_rows_raw = _quality_closure(
        cal, cfg, birth, raw_projection, FAMILY_CODES["QUALITY_PROJECTION_CLOSURE"]
    )
    tail_closure_rows_raw = _quality_closure(
        cal, cfg, birth, cal.p99, FAMILY_CODES["QUALITY_TAIL_CLOSURE"]
    )
    market_closure_rows_raw = _quality_closure(
        cal, cfg, birth, market_opportunity, FAMILY_CODES["QUALITY_MARKET_CLOSURE"]
    )

    # Hard contract: quality closures may preserve/tag identities already born by
    # calibration-qualified world lanes, but they may never create an independent
    # unqualified Phase-2 identity. This keeps the quality doors reachable without
    # bypassing GLOBAL_FAST_PATH_CALIBRATION_QUALIFIED_BIRTH_HARD_GATE.
    qualified_parts = [np.asarray(x, dtype=np.int32) for x in (quality_rows, world_rows, closure_rows) if x is not None and len(x)]
    qualified_surface = np.vstack(qualified_parts).astype(np.int32) if qualified_parts else np.empty((0, ROSTER_SIZE), dtype=np.int32)
    qualified_keys = {tuple(map(int, r.tolist())) for r in qualified_surface}

    def _qualified_only(rows_in: list[np.ndarray]) -> list[np.ndarray]:
        return [np.asarray(r, dtype=np.int32) for r in rows_in if tuple(map(int, np.asarray(r).tolist())) in qualified_keys]

    projection_closure_rows = _qualified_only(projection_closure_rows_raw)
    tail_closure_rows = _qualified_only(tail_closure_rows_raw)
    market_closure_rows = _qualified_only(market_closure_rows_raw)

    parts=[]; codes=[]
    if seed_family_rows is not None and len(seed_family_rows):
        parts.append(np.asarray(seed_family_rows, dtype=np.int32))
        codes.append(np.asarray(seed_family_source, dtype=np.int16))
    for arr, code in [
        (projection_closure_rows, FAMILY_CODES["QUALITY_PROJECTION_CLOSURE"]),
        (tail_closure_rows, FAMILY_CODES["QUALITY_TAIL_CLOSURE"]),
        (market_closure_rows, FAMILY_CODES["QUALITY_MARKET_CLOSURE"]),
        (quality_rows, FAMILY_CODES["QUALITY_WORLD_PERTURB"]),
        (world_rows, FAMILY_CODES["WORLD_NATIVE_OPTIMAL"]),
        (closure_rows, FAMILY_CODES["WORLD_RECURRENT_CORE_CLOSURE"]),
    ]:
        if arr is not None and len(arr):
            parts.append(np.asarray(arr,dtype=np.int32)); codes.append(np.full(len(arr),code,dtype=np.int16))
    if not parts:
        raise RuntimeError("RUN_INVALID:NFL_CLASSIC_ZERO_WORLD_NATIVE_CANDIDATES")
    rows=np.vstack(parts).astype(np.int32); source=np.concatenate(codes)
    _,first=np.unique(rows,axis=0,return_index=True); first=np.sort(first); rows=rows[first]; source=source[first]
    salary=cal.salary[rows].sum(axis=1); keep=(salary>=SALARY_MIN)&(salary<=SALARY_MAX)
    rows=rows[keep]; source=source[keep]; salary=salary[keep]
    if not len(rows): raise RuntimeError("RUN_INVALID:NFL_CLASSIC_ZERO_SALARY_LEGAL_CANDIDATES")
    line_score,feat=_lineup_calibration_score(rows,cal)
    feat.update(world_birth.candidate_recurrence_features(rows, world_rows, cal))
    feat["world_native_receipt"]={
        **quality_receipt,
        **world_receipt,
        **closure_receipt,
        "QUALITY_PROJECTION_CLOSURE_GENERATED": int(len(projection_closure_rows_raw)),
        "QUALITY_PROJECTION_CLOSURE_ROWS": int(len(projection_closure_rows)),
        "QUALITY_PROJECTION_CLOSURE_REJECTED_UNQUALIFIED": int(len(projection_closure_rows_raw)-len(projection_closure_rows)),
        "QUALITY_TAIL_CLOSURE_GENERATED": int(len(tail_closure_rows_raw)),
        "QUALITY_TAIL_CLOSURE_ROWS": int(len(tail_closure_rows)),
        "QUALITY_TAIL_CLOSURE_REJECTED_UNQUALIFIED": int(len(tail_closure_rows_raw)-len(tail_closure_rows)),
        "QUALITY_MARKET_CLOSURE_GENERATED": int(len(market_closure_rows_raw)),
        "QUALITY_MARKET_CLOSURE_ROWS": int(len(market_closure_rows)),
        "QUALITY_MARKET_CLOSURE_REJECTED_UNQUALIFIED": int(len(market_closure_rows_raw)-len(market_closure_rows)),
        "QUALITY_CLOSURE_BIRTH_AUTHORITY": "QUALIFICATION_PRESERVING_ONLY",
        "CALIBRATED_SEED_FAMILY_CLOSURE": seed_family_receipt,
        "CALIBRATED_SEED_FAMILY_CLOSURE_ADDITIONS": int(len(seed_family_rows)),
        "CALIBRATED_SEED_FAMILY_UNQUALIFIED_BIRTHS": int(seed_family_receipt.get("UNQUALIFIED_CANDIDATE_BIRTHS", 0)),
    }
    return rows,{"score":line_score,"seed_family":source,"salary":salary.astype(np.int32),**feat}


def _select_top_by_group(group: np.ndarray, score: np.ndarray, per_group: int) -> np.ndarray:
    chosen: list[np.ndarray] = []
    for g in np.unique(group):
        idx = np.flatnonzero(group == g)
        if idx.size <= per_group: chosen.append(idx)
        else:
            local = np.argpartition(score[idx], -per_group)[-per_group:]
            chosen.append(idx[local])
    return np.unique(np.concatenate(chosen)) if chosen else np.asarray([], dtype=np.int32)


def _phase2(candidate_rows: np.ndarray, cmeta: dict[str, Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, np.ndarray], dict[str, int]]:
    """Full-surface Phase 2: every born legal lineup reaches simulation review."""
    if not len(candidate_rows):
        return candidate_rows, {}, {"CALIBRATION_CANDIDATE_LINEUPS":0,"PHASE2_BUILT_LINEUPS":0}
    score=np.asarray(cmeta["score"],dtype=float)
    order=np.argsort(score,kind="stable")[::-1]
    rows=np.asarray(candidate_rows,dtype=np.int32)[order]
    keys=["score","seed_family","salary","same_pass","bringback","same_rb","dst_vs_qb","dst_same_qb","team_count","game_count","max_game_count","qb_game_count","family","macro","raw_projection","market_quality","mean_pair_corr","concentration_penalty","player_rec_sum","player_rec_min","player_rec_max","core_rec_max","core_rec_sum"]
    pmeta={k:np.asarray(cmeta[k])[order] for k in keys}; pmeta["phase2_index"]=np.arange(len(rows),dtype=np.int32)
    receipt={
        "CALIBRATION_CANDIDATE_LINEUPS":int(len(candidate_rows)),
        "PHASE2_STREAM_MODE":"FULL_BORN_SURFACE_1_TO_1",
        "PHASE2_PRE_MC_TOPK_CULL":0,
        "PHASE2_BUILT_LINEUPS":int(len(rows)),
    }
    return rows,pmeta,receipt



def _score_rows(rows: np.ndarray, sims: np.ndarray) -> np.ndarray:
    return sims[rows].sum(axis=1)


def _public_field_indices(rows: np.ndarray, cal: Calibration, field_size: int, seed: int) -> np.ndarray:
    own = np.clip(cal.ownership, 0.0005, 0.98)
    logw = np.log(own[rows]).sum(axis=1)
    role = np.asarray(cal.strategy.opportunity_score, dtype=float)
    logw += 0.18 * role[rows].sum(axis=1)
    feat = _structural_lineup_features(rows, cal)
    logw += 0.035 * np.minimum(feat["same_pass"], 2) + 0.015 * np.minimum(feat["bringback"], 1)
    logw -= 0.08 * np.maximum(0, feat["max_game_count"].astype(float) - 5.0)
    logw -= np.max(logw)
    w = np.exp(np.clip(logw, -40, 0)); w = w / w.sum()
    rng = np.random.default_rng(seed ^ 0xF13DCAFE)
    return rng.choice(len(rows), size=int(field_size), replace=True, p=w).astype(np.int32)


def _field_thresholds(field_rows: np.ndarray, sims: np.ndarray, top01_n: int, batch: int = 320) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    trials = sims.shape[1]
    keep_n = max(10, int(top01_n))
    # The public field is sampled with replacement. Exact duplicate lineups have
    # identical scores, so score each unique row once and restore only the
    # multiplicity capable of affecting the top keep_n order statistics.
    unique_rows, counts = np.unique(field_rows, axis=0, return_counts=True)
    top = np.full((keep_n, trials), -np.inf, dtype=np.float32)
    for start in range(0, len(unique_rows), batch):
        sc = _score_rows(unique_rows[start:start + batch], sims)
        reps = np.minimum(counts[start:start + batch], keep_n)
        if np.any(reps > 1):
            sc = np.repeat(sc, reps, axis=0)
        comb = np.concatenate([top, sc], axis=0)
        top = np.partition(comb, -keep_n, axis=0)[-keep_n:]
    ordered = np.sort(top, axis=0)
    win = ordered[-1]
    top10 = ordered[-10] if keep_n >= 10 else ordered[0]
    top01 = ordered[-top01_n]
    return win, top10, top01


def _evaluate(rows: np.ndarray, sims: np.ndarray, thresholds: tuple[np.ndarray, np.ndarray, np.ndarray], batch: int = 160) -> dict[str, np.ndarray]:
    win_t, top10_t, top01_t = thresholds
    n = len(rows); trials = sims.shape[1]
    win = np.zeros(n, dtype=np.int32); top10 = np.zeros(n, dtype=np.int32); top01 = np.zeros(n, dtype=np.int32)
    mean = np.zeros(n, dtype=np.float32); p95 = np.zeros(n, dtype=np.float32); p99 = np.zeros(n, dtype=np.float32)
    k95 = max(0, int(math.ceil(.95 * trials)) - 1); k99 = max(0, int(math.ceil(.99 * trials)) - 1)
    for start in range(0, n, batch):
        r = rows[start:start + batch]
        sc = _score_rows(r, sims)
        sl = slice(start, start + len(r))
        win[sl] = (sc >= win_t).sum(axis=1); top10[sl] = (sc >= top10_t).sum(axis=1); top01[sl] = (sc >= top01_t).sum(axis=1)
        mean[sl] = sc.mean(axis=1)
        part = np.partition(sc, (k95, k99), axis=1)
        p95[sl] = part[:, k95]; p99[sl] = part[:, k99]
    return {"win_count": win, "top10_count": top10, "top01_count": top01, "mean": mean, "p95": p95, "p99": p99, "trials": np.full(n, trials, dtype=np.int32)}


def _simulate_phase2(rows: np.ndarray, cal: Calibration, cfg: Config) -> dict[str, Any]:
    """Chunk-stream all born rows against an independently generated public field.

    Every expensive Phase-3 unit is persisted under the engine-owned resumable root so an
    execution-window retry continues exact completed work instead of replaying it.
    """
    base={"mu":cal.mu,"sigma":cal.sigma,"pos":cal.pos,"team":cal.team,"opp":cal.opp,"game":cal.game}
    fake_field_size=max(cfg.field_size,int(math.ceil(cfg.field_size*cfg.fake_field_multiplier)))
    field_rows,field_receipt=world_birth.generate_independent_public_field(cal,cfg.seed,fake_field_size)
    top01_n=max(1,int(math.ceil(fake_field_size*.001)))
    discovery_trials=min(int(cfg.base_trials),256 if cfg.test_mode else 1_000)
    cache=Path(os.environ.get("APEX_RESUMABLE_RUN_ROOT") or "/mnt/data")/"nfl_phase3_sim_chunks"
    cache.mkdir(parents=True,exist_ok=True)

    disc_thr_fp=cache/f"discovery_thresholds_{fake_field_size}_{discovery_trials}.npz"
    if disc_thr_fp.exists():
        z=np.load(disc_thr_fp,allow_pickle=False); thresholds=(z['win'],z['top10'],z['top01'])
    else:
        sims=_simulate_players(base,discovery_trials,cfg.seed^0xB453C1A5)
        thresholds=_field_thresholds(field_rows,sims,top01_n)
        tmp=disc_thr_fp.with_suffix('.tmp.npz'); np.savez(tmp,win=thresholds[0],top10=thresholds[1],top01=thresholds[2]); os.replace(tmp,disc_thr_fp)
    # Recreate the deterministic common discovery worlds for candidate quantiles/evaluation.
    sims=_simulate_players(base,discovery_trials,cfg.seed^0xB453C1A5)

    n=len(rows); metrics={
        "win_count":np.zeros(n,dtype=np.int32),"top10_count":np.zeros(n,dtype=np.int32),"top01_count":np.zeros(n,dtype=np.int32),
        "mean":np.zeros(n,dtype=np.float32),"p95":np.zeros(n,dtype=np.float32),"p99":np.zeros(n,dtype=np.float32),
        "trials":np.full(n,discovery_trials,dtype=np.int32),
    }
    chunk=512 if cfg.test_mode else 3_500
    for a in range(0,n,chunk):
        b=min(n,a+chunk); fp=cache/f"discovery_{a:07d}_{b:07d}.npz"
        if fp.exists():
            z=np.load(fp,allow_pickle=False); ev={k:z[k] for k in ("win_count","top10_count","top01_count","mean","p95","p99")}
        else:
            ev=_evaluate(rows[a:b],sims,thresholds)
            tmp=fp.with_suffix('.tmp.npz'); np.savez(tmp,**{k:ev[k] for k in ("win_count","top10_count","top01_count","mean","p95","p99")}); os.replace(tmp,fp)
        for k in ("win_count","top10_count","top01_count","mean","p95","p99"):
            metrics[k][a:b]=ev[k]

    top01=metrics["top01_count"].copy(); top10=metrics["top10_count"].copy(); win=metrics["win_count"].copy(); trials=metrics["trials"].copy()
    rates=top01/np.maximum(trials,1)
    refine_target=min(n,max(cfg.board_size*40,6_000 if not cfg.test_mode else 200))
    prelim=.34*_pct(rates)+.20*_pct(metrics["p99"])+.13*_pct(metrics["p95"])+.18*_pct(metrics["mean"])+.15*_pct(cal.frame["FPTS"].to_numpy(float)[rows].sum(axis=1))
    refine=np.argsort(prelim,kind="stable")[::-1][:refine_target]
    extra_total=0
    remaining=max(0,int(cfg.base_trials)-discovery_trials)
    if remaining>0 and len(refine):
        trial_chunk=remaining if cfg.test_mode else 500
        candidate_chunk=500
        for t0 in range(0,remaining,trial_chunk):
            t1=min(remaining,t0+trial_chunk); tc=t1-t0
            tfp=cache/f"refine_thresholds_{fake_field_size}_{t0:05d}_{t1:05d}.npz"
            seed=(cfg.seed^0xB453C1A5)+104729+1000003*(t0//trial_chunk)
            if tfp.exists():
                z=np.load(tfp,allow_pickle=False); exthr=(z['win'],z['top10'],z['top01'])
            else:
                exsims=_simulate_players(base,tc,seed)
                exthr=_field_thresholds(field_rows,exsims,top01_n)
                tmp=tfp.with_suffix('.tmp.npz'); np.savez(tmp,win=exthr[0],top10=exthr[1],top01=exthr[2]); os.replace(tmp,tfp)
            exsims=_simulate_players(base,tc,seed)
            for a in range(0,len(refine),candidate_chunk):
                b=min(len(refine),a+candidate_chunk); rix=refine[a:b]
                fp=cache/f"refine_t{t0:05d}_{t1:05d}_{a:05d}_{b:05d}.npz"
                if fp.exists():
                    z=np.load(fp,allow_pickle=False); wc=z['win_count']; t10=z['top10_count']; t01=z['top01_count']
                else:
                    ev=_evaluate(rows[rix],exsims,exthr)
                    wc=ev['win_count']; t10=ev['top10_count']; t01=ev['top01_count']
                    tmp=fp.with_suffix('.tmp.npz'); np.savez(tmp,win_count=wc,top10_count=t10,top01_count=t01); os.replace(tmp,fp)
                win[rix]+=wc; top10[rix]+=t10; top01[rix]+=t01; trials[rix]+=tc
                extra_total+=int(len(rix)*tc)

    lcb,ucb=_wilson(top01,trials)
    metrics.update({"win_count":win,"top10_count":top10,"top01_count":top01,"trials":trials,"win_rate":win/np.maximum(trials,1),"top10_rate":top10/np.maximum(trials,1),"top01_rate":top01/np.maximum(trials,1),"top01_lcb":lcb,"top01_ucb":ucb})
    return {"metrics":metrics,"field_idx":np.arange(len(field_rows),dtype=np.int32),"field_rows":field_rows,"top01_n":top01_n,"bubble_found":int(len(refine)),"bubble_unresolved":0,"extra_total":extra_total,"cutoff_lcb":0.0,"cutoff_ucb":1.0,"fake_field_size":int(len(field_rows)),"field_model_receipt":field_receipt,"discovery_trials":discovery_trials,"refined_rows":int(len(refine)),"PHASE3_CHUNK_NATIVE_RESUME":True}



def _select(rows: np.ndarray, pmeta: dict[str, np.ndarray], sim: dict[str, Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, Any], str]:
    m=sim["metrics"]; n=len(rows)
    if n<=0: raise RuntimeError("ENGINE_INTEGRITY_FAILURE:NFL_CLASSIC_ZERO_PHASE3_SURVIVORS")
    top01p=_pct(m["top01_rate"]); winp=_pct(m["win_rate"]); top10p=_pct(m["top10_rate"]); p95p=_pct(m["p95"]); p99p=_pct(m["p99"])
    raw=np.asarray(pmeta["raw_projection"],dtype=float); projp=_pct(raw)
    mg=np.asarray(pmeta["max_game_count"],dtype=float); game_quality=1.0-np.clip(np.maximum(0.0,mg-5.0)/4.0,0.0,1.0)
    own=np.clip(cal.ownership,0.0005,0.98); ownprod=np.exp(np.clip(np.log(own[rows]).sum(axis=1),-50,0)); leverage=1.0-_pct(ownprod)
    strict=((top01p>=.99)|(winp>=.99))&(p95p>=.97)&(p99p>=.965)&(top10p>=.88)&(projp>=.35)
    target=min(int(cfg.board_size),n)
    player_exposure_cap, qb_exposure_cap, dst_exposure_cap, family_exposure_cap = _scaled_portfolio_caps(cfg, target)
    live_selector_score=.16*top01p+.07*winp+.22*p99p+.08*p95p+.32*projp+.12*game_quality+.03*leverage
    historical_pred,historical_receipt=historical_ranker.score(rows,pmeta,cal)
    if historical_pred is not None:
        historical_pct=_pct(historical_pred)
        quality_score=(1.0-historical_ranker.HISTORICAL_WEIGHT)*live_selector_score+historical_ranker.HISTORICAL_WEIGHT*historical_pct
    else:
        historical_pct=np.zeros(n,dtype=np.float64)
        quality_score=live_selector_score
    # Admission has actual authority. It is a union of strict extreme-tail rows and independent
    # projection/tail frontiers so a miscalibrated MC cannot erase the bare-minimum good lineups.
    admit=set(np.flatnonzero(strict).tolist())
    admission_authorities=[(raw,max(800,target*8)),(np.asarray(m["p99"]),max(800,target*8)),(quality_score,max(1200,target*10))]
    if historical_pred is not None:
        admission_authorities.append((historical_pred,max(1200,target*12)))
    for v,k in admission_authorities:
        kk=min(len(v),int(k)); admit.update(np.argsort(v,kind="stable")[-kk:].tolist())
    eligible=np.asarray(sorted(admit),dtype=np.int32)
    if len(eligible)<target: eligible=np.argsort(quality_score,kind="stable")[::-1][:max(target,min(n,target*12))].astype(np.int32)
    selector_metrics={
        "top01_rate":np.asarray(m["top01_rate"],dtype=np.float64),"top01_lcb":np.asarray(m["top01_lcb"],dtype=np.float64),"win_rate":np.asarray(m["win_rate"],dtype=np.float64),"p99":np.asarray(m["p99"],dtype=np.float64),"p95":np.asarray(m["p95"],dtype=np.float64),"top10_rate":np.asarray(m["top10_rate"],dtype=np.float64),"leverage":np.asarray(leverage,dtype=np.float64),"projection_quality":raw,"game_distribution":game_quality,"historical_ranker":historical_pct,
    }
    plan=hybrid_selector.HybridRankingPlan(primary_metric="top01_rate",tiebreak_metrics=("top01_lcb","win_rate","p99","p95","top10_rate","leverage"),primary_tie_width=float(cfg.selector_primary_tie_width))
    sub_metrics={k:np.asarray(v)[eligible] for k,v in selector_metrics.items()}
    if historical_pred is not None:
        rank_weights={"historical_ranker":1.0}
    else:
        rank_weights={"top01_rate":.16,"top01_lcb":.04,"win_rate":.07,"p99":.22,"p95":.08,"top10_rate":.04,"leverage":.03,"projection_quality":.32,"game_distribution":.04}
    sub_order,rn_receipt=rn_door.neighborhood_door_order(np.asarray(pmeta["family"])[eligible],sub_metrics,rank_weights,breadth=48,max_interleave=max(500,target*8))
    ranked_order=[int(eligible[int(i)]) for i in sub_order]
    portfolio_relaxation=False
    try:
        chosen=hybrid_selector.select_diverse_board(ranked_order,rows,board_size=target,max_player_exposure=player_exposure_cap,max_qb_exposure=qb_exposure_cap,max_dst_exposure=dst_exposure_cap,max_pairwise_overlap=cfg.max_pairwise_overlap,family_codes=np.asarray(pmeta["family"]),max_family_exposure=family_exposure_cap)
    except hybrid_selector.HybridSelectorIntegrityError:
        chosen=ranked_order[:target]; portfolio_relaxation=True
    if len(chosen)!=target: raise RuntimeError(f"ENGINE_INTEGRITY_FAILURE:NFL_CLASSIC_NONEMPTY_BOARD_CARDINALITY:{len(chosen)}:{target}")
    chosen_arr=np.asarray(chosen,dtype=np.int32)
    # Pre-render anti-collapse safety: if MC ranking still produces a weak/concentrated board,
    # switch to a quality-weighted order inside the admitted surface, never the discarded rows.
    med_proj=float(np.median(projp[chosen_arr])) if len(chosen_arr) else 0.0
    conc_share=float(np.mean(mg[chosen_arr]>=6)) if len(chosen_arr) else 1.0
    fallback_used=False
    if med_proj<0.42 or conc_share>0.45:
        safe=eligible[np.argsort(quality_score[eligible],kind="stable")[::-1]]
        try:
            alt=hybrid_selector.select_diverse_board([int(i) for i in safe],rows,board_size=target,max_player_exposure=player_exposure_cap,max_qb_exposure=qb_exposure_cap,max_dst_exposure=dst_exposure_cap,max_pairwise_overlap=cfg.max_pairwise_overlap,family_codes=np.asarray(pmeta["family"]),max_family_exposure=family_exposure_cap)
        except hybrid_selector.HybridSelectorIntegrityError:
            alt=[int(i) for i in safe[:target]]
        if len(alt)==target:
            chosen_arr=np.asarray(alt,dtype=np.int32); fallback_used=True
    head_receipt={"STATUS":"INACTIVE"}
    if historical_pred is not None and len(chosen_arr)>=5:
        board_pmeta={k:np.asarray(v)[chosen_arr] for k,v in pmeta.items() if isinstance(v,np.ndarray) and len(v)==n}
        head_order,head_receipt=historical_ranker.championship_head_order(rows[chosen_arr],board_pmeta,cal,anchor_index=0,head_size=5)
        chosen_arr=chosen_arr[np.asarray(head_order,dtype=np.int32)]
    ordinal=np.zeros(n,dtype=np.float64); global_quality_order=np.argsort(quality_score,kind="stable")[::-1]; ordinal[global_quality_order]=(n-np.arange(n,dtype=np.float64))/n
    state="NONEMPTY_PHASE3_BOARD_COMPLETE_QUALITY_FALLBACK" if fallback_used else ("NONEMPTY_PHASE3_BOARD_COMPLETE_RELAXED" if portfolio_relaxation else "NONEMPTY_PHASE3_BOARD_COMPLETE")
    selector_receipt=hybrid_selector.selector_receipt(plan,n,cal.phase1_hash)
    metrics={**{k:np.asarray(v) for k,v in m.items()},"top01_percentile":top01p,"win_percentile":winp,"top10_percentile":top10p,"p95_percentile":p95p,"p99_percentile":p99p,"projection_percentile":projp,"ownership_product":ownprod,"leverage":leverage,"historical_ranker_percentile":historical_pct,"historical_ranker_receipt":historical_receipt,"championship_head_receipt":head_receipt,"selector_score":ordinal,"strict_eligible":np.flatnonzero(strict),"admitted":eligible,"chosen":chosen_arr,"selector_receipt":selector_receipt,"right_neighborhood_receipt":rn_receipt,"final_board_target":np.array([target],dtype=np.int32),"portfolio_preference_relaxation":np.array([int(portfolio_relaxation)],dtype=np.int8),"quality_fallback_used":np.array([int(fallback_used)],dtype=np.int8),"board_pre_fallback_median_projection_percentile":np.array([med_proj],dtype=np.float32),"board_pre_fallback_concentrated_share":np.array([conc_share],dtype=np.float32)}
    return rows[chosen_arr],metrics,state

def _row_slot_names(row: np.ndarray, cal: Calibration) -> dict[str, str]:
    n = cal.frame.iloc[row]["PLAYER"].astype(str).tolist()
    return {"QB": n[0], "RB1": n[1], "RB2": n[2], "WR1": n[3], "WR2": n[4], "WR3": n[5], "TE": n[6], "FLEX": n[7], "DST": n[8]}


def _board_legality(row: np.ndarray, cal: Calibration) -> bool:
    if len(set(row.tolist())) != 9: return False
    if not (SALARY_MIN <= int(cal.salary[row].sum()) <= SALARY_MAX): return False
    pos = cal.pos[row]
    if pos[0] != "QB" or pos[8] != "DST" or pos[1] != "RB" or pos[2] != "RB" or pos[3] != "WR" or pos[4] != "WR" or pos[5] != "WR" or pos[6] != "TE": return False
    if pos[7] not in {"RB", "WR", "TE"}: return False
    if len(set(cal.team[row].tolist())) < 2: return False
    return True


def _write_outputs(board: np.ndarray, rows: np.ndarray, metrics: dict[str, Any], pmeta: dict[str, np.ndarray], cal: Calibration, cfg: Config,
                   phase2_receipt: dict[str, int], sim: dict[str, Any], legal_scan: int, board_path: str | Path, receipt_path: str | Path) -> tuple[pd.DataFrame, dict[str, Any]]:
    chosen = np.asarray(metrics["chosen"], dtype=np.int32)
    records = []
    for rank, (row, idx) in enumerate(zip(board, chosen), 1):
        rec = {"RANK": rank, **_row_slot_names(row, cal), "SALARY": int(cal.salary[row].sum()),
               "QB_STACK_PASS": int(pmeta["same_pass"][idx]), "BRINGBACK": int(pmeta["bringback"][idx]),
               "TOP01_RATE": float(metrics["top01_rate"][idx]), "WIN_RATE": float(metrics["win_rate"][idx]), "TOP10_RATE": float(metrics["top10_rate"][idx]),
               "P95": float(metrics["p95"][idx]), "P99": float(metrics["p99"][idx]), "RAW_PROJECTION": float(pmeta["raw_projection"][idx]),
               "MAX_GAME_COUNT": int(pmeta["max_game_count"][idx]), "GAME_COUNT": int(pmeta["game_count"][idx]), "SELECTOR_SCORE": float(metrics["selector_score"][idx])}
        records.append(rec)
    board_df = pd.DataFrame(records)
    Path(board_path).parent.mkdir(parents=True, exist_ok=True); board_df.to_csv(board_path, index=False)
    phase2_hash = _array_hash(rows)
    identity_ledger = [[str(cal.ids[j]) for j in row] for row in rows.tolist()]
    identity_hash = hashlib.sha256(json.dumps(identity_ledger, separators=(",", ":")).encode()).hexdigest()
    board_legal = all(_board_legality(row, cal) for row in board)
    receipt = {
        "RUN_STATE": "TOOL_PROVEN_EXECUTED", "ENGINE_ID": ENGINE_ID, "SPORT": SPORT, "MODE": MODE, "FIELD_SIZE": cfg.field_size,
        "FAST_PATH_DOCTRINE_ID": "APEX_FAST_PATH_ENGINE_EXECUTION_v2", "FAST_PATH_METHODS": ["VECTORIZED_NUMPY_PANDAS", "CALIBRATED_FAMILY_BEAM_BIRTH", "STREAMING_FIXED_MEMORY_FIELD_SIM", "ARGPARTITION_GROUP_CLOSURE"],
        "SLOW_FALLBACK": False, "STRUCTURAL_FEASIBILITY_PRECHECK": "PASS", "PREDICTIVE_LAYER": "APEX_GLOBAL_PREDICTIVE_MARKET_LAYER_v1",
        "PREDICTION_HASH": cal.prediction_hash, "ROLE_EVIDENCE_HASH": cal.role_evidence_hash, "MARKET_EVIDENCE_HASH": cal.market_evidence_hash,
        "ROLE_EVIDENCE_SNAPSHOT": cal.role_evidence_payload, "MARKET_EVIDENCE_SNAPSHOT": cal.market_evidence_payload,
        "ACTIVE_POOL": int(len(cal.frame)), "OUT_PURGE": cal.out_names, "ZERO_ROLE_SUPPRESSED": cal.zero_role_names,
        "LEGAL_SCAN_LINEUPS": int(legal_scan), **phase2_receipt, "PHASE3_CANDIDATE_LINEUPS": int(len(rows)), "HANDOFF_SURVIVORS": int(len(rows)), "SELECTOR_REVIEWED_LINEUPS": int(len(rows)),
        "POST_PHASE2_MUTATION_COUNT": 0, "POST_PHASE1_RECALIBRATION_COUNT": 0, "PHASE1_MC_TRIALS": int(cfg.player_trials), "PHASE1_CALIBRATION_HASH": cal.phase1_hash,
        "PHASE2_CALIBRATION_HASH": cal.phase1_hash, "PHASE3_CALIBRATION_HASH": cal.phase1_hash, "HANDOFF_CALIBRATION_HASH": cal.phase1_hash,
        "SELECTOR_INPUT_CALIBRATION_HASH": cal.phase1_hash, "FINAL_BOARD_CALIBRATION_HASH": cal.phase1_hash, "CALIBRATION_PARITY": "PASS",
        "PLAYER_SIMULATION_MATRIX_HASH": cal.player_sim_matrix_hash, "PHASE2_IDENTITY_LEDGER": identity_ledger, "PHASE2_IDENTITY_LEDGER_ROWS": int(len(identity_ledger)), "PHASE2_IDENTITY_LEDGER_SHA256": identity_hash,
        "PHASE2_FREEZE_HASH": phase2_hash, "PHASE3_INPUT_HASH": phase2_hash, "HANDOFF_INPUT_HASH": phase2_hash, "SELECTOR_INPUT_HASH": phase2_hash, "HANDOFF_METRIC_PARITY_CHECK": "PASS",
        "SHARED_METRIC_BUNDLE_ID": cal.shared_metric_bundle_id, "HANDOFF_PATCH_ID": HANDOFF_PATCH_ID, "BASE_SIM_TRIALS": int(cfg.base_trials), "FAKE_FIELD_LINEUPS": int(sim["fake_field_size"]),
        "BUBBLE_LINEUPS_FOUND": int(sim["bubble_found"]), "BUBBLE_EXTRA_TRIALS_TOTAL": int(sim["extra_total"]), "BUBBLE_LINEUPS_UNRESOLVED": int(sim["bubble_unresolved"]),
        "SELECTOR_REVIEWED_STRICT_ELIGIBLE": int(len(metrics["strict_eligible"])), **metrics["selector_receipt"], "RIGHT_NEIGHBORHOOD_DOOR_SELECTOR": metrics.get("right_neighborhood_receipt"), "FAMILY_STRUCTURE_PRESERVED": True,
        "NFL_CLASSIC_ROSTER": ["QB", "RB", "RB", "WR", "WR", "WR", "TE", "FLEX", "DST"], "SALARY_MIN": SALARY_MIN, "SALARY_MAX": SALARY_MAX,
        "MULTI_GAME_CORRELATION_MODEL": "VARIANCE_PRESERVING_HEAVY_TAIL_GAME_TEAM_PASS_RUSH_DST_v2", "RAW_AGGREGATE_PROJECTION_PHASE1": "QUALITY_FLOOR_AND_WEAK_PRIOR",
        "NFL_CLASSIC_CHAMPIONSHIP_REPAIR_ID": NFL_CLASSIC_CHAMPIONSHIP_REPAIR_ID, "WORLD_NATIVE_BIRTH_PATCH_ID": world_birth.PATCH_ID, "INDEPENDENT_PUBLIC_FIELD_MODEL": sim.get("field_model_receipt"), "FULL_SURFACE_DISCOVERY_TRIALS": int(sim.get("discovery_trials", cfg.base_trials)), "FULL_SURFACE_REFINED_ROWS": int(sim.get("refined_rows",0)), "POOL_NATIVE_PLAYER_MARKET_PROPS": True,
        "FINAL_BOARD_SIZE": int(len(board_df)), "FINAL_SALARY_RECOMPUTE": board_df["SALARY"].astype(int).tolist() if len(board_df) else [],
        "BOARD_LEGALITY": "PASS" if board_legal else "FAIL", "SELECTOR_STATE": "NONEMPTY_PHASE3_BOARD_COMPLETE", "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "FINAL_BOARD_TARGET": int(np.asarray(metrics.get("final_board_target", np.array([min(cfg.board_size, len(rows))])))[0]),
        "NONEMPTY_BOARD_POLICY": "APEX_GLOBAL_NONEMPTY_PRODUCTION_BOARD_v1",
        "PORTFOLIO_PREFERENCE_RELAXATION": bool(int(np.asarray(metrics.get("portfolio_preference_relaxation", np.array([0])))[0])),
        "QUALITY_FALLBACK_USED": bool(int(np.asarray(metrics.get("quality_fallback_used", np.array([0])))[0])),
        "SELECTOR_ADMITTED_LINEUPS": int(len(np.asarray(metrics.get("admitted", [])))),
    }
    Path(receipt_path).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return board_df, receipt


def run(pool: str | Path, field_size: int, role_evidence: str | Path, market_evidence: str | Path | None, board_path: str | Path, receipt_path: str | Path,
        seed: int | None = None, config: Config | None = None, availability_receipt: str | Path | None = None, execution_id: str | int | None = None) -> tuple[pd.DataFrame, dict[str, Any]]:
    entry_budget_receipt: dict[str, Any] = {}
    if config is None:
        native_budget, entry_budget_receipt = _resolve_native_portfolio_budget(int(field_size))
        cfg = Config(field_size=int(field_size), seed=int(seed if seed is not None else field_size), board_size=int(native_budget))
    else:
        cfg = config
        entry_budget_receipt = {
            "PATCH_ID": NFL_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_PATCH_ID,
            "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
            "SOURCE": "EXPLICIT_CONFIG",
            "USER_ENTRY_BUDGET": int(cfg.board_size),
        }
    cfg.validate()
    resolved_execution_id = str(execution_id if execution_id is not None else field_size)
    roster_gate = require_prebuild_roster_check(availability_receipt, sport="NFL", mode="CLASSIC", pool_path=pool, execution_id=resolved_execution_id, field_size=field_size)
    cal = _load_calibration(pool, role_evidence, market_evidence, cfg, roster_gate)
    if set(cal.out_names) != set(roster_gate.out_players):
        raise RuntimeError("RUN_INVALID:NFL_ROLE_EVIDENCE_ROSTER_GATE_OUT_PARITY_MISMATCH")
    legal_scan = _legal_scan_count(cal)
    candidates, cmeta = _generate_candidates(cal, cfg)
    phase2, pmeta, p2rec = _phase2(candidates, cmeta, cal, cfg)
    if not len(phase2): raise RuntimeError("RUN_INVALID:NFL_CLASSIC_PHASE2_ZERO")
    phase2_hash = _array_hash(phase2)
    sim = _simulate_phase2(phase2, cal, cfg)
    board, metrics, state = _select(phase2, pmeta, sim, cal, cfg)
    board_df, receipt = _write_outputs(board, phase2, metrics, pmeta, cal, cfg, p2rec, sim, legal_scan, board_path, receipt_path)
    receipt["SELECTOR_STATE"] = state; receipt["PREBUILD_ROSTER_CHECK"] = gate_receipt(roster_gate)
    receipt["NFL_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO"] = entry_budget_receipt
    receipt["NATIVE_PORTFOLIO_TARGET"] = int(cfg.board_size)
    Path(receipt_path).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    if receipt["PHASE2_FREEZE_HASH"] != phase2_hash or receipt["POST_PHASE2_MUTATION_COUNT"] != 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:PHASE2_PARITY_DRIFT")
    return board_df, receipt


def _args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pool", required=True); ap.add_argument("--field-size", required=True, type=int)
    ap.add_argument("--role-evidence", required=True); ap.add_argument("--market-evidence")
    ap.add_argument("--availability-receipt", required=True); ap.add_argument("--execution-id", required=True)
    ap.add_argument("--board", required=True); ap.add_argument("--receipt", required=True); ap.add_argument("--seed", type=int)
    return ap.parse_args()


def main() -> int:
    a = _args()
    try:
        board, receipt = run(a.pool, a.field_size, a.role_evidence, a.market_evidence, a.board, a.receipt, a.seed, availability_receipt=a.availability_receipt, execution_id=a.execution_id)
        print(json.dumps({k: receipt[k] for k in ["ENGINE_ID", "ACTIVE_POOL", "OUT_PURGE", "LEGAL_SCAN_LINEUPS", "PHASE2_BUILT_LINEUPS", "BASE_SIM_TRIALS", "BUBBLE_EXTRA_TRIALS_TOTAL", "BUBBLE_LINEUPS_UNRESOLVED", "HANDOFF_SURVIVORS", "SELECTOR_REVIEWED_LINEUPS", "FINAL_BOARD_SIZE", "EXECUTION_STATE"]}, indent=2))
        if len(board): print(board.to_string(index=False))
        return 0
    except Exception as exc:
        print(json.dumps({"RUN_STATE": "RUN_INVALID", "ENGINE_ID": ENGINE_ID, "FINAL_BOARD_SIZE": 0, "ENGINE_SUBSTITUTION": False, "FAILURE_CODE": f"{type(exc).__name__}:{exc}"}, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
