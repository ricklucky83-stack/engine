from __future__ import annotations

import numpy as np
import pandas as pd

PATCH_ID = "NFL_SS_YARDS_MODE_SPECIFIC_OWNERSHIP_v1"
STATUS = "SHADOW_CANDIDATE"
ELIGIBLE_POSITIONS = frozenset({"RB", "WR", "TE", "FB"})
TARGET_ROSTER_MASS_PCT = 300.0


def _num(df: pd.DataFrame, col: str, default: float = 0.0) -> np.ndarray:
    if col not in df.columns:
        return np.full(len(df), default, dtype=np.float64)
    return pd.to_numeric(df[col], errors="coerce").fillna(default).to_numpy(np.float64)


def _pos_base(s: pd.Series) -> np.ndarray:
    return s.astype(str).str.split("/").str[0].str.strip().str.upper().to_numpy(object)


def eligible_mask(df: pd.DataFrame) -> np.ndarray:
    pos = _pos_base(df.get("POS", pd.Series("", index=df.index)))
    fpts = _num(df, "FPTS")
    rush = _num(df, "O/U RUYD")
    player = df.get("PLAYER", pd.Series("", index=df.index)).astype(str).str.strip().str.upper()
    # Status fields vary by feed. Only explicit hard-out labels may remove a player here.
    status_col = next((c for c in ("STATUS", "Status", "INJURY STATUS", "ROLE_STATUS") if c in df.columns), None)
    if status_col is None:
        hard_out = np.zeros(len(df), dtype=bool)
    else:
        status = df[status_col].astype(str).str.strip().str.upper()
        hard_out = status.isin({"OUT", "IR", "CONFIRMED_OUT", "INACTIVE"}).to_numpy(bool)
    eligible = np.isin(pos, list(ELIGIBLE_POSITIONS)) & ((fpts > 0.0) | (rush > 0.0)) & (~hard_out)
    # Explicit zero-role rows remain excluded even when a stale RST prior is nonzero.
    return eligible


def _mass(x: np.ndarray, target: float = TARGET_ROSTER_MASS_PCT) -> np.ndarray:
    x = np.clip(np.asarray(x, dtype=np.float64), 0.0, None)
    s = float(x.sum())
    if s <= 0.0:
        raise RuntimeError("RUN_INVALID:NFL_SS_YARDS_OWNERSHIP_NO_POSITIVE_SIGNAL")
    return x * (float(target) / s)


def derive_shadow_ownership(df: pd.DataFrame) -> pd.DataFrame:
    """Pre-lock NFL Single-Stat Yards ownership prior.

    Uses only player-pool information available before results: source projection,
    source ceiling, generic RST prior, and explicit rushing-yard market line when present.
    No actual ownership, standings, realized yards, player-name constants, or result labels.
    """
    out = df.copy()
    elig = eligible_mask(out)
    out["NFL_SS_YARDS_ELIGIBLE"] = elig
    out["NFL_SS_YARDS_EXPECTED_OWNERSHIP"] = 0.0
    out["NFL_SS_YARDS_OWNERSHIP_AUTHORITY"] = "SHADOW_MODE_SPECIFIC_PRELOCK"
    out["NFL_SS_YARDS_OWNERSHIP_PATCH_ID"] = PATCH_ID

    if not np.any(elig):
        raise RuntimeError("RUN_INVALID:NFL_SS_YARDS_NO_ELIGIBLE_PLAYERS")

    fpts = np.clip(_num(out, "FPTS"), 0.01, None)
    ceil = np.clip(_num(out, "Ceil", default=np.nan), 0.01, None)
    missing_ceil = ~np.isfinite(ceil)
    ceil[missing_ceil] = fpts[missing_ceil]
    rst = np.clip(_num(out, "RST%"), 0.0, None)
    rush = np.clip(_num(out, "O/U RUYD"), 0.0, None)

    idx = np.flatnonzero(elig)
    def component(v: np.ndarray, power: float) -> np.ndarray:
        z = np.power(np.maximum(v[idx], 0.01), power)
        return _mass(z)

    # Conservative same-mode structure: projection carries most weight; generic RST is only a weak prior.
    fpts_mass = component(fpts, 1.80)
    ceil_mass = component(ceil, 1.60)
    if float(rst[idx].sum()) > 0:
        rst_mass = _mass(rst[idx])
    else:
        rst_mass = np.full(len(idx), TARGET_ROSTER_MASS_PCT / len(idx), dtype=np.float64)

    pred = 0.85 * fpts_mass + 0.10 * ceil_mass + 0.05 * rst_mass

    # Explicit rushing-line information is directly relevant to the target stat.
    # Keep the adjustment small because receiving-yard markets may not be present in the feed.
    max_rush = float(rush[idx].max()) if len(idx) else 0.0
    if max_rush > 0.0:
        pred *= 1.0 + 0.10 * (rush[idx] / max_rush)

    pred = _mass(pred)
    out.loc[out.index[idx], "NFL_SS_YARDS_EXPECTED_OWNERSHIP"] = pred
    return out


def receipt(df: pd.DataFrame) -> dict:
    out = derive_shadow_ownership(df)
    elig = out["NFL_SS_YARDS_ELIGIBLE"].to_numpy(bool)
    own = out["NFL_SS_YARDS_EXPECTED_OWNERSHIP"].to_numpy(np.float64)
    return {
        "PATCH_ID": PATCH_ID,
        "STATUS": STATUS,
        "ELIGIBLE_COUNT": int(elig.sum()),
        "OWNERSHIP_MASS_PCT": float(own.sum()),
        "QB_ELIGIBILITY": False,
        "K_DST_ELIGIBILITY": False,
        "POSTLOCK_INPUTS_USED": False,
        "PLAYER_NAME_CONSTANTS_USED": False,
        "GENERIC_RST_ROLE": "WEAK_PRIOR_ONLY",
        "PRIMARY_SIGNAL": "SOURCE_PROJECTION_WITH_MODE_RELEVANT_YARD_OPPORTUNITY",
    }
