from __future__ import annotations

import csv
import hashlib
import json
import math
import os
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

PATCH_ID = "NFL_SS_TDS_CALIBRATION_QUALIFIED_WORLD_BIRTH_v2"
ROSTER_SIZE = 3
EXPECTED_OWNERSHIP_MASS = 3.0
MAX_PLAYER_TDS_PER_WORLD = 6


def _stable_hash(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def _capped_mass(base: np.ndarray, total: float = 3.0) -> np.ndarray:
    base = np.maximum(np.asarray(base, dtype=float), 1e-12)
    n = len(base)
    if n < 3:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_OWNERSHIP_POOL_LT3")
    cap = 1.0 if n == 3 else 0.985
    free = np.ones(n, dtype=bool)
    out = np.zeros(n, dtype=float)
    remain = total
    for _ in range(n + 2):
        if not free.any():
            break
        alloc = remain * base[free] / base[free].sum()
        over = alloc > cap
        if not over.any():
            out[free] = alloc
            remain = 0.0
            break
        idx_free = np.where(free)[0]
        hit = idx_free[over]
        out[hit] = cap
        remain -= cap * len(hit)
        free[hit] = False
    if remain > 1e-8:
        out[free] += remain / max(1, free.sum())
    out *= total / out.sum()
    if (out > 1.0000001).any() or abs(out.sum() - total) > 1e-8:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_OWNERSHIP_MASS_NORMALIZATION_FAILED")
    return out


def _maxent_theta(target: np.ndarray) -> tuple[np.ndarray, float, np.ndarray]:
    """Exact 3-of-N maximum-entropy weights matching player inclusion marginals."""
    t = np.asarray(target, dtype=float)
    if len(t) == 3:
        return np.ones(3), 1.0, np.ones(3)
    theta = np.log(np.maximum(t, 1e-8) / np.maximum(1.0 - t, 1e-8))
    theta -= theta.mean()
    marg = np.zeros_like(t)
    for _ in range(400):
        w = np.exp(np.clip(theta, -30, 30))
        s1 = w.sum(); s2 = np.square(w).sum(); s3 = np.power(w, 3).sum()
        z = (s1 ** 3 - 3 * s1 * s2 + 2 * s3) / 6.0
        if not (z > 0 and math.isfinite(z)):
            raise RuntimeError("RUN_INVALID:NFL_SS_TDS_MAXENT_PARTITION_INVALID")
        e2_ex = ((s1 - w) ** 2 - (s2 - w ** 2)) / 2.0
        marg = w * e2_ex / z
        err = t - marg
        if float(np.max(np.abs(err))) < 1e-9:
            return w, float(z), marg
        step = np.clip(np.log(np.maximum(t, 1e-12) / np.maximum(marg, 1e-12)), -0.5, 0.5)
        theta += 0.55 * step
        theta -= theta.mean()
    if float(np.max(np.abs(t - marg))) > 2e-6:
        raise RuntimeError(f"RUN_INVALID:NFL_SS_TDS_MAXENT_MARGINAL_SOLVE_FAILED:{float(np.max(np.abs(t-marg))):.6g}")
    w = np.exp(np.clip(theta, -30, 30))
    s1 = w.sum(); s2 = np.square(w).sum(); s3 = np.power(w, 3).sum()
    z = (s1 ** 3 - 3 * s1 * s2 + 2 * s3) / 6.0
    return w, float(z), marg


def _phase1_player_strength(df: pd.DataFrame, counts: np.ndarray) -> np.ndarray:
    p1 = (counts >= 1).mean(axis=1)
    p2 = (counts >= 2).mean(axis=1)
    p3 = (counts >= 3).mean(axis=1)
    mean = counts.mean(axis=1)
    role = df["ROLE_SIGNAL"].to_numpy(float)
    market = df["TD_MARKET_SUPPORT"].to_numpy(float)
    rz = df["RED_ZONE_SUPPORT"].to_numpy(float)
    role_rank = pd.Series(role).rank(pct=True).to_numpy(float)
    market_rank = pd.Series(market).rank(pct=True).to_numpy(float)
    rz_rank = pd.Series(rz).rank(pct=True).to_numpy(float)
    return (
        1.65 * p1 + 0.85 * p2 + 0.45 * p3 + 0.30 * mean
        + 0.18 * role_rank + 0.12 * market_rank + 0.10 * rz_rank
    )


def _add_birth(bucket: dict[tuple[int, int, int], set[str]], ids: Iterable[int], lane: str) -> tuple[int, int, int] | None:
    key = tuple(sorted(int(x) for x in ids))
    if len(key) != ROSTER_SIZE or len(set(key)) != ROSTER_SIZE:
        return None
    bucket.setdefault(key, set()).add(str(lane))
    return key


def phase1_calibration_qualified_birth(
    df: pd.DataFrame,
    counts: np.ndarray,
    max_candidates: int | None = None,
) -> tuple[list[tuple[int, int, int]], dict[tuple[int, int, int], set[str]], dict[str, Any]]:
    """Birth only triads supported by Phase-1 TD worlds or calibrated event cores.

    There is no traversal of the legal C(N,3) lineup lattice.
    """
    n, trials = counts.shape
    if n < ROSTER_SIZE:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_ACTIVE_POOL_LT3")
    if max_candidates is None:
        max_candidates = min(5000, max(64, 32 * n))

    strength = _phase1_player_strength(df, counts)
    tie = 1e-6 * pd.Series(strength).rank(method="first").to_numpy(float)
    births: dict[tuple[int, int, int], set[str]] = {}
    tri_recurrence: Counter[tuple[int, int, int]] = Counter()
    lane_unique = Counter()
    zero_event_worlds = 0

    world_chunk = 512
    for a in range(0, trials, world_chunk):
        b = min(trials, a + world_chunk)
        block = counts[:, a:b].astype(float) + tie[:, None]
        k = min(4, n)
        top = np.argpartition(block, -k, axis=0)[-k:]
        for j in range(b - a):
            ids = top[:, j]
            ids = ids[np.argsort(block[ids, j])[::-1]]
            raw = counts[ids, a + j]
            if int(raw[:3].sum()) <= 0:
                zero_event_worlds += 1
                continue
            before = len(births)
            key = _add_birth(births, ids[:3], "PHASE1_WORLD_OPTIMAL")
            if key is not None:
                tri_recurrence[key] += 1
            if len(births) > before:
                lane_unique["PHASE1_WORLD_OPTIMAL"] += 1
            if k == 4:
                best = int(raw[:3].sum())
                candidates = (
                    (ids[0], ids[1], ids[3]),
                    (ids[0], ids[2], ids[3]),
                    (ids[1], ids[2], ids[3]),
                )
                for tri in candidates:
                    sc = int(counts[list(tri), a + j].sum())
                    if sc >= max(1, best - 1):
                        before = len(births)
                        key = _add_birth(births, tri, "PHASE1_NEAR_OPTIMAL_ONE_TD")
                        if key is not None:
                            tri_recurrence[key] += 1
                        if len(births) > before:
                            lane_unique["PHASE1_NEAR_OPTIMAL_ONE_TD"] += 1

    order = np.argsort(-strength, kind="stable")
    before = len(births)
    _add_birth(births, order[:3], "PHASE1_GLOBAL_EVENT_CORE")
    if len(births) > before:
        lane_unique["PHASE1_GLOBAL_EVENT_CORE"] += 1

    for _, g in df.groupby("TEAM", sort=True):
        ids = g.index.to_numpy(dtype=int)
        if len(ids) < 3:
            continue
        ranked = ids[np.argsort(-strength[ids], kind="stable")]
        before = len(births)
        _add_birth(births, ranked[:3], "PHASE1_TEAM_EVENT_CORE")
        if len(births) > before:
            lane_unique["PHASE1_TEAM_EVENT_CORE"] += 1

    pair_counts: Counter[tuple[int, int]] = Counter()
    for tri, recur in tri_recurrence.items():
        a0, b0, c0 = tri
        pair_counts[(a0, b0)] += recur
        pair_counts[(a0, c0)] += recur
        pair_counts[(b0, c0)] += recur
    posterior_floor = float(np.quantile(strength, 0.50))
    for pair, _ in pair_counts.most_common(64):
        used = 0
        for third in order:
            third = int(third)
            if third in pair or strength[third] < posterior_floor:
                continue
            before = len(births)
            _add_birth(births, (pair[0], pair[1], third), "PHASE1_RECURRENT_PAIR_CLOSURE")
            if len(births) > before:
                lane_unique["PHASE1_RECURRENT_PAIR_CLOSURE"] += 1
            used += 1
            if used >= 2:
                break

    if len(births) > max_candidates:
        scored = []
        for tri in births:
            recur = int(tri_recurrence.get(tri, 0))
            pair_recur = sum(pair_counts.get(tuple(sorted((tri[i], tri[j]))), 0) for i, j in ((0, 1), (0, 2), (1, 2)))
            agg = float(strength[list(tri)].sum())
            scored.append((recur, pair_recur, agg, tri))
        keep = {x[3] for x in sorted(scored, key=lambda x: (-x[0], -x[1], -x[2], x[3]))[:max_candidates]}
        births = {k: v for k, v in births.items() if k in keep}

    if not births:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:NFL_SS_TDS_NO_CALIBRATION_QUALIFIED_BIRTHS")

    keys = sorted(births)
    theoretical = int(math.comb(n, 3))
    receipt = {
        "PATCH_ID": PATCH_ID,
        "CALIBRATION_QUALIFIED_BIRTH_CERTIFIED": True,
        "UNQUALIFIED_CANDIDATE_BIRTH_ALLOWED": False,
        "FULL_LEGAL_UNIVERSE_ENUMERATION_ALLOWED": False,
        "PRE_PHASE2_RAW_LATTICE_MATERIALIZATION_ALLOWED": False,
        "BIRTH_METHOD": "PHASE1_WORLD_NATIVE_PLUS_RECURRENT_EVENT_CORE_CLOSURE",
        "PHASE1_TRIALS": int(trials),
        "THEORETICAL_LEGAL_TRIADS": theoretical,
        "CALIBRATION_QUALIFIED_BIRTHS": int(len(keys)),
        "BIRTH_TO_THEORETICAL_RATIO": float(len(keys) / theoretical),
        "MAX_CANDIDATE_DURABILITY_BOUND": int(max_candidates),
        "LANE_UNIQUE_ADDS": dict(lane_unique),
        "ZERO_EVENT_WORLDS_SKIPPED": int(zero_event_worlds),
        "PLAYER_EVENT_STRENGTH_SHA256": _stable_hash(np.round(strength, 12).tolist()),
    }
    return keys, births, receipt


def weighted_3ofn_score_mass(
    weights: np.ndarray,
    counts: np.ndarray,
    max_score: int,
    world_chunk: int = 512,
) -> tuple[np.ndarray, float]:
    """Exact weighted 3-of-N score distribution by dynamic programming.

    Computes the score polynomial directly; lineup identities are never enumerated.
    """
    w = np.asarray(weights, dtype=float)
    n, trials = counts.shape
    if n < 3:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_FIELD_POOL_LT3")
    s1 = float(w.sum()); s2 = float(np.square(w).sum()); s3 = float(np.power(w, 3).sum())
    z = (s1 ** 3 - 3.0 * s1 * s2 + 2.0 * s3) / 6.0
    if not (z > 0 and math.isfinite(z)):
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_FIELD_PARTITION_INVALID")

    mass = np.zeros((max_score + 1, trials), dtype=np.float64)
    for a in range(0, trials, world_chunk):
        b = min(trials, a + world_chunk)
        m = b - a
        dp = np.zeros((4, max_score + 1, m), dtype=np.float64)
        dp[0, 0, :] = 1.0
        for i in range(n):
            score_i = counts[i, a:b].astype(np.int16)
            for k in (3, 2, 1):
                prev = dp[k - 1].copy()
                for sv in range(MAX_PLAYER_TDS_PER_WORLD + 1):
                    cols = np.flatnonzero(score_i == sv)
                    if not len(cols):
                        continue
                    src = np.arange(0, max_score + 1 - sv)
                    dst = src + sv
                    dp[k][np.ix_(dst, cols)] += w[i] * prev[np.ix_(src, cols)]
        mass[:, a:b] = dp[3] / z
    return mass, float(z)


def build_candidate_surface_calibration_qualified(
    df: pd.DataFrame,
    counts: np.ndarray,
    field_size: int,
    chunk_size: int,
    output: Path,
) -> tuple[dict[str, Any], pd.DataFrame]:
    n, trials = counts.shape
    p1 = (counts >= 1).mean(axis=1)
    p2 = (counts >= 2).mean(axis=1)
    role = df["ROLE_SIGNAL"].to_numpy(float)
    role_rank = pd.Series(role).rank(pct=True).to_numpy(float)
    rst = df["RST_PRIOR_RAW"].to_numpy(float)
    rst_rank = pd.Series(rst).rank(pct=True).fillna(0.5).to_numpy(float)
    attr = 1.55*np.log(np.maximum(p1,1e-5)) + 0.40*np.log1p(8.0*p2) + 0.25*role_rank + 0.10*rst_rank
    base = np.exp(attr - np.max(attr))
    target_own = _capped_mass(base, EXPECTED_OWNERSHIP_MASS)
    w, _, solved_marg = _maxent_theta(target_own)
    own_error = float(np.max(np.abs(solved_marg - target_own)))

    candidates, birth_lanes, birth_receipt = phase1_calibration_qualified_birth(df, counts)
    max_score = int(min(ROSTER_SIZE * MAX_PLAYER_TDS_PER_WORLD, int(counts.max()) * ROSTER_SIZE))
    mass, z = weighted_3ofn_score_mass(w, counts, max_score, world_chunk=max(64, min(1024, chunk_size)))
    world_mass = mass.sum(axis=0)
    err = float(np.max(np.abs(world_mass - 1.0)))
    if err > 2e-7:
        raise RuntimeError(f"RUN_INVALID:NFL_SS_TDS_FIELD_MASS_NOT_ONE:{err:.6g}")
    cdf = np.cumsum(mass, axis=0)
    below = cdf - mass
    max_world_score = np.max(np.where(mass > 1e-14, np.arange(max_score + 1)[:, None], -1), axis=0)

    def threshold(frac: float) -> np.ndarray:
        k = max(1, int(math.ceil(field_size * frac)))
        q = max(0.0, 1.0 - k / field_size)
        return np.argmax(cdf >= q, axis=0).astype(np.uint8)

    t001 = threshold(0.001); t01 = threshold(0.01)
    fields = [
        "LINEUP_ID","UTIL1","UTIL2","UTIL3","PLAYERS","ROUTE","BRANCH","BIRTH_LANES","CALIBRATION_QUALIFIED_BIRTH",
        "MC_WIN_RATE","FIRST_PLACE_SHARE_EV","MC_TOP_0_1_RATE","MC_TOP_1_RATE","MC_P95","MC_P99","MC_CVAR99","MC_MEAN","MC_TRIALS",
        "P_SCORE_GE_2","P_SCORE_GE_3","P_SCORE_GE_4","P_ANY_PLAYER_2PLUS_TD","WORLD_COVERAGE","WORLD_COVERAGE_COUNT",
        "EXPECTED_DUPLICATES","P_UNIQUE","OWNERSHIP_PRODUCT","FIELD_MODEL_RELIABILITY","TD_MARKET_SUPPORT","RED_ZONE_SUPPORT",
        "TD_LAMBDA_SUM","STRATEGY_SCORE","CURRENT_SELECTOR_SCORE","CURRENT_SELECTOR_RANK","CURRENT_SELECTOR_SELECTED","FIELD_SIZE","SELECTION_LANE",
    ]
    rank_buffer: list[tuple[float,str,dict[str,Any]]] = []
    for lineup_counter, tri in enumerate(candidates, start=1):
        ids = np.asarray(tri, dtype=np.int32)
        lp = float(np.prod(w[ids]) / z)
        svec = counts[ids].sum(axis=0).astype(np.int16)
        p_leq = cdf[svec, np.arange(trials)]; p_below = below[svec, np.arange(trials)]; p_equal = mass[svec, np.arange(trials)]
        tied_first = np.exp((field_size - 1) * np.log(np.clip(p_leq, 1e-300, 1.0)))
        share = np.empty(trials, dtype=np.float64); nz = p_equal > 1e-15
        share[~nz] = tied_first[~nz]
        if nz.any():
            aa = np.power(np.clip(p_leq[nz],0.0,1.0),field_size); bb = np.power(np.clip(p_below[nz],0.0,1.0),field_size)
            share[nz] = (aa-bb)/(field_size*p_equal[nz])
        p95=float(np.quantile(svec,0.95,method="higher")); p99=float(np.quantile(svec,0.99,method="higher"))
        tail=svec[svec>=p99]; cvar=float(tail.mean()) if len(tail) else p99
        expdup=float(field_size*lp)
        names=[str(df.at[int(i),"PLAYER"]) for i in ids]; pos=[str(df.at[int(i),"POS"]) for i in ids]; teams=[str(df.at[int(i),"TEAM"]) for i in ids]
        market=float(np.mean(df.loc[ids,"TD_MARKET_SUPPORT"].to_numpy(float))); rz=float(np.mean(df.loc[ids,"RED_ZONE_SUPPORT"].to_numpy(float)))
        ownprod=float(np.prod(target_own[ids])); win=float(tied_first.mean()); share_ev=float(share.mean())
        top001=float((svec>=t001).mean()); top01=float((svec>=t01).mean()); world_cov=float((svec==max_world_score).mean())
        strategy=5.0*share_ev+2.2*win+1.8*top001+0.55*top01+0.18*p99+0.12*cvar+0.12*world_cov+0.08*rz-0.03*math.log1p(expdup)
        lid=f"NFL_SS_TDS_{lineup_counter:07d}"
        row={
            "LINEUP_ID":lid,"UTIL1":names[0],"UTIL2":names[1],"UTIL3":names[2],"PLAYERS":"|".join(names),"ROUTE":"-".join(sorted(pos)),
            "BRANCH":f"TEAMS_{len(set(teams))}","BIRTH_LANES":"|".join(sorted(birth_lanes[tri])),"CALIBRATION_QUALIFIED_BIRTH":1,
            "MC_WIN_RATE":win,"FIRST_PLACE_SHARE_EV":share_ev,"MC_TOP_0_1_RATE":top001,"MC_TOP_1_RATE":top01,"MC_P95":p95,"MC_P99":p99,
            "MC_CVAR99":cvar,"MC_MEAN":float(svec.mean()),"MC_TRIALS":trials,"P_SCORE_GE_2":float((svec>=2).mean()),"P_SCORE_GE_3":float((svec>=3).mean()),
            "P_SCORE_GE_4":float((svec>=4).mean()),"P_ANY_PLAYER_2PLUS_TD":float((counts[ids]>=2).any(axis=0).mean()),"WORLD_COVERAGE":world_cov,
            "WORLD_COVERAGE_COUNT":int((svec==max_world_score).sum()),"EXPECTED_DUPLICATES":expdup,"P_UNIQUE":float(math.exp(-expdup)),
            "OWNERSHIP_PRODUCT":ownprod,"FIELD_MODEL_RELIABILITY":1.0 if own_error<1e-6 else 0.0,"TD_MARKET_SUPPORT":market,"RED_ZONE_SUPPORT":rz,
            "TD_LAMBDA_SUM":float(df.loc[ids,"TD_LAMBDA"].sum()),"STRATEGY_SCORE":strategy,"CURRENT_SELECTOR_SCORE":strategy,"CURRENT_SELECTOR_RANK":0,
            "CURRENT_SELECTOR_SELECTED":0,"FIELD_SIZE":field_size,"SELECTION_LANE":"FIELD_RELATIVE_TD_TROPHY",
        }
        rank_buffer.append((strategy,lid,row))

    rank_buffer.sort(key=lambda x:(-x[0],x[1]))
    ranks={lid:i+1 for i,(_,lid,_) in enumerate(rank_buffer)}; selected={lid for _,lid,_ in rank_buffer[:min(10,len(rank_buffer))]}
    tmp=output.with_suffix(output.suffix+".tmp")
    with tmp.open("w",encoding="utf-8",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader()
        for _,lid,row in sorted(rank_buffer,key=lambda x:int(x[1].rsplit("_",1)[1])):
            row["CURRENT_SELECTOR_RANK"]=ranks[lid]; row["CURRENT_SELECTOR_SELECTED"]=int(lid in selected); writer.writerow(row)
    os.replace(tmp,output)
    native=[dict(x[2]) for x in rank_buffer[:min(10,len(rank_buffer))]]
    receipt={
        **birth_receipt,
        "OWNERSHIP_TARGET_MASS":float(target_own.sum()),"OWNERSHIP_TARGET_MAX":float(target_own.max()),
        "OWNERSHIP_MARGINAL_SOLVE_MAX_ABS_ERROR":own_error,
        "FIELD_LINEUP_MODEL":"EXACT_WEIGHTED_3_OF_N_SCORE_DP_NO_LINEUP_ENUMERATION",
        "PROVIDER_RST_AUTHORITY":False,"FIELD_SCORE_MASS_MAX_ABS_ERROR":err,"MAX_WORLD_SCORE":int(max_world_score.max()),
        "TOP_0_1_FIELD_SEATS":max(1,int(math.ceil(field_size*0.001))),"TOP_1_FIELD_SEATS":max(1,int(math.ceil(field_size*0.01))),
    }
    return receipt,pd.DataFrame(native)
