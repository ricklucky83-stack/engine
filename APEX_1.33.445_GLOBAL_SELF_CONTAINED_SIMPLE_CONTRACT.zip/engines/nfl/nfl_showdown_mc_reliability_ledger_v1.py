from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

import numpy as np

PATCH_ID = "NFL_SD_MC_RELIABILITY_LEDGER_v1"
SCHEMA_VERSION = "1.0"
REQUIRED_METRICS = (
    "win_count", "top0050_count", "top0100_count", "top01_count", "top10_count", "trials",
    "win_rate", "top0050_rate", "top0100_rate", "top01_rate", "top10_rate",
    "p95", "p99",
)
OPTIONAL_METRICS = (
    "expected_rank", "median_rank", "rank_p90", "pairwise_strength", "world_breadth", "rank_stability",
    "top01_lcb", "top01_ucb", "top0100_lcb", "top0100_ucb", "top0050_lcb", "top0050_ucb",
)
OPTIONAL_PMETA = (
    "salary", "score", "family", "macro", "same_cpt_team", "qb_count", "dst_count", "k_count", "rb_count",
    "pass_count", "skill_count", "phase2_common_world_primary_occurrence", "phase2_common_world_secondary_occurrence",
)


def _sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _array_hash(a: np.ndarray) -> str:
    x = np.ascontiguousarray(a)
    return hashlib.sha256(x.view(np.uint8)).hexdigest()


def freeze_prelock_surface(
    rows: np.ndarray,
    pmeta: Mapping[str, np.ndarray],
    metrics: Mapping[str, np.ndarray],
    cal: Any,
    *,
    field_size: int,
    seed: int,
    execution_id: str,
    output_path: str | Path,
    metadata_path: str | Path | None = None,
    public_field_source_hash: str = "",
) -> dict[str, Any]:
    """Persist the complete prelock Phase-2 MC surface without postlock truth.

    This is an evidence artifact only. It does not mutate MC metrics, Phase-2
    membership, selector membership, or terminal order.
    """
    rows = np.asarray(rows, dtype=np.int32)
    if rows.ndim != 2 or rows.shape[1] != 6 or len(rows) <= 0:
        raise RuntimeError("RUN_INVALID:NFL_SD_MC_RELIABILITY_SURFACE_ROWS")
    n = len(rows)
    arrays: dict[str, np.ndarray] = {"rows": rows}
    for key in REQUIRED_METRICS:
        if key not in metrics:
            raise RuntimeError(f"RUN_INVALID:NFL_SD_MC_RELIABILITY_MISSING_METRIC:{key}")
        a = np.asarray(metrics[key])
        if len(a) != n:
            raise RuntimeError(f"RUN_INVALID:NFL_SD_MC_RELIABILITY_METRIC_LENGTH:{key}")
        arrays[f"metric__{key}"] = a
    for key in OPTIONAL_METRICS:
        if key in metrics:
            a = np.asarray(metrics[key])
            if len(a) == n:
                arrays[f"metric__{key}"] = a
    for key in OPTIONAL_PMETA:
        if key in pmeta:
            a = np.asarray(pmeta[key])
            if len(a) == n:
                arrays[f"pmeta__{key}"] = a

    ids = np.asarray(getattr(cal, "ids"), dtype=str)
    names = np.asarray(cal.frame["PLAYER"].astype(str).tolist(), dtype=str)
    pos = np.asarray(cal.pos, dtype=str)
    team = np.asarray(cal.team, dtype=str)
    if not (len(ids) == len(names) == len(pos) == len(team)):
        raise RuntimeError("RUN_INVALID:NFL_SD_MC_RELIABILITY_PLAYER_MAP_LENGTH")
    arrays.update({"player_ids": ids, "player_names": names, "player_pos": pos, "player_team": team})

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    np.savez(out, **arrays)
    sha = _sha256_file(out)
    phase2_hash = _array_hash(rows)
    meta = {
        "PATCH_ID": PATCH_ID,
        "SCHEMA_VERSION": SCHEMA_VERSION,
        "SPORT": "NFL",
        "MODE": "SHOWDOWN",
        "EXECUTION_ID": str(execution_id),
        "FIELD_SIZE": int(field_size),
        "SEED": int(seed),
        "ROWS": int(n),
        "PHASE2_SHA256": phase2_hash,
        "PUBLIC_FIELD_SOURCE_SHA256": str(public_field_source_hash or ""),
        "SURFACE_SHA256": sha,
        "SURFACE_FILE": str(out),
        "PRELOCK_SURFACE_FROZEN": True,
        "SAME_SLATE_POSTLOCK_OUTCOME_PRESENT": False,
        "POSTLOCK_FORWARD_INPUT_USED": False,
        "SELECTOR_MEMBERSHIP_MUTATION": False,
        "TERMINAL_ORDER_MUTATION": False,
        "MC_PARAMETER_MUTATION": False,
        "FUTURE_CALIBRATION_ELIGIBLE_AFTER_POSTLOCK_GRADING": True,
    }
    mp = Path(metadata_path) if metadata_path is not None else out.with_suffix(out.suffix + ".json")
    mp.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    meta["METADATA_FILE"] = str(mp)
    meta["METADATA_SHA256"] = _sha256_file(mp)
    return meta


def read_surface(path: str | Path, expected_sha256: str | None = None) -> dict[str, np.ndarray]:
    p = Path(path)
    if expected_sha256 is not None and _sha256_file(p) != str(expected_sha256):
        raise RuntimeError("RUN_INVALID:NFL_SD_MC_RELIABILITY_SURFACE_HASH_MISMATCH")
    with np.load(p, allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def score_rows_from_actual_points(rows: np.ndarray, actual_points: np.ndarray) -> np.ndarray:
    rows = np.asarray(rows, dtype=np.int32)
    pts = np.asarray(actual_points, dtype=np.float64)
    if rows.ndim != 2 or rows.shape[1] != 6:
        raise RuntimeError("RUN_INVALID:NFL_SD_MC_RELIABILITY_GRADE_ROWS")
    if rows.size and int(rows.max()) >= len(pts):
        raise RuntimeError("RUN_INVALID:NFL_SD_MC_RELIABILITY_ACTUAL_VECTOR_LENGTH")
    return 1.5 * pts[rows[:, 0]] + pts[rows[:, 1:]].sum(axis=1)


def _balanced_brier(p: np.ndarray, y: np.ndarray) -> float | None:
    pos = y == 1
    neg = ~pos
    if not np.any(pos) or not np.any(neg):
        return None
    return float(0.5 * np.mean((p[pos] - 1.0) ** 2) + 0.5 * np.mean(p[neg] ** 2))


def _balanced_logloss(p: np.ndarray, y: np.ndarray) -> float | None:
    pos = y == 1
    neg = ~pos
    if not np.any(pos) or not np.any(neg):
        return None
    q = np.clip(p, 1e-9, 1.0 - 1e-9)
    return float(0.5 * np.mean(-np.log(q[pos])) + 0.5 * np.mean(-np.log(1.0 - q[neg])))


def grade_surface(
    surface: Mapping[str, np.ndarray],
    actual_points: np.ndarray,
    actual_thresholds: Mapping[str, float],
) -> dict[str, Any]:
    """Postlock diagnostic grade. Output is evaluation-only for the source slate."""
    rows = np.asarray(surface["rows"], dtype=np.int32)
    actual_scores = score_rows_from_actual_points(rows, actual_points)
    metric_map = {
        "win": "metric__win_rate",
        "top0050": "metric__top0050_rate",
        "top0100": "metric__top0100_rate",
        "top01": "metric__top01_rate",
    }
    out: dict[str, Any] = {
        "PATCH_ID": PATCH_ID,
        "ROWS": int(len(rows)),
        "POSTLOCK_EVALUATION_ONLY": True,
        "FORWARD_INPUT_TO_SOURCE_SLATE": False,
        "METRICS": {},
    }
    for label, key in metric_map.items():
        if label not in actual_thresholds:
            continue
        p = np.asarray(surface[key], dtype=np.float64)
        y = (actual_scores >= float(actual_thresholds[label])).astype(np.uint8)
        out["METRICS"][label] = {
            "ACTUAL_THRESHOLD": float(actual_thresholds[label]),
            "POSITIVE_ROWS": int(y.sum()),
            "ACTUAL_RATE": float(y.mean()),
            "MEAN_PREDICTED_RATE": float(p.mean()),
            "BRIER": float(np.mean((p - y) ** 2)),
            "BALANCED_BRIER": _balanced_brier(p, y),
            "BALANCED_LOG_LOSS": _balanced_logloss(p, y),
            "NONZERO_PREDICTED_ROWS": int(np.count_nonzero(p > 0)),
            "MAX_PREDICTED_RATE": float(p.max(initial=0.0)),
        }
    return out
