from __future__ import annotations

import collections
import heapq
import itertools
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import numpy as np

try:
    from numba import njit, prange
except Exception as exc:  # production image is expected to provide numba
    raise RuntimeError(f"RUN_INVALID:NFL_WORLD_NATIVE_NUMBA_UNAVAILABLE:{exc}")

PATCH_ID = "NFL_CLASSIC_WORLD_NATIVE_CHAMPIONSHIP_BIRTH_v1"
FIELD_MODEL_ID = "NFL_CLASSIC_INDEPENDENT_PUBLIC_FIELD_v1"


@njit(cache=True)
def _component_dp(scores, salaries, idxs, maxk, maxsal=500):
    neg = -1e30
    dp = np.full((maxk + 1, maxsal + 1), neg, np.float32)
    picks = np.full((maxk + 1, maxsal + 1, maxk), -1, np.int16)
    dp[0, 0] = 0.0
    for z in range(len(idxs)):
        gi = int(idxs[z]); sal = int(salaries[gi]); val = float(scores[gi])
        if sal > maxsal:
            continue
        for c in range(maxk, 0, -1):
            for s in range(maxsal - sal, -1, -1):
                prev = dp[c - 1, s]
                if prev <= neg / 2:
                    continue
                nv = prev + val; ns = s + sal
                if nv > dp[c, ns]:
                    dp[c, ns] = nv
                    for j in range(c - 1):
                        picks[c, ns, j] = picks[c - 1, s, j]
                    picks[c, ns, c - 1] = gi
    return dp, picks


@njit(cache=True)
def _merge_component(prev, prev_parts, comp, comp_slot, maxsal=500):
    neg = -1e30
    out = np.full(maxsal + 1, neg, np.float32)
    parts = np.full((maxsal + 1, 5), -1, np.int16)
    for sa in range(maxsal + 1):
        if prev[sa] <= neg / 2:
            continue
        for sb in range(maxsal + 1 - sa):
            if comp[sb] <= neg / 2:
                continue
            ns = sa + sb; nv = prev[sa] + comp[sb]
            if nv > out[ns]:
                out[ns] = nv
                for j in range(5):
                    parts[ns, j] = prev_parts[sa, j]
                parts[ns, comp_slot] = sb
    return out, parts


@njit(cache=True)
def _one_world(scores, salaries, qb, rb, wr, te, dst):
    qdp, qp = _component_dp(scores, salaries, qb, 1)
    rdp, rp = _component_dp(scores, salaries, rb, 3)
    wdp, wp = _component_dp(scores, salaries, wr, 4)
    tdp, tp = _component_dp(scores, salaries, te, 2)
    ddp, dpick = _component_dp(scores, salaries, dst, 1)
    neg = -1e30
    best = neg; bestparts = np.full(5, -1, np.int16); bestpat = -1; bestsal = -1
    rbks = (3, 2, 2); wrks = (3, 4, 3); teks = (1, 1, 2)
    for pat in range(3):
        cur = np.full(501, neg, np.float32); parts = np.full((501, 5), -1, np.int16); cur[0] = 0.0
        cur, parts = _merge_component(cur, parts, qdp[1], 0)
        cur, parts = _merge_component(cur, parts, rdp[rbks[pat]], 1)
        cur, parts = _merge_component(cur, parts, wdp[wrks[pat]], 2)
        cur, parts = _merge_component(cur, parts, tdp[teks[pat]], 3)
        cur, parts = _merge_component(cur, parts, ddp[1], 4)
        for s in range(480, 501):
            if cur[s] > best:
                best = cur[s]; bestpat = pat; bestsal = s
                for j in range(5):
                    bestparts[j] = parts[s, j]
    row = np.full(9, -1, np.int16)
    if bestpat < 0:
        return row, best, bestsal, bestpat
    qs, rs, ws, ts, ds = [int(x) for x in bestparts]
    row[0] = qp[1, qs, 0]
    rsel = rp[rbks[bestpat], rs]; wsel = wp[wrks[bestpat], ws]; tsel = tp[teks[bestpat], ts]
    row[1] = rsel[0]; row[2] = rsel[1]
    row[3] = wsel[0]; row[4] = wsel[1]; row[5] = wsel[2]
    row[6] = tsel[0]
    if bestpat == 0:
        row[7] = rsel[2]
    elif bestpat == 1:
        row[7] = wsel[3]
    else:
        row[7] = tsel[1]
    row[8] = dpick[1, ds, 0]
    return row, best, bestsal, bestpat


@njit(cache=True, parallel=True)
def optimize_worlds(score_matrix, salaries, qb, rb, wr, te, dst):
    worlds = score_matrix.shape[1]
    rows = np.full((worlds, 9), -1, np.int16)
    vals = np.empty(worlds, np.float32); sals = np.empty(worlds, np.int16); pats = np.empty(worlds, np.int8)
    for w in prange(worlds):
        r, v, s, p = _one_world(score_matrix[:, w], salaries, qb, rb, wr, te, dst)
        rows[w] = r; vals[w] = v; sals[w] = s; pats[w] = p
    return rows, vals, sals, pats


def _optimize_worlds_chunked(score_matrix, salaries, qb, rb, wr, te, dst, *, tag: str, chunk_size: int = 100):
    """Exact optimize_worlds with durable chunk checkpoints; preserves all worlds and order."""
    worlds=int(score_matrix.shape[1])
    base=Path(os.environ.get("APEX_RESUMABLE_RUN_ROOT") or "/mnt/data")/"nfl_world_birth_chunks"
    base.mkdir(parents=True,exist_ok=True)
    parts=[]
    for start in range(0,worlds,int(chunk_size)):
        end=min(worlds,start+int(chunk_size)); fp=base/f"{tag}_{start:06d}_{end:06d}.npy"
        rows=None
        if fp.exists():
            rows=np.load(fp,allow_pickle=False)
            if rows.shape!=(end-start,9):
                fp.unlink(missing_ok=True); rows=None
        if rows is None:
            rows,_,_,_=optimize_worlds(score_matrix[:,start:end],salaries,qb,rb,wr,te,dst)
            tmp=fp.with_suffix('.tmp.npy'); np.save(tmp,rows.astype(np.int32),allow_pickle=False); os.replace(tmp,fp)
        parts.append(np.asarray(rows,dtype=np.int32))
    return np.vstack(parts) if parts else np.empty((0,9),dtype=np.int32)


def _position_indices(cal: Any) -> dict[str, np.ndarray]:
    return {p: np.flatnonzero(cal.pos == p).astype(np.int16) for p in ("QB", "RB", "WR", "TE", "DST")}


def _unique_rows(parts: list[np.ndarray]) -> np.ndarray:
    good = [np.asarray(x, dtype=np.int32) for x in parts if x is not None and len(x)]
    if not good:
        return np.empty((0, 9), dtype=np.int32)
    arr = np.vstack(good).astype(np.int32)
    _, first = np.unique(arr, axis=0, return_index=True)
    return arr[np.sort(first)]


def discover_world_rows(cal: Any, simulate_players_fn: Callable[..., np.ndarray], pct_fn: Callable[[np.ndarray], np.ndarray], seed: int, worlds: int = 5000) -> tuple[np.ndarray, dict[str, Any]]:
    """Birth legal lineups by solving the exact DK roster problem inside correlated football worlds."""
    worlds = max(800, int(worlds))
    base = simulate_players_fn({"mu": cal.mu, "sigma": cal.sigma, "pos": cal.pos, "team": cal.team, "opp": cal.opp, "game": cal.game}, worlds, seed ^ 0xD15C0)
    raw = cal.frame["FPTS"].to_numpy(np.float32)
    market = cal.frame.get("MARKET_OPPORTUNITY").to_numpy(np.float32)
    market_pts = ((market - .5) * 12.0).astype(np.float32)
    salaries = (cal.salary // 100).astype(np.int16); ix = _position_indices(cal)
    # compile once on a one-world slice
    optimize_worlds(base[:, :1].astype(np.float32), salaries, ix["QB"], ix["RB"], ix["WR"], ix["TE"], ix["DST"])
    lanes = (
        ("TAIL", 1.00, 0.00, 0.00),
        ("TAIL75_PROJ25", .75, .25, 0.00),
        ("TAIL60_PROJ40", .60, .40, 0.00),
        ("TAIL72_PROJ20_MARKET08", .72, .20, .08),
        ("TAIL55_PROJ35_MARKET10", .55, .35, .10),
    )
    parts: list[np.ndarray] = []
    lane_counts: dict[str, int] = {}
    for name, a, b, c in lanes:
        score = (a * base + b * raw[:, None] + c * market_pts[:, None]).astype(np.float32)
        rows = _optimize_worlds_chunked(score, salaries, ix["QB"], ix["RB"], ix["WR"], ix["TE"], ix["DST"], tag=f"world_{int(seed)}_{int(worlds)}_{name}")
        parts.append(rows.astype(np.int32)); lane_counts[name] = int(len(np.unique(rows, axis=0)))
    out = _unique_rows(parts)
    return out, {"PATCH_ID": PATCH_ID, "WORLD_TRIALS_PER_LANE": worlds, "LANES": lane_counts, "WORLD_NATIVE_UNIQUE_ROWS": int(len(out))}


def discover_quality_rows(cal: Any, seed: int, worlds: int = 5000) -> tuple[np.ndarray, dict[str, Any]]:
    """Fast exact-roster perturb-and-optimize lanes for strong baseline lineup quality."""
    worlds = max(800, int(worlds))
    raw = cal.frame["FPTS"].to_numpy(np.float32)
    p99 = np.asarray(cal.p99, dtype=np.float32)
    market = cal.frame.get("MARKET_OPPORTUNITY").to_numpy(np.float32)
    role = np.asarray(cal.strategy.opportunity_score, dtype=np.float32)
    market_pts = ((market - .5) * 8.0).astype(np.float32)
    salaries = (cal.salary // 100).astype(np.int16); ix = _position_indices(cal)
    rng = np.random.default_rng(int(seed) ^ 0xA117E)
    lanes = (
        ("RAW_LOW_TEMP", raw, .85),
        ("RAW_TAIL_BLEND", .58 * raw + .42 * p99, 1.05),
        ("RAW_MARKET_ROLE", .72 * raw + .12 * p99 + .10 * market_pts + .06 * role, 1.00),
    )
    parts = []; counts = {}
    for name, base, temp in lanes:
        score = np.asarray(base, dtype=np.float32)[:, None] + float(temp) * rng.gumbel(size=(len(cal.frame), worlds)).astype(np.float32)
        rows = _optimize_worlds_chunked(score, salaries, ix["QB"], ix["RB"], ix["WR"], ix["TE"], ix["DST"], tag=f"quality_{int(seed)}_{int(worlds)}_{name}")
        parts.append(rows.astype(np.int32)); counts[name] = int(len(np.unique(rows, axis=0)))
    out = _unique_rows(parts)
    return out, {"QUALITY_WORLD_TRIALS_PER_LANE": worlds, "QUALITY_LANES": counts, "QUALITY_UNIQUE_ROWS": int(len(out))}


def generate_independent_public_field(cal: Any, seed: int, field_size: int) -> tuple[np.ndarray, dict[str, Any]]:
    """Generate the exact requested opponent-field size in durable chunks."""
    n=int(field_size); own=np.clip(np.asarray(cal.ownership,dtype=float),.0005,.98)
    role=np.asarray(cal.strategy.opportunity_score,dtype=float); salary_k=np.asarray(cal.salary,dtype=float)/1000.0
    temperature=.62; pass_bonus=1.50; bring_bonus=.65; salary_weight=.18
    base=(np.log(own)+.04*role+salary_weight*salary_k).astype(np.float32)
    salaries=(cal.salary//100).astype(np.int16); ix=_position_indices(cal); qbs=ix["QB"]
    qprob=own[qbs]/own[qbs].sum()
    cache=Path(os.environ.get("APEX_RESUMABLE_RUN_ROOT") or "/mnt/data")/"nfl_public_field_chunks"
    cache.mkdir(parents=True,exist_ok=True)
    chunk_size=5000; parts=[]
    probe=np.asarray(base,dtype=np.float32)[:,None]
    optimize_worlds(probe,salaries,ix["QB"],ix["RB"],ix["WR"],ix["TE"],ix["DST"])
    for start in range(0,n,chunk_size):
        end=min(n,start+chunk_size); m=end-start; fp=cache/f"field_{int(seed)}_{int(n)}_{start:06d}_{end:06d}.npy"
        if fp.exists():
            rows=np.load(fp,allow_pickle=False)
            if rows.shape==(m,9):
                parts.append(np.asarray(rows,dtype=np.int32)); continue
            fp.unlink(missing_ok=True)
        rng=np.random.default_rng((int(seed)^0xF13DCAFE)+104729*(start//chunk_size))
        sampled_qb=rng.choice(qbs,size=m,p=qprob)
        util=base[:,None]+temperature*rng.gumbel(size=(len(cal.frame),m)).astype(np.float32)
        for q in qbs:
            cols=np.flatnonzero(sampled_qb==q)
            if not len(cols): continue
            qi=int(q); util[qi,cols]+=1000.0; qt=str(cal.team[qi]); qo=str(cal.opp[qi])
            pc=np.flatnonzero((cal.team==qt)&np.isin(cal.pos,["WR","TE"]))
            br=np.flatnonzero((cal.team==qo)&np.isin(cal.pos,["RB","WR","TE"]))
            util[np.ix_(pc,cols)]+=pass_bonus; util[np.ix_(br,cols)]+=bring_bonus
        rows,_,_,_=optimize_worlds(util,salaries,ix["QB"],ix["RB"],ix["WR"],ix["TE"],ix["DST"])
        rows=rows.astype(np.int32); tmp=fp.with_suffix('.tmp.npy'); np.save(tmp,rows,allow_pickle=False); os.replace(tmp,fp); parts.append(rows)
    rows=np.vstack(parts).astype(np.int32) if parts else np.empty((0,9),dtype=np.int32)
    return rows,{"FIELD_MODEL_ID":FIELD_MODEL_ID,"FIELD_SIZE":int(n),"TEMPERATURE":temperature,"QB_PASS_STACK_BONUS":pass_bonus,"BRINGBACK_BONUS":bring_bonus,"SALARY_UTILITY_WEIGHT":salary_weight,"UNIQUE_FIELD_LINEUPS":int(len(np.unique(rows,axis=0))),"CHUNK_SIZE":int(chunk_size),"CHUNK_COUNT":int(math.ceil(n/chunk_size)),"CHUNK_NATIVE_RESUME":True}


def _core_rows(world_rows: np.ndarray, cal: Any) -> dict[tuple[int, int, int], list[np.ndarray]]:
    out: dict[tuple[int, int, int], list[np.ndarray]] = collections.defaultdict(list)
    for rr in world_rows:
        r = np.asarray(rr, dtype=np.int32); qb = int(r[0]); qt = str(cal.team[qb]); qo = str(cal.opp[qb])
        pcs = [int(i) for i in r if str(cal.team[int(i)]) == qt and str(cal.pos[int(i)]) in ("WR", "TE")]
        br = [int(i) for i in r if str(cal.team[int(i)]) == qo and str(cal.pos[int(i)]) in ("RB", "WR", "TE")]
        for p in pcs:
            for b in br:
                out[(qb, p, b)].append(r)
    return out


def _kpair(a, b, k):
    if not a or not b:
        return []
    h = [(-(a[0][0] + b[0][0]), 0, 0)]; seen = {(0, 0)}; out = []
    while h and len(out) < k:
        neg, i, j = heapq.heappop(h); out.append((-neg, a[i][1] + b[j][1]))
        if i + 1 < len(a) and (i + 1, j) not in seen:
            seen.add((i + 1, j)); heapq.heappush(h, (-(a[i + 1][0] + b[j][0]), i + 1, j))
        if j + 1 < len(b) and (i, j + 1) not in seen:
            seen.add((i, j + 1)); heapq.heappush(h, (-(a[i][0] + b[j + 1][0]), i, j + 1))
    return out


def _merge_alt(old, z, k):
    v = old + z; v.sort(key=lambda x: (-x[0], x[1])); seen = set(); out = []
    for x in v:
        key = tuple(sorted(x[1]))
        if key in seen:
            continue
        seen.add(key); out.append(x)
        if len(out) >= k:
            break
    return out


def _kpair_multi(pair_lists, k):
    h = []; seen = set(); out = []
    for q, (a, b) in enumerate(pair_lists):
        if a and b:
            heapq.heappush(h, (-(a[0][0] + b[0][0]), q, 0, 0)); seen.add((q, 0, 0))
    while h and len(out) < k:
        neg, q, i, j = heapq.heappop(h); a, b = pair_lists[q]; out.append((-neg, a[i][1] + b[j][1]))
        if i + 1 < len(a) and (q, i + 1, j) not in seen:
            seen.add((q, i + 1, j)); heapq.heappush(h, (-(a[i + 1][0] + b[j][0]), q, i + 1, j))
        if j + 1 < len(b) and (q, i, j + 1) not in seen:
            seen.add((q, i, j + 1)); heapq.heappush(h, (-(a[i][0] + b[j + 1][0]), q, i, j + 1))
    return out


def recurrent_core_closure(world_rows: np.ndarray, cal: Any, pct_fn: Callable[[np.ndarray], np.ndarray], pattern_counts_fn: Callable[[int], dict[str, int]], canonical_row_fn: Callable[..., np.ndarray], max_cores: int = 140, min_frequency: int = 4, core_start: int = 0, core_end: int | None = None) -> tuple[np.ndarray, dict[str, Any]]:
    """Deterministic exact-salary k-best closure around recurrent world-discovered cores.

    A core opens its strongest observed salary + FLEX-pattern door.  The closure ranks complete
    legal lineups by raw prelock projection and does not require the exact game-concentration
    signature of the sampled world; that prevents a sampled 5-player game from deleting an
    equally valid, more distributed sibling.
    """
    core_rows = _core_rows(world_rows, cal)
    if not core_rows:
        return np.empty((0, 9), dtype=np.int32), {"RECURRENT_CORES": 0, "CLOSURE_ROWS": 0}
    raw = cal.frame["FPTS"].to_numpy(float); market = cal.frame.get("MARKET_OPPORTUNITY").to_numpy(float); p99 = np.asarray(cal.p99, float)
    cores = list(core_rows); freq = np.asarray([len(core_rows[c]) for c in cores], float)
    cr = np.asarray([raw[list(c)].sum() for c in cores]); cp = np.asarray([p99[list(c)].sum() for c in cores]); cm = np.asarray([market[list(c)].sum() for c in cores])
    score = .18 * pct_fn(freq) + .34 * pct_fn(cr) + .43 * pct_fn(cp) + .05 * pct_fn(cm)
    order = np.argsort(score)[::-1]
    admitted_all = [cores[i] for i in order if freq[i] >= min_frequency][:max_cores]
    total_admitted=len(admitted_all)
    if core_end is None: core_end=total_admitted
    admitted=admitted_all[max(0,int(core_start)):min(total_admitted,int(core_end))]
    if not admitted:
        return np.empty((0, 9), dtype=np.int32), {"RECURRENT_CORES": 0, "CLOSURE_ROWS": 0}
    keep = 220
    glob: dict[tuple[str, int], dict[int, list[tuple[float, tuple[int, ...]]]]] = {}
    for p, ks in {"RB": [1, 2, 3], "WR": [1, 2, 3], "TE": [0, 1, 2], "DST": [1]}.items():
        ix = [int(x) for x in np.flatnonzero(cal.pos == p)]
        for k in ks:
            if k == 0:
                glob[(p, k)] = {0: [(0.0, tuple())]}; continue
            d: dict[int, list[tuple[float, tuple[int, ...]]]] = {}
            for c in itertools.combinations(ix, k):
                sal = int(cal.salary[list(c)].sum()); sc = float(raw[list(c)].sum())
                d.setdefault(sal, []).append((sc, c))
            for sal, vals in d.items():
                vals.sort(key=lambda x: (-x[0], x[1])); d[sal] = vals[:keep]
            glob[(p, k)] = d

    def filt_bucket(d, core):
        cs = set(core); out = {}
        for sal, vals in d.items():
            z = [x for x in vals if not cs.intersection(x[1])]
            if z: out[sal] = z[:keep]
        return out

    adds: list[np.ndarray] = []
    closure_cache=Path(os.environ.get("APEX_RESUMABLE_RUN_ROOT") or "/mnt/data")/"nfl_core_closure_chunks"
    closure_cache.mkdir(parents=True,exist_ok=True)
    for local_core_idx, core in enumerate(admitted):
        global_core_idx=max(0,int(core_start))+int(local_core_idx)
        core_cache=closure_cache/f"core_{global_core_idx:04d}.npy"
        if core_cache.exists():
            cached=np.load(core_cache,allow_pickle=False)
            if cached.ndim==2 and cached.shape[1]==9:
                adds.extend(np.asarray(cached,dtype=np.int32)); continue
        core_adds=[]
        obsrows = core_rows[core]; freq_here=len(obsrows)
        reserve_per_core = 6_000 if freq_here <= 8 else 2_500
        exact_k = reserve_per_core + 500
        core = tuple(map(int, core)); core_sal = int(cal.salary[list(core)].sum())
        door_count = collections.Counter()
        for r in obsrows:
            pos = cal.pos[r]; pat = 0 if int((pos == "RB").sum()) == 3 else (1 if int((pos == "WR").sum()) == 4 else 2)
            door_count[(int(cal.salary[r].sum()), pat)] += 1
        # strongest door; ties prefer full salary and the standard 3-RB pattern before alternatives.
        door = sorted(door_count.items(), key=lambda kv: (-kv[1], -kv[0][0], kv[0][1], kv[0]))[0][0]
        target_salary, pat = door
        targetc = pattern_counts_fn(pat); have = {p: sum(str(cal.pos[i]) == p for i in core) for p in targetc}; need = {p: targetc[p] - have[p] for p in targetc}
        if any(v < 0 for v in need.values()) or need["WR"] > 3:
            continue
        comp = {p: filt_bucket(glob[(p, need[p])], core) for p in ("RB", "WR", "TE", "DST")}
        left: dict[int, list] = {}; right: dict[int, list] = {}
        for sa, la in comp["RB"].items():
            for sb, lb in comp["TE"].items():
                left[sa + sb] = _merge_alt(left.get(sa + sb, []), _kpair(la, lb, keep), keep)
        for sa, la in comp["WR"].items():
            for sb, lb in comp["DST"].items():
                right[sa + sb] = _merge_alt(right.get(sa + sb, []), _kpair(la, lb, keep), keep)
        remsal = target_salary - core_sal; pairs = []
        for sl, ll in left.items():
            rr = right.get(remsal - sl)
            if rr: pairs.append((ll, rr))
        seen = set(); kept = 0
        for _, ids in _kpair_multi(pairs, exact_k):
            full = core + ids
            if len(full) != 9 or len(set(full)) != 9: continue
            key = tuple(sorted(full))
            if key in seen: continue
            seen.add(key)
            try: row = canonical_row_fn(full, pat, cal)
            except Exception: continue
            if len(set(str(cal.team[i]) for i in row)) < 2: continue
            core_adds.append(row); kept += 1
            if kept >= reserve_per_core: break
        carr=np.vstack(core_adds).astype(np.int32) if core_adds else np.empty((0,9),dtype=np.int32)
        tmp=core_cache.with_suffix('.tmp.npy'); np.save(tmp,carr,allow_pickle=False); os.replace(tmp,core_cache)
        adds.extend(carr)
    arr = _unique_rows(adds)
    return arr, {"RECURRENT_CORES": int(len(admitted)), "RECURRENT_CORES_TOTAL": int(total_admitted), "CORE_START": int(core_start), "CORE_END": int(min(total_admitted,int(core_end))), "MIN_CORE_FREQUENCY": int(min_frequency), "CLOSURE_ROWS": int(len(arr)), "MAX_CORES": int(max_cores), "RESERVE_POLICY": "FREQ_LE8_6000__GT8_2500", "CLOSURE_POLICY": "RECURRENT_CORE_STRONGEST_SALARY_PATTERN_KBEST_RAW"}



def candidate_recurrence_features(candidate_rows: np.ndarray, world_rows: np.ndarray, cal: Any) -> dict[str, np.ndarray]:
    """Cross-world recurrence features for terminal ranking.

    Uses only prelock simulated world-optimal lineups. No postlock outcome enters these features.
    """
    rows = np.asarray(candidate_rows, dtype=np.int32)
    worlds = np.asarray(world_rows, dtype=np.int32)
    if not len(rows) or not len(worlds):
        zf = np.zeros(len(rows), dtype=np.float32)
        zi = np.zeros(len(rows), dtype=np.int16)
        return {"player_rec_sum": zf, "player_rec_min": zf.copy(), "player_rec_max": zf.copy(), "core_rec_max": zi, "core_rec_sum": zi.astype(np.int32)}
    n_players = len(cal.frame)
    counts = np.bincount(worlds.ravel(), minlength=n_players).astype(np.float64)
    player_rec = counts / float(len(worlds))
    corefreq: collections.Counter[tuple[int, int, int]] = collections.Counter()
    for rr in worlds:
        r = np.asarray(rr, dtype=np.int32)
        qb = int(r[0]); qt = str(cal.team[qb]); qo = str(cal.opp[qb])
        pcs = [int(i) for i in r if str(cal.team[int(i)]) == qt and str(cal.pos[int(i)]) in ("WR", "TE")]
        br = [int(i) for i in r if str(cal.team[int(i)]) == qo and str(cal.pos[int(i)]) in ("RB", "WR", "TE")]
        for p in pcs:
            for b in br:
                corefreq[(qb, p, b)] += 1
    pr = player_rec[rows]
    cmax = np.zeros(len(rows), dtype=np.int16)
    csum = np.zeros(len(rows), dtype=np.int32)
    for z, rr in enumerate(rows):
        qb = int(rr[0]); qt = str(cal.team[qb]); qo = str(cal.opp[qb])
        pcs = [int(i) for i in rr if str(cal.team[int(i)]) == qt and str(cal.pos[int(i)]) in ("WR", "TE")]
        br = [int(i) for i in rr if str(cal.team[int(i)]) == qo and str(cal.pos[int(i)]) in ("RB", "WR", "TE")]
        vals = [int(corefreq.get((qb, p, b), 0)) for p in pcs for b in br]
        if vals:
            cmax[z] = max(vals); csum[z] = sum(vals)
    return {
        "player_rec_sum": pr.sum(axis=1).astype(np.float32),
        "player_rec_min": pr.min(axis=1).astype(np.float32),
        "player_rec_max": pr.max(axis=1).astype(np.float32),
        "core_rec_max": cmax,
        "core_rec_sum": csum,
    }
