from __future__ import annotations

"""Guarded joint public-field model for DraftKings NFL Showdown.

This module is deliberately split into two responsibilities:
1. an executable maximum-entropy / iterative-proportional-fitting (IPF) reweighter
   for legal Showdown lineup identities; and
2. a chronology/provenance promotion gate that prevents partial or same-slate
   post-lock evidence from acquiring production authority.

The current production runtime may expose this module's status/receipt, but must not
change public-field weights until the promotion gate is satisfied by certified prior
full-field ledgers.
"""

from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
import hashlib
import json
import numpy as np

PATCH_ID = "NFL_SD_PUBLIC_FIELD_JOINT_DEPENDENCE_IPF_v1"
MIN_CERTIFIED_CONTESTS = 3
DEFAULT_TOL = 5e-5
DEFAULT_MAX_ITER = 400
EPS = 1e-12

# This is provenance only. It encodes the pre-existing historical backfill gate and
# deliberately excludes the active DEN-KC diagnostic contests from training authority.
INSTALLED_PROVENANCE = {
    "STATUS": "PRODUCTION_IDENTITY_JOINT_ACTIVE__SALARY_STRUCTURE_BLOCKED",
    "CERTIFIED_OWNERSHIP_DISTINCT_GAMES": [
        "2026-09-13__ATL__PIT", "2026-09-13__CAR__CHI",
        "2026-09-13__DET__NO", "2026-09-14__DEN__KC",
    ],
    "CERTIFIED_OWNERSHIP_DISTINCT_GAME_COUNT": 4,
    "CERTIFIED_IDENTITY_STRUCTURAL_DISTINCT_GAMES": [
        "2026-09-13__ATL__PIT", "2026-09-13__CAR__CHI", "2026-09-13__DET__NO",
    ],
    "CERTIFIED_IDENTITY_STRUCTURAL_DISTINCT_GAME_COUNT": 3,
    "CERTIFIED_SALARY_STRUCTURAL_DISTINCT_GAMES": [
        "2026-09-13__ATL__PIT", "2026-09-13__CAR__CHI",
    ],
    "CERTIFIED_SALARY_STRUCTURAL_DISTINCT_GAME_COUNT": 2,
    # Legacy structural fields remain salary-complete aliases.
    "CERTIFIED_STRUCTURAL_DISTINCT_GAMES": ["2026-09-13__ATL__PIT", "2026-09-13__CAR__CHI"],
    "CERTIFIED_STRUCTURAL_DISTINCT_GAME_COUNT": 2,
    "MIN_CERTIFIED_IDENTITY_STRUCTURAL_DISTINCT_GAMES": MIN_CERTIFIED_CONTESTS,
    "MIN_CERTIFIED_SALARY_STRUCTURAL_DISTINCT_GAMES": MIN_CERTIFIED_CONTESTS,
    "IDENTITY_JOINT_FIT": "ACTIVE_EQUAL_GAME_3_GAME_TARGETS",
    "SALARY_JOINT_FIT": "NOT_AUTHORIZED_2_OF_3",
    "SAME_CONTEST_POSTLOCK_FORWARD_INPUT": False,
    "SAME_UNDERLYING_GAME_FORWARD_INPUT": False,
    "PRODUCTION_FIELD_WEIGHT_MUTATION": True,
    "PRODUCTION_FIELD_WEIGHT_SCOPE": "IDENTITY_STRUCTURE_ONLY__NO_SALARY_LEFT_CONSTRAINTS",
}

_TARGET_PATH = Path(__file__).resolve().parents[2] / "calibration" / "nfl_showdown_public_field" / "identity_joint_targets_v1.json"



def _sha(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()


def _as_date(v: str | date | None) -> date | None:
    if v is None or v == "":
        return None
    if isinstance(v, date):
        return v
    return date.fromisoformat(str(v)[:10])


@dataclass(frozen=True)
class CertifiedContest:
    contest_id: str
    contest_date: str
    ledger_complete: bool = True
    underlying_game_id: str = ""
    identity_complete: bool | None = None
    salary_complete: bool | None = None

    @property
    def independence_key(self) -> str:
        return str(self.underlying_game_id or self.contest_id)

    @property
    def identity_certified(self) -> bool:
        return bool(self.ledger_complete if self.identity_complete is None else self.identity_complete)

    @property
    def salary_certified(self) -> bool:
        return bool(self.ledger_complete if self.salary_complete is None else self.salary_complete)


@dataclass(frozen=True)
class JointModelMetadata:
    model_id: str
    status: str
    training_contests: tuple[CertifiedContest, ...]
    fit_hash: str = ""

    @property
    def certified_contests(self) -> tuple[CertifiedContest, ...]:
        # Backwards-compatible exact/salary structural surface.
        return tuple(c for c in self.training_contests if c.salary_certified)

    def certified_for(self, scope: str) -> tuple[CertifiedContest, ...]:
        scope = str(scope).upper()
        if scope in {"IDENTITY", "IDENTITY_STRUCTURAL"}:
            return tuple(c for c in self.training_contests if c.identity_certified)
        if scope in {"SALARY", "SALARY_STRUCTURAL", "STRUCTURAL"}:
            return tuple(c for c in self.training_contests if c.salary_certified)
        raise ValueError(f"JOINT_FIELD_UNKNOWN_CERTIFICATION_SCOPE:{scope}")


@dataclass(frozen=True)
class Constraint:
    name: str
    target: float
    indicator: np.ndarray

    def normalized(self, n: int) -> "Constraint":
        x = np.asarray(self.indicator, dtype=np.float64).reshape(-1)
        if len(x) != int(n):
            raise ValueError(f"JOINT_FIELD_CONSTRAINT_LENGTH_MISMATCH:{self.name}:{len(x)}!={n}")
        if np.any(~np.isfinite(x)) or np.any(x < 0.0):
            raise ValueError(f"JOINT_FIELD_CONSTRAINT_INVALID_INDICATOR:{self.name}")
        t = float(self.target)
        if not np.isfinite(t) or t < -1e-12 or t > float(np.max(x)) + 1e-9:
            raise ValueError(f"JOINT_FIELD_CONSTRAINT_INVALID_TARGET:{self.name}:{t}")
        return Constraint(str(self.name), t, x)


def validate_production_gate(
    metadata: JointModelMetadata,
    *,
    target_contest_id: str,
    target_date: str | date | None,
    target_underlying_game_id: str = "",
    min_contests: int = MIN_CERTIFIED_CONTESTS,
    certification_scope: str = "SALARY_STRUCTURAL",
) -> dict[str, Any]:
    certified = metadata.certified_for(certification_scope)
    ids = tuple(str(c.contest_id) for c in certified)
    independence_keys = tuple(c.independence_key for c in certified)
    unique_games = set(independence_keys)
    if len(unique_games) < int(min_contests):
        raise ValueError(f"JOINT_FIELD_PRODUCTION_GATE_INSUFFICIENT_CERTIFIED_DISTINCT_GAMES:{len(unique_games)}<{int(min_contests)}")
    if str(target_contest_id) in set(ids):
        raise ValueError("JOINT_FIELD_PRODUCTION_GATE_SAME_SLATE_LEAKAGE")
    if target_underlying_game_id and str(target_underlying_game_id) in unique_games:
        raise ValueError("JOINT_FIELD_PRODUCTION_GATE_SAME_UNDERLYING_GAME_LEAKAGE")
    td = _as_date(target_date)
    if td is None:
        raise ValueError("JOINT_FIELD_PRODUCTION_GATE_TARGET_DATE_REQUIRED")
    for c in certified:
        cd = _as_date(c.contest_date)
        if cd is None:
            raise ValueError(f"JOINT_FIELD_PRODUCTION_GATE_TRAIN_DATE_MISSING:{c.contest_id}")
        if cd >= td:
            raise ValueError(f"JOINT_FIELD_PRODUCTION_GATE_NON_CHRONOLOGICAL:{c.contest_id}:{cd.isoformat()}>={td.isoformat()}")
    allowed_status = {"PRODUCTION_CERTIFIED", "PRODUCTION_IDENTITY_JOINT_ACTIVE__SALARY_STRUCTURE_BLOCKED"}
    if str(metadata.status).upper() not in allowed_status:
        raise ValueError(f"JOINT_FIELD_PRODUCTION_GATE_STATUS:{metadata.status}")
    if str(certification_scope).upper() in {"SALARY", "SALARY_STRUCTURAL", "STRUCTURAL"} and str(metadata.status).upper() != "PRODUCTION_CERTIFIED":
        raise ValueError(f"JOINT_FIELD_PRODUCTION_GATE_SALARY_SCOPE_NOT_CERTIFIED:{metadata.status}")
    return {
        "PATCH_ID": PATCH_ID,
        "GATE": "PASS",
        "MODEL_ID": metadata.model_id,
        "CERTIFIED_PRIOR_CONTESTS": list(ids),
        "CERTIFIED_PRIOR_DISTINCT_GAMES": sorted(unique_games),
        "CERTIFIED_PRIOR_COUNT": len(unique_games),
        "TARGET_CONTEST_ID": str(target_contest_id),
        "TARGET_UNDERLYING_GAME_ID": str(target_underlying_game_id),
        "TARGET_DATE": td.isoformat(),
        "FIT_HASH": str(metadata.fit_hash),
        "CERTIFICATION_SCOPE": str(certification_scope).upper(),
        "SAME_SLATE_POSTLOCK_FORWARD_INPUT": False,
        "SAME_UNDERLYING_GAME_FORWARD_INPUT": False,
    }


def base_marginal_product_weights(rows: np.ndarray, cpt_own: np.ndarray, flex_own: np.ndarray, role_score: np.ndarray | None = None) -> np.ndarray:
    rows = np.asarray(rows, dtype=np.int32)
    if rows.ndim != 2 or rows.shape[1] != 6:
        raise ValueError("JOINT_FIELD_ROWS_MUST_BE_Nx6")
    cpt = np.clip(np.asarray(cpt_own, dtype=np.float64), 0.0005, 0.65)
    flex = np.clip(np.asarray(flex_own, dtype=np.float64), 0.0005, 0.98)
    logw = np.log(cpt[rows[:, 0]]) + np.log(flex[rows[:, 1:]]).sum(axis=1)
    if role_score is not None:
        role = np.asarray(role_score, dtype=np.float64)
        logw += 0.25 * role[rows].sum(axis=1)
    logw -= float(np.max(logw))
    w = np.exp(np.clip(logw, -60.0, 0.0))
    s = float(w.sum())
    if not np.isfinite(s) or s <= 0.0:
        raise ValueError("JOINT_FIELD_BASE_WEIGHT_MASS_ZERO")
    return w / s


def player_marginal_constraints(rows: np.ndarray, cpt_targets: np.ndarray, flex_targets: np.ndarray, *, min_target: float = 2e-5) -> list[Constraint]:
    rows = np.asarray(rows, dtype=np.int32)
    cpt = np.asarray(cpt_targets, dtype=np.float64)
    flex = np.asarray(flex_targets, dtype=np.float64)
    if len(cpt) != len(flex):
        raise ValueError("JOINT_FIELD_PLAYER_MARGINAL_TARGET_LENGTH_MISMATCH")
    out: list[Constraint] = []
    for p in range(len(cpt)):
        cind = (rows[:, 0] == p).astype(np.float64)
        find = (rows[:, 1:] == p).any(axis=1).astype(np.float64)
        # Impossible targets are not silently imposed. A player absent from the legal
        # candidate universe must remain absent and be surfaced through the receipt.
        if cind.any() and float(cpt[p]) >= min_target:
            out.append(Constraint(f"CPT_PLAYER_{p}", float(cpt[p]), cind))
        if find.any() and float(flex[p]) >= min_target:
            out.append(Constraint(f"FLEX_PLAYER_{p}", float(flex[p]), find))
    return out


def lineup_structural_features(rows: np.ndarray, *, team: Sequence[str], salary: Sequence[float], position: Sequence[str], team_total: Sequence[float] | None = None) -> dict[str, np.ndarray]:
    """Player-name-blind structural features for conditional field calibration."""
    rows = np.asarray(rows, dtype=np.int32)
    team = np.asarray(team, dtype=object)
    sal = np.asarray(salary, dtype=np.float64)
    pos = np.asarray(position, dtype=object)
    lineup_salary = np.floor(1.5 * sal[rows[:, 0]] + 1e-9) + sal[rows[:, 1:]].sum(axis=1)
    salary_left = 50_000.0 - lineup_salary
    teams = team[rows]
    cpt_team = teams[:, 0]
    same = (teams == cpt_team[:, None]).sum(axis=1)
    max_team = np.maximum(same, 6 - same)
    positions = pos[rows]
    qb_count = (positions == "QB").sum(axis=1)
    rb_count = (positions == "RB").sum(axis=1)
    dst_count = (positions == "DST").sum(axis=1)
    k_count = (positions == "K").sum(axis=1)
    cpt_pos = positions[:, 0]
    out = {
        "SALARY_LEFT": salary_left.astype(np.float64),
        "SALARY_LEFT_LE_500": (salary_left <= 500).astype(np.float64),
        "SALARY_LEFT_LE_1000": (salary_left <= 1000).astype(np.float64),
        "SALARY_LEFT_1001_2500": ((salary_left > 1000) & (salary_left <= 2500)).astype(np.float64),
        "SALARY_LEFT_GT_2500": (salary_left > 2500).astype(np.float64),
        "TEAM_SPLIT_3_3": (max_team == 3).astype(np.float64),
        "TEAM_SPLIT_4_2": (max_team == 4).astype(np.float64),
        "TEAM_SPLIT_5_1": (max_team == 5).astype(np.float64),
        "CPT_SAME_TEAM_3": (same == 3).astype(np.float64),
        "CPT_SAME_TEAM_4": (same == 4).astype(np.float64),
        "CPT_SAME_TEAM_5": (same == 5).astype(np.float64),
        "QB_COUNT_2": (qb_count == 2).astype(np.float64),
        "RB_COUNT_GE2": (rb_count >= 2).astype(np.float64),
        "DST_COUNT_GE1": (dst_count >= 1).astype(np.float64),
        "K_OR_DST_COUNT_GE2": ((dst_count + k_count) >= 2).astype(np.float64),
        "CPT_QB": (cpt_pos == "QB").astype(np.float64),
        "CPT_RB": (cpt_pos == "RB").astype(np.float64),
        "CPT_WR_TE": np.isin(cpt_pos, ["WR", "TE"]).astype(np.float64),
        "CPT_DST_K": np.isin(cpt_pos, ["DST", "K"]).astype(np.float64),
    }
    same_flex = teams[:, 1:] == cpt_team[:, None]
    flex_pos = positions[:, 1:]
    passcatch = np.isin(flex_pos, ["WR", "TE"])
    cpt_qb = cpt_pos == "QB"
    cpt_wrte = np.isin(cpt_pos, ["WR", "TE"])
    same_pc_count = (same_flex & passcatch).sum(axis=1)
    out["CPT_QB_WITH_SAME_TEAM_PASSCATCHER_GE1"] = (cpt_qb & (same_pc_count >= 1)).astype(np.float64)
    out["CPT_QB_WITH_SAME_TEAM_PASSCATCHER_GE2"] = (cpt_qb & (same_pc_count >= 2)).astype(np.float64)
    out["CPT_WR_TE_WITH_SAME_TEAM_QB"] = (cpt_wrte & (same_flex & (flex_pos == "QB")).any(axis=1)).astype(np.float64)
    rb_dst = np.zeros(len(rows), dtype=bool)
    k_dst = np.zeros(len(rows), dtype=bool)
    for a in range(6):
        for b in range(a + 1, 6):
            same_team = teams[:, a] == teams[:, b]
            rb_dst |= same_team & (((positions[:, a] == "RB") & (positions[:, b] == "DST")) | ((positions[:, a] == "DST") & (positions[:, b] == "RB")))
            k_dst |= same_team & (((positions[:, a] == "K") & (positions[:, b] == "DST")) | ((positions[:, a] == "DST") & (positions[:, b] == "K")))
    out["RB_DST_SAME_TEAM_PAIR"] = rb_dst.astype(np.float64)
    out["K_DST_SAME_TEAM_PAIR"] = k_dst.astype(np.float64)
    out["CPT_QB_OPP_DST"] = (cpt_qb & ((~same_flex) & (flex_pos == "DST")).any(axis=1)).astype(np.float64)
    if team_total is not None:
        tt = np.asarray(team_total, dtype=np.float64)
        # Favorite is represented structurally as the higher implied-total team. No
        # team name is persisted in the feature key or model contract.
        cpt_is_fav = np.zeros(len(rows), dtype=np.float64)
        fav_count = np.zeros(len(rows), dtype=np.float64)
        for i, rr in enumerate(rows):
            vals = tt[rr]
            mx = float(np.max(vals))
            fav_mask = vals >= mx - 1e-9
            fav_count[i] = float(fav_mask.sum())
            cpt_is_fav[i] = float(tt[rr[0]] >= mx - 1e-9)
        out["CPT_FAVORITE_SIDE"] = cpt_is_fav
        out["FAVORITE_SIDE_5"] = (fav_count == 5).astype(np.float64)
        out["FAVORITE_SIDE_4"] = (fav_count == 4).astype(np.float64)
        out["FAVORITE_SIDE_3"] = (fav_count == 3).astype(np.float64)
    return out


def constraints_from_targets(features: Mapping[str, np.ndarray], targets: Mapping[str, float]) -> list[Constraint]:
    out: list[Constraint] = []
    for name, target in sorted(targets.items()):
        if name not in features:
            raise ValueError(f"JOINT_FIELD_UNKNOWN_STRUCTURAL_FEATURE:{name}")
        out.append(Constraint(str(name), float(target), np.asarray(features[name], dtype=np.float64)))
    return out


def rake_weights(base_weights: np.ndarray, constraints: Iterable[Constraint], *, tol: float = DEFAULT_TOL, max_iter: int = DEFAULT_MAX_ITER) -> tuple[np.ndarray, dict[str, Any]]:
    """Iterative proportional fitting / generalized raking over binary indicators.

    Each constraint controls E_w[indicator] under a probability distribution over
    legal lineup identities.  Repeated multiplicative projections give the
    maximum-entropy/KL-nearest solution to the base distribution when the target set
    is feasible.  We fail closed on non-convergence instead of silently accepting a
    distorted field.
    """
    w = np.asarray(base_weights, dtype=np.float64).reshape(-1).copy()
    if len(w) == 0 or np.any(~np.isfinite(w)) or np.any(w < 0.0) or float(w.sum()) <= 0.0:
        raise ValueError("JOINT_FIELD_INVALID_BASE_WEIGHTS")
    w /= float(w.sum())
    cs = [c.normalized(len(w)) for c in constraints]
    if not cs:
        return w, {"IPF_CONVERGED": True, "IPF_ITERATIONS": 0, "MAX_ABS_CONSTRAINT_ERROR": 0.0, "CONSTRAINT_COUNT": 0, "CONSTRAINT_ERRORS": {}}
    converged = False
    it_used = 0
    for it in range(1, int(max_iter) + 1):
        for c in cs:
            x = c.indicator
            t = float(c.target)
            # Binary IPF projection: rescale in-group vs out-group mass exactly.
            # This is stable even for t=0/1 with EPS protection.
            mask = x > 0.5
            m = float(w[mask].sum())
            if t <= EPS:
                w[mask] *= EPS / max(m, EPS)
            elif t >= 1.0 - EPS:
                w[~mask] *= EPS / max(1.0 - m, EPS)
            else:
                if m <= EPS or (1.0 - m) <= EPS:
                    raise ValueError(f"JOINT_FIELD_INFEASIBLE_CONSTRAINT:{c.name}:CURRENT={m}:TARGET={t}")
                w[mask] *= t / m
                w[~mask] *= (1.0 - t) / (1.0 - m)
            w /= float(w.sum())
        errs = {c.name: float(np.dot(w, c.indicator) - c.target) for c in cs}
        maxerr = max(abs(v) for v in errs.values())
        it_used = it
        if maxerr <= float(tol):
            converged = True
            break
    errs = {c.name: float(np.dot(w, c.indicator) - c.target) for c in cs}
    maxerr = max(abs(v) for v in errs.values()) if errs else 0.0
    receipt = {
        "IPF_CONVERGED": bool(converged),
        "IPF_ITERATIONS": int(it_used),
        "MAX_ABS_CONSTRAINT_ERROR": float(maxerr),
        "CONSTRAINT_COUNT": len(cs),
        "CONSTRAINT_ERRORS": errs,
        "WEIGHT_SHA256": hashlib.sha256(np.ascontiguousarray(w).view(np.uint8)).hexdigest(),
    }
    if not converged:
        raise ValueError(f"JOINT_FIELD_IPF_DID_NOT_CONVERGE:{maxerr}")
    return w, receipt


def load_installed_identity_targets() -> dict[str, Any]:
    if not _TARGET_PATH.exists():
        raise ValueError(f"JOINT_FIELD_IDENTITY_TARGET_FILE_MISSING:{_TARGET_PATH}")
    obj = json.loads(_TARGET_PATH.read_text(encoding="utf-8"))
    if str(obj.get("STATUS")) != "CALIBRATED_3_DISTINCT_GAMES":
        raise ValueError(f"JOINT_FIELD_IDENTITY_TARGET_STATUS:{obj.get('STATUS')}")
    targets = obj.get("IDENTITY_STRUCTURAL_TARGETS", {})
    if not isinstance(targets, dict) or not targets:
        raise ValueError("JOINT_FIELD_IDENTITY_TARGETS_EMPTY")
    if any(str(k).startswith("SALARY_") for k in targets):
        raise ValueError("JOINT_FIELD_IDENTITY_TARGETS_CONTAIN_SALARY_FEATURE")
    return obj


def _feasible_identity_constraints(features: Mapping[str, np.ndarray], targets: Mapping[str, float]) -> tuple[list[Constraint], list[str]]:
    out: list[Constraint] = []
    skipped: list[str] = []
    for name, target in sorted(targets.items()):
        if name not in features:
            skipped.append(f"{name}:FEATURE_MISSING"); continue
        x = np.asarray(features[name], dtype=np.float64)
        t = float(target)
        lo = float(np.min(x)); hi = float(np.max(x))
        if t < lo - 1e-9 or t > hi + 1e-9:
            skipped.append(f"{name}:TARGET_OUTSIDE_CURRENT_UNIVERSE_SUPPORT"); continue
        # Constants already satisfy only their own constant target; imposing them adds
        # no information and can destabilize the projection numerically.
        if abs(hi - lo) <= EPS:
            if abs(t - lo) <= 5e-4:
                skipped.append(f"{name}:CONSTANT_ALREADY_SATISFIED"); continue
            skipped.append(f"{name}:CONSTANT_UNIVERSE_MISMATCH"); continue
        out.append(Constraint(str(name), t, x))
    return out, skipped


def production_identity_joint_weights(
    rows: np.ndarray,
    cpt_own: np.ndarray,
    flex_own: np.ndarray,
    *,
    role_score: np.ndarray | None,
    team: Sequence[str],
    salary: Sequence[float],
    position: Sequence[str],
    team_total: Sequence[float] | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Apply the production-authorized non-salary structural IPF layer.

    Salary is accepted only because the shared feature extractor computes a complete
    feature dictionary. Installed targets contain no salary keys, so salary-left has
    no calibration authority until its independent 3-game gate is satisfied.
    """
    base = base_marginal_product_weights(rows, cpt_own, flex_own, role_score)
    obj = load_installed_identity_targets()
    feat = lineup_structural_features(rows, team=team, salary=salary, position=position, team_total=team_total)
    constraints, skipped = _feasible_identity_constraints(feat, obj["IDENTITY_STRUCTURAL_TARGETS"])
    if not constraints:
        return base, {
            "PATCH_ID": PATCH_ID, "STATUS": "BASE_FALLBACK_NO_FEASIBLE_IDENTITY_CONSTRAINTS",
            "PRODUCTION_FIELD_WEIGHT_MUTATION": False, "SALARY_CONSTRAINTS_APPLIED": False,
            "SKIPPED_CONSTRAINTS": skipped, "FIT_HASH": obj.get("FIT_HASH", ""),
        }
    try:
        w, ipf = rake_weights(base, constraints, tol=5e-4, max_iter=800)
        return w, {
            "PATCH_ID": PATCH_ID, "STATUS": "IDENTITY_JOINT_IPF_APPLIED",
            "PRODUCTION_FIELD_WEIGHT_MUTATION": True, "SALARY_CONSTRAINTS_APPLIED": False,
            "APPLIED_CONSTRAINT_COUNT": len(constraints), "SKIPPED_CONSTRAINTS": skipped,
            "FIT_HASH": obj.get("FIT_HASH", ""), **ipf,
        }
    except ValueError as exc:
        # Fail closed to the prior production distribution for an infeasible current
        # candidate universe. Never crash a live run or silently improvise targets.
        return base, {
            "PATCH_ID": PATCH_ID, "STATUS": "BASE_FALLBACK_IPF_INFEASIBLE",
            "PRODUCTION_FIELD_WEIGHT_MUTATION": False, "SALARY_CONSTRAINTS_APPLIED": False,
            "APPLIED_CONSTRAINT_COUNT": len(constraints), "SKIPPED_CONSTRAINTS": skipped,
            "FIT_HASH": obj.get("FIT_HASH", ""), "ERROR": str(exc),
        }


def installed_shadow_receipt() -> dict[str, Any]:
    r = dict(INSTALLED_PROVENANCE)
    r.update({
        "PATCH_ID": PATCH_ID,
        "IPF_ENGINE_IMPLEMENTED": True,
        "CONDITIONAL_FEATURES": [
            "CPT_FLEX_PLAYER_MARGINALS", "SALARY_LEFT_BUCKET", "TEAM_SPLIT",
            "CPT_TEAM_SPLIT", "CPT_ROLE", "FAVORITE_SIDE_SPLIT", "POSITION_GEOMETRY",
            "CPT_FLEX_ROLE_PAIRS", "RB_DST_SAME_TEAM", "K_DST_SAME_TEAM",
        ],
        "PROVIDER_DIRECT_AUTHORITY": False,
        "EXACT_LINEUP_DUPLICATION_SEPARATE_OUTPUT": True,
        "CURRENT_RUNTIME_WEIGHT_PATH": "IDENTITY_JOINT_IPF_WITH_FAIL_CLOSED_BASE_FALLBACK",
        "SALARY_LEFT_CALIBRATION_AUTHORIZED": False,
        "PROMOTION_GATE_SHA256": _sha(INSTALLED_PROVENANCE),
    })
    return r
