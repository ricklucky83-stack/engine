from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from .nfl_ss_yards_mode_specific_ownership_v1 import derive_shadow_ownership

PATCH_ID = "NFL_SS_YARDS_PROSPECTIVE_VALIDATION_v1"

FORBIDDEN_POSTLOCK_COLUMNS = {
    "Rank", "EntryId", "EntryName", "Points", "TimeRemaining",
    "%Drafted", "actual_ownership", "actual_yards", "contest_rank",
}


def _base_pos(v: str) -> str:
    return str(v).split("/")[0].strip().upper()


def capture_prelock_snapshot(df: pd.DataFrame, slate_id: str, path: str | Path) -> dict:
    """Write a result-blind SS YARDS ownership snapshot before lock.

    This is deliberately not a production gate and uses no pointer/hash requirement.
    """
    forbidden_present = sorted(c for c in FORBIDDEN_POSTLOCK_COLUMNS if c in df.columns)
    if forbidden_present:
        raise RuntimeError(f"RUN_INVALID:POSTLOCK_COLUMNS_PRESENT:{','.join(forbidden_present)}")

    out = derive_shadow_ownership(df)
    keep = [c for c in [
        "PLAYER", "POS", "TEAM", "OPP", "FPTS", "Ceil", "RST%", "O/U RUYD",
        "NFL_SS_YARDS_ELIGIBLE", "NFL_SS_YARDS_EXPECTED_OWNERSHIP",
        "NFL_SS_YARDS_OWNERSHIP_AUTHORITY", "NFL_SS_YARDS_OWNERSHIP_PATCH_ID",
    ] if c in out.columns]
    snap = out.loc[out["NFL_SS_YARDS_ELIGIBLE"], keep].copy()
    snap.insert(0, "SLATE_ID", str(slate_id))
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    snap.to_csv(p, index=False)
    return {
        "PATCH_ID": PATCH_ID,
        "SLATE_ID": str(slate_id),
        "ROWS": int(len(snap)),
        "OWNERSHIP_MASS_PCT": float(snap["NFL_SS_YARDS_EXPECTED_OWNERSHIP"].sum()),
        "POSTLOCK_INPUTS_USED": False,
        "POINTER_HASH_GATE": False,
        "SNAPSHOT_PATH": str(p),
    }


def _actual_ownership_from_standings(path: str | Path) -> pd.DataFrame:
    """Read the DraftKings player-summary rows embedded in contest standings exports."""
    p = Path(path)
    if p.suffix.lower() == ".zip":
        import zipfile
        with zipfile.ZipFile(p) as z:
            names = [n for n in z.namelist() if n.lower().endswith(".csv")]
            if not names:
                raise RuntimeError("RUN_INVALID:STANDINGS_ZIP_HAS_NO_CSV")
            with z.open(names[0]) as fh:
                df = pd.read_csv(fh)
    else:
        df = pd.read_csv(p)

    if "Player" not in df.columns or "%Drafted" not in df.columns:
        raise RuntimeError("RUN_INVALID:STANDINGS_MISSING_PLAYER_OWNERSHIP_ROWS")

    x = df.loc[df["Player"].notna() & df["%Drafted"].notna(), ["Player", "%Drafted"]].copy()
    if x.empty:
        raise RuntimeError("RUN_INVALID:NO_PLAYER_OWNERSHIP_ROWS")
    x["PLAYER"] = x["Player"].astype(str).str.strip()
    x["ACTUAL_OWNERSHIP"] = (
        x["%Drafted"].astype(str).str.replace("%", "", regex=False)
        .pipe(pd.to_numeric, errors="coerce")
    )
    x = x.dropna(subset=["ACTUAL_OWNERSHIP"])
    # DK exports can include CPT/UTIL rows in other formats; SS YARDS is UTIL-only.
    return x.groupby("PLAYER", as_index=False)["ACTUAL_OWNERSHIP"].max()


def evaluate_distinct_holdout(snapshot_csv: str | Path, standings_path: str | Path,
                              calibration_slate_ids: Iterable[str]) -> dict:
    snap = pd.read_csv(snapshot_csv)
    slate_ids = set(snap["SLATE_ID"].astype(str).unique())
    if len(slate_ids) != 1:
        raise RuntimeError("RUN_INVALID:SNAPSHOT_MUST_CONTAIN_ONE_SLATE")
    slate_id = next(iter(slate_ids))
    if slate_id in {str(x) for x in calibration_slate_ids}:
        raise RuntimeError("RUN_INVALID:HOLDOUT_NOT_DISTINCT_FROM_CALIBRATION")

    act = _actual_ownership_from_standings(standings_path)
    j = snap.merge(act, on="PLAYER", how="inner")
    if len(j) < 6:
        raise RuntimeError("RUN_INVALID:INSUFFICIENT_PLAYER_OVERLAP")

    pred = pd.to_numeric(j["NFL_SS_YARDS_EXPECTED_OWNERSHIP"], errors="coerce").to_numpy(float)
    actual = pd.to_numeric(j["ACTUAL_OWNERSHIP"], errors="coerce").to_numpy(float)
    raw = pd.to_numeric(j.get("RST%", pd.Series(np.nan, index=j.index)), errors="coerce").to_numpy(float)

    mae_shadow = float(np.mean(np.abs(pred - actual)))
    rmse_shadow = float(np.sqrt(np.mean((pred - actual) ** 2)))
    sp_shadow = float(pd.Series(pred).corr(pd.Series(actual), method="spearman"))

    raw_ok = np.isfinite(raw)
    if raw_ok.any():
        # Compare raw RST after preserving its native scale. This is diagnostic only.
        mae_raw = float(np.mean(np.abs(raw[raw_ok] - actual[raw_ok])))
        rmse_raw = float(np.sqrt(np.mean((raw[raw_ok] - actual[raw_ok]) ** 2)))
        sp_raw = float(pd.Series(raw[raw_ok]).corr(pd.Series(actual[raw_ok]), method="spearman"))
    else:
        mae_raw = rmse_raw = sp_raw = float("nan")

    # Independent promotion support requires material error improvement and no rank degradation.
    mae_improvement = mae_raw - mae_shadow if np.isfinite(mae_raw) else float("nan")
    promotion_support = bool(
        np.isfinite(mae_improvement) and mae_improvement >= 1.0 and
        np.isfinite(sp_shadow) and (not np.isfinite(sp_raw) or sp_shadow >= sp_raw)
    )

    return {
        "PATCH_ID": PATCH_ID,
        "SLATE_ID": slate_id,
        "DISTINCT_HOLDOUT": True,
        "MATCHED_PLAYERS": int(len(j)),
        "RAW_RST_MAE_PP": mae_raw,
        "SHADOW_MAE_PP": mae_shadow,
        "MAE_IMPROVEMENT_PP": mae_improvement,
        "RAW_RST_RMSE": rmse_raw,
        "SHADOW_RMSE": rmse_shadow,
        "RAW_RST_SPEARMAN": sp_raw,
        "SHADOW_SPEARMAN": sp_shadow,
        "PROMOTION_SUPPORT": promotion_support,
        "PRODUCTION_MUTATION": False,
    }


def write_receipt(result: dict, path: str | Path) -> None:
    Path(path).write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
