from __future__ import annotations

"""NFL Showdown terminal order adapter using the global MC-signal doctrine.

Membership is immutable. AI Hybrid protected cross-world cores are bounded front
context; inside protected and unprotected groups, order is determined by normalized
prelock evidence, never literal MC values or postlock outcomes.
"""

from typing import Any, Mapping, Sequence
import math
import numpy as np
from engines.common import apex_global_mc_signal_doctrine_v1 as doctrine

PATCH_ID = "NFL_SD_MC_SIGNAL_HYBRID_TERMINAL_ORDER_v1_CANDIDATE"
MEMBERSHIP_MUTATION = False
MAX_PROTECTED_FRONT = 3
FORBIDDEN_POSTLOCK = {
    "CONTEST_RANK","ACTUAL_RANK","FINAL_CONTEST_RANK","ACTUAL_FPTS","REALIZED_FPTS",
    "POSTLOCK_SCORE","REALIZED_SCORE","ACTUAL_SCORE","WINNING_LINEUP","TARGET_ACTUAL_SCORE",
    "VIRTUAL_CONTEST_RANK","EXACT_FIELD_RANK","ACTUAL_POINTS",
}

class NFLSDMCSignalOrderError(RuntimeError):
    pass


def _norm(s: Any) -> str:
    return str(s or "").strip().upper()


def _num(row: Mapping[str, Any], *keys: str) -> float:
    for k in keys:
        v = row.get(k)
        if v not in (None, ""):
            try:
                x = float(v)
                if math.isfinite(x):
                    return x
            except Exception:
                pass
    return float("nan")


def _truthy(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    return _norm(v) in {"1","TRUE","T","YES","Y","PROTECTED","SELECTED"}


def _id(row: Mapping[str, Any], i: int) -> str:
    for k in ("LINEUP_ID","LINEUP_INDEX","ID","RANK"):
        if row.get(k) not in (None, ""):
            return str(row[k])
    return str(i)


def order_rows(rows: Sequence[Mapping[str, Any]], *, stability_higher_is_better: bool = False) -> tuple[list[int], dict[str, Any], dict[str, np.ndarray]]:
    if not rows:
        raise NFLSDMCSignalOrderError("NFL_SD_MC_SIGNAL_EMPTY_BOARD")
    for r in rows:
        bad = sorted(FORBIDDEN_POSTLOCK.intersection({_norm(k) for k in r.keys()}))
        if bad:
            raise NFLSDMCSignalOrderError("NFL_SD_MC_SIGNAL_POSTLOCK_LEAKAGE:" + ",".join(bad))
    n = len(rows)
    a = lambda *ks: np.asarray([_num(r, *ks) for r in rows], dtype=np.float64)

    core4 = a("CROSS_WORLD_CORE4_SUPPORT","RECURRENCE","AI_CROSS_WORLD_BREADTH_PRIORITY")
    core4_secondary = a("CROSS_WORLD_CORE4_SECONDARY_SUPPORT","CORE4_SECOND")
    ptop10 = a("P_TOP10","TOP10_RATE","MC_TOP10_RATE")
    # Stable tail presence is a cross-world construct first; tail rates are only a fallback.
    stable_tail = np.nanmean(np.vstack([core4, core4_secondary, ptop10]), axis=0)

    result = doctrine.score_surface(
        cross_world_recurrence=a("RECURRENCE","CROSS_WORLD_CORE4_SUPPORT","AI_CROSS_WORLD_BREADTH_PRIORITY"),
        pairwise_strength=a("PAIRWISE_STRENGTH","AI_PAIRWISE_ORDER_STRENGTH","PAIRWISE_BEAT_PROB"),
        world_breadth=a("WORLD_BREADTH","AI_WORLD_COVERAGE_PCTL","P_TOP10"),
        rank_stability=a("RANK_STABILITY","CROSS_SEED_STABILITY","CALIBRATION_STABILITY"),
        stable_tail_presence=stable_tail,
        win=a("WIN_RATE","MC_WIN_RATE","MC_WIN_LCB"),
        top01=a("TOP01_RATE","MC_TOP_0_1_RATE","MC_TOP_0_1_LCB"),
        top1_or_top10=a("TOP10_RATE","MC_TOP10_RATE","P_TOP10"),
        p95=a("P95","MC_P95"),
        p99=a("P99","MC_P99"),
        expected_rank=a("EXPECTED_RANK","AI_EXPECTED_CONTEST_RANK","POSTERIOR_EXPECTED_RANK"),
        median_rank=a("MEDIAN_RANK","AI_MEDIAN_CONTEST_RANK","POSTERIOR_MEDIAN_RANK"),
        rank_p90=a("RANK_P90","AI_CONTEST_RANK_P90","POSTERIOR_RANK_P90"),
        structure_context=a("STRUCT_PCT","SPORT_NATIVE_ORDER_SCORE","GLOBAL_CORE_PRIORITY"),
        neighborhood_context=a("TN_BLEND","GLOBAL_TOP_NEIGHBORHOOD_SUPPORT"),
        # nfl_sd_common_world_terminal_order_v1 exposes rank std: lower is better.
        stability_higher_is_better=bool(stability_higher_is_better),
    )

    protected = np.asarray([_truthy(r.get("GLOBAL_CORE_PROTECTED")) for r in rows], dtype=bool)
    protected_idx = np.flatnonzero(protected)
    protected_sorted = protected_idx[np.argsort(-result.score[protected_idx], kind="mergesort")] if len(protected_idx) else protected_idx
    front = protected_sorted[:MAX_PROTECTED_FRONT]
    front_set = set(map(int, front.tolist()))
    remaining = np.asarray([i for i in range(n) if i not in front_set], dtype=np.int32)
    remaining = remaining[np.argsort(-result.score[remaining], kind="mergesort")]
    order = np.concatenate([front.astype(np.int32), remaining.astype(np.int32)]).tolist()
    if sorted(order) != list(range(n)):
        raise NFLSDMCSignalOrderError("NFL_SD_MC_SIGNAL_MEMBERSHIP_PERMUTATION_FAILURE")

    receipt = {
        "PATCH_ID": PATCH_ID,
        "GLOBAL_DOCTRINE_PATCH_ID": doctrine.PATCH_ID,
        "MC_METRICS_ROLE": doctrine.MC_METRICS_ROLE,
        "MEMBERSHIP_MUTATION": False,
        "PROTECTED_FRONT_LIMIT": MAX_PROTECTED_FRONT,
        "PROTECTED_FRONT_COUNT": int(len(front)),
        "PROTECTED_FRONT_IDS": [_id(rows[i], i) for i in front],
        "ORDERED_LINEUP_IDS": [_id(rows[i], i) for i in order],
        "RAW_MC_LITERAL_AUTHORITY": False,
        "POSTLOCK_INPUTS": False,
        "STABILITY_HIGHER_IS_BETTER": bool(stability_higher_is_better),
    }
    telemetry = {
        "signal_score": result.score,
        "primary_score": result.primary_score,
        "secondary_score": result.secondary_score,
        "disagreement": result.disagreement,
        **result.channels,
    }
    return order, receipt, telemetry
