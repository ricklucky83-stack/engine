"""APEX NFL SS YARDS 20-max selector repair v2.

Prelock-only structural selector:
1) full legal surface remains intact;
2) primary seats use field-relative marginal winner/top-1% coverage;
3) reserve seats cover SUPERANCHOR + DOUBLE_SECONDARY leverage worlds;
4) generic ownership never hard-prunes a prop-qualified player.

No postlock player identity or realized score is referenced by selection logic.
"""
from dataclasses import dataclass
import numpy as np

@dataclass
class SelectorConfig:
    portfolio_size: int = 20
    core_seats: int = 15
    leverage_seats: int = 5
    secondary_own_max: float = 0.20
    top01_weight: float = 3.0
    top1_weight: float = 1.0


def select_20max(lineups, player_yard_mean, player_internal_own,
                 top01_success, top1_success, q999, expected_field_copies,
                 cfg=SelectorConfig()):
    """
    Parameters
    ----------
    lineups: (L,3) integer player ids
    player_yard_mean: (P,) prelock rush+receive yard means
    player_internal_own: (P,) normalized SS-YARDS roster probabilities
    top01_success/top1_success: (L,W) boolean field-relative success events
    q999: (L,) simulated 99.9th percentile lineup yards
    expected_field_copies: (L,) expected public-field copies
    """
    L, W = top01_success.shape
    selected=[]
    remaining=set(range(L))
    cov01=np.zeros(W,dtype=bool)
    cov1=np.zeros(W,dtype=bool)

    # Core: marginal field-relative coverage, not exact-perfect recurrence.
    for _ in range(min(cfg.core_seats, cfg.portfolio_size)):
        best=None; key=None
        for j in remaining:
            new01=np.logical_and(top01_success[j], ~cov01).sum()
            new1=np.logical_and(top1_success[j], ~cov1).sum()
            k=(cfg.top01_weight*new01 + cfg.top1_weight*new1,
               new01, new1, q999[j], -expected_field_copies[j])
            if key is None or k>key:
                key=k; best=j
        selected.append(best)
        remaining.remove(best)
        cov01 |= top01_success[best]
        cov1 |= top1_success[best]

    # Leverage lane: preserve tail worlds where the dominant yard anchor succeeds
    # while TWO sub-20% secondary pieces jointly beat the public construction.
    anchor=int(np.argmax(player_yard_mean))
    leverage=[]
    for j in remaining:
        lu=lineups[j]
        if anchor not in lu:
            continue
        others=[int(x) for x in lu if int(x)!=anchor]
        if len(others)!=2 or not all(player_internal_own[x] < cfg.secondary_own_max for x in others):
            continue
        # rank by field-relative top-1%, then top-.1%, then extreme tail and duplication.
        leverage.append((top1_success[j].mean(), top01_success[j].mean(),
                         q999[j], -expected_field_copies[j], j))
    leverage.sort(reverse=True)

    for *_, j in leverage:
        if len(selected)>=cfg.portfolio_size:
            break
        selected.append(j)
        remaining.remove(j)

    # If leverage lane has too few candidates, fill by marginal coverage.
    while len(selected)<cfg.portfolio_size and remaining:
        best=max(remaining, key=lambda j:(
            np.logical_and(top01_success[j],~cov01).sum(),
            np.logical_and(top1_success[j],~cov1).sum(),
            q999[j], -expected_field_copies[j]))
        selected.append(best); remaining.remove(best)
        cov01 |= top01_success[best]; cov1 |= top1_success[best]
    return selected
