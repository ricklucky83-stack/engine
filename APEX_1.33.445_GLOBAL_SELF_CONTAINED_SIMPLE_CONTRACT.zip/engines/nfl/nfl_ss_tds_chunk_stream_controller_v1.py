#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import sys
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from engines.common import apex_terminal_ai_hybrid_selector_v6 as terminal_ai

PATCH_ID = "NFL_SS_TDS_EVENT_NATIVE_TOUCHDOWN_WORLD_v1"
ENGINE_ID = "APEX_NFL_SS_TDS_CHUNK_STREAM_RUNTIME_v1"
MODE_ID = "DK_NFL_SINGLE_STAT_TOUCHDOWNS"
SCHEMA_VERSION = "1.0.0"
ROSTER_SIZE = 3
ELIGIBLE_POSITIONS = frozenset({"RB", "WR", "TE", "FB"})
HARD_EXCLUDED_POSITIONS = frozenset({"QB", "K", "P", "LS", "DST", "DEF"})
HARD_OUT_STATUSES = frozenset({"OUT", "IR", "DNP", "REST", "CONFIRMED_OUT", "DOUBTFUL"})
PROVIDER_RST_AUTHORITY = False
EXPECTED_OWNERSHIP_MASS = 3.0
OTHER_SCORER_RESERVE_SHARE = 0.08  # unselectable QB rush / gadget / other scorer bucket
MAX_PLAYER_TDS_PER_WORLD = 6

TD_MARKET_ALIASES = (
    "1+ TD", "1+ TDS", "ANYTIME TD", "ANYTIME TDS", "ATTD", "TD%", "TD %",
    "ANYTIME TOUCHDOWN", "ANYTIME TOUCHDOWN ODDS", "TD ODDS", "SCORE TD",
)
TEAM_TOTAL_ALIASES = (
    "TM SCORE", "TEAM SCORE", "TEAM TOTAL", "IMPLIED TEAM TOTAL", "T SCORE", "T TOTAL",
)
GAME_TOTAL_ALIASES = ("O/U", "OU", "GAME TOTAL", "TOTAL")
RST_ALIASES = ("RST%", "RST %", "OWN%", "OWN %", "OWNERSHIP", "OWNERSHIP%")
SNAP_SHARE_ALIASES = ("SNAP%", "SNAP %", "SNAP SHARE", "SNAP SHARE%", "SNAPS%")
ROUTE_SHARE_ALIASES = ("ROUTE%", "ROUTE %", "ROUTE SHARE", "ROUTE SHARE%", "ROUTES%")
TARGET_SHARE_ALIASES = ("TARGET%", "TARGET %", "TARGET SHARE", "TARGET SHARE%", "TAR%", "TAR %")
CARRY_SHARE_ALIASES = ("CARRY%", "CARRY %", "CARRY SHARE", "CARRY SHARE%", "RUSH SHARE", "RUSH SHARE%")
CARRY_COUNT_ALIASES = ("CARRIES", "CAR", "RUSH ATT", "RUSH ATTEMPTS", "RUSHES")
TARGET_COUNT_ALIASES = ("TARGETS", "TAR", "TGTS", "TGT")
RZ_CARRY_ALIASES = ("RZ CARRIES", "RZ CAR", "RED ZONE CARRIES", "REDZONE CARRIES")
I10_CARRY_ALIASES = ("I10 CARRIES", "INSIDE 10 CARRIES", "CARRIES INSIDE 10", "GL CARRIES")
I5_CARRY_ALIASES = ("I5 CARRIES", "INSIDE 5 CARRIES", "CARRIES INSIDE 5", "GOAL LINE CARRIES")
RZ_TARGET_ALIASES = ("RZ TARGETS", "RZ TAR", "RED ZONE TARGETS", "REDZONE TARGETS")
EZ_TARGET_ALIASES = ("END ZONE TARGETS", "ENDZONE TARGETS", "EZ TARGETS", "EZ TAR")
STATUS_ALIASES = ("STATUS", "INJURY STATUS", "PLAYER STATUS")


def _norm(s: object) -> str:
    return " ".join(str(s or "").strip().upper().replace("_", " ").split())


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _stable_hash(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def _atomic_json(path: Path, obj: dict[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _to_num(v: object) -> float:
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return float("nan")
    s = str(v).strip().replace(",", "").replace("%", "")
    if s.upper() in {"", "-", "NAN", "NONE", "N/A", "NA"}:
        return float("nan")
    try:
        return float(s)
    except Exception:
        return float("nan")


def _market_prob(v: object) -> float:
    """Parse probability-like or American-odds TD cells; never parse a touchdown line."""
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return float("nan")
    s = str(v).strip().replace(",", "")
    if not s or s.upper() in {"-", "NAN", "NONE", "N/A", "NA"}:
        return float("nan")
    is_pct = "%" in s
    s = s.replace("%", "")
    try:
        x = float(s)
    except Exception:
        return float("nan")
    if is_pct:
        return float(np.clip(x / 100.0, 0.001, 0.995))
    # American odds are typically |x| >= 100.  Values between 1 and 100 are read as percentages.
    if x >= 100:
        return float(np.clip(100.0 / (x + 100.0), 0.001, 0.995))
    if x <= -100:
        return float(np.clip((-x) / ((-x) + 100.0), 0.001, 0.995))
    if 0.0 < x <= 1.0:
        return float(np.clip(x, 0.001, 0.995))
    if 1.0 < x <= 100.0:
        return float(np.clip(x / 100.0, 0.001, 0.995))
    return float("nan")


def _col_map(df: pd.DataFrame) -> dict[str, str]:
    return {_norm(c): c for c in df.columns}


def _first_col(cmap: dict[str, str], aliases: Iterable[str]) -> str | None:
    for a in aliases:
        c = cmap.get(_norm(a))
        if c is not None:
            return c
    return None


def _row_num(row: pd.Series, cmap: dict[str, str], aliases: Iterable[str]) -> float:
    c = _first_col(cmap, aliases)
    return _to_num(row[c]) if c else float("nan")


def _row_prob(row: pd.Series, cmap: dict[str, str], aliases: Iterable[str]) -> float:
    c = _first_col(cmap, aliases)
    return _market_prob(row[c]) if c else float("nan")


def _pct_share(x: float) -> float:
    if not math.isfinite(x):
        return 0.0
    if x > 1.0:
        x /= 100.0
    return float(np.clip(x, 0.0, 1.0))


def _position_tokens(raw: object) -> set[str]:
    s = _norm(raw).replace("/", " ").replace(",", " ").replace("-", " ")
    return {x for x in s.split() if x}


def _base_position(raw: object) -> str:
    toks = _position_tokens(raw)
    if "QB" in toks:
        return "QB"
    for p in ("RB", "WR", "TE", "FB", "K", "P", "LS", "DST", "DEF"):
        if p in toks:
            return p
    return next(iter(toks), "UNKNOWN")


def _load_role_evidence(path: str | None) -> dict[str, Any]:
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        raise RuntimeError(f"RUN_INVALID:NFL_SS_TDS_ROLE_EVIDENCE_MISSING:{p}")
    obj = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_ROLE_EVIDENCE_INVALID")
    return obj


def _dedupe_and_prepare(pool: Path, role_evidence: dict[str, Any]) -> tuple[pd.DataFrame, dict[str, Any]]:
    raw = pd.read_csv(pool)
    raw_row_count = int(len(raw))
    cmap = _col_map(raw)
    player_col = _first_col(cmap, ("PLAYER", "PLAYER NAME", "NAME"))
    pos_col = _first_col(cmap, ("POS", "POSITION"))
    team_col = _first_col(cmap, ("TEAM", "TEAM ABBR"))
    opp_col = _first_col(cmap, ("OPP", "OPPONENT"))
    if not player_col or not pos_col or not team_col:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_REQUIRED_POOL_FIELDS:PLAYER,POS,TEAM")

    raw = raw.copy()
    raw["__PLAYER"] = raw[player_col].astype(str).str.strip()
    raw = raw[raw["__PLAYER"].ne("") & raw["__PLAYER"].str.lower().ne("nan")]
    if raw.empty:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_EMPTY_POOL")

    ev_players = role_evidence.get("players", {}) if isinstance(role_evidence.get("players", {}), dict) else {}
    records: list[dict[str, Any]] = []
    qb_purge: list[str] = []
    out_purge: list[str] = []
    noneligible_purge: list[str] = []
    zero_role_purge: list[str] = []
    duplicate_rows_removed = 0

    for name, group in raw.groupby("__PLAYER", sort=False):
        duplicate_rows_removed += max(0, len(group) - 1)
        positions = {_base_position(x) for x in group[pos_col].tolist()}
        if "QB" in positions:
            qb_purge.append(name)
            continue
        pos = next((p for p in ("RB", "WR", "TE", "FB") if p in positions), next(iter(positions), "UNKNOWN"))
        if pos not in ELIGIBLE_POSITIONS:
            noneligible_purge.append(name)
            continue
        teams = [str(x).strip().upper() for x in group[team_col].tolist() if str(x).strip() and str(x).lower() != "nan"]
        if not teams or len(set(teams)) != 1:
            raise RuntimeError(f"RUN_INVALID:NFL_SS_TDS_TEAM_IDENTITY_CONFLICT:{name}")
        team = teams[0]
        opps = [] if not opp_col else [str(x).strip().upper() for x in group[opp_col].tolist() if str(x).strip() and str(x).lower() != "nan"]
        opp = opps[0] if opps else ""

        # Use the most informative duplicate row for direct pool signals, never aggregate FPTS.
        base = group.iloc[0]
        status_col = _first_col(cmap, STATUS_ALIASES)
        raw_statuses = {_norm(x) for x in group[status_col].tolist()} if status_col else set()
        ev = ev_players.get(name, {}) or {}
        ev_status = _norm(ev.get("status", ""))
        status = ev_status or next(iter(raw_statuses), "ACTIVE") or "ACTIVE"
        if status in HARD_OUT_STATUSES or any(x in HARD_OUT_STATUSES for x in raw_statuses):
            out_purge.append(name)
            continue

        def gmax(aliases: Iterable[str]) -> float:
            c = _first_col(cmap, aliases)
            if not c:
                return float("nan")
            vals = [_to_num(x) for x in group[c].tolist()]
            vals = [x for x in vals if math.isfinite(x)]
            return max(vals) if vals else float("nan")

        market_vals = []
        mc = _first_col(cmap, TD_MARKET_ALIASES)
        if mc:
            market_vals = [_market_prob(x) for x in group[mc].tolist()]
            market_vals = [x for x in market_vals if math.isfinite(x)]
        p_market = max(market_vals) if market_vals else float("nan")
        if math.isfinite(_market_prob(ev.get("anytime_td_prob"))):
            p_market = _market_prob(ev.get("anytime_td_prob"))
        elif math.isfinite(_market_prob(ev.get("anytime_td_odds"))):
            p_market = _market_prob(ev.get("anytime_td_odds"))

        def finite_ev(key: str, fallback: float) -> float:
            x = _to_num(ev.get(key)) if key in ev else fallback
            return float(x) if math.isfinite(float(x)) else 0.0

        snap = _pct_share(finite_ev("snap_share", gmax(SNAP_SHARE_ALIASES)))
        route = _pct_share(finite_ev("route_share", gmax(ROUTE_SHARE_ALIASES)))
        target_share = _pct_share(finite_ev("target_share", gmax(TARGET_SHARE_ALIASES)))
        carry_share = _pct_share(finite_ev("carry_share", gmax(CARRY_SHARE_ALIASES)))
        carries = finite_ev("carries", gmax(CARRY_COUNT_ALIASES))
        targets = finite_ev("targets", gmax(TARGET_COUNT_ALIASES))
        rz_carries = finite_ev("red_zone_carries", gmax(RZ_CARRY_ALIASES))
        i10_carries = finite_ev("inside_10_carries", gmax(I10_CARRY_ALIASES))
        i5_carries = finite_ev("inside_5_carries", gmax(I5_CARRY_ALIASES))
        rz_targets = finite_ev("red_zone_targets", gmax(RZ_TARGET_ALIASES))
        ez_targets = finite_ev("end_zone_targets", gmax(EZ_TARGET_ALIASES))

        rush_signal = max(0.25 * carries, 1.25 * rz_carries, 2.50 * i10_carries, 4.50 * i5_carries, 3.0 * carry_share)
        rec_signal = max(0.25 * targets, 1.25 * rz_targets, 3.25 * ez_targets, 3.0 * target_share, 0.80 * route)
        # Current on-field role is allowed to keep a player alive, but cannot dominate touchdown allocation.
        role_floor = 0.10 * snap + 0.08 * route
        role_signal = rush_signal + rec_signal + role_floor
        if role_signal <= 0.0 and not math.isfinite(p_market):
            zero_role_purge.append(name)
            continue

        team_total = gmax(TEAM_TOTAL_ALIASES)
        game_total = gmax(GAME_TOTAL_ALIASES)
        rst = gmax(RST_ALIASES)
        records.append({
            "PLAYER": name, "POS": pos, "TEAM": team, "OPP": opp, "STATUS": status,
            "P_MARKET": p_market, "SNAP_SHARE": snap, "ROUTE_SHARE": route,
            "TARGET_SHARE": target_share, "CARRY_SHARE": carry_share,
            "CARRIES": max(0.0, carries), "TARGETS": max(0.0, targets),
            "RZ_CARRIES": max(0.0, rz_carries), "I10_CARRIES": max(0.0, i10_carries),
            "I5_CARRIES": max(0.0, i5_carries), "RZ_TARGETS": max(0.0, rz_targets),
            "EZ_TARGETS": max(0.0, ez_targets), "RUSH_SIGNAL": rush_signal,
            "REC_SIGNAL": rec_signal, "ROLE_SIGNAL": role_signal,
            "TEAM_TOTAL_RAW": team_total, "GAME_TOTAL_RAW": game_total,
            "RST_PRIOR_RAW": rst,
        })

    df = pd.DataFrame(records)
    if len(df) < 3:
        raise RuntimeError(f"RUN_INVALID:NFL_SS_TDS_ACTIVE_NON_QB_POOL_LT3:{len(df)}")
    if (df["POS"] == "QB").any():
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_QB_SURVIVED_HARD_PURGE")

    # Build game keys after identity is frozen.
    def game_key(r: pd.Series) -> str:
        if r["OPP"]:
            a, b = sorted((str(r["TEAM"]), str(r["OPP"])))
            return f"{a}@{b}"
        return str(r["TEAM"])
    df["GAME"] = df.apply(game_key, axis=1)

    # Direct team touchdown environment is required. Prefer implied team total; fall back to half game total;
    # if neither exists, only a sufficiently covered player TD market can identify team scoring intensity.
    team_mean: dict[str, float] = {}
    for team, g in df.groupby("TEAM"):
        tt = g["TEAM_TOTAL_RAW"].replace([np.inf, -np.inf], np.nan).dropna()
        if len(tt):
            pts = float(tt.median())
            mean_td = max(0.25, pts * 0.78 / 7.0)
        else:
            gt = g["GAME_TOTAL_RAW"].replace([np.inf, -np.inf], np.nan).dropna()
            if len(gt):
                pts = float(gt.median()) / 2.0
                mean_td = max(0.25, pts * 0.78 / 7.0)
            else:
                market_lams = [-math.log(max(1e-9, 1.0 - float(p))) for p in g["P_MARKET"] if math.isfinite(float(p))]
                coverage = len(market_lams) / max(1, len(g))
                if coverage < 0.60 or not market_lams:
                    raise RuntimeError(f"RUN_INVALID:NFL_SS_TDS_TEAM_TD_ENVIRONMENT_MISSING:{team}")
                mean_td = max(0.25, sum(market_lams) / max(0.50, 1.0 - OTHER_SCORER_RESERVE_SHARE))
        team_mean[str(team)] = float(np.clip(mean_td, 0.25, 6.5))

    # Role and market determine who scores; team environment determines how many offensive TDs occur.
    lambdas = np.zeros(len(df), dtype=float)
    market_support = np.zeros(len(df), dtype=float)
    redzone_support = np.zeros(len(df), dtype=float)
    for team, ids in df.groupby("TEAM").groups.items():
        ix = np.asarray(list(ids), dtype=int)
        role = df.loc[ix, "ROLE_SIGNAL"].to_numpy(float)
        role = np.maximum(role, 1e-8)
        role_share = role / role.sum()
        team_eligible_mean = team_mean[str(team)] * (1.0 - OTHER_SCORER_RESERVE_SHARE)
        base_lambda = team_eligible_mean * role_share
        raw = base_lambda.copy()
        for j, i in enumerate(ix):
            p = float(df.at[i, "P_MARKET"])
            if math.isfinite(p):
                lm = -math.log(max(1e-9, 1.0 - np.clip(p, 0.001, 0.995)))
                raw[j] = 0.70 * lm + 0.30 * base_lambda[j]
                market_support[i] = p
            rz = (df.at[i, "RZ_CARRIES"] + 2.0 * df.at[i, "I10_CARRIES"] + 3.0 * df.at[i, "I5_CARRIES"] +
                  df.at[i, "RZ_TARGETS"] + 2.5 * df.at[i, "EZ_TARGETS"])
            redzone_support[i] = float(rz)
        if raw.sum() <= 0:
            raise RuntimeError(f"RUN_INVALID:NFL_SS_TDS_ZERO_TEAM_SCORER_MASS:{team}")
        lambdas[ix] = team_eligible_mean * raw / raw.sum()

    df["TD_LAMBDA"] = lambdas
    df["TD_MARKET_SUPPORT"] = market_support
    # bounded 0..1 signal for terminal intelligence
    if redzone_support.max() > 0:
        redzone_support = redzone_support / redzone_support.max()
    df["RED_ZONE_SUPPORT"] = redzone_support

    receipt = {
        "RAW_ROWS": raw_row_count, "ACTIVE_NON_QB_POOL": int(len(df)),
        "QB_PURGE": sorted(qb_purge), "OUT_PURGE": sorted(out_purge),
        "NONELIGIBLE_POSITION_PURGE": sorted(noneligible_purge), "ZERO_ROLE_PURGE": sorted(zero_role_purge),
        "DUPLICATE_SLOT_ROWS_REMOVED": int(duplicate_rows_removed),
        "TEAM_TD_MEAN": team_mean, "ELIGIBLE_POSITIONS": sorted(ELIGIBLE_POSITIONS),
        "FPTS_USED": False, "PROVIDER_RST_AUTHORITY": False,
    }
    return df.reset_index(drop=True), receipt


def _simulate_touchdowns(df: pd.DataFrame, team_mean: dict[str, float], trials: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    out = np.zeros((len(df), trials), dtype=np.uint8)
    # Shared game factor produces correlated shootout/low-score worlds across both teams.
    game_factors: dict[str, np.ndarray] = {}
    for game in df["GAME"].unique().tolist():
        game_factors[str(game)] = rng.gamma(shape=8.0, scale=1.0 / 8.0, size=trials)
    for team, ids0 in df.groupby("TEAM").groups.items():
        ids = np.asarray(list(ids0), dtype=int)
        game = str(df.loc[ids[0], "GAME"])
        team_factor = rng.gamma(shape=12.0, scale=1.0 / 12.0, size=trials)
        mean_world = float(team_mean[str(team)]) * game_factors[game] * team_factor
        team_counts = np.minimum(rng.poisson(mean_world), MAX_PLAYER_TDS_PER_WORLD).astype(np.int16)
        eligible_lambda = df.loc[ids, "TD_LAMBDA"].to_numpy(float)
        other_lambda = max(1e-8, float(team_mean[str(team)]) - float(eligible_lambda.sum()))
        probs = np.append(eligible_lambda, other_lambda)
        probs = probs / probs.sum()
        for ntd in np.unique(team_counts):
            mask = np.where(team_counts == ntd)[0]
            if len(mask) == 0:
                continue
            alloc = rng.multinomial(int(ntd), probs, size=len(mask))
            out[np.ix_(ids, mask)] = alloc[:, : len(ids)].T.astype(np.uint8)
    return out


def _capped_mass(base: np.ndarray, total: float = 3.0) -> np.ndarray:
    base = np.maximum(np.asarray(base, dtype=float), 1e-12)
    n = len(base)
    if n < 3:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_OWNERSHIP_POOL_LT3")
    cap = 1.0 if n == 3 else 0.985
    free = np.ones(n, dtype=bool)
    out = np.zeros(n, dtype=float)
    remain = total
    for _ in range(n + 2):
        if not free.any():
            break
        alloc = remain * base[free] / base[free].sum()
        over = alloc > cap
        if not over.any():
            out[free] = alloc
            remain = 0.0
            break
        idx_free = np.where(free)[0]
        hit = idx_free[over]
        out[hit] = cap
        remain -= cap * len(hit)
        free[hit] = False
    if remain > 1e-8:
        out[free] += remain / max(1, free.sum())
    out *= total / out.sum()
    if (out > 1.0000001).any() or abs(out.sum() - total) > 1e-8:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_OWNERSHIP_MASS_NORMALIZATION_FAILED")
    return out


def _maxent_theta(target: np.ndarray) -> tuple[np.ndarray, float, np.ndarray]:
    """Exact 3-of-N maximum-entropy distribution matching player inclusion marginals."""
    t = np.asarray(target, dtype=float)
    if len(t) == 3:
        return np.zeros(3), 1.0, np.ones(3)
    theta = np.log(np.maximum(t, 1e-8) / np.maximum(1.0 - t, 1e-8))
    theta -= theta.mean()
    marg = np.zeros_like(t)
    for _ in range(400):
        w = np.exp(np.clip(theta, -30, 30))
        s1 = w.sum(); s2 = np.square(w).sum(); s3 = np.power(w, 3).sum()
        z = (s1 ** 3 - 3 * s1 * s2 + 2 * s3) / 6.0
        if not (z > 0 and math.isfinite(z)):
            raise RuntimeError("RUN_INVALID:NFL_SS_TDS_MAXENT_PARTITION_INVALID")
        e2_ex = ((s1 - w) ** 2 - (s2 - w ** 2)) / 2.0
        marg = w * e2_ex / z
        err = t - marg
        if float(np.max(np.abs(err))) < 1e-9:
            return w, float(z), marg
        step = np.clip(np.log(np.maximum(t, 1e-12) / np.maximum(marg, 1e-12)), -0.5, 0.5)
        theta += 0.55 * step
        theta -= theta.mean()
    if float(np.max(np.abs(t - marg))) > 2e-6:
        raise RuntimeError(f"RUN_INVALID:NFL_SS_TDS_MAXENT_MARGINAL_SOLVE_FAILED:{float(np.max(np.abs(t-marg))):.6g}")
    w = np.exp(np.clip(theta, -30, 30))
    s1 = w.sum(); s2 = np.square(w).sum(); s3 = np.power(w, 3).sum()
    z = (s1 ** 3 - 3 * s1 * s2 + 2 * s3) / 6.0
    return w, float(z), marg


def _build_candidate_surface(df: pd.DataFrame, counts: np.ndarray, field_size: int, chunk_size: int, output: Path) -> tuple[dict[str, Any], pd.DataFrame]:
    from engines.nfl.nfl_ss_tds_calibration_qualified_birth_v2 import build_candidate_surface_calibration_qualified
    return build_candidate_surface_calibration_qualified(df, counts, field_size, chunk_size, output)


def main() -> int:
    pool_raw = os.environ.get("APEX_PLAYER_POOL", "")
    if not pool_raw:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_PLAYER_POOL_REQUIRED")
    pool = Path(pool_raw).resolve()
    if not pool.exists():
        raise RuntimeError(f"RUN_INVALID:NFL_SS_TDS_PLAYER_POOL_MISSING:{pool}")
    if os.environ.get("APEX_CHUNK_STREAM_ONLY") != "1" and os.environ.get("APEX_TEST_MODE") != "1":
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_CHUNK_STREAM_ONLY_REQUIRED")
    field_size = int(os.environ.get("APEX_FIELD_SIZE", "0") or 0)
    if field_size <= 0:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_FIELD_SIZE_REQUIRED")
    test_mode = os.environ.get("APEX_TEST_MODE") == "1"
    trials = int(os.environ.get("APEX_SS_TDS_MC_SIMS", "20000") or 20000)
    if not test_mode and trials < 10000:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:NFL_SS_TDS_MC_TRIALS_LT_10000")
    if test_mode:
        trials = max(500, trials)
    chunk_size = max(16, int(os.environ.get("APEX_SS_TDS_COMBO_CHUNK", "512") or 512))
    execution_id = str(os.environ.get("APEX_EXECUTION_ID", "UNSET"))
    out_dir = Path(os.environ.get("APEX_OUTPUT_DIR", "/mnt/data")).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    role_evidence = _load_role_evidence(os.environ.get("APEX_ROLE_EVIDENCE"))
    pool_hash = _sha256_file(pool)
    seed = int(os.environ["APEX_SEED"]) if os.environ.get("APEX_SEED") else int(hashlib.sha256(f"{execution_id}|{pool_hash}|SS_TDS".encode()).hexdigest()[:8], 16)

    df, prep_receipt = _dedupe_and_prepare(pool, role_evidence)
    team_mean = prep_receipt["TEAM_TD_MEAN"]
    counts = _simulate_touchdowns(df, team_mean, trials, seed)
    if int(counts.sum()) <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:NFL_SS_TDS_ZERO_SIMULATED_TOUCHDOWNS")
    if int((counts >= 2).sum()) <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:NFL_SS_TDS_MULTI_TD_TAIL_NOT_REPRESENTED")

    surface = out_dir / f"DK_NFL_SS_TDS_{execution_id}_AI_TERMINAL_CANDIDATES.csv"
    field_receipt, native = _build_candidate_surface(df, counts, field_size, chunk_size, surface)
    scan = terminal_ai.scan_candidate_csv(surface)
    surface_receipt_path = out_dir / f"DK_NFL_SS_TDS_{execution_id}_AI_TERMINAL_CANDIDATE_RECEIPT.json"
    surface_receipt = {
        "PATCH_ID": PATCH_ID, "ENGINE_ID": ENGINE_ID, "SPORT": "NFL", "MODE": "SS_TDS",
        "EXECUTION_ID": execution_id, "CANDIDATE_COUNT": int(scan["CANDIDATE_COUNT"]),
        "CANDIDATE_FREEZE_SHA256": scan["CANDIDATE_FREEZE_SHA256"],
        "CANDIDATE_SURFACE_SHA256": scan["CANDIDATE_SURFACE_SHA256"],
        "FEATURE_AVAILABILITY": scan["FEATURE_AVAILABILITY"], "POSTLOCK_FIELDS_PRESENT": False,
        "QB_ALLOWED": False, "PROVIDER_RST_AUTHORITY": False, "OWNERSHIP_TARGET_MASS": EXPECTED_OWNERSHIP_MASS,
    }
    _atomic_json(surface_receipt_path, surface_receipt)

    native_path = out_dir / f"DK_NFL_SS_TDS_{execution_id}_NATIVE_REVIEW_BOARD.csv"
    if native.empty:
        raise RuntimeError("RUN_INVALID:NFL_SS_TDS_NATIVE_REVIEW_BOARD_EMPTY")
    native.to_csv(native_path, index=False)

    receipt_path = out_dir / f"DK_NFL_SS_TDS_{execution_id}_FINAL_RECEIPT.json"
    receipt = {
        "RUN_STATUS": "PASS", "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "RUN_STATE": "NATIVE_BOARD_READY_FOR_GLOBAL_CORE5", "PATCH_ID": PATCH_ID,
        "ENGINE_ID": ENGINE_ID, "MODE_ID": MODE_ID, "SPORT": "NFL", "MODE": "SS_TDS",
        "EXECUTION_ID": execution_id, "POOL_SHA256": pool_hash, "SEED": seed,
        "ACTIVE_POOL": int(len(df)), "QB_PURGE": prep_receipt["QB_PURGE"],
        "OUT_PURGE": prep_receipt["OUT_PURGE"], "NONELIGIBLE_POSITION_PURGE": prep_receipt["NONELIGIBLE_POSITION_PURGE"],
        "ZERO_ROLE_PURGE": prep_receipt["ZERO_ROLE_PURGE"], "DUPLICATE_SLOT_ROWS_REMOVED": prep_receipt["DUPLICATE_SLOT_ROWS_REMOVED"],
        "QB_ALLOWED": False, "ELIGIBLE_POSITIONS": sorted(ELIGIBLE_POSITIONS),
        "ROSTER_SIZE": ROSTER_SIZE, "SALARY_CAP": None, "ALL_SAME_TEAM_ALLOWED": True,
        "COUNT_VALUED_TOUCHDOWN_WORLDS": True, "MULTI_TD_PLAYER_SUPPORT": True,
        "TEAM_SCORING_COHERENCE": "TEAM_TD_COUNT_THEN_SCORER_ALLOCATION_WITH_UNSELECTABLE_OTHER_BUCKET",
        "OTHER_SCORER_RESERVE_SHARE": OTHER_SCORER_RESERVE_SHARE,
        "PROVIDER_RST_AUTHORITY": False, "EXPECTED_OWNERSHIP_MASS": EXPECTED_OWNERSHIP_MASS,
        "PHASE2_BUILT_LINEUPS": int(field_receipt["CALIBRATION_QUALIFIED_BIRTHS"]),
        "SELECTOR_REVIEWED_LINEUPS": int(scan["CANDIDATE_COUNT"]),
        "BASE_SIM_TRIALS": trials, "FAKE_FIELD_LINEUPS": field_size,
        "FIELD_MODEL": field_receipt, "PREP": prep_receipt,
        "AI_TERMINAL_AUTHORITY_REQUIRED": True,
        "AI_TERMINAL_CANDIDATE_SURFACE_PATH": str(surface),
        "AI_TERMINAL_CANDIDATE_RECEIPT_PATH": str(surface_receipt_path),
        "AI_TERMINAL_CANDIDATE_COUNT": int(scan["CANDIDATE_COUNT"]),
        "AI_TERMINAL_CANDIDATE_FREEZE_SHA256": scan["CANDIDATE_FREEZE_SHA256"],
        "NATIVE_REVIEW_BOARD_PATH": str(native_path), "NATIVE_REVIEW_BOARD_SIZE": int(len(native)),
        "FINAL_BOARD_SIZE": int(len(native)), "FINAL_BOARD": native.to_dict("records"),
        "GLOBAL_FINAL_PLAYABLE_CORE5_PENDING": True, "POSTLOCK_RESULTS_USED": False,
        "FPTS_USED_IN_SCORING_MODEL": False,
        "CALIBRATION_QUALIFIED_BIRTH_CERTIFIED": True,
        "UNQUALIFIED_CANDIDATE_BIRTH_ALLOWED": False,
        "FULL_LEGAL_UNIVERSE_ENUMERATION_ALLOWED": False,
        "PRE_PHASE2_RAW_LATTICE_MATERIALIZATION_ALLOWED": False,
    }
    _atomic_json(receipt_path, receipt)
    # Emit a compact terminal handoff only after every terminal surface artifact is durably written.
    # The global runner consumes stdout as a control plane; keep the payload one-line so an
    # already-exited child cannot outrun a multi-line JSON drain. The full receipt remains on disk.
    handoff = {
        "RUN_STATE": "NATIVE_BOARD_READY_FOR_GLOBAL_CORE5",
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "PATCH_ID": PATCH_ID, "ENGINE_ID": ENGINE_ID, "SPORT": "NFL", "MODE": "SS_TDS",
        "EXECUTION_ID": execution_id, "ACTIVE_POOL": int(len(df)),
        "QB_PURGE": prep_receipt["QB_PURGE"], "OUT_PURGE": prep_receipt["OUT_PURGE"],
        "QB_ALLOWED": False, "PHASE2_BUILT_LINEUPS": int(field_receipt["CALIBRATION_QUALIFIED_BIRTHS"]),
        "SELECTOR_REVIEWED_LINEUPS": int(scan["CANDIDATE_COUNT"]), "BASE_SIM_TRIALS": trials,
        "FAKE_FIELD_LINEUPS": field_size, "AI_TERMINAL_AUTHORITY_REQUIRED": True,
        "AI_TERMINAL_CANDIDATE_SURFACE_PATH": str(surface),
        "AI_TERMINAL_CANDIDATE_RECEIPT_PATH": str(surface_receipt_path),
        "AI_TERMINAL_CANDIDATE_COUNT": int(scan["CANDIDATE_COUNT"]),
        "AI_TERMINAL_CANDIDATE_FREEZE_SHA256": scan["CANDIDATE_FREEZE_SHA256"],
        "PRODUCTION_RECEIPT_PATH": str(receipt_path), "GLOBAL_FINAL_PLAYABLE_CORE5_PENDING": True
    }
    print(json.dumps(handoff, sort_keys=True, separators=(",", ":")), flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({
            "RUN_STATE": "RUN_INVALID", "EXECUTION_STATE": "FAILED", "PATCH_ID": PATCH_ID,
            "ENGINE_ID": ENGINE_ID, "SPORT": "NFL", "MODE": "SS_TDS",
            "FAILURE_CODE": f"{type(exc).__name__}:{exc}", "FINAL_BOARD_SIZE": 0,
        }, indent=2), flush=True)
        raise
