from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence
import hashlib
import json

import numpy as np

PATCH_ID = "NFL_SHOWDOWN_FROZEN_CALIBRATION_HYBRID_SELECTOR_WIRING_v1"
SELECTOR_MODE = "CODE_AI_HYBRID"
PRIMARY_OBJECTIVE = "TOP_0_1_PERCENT_BOARD_CAPTURE"
WEIGHTED_METRIC_SUM_USED = False

class HybridSelectorIntegrityError(RuntimeError):
    pass

PROHIBITED_METRIC_NAMES = frozenset({
    "PLAYER", "PLAYER_NAME", "NAME", "RAW_PROJECTION", "PROJECTION",
    "ACTUAL_FPTS", "POSTLOCK_FPTS", "CONTEST_RANK", "REALIZED_RESULT",
    "ORIGINAL_SELECTOR", "SELECTOR_SCORE", "OBJECTIVE",
})

@dataclass(frozen=True)
class HybridRankingPlan:
    primary_metric: str
    tiebreak_metrics: tuple[str, ...]
    primary_tie_width: float = 0.0

    def as_dict(self) -> dict[str, object]:
        return {
            "primary_metric": self.primary_metric,
            "tiebreak_metrics": list(self.tiebreak_metrics),
            "primary_tie_width": float(self.primary_tie_width),
        }


def _normalize_metric_name(name: str) -> str:
    return str(name).strip().upper()


def validate_metric_plan(plan: HybridRankingPlan, metrics: Mapping[str, np.ndarray]) -> None:
    names = [plan.primary_metric, *plan.tiebreak_metrics]
    if len(names) != len(set(names)):
        raise HybridSelectorIntegrityError("DUPLICATE_SELECTOR_METRIC")
    for name in names:
        if _normalize_metric_name(name) in PROHIBITED_METRIC_NAMES:
            raise HybridSelectorIntegrityError(f"PROHIBITED_SELECTOR_METRIC:{name}")
        if name not in metrics:
            raise HybridSelectorIntegrityError(f"MISSING_SELECTOR_METRIC:{name}")
        arr = np.asarray(metrics[name])
        if arr.ndim != 1:
            raise HybridSelectorIntegrityError(f"SELECTOR_METRIC_NOT_VECTOR:{name}")
        if not np.issubdtype(arr.dtype, np.number):
            raise HybridSelectorIntegrityError(f"SELECTOR_METRIC_NOT_NUMERIC:{name}")


def assert_calibration_hash_chain(expected: str, stage_hashes: Mapping[str, str]) -> None:
    expected = str(expected)
    required = (
        "PHASE1", "PHASE2_INPUT", "PHASE3_INPUT", "HANDOFF_INPUT",
        "SELECTOR_INPUT", "FINAL_BOARD_INPUT",
    )
    missing = [k for k in required if k not in stage_hashes]
    if missing:
        raise HybridSelectorIntegrityError("CALIBRATION_HASH_CHAIN_MISSING:" + ",".join(missing))
    bad = {k: str(stage_hashes[k]) for k in required if str(stage_hashes[k]) != expected}
    if bad:
        raise HybridSelectorIntegrityError("CALIBRATION_HASH_MISMATCH:" + json.dumps(bad, sort_keys=True))


def ranking_order(plan: HybridRankingPlan, metrics: Mapping[str, np.ndarray]) -> np.ndarray:
    """Rank by one primary metric; only tied/near-tied primary rows use ordered tiebreaks.

    This never forms a weighted sum. A positive tie width bins only the primary metric,
    so secondary metrics cannot overcome a materially better primary Top-0.1 signal.
    """
    validate_metric_plan(plan, metrics)
    primary = np.asarray(metrics[plan.primary_metric], dtype=np.float64)
    if not np.all(np.isfinite(primary)):
        primary = np.nan_to_num(primary, nan=-np.inf, posinf=np.inf, neginf=-np.inf)
    if plan.primary_tie_width > 0:
        bucket = np.rint(primary / float(plan.primary_tie_width))
    else:
        bucket = primary

    # np.lexsort uses the last key as primary. Stable row index is the final tie breaker.
    keys: list[np.ndarray] = [np.arange(len(primary), dtype=np.int64), -primary]
    for name in reversed(plan.tiebreak_metrics):
        arr = np.asarray(metrics[name], dtype=np.float64)
        arr = np.nan_to_num(arr, nan=-np.inf, posinf=np.inf, neginf=-np.inf)
        keys.append(-arr)
    keys.append(-bucket)
    return np.lexsort(tuple(keys)).astype(np.int64, copy=False)


def select_diverse_board(
    order: Sequence[int],
    lineups: np.ndarray,
    *,
    board_size: int,
    max_player_exposure: int,
    max_pairwise_overlap: int,
    sibling_max_pairwise_overlap: int,
    family_recurrent: np.ndarray | None = None,
) -> list[int]:
    lineups = np.asarray(lineups)
    if lineups.ndim != 2:
        raise HybridSelectorIntegrityError("LINEUP_MATRIX_REQUIRED")
    n_players = int(lineups.max()) + 1 if lineups.size else 0
    exposure = np.zeros(n_players, dtype=np.int16)
    selected: list[int] = []
    selected_sets: list[set[int]] = []
    family_recurrent = np.asarray(family_recurrent, dtype=bool) if family_recurrent is not None else np.zeros(len(lineups), dtype=bool)
    for raw_i in order:
        i = int(raw_i)
        players = np.asarray(lineups[i], dtype=np.int64)
        if np.any(exposure[players] >= int(max_player_exposure)):
            continue
        si = set(int(x) for x in players)
        ok = True
        for prior_i, sj in zip(selected, selected_sets):
            overlap = len(si & sj)
            sibling = bool(family_recurrent[i] and family_recurrent[prior_i] and overlap >= 4)
            allowed = int(sibling_max_pairwise_overlap if sibling else max_pairwise_overlap)
            if overlap > allowed:
                ok = False
                break
        if not ok:
            continue
        selected.append(i)
        selected_sets.append(si)
        exposure[players] += 1
        if len(selected) == int(board_size):
            break
    if len(selected) != int(board_size):
        raise HybridSelectorIntegrityError(f"STRICT_BOARD_INFEASIBLE:{len(selected)}:{board_size}")
    return selected


def selector_receipt(plan: HybridRankingPlan, candidate_count: int, calibration_hash: str) -> dict[str, object]:
    payload = {
        "PATCH_ID": PATCH_ID,
        "SELECTOR_MODE": SELECTOR_MODE,
        "SELECTOR_PRIMARY_OBJECTIVE": PRIMARY_OBJECTIVE,
        "SELECTOR_PRIMARY_METRIC": plan.primary_metric,
        "SELECTOR_METRIC_ORDER": [plan.primary_metric, *plan.tiebreak_metrics],
        "SELECTOR_PRIMARY_TIE_WIDTH": float(plan.primary_tie_width),
        "SELECTOR_WEIGHTED_METRIC_SUM_USED": WEIGHTED_METRIC_SUM_USED,
        "SELECTOR_REVIEWED_LINEUPS": int(candidate_count),
        "SELECTOR_CALIBRATION_HASH": str(calibration_hash),
        "AI_AUTHORITY": "RANK_SORT_COMPARE_TIEBREAK_PORTFOLIO_SELECT_ONLY",
        "PLAYER_NAMES_USED_BY_SELECTOR": False,
        "RAW_PROJECTIONS_USED_BY_SELECTOR": False,
        "POSTLOCK_RESULTS_USED_BY_SELECTOR": False,
    }
    payload["SELECTOR_PLAN_SHA256"] = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return payload
