from __future__ import annotations

"""Pre-lock nflverse role / red-zone enrichment for NFL Showdown.

This module is intentionally result-blind for the target slate.  It derives rolling
opportunity features only from games dated strictly before ``as_of`` and merges them
into an already-current role-evidence payload.  Historical nflverse data is never
allowed to establish target-slate availability by itself.
"""

import hashlib
import json
import math
import re
import shutil
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

PATCH_ID = "NFL_SHOWDOWN_NFLVERSE_PRELOCK_RED_ZONE_ROLE_PIPELINE_v1"
SOURCE_AUTHORITY = "NFLVERSE_PBP_PLUS_SNAP_COUNTS_PRELOCK_HISTORY"
DEFAULT_LOOKBACK_GAMES = 8
DEFAULT_DECAY = 0.84

URLS = {
    "pbp_csv_gz": "https://github.com/nflverse/nflverse-data/releases/download/pbp/play_by_play_{season}.csv.gz",
    "pbp_csv": "https://github.com/nflverse/nflverse-data/releases/download/pbp/play_by_play_{season}.csv",
    "snap_counts_csv": "https://github.com/nflverse/nflverse-data/releases/download/snap_counts/snap_counts_{season}.csv",
    "weekly_rosters_csv": "https://github.com/nflverse/nflverse-data/releases/download/weekly_rosters/roster_weekly_{season}.csv",
    "players_csv": "https://github.com/nflverse/nflverse-data/releases/download/players/players.csv",
}


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _norm_name(value: Any) -> str:
    x = str(value or "").upper()
    x = x.replace("’", "'")
    x = re.sub(r"\b(JR|SR|II|III|IV)\b\.?", "", x)
    x = re.sub(r"[^A-Z0-9]+", "", x)
    return x


def source_urls(seasons: Iterable[int]) -> dict[str, list[str] | str]:
    ss = [int(s) for s in seasons]
    return {
        "pbp": [URLS["pbp_csv_gz"].format(season=s) for s in ss],
        "snap_counts": [URLS["snap_counts_csv"].format(season=s) for s in ss],
        "weekly_rosters": [URLS["weekly_rosters_csv"].format(season=s) for s in ss],
        "players": URLS["players_csv"],
    }


def _candidate_cache_names(kind: str, season: int | None = None) -> list[str]:
    if kind == "pbp" and season is not None:
        return [f"play_by_play_{season}.csv", f"play_by_play_{season}.csv.gz"]
    if kind == "snap_counts" and season is not None:
        return [f"snap_counts_{season}.csv"]
    if kind == "weekly_rosters" and season is not None:
        return [f"roster_weekly_{season}.csv"]
    if kind == "players":
        return ["players.csv"]
    return []


def refresh_cache(
    cache_dir: str | Path,
    seasons: Iterable[int],
    *,
    include_snap_counts: bool = True,
    include_weekly_rosters: bool = True,
    timeout_seconds: int = 60,
) -> dict[str, Any]:
    """Download official nflverse release assets into a deterministic local cache.

    This is a pre-run acquisition step.  The live optimizer consumes only frozen local
    bytes and never depends on a network request while Phase 1/2 is running.
    """
    root = Path(cache_dir)
    root.mkdir(parents=True, exist_ok=True)
    seasons = [int(s) for s in seasons]
    fetched: list[dict[str, Any]] = []

    def _download(urls: list[str], out: Path) -> None:
        last: Exception | None = None
        for url in urls:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "APEX-NFLVerse-Prelock/1.0"})
                with urllib.request.urlopen(req, timeout=int(timeout_seconds)) as r, out.open("wb") as f:
                    shutil.copyfileobj(r, f)
                if out.stat().st_size <= 0:
                    raise RuntimeError("EMPTY_DOWNLOAD")
                fetched.append({"path": str(out), "url": url, "sha256": _sha256_file(out), "bytes": out.stat().st_size})
                return
            except Exception as exc:  # pragma: no cover - network path
                last = exc
                try:
                    out.unlink(missing_ok=True)
                except Exception:
                    pass
        raise RuntimeError(f"NFLVERSE_DOWNLOAD_FAILED:{out.name}:{last}")

    for season in seasons:
        pbp_out = root / f"play_by_play_{season}.csv"
        if not pbp_out.exists():
            _download([URLS["pbp_csv"].format(season=season)], pbp_out)
        if include_snap_counts:
            p = root / f"snap_counts_{season}.csv"
            if not p.exists():
                _download([URLS["snap_counts_csv"].format(season=season)], p)
        if include_weekly_rosters:
            p = root / f"roster_weekly_{season}.csv"
            if not p.exists():
                _download([URLS["weekly_rosters_csv"].format(season=season)], p)
    players = root / "players.csv"
    if not players.exists():
        _download([URLS["players_csv"]], players)
    return {"PATCH_ID": PATCH_ID, "cache_dir": str(root), "fetched": fetched, "source_urls": source_urls(seasons)}


def _read_one(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path, low_memory=False)


def _load_cached(cache_dir: str | Path, seasons: Iterable[int]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, str]]:
    root = Path(cache_dir)
    pbp_parts: list[pd.DataFrame] = []
    snap_parts: list[pd.DataFrame] = []
    roster_parts: list[pd.DataFrame] = []
    hashes: dict[str, str] = {}
    for season in [int(s) for s in seasons]:
        pbp_path = next((root / n for n in _candidate_cache_names("pbp", season) if (root / n).exists()), None)
        if pbp_path is not None:
            pbp_parts.append(_read_one(pbp_path)); hashes[pbp_path.name] = _sha256_file(pbp_path)
        snap_path = next((root / n for n in _candidate_cache_names("snap_counts", season) if (root / n).exists()), None)
        if snap_path is not None:
            snap_parts.append(_read_one(snap_path)); hashes[snap_path.name] = _sha256_file(snap_path)
        roster_path = next((root / n for n in _candidate_cache_names("weekly_rosters", season) if (root / n).exists()), None)
        if roster_path is not None:
            roster_parts.append(_read_one(roster_path)); hashes[roster_path.name] = _sha256_file(roster_path)
    players_path = root / "players.csv"
    players = _read_one(players_path)
    if players_path.exists(): hashes[players_path.name] = _sha256_file(players_path)
    return (
        pd.concat(pbp_parts, ignore_index=True) if pbp_parts else pd.DataFrame(),
        pd.concat(snap_parts, ignore_index=True) if snap_parts else pd.DataFrame(),
        pd.concat(roster_parts, ignore_index=True) if roster_parts else pd.DataFrame(),
        players,
        hashes,
    )


def _coalesce_col(df: pd.DataFrame, names: list[str]) -> str | None:
    return next((c for c in names if c in df.columns), None)


def _id_name_map(players: pd.DataFrame, rosters: pd.DataFrame) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for frame in [players, rosters]:
        if frame is None or frame.empty:
            continue
        id_col = _coalesce_col(frame, ["gsis_id", "player_id", "gsis_it_id"])
        nm_col = _coalesce_col(frame, ["display_name", "full_name", "player_name", "football_name"])
        if not id_col or not nm_col:
            continue
        for pid, name in zip(frame[id_col], frame[nm_col]):
            if pd.notna(pid) and pd.notna(name):
                mapping[str(pid)] = str(name)
    return mapping


def _as_float01(v: Any) -> float:
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return 0.0
    if isinstance(v, str):
        s = v.strip().replace("%", "")
        try: x = float(s)
        except Exception: return 0.0
    else:
        try: x = float(v)
        except Exception: return 0.0
    if x > 1.5: x /= 100.0
    return float(np.clip(x, 0.0, 1.0))


def _filter_prelock(pbp: pd.DataFrame, as_of: str | pd.Timestamp) -> pd.DataFrame:
    if pbp.empty:
        return pbp.copy()
    out = pbp.copy()
    if "game_date" not in out.columns:
        raise RuntimeError("NFLVERSE_PBP_GAME_DATE_MISSING")
    d = pd.to_datetime(out["game_date"], errors="coerce")
    cutoff = pd.Timestamp(as_of)
    if cutoff.tzinfo is not None:
        cutoff = cutoff.tz_localize(None)
    # NFLVerse game_date is date-grain. Strictly earlier date prevents same-day target-slate leakage.
    out = out.loc[d.dt.normalize() < cutoff.normalize()].copy()
    if "season_type" in out.columns:
        out = out.loc[out["season_type"].astype(str).str.upper().isin(["REG", "POST"])].copy()
    return out


def _build_game_opportunity(pbp: pd.DataFrame, id_to_name: dict[str, str]) -> pd.DataFrame:
    if pbp.empty:
        return pd.DataFrame()
    req = ["game_id", "posteam", "yardline_100"]
    if any(c not in pbp.columns for c in req):
        raise RuntimeError("NFLVERSE_PBP_REQUIRED_FIELDS_MISSING")
    x = pbp.copy()
    yd = pd.to_numeric(x["yardline_100"], errors="coerce")
    x["_rz"] = yd.le(20)
    x["_i10"] = yd.le(10)
    x["_i5"] = yd.le(5)
    rush = pd.to_numeric(x.get("rush_attempt", 0), errors="coerce").fillna(0).eq(1)
    if "qb_kneel" in x.columns:
        rush &= ~pd.to_numeric(x["qb_kneel"], errors="coerce").fillna(0).eq(1)
    passer_id = x.get("passer_player_id", pd.Series(index=x.index, dtype=object))
    receiver_id = x.get("receiver_player_id", pd.Series(index=x.index, dtype=object))
    rusher_id = x.get("rusher_player_id", pd.Series(index=x.index, dtype=object))
    pass_attempt = pd.to_numeric(x.get("pass_attempt", 0), errors="coerce").fillna(0).eq(1)
    target = pass_attempt & receiver_id.notna()

    team = x["posteam"].astype(str)
    game = x["game_id"].astype(str)
    key = pd.DataFrame({"game_id": game, "team": team})
    den = key.copy()
    den["team_rush"] = rush.astype(float)
    den["team_targets"] = target.astype(float)
    den["team_rz_rush"] = (rush & x["_rz"]).astype(float)
    den["team_i10_rush"] = (rush & x["_i10"]).astype(float)
    den["team_i5_rush"] = (rush & x["_i5"]).astype(float)
    den["team_rz_targets"] = (target & x["_rz"]).astype(float)
    den = den.groupby(["game_id", "team"], as_index=False).sum(numeric_only=True)

    records: list[pd.DataFrame] = []
    def _events(mask: pd.Series, ids: pd.Series, role: str) -> None:
        sub = pd.DataFrame({"game_id": game[mask], "team": team[mask], "player_id": ids[mask].astype(str)})
        if sub.empty: return
        sub[role] = 1.0
        records.append(sub.groupby(["game_id", "team", "player_id"], as_index=False)[role].sum())

    _events(rush, rusher_id, "rush_att")
    _events(rush & x["_rz"], rusher_id, "rz_rush_attempts")
    _events(rush & x["_i10"], rusher_id, "inside10_rush_attempts")
    _events(rush & x["_i5"], rusher_id, "inside5_rush_attempts")
    _events(target, receiver_id, "targets")
    _events(target & x["_rz"], receiver_id, "rz_targets")
    _events(target & x["_i10"], receiver_id, "inside10_targets")
    if "air_yards" in x.columns:
        air = pd.to_numeric(x["air_yards"], errors="coerce")
        ez = target & air.ge(yd)
        _events(ez, receiver_id, "end_zone_targets")
    _events(pass_attempt & x["_rz"] & passer_id.notna(), passer_id, "rz_pass_attempts")
    _events(rush & x["_rz"], rusher_id, "qb_rz_rush_attempts_raw")

    if not records:
        return pd.DataFrame()
    out = records[0]
    for rec in records[1:]:
        out = out.merge(rec, on=["game_id", "team", "player_id"], how="outer")
    out = out.fillna(0.0).merge(den, on=["game_id", "team"], how="left")
    out["player_name"] = out["player_id"].map(id_to_name).fillna("")
    return out


def _attach_snap_pct(game_opp: pd.DataFrame, snaps: pd.DataFrame, id_to_name: dict[str, str]) -> pd.DataFrame:
    if game_opp.empty or snaps is None or snaps.empty:
        game_opp["offense_pct"] = 0.0
        return game_opp
    s = snaps.copy()
    id_col = _coalesce_col(s, ["gsis_id", "player_id"])
    name_col = _coalesce_col(s, ["player", "player_name", "full_name"])
    if "game_id" not in s.columns:
        game_opp["offense_pct"] = 0.0
        return game_opp
    if id_col:
        s["player_id"] = s[id_col].astype(str)
    elif name_col:
        reverse = {_norm_name(v): k for k, v in id_to_name.items()}
        s["player_id"] = s[name_col].map(lambda z: reverse.get(_norm_name(z), ""))
    else:
        game_opp["offense_pct"] = 0.0
        return game_opp
    pct_col = _coalesce_col(s, ["offense_pct", "off_pct", "offense_percent"])
    if not pct_col:
        game_opp["offense_pct"] = 0.0
        return game_opp
    s["offense_pct"] = s[pct_col].map(_as_float01)
    team_col = _coalesce_col(s, ["team", "posteam"])
    keep = ["game_id", "player_id", "offense_pct"] + ([team_col] if team_col else [])
    sg = s[keep].copy()
    if team_col and team_col != "team": sg = sg.rename(columns={team_col:"team"})
    if "team" not in sg.columns: sg["team"] = ""
    sg = sg.groupby(["game_id", "player_id", "team"], as_index=False)["offense_pct"].max()
    # Keep snap-only appearances so historical snap share can exist even when a player
    # recorded no target/carry in that game.  Opportunity denominators remain zero.
    base = game_opp.merge(sg[["game_id","player_id","offense_pct"]], on=["game_id","player_id"], how="outer")
    if "team" not in base.columns: base["team"] = ""
    missing_team = base["team"].isna() | base["team"].astype(str).eq("")
    if missing_team.any():
        tm = sg.set_index(["game_id","player_id"])["team"].to_dict()
        base.loc[missing_team,"team"] = [tm.get((str(g),str(pid)),"") for g,pid in zip(base.loc[missing_team,"game_id"], base.loc[missing_team,"player_id"])]
    if "player_name" not in base.columns: base["player_name"] = ""
    missing_name = base["player_name"].isna() | base["player_name"].astype(str).eq("")
    base.loc[missing_name,"player_name"] = base.loc[missing_name,"player_id"].map(id_to_name).fillna("")
    return base.fillna(0.0)


def _rolling_features(game_opp: pd.DataFrame, lookback_games: int, decay: float, pos_by_name: dict[str, str]) -> dict[str, dict[str, float]]:
    if game_opp.empty:
        return {}
    out: dict[str, dict[str, float]] = {}
    for pid, g in game_opp.groupby("player_id", sort=False):
        # game_id begins with season_week and sorts chronologically in nflverse; use unique appearance order by string as fallback.
        gg = g.sort_values("game_id", ascending=False).head(int(lookback_games)).copy()
        weights = np.power(float(decay), np.arange(len(gg), dtype=float))
        weights = weights / max(weights.sum(), 1e-12)
        def wsum(col: str) -> float:
            if col not in gg.columns: return 0.0
            return float(np.sum(pd.to_numeric(gg[col], errors="coerce").fillna(0.0).to_numpy(float) * weights))
        def ratio(num: str, den: str) -> float:
            n = wsum(num); d = wsum(den)
            return float(n / d) if d > 1e-9 else 0.0
        name = next((str(v) for v in gg.get("player_name", pd.Series(dtype=str)).tolist() if str(v).strip()), "")
        if not name: continue
        pos = str(pos_by_name.get(_norm_name(name), "")).upper()
        feat = {
            "rz_rush_attempts": wsum("rz_rush_attempts"),
            "inside10_rush_attempts": wsum("inside10_rush_attempts"),
            "inside5_rush_attempts": wsum("inside5_rush_attempts"),
            "rz_targets": wsum("rz_targets"),
            "inside10_targets": wsum("inside10_targets"),
            "end_zone_targets": wsum("end_zone_targets"),
            "rz_target_share": ratio("rz_targets", "team_rz_targets"),
            "rz_rush_share": ratio("rz_rush_attempts", "team_rz_rush"),
            "goal_line_share": ratio("inside5_rush_attempts", "team_i5_rush"),
            "target_share_hist": ratio("targets", "team_targets"),
            "carry_share_hist": ratio("rush_att", "team_rush"),
            "snap_share_hist": wsum("offense_pct"),
            "rz_pass_attempts": wsum("rz_pass_attempts") if pos == "QB" else 0.0,
            "qb_rz_rush_attempts": wsum("qb_rz_rush_attempts_raw") if pos == "QB" else 0.0,
            "nflverse_history_games": float(len(gg)),
        }
        out[_norm_name(name)] = feat
    return out


def derive_from_frames(
    pool: pd.DataFrame,
    pbp: pd.DataFrame,
    snaps: pd.DataFrame,
    rosters: pd.DataFrame,
    players: pd.DataFrame,
    *,
    as_of: str | pd.Timestamp,
    lookback_games: int = DEFAULT_LOOKBACK_GAMES,
    decay: float = DEFAULT_DECAY,
) -> tuple[dict[str, dict[str, float]], dict[str, Any]]:
    if pool.empty:
        raise RuntimeError("NFLVERSE_POOL_EMPTY")
    id_to_name = _id_name_map(players, rosters)
    pre = _filter_prelock(pbp, as_of)
    game_opp = _build_game_opportunity(pre, id_to_name)
    game_opp = _attach_snap_pct(game_opp, snaps, id_to_name)
    pos_by_name = {_norm_name(n): str(p).split("/")[0].upper() for n, p in zip(pool["PLAYER"], pool["POS"])}
    hist = _rolling_features(game_opp, int(lookback_games), float(decay), pos_by_name)
    pool_names = {_norm_name(x) for x in pool["PLAYER"].astype(str)}
    matched = {k: v for k, v in hist.items() if k in pool_names}
    max_date = None
    if not pre.empty and "game_date" in pre.columns:
        mx = pd.to_datetime(pre["game_date"], errors="coerce").max()
        if pd.notna(mx): max_date = str(mx.date())
    receipt = {
        "PATCH_ID": PATCH_ID,
        "SOURCE_AUTHORITY": SOURCE_AUTHORITY,
        "AS_OF": str(pd.Timestamp(as_of)),
        "STRICT_PRELOCK_DATE_FILTER": True,
        "LOOKBACK_GAMES": int(lookback_games),
        "RECENCY_DECAY": float(decay),
        "PBP_ROWS_PRELOCK": int(len(pre)),
        "PLAYER_GAME_ROWS": int(len(game_opp)),
        "POOL_PLAYERS_MATCHED": int(len(matched)),
        "MAX_GAME_DATE_USED": max_date,
        "POSTLOCK_TARGET_GAME_USED": False,
    }
    return matched, receipt


def enrich_role_evidence(
    role_evidence: dict[str, Any],
    pool_path: str | Path,
    *,
    cache_dir: str | Path,
    as_of: str | pd.Timestamp,
    seasons: Iterable[int],
    lookback_games: int = DEFAULT_LOOKBACK_GAMES,
    decay: float = DEFAULT_DECAY,
) -> tuple[dict[str, Any], dict[str, Any]]:
    pool = pd.read_csv(pool_path)
    pbp, snaps, rosters, players, hashes = _load_cached(cache_dir, seasons)
    if pbp.empty:
        receipt = {
            "PATCH_ID": PATCH_ID,
            "STATUS": "NO_LOCAL_PBP_BYTES",
            "CACHE_DIR": str(cache_dir),
            "SEASONS": [int(s) for s in seasons],
            "SOURCE_URLS": source_urls(seasons),
            "POSTLOCK_TARGET_GAME_USED": False,
        }
        return json.loads(json.dumps(role_evidence)), receipt
    features, receipt = derive_from_frames(pool, pbp, snaps, rosters, players, as_of=as_of, lookback_games=lookback_games, decay=decay)
    payload = json.loads(json.dumps(role_evidence))
    pmap = payload.get("players", {})
    if not isinstance(pmap, dict):
        raise RuntimeError("RUN_INVALID:ROLE_EVIDENCE_PLAYERS_INVALID")
    filled: list[str] = []
    # Historical nflverse data augments current role evidence; it never creates target-slate eligibility by itself.
    for name in pool["PLAYER"].astype(str):
        key = _norm_name(name)
        feat = features.get(key)
        if not feat or name not in pmap or not isinstance(pmap.get(name), dict):
            continue
        ev = dict(pmap[name])
        for f in [
            "rz_rush_attempts", "inside10_rush_attempts", "inside5_rush_attempts",
            "rz_targets", "inside10_targets", "end_zone_targets", "rz_target_share",
            "rz_rush_share", "goal_line_share", "rz_pass_attempts", "qb_rz_rush_attempts",
            "nflverse_history_games",
        ]:
            ev[f] = float(feat.get(f, 0.0))
        # Current source-backed role remains authority. Historical shares only fill missing values.
        if float(ev.get("snap_share", 0.0) or 0.0) <= 0.0 and feat.get("snap_share_hist", 0.0) > 0.0:
            ev["historical_snap_share"] = float(feat["snap_share_hist"])
        if float(ev.get("target_share", 0.0) or 0.0) <= 0.0 and feat.get("target_share_hist", 0.0) > 0.0:
            ev["historical_target_share"] = float(feat["target_share_hist"])
        if float(ev.get("carry_share", 0.0) or 0.0) <= 0.0 and feat.get("carry_share_hist", 0.0) > 0.0:
            ev["historical_carry_share"] = float(feat["carry_share_hist"])
        ev["nflverse_prelock_source"] = PATCH_ID
        pmap[name] = ev
        filled.append(name)
    payload["players"] = pmap
    receipt.update({
        "STATUS": "ENRICHED",
        "CACHE_DIR": str(cache_dir),
        "SEASONS": [int(s) for s in seasons],
        "SOURCE_URLS": source_urls(seasons),
        "SOURCE_FILE_SHA256": hashes,
        "PLAYERS_ENRICHED": sorted(filled),
        "PLAYERS_ENRICHED_COUNT": int(len(filled)),
        "CURRENT_ROLE_AUTHORITY_PRESERVED": True,
        "HISTORICAL_DATA_CANNOT_ESTABLISH_AVAILABILITY": True,
    })
    payload["nflverse_prelock_receipt"] = receipt
    return payload, receipt
