
from __future__ import annotations
import math
from collections import defaultdict

def _clip(p, lo=1e-4, hi=1-1e-4):
    return min(hi, max(lo, float(p)))

def logit(p):
    p=_clip(p)
    return math.log(p/(1-p))

def sigmoid(x):
    return 1/(1+math.exp(-x))

def calibrate_marginal_ownership(prelock_own, residual_logit, weight=1.0):
    """Shadow-only ownership calibration. residual_logit is learned only from matched prior controls."""
    return sigmoid(logit(prelock_own) + float(weight)*float(residual_logit))

def shrink_dependence_factor(empirical_factor, weight):
    """Shrink pair/trio co-occurrence multiplier toward independence (1.0) in log space."""
    f=max(1e-6, float(empirical_factor))
    return math.exp(float(weight)*math.log(f))

def lineup_weight(players, marginals, pair_factors=None, trio_factor=1.0):
    """
    Unnormalized public-field lineup weight.
    Keeps marginal strength primary, then applies empirically learned dependence.
    This does NOT force diversity or contrarianism.
    """
    pair_factors = pair_factors or {}
    w=1.0
    for p in players:
        w *= _clip(marginals[p])
    ps=tuple(players)
    for i in range(len(ps)):
        for j in range(i+1,len(ps)):
            key=tuple(sorted((ps[i],ps[j])))
            w *= max(1e-6, float(pair_factors.get(key,1.0)))
    w *= max(1e-6, float(trio_factor))
    return w

def normalize_lineup_weights(weights):
    s=sum(weights)
    if s<=0:
        raise ValueError("non-positive lineup-weight mass")
    return [w/s for w in weights]

def promotion_gate(independent_controls, winner_capture_all, calibration_improves_holdout):
    return (
        int(independent_controls) >= 3
        and bool(winner_capture_all)
        and bool(calibration_improves_holdout)
    )
