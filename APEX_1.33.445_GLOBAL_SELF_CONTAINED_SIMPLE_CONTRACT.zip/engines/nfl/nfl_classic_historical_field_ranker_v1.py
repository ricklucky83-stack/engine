from __future__ import annotations
import hashlib
import json
from pathlib import Path
from typing import Any
import numpy as np

PATCH_ID = "NFL_CLASSIC_HISTORICAL_FIELD_RANKER_v1"
TOP5_HEAD_PATCH_ID = "NFL_CLASSIC_TOP5_MEDIAN_HEAD_SHRINKAGE_v1"
TOP1_MODEL_FILE = Path(__file__).with_name("nfl_classic_historical_field_ranker_v1.joblib")
TOP01_MODEL_FILE = Path(__file__).with_name("nfl_classic_historical_top01_ranker_v1.joblib")
META_FILE = Path(__file__).with_name("nfl_classic_historical_field_ranker_v1.json")
# Cumulative historical learning is always on by user direction.
# Top-0.1% classification owns championship ordering; Top-1% classification stabilizes it.
# Live MC/projection/legality remain admission and safety evidence.
HISTORICAL_WEIGHT = 1.0
TOP01_BLEND_WEIGHT = 0.85
TOP1_BLEND_WEIGHT = 0.15

FEATURES = [
    'raw_sum','p95_sum','p99_sum','market_sum','opp_sum','logown','salary_k','same_pass','bring','same_rb','games','maxgame','qbgame','teams',
    'raw_min','raw_max','raw_std','p99_min','p99_max','p99_std','player_rec_sum','player_rec_min','player_rec_max','core_rec_max','core_rec_sum',
    'mean_corr','market_quality','cal_score','low10_count','low5_count','ownsum'
]

def slate_fingerprint(cal: Any) -> str:
    parts=[]
    frame=cal.frame
    for _,r in frame.iterrows():
        parts.append('|'.join([str(r.get('ID','')),str(r.get('PLAYER','')),str(r.get('SALARY','')),str(r.get('TEAM','')),str(r.get('OPP','')),str(r.get('FPTS',''))]))
    return hashlib.sha256('\n'.join(parts).encode()).hexdigest()

def _meta() -> dict[str, Any]:
    if not META_FILE.exists() or not TOP1_MODEL_FILE.exists() or not TOP01_MODEL_FILE.exists():
        raise FileNotFoundError("NFL_CLASSIC_HISTORICAL_FIELD_RANKER_MODEL_MISSING")
    return json.loads(META_FILE.read_text())

def feature_matrix(rows: np.ndarray, pmeta: dict[str, np.ndarray], cal: Any) -> np.ndarray:
    rows = np.asarray(rows, dtype=np.int32)
    raw_player = cal.frame['FPTS'].to_numpy(float)
    p99_player = np.asarray(cal.p99, dtype=float)
    own = np.clip(np.asarray(cal.ownership, dtype=float), .0005, .98)
    opportunity = np.asarray(cal.strategy.opportunity_score, dtype=float)
    own_rows = own[rows]
    return np.column_stack([
        np.asarray(pmeta['raw_projection'], dtype=float),
        np.asarray(cal.p95, dtype=float)[rows].sum(axis=1),
        p99_player[rows].sum(axis=1),
        np.asarray(pmeta['market_quality'], dtype=float),
        opportunity[rows].sum(axis=1),
        np.log(own_rows).sum(axis=1),
        np.asarray(pmeta['salary'], dtype=float) / 1000.0,
        np.asarray(pmeta['same_pass'], dtype=float),
        np.asarray(pmeta['bringback'], dtype=float),
        np.asarray(pmeta['same_rb'], dtype=float),
        np.asarray(pmeta['game_count'], dtype=float),
        np.asarray(pmeta['max_game_count'], dtype=float),
        np.asarray(pmeta['qb_game_count'], dtype=float),
        np.asarray(pmeta['team_count'], dtype=float),
        raw_player[rows].min(axis=1), raw_player[rows].max(axis=1), raw_player[rows].std(axis=1),
        p99_player[rows].min(axis=1), p99_player[rows].max(axis=1), p99_player[rows].std(axis=1),
        np.asarray(pmeta['player_rec_sum'], dtype=float),
        np.asarray(pmeta['player_rec_min'], dtype=float),
        np.asarray(pmeta['player_rec_max'], dtype=float),
        np.asarray(pmeta['core_rec_max'], dtype=float),
        np.asarray(pmeta['core_rec_sum'], dtype=float),
        np.asarray(pmeta['mean_pair_corr'], dtype=float),
        np.asarray(pmeta['market_quality'], dtype=float),
        np.asarray(pmeta['score'], dtype=float),
        (own_rows < .10).sum(axis=1),
        (own_rows < .05).sum(axis=1),
        own_rows.sum(axis=1),
    ]).astype(np.float64)

def _predict_components(rows: np.ndarray, pmeta: dict[str, np.ndarray], cal: Any) -> tuple[np.ndarray, np.ndarray]:
    import joblib
    top01_model = joblib.load(TOP01_MODEL_FILE)
    top1_model = joblib.load(TOP1_MODEL_FILE)
    X = feature_matrix(rows, pmeta, cal)
    p01 = np.asarray(top01_model.predict_proba(X)[:,1], dtype=np.float64)
    p1 = np.asarray(top1_model.predict_proba(X)[:,1], dtype=np.float64)
    return p01, p1

def _z(v: np.ndarray) -> np.ndarray:
    v=np.asarray(v,dtype=np.float64)
    sd=float(np.std(v))
    return (v-float(np.mean(v)))/(sd if sd>1e-12 else 1.0)

def championship_head_order(rows: np.ndarray, pmeta: dict[str, np.ndarray], cal: Any, anchor_index: int = 0, head_size: int = 5) -> tuple[np.ndarray, dict[str, Any]]:
    """Reorder only the championship head; membership remains unchanged.

    Seat 1 is immutable. Seats 2-5 must come from the top quartile of Top-0.1
    probability on the already-selected board. Within that elite neighborhood,
    a shrinkage score balances Top-1 stability against ownership and raw-ceiling
    concentration, reducing optimizer's-curse siblings without weakening the
    championship anchor.
    """
    rows=np.asarray(rows,dtype=np.int32)
    n=len(rows)
    if n<=1 or head_size<=1:
        return np.arange(n,dtype=np.int32), {"PATCH_ID":TOP5_HEAD_PATCH_ID,"STATUS":"HEAD_NOOP","HEAD_SIZE":min(n,head_size)}
    p01,p1=_predict_components(rows,pmeta,cal)
    own=np.clip(np.asarray(cal.ownership,dtype=np.float64),0.0005,0.98)
    ownsum=own[rows].sum(axis=1)
    if "Ceil" in cal.frame.columns:
        ceil_player=cal.frame["Ceil"].to_numpy(float)
    else:
        ceil_player=np.asarray(cal.p99,dtype=float)
    ceilsum=ceil_player[rows].sum(axis=1)
    threshold=float(np.quantile(p01,0.75))
    all_nonanchor=np.asarray([i for i in range(n) if i!=int(anchor_index)],dtype=np.int32)
    eligible=all_nonanchor[p01[all_nonanchor]>=threshold]
    need=min(max(0,int(head_size)-1),n-1)
    if len(eligible)<need:
        order01=np.argsort(p01[all_nonanchor],kind="stable")[::-1]
        eligible=all_nonanchor[order01[:max(need,len(eligible))]]
    # Standardize on the full non-anchor board, then apply only inside the elite Top-0.1 neighborhood.
    z01=np.zeros(n,dtype=np.float64); z1=np.zeros(n,dtype=np.float64); zown=np.zeros(n,dtype=np.float64); zceil=np.zeros(n,dtype=np.float64)
    z01[all_nonanchor]=_z(p01[all_nonanchor]); z1[all_nonanchor]=_z(p1[all_nonanchor])
    zown[all_nonanchor]=_z(ownsum[all_nonanchor]); zceil[all_nonanchor]=_z(ceilsum[all_nonanchor])
    head_score=np.full(n,-np.inf,dtype=np.float64)
    head_score[eligible]=(z01[eligible] + 0.50*z1[eligible] - 0.50*zown[eligible] - 0.25*zceil[eligible])
    picks=eligible[np.argsort(head_score[eligible],kind="stable")[::-1][:need]]
    seen={int(anchor_index),*(int(x) for x in picks.tolist())}
    remainder=[i for i in range(n) if i not in seen]
    order=np.asarray([int(anchor_index),*(int(x) for x in picks.tolist()),*remainder],dtype=np.int32)
    return order,{
        "PATCH_ID":TOP5_HEAD_PATCH_ID,
        "STATUS":"ACTIVE_TOP01_QUARTILE_HEAD_SHRINKAGE",
        "ANCHOR_INDEX":int(anchor_index),
        "HEAD_SIZE":int(min(head_size,n)),
        "TOP01_ELIGIBILITY_QUANTILE":0.75,
        "TOP01_WEIGHT":1.00,
        "TOP1_STABILITY_WEIGHT":0.50,
        "OWNERSHIP_SHRINKAGE_WEIGHT":0.50,
        "RAW_CEILING_SHRINKAGE_WEIGHT":0.25,
        "ELIGIBLE_COUNT":int(len(eligible)),
        "HEAD_ORDER":order[:min(head_size,n)].tolist(),
    }

def score(rows: np.ndarray, pmeta: dict[str, np.ndarray], cal: Any) -> tuple[np.ndarray | None, dict[str, Any]]:
    try:
        meta = _meta()
    except FileNotFoundError:
        return None, {"PATCH_ID": PATCH_ID, "STATUS": "MODEL_MISSING"}
    p01,p1 = _predict_components(rows,pmeta,cal)
    def _pct(v: np.ndarray) -> np.ndarray:
        order = np.argsort(v, kind="stable")
        out = np.empty(len(v), dtype=np.float64)
        out[order] = (np.arange(len(v), dtype=np.float64) + 1.0) / max(len(v), 1)
        return out
    pred = TOP01_BLEND_WEIGHT * _pct(p01) + TOP1_BLEND_WEIGHT * _pct(p1)
    return pred, {
        "PATCH_ID": PATCH_ID,
        "STATUS": "ACTIVE_DUAL_TAIL_HISTORICAL_ALWAYS_ON",
        "TRAINING_CONTESTS": meta.get('training_contests'),
        "TRAINING_FIELD_ROWS": meta.get('training_field_rows'),
        "TRAINING_TARGETS": meta.get('training_targets'),
        "TOP01_BLEND_WEIGHT": TOP01_BLEND_WEIGHT,
        "TOP1_BLEND_WEIGHT": TOP1_BLEND_WEIGHT,
        "HISTORICAL_WEIGHT": HISTORICAL_WEIGHT,
        "SAME_SLATE_GUARD": False,
        "VALIDATION": meta.get('validation'),
    }
