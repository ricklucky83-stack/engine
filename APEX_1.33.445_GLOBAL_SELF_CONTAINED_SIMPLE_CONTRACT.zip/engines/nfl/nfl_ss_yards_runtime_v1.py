#!/usr/bin/env python3
from __future__ import annotations

import hashlib, json, math, os, sys
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from engines.common import apex_terminal_ai_hybrid_selector_v6 as terminal_ai
from engines.nfl.nfl_ss_yards_mode_specific_ownership_v1 import derive_shadow_ownership
from engines.nfl.nfl_ss_yards_calibration_qualified_birth_v1 import phase1_birth
from engines.nfl.nfl_ss_yards_20max_selector_v2 import select_20max, SelectorConfig

PATCH_ID="NFL_SS_YARDS_STAT_NATIVE_WORLD_v1"
BIRTH_PATCH_ID="NFL_SS_YARDS_CALIBRATION_QUALIFIED_WORLD_BIRTH_v1"
SELECTOR_PATCH_ID="NFL_SS_YARDS_20MAX_FIELD_RELATIVE_PLUS_DOUBLE_SECONDARY_v2"
ENGINE_ID="APEX_NFL_SS_YARDS_CHUNK_STREAM_RUNTIME_v1"
MODE_ID="DK_NFL_SINGLE_STAT_YARDS"
ROSTER_SIZE=3
ELIGIBLE=frozenset({"RB","WR","TE","FB"})
HARD_OUT=frozenset({"OUT","IR","INACTIVE","CONFIRMED_OUT","DNP","DOUBTFUL"})


def _norm(x): return " ".join(str(x or "").strip().upper().replace("_"," ").split())
def _num(v):
    try:
        s=str(v).replace(",","").replace("%","").strip()
        if s in {"","-","nan","None","N/A","NA"}: return float("nan")
        return float(s)
    except Exception:return float("nan")
def _pos(v):
    s=_norm(v).replace("/"," ").replace("-"," ")
    for p in ("QB","RB","WR","TE","FB","K","P","LS","DST","DEF"):
        if p in s.split(): return p
    return s.split()[0] if s.split() else "UNKNOWN"
def _sha(p:Path): return hashlib.sha256(p.read_bytes()).hexdigest()
def _atomic_json(path:Path,obj):
    tmp=path.with_suffix(path.suffix+".tmp"); tmp.write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n"); os.replace(tmp,path)

def _first(df, aliases):
    cmap={_norm(c):c for c in df.columns}
    for a in aliases:
        if _norm(a) in cmap:return cmap[_norm(a)]
    return None

def _series_num(df, aliases):
    c=_first(df,aliases)
    if not c:return np.full(len(df),np.nan)
    return np.array([_num(x) for x in df[c]],dtype=float)

def _prepare(pool:Path):
    raw=pd.read_csv(pool).copy()
    pc=_first(raw,("PLAYER","PLAYER NAME","NAME")); posc=_first(raw,("POS","POSITION")); tc=_first(raw,("TEAM",))
    if not pc or not posc or not tc: raise RuntimeError("RUN_INVALID:NFL_SS_YARDS_REQUIRED_POOL_FIELDS")
    statusc=_first(raw,("STATUS","INJURY STATUS","ROLE_STATUS","INJ"))
    rows=[]; qb=[]; non=[]; out=[]; zero=[]; dup=0
    for name,g in raw.groupby(raw[pc].astype(str).str.strip(),sort=False):
        if not name or name.lower()=="nan": continue
        dup += max(0,len(g)-1)
        positions={_pos(x) for x in g[posc]}
        if "QB" in positions: qb.append(name); continue
        p=next((x for x in ("RB","WR","TE","FB") if x in positions),next(iter(positions),"UNKNOWN"))
        if p not in ELIGIBLE: non.append(name); continue
        if statusc:
            sts={_norm(x) for x in g[statusc]}
            if any(x in HARD_OUT for x in sts): out.append(name); continue
        team=str(g.iloc[0][tc]).strip().upper()
        # Target stat authority: explicit rushing + receiving yard lines first; historical yard columns only as fallback.
        ru=_series_num(g,("O/U RUYD","RUSH YARDS PROP","RUSH YDS PROP"))
        reyd=_series_num(g,("O/U REYD","RECEIVING YARDS PROP","REC YDS PROP"))
        hru=_series_num(g,("L8 Rush Yds","Rush Yds","AVG Rush Yds"))
        hre=_series_num(g,("L8 Rec Yds","Rec Yds","AVG Rec Yds"))
        def best(a,b):
            av=a[np.isfinite(a)]; bv=b[np.isfinite(b)]
            if len(av): return float(np.max(av))
            if len(bv): return float(np.max(bv))
            return 0.0
        rush=best(ru,hru); rec=best(reyd,hre); mean=max(0.0,rush)+max(0.0,rec)
        if mean<=0: zero.append(name); continue
        rows.append({"PLAYER":name,"POS":p,"TEAM":team,"RUSH_YARD_MEAN":rush,"REC_YARD_MEAN":rec,"YARD_MEAN":mean})
    df=pd.DataFrame(rows).reset_index(drop=True)
    if len(df)<3: raise RuntimeError("RUN_INVALID:NFL_SS_YARDS_ACTIVE_POOL_LT3")
    # bring source ownership/projection columns back by player for recovered ownership model only
    src=raw.drop_duplicates(subset=[pc]).set_index(raw.drop_duplicates(subset=[pc])[pc].astype(str).str.strip())
    for c in ("FPTS","Ceil","RST%","O/U RUYD","O/U REYD"):
        if c in raw.columns: df[c]=[src.at[n,c] if n in src.index else np.nan for n in df.PLAYER]
    own=derive_shadow_ownership(df.copy())
    if float(own["NFL_SS_YARDS_EXPECTED_OWNERSHIP"].sum())<=0: raise RuntimeError("RUN_INVALID:NFL_SS_YARDS_OWNERSHIP_ZERO")
    df["INTERNAL_OWN"]=(own["NFL_SS_YARDS_EXPECTED_OWNERSHIP"].to_numpy(float)/100.0)
    return df,{"QB_PURGE":qb,"NONELIGIBLE_PURGE":non,"OUT_PURGE":out,"ZERO_ROLE_PURGE":zero,"DUPLICATE_ROWS_REMOVED":dup}

def _simulate(df:pd.DataFrame,trials:int,seed:int):
    rng=np.random.default_rng(seed); n=len(df); out=np.zeros((n,trials),dtype=np.float32)
    team_lat={t:rng.lognormal(mean=-.5*.16**2,sigma=.16,size=trials).astype(np.float32) for t in df.TEAM.unique()}
    pos_cv={"RB":.45,"WR":.58,"TE":.55,"FB":.70}
    for i,r in df.iterrows():
        cv=pos_cv.get(r.POS,.58); sigma=math.sqrt(math.log1p(cv*cv)); mu=-.5*sigma*sigma
        idio=rng.lognormal(mu,sigma,size=trials).astype(np.float32)
        # small zero-yard role-failure mass; decreases with projected yard opportunity
        p0=float(np.clip(.22*math.exp(-float(r.YARD_MEAN)/35.0),.01,.18))
        live=(rng.random(trials)>=p0).astype(np.float32)
        out[i]=float(r.YARD_MEAN)*team_lat[r.TEAM]*idio*live
    return out

def _sample_field(weights, count, seed):
    rng=np.random.default_rng(seed); w=np.asarray(weights,float); w=w/w.sum(); n=len(w)
    ids=np.empty((count,3),dtype=np.int32)
    for j in range(count):
        # exact weighted sequential draw without replacement; no legal-lattice enumeration
        avail=np.ones(n,dtype=bool)
        for k in range(3):
            q=w*avail; q=q/q.sum(); x=int(rng.choice(n,p=q)); ids[j,k]=x; avail[x]=False
    return ids

def _entry_limit():
    raw=os.environ.get("APEX_ENTRY_LIMIT_PROFILE_JSON")
    if raw:
        try:
            j=json.loads(raw)
            for k in ("user_entries","max_entries","entry_limit","MAX_ENTRIES"):
                if j.get(k): return int(j[k])
        except Exception: pass
    for k in ("APEX_MAX_ENTRIES","APEX_ENTRY_LIMIT","APEX_MAX_ENTRY"):
        if os.environ.get(k): return int(os.environ[k])
    if os.environ.get("APEX_TEST_MODE")=="1": return 20
    raise RuntimeError("RUN_INVALID:NFL_SS_YARDS_ENTRY_LIMIT_REQUIRED")

def _greedy(lineups,top01,top1,q999,dups,k):
    sel=[]; rem=set(range(len(lineups))); c01=np.zeros(top01.shape[1],bool); c1=np.zeros(top1.shape[1],bool)
    for _ in range(min(k,len(rem))):
        j=max(rem,key=lambda x:(np.logical_and(top01[x],~c01).sum()*3+np.logical_and(top1[x],~c1).sum(),q999[x],-dups[x]))
        sel.append(j); rem.remove(j); c01|=top01[j]; c1|=top1[j]
    return sel

def main():
    pr=os.environ.get("APEX_PLAYER_POOL","")
    if not pr: raise RuntimeError("RUN_INVALID:NFL_SS_YARDS_PLAYER_POOL_REQUIRED")
    pool=Path(pr).resolve(); field_size=int(os.environ.get("APEX_FIELD_SIZE","0") or 0)
    if field_size<=0: raise RuntimeError("RUN_INVALID:NFL_SS_YARDS_FIELD_SIZE_REQUIRED")
    if os.environ.get("APEX_CHUNK_STREAM_ONLY")!="1" and os.environ.get("APEX_TEST_MODE")!="1": raise RuntimeError("RUN_INVALID:NFL_SS_YARDS_CHUNK_STREAM_ONLY_REQUIRED")
    entry_limit=_entry_limit(); trials=int(os.environ.get("APEX_SS_YARDS_MC_SIMS","20000") or 20000)
    if os.environ.get("APEX_TEST_MODE")!="1" and trials<10000: raise RuntimeError("ENGINE_INTEGRITY_HALT:NFL_SS_YARDS_MC_TRIALS_LT_10000")
    trials=max(1000,trials) if os.environ.get("APEX_TEST_MODE")=="1" else trials
    exec_id=os.environ.get("APEX_EXECUTION_ID","UNSET"); outdir=Path(os.environ.get("APEX_OUTPUT_DIR","/mnt/data")).resolve(); outdir.mkdir(parents=True,exist_ok=True)
    seed=int(os.environ.get("APEX_SEED") or hashlib.sha256(f"{exec_id}|{_sha(pool)}|SS_YARDS".encode()).hexdigest()[:8],16)
    df,prep=_prepare(pool); yards=_simulate(df,trials,seed)
    if not np.isfinite(yards).all() or float(yards.sum())<=0: raise RuntimeError("ENGINE_INTEGRITY_HALT:NFL_SS_YARDS_SIM_INVALID")
    lineups,lanes,birth=phase1_birth(df,yards)
    L=np.asarray(lineups,dtype=np.int32); scores=yards[L].sum(axis=1)
    sample_n=min(max(field_size,512),5000); field_ids=_sample_field(df.INTERNAL_OWN.to_numpy(float),sample_n,seed+17); field_scores=yards[field_ids].sum(axis=1)
    top01=np.zeros((len(L),trials),dtype=bool); top1=np.zeros_like(top01); win=np.zeros_like(top01)
    q999=np.quantile(scores,.999,axis=1); dups=np.zeros(len(L),float)
    # sampled public-field identity duplication estimate
    from collections import Counter
    fc=Counter(tuple(sorted(map(int,x))) for x in field_ids)
    for i,tri in enumerate(lineups): dups[i]=fc.get(tuple(tri),0)*field_size/sample_n
    for a in range(0,trials,256):
        b=min(trials,a+256); fs=field_scores[:,a:b]
        k01=max(1,int(math.ceil(sample_n*.001))); k1=max(1,int(math.ceil(sample_n*.01)))
        t01=np.partition(fs,fs.shape[0]-k01,axis=0)[fs.shape[0]-k01]
        t1=np.partition(fs,fs.shape[0]-k1,axis=0)[fs.shape[0]-k1]
        mx=fs.max(axis=0)
        s=scores[:,a:b]; top01[:,a:b]=s>=t01; top1[:,a:b]=s>=t1; win[:,a:b]=s>=mx
    if entry_limit==20:
        sel=select_20max(L,df.YARD_MEAN.to_numpy(float),df.INTERNAL_OWN.to_numpy(float),top01,top1,q999,dups,SelectorConfig(portfolio_size=20))
        lane="FIELD_RELATIVE_20MAX_PLUS_DOUBLE_SECONDARY"
    else:
        sel=_greedy(L,top01,top1,q999,dups,entry_limit); lane="FIELD_RELATIVE_MARGINAL_COVERAGE"
    rank_order=sorted(range(len(L)),key=lambda i:(-(3*top01[i].mean()+top1[i].mean()+.002*q999[i]),dups[i],i)); rank={j:i+1 for i,j in enumerate(rank_order)}
    selected=set(sel)
    rows=[]
    for i,tri in enumerate(lineups):
        names=[df.at[x,"PLAYER"] for x in tri]; s=scores[i]
        rows.append({"LINEUP_ID":f"NFL_SS_YARDS_{i+1:07d}","UTIL1":names[0],"UTIL2":names[1],"UTIL3":names[2],"PLAYERS":"|".join(names),"BIRTH_LANES":"|".join(sorted(lanes[tri])),"CALIBRATION_QUALIFIED_BIRTH":1,"MC_WIN_RATE":float(win[i].mean()),"MC_TOP_0_1_RATE":float(top01[i].mean()),"MC_TOP_1_RATE":float(top1[i].mean()),"MC_P95":float(np.quantile(s,.95)),"MC_P99":float(np.quantile(s,.99)),"Q999":float(q999[i]),"MC_MEAN":float(s.mean()),"MC_TRIALS":trials,"EXPECTED_DUPLICATES":float(dups[i]),"OWNERSHIP_PRODUCT":float(np.prod(df.INTERNAL_OWN.to_numpy(float)[list(tri)])),"CURRENT_SELECTOR_RANK":rank[i],"CURRENT_SELECTOR_SELECTED":int(i in selected),"FIELD_SIZE":field_size,"ENTRY_LIMIT":entry_limit,"SELECTION_LANE":lane})
    surf=pd.DataFrame(rows); surface=outdir/f"DK_NFL_SS_YARDS_{exec_id}_AI_TERMINAL_CANDIDATES.csv"; surf.to_csv(surface,index=False)
    scan=terminal_ai.scan_candidate_csv(surface)
    native=surf.loc[[i in selected for i in range(len(surf))]].sort_values("CURRENT_SELECTOR_RANK").head(entry_limit)
    native_path=outdir/f"DK_NFL_SS_YARDS_{exec_id}_NATIVE_REVIEW_BOARD.csv"; native.to_csv(native_path,index=False)
    receipt={"RUN_STATUS":"PASS","EXECUTION_STATE":"TOOL_PROVEN_EXECUTED","RUN_STATE":"NATIVE_BOARD_READY_FOR_GLOBAL_CORE5","PATCH_ID":PATCH_ID,"BIRTH_PATCH_ID":BIRTH_PATCH_ID,"SELECTOR_PATCH_ID":SELECTOR_PATCH_ID,"ENGINE_ID":ENGINE_ID,"SPORT":"NFL","MODE":"SS_YARDS","MODE_ID":MODE_ID,"EXECUTION_ID":exec_id,"POOL_SHA256":_sha(pool),"ACTIVE_POOL":len(df),"QB_PURGE":prep["QB_PURGE"],"OUT_PURGE":prep["OUT_PURGE"],"NONELIGIBLE_POSITION_PURGE":prep["NONELIGIBLE_PURGE"],"ZERO_ROLE_PURGE":prep["ZERO_ROLE_PURGE"],"QB_ALLOWED":False,"K_DST_ALLOWED":False,"PASSING_YARDS_AUTHORITY":False,"YARD_STAT_AUTHORITY":"RUSHING_PLUS_RECEIVING_ONLY","SALARY_CAP":None,"PHASE1_BEFORE_BIRTH":True,"PHASE2_BUILT_LINEUPS":len(lineups),"SELECTOR_REVIEWED_LINEUPS":int(scan["CANDIDATE_COUNT"]),"BASE_SIM_TRIALS":trials,"FAKE_FIELD_LINEUPS":field_size,"FIELD_SAMPLE_IDENTITIES":sample_n,"CALIBRATION_QUALIFIED_BIRTH_CERTIFIED":True,"UNQUALIFIED_CANDIDATE_BIRTH_ALLOWED":False,"FULL_LEGAL_UNIVERSE_ENUMERATION_ALLOWED":False,"PRE_PHASE2_RAW_LATTICE_MATERIALIZATION_ALLOWED":False,"PROVIDER_RST_AUTHORITY":False,"MODE_SPECIFIC_OWNERSHIP_PATCH":"NFL_SS_YARDS_MODE_SPECIFIC_OWNERSHIP_v1","AI_TERMINAL_AUTHORITY_REQUIRED":True,"AI_TERMINAL_CANDIDATE_SURFACE_PATH":str(surface),"AI_TERMINAL_CANDIDATE_COUNT":int(scan["CANDIDATE_COUNT"]),"NATIVE_REVIEW_BOARD_PATH":str(native_path),"REQUESTED_PORTFOLIO_SIZE":entry_limit,"FINAL_BOARD_SIZE":len(native),"GLOBAL_FINAL_PLAYABLE_CORE5_PENDING":True,"POSTLOCK_RESULTS_USED":False,"FPTS_USED_IN_SCORING_MODEL":False,"BIRTH":birth,"FINAL_BOARD":native.to_dict("records")}
    rp=outdir/f"DK_NFL_SS_YARDS_{exec_id}_FINAL_RECEIPT.json"; _atomic_json(rp,receipt)
    hand={k:receipt[k] for k in ("RUN_STATE","EXECUTION_STATE","PATCH_ID","ENGINE_ID","SPORT","MODE","EXECUTION_ID","PHASE2_BUILT_LINEUPS","SELECTOR_REVIEWED_LINEUPS","BASE_SIM_TRIALS","FAKE_FIELD_LINEUPS","REQUESTED_PORTFOLIO_SIZE")}; hand.update({"AI_TERMINAL_CANDIDATE_SURFACE_PATH":str(surface),"NATIVE_REVIEW_BOARD_PATH":str(native_path),"FINAL_BOARD_SIZE":len(native),"FINAL_BOARD":native.to_dict("records"),"PRODUCTION_RECEIPT_PATH":str(rp),"GLOBAL_FINAL_PLAYABLE_CORE5_PENDING":True})
    print(json.dumps(hand,sort_keys=True,separators=(",",":")),flush=True); return 0

if __name__=="__main__":
    try: raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({"RUN_STATE":"RUN_INVALID","EXECUTION_STATE":"FAILED","PATCH_ID":PATCH_ID,"ENGINE_ID":ENGINE_ID,"SPORT":"NFL","MODE":"SS_YARDS","FAILURE_CODE":f"{type(exc).__name__}:{exc}","FINAL_BOARD_SIZE":0},sort_keys=True),flush=True); raise
