from __future__ import annotations

"""Chronological NFL Showdown ownership model (shadow until promotion gate passes).

This module predicts DraftKings Showdown total inclusion, Captain, and FLEX ownership
from pre-lock player/slate features.  Post-lock ownership is accepted only in historical
training ledgers.  The provider RST% column can be tested as an optional feature, but it
is never copied, renormalized, or used as direct output authority.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
import json
import numpy as np
import pandas as pd

PATCH_ID = "NFL_SHOWDOWN_CHRONOLOGICAL_SELF_OWNERSHIP_MODEL_v3_SHADOW"
MIN_TRAIN_CONTESTS = 3
RIDGE_L2 = 2.0
EPS = 1e-5

_POSITIONS = ("QB", "RB", "WR", "TE", "K", "DST")
_BASE_NUMERIC = (
    "FPTS", "Ceil", "Floor", "VAL", "SAL", "TM Score", "O/U", "SPRD",
    "SNAPS", "ROUTES", "TARGETS", "CARRIES", "RED_ZONE_OPPORTUNITY",
    "MULTI_PATH_CEILING",
)


def _num(df: pd.DataFrame, col: str) -> np.ndarray:
    if col not in df.columns:
        return np.zeros(len(df), dtype=np.float64)
    return pd.to_numeric(df[col], errors="coerce").fillna(0.0).to_numpy(np.float64)


def _rank01(v: np.ndarray) -> np.ndarray:
    v = np.asarray(v, dtype=np.float64)
    out = np.zeros(len(v), dtype=np.float64)
    if len(v) == 0:
        return out
    order = np.argsort(v, kind="stable")
    out[order] = (np.arange(len(v), dtype=np.float64) + 0.5) / len(v)
    return out


def _position(df: pd.DataFrame) -> np.ndarray:
    if "POS_BASE" in df.columns:
        return df["POS_BASE"].astype(str).str.upper().to_numpy(object)
    if "POS" in df.columns:
        return df["POS"].astype(str).str.split("/").str[0].str.upper().to_numpy(object)
    return np.full(len(df), "UNK", dtype=object)


def build_feature_matrix(df: pd.DataFrame, *, include_provider_prior: bool = False) -> tuple[np.ndarray, list[str]]:
    """Player-slate features only. All continuous features are slate-relative ranks."""
    cols: list[np.ndarray] = [np.ones(len(df), dtype=np.float64)]
    names = ["INTERCEPT"]
    for col in _BASE_NUMERIC:
        vals = _num(df, col)
        # Salary/spread can be signed/non-opportunity; rank is still well-defined.
        cols.append(_rank01(vals))
        names.append(f"RANK_{col}")
    pos = _position(df)
    for p in _POSITIONS:
        cols.append((pos == p).astype(np.float64))
        names.append(f"POS_{p}")
    if "Home?" in df.columns:
        home = df["Home?"].astype(str).str.lower().isin(["yes", "true", "1"]).to_numpy(np.float64)
    else:
        home = np.zeros(len(df), dtype=np.float64)
    cols.append(home); names.append("HOME")
    # Explicit viability prevents zero-projection backups/inactives from receiving a
    # large ownership prior simply because they share a position with starters.
    fpts = _num(df, "FPTS")
    ceil = _num(df, "Ceil")
    viable = ((fpts > 0.0) | (ceil > 0.0) | np.isin(pos, ["K", "DST"])).astype(np.float64)
    cols.append(viable); names.append("PRELOCK_VIABLE")
    if include_provider_prior:
        provider = _num(df, "RST%")
        cols.append(_rank01(provider)); names.append("PROVIDER_RST_RANK_OPTIONAL")
    return np.column_stack(cols).astype(np.float64), names


def _logit(y: np.ndarray) -> np.ndarray:
    y = np.clip(np.asarray(y, dtype=np.float64), EPS, 1.0 - EPS)
    return np.log(y / (1.0 - y))


def _sigmoid(z: np.ndarray) -> np.ndarray:
    z = np.clip(np.asarray(z, dtype=np.float64), -30.0, 30.0)
    return 1.0 / (1.0 + np.exp(-z))


def _ridge_fit(x: np.ndarray, y: np.ndarray, l2: float = RIDGE_L2) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64); y = np.asarray(y, dtype=np.float64)
    reg = np.eye(x.shape[1], dtype=np.float64) * float(l2)
    reg[0, 0] = 0.0  # do not regularize intercept
    return np.linalg.solve(x.T @ x + reg, x.T @ y)


def _capped_normalize(weights: np.ndarray, target: float, cap: np.ndarray | float) -> np.ndarray:
    w = np.maximum(np.asarray(weights, dtype=np.float64), 1e-12)
    capv = np.full(len(w), float(cap), dtype=np.float64) if np.isscalar(cap) else np.asarray(cap, dtype=np.float64)
    out = np.zeros(len(w), dtype=np.float64)
    free = np.ones(len(w), dtype=bool)
    remaining = float(target)
    for _ in range(len(w) + 4):
        if not free.any() or remaining <= 1e-12:
            break
        wf = w[free]
        alloc = remaining * wf / max(wf.sum(), 1e-12)
        idx = np.flatnonzero(free)
        hit = alloc >= capv[idx] - 1e-12
        if not hit.any():
            out[idx] = alloc
            remaining = 0.0
            break
        hit_idx = idx[hit]
        out[hit_idx] = capv[hit_idx]
        remaining -= float(out[hit_idx].sum())
        free[hit_idx] = False
    if remaining > 1e-8 and free.any():
        idx = np.flatnonzero(free)
        out[idx] += remaining * w[idx] / max(w[idx].sum(), 1e-12)
    return out


@dataclass(frozen=True)
class OwnershipModel:
    feature_names: tuple[str, ...]
    coef_total: np.ndarray
    coef_cpt: np.ndarray
    include_provider_prior: bool
    train_contests: tuple[str, ...]

    def predict(self, frame: pd.DataFrame) -> pd.DataFrame:
        x, names = build_feature_matrix(frame, include_provider_prior=self.include_provider_prior)
        if tuple(names) != self.feature_names:
            raise ValueError("OWNERSHIP_FEATURE_SCHEMA_MISMATCH")
        total_raw = _sigmoid(x @ self.coef_total)
        cpt_raw = _sigmoid(x @ self.coef_cpt)
        pos = _position(frame)
        viable = ((np.maximum(_num(frame, "FPTS"), _num(frame, "Ceil")) > 0.0) | np.isin(pos, ["K", "DST"]))
        total_raw = np.where(viable, total_raw, 1e-7)
        cpt_raw = np.where(viable, cpt_raw, 1e-8)
        total = _capped_normalize(total_raw, 6.0, 0.98)
        cpt = _capped_normalize(cpt_raw, 1.0, total)
        flex = total - cpt
        out = frame.copy()
        out["OWN_TOTAL_MODEL"] = total
        out["OWN_CPT_MODEL"] = cpt
        out["OWN_FLEX_MODEL"] = flex
        return out

    def receipt(self) -> dict:
        return {
            "PATCH_ID": PATCH_ID,
            "STATUS": "SHADOW_CHRONOLOGICAL_MODEL",
            "TRAIN_CONTESTS": list(self.train_contests),
            "TRAIN_CONTEST_COUNT": len(self.train_contests),
            "INCLUDE_PROVIDER_PRIOR_AS_FEATURE": bool(self.include_provider_prior),
            "PROVIDER_DIRECT_AUTHORITY": False,
            "TARGET_MASS_TOTAL": 6.0,
            "TARGET_MASS_CPT": 1.0,
            "TARGET_MASS_FLEX": 5.0,
        }


def fit_model(ledger: pd.DataFrame, *, include_provider_prior: bool = False, min_contests: int = MIN_TRAIN_CONTESTS) -> OwnershipModel:
    required = {"CONTEST_ID", "ACTUAL_TOTAL_OWN", "ACTUAL_CPT_OWN"}
    missing = sorted(required - set(ledger.columns))
    if missing:
        raise ValueError(f"OWNERSHIP_LEDGER_MISSING_COLUMNS:{','.join(missing)}")
    contests = tuple(sorted(map(str, ledger["CONTEST_ID"].dropna().unique().tolist())))
    if len(contests) < int(min_contests):
        raise ValueError(f"OWNERSHIP_CALIBRATION_INSUFFICIENT_CONTESTS:{len(contests)}<{min_contests}")
    x, names = build_feature_matrix(ledger, include_provider_prior=include_provider_prior)
    y_total = _logit(pd.to_numeric(ledger["ACTUAL_TOTAL_OWN"], errors="coerce").fillna(0.0).to_numpy(float))
    y_cpt = _logit(pd.to_numeric(ledger["ACTUAL_CPT_OWN"], errors="coerce").fillna(0.0).to_numpy(float))
    return OwnershipModel(tuple(names), _ridge_fit(x, y_total), _ridge_fit(x, y_cpt), bool(include_provider_prior), contests)


def evaluate(pred: pd.DataFrame) -> dict:
    metrics = {}
    for pred_col, actual_col, tag in [
        ("OWN_TOTAL_MODEL", "ACTUAL_TOTAL_OWN", "TOTAL"),
        ("OWN_CPT_MODEL", "ACTUAL_CPT_OWN", "CPT"),
        ("OWN_FLEX_MODEL", "ACTUAL_FLEX_OWN", "FLEX"),
    ]:
        if actual_col not in pred.columns:
            continue
        a = pd.to_numeric(pred[actual_col], errors="coerce").fillna(0.0).to_numpy(float)
        p = pd.to_numeric(pred[pred_col], errors="coerce").fillna(0.0).to_numpy(float)
        e = p - a
        metrics[f"{tag}_MAE_PP"] = float(np.mean(np.abs(e)) * 100.0)
        metrics[f"{tag}_RMSE_PP"] = float(np.sqrt(np.mean(e * e)) * 100.0)
        metrics[f"{tag}_MASS_PRED"] = float(np.sum(p))
        metrics[f"{tag}_MASS_ACTUAL"] = float(np.sum(a))
    return metrics


def load_ledger(folder: str | Path) -> pd.DataFrame:
    paths = sorted(Path(folder).glob("*.csv"))
    if not paths:
        return pd.DataFrame()
    return pd.concat([pd.read_csv(p) for p in paths], ignore_index=True, sort=False)
