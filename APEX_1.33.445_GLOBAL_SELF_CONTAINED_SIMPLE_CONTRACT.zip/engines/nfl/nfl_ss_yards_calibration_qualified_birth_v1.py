from __future__ import annotations

import math
from collections import Counter
from typing import Any

import numpy as np
import pandas as pd

PATCH_ID = "NFL_SS_YARDS_CALIBRATION_QUALIFIED_WORLD_BIRTH_v1"
ROSTER_SIZE = 3


def _add(births: dict[tuple[int,int,int], set[str]], ids, lane: str) -> None:
    key=tuple(sorted(int(x) for x in ids))
    if len(key)==3 and len(set(key))==3:
        births.setdefault(key,set()).add(lane)


def phase1_birth(df: pd.DataFrame, yards: np.ndarray, max_candidates: int = 5000):
    n,trials=yards.shape
    if n < 3:
        raise RuntimeError("RUN_INVALID:NFL_SS_YARDS_ACTIVE_POOL_LT3")
    means=yards.mean(axis=1)
    q95=np.quantile(yards,.95,axis=1)
    q99=np.quantile(yards,.99,axis=1)
    strength=.45*means+.25*q95+.30*q99
    births: dict[tuple[int,int,int],set[str]]={}
    recur=Counter(); zero=0
    for a in range(0,trials,512):
        b=min(trials,a+512)
        block=yards[:,a:b]
        k=min(4,n)
        top=np.argpartition(block,-k,axis=0)[-k:]
        for j in range(b-a):
            ids=top[:,j]
            ids=ids[np.argsort(block[ids,j])[::-1]]
            best=float(block[ids[:3],j].sum())
            if best <= 0:
                zero+=1; continue
            tri=tuple(sorted(map(int,ids[:3])))
            _add(births,tri,"PHASE1_WORLD_OPTIMAL")
            recur[tri]+=1
            if k==4:
                tol=max(12.0,.06*best)
                alts=((ids[0],ids[1],ids[3]),(ids[0],ids[2],ids[3]),(ids[1],ids[2],ids[3]))
                for alt in alts:
                    sc=float(block[list(alt),j].sum())
                    if sc >= best-tol:
                        _add(births,alt,"PHASE1_NEAR_OPTIMAL")
    order=np.argsort(-strength,kind="stable")
    _add(births,order[:3],"PHASE1_GLOBAL_TAIL_CORE")
    for team,g in df.groupby("TEAM",sort=True):
        ids=g.index.to_numpy(dtype=int)
        if len(ids)>=3:
            ranked=ids[np.argsort(-strength[ids],kind="stable")]
            _add(births,ranked[:3],"PHASE1_TEAM_YARD_CORE")
    pair_counts=Counter()
    for tri,c in recur.items():
        a,b,c3=tri
        for p in ((a,b),(a,c3),(b,c3)): pair_counts[tuple(sorted(p))]+=c
    floor=float(np.quantile(strength,.50))
    for pair,_ in pair_counts.most_common(64):
        used=0
        for third in order:
            third=int(third)
            if third in pair or strength[third] < floor: continue
            _add(births,(pair[0],pair[1],third),"PHASE1_RECURRENT_PAIR_CLOSURE")
            used+=1
            if used>=2: break
    if len(births)>max_candidates:
        scored=[]
        for tri in births:
            r=int(recur.get(tri,0))
            pr=sum(pair_counts.get(tuple(sorted((tri[i],tri[j]))),0) for i,j in ((0,1),(0,2),(1,2)))
            st=float(strength[list(tri)].sum())
            scored.append((r,pr,st,tri))
        keep={x[3] for x in sorted(scored,key=lambda x:(-x[0],-x[1],-x[2],x[3]))[:max_candidates]}
        births={k:v for k,v in births.items() if k in keep}
    if not births:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:NFL_SS_YARDS_NO_CALIBRATION_QUALIFIED_BIRTHS")
    keys=sorted(births)
    theoretical=math.comb(n,3)
    receipt={
        "PATCH_ID":PATCH_ID,
        "CALIBRATION_QUALIFIED_BIRTH_CERTIFIED":True,
        "UNQUALIFIED_CANDIDATE_BIRTH_ALLOWED":False,
        "FULL_LEGAL_UNIVERSE_ENUMERATION_ALLOWED":False,
        "PRE_PHASE2_RAW_LATTICE_MATERIALIZATION_ALLOWED":False,
        "BIRTH_METHOD":"PHASE1_YARD_WORLD_OPTIMAL_NEAR_OPTIMAL_RECURRENT_PAIR",
        "PHASE1_TRIALS":int(trials),
        "THEORETICAL_LEGAL_TRIADS":int(theoretical),
        "CALIBRATION_QUALIFIED_BIRTHS":int(len(keys)),
        "BIRTH_TO_THEORETICAL_RATIO":float(len(keys)/theoretical),
        "ZERO_YARD_WORLDS_SKIPPED":int(zero),
    }
    return keys,births,receipt
