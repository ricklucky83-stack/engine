#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import zipfile
from pathlib import Path
from typing import Any

POOL_REQUIRED = {"PLAYER", "POS", "TEAM", "OPP", "SAL"}
CONTEST_REQUIRED = {"Rank", "Points", "Lineup", "Player", "Roster Position", "FPTS"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def csv_columns(path: Path) -> set[str]:
    import pandas as pd
    return set(pd.read_csv(path, nrows=5).columns.astype(str))


def zip_csv_columns(path: Path) -> tuple[set[str], str]:
    import pandas as pd
    with zipfile.ZipFile(path) as z:
        members = [n for n in z.namelist() if n.lower().endswith(".csv")]
        if not members:
            raise ValueError("NO_CSV_MEMBER")
        member = members[0]
        with z.open(member) as f:
            cols = set(pd.read_csv(f, nrows=5).columns.astype(str))
    return cols, member


def is_classic_pool(path: Path) -> tuple[bool, str]:
    try:
        import pandas as pd
        d = pd.read_csv(path, nrows=200)
        cols = set(d.columns.astype(str))
        if not POOL_REQUIRED.issubset(cols):
            return False, "MISSING_CLASSIC_POOL_COLUMNS"
        pos = d["POS"].astype(str)
        if pos.str.contains("CPTN|CPT", case=False, regex=True).any():
            return False, "SHOWDOWN_MULTIPLIER_POSITION_PRESENT"
        if not pos.str.contains(r"(?:^|/)(?:G|F)(?:/|$)", case=False, regex=True).any():
            return False, "NO_G_OR_F_POSITIONS"
        return True, "PASS"
    except Exception as exc:
        return False, f"READ_ERROR:{type(exc).__name__}:{exc}"


def is_contest(path: Path) -> tuple[bool, str, str | None]:
    try:
        if path.suffix.lower() == ".zip":
            cols, member = zip_csv_columns(path)
        else:
            cols, member = csv_columns(path), None
        if not CONTEST_REQUIRED.issubset(cols):
            return False, "MISSING_CONTEST_COLUMNS", member
        return True, "PASS", member
    except Exception as exc:
        return False, f"READ_ERROR:{type(exc).__name__}:{exc}", None


def resolve(root: Path, name: str | None) -> Path | None:
    if not name:
        return None
    direct = root / name
    if direct.exists():
        return direct
    hits = [p for p in root.rglob(name) if p.is_file()]
    return hits[0] if len(hits) == 1 else None


def field_band(field: int | None) -> str | None:
    if not field:
        return None
    if field < 1000:
        return "SMALL"
    if field < 3000:
        return "MEDIUM"
    return "LARGE"


def pair_hash(pool_hash: str, contest_hash: str) -> str:
    return hashlib.sha256(f"{pool_hash}|{contest_hash}|WNBA_CLASSIC|2G_3F_1UTIL".encode()).hexdigest()


def run(root: Path, reference_ledger: Path, out_dir: Path) -> dict[str, Any]:
    refs = json.loads(reference_ledger.read_text())
    out_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    missing: list[str] = []
    pair_ids: set[str] = set()

    for ref in refs["REFERENCES"]:
        pool = resolve(root, ref.get("POOL_FILE"))
        contest = resolve(root, ref.get("CONTEST_FILE"))
        pool_present = pool is not None
        contest_present = contest is not None
        pool_valid = False
        contest_valid = False
        pool_reason = "NOT_PRESENT"
        contest_reason = "NOT_PRESENT"
        contest_member = None
        pool_digest = None
        contest_digest = None
        digest_match = None

        if pool_present:
            pool_valid, pool_reason = is_classic_pool(pool)
            pool_digest = sha256(pool)
        if contest_present:
            contest_valid, contest_reason, contest_member = is_contest(contest)
            contest_digest = sha256(contest)

        expected_pool = ref.get("POOL_SHA256_EXPECTED")
        expected_pool16 = ref.get("POOL_SHA16_EXPECTED")
        expected_contest = ref.get("CONTEST_SHA256_EXPECTED")
        expected_contest16 = ref.get("CONTEST_SHA16_EXPECTED")
        checks = []
        if expected_pool and pool_digest:
            checks.append(pool_digest == expected_pool)
        if expected_pool16 and pool_digest:
            checks.append(pool_digest.startswith(expected_pool16))
        if expected_contest and contest_digest:
            checks.append(contest_digest == expected_contest)
        if expected_contest16 and contest_digest:
            checks.append(contest_digest.startswith(expected_contest16))
        if checks:
            digest_match = all(checks)

        byte_complete = bool(pool_present and contest_present and pool_valid and contest_valid and digest_match is not False)
        pid = pair_hash(pool_digest, contest_digest) if byte_complete else None
        distinct = bool(pid and pid not in pair_ids)
        if pid:
            pair_ids.add(pid)

        status = "BYTE_COMPLETE_RUNNABLE_RAW_PAIR" if byte_complete else ref["EVIDENCE_CLASS"]
        countable = bool(byte_complete and distinct)
        if ref.get("POOL_FILE") and not pool_present:
            missing.append(ref["POOL_FILE"])
        if ref.get("CONTEST_FILE") and not contest_present:
            missing.append(ref["CONTEST_FILE"])

        rows.append({
            "CASE_ID": ref["CASE_ID"],
            "FIELD_SIZE": ref.get("FIELD_SIZE"),
            "FIELD_BAND": field_band(ref.get("FIELD_SIZE")),
            "POOL_FILE": ref.get("POOL_FILE"),
            "CONTEST_FILE": ref.get("CONTEST_FILE"),
            "POOL_BYTES_PRESENT": pool_present,
            "CONTEST_BYTES_PRESENT": contest_present,
            "POOL_SCHEMA_VALID": pool_valid,
            "CONTEST_SCHEMA_VALID": contest_valid,
            "POOL_VALIDATION": pool_reason,
            "CONTEST_VALIDATION": contest_reason,
            "CONTEST_MEMBER": contest_member,
            "POOL_SHA256": pool_digest,
            "CONTEST_SHA256": contest_digest,
            "EXPECTED_HASH_CHECK": digest_match,
            "PAIR_SHA256": pid,
            "DISTINCT_PAIR": distinct,
            "BYTE_COMPLETE_RUNNABLE": byte_complete,
            "COUNTABLE_LOSO_FOLD": countable,
            "EVIDENCE_CLASS": status,
            "SOURCE": ref.get("SOURCE"),
            "NOTE": ref.get("NOTE"),
        })

    ledger = out_dir / "holdout_acquisition_ledger.csv"
    with ledger.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    byte_pairs = [r for r in rows if r["COUNTABLE_LOSO_FOLD"]]
    bands = sorted({r["FIELD_BAND"] for r in byte_pairs if r["FIELD_BAND"]})
    exact_refs = [r for r in rows if r["EVIDENCE_CLASS"] == "EXACT_RAW_PAIR_REFERENCE_BYTES_MISSING"]
    partial = [r for r in rows if r["EVIDENCE_CLASS"] == "PARTIAL_PAIR_POOL_ONLY"]
    sealed = [r for r in rows if r["EVIDENCE_CLASS"] == "SEALED_LEVEL_B_ARTIFACT"]
    minimum = 5
    inventory = {
        "INVENTORY_ID": "WNBA_CLASSIC_RAW_HOLDOUT_ACQUISITION_v1",
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "ROOT_SCANNED": str(root),
        "REFERENCE_LEDGER": str(reference_ledger),
        "CLASSIC_REFERENCE_CASES": len(rows),
        "BYTE_COMPLETE_DISTINCT_RAW_PAIRS": len(byte_pairs),
        "BYTE_COMPLETE_FIELD_BANDS": bands,
        "EXACT_REFERENCED_PAIRS_BYTES_MISSING": len(exact_refs),
        "PARTIAL_POOL_ONLY_CASES": len(partial),
        "SEALED_LEVEL_B_ARTIFACT_CASES": len(sealed),
        "SHOWDOWN_PAIR_REFERENCES_EXCLUDED": sum(int(x.get("PAIR_COUNT", 0)) for x in refs.get("EXCLUDED_MODE_REFERENCES", [])),
        "LOSO_MINIMUM_PAIRS": minimum,
        "LOSO_PREFERRED_PAIRS": 10,
        "LOSO_PAIR_DEFICIT": max(0, minimum - len(byte_pairs)),
        "LOSO_READY": len(byte_pairs) >= minimum and len(bands) >= 2,
        "PRODUCTION_PROMOTION_ALLOWED": False,
        "PRODUCTION_BOARD_AND_ORDER_FROZEN": True,
        "MISSING_FILES": sorted(set(missing)),
        "ACQUISITION_LEDGER_SHA256": sha256(ledger),
        "ROWS": rows,
    }
    (out_dir / "holdout_inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
    (out_dir / "missing_raw_files.txt").write_text("\n".join(sorted(set(missing))) + ("\n" if missing else ""))
    return inventory


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--reference-ledger", required=True)
    ap.add_argument("--out-dir", required=True)
    args = ap.parse_args()
    result = run(Path(args.root), Path(args.reference_ledger), Path(args.out_dir))
    print(json.dumps({k: result[k] for k in (
        "EXECUTION_STATE", "BYTE_COMPLETE_DISTINCT_RAW_PAIRS",
        "EXACT_REFERENCED_PAIRS_BYTES_MISSING", "PARTIAL_POOL_ONLY_CASES",
        "SEALED_LEVEL_B_ARTIFACT_CASES", "SHOWDOWN_PAIR_REFERENCES_EXCLUDED",
        "LOSO_PAIR_DEFICIT", "LOSO_READY", "PRODUCTION_PROMOTION_ALLOWED",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
