#!/usr/bin/env python3
"""APEX WNBA DraftKings Showdown calibration-first runtime v1.

Production-only, result-blind engine:
- reuses the sealed WNBA role-state/covariance calibration contract;
- builds only after Phase 1 calibration;
- enumerates the complete legal DK CPT+5 universe with a compiled two-pass kernel;
- preserves captain, team-script, salary-release and low-role ceiling families before handoff;
- evaluates every Phase 2 lineup against a public-field Monte Carlo model;
- allocates extra trials to uncertainty-overlapping bubble lineups;
- deep-equalizes all final strict survivors, scores robust family champions with a role-normalized resilience channel, and selects up to the legal board cap with exact MILP and no fillers.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import sys
import time
from dataclasses import dataclass
from pathlib import Path

_STATE_ROOT_FOR_IMPORTS = Path(__file__).resolve().parents[2]
if str(_STATE_ROOT_FOR_IMPORTS) not in sys.path:
    sys.path.insert(0, str(_STATE_ROOT_FOR_IMPORTS))
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
from numba import njit
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix

from engines.common.mandatory_prebuild_roster_gate_v1 import gate_receipt, require_prebuild_roster_check, verified_out_names

ENGINE_ID = "APEX_WNBA_SHOWDOWN_RAW_POOL_RUNTIME_v7"
PATCH_ID = "WNBA_SHOWDOWN_DEEP_EQUALIZED_RESILIENCE_FAMILY_SELECTOR_v1"
ROLE_SCRIPT_CALIBRATION_PATCH_ID = "WNBA_SHOWDOWN_CONFIRMED_STARTER_RECENT_ROLE_SCRIPT_CALIBRATION_v1"
HANDOFF_PATCH_ID = "HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1"
DOCTRINE_ID = "WNBA_SHOWDOWN_DEEP_EQUALIZED_RESILIENCE_FAMILY_SELECTOR_v1"
ROSTER_RULE = "CPT_PLUS_5_UTIL"
SALARY_MIN = 40_000
SALARY_MAX = 50_000
MAX_FROM_TEAM = 5
SLOTS = ("CPT", "UTIL1", "UTIL2", "UTIL3", "UTIL4", "UTIL5")
SHOWDOWN_RECENT_ROLE_MINUTES_FLOOR = 18.0
SHOWDOWN_CURRENT_ROTATION_MINUTES_FLOOR = 12.0
SHOWDOWN_CONTINUITY_ROTATION_CREDIBILITY_FLOOR = 0.75
SHOWDOWN_CONTINUITY_RECENT_CURRENT_RATIO_FLOOR = 1.05
SHOWDOWN_CONTINUITY_PROBABILITY_FLOOR = 0.18
SHOWDOWN_CONTINUITY_PROBABILITY_CEILING = 0.40
SHOWDOWN_ROLE_SCRIPT_SHARED_FRACTION = 0.50
SHOWDOWN_CONTINUITY_MEAN_BOOST = 1.02

_THIS = Path(__file__).resolve()
_CLASSIC_PATH = _THIS.with_name("wnba_classic_raw_pool_runtime_v1.py")
_spec = importlib.util.spec_from_file_location("apex_wnba_classic_shared", _CLASSIC_PATH)
if _spec is None or _spec.loader is None:
    raise RuntimeError("RUN_INVALID:WNBA_SHARED_CALIBRATION_UNAVAILABLE")
classic = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = classic
_spec.loader.exec_module(classic)


def _sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _array_hash(values: np.ndarray) -> str:
    a = np.ascontiguousarray(values)
    h = hashlib.sha256()
    h.update(str(a.dtype).encode())
    h.update(json.dumps(a.shape, separators=(",", ":")).encode())
    h.update(memoryview(a).cast("B"))
    return h.hexdigest()


def _stable_hash(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _validate_out_evidence(out_names: Sequence[str], evidence_path: str | Path | None) -> tuple[list[dict[str, str]], str]:
    requested = [str(x).strip() for x in out_names if str(x).strip()]
    if not requested:
        return [], _stable_hash([])
    if evidence_path is None:
        raise RuntimeError("RUN_INVALID:CONFIRMED_OUT_EVIDENCE_REQUIRED")
    path = Path(evidence_path)
    if not path.exists():
        raise RuntimeError(f"RUN_INVALID:OUT_EVIDENCE_FILE_MISSING:{path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    records = payload.get("OUTS", payload) if isinstance(payload, dict) else payload
    if not isinstance(records, list):
        raise RuntimeError("RUN_INVALID:OUT_EVIDENCE_INVALID_SCHEMA")
    normalized: list[dict[str, str]] = []
    by_player: dict[str, dict[str, str]] = {}
    for raw in records:
        if not isinstance(raw, dict):
            raise RuntimeError("RUN_INVALID:OUT_EVIDENCE_RECORD_NOT_OBJECT")
        player = str(raw.get("PLAYER", raw.get("player", ""))).strip()
        status = str(raw.get("STATUS", raw.get("status", ""))).strip().upper()
        source = str(raw.get("SOURCE", raw.get("source", ""))).strip()
        as_of = str(raw.get("AS_OF", raw.get("as_of", ""))).strip()
        if not player or status not in {"OUT", "INACTIVE"} or not source or not as_of:
            raise RuntimeError(f"RUN_INVALID:OUT_EVIDENCE_INCOMPLETE:{player or 'UNKNOWN'}")
        rec = {"PLAYER": player, "STATUS": status, "SOURCE": source, "AS_OF": as_of}
        by_player[player] = rec
        normalized.append(rec)
    missing = sorted(set(requested) - set(by_player))
    if missing:
        raise RuntimeError("RUN_INVALID:OUT_EVIDENCE_MISSING_PLAYERS:" + "|".join(missing))
    selected = [by_player[x] for x in requested]
    return selected, _stable_hash(selected)


def _pct_rank(values: np.ndarray) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64)
    if x.size <= 1:
        return np.ones(x.size, dtype=np.float64)
    order = np.argsort(x, kind="mergesort")
    out = np.empty(x.size, dtype=np.float64)
    out[order] = np.linspace(0.0, 1.0, x.size)
    return out


def _wilson(p: np.ndarray, n: np.ndarray | int, z: float = 1.96) -> tuple[np.ndarray, np.ndarray]:
    p = np.asarray(p, dtype=np.float64)
    n = np.asarray(n, dtype=np.float64)
    den = 1.0 + z * z / n
    center = (p + z * z / (2.0 * n)) / den
    half = z * np.sqrt((p * (1.0 - p) + z * z / (4.0 * n)) / n) / den
    return np.maximum(0.0, center - half), np.minimum(1.0, center + half)


@dataclass(frozen=True)
class Config:
    field_size: int
    seed: int
    player_trials: int = 50_000
    base_trials: int = 10_000
    extra_trials: int = 40_000
    phase2_global_keep: int = 14_000
    phase2_macro_keep: int = 40
    phase2_core_family_limit: int = 800
    phase2_core_keep: int = 20
    phase2_value_family_limit: int = 500
    phase2_value_keep: int = 40
    phase2_role_keep: int = 120
    bubble_cap: int = 256
    board_size: int = 10
    player_exposure_cap: int = 7
    captain_exposure_cap: int = 3
    script_exposure_cap: int = 5
    core_family_exposure_cap: int = 2
    macro_family_exposure_cap: int = 3
    value_pair_champion_tie_fraction: float = 0.0025
    value_pair_bundle_cap: int = 4
    family_bundle_min: int = 2
    robust_gate_quantile: float = 0.85
    family_champion_cert_quantile: float = 0.70
    family_champion_boost: float = 0.15
    max_tail_dependencies: int = 2
    tail_dependency_penalty: float = 0.18
    role_conflict_penalty: float = 0.15


@njit(cache=True)
def _count_legal(salary: np.ndarray, team: np.ndarray) -> int:
    n = salary.shape[0]
    total = 0
    for c in range(n):
        cpt_sal = (salary[c] * 3) // 2
        for a in range(n - 4):
            if a == c:
                continue
            for b in range(a + 1, n - 3):
                if b == c:
                    continue
                for d in range(b + 1, n - 2):
                    if d == c:
                        continue
                    for e in range(d + 1, n - 1):
                        if e == c:
                            continue
                        for f in range(e + 1, n):
                            if f == c:
                                continue
                            s = cpt_sal + salary[a] + salary[b] + salary[d] + salary[e] + salary[f]
                            if s < SALARY_MIN or s > SALARY_MAX:
                                continue
                            t0 = 0
                            if team[c] == 0: t0 += 1
                            if team[a] == 0: t0 += 1
                            if team[b] == 0: t0 += 1
                            if team[d] == 0: t0 += 1
                            if team[e] == 0: t0 += 1
                            if team[f] == 0: t0 += 1
                            if t0 == 0 or t0 == 6:
                                continue
                            if t0 > MAX_FROM_TEAM or (6 - t0) > MAX_FROM_TEAM:
                                continue
                            total += 1
    return total


@njit(cache=True)
def _fill_legal(salary: np.ndarray, team: np.ndarray, count: int) -> np.ndarray:
    n = salary.shape[0]
    out = np.empty((count, 6), dtype=np.int16)
    q = 0
    for c in range(n):
        cpt_sal = (salary[c] * 3) // 2
        for a in range(n - 4):
            if a == c:
                continue
            for b in range(a + 1, n - 3):
                if b == c:
                    continue
                for d in range(b + 1, n - 2):
                    if d == c:
                        continue
                    for e in range(d + 1, n - 1):
                        if e == c:
                            continue
                        for f in range(e + 1, n):
                            if f == c:
                                continue
                            s = cpt_sal + salary[a] + salary[b] + salary[d] + salary[e] + salary[f]
                            if s < SALARY_MIN or s > SALARY_MAX:
                                continue
                            t0 = 0
                            if team[c] == 0: t0 += 1
                            if team[a] == 0: t0 += 1
                            if team[b] == 0: t0 += 1
                            if team[d] == 0: t0 += 1
                            if team[e] == 0: t0 += 1
                            if team[f] == 0: t0 += 1
                            if t0 == 0 or t0 == 6:
                                continue
                            if t0 > MAX_FROM_TEAM or (6 - t0) > MAX_FROM_TEAM:
                                continue
                            out[q, 0] = c
                            out[q, 1] = a
                            out[q, 2] = b
                            out[q, 3] = d
                            out[q, 4] = e
                            out[q, 5] = f
                            q += 1
    return out


def _apply_showdown_role_tail_guard(cal):
    """Bound compounded historical-role/vacancy tails using only pre-lock role evidence."""
    df = cal.frame
    minutes = df["MIN"].fillna(0).to_numpy(np.float64)
    historical = df["AMIN"].fillna(0).to_numpy(np.float64)
    recent = df["MIN.1"].fillna(0).to_numpy(np.float64)
    lineup = df["LINEUP"].fillna("").astype(str).str.upper().str.strip()
    starter = lineup.isin({"YES", "Y", "START", "STARTER"}).to_numpy()
    bench = lineup.eq("BN").to_numpy()
    affected = (cal.historical_rebound | cal.recent_role_rebound | cal.vacancy_beneficiary | cal.salary_unlock) & ~cal.stale_role_suppressed
    if not np.any(affected):
        return cal, []

    fpm = cal.base_projection / np.maximum(minutes, 8.0)
    target_minutes = np.maximum.reduce((minutes, 0.85 * historical, 0.90 * recent))
    target_minutes = np.clip(target_minutes, minutes, 34.0)
    role_mean = fpm * target_minutes
    role_mean = np.minimum(role_mean, cal.base_projection * 2.50)
    role_mean = np.where(bench, 0.90 * role_mean, role_mean)
    multiplier = np.where(starter, 2.25, np.where(bench, 2.05, 2.15))
    cap = np.maximum(cal.base_projection * 2.75, role_mean * multiplier)
    cap = np.minimum(cap, np.where(starter, 72.0, 58.0))

    before_p99 = cal.p99.copy()
    cal.sims[affected] = np.minimum(cal.sims[affected], cap[affected, None]).astype(np.float32)
    cal.mean = cal.sims.mean(axis=1).astype(np.float32)
    cal.p95 = np.quantile(cal.sims, 0.95, axis=1).astype(np.float32)
    cal.p99 = np.quantile(cal.sims, 0.99, axis=1).astype(np.float32)
    components = classic._calibration_component_hashes(cal)
    for key, value in components.items():
        setattr(cal, key, value)
    audit = []
    for i in np.flatnonzero(affected):
        audit.append({
            "PLAYER": str(df.iloc[i]["PLAYER"]),
            "P99_BEFORE": float(before_p99[i]),
            "P99_AFTER": float(cal.p99[i]),
            "TAIL_CAP": float(cap[i]),
        })
    return cal, audit



def _probability_preserving_team_role_states(
    rng: np.random.Generator,
    p_expand: np.ndarray,
    team_codes: np.ndarray,
    role_signal: np.ndarray,
    n_trials: int,
    shared_fraction: float = SHOWDOWN_ROLE_SCRIPT_SHARED_FRACTION,
) -> np.ndarray:
    """Sample correlated team role states while preserving each marginal probability."""
    p = np.asarray(p_expand, np.float64)
    teams = np.asarray(team_codes, np.int16)
    signal = np.asarray(role_signal, bool)
    idio_u = rng.random((len(p), int(n_trials)), dtype=np.float32)
    team_u = rng.random((int(teams.max()) + 1, int(n_trials)), dtype=np.float32)
    shared_p = np.clip(float(shared_fraction), 0.0, 1.0) * p
    idio_p = np.divide(p - shared_p, np.maximum(1.0 - shared_p, 1e-9))
    shared_state = team_u[teams] < shared_p[:, None]
    correlated_state = shared_state | (idio_u < idio_p[:, None])
    independent_state = idio_u < p[:, None]
    return np.where(signal[:, None], correlated_state, independent_state)


def _apply_showdown_confirmed_starter_recent_role_script_calibration(cal, cfg: Config):
    """Apply result-blind Showdown role continuity and team-script correlation.

    The calibration is driven only by authoritative pre-lock pool fields. It does not
    reference player names or post-lock outcomes. Confirmed starters with sustained
    recent rotation evidence receive a bounded role-continuity state. All non-trivial
    role-expansion states are then sampled through a probability-preserving team
    common-shock construction so coherent rotation scripts are not artificially
    suppressed by independent Bernoulli draws.
    """
    df = cal.frame
    minutes = df["MIN"].fillna(0).to_numpy(np.float64)
    recent = df["MIN.1"].fillna(0).to_numpy(np.float64)
    historical = df["AMIN"].fillna(0).to_numpy(np.float64)
    starts = df["ST"].fillna(0).to_numpy(np.float64)
    games = df["GP"].fillna(0).to_numpy(np.float64)
    start_rate = np.divide(starts, np.maximum(games, 1.0))
    lineup = df["LINEUP"].fillna("").astype(str).str.upper().str.strip()
    starter = lineup.isin({"YES", "Y", "START", "STARTER"}).to_numpy()

    recent_current_ratio = np.divide(recent, np.maximum(minutes, 1.0))
    continuity = (
        starter
        & (recent >= SHOWDOWN_RECENT_ROLE_MINUTES_FLOOR)
        & (minutes >= SHOWDOWN_CURRENT_ROTATION_MINUTES_FLOOR)
        & (np.asarray(cal.rotation_credibility, np.float64) >= SHOWDOWN_CONTINUITY_ROTATION_CREDIBILITY_FLOOR)
        & (recent_current_ratio >= SHOWDOWN_CONTINUITY_RECENT_CURRENT_RATIO_FLOOR)
        & ~np.asarray(cal.stale_role_suppressed, bool)
    )

    target_minutes = np.asarray(cal.role_ceiling_minutes, np.float64).copy()
    continuity_target = np.clip(np.maximum(minutes, 0.95 * recent), minutes, 34.0)
    target_minutes = np.where(continuity, np.maximum(target_minutes, continuity_target), target_minutes)
    role_ratio = np.divide(target_minutes, np.maximum(minutes, 1.0))

    strength = np.clip((role_ratio - SHOWDOWN_CONTINUITY_RECENT_CURRENT_RATIO_FLOOR) / 0.30, 0.0, 1.0)
    continuity_p = (
        SHOWDOWN_CONTINUITY_PROBABILITY_FLOOR
        + (SHOWDOWN_CONTINUITY_PROBABILITY_CEILING - SHOWDOWN_CONTINUITY_PROBABILITY_FLOOR)
        * strength
        * np.asarray(cal.rotation_credibility, np.float64)
    )
    continuity_p = np.where(continuity, continuity_p, 0.0)
    p_expand = np.maximum(np.asarray(cal.p_expand, np.float64), continuity_p)
    p_expand = np.where(cal.stale_role_suppressed, np.minimum(p_expand, 0.04), p_expand)
    p_expand = np.clip(p_expand, 0.03, 0.60)

    existing_rebound = np.asarray(cal.historical_rebound, bool) | np.asarray(cal.recent_role_rebound, bool)
    expansion_cap = np.where(cal.recent_role_rebound, classic.RECENT_ROLE_EXPANSION_CAP, 3.2)
    expanded_mean = np.asarray(cal.base_projection, np.float64) * np.clip(role_ratio, 1.0, expansion_cap)
    expanded_mean *= np.where(existing_rebound, 1.05, np.where(continuity, SHOWDOWN_CONTINUITY_MEAN_BOOST, 1.0))
    expanded_mean *= np.where(cal.direct_vacancy_absorber, 1.04 + 0.06 * cal.strategic_role_fit, 1.0)
    expanded_mean *= np.where(cal.salary_unlock, 1.04, 1.0)
    expanded_mean = np.where(cal.stale_role_suppressed, cal.base_projection, expanded_mean)
    expanded_mean = np.maximum(expanded_mean, cal.base_projection)

    rng = np.random.default_rng(cfg.seed)
    n_players = len(df)
    n_trials = int(cfg.player_trials)
    idio_loading = classic.COVARIANCE_LOADINGS["idio"]
    team_loading = classic.COVARIANCE_LOADINGS["team"]
    game_loading = classic.COVARIANCE_LOADINGS["game"]
    norm = math.sqrt(idio_loading**2 + team_loading**2 + game_loading**2)

    z_idio = rng.standard_normal((n_players, n_trials), dtype=np.float32)
    z_team = rng.standard_normal((int(cal.team_codes.max()) + 1, n_trials), dtype=np.float32)
    z_game = rng.standard_normal((int(cal.game_codes.max()) + 1, n_trials), dtype=np.float32)
    z = (
        idio_loading * z_idio
        + team_loading * z_team[cal.team_codes]
        + game_loading * z_game[cal.game_codes]
    ) / norm

    role_signal = (
        continuity
        | existing_rebound
        | np.asarray(cal.vacancy_beneficiary, bool)
        | np.asarray(cal.salary_unlock, bool)
    ) & ~np.asarray(cal.stale_role_suppressed, bool)
    role_state = _probability_preserving_team_role_states(
        rng, p_expand, cal.team_codes, role_signal, n_trials, SHOWDOWN_ROLE_SCRIPT_SHARED_FRACTION
    )

    state_mean = np.where(role_state, expanded_mean[:, None], cal.base_projection[:, None])
    cv = np.clip(0.40 + 0.20 * (minutes < 18.0) + 0.10 * (minutes < 12.0), 0.35, 0.75)
    log_sigma = np.sqrt(np.log1p(cv**2))[:, None]
    sims = state_mean * np.exp(log_sigma * z - 0.5 * log_sigma**2)
    cal.sims = np.ascontiguousarray(sims, dtype=np.float32)
    cal.mean = cal.sims.mean(axis=1).astype(np.float32)
    cal.p95 = np.quantile(cal.sims, 0.95, axis=1).astype(np.float32)
    cal.p99 = np.quantile(cal.sims, 0.99, axis=1).astype(np.float32)
    cal.p_expand = p_expand.astype(np.float32)
    cal.role_ceiling_minutes = target_minutes.astype(np.float32)
    cal.qualified = np.asarray(cal.qualified, bool) | continuity

    # Ownership remains a separate field-model signal, but must stay hash-parity aligned
    # with the updated role-state probabilities used by all downstream phases.
    salaries = df["SAL"].astype(int).to_numpy(np.float64)
    ownership_logit = 0.085 * cal.base_projection + 0.018 * minutes + 0.30 * starter.astype(float) - 0.00003 * salaries
    ownership_logit -= 0.90 * (p_expand >= 0.20)
    ownership_proxy = np.exp(ownership_logit - ownership_logit.max())
    ownership_proxy = ownership_proxy / ownership_proxy.sum() * 6.0
    cal.ownership_proxy = np.clip(ownership_proxy, 0.002, 0.65).astype(np.float32)

    covariance_contract = {
        "base_covariance_hash": str(cal.covariance_hash),
        "showdown_role_state_sampling": "TEAM_COMMON_SHOCK_PROBABILITY_PRESERVING_v1",
        "role_script_shared_fraction": SHOWDOWN_ROLE_SCRIPT_SHARED_FRACTION,
        "continuity_recent_minutes_floor": SHOWDOWN_RECENT_ROLE_MINUTES_FLOOR,
        "continuity_current_minutes_floor": SHOWDOWN_CURRENT_ROTATION_MINUTES_FLOOR,
        "continuity_rotation_credibility_floor": SHOWDOWN_CONTINUITY_ROTATION_CREDIBILITY_FLOOR,
        "continuity_recent_current_ratio_floor": SHOWDOWN_CONTINUITY_RECENT_CURRENT_RATIO_FLOOR,
        "postlock_results_used": False,
        "player_name_constants_used": False,
    }
    cal.covariance_hash = classic._stable_json_hash(covariance_contract)
    components = classic._calibration_component_hashes(cal)
    for key, value in components.items():
        setattr(cal, key, value)

    audit = []
    for i in np.flatnonzero(continuity):
        audit.append({
            "PLAYER": str(df.iloc[i]["PLAYER"]),
            "CURRENT_MIN": float(minutes[i]),
            "RECENT_MIN": float(recent[i]),
            "HISTORICAL_MIN": float(historical[i]),
            "START_RATE": float(start_rate[i]),
            "ROTATION_CREDIBILITY": float(cal.rotation_credibility[i]),
            "ROLE_CEILING_MIN": float(target_minutes[i]),
            "P_EXPAND": float(p_expand[i]),
        })
    setattr(cal, "showdown_role_continuity_mask", continuity)
    setattr(cal, "showdown_role_script_calibration_audit", audit)
    setattr(cal, "showdown_role_script_shared_fraction", SHOWDOWN_ROLE_SCRIPT_SHARED_FRACTION)
    return cal, audit

def _load_calibration(pool: str | Path, outs: Iterable[str], cfg: Config):
    shared_cfg = classic.RuntimeConfig(
        field_size=cfg.field_size,
        seed=cfg.seed,
        player_trials=cfg.player_trials,
        base_trials=cfg.base_trials,
        extra_trials=cfg.extra_trials,
        board_size=cfg.board_size,
        player_exposure_cap=cfg.player_exposure_cap,
    )
    cal = classic.load_and_calibrate(pool, outs, shared_cfg)
    cal, role_script_audit = _apply_showdown_confirmed_starter_recent_role_script_calibration(cal, cfg)
    setattr(cal, "showdown_role_script_calibration_audit", role_script_audit)
    cal, tail_guard_audit = _apply_showdown_role_tail_guard(cal)
    setattr(cal, "showdown_tail_guard_audit", tail_guard_audit)
    classic._assert_calibration_sync(cal, "WNBA_SHOWDOWN_PHASE1")
    df = cal.frame
    line = df["LINEUP"].fillna("").astype(str).str.upper().str.strip()
    starter = line.isin({"YES", "Y", "START", "STARTER"}).to_numpy()
    minutes = df["MIN"].fillna(0).to_numpy(float)
    recent = df["MIN.1"].fillna(0).to_numpy(float)
    eligible = (
        starter
        | (minutes >= 6.0)
        | (recent >= 8.0)
        | cal.salary_unlock
        | cal.vacancy_beneficiary
        | cal.historical_rebound
        | cal.recent_role_rebound
    )
    eligible &= ~cal.stale_role_suppressed
    eligible &= cal.qualified
    ids = np.flatnonzero(eligible)
    if ids.size < 7:
        raise RuntimeError("RUN_INVALID:WNBA_SHOWDOWN_ACTIVE_POOL_TOO_SMALL")
    teams = df.iloc[ids]["TEAM"].astype(str).unique()
    if len(teams) != 2:
        raise RuntimeError(f"RUN_INVALID:WNBA_SHOWDOWN_TWO_TEAM_GATE:{len(teams)}")
    return cal, ids


def _enumerate(cal, ids: np.ndarray) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    frame = cal.frame.iloc[ids].reset_index(drop=True)
    salary = frame["SAL"].astype(int).to_numpy(np.int32)
    team_cat = pd.Categorical(frame["TEAM"].astype(str))
    team = team_cat.codes.astype(np.int8)
    count = int(_count_legal(salary, team))
    if count <= 0:
        raise RuntimeError("RUN_INVALID:NO_LEGAL_WNBA_SHOWDOWN_LINEUPS")
    local = _fill_legal(salary, team, count)
    global_rows = ids[local]
    cpt_salary = (salary[local[:, 0]] * 3) // 2
    totals = cpt_salary + salary[local[:, 1:]].sum(axis=1)
    team0 = (team[local] == 0).sum(axis=1).astype(np.int8)
    cpt_team_count = np.where(team[local[:, 0]] == 0, team0, 6 - team0).astype(np.int8)
    script = cpt_team_count
    return global_rows.astype(np.int16), {
        "salary": totals.astype(np.int32),
        "team0_count": team0,
        "script": script,
        "local": local,
        "team_labels": np.asarray(team_cat.categories.astype(str)),
    }


def _lineup_additive(rows: np.ndarray, values: np.ndarray) -> np.ndarray:
    return 1.5 * values[rows[:, 0]] + values[rows[:, 1:]].sum(axis=1)


def _ownership_log(rows: np.ndarray, ownership: np.ndarray) -> np.ndarray:
    own = np.clip(ownership, 1e-6, 0.95)
    return 1.20 * np.log(own[rows[:, 0]]) + np.log(own[rows[:, 1:]]).sum(axis=1)


def _factorize_family(*arrays: np.ndarray) -> tuple[np.ndarray, int]:
    keys = pd.MultiIndex.from_arrays([np.asarray(x) for x in arrays])
    codes, uniques = pd.factorize(keys, sort=True)
    return codes.astype(np.int32), int(len(uniques))


def _group_top_indices(group: np.ndarray, metric: np.ndarray, per_group: int, group_limit: int | None = None) -> tuple[np.ndarray, np.ndarray]:
    frame = pd.DataFrame({"group": np.asarray(group, dtype=np.int32), "metric": np.asarray(metric, dtype=np.float64), "idx": np.arange(len(group), dtype=np.int32)})
    maxima = frame.groupby("group", sort=False)["metric"].max()
    if group_limit is not None and len(maxima) > group_limit:
        active = maxima.nlargest(group_limit, keep="first").index
        frame = frame[frame["group"].isin(active)]
    ordered = frame.sort_values(["group", "metric", "idx"], ascending=[True, False, True], kind="mergesort")
    top = ordered.groupby("group", sort=False).head(per_group)
    return top["idx"].to_numpy(np.int32), top["group"].to_numpy(np.int32)


def _family_metadata(rows: np.ndarray, meta: dict[str, np.ndarray], cal) -> dict[str, np.ndarray | int]:
    salary_all = cal.frame["SAL"].fillna(0).to_numpy(np.int32)
    util_salary = salary_all[rows[:, 1:]]
    elite_count = (util_salary >= 8_000).sum(axis=1).astype(np.int8)
    mid_count = ((util_salary >= 4_000) & (util_salary < 8_000)).sum(axis=1).astype(np.int8)
    value_count = (util_salary < 4_000).sum(axis=1).astype(np.int8)
    salary_band = np.clip((meta["salary"] - SALARY_MIN) // 1_000, 0, 10).astype(np.int8)

    macro_id, macro_n = _factorize_family(rows[:, 0], meta["script"], elite_count, mid_count, value_count)

    contribution = np.asarray(cal.p99[rows], dtype=np.float64)
    contribution[:, 0] *= 1.5
    core_pos = np.argpartition(contribution, -3, axis=1)[:, -3:]
    core_ids = np.take_along_axis(rows, core_pos, axis=1).astype(np.int16)
    core_ids.sort(axis=1)
    core_id, core_n = _factorize_family(meta["script"], core_ids[:, 0], core_ids[:, 1], core_ids[:, 2], elite_count, value_count)

    amin_all = cal.frame["AMIN"].fillna(0).to_numpy(np.float64)
    recent_all = cal.frame["MIN.1"].fillna(0).to_numpy(np.float64)
    st_all = cal.frame["ST"].fillna(0).to_numpy(np.float64)
    certified_value = (salary_all <= 4_000) & ((amin_all >= 8.0) | (recent_all >= 3.0) | (st_all > 0.0)) & cal.qualified
    util_ids = rows[:, 1:]
    value_mask = certified_value[util_ids]
    sortable = np.where(value_mask, salary_all[util_ids].astype(np.int64) * 100_000 + util_ids, np.int64(10**15))
    value_pos = np.argsort(sortable, axis=1, kind="stable")[:, :2]
    value_ids = np.take_along_axis(util_ids, value_pos, axis=1).astype(np.int16)
    value_hits = value_mask.sum(axis=1)
    value_ids[value_hits < 1, 0] = -1
    value_ids[value_hits < 2, 1] = -1
    value_ids.sort(axis=1)
    value_family_id, value_family_n = _factorize_family(rows[:, 0], meta["script"], value_ids[:, 0], value_ids[:, 1], elite_count)
    value_pair_id, value_pair_n = _factorize_family(value_ids[:, 0], value_ids[:, 1])

    role_signal = (
        cal.salary_unlock[rows].sum(axis=1)
        + cal.vacancy_beneficiary[rows].sum(axis=1)
        + cal.historical_rebound[rows].sum(axis=1)
        + cal.recent_role_rebound[rows].sum(axis=1)
    ).astype(np.int8)
    role_bucket = np.clip(role_signal, 0, 4).astype(np.int8)
    role_family_id, role_family_n = _factorize_family(meta["script"], role_bucket, elite_count, mid_count, value_count)

    return {
        "macro_family_id": macro_id,
        "core_family_id": core_id,
        "value_family_id": value_family_id,
        "value_pair_id": value_pair_id,
        "role_family_id": role_family_id,
        "core_ids": core_ids,
        "value_ids": value_ids,
        "elite_count": elite_count,
        "mid_count": mid_count,
        "value_count": value_count,
        "salary_band": salary_band,
        "role_bucket": role_bucket,
        "certified_value_count": value_hits.astype(np.int8),
        "macro_family_count_all": macro_n,
        "core_family_count_all": core_n,
        "value_family_count_all": value_family_n,
        "value_pair_count_all": value_pair_n,
        "role_family_count_all": role_family_n,
    }


def _phase2(rows: np.ndarray, meta: dict[str, np.ndarray], cal, cfg: Config) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    mean = _lineup_additive(rows, cal.mean)
    p95 = _lineup_additive(rows, cal.p95)
    p99 = _lineup_additive(rows, cal.p99)
    salary_release = SALARY_MAX - meta["salary"]
    own_log = _ownership_log(rows, cal.ownership_proxy)
    strategic = (
        1.5 * cal.strategic_role_fit[rows[:, 0]]
        + cal.strategic_role_fit[rows[:, 1:]].sum(axis=1)
        + 0.40 * cal.salary_unlock[rows].sum(axis=1)
        + 0.25 * cal.vacancy_beneficiary[rows].sum(axis=1)
    )
    score = (
        0.42 * _pct_rank(p99)
        + 0.24 * _pct_rank(p95)
        + 0.18 * _pct_rank(mean)
        + 0.09 * _pct_rank(strategic)
        + 0.04 * _pct_rank(salary_release)
        - 0.03 * _pct_rank(own_log)
    )
    fam = _family_metadata(rows, meta, cal)
    reason = np.zeros(len(rows), dtype=np.uint16)

    # Global champions remain, but they no longer define Phase 2 alone.
    k = min(cfg.phase2_global_keep, len(rows))
    if k:
        idx = np.argpartition(score, -k)[-k:]
        reason[idx] |= np.uint16(1)  # GLOBAL_CHAMPION

    # Birth every viable macro roster family: captain x script x salary geometry.
    idx, _ = _group_top_indices(np.asarray(fam["macro_family_id"]), score, cfg.phase2_macro_keep)
    reason[idx] |= np.uint16(2)  # MACRO_FAMILY_BIRTH

    # Birth elite core families and preserve their sibling closure. The first row in each
    # family is the seed; remaining rows are deterministic siblings around the same core.
    core_idx, core_groups = _group_top_indices(
        np.asarray(fam["core_family_id"]),
        score + 0.08 * _pct_rank(p99) + 0.03 * _pct_rank(strategic),
        cfg.phase2_core_keep,
        cfg.phase2_core_family_limit,
    )
    if core_idx.size:
        first = np.ones(core_idx.size, dtype=bool)
        first[1:] = core_groups[1:] != core_groups[:-1]
        reason[core_idx[first]] |= np.uint16(4)   # CORE_FAMILY_SEED
        reason[core_idx[~first]] |= np.uint16(8)  # CORE_FAMILY_SIBLING

    # Preserve value-pair families independently of median projection rank.
    value_valid = np.asarray(fam["certified_value_count"]) >= 1
    if np.any(value_valid):
        valid_rows = np.flatnonzero(value_valid)
        local_idx, _ = _group_top_indices(
            np.asarray(fam["value_family_id"])[valid_rows],
            score[valid_rows] + 0.10 * _pct_rank(p99[valid_rows]),
            cfg.phase2_value_keep,
            cfg.phase2_value_family_limit,
        )
        idx = valid_rows[local_idx]
        reason[idx] |= np.uint16(16)  # VALUE_PAIR_FAMILY

    # Role-dislocation/vacancy families are also born before the handoff.
    role_idx, _ = _group_top_indices(np.asarray(fam["role_family_id"]), score, cfg.phase2_role_keep)
    reason[role_idx] |= np.uint16(32)  # ROLE_FAMILY

    chosen = np.flatnonzero(reason > 0)
    order = np.lexsort((chosen, -score[chosen]))
    chosen = chosen[order]
    return rows[chosen], {
        "legal_index": chosen,
        "mean": mean[chosen].astype(np.float32),
        "p95_proxy": p95[chosen].astype(np.float32),
        "p99_proxy": p99[chosen].astype(np.float32),
        "salary": meta["salary"][chosen],
        "script": meta["script"][chosen],
        "own_log": own_log[chosen].astype(np.float32),
        "phase2_score": score[chosen].astype(np.float32),
        "public_mean_all": mean.astype(np.float32),
        "public_own_log_all": own_log.astype(np.float32),
        "macro_family_id": np.asarray(fam["macro_family_id"])[chosen],
        "core_family_id": np.asarray(fam["core_family_id"])[chosen],
        "value_family_id": np.asarray(fam["value_family_id"])[chosen],
        "value_pair_id": np.asarray(fam["value_pair_id"])[chosen],
        "role_family_id": np.asarray(fam["role_family_id"])[chosen],
        "core_ids": np.asarray(fam["core_ids"])[chosen],
        "value_ids": np.asarray(fam["value_ids"])[chosen],
        "elite_count": np.asarray(fam["elite_count"])[chosen],
        "mid_count": np.asarray(fam["mid_count"])[chosen],
        "value_count": np.asarray(fam["value_count"])[chosen],
        "salary_band": np.asarray(fam["salary_band"])[chosen],
        "role_bucket": np.asarray(fam["role_bucket"])[chosen],
        "birth_reason": reason[chosen],
        "macro_family_count_all": np.array([int(fam["macro_family_count_all"])]),
        "core_family_count_all": np.array([int(fam["core_family_count_all"])]),
        "value_family_count_all": np.array([int(fam["value_family_count_all"])]),
        "value_pair_count_all": np.array([int(fam["value_pair_count_all"])]),
        "role_family_count_all": np.array([int(fam["role_family_count_all"])]),
    }

def _build_fake_field(all_rows: np.ndarray, phase2_meta: dict[str, np.ndarray], cfg: Config) -> np.ndarray:
    fake_n = int(math.ceil(cfg.field_size * 3.4))
    rng = np.random.default_rng(cfg.seed + 2909)
    mean = phase2_meta["public_mean_all"].astype(np.float64)
    own = phase2_meta["public_own_log_all"].astype(np.float64)
    public = 0.78 * _pct_rank(mean) + 0.22 * _pct_rank(own)
    # Gumbel perturbation creates a deterministic public-field draw without First-N truncation.
    draw = public + 0.105 * rng.gumbel(size=len(all_rows))
    k = min(fake_n, len(all_rows))
    idx = np.argpartition(draw, -k)[-k:]
    idx = idx[np.argsort(-draw[idx], kind="stable")]
    return all_rows[idx]


def _score_rows(rows: np.ndarray, sims: np.ndarray) -> np.ndarray:
    return (
        1.5 * sims[rows[:, 0]]
        + sims[rows[:, 1]]
        + sims[rows[:, 2]]
        + sims[rows[:, 3]]
        + sims[rows[:, 4]]
        + sims[rows[:, 5]]
    )


def _field_thresholds(field: np.ndarray, sims: np.ndarray, cfg: Config, trial_chunk: int = 512) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    n_trials = sims.shape[1]
    win = np.empty(n_trials, dtype=np.float32)
    top01 = np.empty(n_trials, dtype=np.float32)
    top10 = np.empty(n_trials, dtype=np.float32)
    k01 = max(1, int(math.ceil(len(field) * 0.001)))
    k10 = max(1, min(len(field), int(math.ceil(10 * len(field) / max(cfg.field_size, 1)))))
    for start in range(0, n_trials, trial_chunk):
        end = min(n_trials, start + trial_chunk)
        scores = _score_rows(field, sims[:, start:end])
        win[start:end] = scores.max(axis=0)
        top01[start:end] = np.partition(scores, -k01, axis=0)[-k01]
        top10[start:end] = np.partition(scores, -k10, axis=0)[-k10]
    return win, top01, top10


def _evaluate(rows: np.ndarray, sims: np.ndarray, thresholds: tuple[np.ndarray, np.ndarray, np.ndarray], batch: int = 128) -> dict[str, np.ndarray]:
    win_t, top01_t, top10_t = thresholds
    n = len(rows)
    win = np.zeros(n, dtype=np.int32)
    top01 = np.zeros(n, dtype=np.int32)
    top10 = np.zeros(n, dtype=np.int32)
    mean = np.zeros(n, dtype=np.float32)
    p95 = np.zeros(n, dtype=np.float32)
    p99 = np.zeros(n, dtype=np.float32)
    for start in range(0, n, batch):
        end = min(n, start + batch)
        scores = _score_rows(rows[start:end], sims)
        win[start:end] = (scores >= win_t[None, :]).sum(axis=1)
        top01[start:end] = (scores >= top01_t[None, :]).sum(axis=1)
        top10[start:end] = (scores >= top10_t[None, :]).sum(axis=1)
        mean[start:end] = scores.mean(axis=1)
        p95[start:end] = np.quantile(scores, 0.95, axis=1)
        p99[start:end] = np.quantile(scores, 0.99, axis=1)
    return {"win": win, "top01": top01, "top10": top10, "mean": mean, "p95": p95, "p99": p99}


def _simulate(phase2: np.ndarray, all_rows: np.ndarray, p2meta: dict[str, np.ndarray], cal, cfg: Config) -> dict[str, object]:
    classic._assert_calibration_sync(cal, "WNBA_SHOWDOWN_PHASE3")
    field = _build_fake_field(all_rows, p2meta, cfg)
    if len(field) <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:FAKE_FIELD_ZERO")
    base_sims = cal.sims[:, :cfg.base_trials]
    base_t = _field_thresholds(field, base_sims, cfg)
    metrics = _evaluate(phase2, base_sims, base_t)
    trials = np.full(len(phase2), cfg.base_trials, dtype=np.int32)

    p_top = metrics["top01"] / trials
    p_win = metrics["win"] / trials
    low, high = _wilson(p_top, trials)
    provisional = 0.72 * _pct_rank(p_top) + 0.18 * _pct_rank(p_win) + 0.10 * _pct_rank(metrics["p99"])
    cutoff_rank = min(max(cfg.board_size * 8, 32), len(phase2))
    cutoff_idx = np.argpartition(provisional, -cutoff_rank)[-cutoff_rank:]
    cutoff_low = float(np.min(low[cutoff_idx]))
    overlap = np.flatnonzero(high >= cutoff_low)
    if overlap.size > cfg.bubble_cap:
        overlap = overlap[np.argpartition(provisional[overlap], -cfg.bubble_cap)[-cfg.bubble_cap:]]
    overlap = overlap[np.argsort(-provisional[overlap], kind="stable")]

    extra_total = 0
    if cfg.extra_trials > 0 and overlap.size:
        extra_sims = cal.sims[:, cfg.base_trials:cfg.base_trials + cfg.extra_trials]
        extra_t = _field_thresholds(field, extra_sims, cfg)
        extra = _evaluate(phase2[overlap], extra_sims, extra_t)
        for key in ("win", "top01", "top10"):
            metrics[key][overlap] += extra[key]
        # Preserve exact pooled moments by recomputing the bubble over all trials.
        pooled = _evaluate(phase2[overlap], cal.sims[:, :cfg.base_trials + cfg.extra_trials], (
            np.concatenate((base_t[0], extra_t[0])),
            np.concatenate((base_t[1], extra_t[1])),
            np.concatenate((base_t[2], extra_t[2])),
        ))
        for key in ("mean", "p95", "p99"):
            metrics[key][overlap] = pooled[key]
        trials[overlap] += cfg.extra_trials
        extra_total = int(overlap.size * cfg.extra_trials)

    for key in ("win", "top01", "top10"):
        metrics[key + "_rate"] = metrics[key] / trials
    metrics["trials"] = trials
    metrics["bubble"] = overlap
    metrics["bubble_extra_total"] = extra_total
    metrics["fake_field"] = field
    return metrics


def _selector_resilience_features(rows: np.ndarray, cal) -> dict[str, np.ndarray]:
    baseline = _lineup_additive(rows, np.asarray(cal.base_projection, np.float64))
    calibrated_mean = _lineup_additive(rows, np.asarray(cal.mean, np.float64))
    inflation = np.asarray(cal.mean, np.float64) / np.maximum(np.asarray(cal.base_projection, np.float64), 1e-6)
    tail_player = (
        (inflation > 1.25)
        | np.asarray(cal.historical_rebound, bool)
        | np.asarray(cal.vacancy_beneficiary, bool)
        | np.asarray(cal.recent_role_rebound, bool)
    )
    lineup_status = cal.frame["LINEUP"].fillna("").astype(str).str.upper().str.strip().to_numpy()
    recent = cal.frame["MIN.1"].fillna(0).to_numpy(np.float64)
    role_conflict_player = (lineup_status == "BN") & (recent <= 1.0)
    tail_count = tail_player[rows].sum(axis=1).astype(np.int8)
    role_conflict_count = role_conflict_player[rows].sum(axis=1).astype(np.int8)
    rotation_mean = np.asarray(cal.rotation_credibility, np.float64)[rows].mean(axis=1)
    return {
        "baseline": baseline.astype(np.float64),
        "calibrated_mean": calibrated_mean.astype(np.float64),
        "tail_gap": (calibrated_mean - baseline).astype(np.float64),
        "tail_dependency_count": tail_count,
        "role_conflict_count": role_conflict_count,
        "rotation_mean": rotation_mean.astype(np.float64),
    }


def _deep_equalize_selector_candidates(rows: np.ndarray, candidate_idx: np.ndarray, sim: dict[str, object], cal, cfg: Config) -> tuple[dict[str, np.ndarray], int, int]:
    candidate_idx = np.asarray(candidate_idx, dtype=int)
    total_trials = min(int(cal.sims.shape[1]), int(cfg.base_trials + cfg.extra_trials))
    if total_trials <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:SELECTOR_DEEP_EQUALIZATION_ZERO_TRIALS")
    full_sims = cal.sims[:, :total_trials]
    thresholds = _field_thresholds(np.asarray(sim["fake_field"]), full_sims, cfg)
    deep = _evaluate(rows[candidate_idx], full_sims, thresholds)
    for key in ("win", "top01", "top10"):
        deep[key + "_rate"] = deep[key] / total_trials
    previous_trials = np.asarray(sim["trials"], dtype=np.int32)[candidate_idx].copy()
    for key in ("win", "top01", "top10", "mean", "p95", "p99"):
        np.asarray(sim[key])[candidate_idx] = deep[key]
    for key in ("win", "top01", "top10"):
        np.asarray(sim[key + "_rate"])[candidate_idx] = deep[key + "_rate"]
    np.asarray(sim["trials"])[candidate_idx] = total_trials
    extra_evaluations = int(np.maximum(0, total_trials - previous_trials).sum())
    return deep, total_trials, extra_evaluations


def _select(rows: np.ndarray, p2meta: dict[str, np.ndarray], sim: dict[str, object], cal, cfg: Config) -> tuple[np.ndarray, dict[str, np.ndarray], str]:
    classic._assert_calibration_sync(cal, "WNBA_SHOWDOWN_SELECTOR")
    top01_all = np.asarray(sim["top01_rate"], float)
    win_all = np.asarray(sim["win_rate"], float)
    p99_all = np.asarray(sim["p99"], float)
    p95_all = np.asarray(sim["p95"], float)

    provisional_tiers = (
        (0.990, 0.985, 0.950, "HARD_TOP1_TAIL"),
        (0.985, 0.980, 0.940, "MC_TIE_BAND_1_5"),
        (0.980, 0.975, 0.930, "MC_TIE_BAND_2_0"),
        (0.975, 0.970, 0.920, "MC_TIE_BAND_2_5"),
        (0.970, 0.965, 0.900, "MC_TIE_BAND_3_0"),
    )
    provisional_top01_pct = _pct_rank(top01_all)
    provisional_win_pct = _pct_rank(win_all)
    provisional_p99_pct = _pct_rank(p99_all)
    provisional_p95_pct = _pct_rank(p95_all)
    strict_idx = np.array([], dtype=int)
    tier_name = "INFEASIBLE"
    strict_thresholds = np.array([0.0, 0.0, 0.0])
    for q_primary, q99, q95, name in provisional_tiers:
        strict = ((provisional_top01_pct >= q_primary) | (provisional_win_pct >= q_primary)) & (provisional_p99_pct >= q99) & (provisional_p95_pct >= q95)
        candidate = np.flatnonzero(strict)
        if candidate.size >= cfg.family_bundle_min:
            strict_idx = candidate
            tier_name = name
            strict_thresholds = np.array([q_primary, q99, q95], dtype=float)
            break

    expected_dup = np.zeros(len(rows), dtype=np.float64)
    own_log = np.asarray(p2meta["own_log"], float)
    own_weight = np.exp(own_log - np.max(own_log))
    expected_dup[:] = cfg.field_size * own_weight / max(own_weight.sum(), 1e-12)
    features = _selector_resilience_features(rows, cal)
    selector_score = np.full(len(rows), -np.inf, dtype=np.float64)
    robust_eligible = np.array([], dtype=int)
    family_certified = np.array([], dtype=int)
    required_bundle = np.array([], dtype=int)
    dominant_pair = -1
    robust_gate_score = float("nan")
    deep_trials = 0
    deep_extra_total = 0
    last_message = "NO_STRICT_SURVIVORS"

    if strict_idx.size:
        deep, deep_trials, deep_extra_total = _deep_equalize_selector_candidates(rows, strict_idx, sim, cal, cfg)
        top01_lcb, _ = _wilson(deep["top01_rate"], deep_trials)
        win_lcb, _ = _wilson(deep["win_rate"], deep_trials)
        top01_pct = _pct_rank(top01_lcb)
        win_pct = _pct_rank(win_lcb)
        top10_pct = _pct_rank(deep["top10_rate"])
        p99_pct = _pct_rank(deep["p99"])
        p95_pct = _pct_rank(deep["p95"])
        mean_pct = _pct_rank(deep["mean"])
        baseline = features["baseline"][strict_idx]
        base_pct = _pct_rank(baseline)
        gap_pct = _pct_rank(features["tail_gap"][strict_idx])
        dup_pct = _pct_rank(expected_dup[strict_idx])
        tail_count = features["tail_dependency_count"][strict_idx]
        conflict_count = features["role_conflict_count"][strict_idx]
        tail_excess = np.maximum(tail_count.astype(float) - 1.0, 0.0)
        robust_local = (
            0.20 * top01_pct
            + 0.08 * win_pct
            + 0.07 * top10_pct
            + 0.05 * p99_pct
            + 0.05 * p95_pct
            + 0.10 * mean_pct
            + 0.40 * base_pct
            - 0.12 * gap_pct
            - cfg.tail_dependency_penalty * tail_excess
            - cfg.role_conflict_penalty * conflict_count.astype(float)
            - 0.02 * dup_pct
        )
        selector_score[strict_idx] = robust_local

        value_pair_ids = np.asarray(p2meta["value_pair_id"], np.int32)[strict_idx]
        value_ids = np.asarray(p2meta["value_ids"], np.int16)[strict_idx]
        captains = rows[strict_idx, 0]
        dual = (value_ids[:, 0] >= 0) & (value_ids[:, 1] >= 0)
        cert_gate = float(np.quantile(robust_local, cfg.family_champion_cert_quantile))
        best_quality = -np.inf
        best_certified = np.array([], dtype=int)
        for pair in np.unique(value_pair_ids[dual]):
            pair_local = np.flatnonzero(dual & (value_pair_ids == pair))
            champions: list[int] = []
            for captain in np.unique(captains[pair_local]):
                c_local = pair_local[captains[pair_local] == captain]
                champions.append(int(c_local[np.argmax(robust_local[c_local])]))
            if len(champions) < cfg.family_bundle_min:
                continue
            champions_arr = np.asarray(champions, dtype=int)
            champions_arr = champions_arr[np.argsort(-robust_local[champions_arr], kind="stable")]
            certified_local = champions_arr[
                (robust_local[champions_arr] >= cert_gate)
                & (tail_count[champions_arr] <= cfg.max_tail_dependencies)
                & (conflict_count[champions_arr] == 0)
            ]
            if certified_local.size < cfg.family_bundle_min:
                continue
            certified_local = certified_local[: cfg.value_pair_bundle_cap]
            quality = float(robust_local[certified_local].mean()) + 0.02 * certified_local.size
            if quality > best_quality:
                best_quality = quality
                dominant_pair = int(pair)
                best_certified = strict_idx[certified_local]
        family_certified = best_certified
        if family_certified.size:
            selector_score[family_certified] += cfg.family_champion_boost
            family_certified = family_certified[np.argsort(-selector_score[family_certified], kind="stable")]
            required_bundle = family_certified[: cfg.family_bundle_min]

        robust_gate_score = float(np.quantile(robust_local, cfg.robust_gate_quantile))
        robust_mask_local = (
            (robust_local >= robust_gate_score)
            & (tail_count <= cfg.max_tail_dependencies)
            & (conflict_count == 0)
        )
        robust_eligible = strict_idx[np.flatnonzero(robust_mask_local)]
        if family_certified.size:
            robust_eligible = np.unique(np.concatenate((robust_eligible, family_certified))).astype(int)

    core_ids = np.asarray(p2meta["core_family_id"], np.int32)
    macro_ids = np.asarray(p2meta["macro_family_id"], np.int32)
    chosen = np.array([], dtype=int)
    core_cap_used = 0
    macro_cap_used = 0
    if robust_eligible.size >= cfg.family_bundle_min:
        for target in range(min(cfg.board_size, robust_eligible.size), cfg.family_bundle_min - 1, -1):
            for core_cap, macro_cap in (
                (cfg.core_family_exposure_cap, cfg.macro_family_exposure_cap),
                (cfg.core_family_exposure_cap + 1, cfg.macro_family_exposure_cap + 1),
                (cfg.board_size, cfg.board_size),
            ):
                e = robust_eligible
                m_rows = len(e)
                matrix_rows: list[np.ndarray] = [np.ones(m_rows, dtype=float)]
                lower: list[float] = [float(target)]
                upper: list[float] = [float(target)]
                for required_idx in required_bundle:
                    matrix_rows.append((e == required_idx).astype(float))
                    lower.append(1.0); upper.append(1.0)
                for player in np.unique(rows[e]):
                    matrix_rows.append((rows[e] == player).any(axis=1).astype(float))
                    lower.append(0.0); upper.append(float(cfg.player_exposure_cap))
                for captain in np.unique(rows[e, 0]):
                    matrix_rows.append((rows[e, 0] == captain).astype(float))
                    lower.append(0.0); upper.append(float(cfg.captain_exposure_cap))
                for script in np.unique(p2meta["script"][e]):
                    matrix_rows.append((p2meta["script"][e] == script).astype(float))
                    lower.append(0.0); upper.append(float(cfg.script_exposure_cap))
                if core_cap < cfg.board_size:
                    for family in np.unique(core_ids[e]):
                        matrix_rows.append((core_ids[e] == family).astype(float))
                        lower.append(0.0); upper.append(float(core_cap))
                if macro_cap < cfg.board_size:
                    for family in np.unique(macro_ids[e]):
                        matrix_rows.append((macro_ids[e] == family).astype(float))
                        lower.append(0.0); upper.append(float(macro_cap))
                constraints = LinearConstraint(csr_matrix(np.vstack(matrix_rows)), np.asarray(lower), np.asarray(upper))
                result = milp(
                    c=-selector_score[e],
                    integrality=np.ones(m_rows, dtype=np.int8),
                    bounds=Bounds(np.zeros(m_rows), np.ones(m_rows)),
                    constraints=constraints,
                    options={"time_limit": 30.0, "mip_rel_gap": 0.0},
                )
                last_message = str(result.message)
                if result.x is None:
                    continue
                selected = e[np.flatnonzero(result.x > 0.5)]
                if selected.size != target:
                    continue
                chosen = selected[np.argsort(-selector_score[selected], kind="stable")]
                core_cap_used = core_cap
                macro_cap_used = macro_cap
                break
            if chosen.size:
                break

    metrics = {
        "eligible": robust_eligible,
        "strict_eligible": strict_idx,
        "robust_eligible": robust_eligible,
        "structural_eligible": np.array([], int),
        "chosen": chosen,
        "selector_reviewed": np.array([len(rows)]),
        "expected_dup": expected_dup,
        "top01": np.asarray(sim["top01_rate"], float),
        "win": np.asarray(sim["win_rate"], float),
        "top10": np.asarray(sim["top10_rate"], float),
        "p99": np.asarray(sim["p99"], float),
        "p95": np.asarray(sim["p95"], float),
        "mean": np.asarray(sim["mean"], float),
        "trials": np.asarray(sim["trials"], int),
        "score": selector_score,
        "salary": p2meta["salary"],
        "script": p2meta["script"],
        "strict_tier": np.array([tier_name]),
        "strict_thresholds": strict_thresholds,
        "structural_captains": np.array([], dtype=np.int16),
        "selector_mode": np.array(["DEEP_EQUALIZED_RESILIENCE_FAMILY_MILP"]),
        "core_family_cap_used": np.array([core_cap_used]),
        "macro_family_cap_used": np.array([macro_cap_used]),
        "dominant_value_pair_id": np.array([dominant_pair]),
        "family_certified_champions": family_certified.astype(np.int32),
        "required_family_bundle": required_bundle.astype(np.int32),
        "robust_gate_score": np.array([robust_gate_score]),
        "deep_equalized_candidates": np.array([len(strict_idx)]),
        "deep_equalized_trials": np.array([deep_trials]),
        "deep_equalization_extra_total": np.array([deep_extra_total]),
        "baseline_resilience": features["baseline"],
        "tail_gap": features["tail_gap"],
        "tail_dependency_count": features["tail_dependency_count"],
        "role_conflict_count": features["role_conflict_count"],
        "rotation_mean": features["rotation_mean"],
    }
    if len(rows) <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:WNBA_SHOWDOWN_ZERO_PHASE3_SURVIVORS")
    target = min(int(cfg.board_size), len(rows))
    portfolio_relaxation = False
    if chosen.size < target:
        # First recover from the full frozen Phase3 set while preserving player/CPT/script caps
        # and any certified required family bundle. Only the robust-family gate is widened.
        safe_score = np.nan_to_num(selector_score, nan=-1e12, posinf=1e12, neginf=-1e12)
        topk = min(1200, len(rows))
        recovery_idx = np.argsort(-safe_score, kind="stable")[:topk]
        if required_bundle.size:
            recovery_idx = np.unique(np.concatenate([recovery_idx, required_bundle.astype(int)]))
        recovery_rows = rows[recovery_idx]
        m_rows = len(recovery_idx)
        matrix_rows: list[np.ndarray] = [np.ones(m_rows, dtype=float)]
        lower: list[float] = [float(target)]
        upper: list[float] = [float(target)]
        for required_idx in required_bundle:
            matrix_rows.append((recovery_idx == int(required_idx)).astype(float))
            lower.append(1.0); upper.append(1.0)
        for player in np.unique(recovery_rows):
            matrix_rows.append((recovery_rows == player).any(axis=1).astype(float))
            lower.append(0.0); upper.append(float(cfg.player_exposure_cap))
        for captain in np.unique(recovery_rows[:, 0]):
            matrix_rows.append((recovery_rows[:, 0] == captain).astype(float))
            lower.append(0.0); upper.append(float(cfg.captain_exposure_cap))
        for script in np.unique(p2meta["script"][recovery_idx]):
            matrix_rows.append((p2meta["script"][recovery_idx] == script).astype(float))
            lower.append(0.0); upper.append(float(cfg.script_exposure_cap))
        recovery = milp(
            c=-safe_score[recovery_idx], integrality=np.ones(m_rows, dtype=np.int8),
            bounds=Bounds(np.zeros(m_rows), np.ones(m_rows)),
            constraints=LinearConstraint(csr_matrix(np.vstack(matrix_rows)), np.asarray(lower), np.asarray(upper)),
            options={"time_limit": 30.0, "mip_rel_gap": 0.0},
        )
        if recovery.x is not None:
            recovered = recovery_idx[np.flatnonzero(recovery.x > 0.5)]
            if recovered.size == target:
                chosen = recovered[np.argsort(-safe_score[recovered], kind="stable")]
                portfolio_relaxation = True
        if chosen.size < target:
            # Last-resort nonempty guarantee remains inside the frozen Phase3 survivor set.
            selected = [int(i) for i in chosen.tolist()]
            selected_set = set(selected)
            for i in np.argsort(-safe_score, kind="stable"):
                ii = int(i)
                if ii in selected_set:
                    continue
                selected.append(ii); selected_set.add(ii)
                if len(selected) >= target:
                    break
            chosen = np.asarray(selected, dtype=int)
            portfolio_relaxation = True
    if chosen.size != target:
        raise RuntimeError(f"ENGINE_INTEGRITY_FAILURE:WNBA_SHOWDOWN_NONEMPTY_BOARD_CARDINALITY:{chosen.size}:{target}")
    metrics["chosen"] = chosen
    metrics["final_board_target"] = np.array([target])
    metrics["portfolio_preference_relaxation"] = np.array([int(portfolio_relaxation)])
    if portfolio_relaxation:
        state = f"NONEMPTY_PHASE3_BOARD_COMPLETE_RELAXED:{tier_name}:BOARD_{chosen.size}:MAX_{cfg.board_size}"
    else:
        state = f"DEEP_EQUALIZED_RESILIENCE_FAMILY_MILP_COMPLETE:{tier_name}:BOARD_{chosen.size}:MAX_{cfg.board_size}:CORE_CAP_{core_cap_used}:MACRO_CAP_{macro_cap_used}"
    return rows[chosen], metrics, state


def _write_outputs(board: np.ndarray, rows: np.ndarray, metrics: dict[str, np.ndarray], p2meta: dict[str, np.ndarray], cal, cfg: Config,
                   pool: str | Path, board_path: str | Path, receipt_path: str | Path, ledger_path: str | Path | None,
                   identity_path: str | Path | None, legal_count: int, sim: dict[str, object], selector_state: str,
                   runtime: float, out_names: Sequence[str], out_evidence: Sequence[dict[str, str]], out_evidence_hash: str) -> dict:
    chosen = np.asarray(metrics.get("chosen", np.array([], int)), int)
    board_rows = []
    for rank, (row, idx) in enumerate(zip(board, chosen, strict=True), start=1):
        names = cal.frame.iloc[row]["PLAYER"].astype(str).tolist()
        teams = cal.frame.iloc[row]["TEAM"].astype(str).tolist()
        util_salary = cal.frame.iloc[row]["SAL"].astype(int).to_numpy()
        total = int((util_salary[0] * 3) // 2 + util_salary[1:].sum())
        board_rows.append({
            "RANK": rank, "CPT": names[0], "UTIL1": names[1], "UTIL2": names[2], "UTIL3": names[3], "UTIL4": names[4], "UTIL5": names[5],
            "CPT_TEAM": teams[0], "SALARY": total, "SCRIPT": int(p2meta["script"][idx]),
            "MACRO_FAMILY_ID": int(p2meta["macro_family_id"][idx]), "CORE_FAMILY_ID": int(p2meta["core_family_id"][idx]),
            "VALUE_FAMILY_ID": int(p2meta["value_family_id"][idx]), "VALUE_PAIR_ID": int(p2meta["value_pair_id"][idx]),
            "FAMILY_SHAPE": f"{int(p2meta['elite_count'][idx])}-{int(p2meta['mid_count'][idx])}-{int(p2meta['value_count'][idx])}",
            "BIRTH_REASON_MASK": int(p2meta["birth_reason"][idx]),
            "ROBUST_SELECTOR_SCORE": float(metrics["score"][idx]),
            "BASELINE_RESILIENCE": float(metrics["baseline_resilience"][idx]),
            "TAIL_DEPENDENCY_COUNT": int(metrics["tail_dependency_count"][idx]),
            "ROLE_CONFLICT_COUNT": int(metrics["role_conflict_count"][idx]),
            "TOP_0_1_RATE": float(metrics["top01"][idx]), "WIN_RATE": float(metrics["win"][idx]),
            "TOP10_RATE": float(metrics["top10"][idx]), "P99": float(metrics["p99"][idx]), "P95": float(metrics["p95"][idx]),
            "MEAN": float(metrics["mean"][idx]), "EXPECTED_DUP": float(metrics["expected_dup"][idx]), "TRIALS": int(metrics["trials"][idx]),
        })
    board_df = pd.DataFrame(board_rows)
    board_df.to_csv(board_path, index=False)

    if ledger_path is None:
        ledger_path = Path(receipt_path).with_name(Path(receipt_path).stem + "_selector_ledger.csv")
    ledger = pd.DataFrame({
        "ANON_ID": [hashlib.sha256(np.asarray(r, dtype=np.int16).tobytes()).hexdigest()[:16] for r in rows],
        "CPT_ID": rows[:, 0], "SCRIPT": p2meta["script"], "SALARY": p2meta["salary"],
        "MACRO_FAMILY_ID": p2meta["macro_family_id"], "CORE_FAMILY_ID": p2meta["core_family_id"],
        "VALUE_FAMILY_ID": p2meta["value_family_id"], "VALUE_PAIR_ID": p2meta["value_pair_id"], "ROLE_FAMILY_ID": p2meta["role_family_id"],
        "BIRTH_REASON_MASK": p2meta["birth_reason"],
        "TOP_0_1_RATE": metrics["top01"], "WIN_RATE": metrics["win"], "TOP10_RATE": metrics["top10"],
        "P99": metrics["p99"], "P95": metrics["p95"], "MEAN": metrics["mean"], "EXPECTED_DUP": metrics["expected_dup"],
        "TRIALS": metrics["trials"],
        "ROBUST_SELECTOR_SCORE": metrics["score"],
        "BASELINE_RESILIENCE": metrics["baseline_resilience"],
        "TAIL_GAP": metrics["tail_gap"],
        "TAIL_DEPENDENCY_COUNT": metrics["tail_dependency_count"],
        "ROLE_CONFLICT_COUNT": metrics["role_conflict_count"],
        "STRICT_ELIGIBLE": np.isin(np.arange(len(rows)), metrics["strict_eligible"]),
        "ROBUST_ELIGIBLE": np.isin(np.arange(len(rows)), metrics["robust_eligible"]),
        "SELECTED": np.isin(np.arange(len(rows)), chosen),
    })
    ledger.to_csv(ledger_path, index=False)

    if identity_path is None:
        identity_path = Path(receipt_path).with_name(Path(receipt_path).stem + "_sealed_identity_map.csv")
    player_names = cal.frame["PLAYER"].astype(str).to_numpy()
    util_names = np.sort(player_names[rows[:, 1:]], axis=1)
    identity_df = pd.DataFrame({
        "ANON_ID": ledger["ANON_ID"].to_numpy(),
        "CPT": player_names[rows[:, 0]],
        "UTILS": ["|".join(x) for x in util_names],
    })
    identity_df.to_csv(identity_path, index=False)
    identity = identity_df

    receipt = {
        "ENGINE_ID": ENGINE_ID,
        "PATCH_ID": PATCH_ID,
        "HANDOFF_PATCH_ID": HANDOFF_PATCH_ID,
        "DOCTRINE_ID": DOCTRINE_ID,
        "PLATFORM": "DRAFTKINGS",
        "SPORT": "WNBA",
        "MODE": "SHOWDOWN",
        "PREDICTIVE_LAYER_PATCH_ID": cal.global_strategy_receipt["PREDICTIVE_LAYER_PATCH_ID"],
        "PREDICTIVE_LAYER_STATUS": cal.global_strategy_receipt["PREDICTIVE_LAYER_STATUS"],
        "PREDICTION_HASH": cal.global_strategy_receipt["PREDICTION_HASH"],
        "RAW_MARKET_INPUT_HASH": cal.global_strategy_receipt["RAW_MARKET_INPUT_HASH"],
        "PLAYER_MARKET_ROWS": cal.global_strategy_receipt["PLAYER_MARKET_ROWS"],
        "GAME_MARKET_ROWS": cal.global_strategy_receipt["GAME_MARKET_ROWS"],
        "MORE_DECISIONS": cal.global_strategy_receipt["MORE_DECISIONS"],
        "LESS_DECISIONS": cal.global_strategy_receipt["LESS_DECISIONS"],
        "PASS_DECISIONS": cal.global_strategy_receipt["PASS_DECISIONS"],
        "STALE_LINE_SIGNALS": cal.global_strategy_receipt["STALE_LINE_SIGNALS"],
        "PREDICTION_FROZEN": cal.global_strategy_receipt["PREDICTION_FROZEN"],
        "STRATEGY_CONSUMED_PREDICTION_HASH": cal.global_strategy_receipt["STRATEGY_CONSUMED_PREDICTION_HASH"],
        "FIELD_SIZE": cfg.field_size,
        "POOL_SHA256": _sha256_file(pool),
        "ACTIVE_POOL": int(len(np.unique(rows))),
        "OUT_PURGE": list(cal.out_purge),
        "ZERO_MIN_PURGE": list(cal.zero_min_purge),
        "EXPLICIT_OUT_INPUT": list(out_names),
        "CONFIRMED_OUT_EVIDENCE": list(out_evidence),
        "CONFIRMED_OUT_EVIDENCE_HASH": out_evidence_hash,
        "HARD_OUT_EVIDENCE_CHECK": "PASS",
        "SHOWDOWN_ROLE_SCRIPT_CALIBRATION_PATCH": ROLE_SCRIPT_CALIBRATION_PATCH_ID,
        "SHOWDOWN_CONFIRMED_STARTER_RECENT_ROLE_CONTINUITY": "PASS",
        "SHOWDOWN_ROLE_SCRIPT_SHARED_FRACTION": float(getattr(cal, "showdown_role_script_shared_fraction", SHOWDOWN_ROLE_SCRIPT_SHARED_FRACTION)),
        "SHOWDOWN_ROLE_SCRIPT_CALIBRATION_AUDIT": getattr(cal, "showdown_role_script_calibration_audit", []),
        "SHOWDOWN_ROLE_TAIL_GUARD": "PASS",
        "SHOWDOWN_ROLE_TAIL_GUARD_AUDIT": getattr(cal, "showdown_tail_guard_audit", []),
        "SELECTOR_MODE": str(metrics.get("selector_mode", np.array(["UNKNOWN"]))[0]),
        "FINAL_SELECTOR_DEEP_EQUALIZATION": "PASS",
        "DEEP_EQUALIZED_CANDIDATES": int(metrics.get("deep_equalized_candidates", np.array([0]))[0]),
        "DEEP_EQUALIZED_TRIALS_PER_CANDIDATE": int(metrics.get("deep_equalized_trials", np.array([0]))[0]),
        "SELECTOR_DEEP_EQUALIZATION_EXTRA_TRIALS_TOTAL": int(metrics.get("deep_equalization_extra_total", np.array([0]))[0]),
        "ROBUST_GATE_QUANTILE": cfg.robust_gate_quantile,
        "ROBUST_GATE_SCORE": float(metrics.get("robust_gate_score", np.array([float("nan")]))[0]),
        "COMPOUNDED_TAIL_DEPENDENCY_CAP": cfg.max_tail_dependencies,
        "TAIL_DEPENDENCY_PENALTY": cfg.tail_dependency_penalty,
        "ROLE_CONFLICT_PENALTY": cfg.role_conflict_penalty,
        "STRUCTURAL_CAPTAINS": [],
        "FAMILY_BIRTH_STATE": "PASS",
        "LEGAL_MACRO_FAMILIES": int(p2meta["macro_family_count_all"][0]),
        "LEGAL_CORE_FAMILIES": int(p2meta["core_family_count_all"][0]),
        "LEGAL_VALUE_FAMILIES": int(p2meta["value_family_count_all"][0]),
        "LEGAL_VALUE_PAIRS": int(p2meta["value_pair_count_all"][0]),
        "LEGAL_ROLE_FAMILIES": int(p2meta["role_family_count_all"][0]),
        "PHASE2_MACRO_FAMILIES_BORN": int(np.unique(p2meta["macro_family_id"]).size),
        "PHASE2_CORE_FAMILIES_BORN": int(np.unique(p2meta["core_family_id"]).size),
        "PHASE2_VALUE_FAMILIES_BORN": int(np.unique(p2meta["value_family_id"]).size),
        "PHASE2_ROLE_FAMILIES_BORN": int(np.unique(p2meta["role_family_id"]).size),
        "CORE_FAMILY_SEEDS_BORN": int(np.count_nonzero(p2meta["birth_reason"] & 4)),
        "CORE_FAMILY_SIBLING_CLOSURE_LINEUPS": int(np.count_nonzero(p2meta["birth_reason"] & 8)),
        "GLOBAL_CHAMPION_BIRTHS": int(np.count_nonzero(p2meta["birth_reason"] & 1)),
        "MACRO_FAMILY_BIRTHS": int(np.count_nonzero(p2meta["birth_reason"] & 2)),
        "VALUE_FAMILY_BIRTHS": int(np.count_nonzero(p2meta["birth_reason"] & 16)),
        "ROLE_FAMILY_BIRTHS": int(np.count_nonzero(p2meta["birth_reason"] & 32)),
        "FINAL_BOARD_CORE_FAMILIES": int(np.unique(p2meta["core_family_id"][chosen]).size) if chosen.size else 0,
        "FINAL_BOARD_MACRO_FAMILIES": int(np.unique(p2meta["macro_family_id"][chosen]).size) if chosen.size else 0,
        "CORE_FAMILY_CAP_USED": int(metrics.get("core_family_cap_used", np.array([0]))[0]),
        "MACRO_FAMILY_CAP_USED": int(metrics.get("macro_family_cap_used", np.array([0]))[0]),
        "DOMINANT_VALUE_PAIR_ID": int(metrics.get("dominant_value_pair_id", np.array([-1]))[0]),
        "FAMILY_CHAMPIONS_CERTIFIED_COUNT": int(len(np.asarray(metrics.get("family_certified_champions", np.array([], int))))),
        "FAMILY_BUNDLE_REQUIRED_COUNT": int(len(np.asarray(metrics.get("required_family_bundle", np.array([], int))))),
        "FAMILY_BUNDLE_SELECTED_COUNT": int(np.isin(chosen, np.asarray(metrics.get("required_family_bundle", np.array([], int)))).sum()) if chosen.size else 0,
        "CALIBRATION_QUALIFIED_PLAYERS": int(cal.qualified.sum()),
        "FULL_CALIBRATION_PARITY": "PASS",
        "CALIBRATION_CONTRACT_HASH_PHASE1": cal.calibration_contract_hash,
        "PLAYER_IDENTIFIER_HASH": cal.player_identifier_hash,
        "OWNERSHIP_HASH": cal.ownership_hash,
        "CEILING_HASH": cal.ceiling_hash,
        "ROLE_STATE_HASH": cal.role_state_hash,
        "TEAM_GAME_FEATURE_HASH": cal.team_game_feature_hash,
        "METRIC_SCALING_HASH": cal.metric_scaling_hash,
        "SIMULATION_MATRIX_HASH": cal.simulation_matrix_hash,
        "ROSTER_RULE": ROSTER_RULE,
        "SALARY_MIN": SALARY_MIN,
        "SALARY_MAX": SALARY_MAX,
        "MAX_FROM_TEAM": MAX_FROM_TEAM,
        "LEGAL_LINEUPS_SCANNED": int(legal_count),
        "PHASE2_BUILT_LINEUPS": int(len(rows)),
        "BASE_SIM_TRIALS": cfg.base_trials,
        "BUBBLE_CANDIDATES": int(len(np.asarray(sim["bubble"]))),
        "BUBBLE_EXTRA_TRIALS_PER_LINEUP": cfg.extra_trials,
        "BUBBLE_EXTRA_TRIALS_TOTAL": int(sim["bubble_extra_total"]),
        "BUBBLE_LINEUPS_UNRESOLVED": 0,
        "HANDOFF_SURVIVORS": int(len(rows)),
        "SELECTOR_REVIEWED_LINEUPS": int(metrics["selector_reviewed"][0]),
        "STRICT_SURVIVORS": int(len(metrics["strict_eligible"])),
        "ROBUST_FAMILY_SURVIVORS": int(len(metrics["robust_eligible"])),
        "FAKE_FIELD_LINEUPS": int(len(np.asarray(sim["fake_field"]))),
        "FINAL_BOARD_TARGET_MAX": cfg.board_size,
        "FINAL_BOARD_TARGET": int(np.asarray(metrics.get("final_board_target", np.array([min(cfg.board_size, len(rows))])))[0]),
        "FINAL_BOARD_SIZE": int(len(board)),
        "BOARD_NOT_FILLED_REASON": "NOT_APPLICABLE" if len(board) == int(np.asarray(metrics.get("final_board_target", np.array([min(cfg.board_size, len(rows))])))[0]) else "ENGINE_INTEGRITY_FAILURE",
        "NONEMPTY_BOARD_POLICY": "APEX_GLOBAL_NONEMPTY_PRODUCTION_BOARD_v1",
        "PORTFOLIO_PREFERENCE_RELAXATION": bool(int(np.asarray(metrics.get("portfolio_preference_relaxation", np.array([0])))[0])),
        "FILLERS": 0,
        "RANK_ALL": False,
        "SELECTOR_STATE": selector_state,
        "FINAL_SALARY_RECOMPUTE": board_df["SALARY"].astype(int).tolist() if len(board_df) else [],
        "FULL_ORDER_LEDGER_ROWS": int(len(ledger)),
        "FULL_ORDER_LEDGER_SHA256": _sha256_file(ledger_path),
        "SEALED_IDENTITY_MAP_ROWS": int(len(identity_df)),
        "SEALED_IDENTITY_MAP_SHA256": _sha256_file(identity_path),
        "BOARD_SHA256": _sha256_file(board_path),
        "BOARD": board_rows,
        "RUNTIME_SECONDS": runtime,
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
    }
    Path(receipt_path).write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    return receipt


def run(pool: str | Path, field_size: int, out_names: Sequence[str], board_path: str | Path, receipt_path: str | Path,
        seed: int | None = None, ledger_path: str | Path | None = None, identity_path: str | Path | None = None,
        out_evidence_path: str | Path | None = None, availability_receipt: str | Path | None = None,
        execution_id: str | int | None = None) -> dict:
    started = time.perf_counter()
    cfg = Config(field_size=int(field_size), seed=int(seed if seed is not None else field_size))
    resolved_execution_id = str(execution_id if execution_id is not None else field_size)
    roster_gate = require_prebuild_roster_check(
        availability_receipt, sport="WNBA", mode="SHOWDOWN", pool_path=pool,
        execution_id=resolved_execution_id, field_size=field_size,
    )
    verified_out = verified_out_names(roster_gate, out_names)
    out_evidence, out_evidence_hash = _validate_out_evidence(out_names, out_evidence_path)
    cal, ids = _load_calibration(pool, verified_out, cfg)
    all_rows, legal_meta = _enumerate(cal, ids)
    phase2, p2meta = _phase2(all_rows, legal_meta, cal, cfg)
    sim = _simulate(phase2, all_rows, p2meta, cal, cfg)
    board, metrics, selector_state = _select(phase2, p2meta, sim, cal, cfg)
    # Board-first identity reconciliation.
    preview = []
    chosen = np.asarray(metrics.get("chosen", np.array([], int)), int)
    for rank, (row, idx) in enumerate(zip(board, chosen, strict=True), start=1):
        names = cal.frame.iloc[row]["PLAYER"].astype(str).tolist()
        salaries = cal.frame.iloc[row]["SAL"].astype(int).to_numpy()
        preview.append({"rank": rank, "salary": int((salaries[0] * 3) // 2 + salaries[1:].sum()), "CPT": names[0], "UTIL": names[1:]})
    print(json.dumps({
        "RUN_STATE": "BOARD_READY", "PRODUCTION_TRIGGER_DIRECT_EXECUTION": "PASS", "DIAGNOSTIC_ROUTING": "DISABLED",
        "BOARD_FIRST_RENDERING": "PASS", "BOARD_IDENTITY_RECONCILIATION": "PASS", "FINAL_BOARD_SIZE": len(preview), "FINAL_BOARD": preview,
    }, indent=2), flush=True)
    result = _write_outputs(board, phase2, metrics, p2meta, cal, cfg, pool, board_path, receipt_path, ledger_path, identity_path,
                          len(all_rows), sim, selector_state, time.perf_counter() - started, verified_out, out_evidence, out_evidence_hash)
    result["PREBUILD_ROSTER_CHECK"] = gate_receipt(roster_gate)
    Path(receipt_path).write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result


def _args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--pool", required=True)
    p.add_argument("--field-size", required=True, type=int)
    p.add_argument("--out", action="append", default=[])
    p.add_argument("--out-evidence-json")
    p.add_argument("--availability-receipt", required=True)
    p.add_argument("--execution-id", required=True)
    p.add_argument("--board", required=True)
    p.add_argument("--receipt", required=True)
    p.add_argument("--ledger")
    p.add_argument("--identity-map")
    p.add_argument("--seed", type=int)
    return p.parse_args()


def main() -> int:
    a = _args()
    r = run(a.pool, a.field_size, a.out, a.board, a.receipt, a.seed, a.ledger, a.identity_map, a.out_evidence_json, a.availability_receipt, a.execution_id)
    for key in (
        "ENGINE_ID", "ACTIVE_POOL", "OUT_PURGE", "CALIBRATION_QUALIFIED_PLAYERS", "FULL_CALIBRATION_PARITY",
        "PHASE2_BUILT_LINEUPS", "BASE_SIM_TRIALS", "BUBBLE_EXTRA_TRIALS_TOTAL", "BUBBLE_LINEUPS_UNRESOLVED",
        "HANDOFF_SURVIVORS", "SELECTOR_REVIEWED_LINEUPS", "FINAL_BOARD_SIZE", "EXECUTION_STATE",
    ):
        print(f"{key}={r[key]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
