#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

PATCH_ID = "WNBA_CLASSIC_RAW_HOLDOUT_AUTO_INGEST_AND_AUTONOMOUS_LOSO_TRIGGER_v1"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scan_vault(vault: Path) -> list[dict[str, Any]]:
    rows = []
    for p in sorted(vault.rglob("pair_manifest.json")):
        d = json.loads(p.read_text())
        if d.get("MODE") != "WNBA_CLASSIC":
            continue
        d["MANIFEST_PATH"] = str(p)
        d["PAIR_ROOT"] = str(p.parent)
        rows.append(d)
    return rows


def distinct_folds(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    best: dict[str, dict[str, Any]] = {}
    for row in rows:
        slate = row.get("SLATE_SHA256")
        if not slate:
            continue
        cur = best.get(slate)
        if cur is None or str(row.get("CONTEST_SHA256", "")) < str(cur.get("CONTEST_SHA256", "")):
            best[slate] = row
    return [best[k] for k in sorted(best)]


def build_plan(vault: Path, output_dir: Path, execute: bool, engine_root: Path | None = None) -> dict[str, Any]:
    rows = scan_vault(vault)
    folds = distinct_folds(rows)
    bands = sorted({str(x.get("FIELD_BAND")) for x in folds if x.get("FIELD_BAND")})
    reasons = []
    if len(folds) < 5:
        reasons.append(f"DISTINCT_BYTE_COMPLETE_SLATE_COUNT_{len(folds)}_LT_5")
    if len(bands) < 2:
        reasons.append(f"FIELD_BAND_COUNT_{len(bands)}_LT_2")
    ready = not reasons
    output_dir.mkdir(parents=True, exist_ok=True)
    plan_rows = []
    for i, f in enumerate(folds, start=1):
        pair_root = Path(f["PAIR_ROOT"])
        plan_rows.append({
            "FOLD": i,
            "SLATE_SHA256": f["SLATE_SHA256"],
            "PAIR_SHA256": f["PAIR_SHA256"],
            "FIELD_SIZE": int(f["FIELD_SIZE"]),
            "FIELD_BAND": f["FIELD_BAND"],
            "POOL": str(pair_root / Path(f["POOL_FILE"]).relative_to(Path(f["POOL_FILE"]).parts[0]) if False else vault / f["POOL_FILE"]),
            "CONTEST": str(vault / f["CONTEST_FILE"]),
            "OUT_PLAYERS": f.get("OUT_PLAYERS", []),
        })
    plan = {
        "PATCH_ID": PATCH_ID,
        "MODE": "SHADOW_RESEARCH_ONLY",
        "DISTINCT_BYTE_COMPLETE_SLATES": len(folds),
        "FIELD_BANDS": bands,
        "LOSO_READY": ready,
        "LOSO_TRIGGERED": bool(ready),
        "LOSO_EXECUTED": False,
        "FAIL_CLOSED": not ready,
        "BLOCK_REASONS": reasons,
        "PRODUCTION_MUTATED": False,
        "PRODUCTION_PROMOTION_ALLOWED": False,
        "FOLDS": plan_rows,
    }
    (output_dir / "loso_fold_plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    if not ready or not execute:
        plan["NEXT_ACTION"] = "WAIT_FOR_MINIMUM_RAW_PAIRS" if not ready else "EXECUTE_AUTONOMOUS_LOSO_CONTROLLER"
        (output_dir / "loso_controller_receipt.json").write_text(json.dumps(plan, indent=2) + "\n")
        return plan
    if engine_root is None:
        raise RuntimeError("ENGINE_ROOT_REQUIRED_FOR_EXECUTION")
    results = []
    for fold in plan_rows:
        fold_dir = output_dir / f"fold_{fold['FOLD']:02d}_{fold['SLATE_SHA256'][:12]}"
        fold_dir.mkdir(parents=True, exist_ok=True)
        replay_receipt = fold_dir / "research_replay_receipt.json"
        cmd = [sys.executable, str(engine_root / "engines/wnba/wnba_loso_research_replay_v1.py"),
               "--engine-root", str(engine_root), "--pool", fold["POOL"], "--contest", fold["CONTEST"],
               "--field-size", str(fold["FIELD_SIZE"]), "--output-dir", str(fold_dir),
               "--raw-holdout-pairs", str(len(folds))]
        for out in fold["OUT_PLAYERS"]:
            cmd += ["--out", str(out)]
        subprocess.run(cmd, check=True, cwd=engine_root)
        replay = json.loads(replay_receipt.read_text())
        m = replay["POSTLOCK_MATCH"]
        results.append({"FOLD": fold["FOLD"], **m})
    n = len(results)
    prod_hits = sum(bool(r["PRODUCTION_RANK1_CAPTURE"]) for r in results)
    shadow_hits = sum(bool(r["SHADOW_RANK1_CAPTURE"]) for r in results)
    board_caps = sum(bool(r["WINNER_SELECTED_TO_PRODUCTION_BOARD"]) for r in results)
    plan.update({
        "LOSO_EXECUTED": True,
        "FAIL_CLOSED": False,
        "FOLD_RESULTS": results,
        "PRODUCTION_RANK1_HITS": prod_hits,
        "SHADOW_RANK1_HITS": shadow_hits,
        "PRODUCTION_RANK1_HIT_RATE": prod_hits / n if n else 0.0,
        "SHADOW_RANK1_HIT_RATE": shadow_hits / n if n else 0.0,
        "WINNER_BOARD_CAPTURE_RATE": board_caps / n if n else 0.0,
        "PROMOTION_REVIEW_ELIGIBLE": bool(shadow_hits > prod_hits and n >= 5),
        "PRODUCTION_PROMOTION_ALLOWED": False,
        "NEXT_ACTION": "SEPARATE_MULTI_SLATE_CERTIFICATION_REVIEW",
    })
    (output_dir / "loso_controller_receipt.json").write_text(json.dumps(plan, indent=2) + "\n")
    return plan


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--vault", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--execute", action="store_true")
    p.add_argument("--engine-root")
    a = p.parse_args()
    result = build_plan(Path(a.vault), Path(a.output_dir), a.execute, Path(a.engine_root) if a.engine_root else None)
    print(json.dumps({k: result[k] for k in (
        "DISTINCT_BYTE_COMPLETE_SLATES", "FIELD_BANDS", "LOSO_READY",
        "LOSO_TRIGGERED", "LOSO_EXECUTED", "FAIL_CLOSED", "PRODUCTION_PROMOTION_ALLOWED"
    )}, indent=2))
    return 0 if not result["FAIL_CLOSED"] or not a.execute else 2


if __name__ == "__main__":
    raise SystemExit(main())
