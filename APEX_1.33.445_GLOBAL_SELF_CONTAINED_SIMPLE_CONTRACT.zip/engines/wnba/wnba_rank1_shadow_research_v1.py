#!/usr/bin/env python3
"""WNBA Classic rank-1 shadow research harness.

This module consumes only the anonymous pre-lock selector ledger. It may propose a
shadow ordering, but it cannot alter production board composition or order. Same-slate
results are never read here and same-slate diagnostics are not blind proof.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

RESEARCH_ID = "WNBA_CLASSIC_SELECTOR_RANK1_OPEN_RESEARCH_v1"
GOVERNANCE_ID = "WNBA_CLASSIC_SELECTOR_RANK1_OPEN_RESEARCH_GOVERNANCE_v1"
REQUIRED_RAW_HOLDOUT_PAIRS = 5
PREFERRED_RAW_HOLDOUT_PAIRS = 10
REQUIRED_COLUMNS = {
    "LINEUP_ID", "GLOBAL_PHASE3_RANK", "SCENARIO_CLUSTER",
    "SCENARIO_RELATIVE_RANK", "SELECTION_VECTOR", "PORTFOLIO_PENALTIES",
    "FINAL_RANK", "SELECTED", "REJECTED", "REJECTION_REASON", "MC_TRIALS",
    "MC_MEAN", "MC_P95", "MC_P99", "MC_WIN_RATE", "MC_TOP_0_1_RATE",
    "MC_TOP_10_RATE", "EXPECTED_DUP", "LINEUP_SALARY", "SELECTOR_SCORE",
    "SCENARIO_LANE_MEMBER", "DENSE_SPINE_BRIDGE", "QUALIFIED_BRIDGE_COUNT",
    "FALSE_BRIDGE_COUNT", "SHADOW_RANK1_ELIGIBLE",
}
PROHIBITED_COLUMNS = {
    "PLAYER", "TEAM", "ACTUAL", "ACTUAL_FPTS", "CONTEST_RANK",
    "TARGET_ACTUAL_SCORE", "FINAL_BOARD_RANKS",
}


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def wilson_bounds(rate: np.ndarray, trials: np.ndarray, z: float = 1.96) -> tuple[np.ndarray, np.ndarray]:
    p = np.asarray(rate, dtype=float)
    n = np.maximum(np.asarray(trials, dtype=float), 1.0)
    den = 1.0 + z * z / n
    center = p + z * z / (2.0 * n)
    spread = z * np.sqrt((p * (1.0 - p) + z * z / (4.0 * n)) / n)
    return np.maximum(0.0, (center - spread) / den), np.minimum(1.0, (center + spread) / den)


def wilson_lower(rate: np.ndarray, trials: np.ndarray, z: float = 1.96) -> np.ndarray:
    return wilson_bounds(rate, trials, z)[0]


def run_shadow_research(
    ledger_path: str | Path,
    output_order: str | Path,
    output_receipt: str | Path,
    *,
    seed: int = 713,
    posterior_draws: int = 20_000,
    raw_holdout_pairs_available: int = 1,
) -> dict:
    ledger = pd.read_csv(ledger_path)
    missing = sorted(REQUIRED_COLUMNS - set(ledger.columns))
    if missing:
        raise ValueError(f"MISSING_LEDGER_COLUMNS={','.join(missing)}")
    leaked = sorted(PROHIBITED_COLUMNS & set(ledger.columns))
    if leaked:
        raise RuntimeError(f"POSTLOCK_OR_IDENTITY_LEAK={','.join(leaked)}")
    if ledger["LINEUP_ID"].duplicated().any():
        raise RuntimeError("DUPLICATE_ANONYMOUS_LINEUP_ID")

    board = ledger.loc[ledger["SELECTED"].astype(bool)].copy()
    board.sort_values("FINAL_RANK", inplace=True, kind="mergesort")
    expected_ranks = list(range(1, len(board) + 1))
    if board["FINAL_RANK"].astype(int).tolist() != expected_ranks:
        raise RuntimeError("PRODUCTION_FINAL_RANK_SEQUENCE_INVALID")

    trials = board["MC_TRIALS"].to_numpy(float)
    top01_lcb = wilson_lower(board["MC_TOP_0_1_RATE"].to_numpy(float), trials)
    win_lcb = wilson_lower(board["MC_WIN_RATE"].to_numpy(float), trials)
    board["TOP01_WILSON_LCB"] = top01_lcb
    board["WIN_WILSON_LCB"] = win_lcb

    # Research-only rule derived from the existing structural doctrine: among certified
    # scenario-lane representatives, a dense anchor spine plus qualified value bridges
    # may be tested as the shadow rank-1 lane. No player/team identities are available.
    eligible = board.loc[
        board["SHADOW_RANK1_ELIGIBLE"].astype(bool)
        & board["SCENARIO_LANE_MEMBER"].astype(bool)
        & board["DENSE_SPINE_BRIDGE"].astype(bool)
        & board["QUALIFIED_BRIDGE_COUNT"].astype(int).ge(2)
        & board["FALSE_BRIDGE_COUNT"].astype(int).eq(0)
    ].copy()

    if len(eligible):
        eligible["SALARY_RELEASE"] = 50_000 - eligible["LINEUP_SALARY"].astype(int)
        e_trials = eligible["MC_TRIALS"].to_numpy(float)
        top01_low, top01_high = wilson_bounds(eligible["MC_TOP_0_1_RATE"].to_numpy(float), e_trials)
        win_low, win_high = wilson_bounds(eligible["MC_WIN_RATE"].to_numpy(float), e_trials)
        top10_low, top10_high = wilson_bounds(eligible["MC_TOP_10_RATE"].to_numpy(float), e_trials)
        best_top01 = int(np.argmax(eligible["MC_TOP_0_1_RATE"].to_numpy(float)))
        best_win = int(np.argmax(eligible["MC_WIN_RATE"].to_numpy(float)))
        best_top10 = int(np.argmax(eligible["MC_TOP_10_RATE"].to_numpy(float)))
        eligible["TOP01_WILSON_TIE"] = top01_high >= top01_low[best_top01]
        eligible["WIN_WILSON_TIE"] = win_high >= win_low[best_win]
        eligible["TOP10_WILSON_TIE"] = top10_high >= top10_low[best_top10]
        eligible.sort_values(
            [
                "TOP01_WILSON_TIE", "WIN_WILSON_TIE", "SALARY_RELEASE",
                "EXPECTED_DUP", "TOP10_WILSON_TIE", "MC_P99", "MC_P95",
                "MC_MEAN", "GLOBAL_PHASE3_RANK", "LINEUP_ID",
            ],
            ascending=[False, False, False, True, False, False, False, False, True, True],
            inplace=True,
            kind="mergesort",
        )
        leader_id = str(eligible.iloc[0]["LINEUP_ID"])
        shadow = pd.concat([
            board.loc[board["LINEUP_ID"].eq(leader_id)],
            board.loc[~board["LINEUP_ID"].eq(leader_id)],
        ], ignore_index=True)
        leader_reason = "CERTIFIED_DENSE_SPINE_QUALIFIED_BRIDGE_LANE_LEADER"
    else:
        shadow = board.copy().reset_index(drop=True)
        leader_id = str(shadow.iloc[0]["LINEUP_ID"]) if len(shadow) else ""
        leader_reason = "NO_CERTIFIED_SHADOW_LANE_PRESERVE_PRODUCTION_ORDER"

    shadow["PRODUCTION_RANK"] = shadow["FINAL_RANK"].astype(int)
    shadow["SHADOW_RANK"] = np.arange(1, len(shadow) + 1, dtype=int)
    shadow["SHADOW_REASON"] = np.where(
        shadow["SHADOW_RANK"].eq(1), leader_reason, "PRODUCTION_RELATIVE_ORDER_PRESERVED"
    )

    # MC-only posterior rank-1 stability is diagnostic and does not control the structural
    # shadow promotion. It quantifies how often each board row leads under sampling noise.
    rng = np.random.default_rng(seed)
    n = len(board)
    if n:
        top_counts = np.rint(board["MC_TOP_0_1_RATE"].to_numpy(float) * trials)
        win_counts = np.rint(board["MC_WIN_RATE"].to_numpy(float) * trials)
        top_draw = rng.beta(top_counts + 0.5, np.maximum(trials - top_counts, 0) + 0.5, size=(posterior_draws, n))
        win_draw = rng.beta(win_counts + 0.5, np.maximum(trials - win_counts, 0) + 0.5, size=(posterior_draws, n))
        fixed = (
            0.050 * board["MC_P99"].to_numpy(float)
            + 0.020 * board["MC_P95"].to_numpy(float)
            + 0.002 * board["MC_MEAN"].to_numpy(float)
            - 0.010 * board["EXPECTED_DUP"].to_numpy(float)
        )
        draw_score = 1000.0 * top_draw + 100.0 * win_draw + fixed[None, :]
        winners = np.argmax(draw_score, axis=1)
        probability = np.bincount(winners, minlength=n) / float(posterior_draws)
        rank1_prob = dict(zip(board["LINEUP_ID"].astype(str), probability, strict=True))
    else:
        rank1_prob = {}
    shadow["MC_ONLY_POSTERIOR_RANK1_PROBABILITY"] = shadow["LINEUP_ID"].map(rank1_prob).fillna(0.0)

    output_cols = [
        "LINEUP_ID", "SHADOW_RANK", "PRODUCTION_RANK", "SHADOW_REASON",
        "GLOBAL_PHASE3_RANK", "SCENARIO_CLUSTER", "SCENARIO_RELATIVE_RANK",
        "MC_TRIALS", "MC_MEAN", "MC_P95", "MC_P99", "MC_WIN_RATE",
        "MC_TOP_0_1_RATE", "MC_TOP_10_RATE", "TOP01_WILSON_LCB",
        "WIN_WILSON_LCB", "EXPECTED_DUP", "LINEUP_SALARY",
        "MC_ONLY_POSTERIOR_RANK1_PROBABILITY",
    ]
    out_order = Path(output_order)
    out_order.parent.mkdir(parents=True, exist_ok=True)
    shadow[output_cols].to_csv(out_order, index=False)

    production_order = board["LINEUP_ID"].astype(str).tolist()
    shadow_order = shadow["LINEUP_ID"].astype(str).tolist()
    receipt = {
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "RESEARCH_ID": RESEARCH_ID,
        "GOVERNANCE_ID": GOVERNANCE_ID,
        "VALIDATION_CLASS": "SAME_SLATE_DIAGNOSTIC_ONLY",
        "BLIND_PROOF_CLAIMED": False,
        "PRODUCTION_BOARD_MUTATED": False,
        "PRODUCTION_ORDER_MUTATED": False,
        "SHADOW_ORDER_ONLY": True,
        "LEDGER_PATH": str(ledger_path),
        "LEDGER_SHA256": sha256_file(ledger_path),
        "LEDGER_ROWS": int(len(ledger)),
        "PRODUCTION_BOARD_SIZE": int(len(board)),
        "SHADOW_BOARD_SIZE": int(len(shadow)),
        "SHADOW_RANK1_ELIGIBLE_COUNT": int(len(eligible)),
        "SHADOW_RANK1_LINEUP_ID": leader_id,
        "SHADOW_RANK1_PRODUCTION_RANK": int(board.loc[board["LINEUP_ID"].eq(leader_id), "FINAL_RANK"].iloc[0]) if leader_id else 0,
        "SHADOW_ORDER_CHANGED": shadow_order != production_order,
        "POSTERIOR_DRAWS": int(posterior_draws),
        "RAW_HOLDOUT_PAIRS_AVAILABLE": int(raw_holdout_pairs_available),
        "RAW_HOLDOUT_PAIRS_REQUIRED": REQUIRED_RAW_HOLDOUT_PAIRS,
        "RAW_HOLDOUT_PAIRS_PREFERRED": PREFERRED_RAW_HOLDOUT_PAIRS,
        "PRODUCTION_PROMOTION_ALLOWED": raw_holdout_pairs_available >= REQUIRED_RAW_HOLDOUT_PAIRS,
        "PRODUCTION_PROMOTION_DECISION": (
            "ELIGIBLE_FOR_MULTI_SLATE_REVIEW" if raw_holdout_pairs_available >= REQUIRED_RAW_HOLDOUT_PAIRS
            else "BLOCKED_PENDING_RAW_MULTI_SLATE_HOLDOUT_MATRIX"
        ),
        "OUTPUT_ORDER_PATH": str(out_order),
        "OUTPUT_ORDER_SHA256": sha256_file(out_order),
        "PLAYER_NAMES_USED": False,
        "TEAM_NAMES_USED": False,
        "REALIZED_RESULTS_USED": False,
        "STANDINGS_USED_PRESEAL": False,
        "SELECTOR_CHANGED_AFTER_STANDINGS": False,
    }
    Path(output_receipt).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return receipt


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--ledger", required=True)
    p.add_argument("--output-order", required=True)
    p.add_argument("--output-receipt", required=True)
    p.add_argument("--seed", type=int, default=713)
    p.add_argument("--posterior-draws", type=int, default=20_000)
    p.add_argument("--raw-holdout-pairs", type=int, default=1)
    return p.parse_args()


def main() -> int:
    a = parse_args()
    result = run_shadow_research(
        a.ledger, a.output_order, a.output_receipt,
        seed=a.seed, posterior_draws=a.posterior_draws,
        raw_holdout_pairs_available=a.raw_holdout_pairs,
    )
    for key in (
        "EXECUTION_STATE", "VALIDATION_CLASS", "SHADOW_RANK1_ELIGIBLE_COUNT",
        "SHADOW_RANK1_PRODUCTION_RANK", "SHADOW_ORDER_CHANGED",
        "PRODUCTION_PROMOTION_DECISION",
    ):
        print(f"{key}={result[key]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
