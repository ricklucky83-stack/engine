from __future__ import annotations
import hashlib
from collections import defaultdict
import numpy as np

PATCH_ID = 'WNBA_CLASSIC_EXPERT_ROUTED_TROPHY_DOOR_v1'


def pct_rank(x):
    x=np.asarray(x,float); n=len(x)
    if n==0:return np.empty(0,float)
    order=np.argsort(x,kind='mergesort'); sx=x[order]; out=np.empty(n,float)
    st=0
    while st<n:
        en=st+1
        while en<n and sx[en]==sx[st]: en+=1
        out[order[st:en]]=((st+1.0)+en)*0.5/n
        st=en
    return out


def _runs(a):
    a=np.asarray(a)
    used=1+(a[:,1:]!=a[:,:-1]).sum(1)
    mx=np.ones(len(a),np.int16); cur=np.ones(len(a),np.int16)
    for j in range(1,a.shape[1]):
        cur=np.where(a[:,j]==a[:,j-1],cur+1,1); mx=np.maximum(mx,cur)
    return used,mx


def _pareto2(a,b,eligible):
    idx=np.flatnonzero(np.asarray(eligible,bool))
    if idx.size==0:return idx
    # a desc, then b desc, then candidate id asc
    order=idx[np.lexsort((idx,-np.asarray(b)[idx],-np.asarray(a)[idx]))]
    out=[]; best=-np.inf
    for i in order:
        bi=float(b[i])
        if bi>best+1e-12:
            out.append(int(i)); best=bi
    return np.asarray(out,np.int64)


def _pareto2_idx(a,b,idx):
    idx=np.asarray(idx,dtype=np.int64)
    if idx.size==0:return idx
    order=idx[np.lexsort((idx,-np.asarray(b)[idx],-np.asarray(a)[idx]))]
    out=[]; best=-np.inf
    for i in order:
        bi=float(b[i])
        if bi>best+1e-12:
            out.append(int(i)); best=bi
    return np.asarray(out,np.int64)

def _family(row, cal, salary_player):
    tc=np.bincount(cal.team_codes[row]); tc=tuple(sorted((int(x) for x in tc if x),reverse=True))
    games=int(len(np.unique(cal.game_codes[row])))
    cont=int((cal.p_expand[row]>=0.20).sum()); vac=int(cal.vacancy_beneficiary[row].sum())
    salary=int(salary_player[row].sum()); bucket=(50000-salary)//500
    return (tc,games,min(cont,2),min(vac,1),bucket)


def build_surfaces(candidates, sim, cal, config):
    n=len(candidates)
    salp=cal.frame['SAL'].astype(int).to_numpy(); mins=cal.frame['MIN'].fillna(0).astype(float).to_numpy()
    row_sal=salp[candidates]; row_min=mins[candidates]; salary=row_sal.sum(1); release=50000-salary
    teams=np.sort(cal.team_codes[candidates],axis=1); games=np.sort(cal.game_codes[candidates],axis=1)
    teams_used,max_team=_runs(teams); games_used,max_game=_runs(games)
    premium9=(row_sal>=9000).sum(1); premium10=(row_sal>=10000).sum(1); cheap35=(row_sal<=3500).sum(1)
    low15=(row_min<15).sum(1)
    role_player=(salp<=3500)&(mins>=6)&(mins<15)&cal.rotation_active&~cal.stale_role_suppressed
    role_count=role_player[candidates].sum(1)
    role_expand=(cal.p_expand[candidates]*role_player[candidates]).sum(1)
    structural=cal.structural_value_geometry[candidates].sum(1)
    vacancy=cal.vacancy_beneficiary[candidates].sum(1)
    rebound=(cal.historical_rebound|cal.recent_role_rebound)[candidates].sum(1)
    top=np.asarray(sim.get('top01_posterior',sim['top01_rate']),float); win=np.asarray(sim.get('win_posterior',sim['win_rate']),float); p99=np.asarray(sim['p99'],float); cvar99=np.asarray(sim.get('cvar99',sim['p99']),float); p95=np.asarray(sim['p95'],float); mean=np.asarray(sim['mean'],float)
    logown=np.log(np.clip(cal.ownership_proxy[candidates],1e-9,None)).sum(1); expected_dup=np.exp(logown)*config.field_size

    # Role-conditioned ownership uncertainty. This is deliberately an interval width,
    # not a uniform multiplier on the ownership point estimate.
    ownp=np.asarray(cal.ownership_proxy,float)
    unc=np.full(len(ownp),0.035,float)
    cheap_role=(salp<=3500)&(mins<15)
    star=salp>=10000
    unc[cheap_role]+=0.16+0.80*np.clip(ownp[cheap_role],0,0.30)
    unc[star]+=0.06
    unc[cal.p_expand>=0.20]+=0.055
    own_unc=unc[candidates].sum(1)

    P={
      'top':pct_rank(top),'win':pct_rank(win),'cvar99':pct_rank(cvar99),'p99':pct_rank(p99),'p95':pct_rank(p95),'mean':pct_rank(mean),
      'salary':pct_rank(salary),'role_expand':pct_rank(role_expand),'structural':pct_rank(structural),
      'vacancy':pct_rank(vacancy),'rebound':pct_rank(rebound),'own_unc':pct_rank(own_unc),
      'low_dup':pct_rank(-expected_dup),
    }
    geometry_strength=(1.25*(max_game>=3)+0.80*(games_used==3)+0.55*(teams_used>=4)+0.45*(structural>=1)+0.25*(rebound>=1)).astype(float)
    premium_strength=(premium9+0.5*premium10+0.75*(release<=200)+0.35*(cheap35>=1)).astype(float)
    role_strength=(role_count+1.5*role_expand+0.45*vacancy+0.25*rebound).astype(float)
    P['geometry']=pct_rank(geometry_strength); P['premium']=pct_rank(premium_strength); P['role']=pct_rank(role_strength)

    scores={
      'base': .32*P['win']+.28*P['top']+.16*P['cvar99']+.12*P['p99']+.06*P['p95']+.06*P['mean'],
      'role': .30*P['p99']+.12*P['top']+.18*P['mean']+.28*P['role']+.07*P['salary']+.05*P['own_unc'],
      'premium': .30*P['p99']+.18*P['top']+.20*P['mean']+.22*P['premium']+.10*P['salary'],
      'geometry': .30*P['top']+.24*P['p99']+.22*P['geometry']+.12*P['structural']+.07*P['mean']+.05*P['salary'],
      'ownership': .28*P['top']+.24*P['p99']+.16*P['mean']+.16*P['low_dup']+.16*P['own_unc'],
    }
    M=np.column_stack([scores[k] for k in ('base','role','premium','geometry','ownership')])
    disagree=M.std(1); upper=M.max(1)
    scores['uncertainty']=.55*upper+.20*pct_rank(disagree)+.15*P['p99']+.10*P['own_unc']

    eligible={
      'base':np.ones(n,bool),
      'role':(role_count>=1)&(cheap35>=1)&(release<=2000),
      'premium':(premium9>=3)&(release<=1000),
      'geometry':(max_game>=2)&(games_used<=3)&(teams_used<=5),
      'ownership':np.ones(n,bool),
      'uncertainty':(P['p99']>=0.90)&(pct_rank(disagree)>=0.80),
    }
    # Exact 2-D fronts, no first-N candidate truncation.
    fronts={
      'base':_pareto2(P['top'],P['p99'],eligible['base']),
      'role':_pareto2(P['p99'],P['role'],eligible['role']),
      'premium':_pareto2(P['p99'],P['premium'],eligible['premium']),
      'geometry':_pareto2(P['top'],P['geometry'],eligible['geometry']),
      'ownership':_pareto2(P['top'],P['low_dup'],eligible['ownership']),
      'uncertainty':_pareto2(upper,pct_rank(disagree),eligible['uncertainty']),
    }
    return {
      'salary_player':salp,'salary':salary,'release':release,'premium9':premium9,'premium10':premium10,'cheap35':cheap35,
      'low15':low15,'role_count':role_count,'role_expand':role_expand,'teams_used':teams_used,'max_team':max_team,
      'games_used':games_used,'max_game':max_game,'structural':structural,'vacancy':vacancy,'rebound':rebound,
      'expected_dup':expected_dup,'own_unc':own_unc,'P':P,'scores':scores,'fronts':fronts,'eligible':eligible,'expert_upper':upper,'expert_disagree_pct':pct_rank(disagree),
    }


def _neighborhood_order(name, candidates, s, local_depth=5):
    # Forward-only structural routing keys. No player identities or post-lock fields.
    relbucket=(s['release']//250).astype(int)
    keys=list(zip(s['premium9'].astype(int),s['cheap35'].astype(int),s['low15'].astype(int),s['max_game'].astype(int),s['games_used'].astype(int),s['teams_used'].astype(int),relbucket))
    eligible=np.asarray(s['eligible'][name],bool)
    groups=defaultdict(list)
    for i in np.flatnonzero(eligible): groups[keys[int(i)]].append(int(i))
    reps=[]
    score=np.asarray(s['scores'][name],float)
    # Local Pareto first; retain up to local_depth doors in each neighborhood.
    for key,idxs in groups.items():
        ii=np.asarray(idxs,np.int64)
        if name=='role': front=_pareto2_idx(s['P']['p99'],s['P']['role'],ii)
        elif name=='premium': front=_pareto2_idx(s['P']['p99'],s['P']['premium'],ii)
        elif name=='geometry': front=_pareto2_idx(s['P']['top'],s['P']['geometry'],ii)
        elif name=='ownership': front=_pareto2_idx(s['P']['top'],s['P']['low_dup'],ii)
        elif name=='uncertainty': front=_pareto2_idx(s['expert_upper'],s['expert_disagree_pct'],ii)
        else: front=_pareto2_idx(s['P']['top'],s['P']['p99'],ii)
        if front.size==0: front=ii
        ordered=front[np.argsort(-score[front],kind='mergesort')][:local_depth]
        for depth,i in enumerate(ordered): reps.append((float(score[i]),-depth,key,int(i)))
    reps.sort(key=lambda z:(-z[0],-z[1],z[2],z[3]))
    return np.asarray([r[3] for r in reps],np.int64)


def select_shadow_board(candidates, sim, cal, config, base_selected=None):
    s=build_surfaces(candidates,sim,cal,config)
    n=len(candidates); target=min(int(config.board_size),n)
    if base_selected is None:
        base_order=np.argsort(-s['scores']['base'],kind='mergesort')
    else:
        base_order=np.asarray(base_selected,dtype=np.int64)
    routes={
      'role':_neighborhood_order('role',candidates,s,local_depth=5),
      'premium':_neighborhood_order('premium',candidates,s,local_depth=3),
      'geometry':_neighborhood_order('geometry',candidates,s,local_depth=3),
      'ownership':_neighborhood_order('ownership',candidates,s,local_depth=2),
      'uncertainty':_neighborhood_order('uncertainty',candidates,s,local_depth=3),
    }
    # Five base seats + one each for four experts + one uncertainty reserve.
    plan=[('base',base_order)]*5+[(k,routes[k]) for k in ('role','premium','geometry','ownership','uncertainty')]
    selected=[]; player_count=defaultdict(int); fam_count=defaultdict(int); source=[]
    salp=s['salary_player']
    def admissible(i):
        if i in selected:return False
        row=candidates[i]
        if any(player_count[int(p)]>=int(config.player_exposure_cap) for p in row):return False
        fam=_family(row,cal,salp)
        if fam_count[fam]>=int(config.family_cap):return False
        return True
    for label,order in plan:
        for i in order:
            i=int(i)
            if admissible(i):
                selected.append(i);source.append(label)
                for p in candidates[i]:player_count[int(p)]+=1
                fam_count[_family(candidates[i],cal,salp)]+=1
                break
    # Fill any holes from union of expert orders, then base score.
    if len(selected)<target:
        union=[]
        for k in ('role','premium','geometry','ownership','uncertainty'):
            union.extend(routes[k].tolist())
        union.extend(np.argsort(-s['scores']['base'],kind='mergesort').tolist())
        for i in union:
            if len(selected)>=target:break
            i=int(i)
            if admissible(i):
                selected.append(i);source.append('fill')
                for p in candidates[i]:player_count[int(p)]+=1
                fam_count[_family(candidates[i],cal,salp)]+=1
    selected=np.asarray(selected[:target],np.int64)
    receipt={
      'PATCH_ID':PATCH_ID,
      'SELECTED_CANDIDATE_INDICES':selected.tolist(),
      'SOURCE_LANES':source[:len(selected)],
      'FRONT_SIZES':{k:int(len(v)) for k,v in s['fronts'].items()},
      'ROUTE_ELIGIBLE_COUNTS':{k:int(np.asarray(v).sum()) for k,v in s['eligible'].items()},
      'ROUTE_ORDER_SHA256':{k:hashlib.sha256(routes[k].astype(np.int64).tobytes()).hexdigest() for k in routes},
    }
    return selected,s,receipt
