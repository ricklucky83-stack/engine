#!/usr/bin/env python3
"""Post-lock recall evaluator for WNBA Classic.

This module is intentionally isolated from the production selector. Actual scores and
perfect-lineup identities are accepted only after board construction.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
RUNTIME_PATH = HERE / "wnba_classic_raw_pool_runtime_v1.py"
_spec = importlib.util.spec_from_file_location("apex_wnba_runtime_v1_eval", RUNTIME_PATH)
_runtime = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = _runtime
assert _spec.loader is not None
_spec.loader.exec_module(_runtime)

EVALUATOR_ID = "WNBA_POSTLOCK_RECALL_EVALUATOR_v1"


def evaluate(
    pool_path: str | Path,
    board_path: str | Path,
    field_size: int,
    out_names: Sequence[str],
    target_players: Sequence[str],
    actual_scores: dict[str, float] | None = None,
) -> dict:
    cfg = _runtime.RuntimeConfig(field_size=int(field_size), seed=int(field_size))
    cal = _runtime.load_and_calibrate(pool_path, out_names, cfg)
    legal = _runtime.enumerate_legal(cal)
    phase2, _ = _runtime.phase2_family_closure(legal, cal, cfg)

    target = [str(x) for x in target_players]
    missing = [name for name in target if not cal.frame["PLAYER"].astype(str).eq(name).any()]
    if missing:
        target_ids = np.array([], dtype=np.int16)
        legal_capture = False
        phase2_capture = False
    else:
        target_ids = np.sort([
            int(cal.frame.index[cal.frame["PLAYER"].astype(str).eq(name)][0]) for name in target
        ]).astype(np.int16)
        legal_capture = bool(np.any(np.all(np.sort(legal, axis=1) == target_ids, axis=1)))
        phase2_capture = bool(np.any(np.all(np.sort(phase2, axis=1) == target_ids, axis=1)))

    board = pd.read_csv(board_path)
    board_sets = {
        int(lineup): frozenset(group["PLAYER"].astype(str).tolist())
        for lineup, group in board.groupby("LINEUP")
    } if not board.empty else {}
    target_set = frozenset(target)
    board_ranks = sorted(rank for rank, players in board_sets.items() if players == target_set)
    board_capture = bool(board_ranks)

    if missing:
        failure_class = "AUTHORITATIVE_POOL_RECONCILIATION_FAILURE"
    elif not legal_capture:
        failure_class = "LEGAL_GENERATION_FAILURE"
    elif not phase2_capture:
        failure_class = "GENERATOR_CALIBRATION_FAILURE"
    elif not board_capture:
        failure_class = "SELECTOR_OR_MODEL_VARIANCE_FAILURE"
    else:
        failure_class = "PERFECT_CAPTURE_PASS"

    projection_total = 0.0
    if not missing:
        projection_total = float(cal.base_projection[target_ids].sum())
    actual_total = None
    if actual_scores is not None:
        actual_total = float(sum(float(actual_scores[name]) for name in target if name in actual_scores))

    return {
        "EVALUATOR_ID": EVALUATOR_ID,
        "ACTUAL_RESULTS_USED_BY_SELECTOR": False,
        "TARGET_PLAYERS": target,
        "TARGET_MISSING_FROM_ACTIVE_POOL": missing,
        "TARGET_SALARY": int(cal.frame.loc[cal.frame["PLAYER"].isin(target), "SAL"].sum()),
        "TARGET_BASE_PROJECTION": projection_total,
        "TARGET_ACTUAL_SCORE": actual_total,
        "LEGAL_BIRTH": legal_capture,
        "PHASE2_HANDOFF": phase2_capture,
        "SELECTOR_REVIEWED": phase2_capture,
        "FINAL_BOARD_CAPTURE": board_capture,
        "FINAL_BOARD_RANKS": board_ranks,
        "FAILURE_CLASS": failure_class,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pool", required=True)
    parser.add_argument("--board", required=True)
    parser.add_argument("--field-size", type=int, required=True)
    parser.add_argument("--out", action="append", default=[])
    parser.add_argument("--target", action="append", required=True)
    parser.add_argument("--actual-json")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    actual = json.loads(Path(args.actual_json).read_text()) if args.actual_json else None
    result = evaluate(args.pool, args.board, args.field_size, args.out, args.target, actual)
    Path(args.output).write_text(json.dumps(result, indent=2), encoding="utf-8")
    for key, value in result.items():
        if key in {"LEGAL_BIRTH", "PHASE2_HANDOFF", "FINAL_BOARD_CAPTURE", "FAILURE_CLASS"}:
            print(f"{key}={value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
