#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path

import pandas as pd

EVALUATOR_ID = "WNBA_CLASSIC_POSTLOCK_CONTEST_MATCHER_v1"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalize_name(value: object) -> str:
    text = re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()
    return re.sub(r"\s+", " ", text)


def contest_frame(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as z:
            members = [n for n in z.namelist() if n.lower().endswith(".csv")]
            if not members:
                raise ValueError("NO_CSV_MEMBER")
            with z.open(members[0]) as f:
                return pd.read_csv(f)
    return pd.read_csv(path)


def winner_keys(path: Path, pool: Path | None = None) -> list[str]:
    d = contest_frame(path)
    required = {"Rank", "Player"}
    if not required.issubset(d.columns):
        raise ValueError("MISSING_RANK_OR_PLAYER")
    rank_num = pd.to_numeric(d["Rank"].astype(str).str.extract(r"(\d+)", expand=False), errors="coerce")
    if not rank_num.notna().any():
        raise ValueError("NO_NUMERIC_RANK")
    best = rank_num.min()
    w = d.loc[rank_num.eq(best)].copy()
    keys: list[str] = []
    if pool is not None and "Lineup" in w.columns:
        pool_df = pd.read_csv(pool, usecols=lambda c: str(c) == "PLAYER")
        frozen_names = sorted({normalize_name(x) for x in pool_df["PLAYER"].dropna() if normalize_name(x)}, key=len, reverse=True)
        for lineup in w["Lineup"].dropna().astype(str).unique().tolist():
            normalized_lineup = normalize_name(lineup)
            found = []
            for name in frozen_names:
                if re.search(r"(?<![a-z0-9])" + re.escape(name) + r"(?![a-z0-9])", normalized_lineup):
                    found.append(name)
            found = sorted(set(found))
            if len(found) == 6:
                keys.append("|".join(found))
    if "Lineup" in w.columns:
        for _, group in w.groupby(w["Lineup"].fillna(""), sort=False):
            names = sorted({normalize_name(x) for x in group["Player"].dropna() if normalize_name(x)})
            if len(names) == 6:
                keys.append("|".join(names))
    if not keys:
        names = sorted({normalize_name(x) for x in w["Player"].dropna() if normalize_name(x)})
        if len(names) == 6:
            keys.append("|".join(names))
    if not keys:
        raise RuntimeError("WINNER_PLAYER_SET_NOT_IDENTIFIABLE")
    return sorted(set(keys))


def evaluate(contest: Path, identity_map: Path, ledger: Path, shadow_order: Path, output: Path, pool: Path | None = None) -> dict:
    winners = winner_keys(contest, pool)
    identities = pd.read_csv(identity_map)
    audit = pd.read_csv(ledger)
    shadow = pd.read_csv(shadow_order)
    needed = {"LINEUP_ID", "PLAYER_SET_KEY"}
    if not needed.issubset(identities.columns):
        raise ValueError("IDENTITY_MAP_SCHEMA_INVALID")
    matched = identities.loc[identities["PLAYER_SET_KEY"].astype(str).isin(winners)].copy()
    if len(matched) > 1:
        matched = matched.drop_duplicates("LINEUP_ID")
    ids = matched["LINEUP_ID"].astype(str).tolist()
    audit_match = audit.loc[audit["LINEUP_ID"].astype(str).isin(ids)].copy()
    shadow_match = shadow.loc[shadow["LINEUP_ID"].astype(str).isin(ids)].copy()
    born = bool(len(ids))
    selected = bool(len(audit_match) and audit_match["SELECTED"].astype(bool).any())
    production_rank = int(audit_match.loc[audit_match["SELECTED"].astype(bool), "FINAL_RANK"].min()) if selected else 0
    shadow_rank = int(shadow_match["SHADOW_RANK"].min()) if len(shadow_match) else 0
    result = {
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "EVALUATOR_ID": EVALUATOR_ID,
        "POSTLOCK_ONLY": True,
        "PRODUCTION_SELECTOR_IMPORT": False,
        "SHADOW_RANKER_IMPORT": False,
        "CONTEST_SHA256": sha256(contest),
        "IDENTITY_MAP_SHA256": sha256(identity_map),
        "LEDGER_SHA256": sha256(ledger),
        "SHADOW_ORDER_SHA256": sha256(shadow_order),
        "WINNER_LINEUP_KEYS": winners,
        "MATCHED_LINEUP_IDS": ids,
        "WINNER_BORN_PHASE2": born,
        "WINNER_REACHED_SELECTOR_LEDGER": bool(len(audit_match)),
        "WINNER_SELECTED_TO_PRODUCTION_BOARD": selected,
        "WINNER_PRODUCTION_BOARD_RANK": production_rank,
        "WINNER_SHADOW_RANK": shadow_rank,
        "PRODUCTION_RANK1_CAPTURE": production_rank == 1,
        "SHADOW_RANK1_CAPTURE": shadow_rank == 1,
        "PRODUCTION_MUTATED": False,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--contest", required=True)
    p.add_argument("--identity-map", required=True)
    p.add_argument("--ledger", required=True)
    p.add_argument("--shadow-order", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--pool")
    a = p.parse_args()
    result = evaluate(Path(a.contest), Path(a.identity_map), Path(a.ledger), Path(a.shadow_order), Path(a.output), Path(a.pool) if a.pool else None)
    print(json.dumps({k: result[k] for k in (
        "EXECUTION_STATE", "WINNER_BORN_PHASE2", "WINNER_SELECTED_TO_PRODUCTION_BOARD",
        "WINNER_PRODUCTION_BOARD_RANK", "WINNER_SHADOW_RANK", "SHADOW_RANK1_CAPTURE"
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
