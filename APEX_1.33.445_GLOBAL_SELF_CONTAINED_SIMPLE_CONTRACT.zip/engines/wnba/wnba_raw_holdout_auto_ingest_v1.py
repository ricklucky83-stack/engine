#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from wnba_raw_holdout_inventory_v1 import is_classic_pool, is_contest, sha256, field_band

PATCH_ID = "WNBA_CLASSIC_RAW_HOLDOUT_AUTO_INGEST_AND_AUTONOMOUS_LOSO_TRIGGER_v1"


def normalize_name(value: object) -> str:
    text = re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()
    return re.sub(r"\s+", " ", text)


def pool_players(path: Path) -> set[str]:
    d = pd.read_csv(path, usecols=lambda c: str(c) == "PLAYER")
    return {normalize_name(x) for x in d["PLAYER"].dropna() if normalize_name(x)}


def _contest_frame(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as z:
            members = [n for n in z.namelist() if n.lower().endswith(".csv")]
            if not members:
                raise ValueError("NO_CSV_MEMBER")
            with z.open(members[0]) as f:
                return pd.read_csv(f)
    return pd.read_csv(path)


def contest_players(path: Path) -> set[str]:
    d = _contest_frame(path)
    if "Player" not in d.columns:
        return set()
    return {normalize_name(x) for x in d["Player"].dropna() if normalize_name(x)}


def infer_field_size(path: Path) -> int | None:
    """Infer actual contest entry count; ranking ties must not shrink field size."""
    d = _contest_frame(path)
    if "EntryId" in d.columns:
        entry_ids = d["EntryId"].dropna().astype(str).str.strip()
        entry_ids = entry_ids[entry_ids.ne("")]
        if len(entry_ids):
            return int(entry_ids.nunique())
    if "EntryName" in d.columns:
        entry_names = d["EntryName"].dropna().astype(str).str.strip()
        entry_names = entry_names[entry_names.ne("")]
        if len(entry_names):
            return int(len(entry_names))
    if "Rank" not in d.columns:
        return None
    ranks = pd.to_numeric(d["Rank"].astype(str).str.extract(r"(\d+)", expand=False), errors="coerce")
    return int(ranks.max()) if ranks.notna().any() else None


def slate_hash(pool_path: Path, players: set[str]) -> str:
    payload = sha256(pool_path) + "|" + "|".join(sorted(players)) + "|WNBA_CLASSIC_2G_3F_1UTIL"
    return hashlib.sha256(payload.encode()).hexdigest()


def pair_hash(pool_digest: str, contest_digest: str) -> str:
    return hashlib.sha256(f"{pool_digest}|{contest_digest}|WNBA_CLASSIC|2G_3F_1UTIL".encode()).hexdigest()


def _load_refs(path: Path | None) -> list[dict[str, Any]]:
    if not path or not path.exists():
        return []
    return list(json.loads(path.read_text()).get("REFERENCES", []))


def discover(root: Path, exclude: Path | None = None) -> tuple[list[Path], list[Path]]:
    pools: list[Path] = []
    contests: list[Path] = []
    exclude_resolved = exclude.resolve() if exclude else None
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.name.startswith("."):
            continue
        if exclude_resolved is not None:
            try:
                p.resolve().relative_to(exclude_resolved)
                continue
            except ValueError:
                pass
        suffix = p.suffix.lower()
        if suffix == ".csv":
            ok, _ = is_classic_pool(p)
            if ok:
                pools.append(p)
                continue
        if suffix in {".zip", ".csv"}:
            ok, _, _ = is_contest(p)
            if ok:
                contests.append(p)
    return pools, contests


def _score(pool_set: set[str], contest_set: set[str]) -> tuple[float, float, float]:
    if not pool_set or len(contest_set) < 6:
        return 0.0, 0.0, 0.0
    inter = len(pool_set & contest_set)
    coverage = inter / len(contest_set)
    jaccard = inter / len(pool_set | contest_set)
    return 0.70 * coverage + 0.30 * jaccard, coverage, jaccard


def _copy_immutable(source: Path, target: Path, expected_hash: str) -> str:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        existing = sha256(target)
        if existing != expected_hash:
            raise RuntimeError(f"IMMUTABLE_HASH_CONFLICT={target}")
        return "IDEMPOTENT_PRESENT"
    shutil.copy2(source, target)
    actual = sha256(target)
    if actual != expected_hash:
        target.unlink(missing_ok=True)
        raise RuntimeError(f"COPY_HASH_MISMATCH={source}")
    return "COPIED"


def ingest(root: Path, vault: Path, receipt_path: Path, reference_ledger: Path | None = None) -> dict[str, Any]:
    pools, contests = discover(root, vault)
    refs = _load_refs(reference_ledger)
    ref_pairs = {(r.get("POOL_FILE"), r.get("CONTEST_FILE")): r for r in refs}
    pool_sets = {p: pool_players(p) for p in pools}
    contest_sets = {p: contest_players(p) for p in contests}
    matches: list[dict[str, Any]] = []
    ambiguous: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []

    for contest in contests:
        exact = []
        for pool in pools:
            ref = ref_pairs.get((pool.name, contest.name))
            if ref:
                exact.append((pool, ref))
        field = infer_field_size(contest)
        chosen: Path | None = None
        reason = ""
        score = coverage = jaccard = 0.0
        ref: dict[str, Any] | None = None
        if len(exact) == 1:
            chosen, ref = exact[0]
            reason = "EXACT_REFERENCE_FILENAME_PAIR"
            score = coverage = 1.0
        elif len(exact) > 1:
            ambiguous.append({"CONTEST_FILE": str(contest), "REASON": "MULTIPLE_EXACT_REFERENCE_POOLS"})
            continue
        else:
            candidates = []
            for pool in pools:
                s, c, j = _score(pool_sets[pool], contest_sets[contest])
                candidates.append((s, c, j, pool))
            candidates.sort(key=lambda x: (-x[0], str(x[3])))
            if not candidates or candidates[0][1] < 0.85 or candidates[0][0] < 0.65:
                rejected.append({"CONTEST_FILE": str(contest), "REASON": "NO_CONFIDENT_POOL_MATCH"})
                continue
            if len(candidates) > 1 and candidates[0][0] - candidates[1][0] <= 0.02:
                ambiguous.append({
                    "CONTEST_FILE": str(contest), "REASON": "TOP_TWO_MATCH_SCORES_AMBIGUOUS",
                    "TOP_SCORE": candidates[0][0], "SECOND_SCORE": candidates[1][0],
                    "TOP_POOL": str(candidates[0][3]), "SECOND_POOL": str(candidates[1][3]),
                })
                continue
            score, coverage, jaccard, chosen = candidates[0]
            reason = "PLAYER_UNIVERSE_COVERAGE_MATCH"
        if chosen is None:
            continue
        pool_digest = sha256(chosen)
        contest_digest = sha256(contest)
        s_hash = slate_hash(chosen, pool_sets[chosen])
        p_hash = pair_hash(pool_digest, contest_digest)
        if field is None and ref:
            field = ref.get("FIELD_SIZE")
        if field is None:
            rejected.append({"CONTEST_FILE": str(contest), "POOL_FILE": str(chosen), "REASON": "FIELD_SIZE_UNRESOLVED"})
            continue
        pair_dir = vault / s_hash / contest_digest[:16]
        pool_target = pair_dir / "pool" / chosen.name
        contest_target = pair_dir / "contest" / contest.name
        pool_copy = _copy_immutable(chosen, pool_target, pool_digest)
        contest_copy = _copy_immutable(contest, contest_target, contest_digest)
        manifest = {
            "PATCH_ID": PATCH_ID,
            "STATUS": "BYTE_COMPLETE_RAW_PAIR_INGESTED",
            "INGESTED_AT_UTC": datetime.now(timezone.utc).isoformat(),
            "MODE": "WNBA_CLASSIC",
            "FIELD_SIZE": int(field),
            "FIELD_BAND": field_band(int(field)),
            "SLATE_SHA256": s_hash,
            "PAIR_SHA256": p_hash,
            "POOL_FILE": str(pool_target.relative_to(vault)),
            "CONTEST_FILE": str(contest_target.relative_to(vault)),
            "POOL_ORIGINAL_NAME": chosen.name,
            "CONTEST_ORIGINAL_NAME": contest.name,
            "POOL_SHA256": pool_digest,
            "CONTEST_SHA256": contest_digest,
            "MATCH_METHOD": reason,
            "MATCH_SCORE": score,
            "CONTEST_PLAYER_COVERAGE": coverage,
            "PLAYER_JACCARD": jaccard,
            "POOL_PLAYER_COUNT": len(pool_sets[chosen]),
            "CONTEST_PLAYER_COUNT": len(contest_sets[contest]),
            "OUT_PLAYERS": [],
            "PRODUCTION_SELECTOR_MUTATED": False,
        }
        manifest_path = pair_dir / "pair_manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
        matches.append({**manifest, "POOL_COPY": pool_copy, "CONTEST_COPY": contest_copy, "MANIFEST": str(manifest_path)})

    distinct_slates = sorted({m["SLATE_SHA256"] for m in matches})
    bands = sorted({m["FIELD_BAND"] for m in matches if m.get("FIELD_BAND")})
    result = {
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "PATCH_ID": PATCH_ID,
        "ROOT_SCANNED": str(root),
        "VAULT": str(vault),
        "POOLS_DISCOVERED": len(pools),
        "CONTESTS_DISCOVERED": len(contests),
        "PAIRS_INGESTED_OR_PRESENT": len(matches),
        "DISTINCT_SLATES_IN_THIS_INGEST": len(distinct_slates),
        "FIELD_BANDS_IN_THIS_INGEST": bands,
        "AMBIGUOUS_MATCHES": ambiguous,
        "REJECTED_MATCHES": rejected,
        "FAIL_CLOSED": bool(ambiguous),
        "PRODUCTION_SELECTOR_MUTATED": False,
        "PRODUCTION_BOARD_MUTATED": False,
        "MATCHES": matches,
    }
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    receipt_path.write_text(json.dumps(result, indent=2) + "\n")
    return result


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--root", required=True)
    p.add_argument("--vault", required=True)
    p.add_argument("--receipt", required=True)
    p.add_argument("--reference-ledger")
    a = p.parse_args()
    result = ingest(Path(a.root), Path(a.vault), Path(a.receipt), Path(a.reference_ledger) if a.reference_ledger else None)
    print(json.dumps({k: result[k] for k in (
        "EXECUTION_STATE", "POOLS_DISCOVERED", "CONTESTS_DISCOVERED",
        "PAIRS_INGESTED_OR_PRESENT", "DISTINCT_SLATES_IN_THIS_INGEST", "FAIL_CLOSED"
    )}, indent=2))
    return 2 if result["FAIL_CLOSED"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
