#!/usr/bin/env python3
"""Post-lock evaluator for an already frozen WNBA rank-1 shadow order.

This file is intentionally separate from the production runtime and shadow ranker.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd

EVALUATOR_ID = "WNBA_CLASSIC_RANK1_SHADOW_POSTLOCK_EVALUATOR_v1"


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def evaluate(
    ledger_path: str | Path,
    shadow_order_path: str | Path,
    target_production_rank: int,
    output_receipt: str | Path,
) -> dict:
    ledger = pd.read_csv(ledger_path)
    shadow = pd.read_csv(shadow_order_path)
    target = ledger.loc[
        ledger["SELECTED"].astype(bool) & ledger["FINAL_RANK"].astype(int).eq(int(target_production_rank))
    ]
    if len(target) != 1:
        raise RuntimeError(f"TARGET_PRODUCTION_RANK_NOT_UNIQUE={target_production_rank}")
    lineup_id = str(target.iloc[0]["LINEUP_ID"])
    matched = shadow.loc[shadow["LINEUP_ID"].astype(str).eq(lineup_id)]
    if len(matched) != 1:
        raise RuntimeError("TARGET_LINEUP_MISSING_FROM_FROZEN_SHADOW_ORDER")
    shadow_rank = int(matched.iloc[0]["SHADOW_RANK"])
    result = {
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "EVALUATOR_ID": EVALUATOR_ID,
        "PRODUCTION_SELECTOR_ISOLATED": True,
        "SHADOW_RANKER_ISOLATED": True,
        "POSTLOCK_INPUT_USED_FOR_PRODUCTION": False,
        "TARGET_PRODUCTION_RANK": int(target_production_rank),
        "TARGET_ANONYMOUS_LINEUP_ID": lineup_id,
        "TARGET_SHADOW_RANK": shadow_rank,
        "SHADOW_RANK1_CAPTURE": shadow_rank == 1,
        "VALIDATION_CLASS": "SAME_SLATE_POSTLOCK_DIAGNOSTIC_ONLY",
        "BLIND_PROOF_CLAIMED": False,
        "LEDGER_SHA256": sha256_file(ledger_path),
        "SHADOW_ORDER_SHA256": sha256_file(shadow_order_path),
    }
    Path(output_receipt).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--ledger", required=True)
    p.add_argument("--shadow-order", required=True)
    p.add_argument("--target-production-rank", type=int, required=True)
    p.add_argument("--output-receipt", required=True)
    a = p.parse_args()
    result = evaluate(a.ledger, a.shadow_order, a.target_production_rank, a.output_receipt)
    for k in ("EXECUTION_STATE", "TARGET_PRODUCTION_RANK", "TARGET_SHADOW_RANK", "SHADOW_RANK1_CAPTURE"):
        print(f"{k}={result[k]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
