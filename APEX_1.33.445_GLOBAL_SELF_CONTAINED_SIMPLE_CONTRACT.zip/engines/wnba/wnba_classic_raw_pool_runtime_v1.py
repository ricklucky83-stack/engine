#!/usr/bin/env python3
"""APEX WNBA Classic deterministic calibration-first runtime v1.

Production behavior:
- Reads the DraftKings/LineStar player-pool CSV as authoritative pre-lock input.
- Applies explicit OUT overrides before calibration and lineup birth.
- Builds a role-state Monte Carlo matrix before generating lineups.
- Preserves historical-role rebound and OUT-vacancy beneficiary families.
- Preserves field-derived position/salary/opportunity value paths before birth.
- Enumerates the legal qualified universe with compiled two-pass kernels.
- Uses one shared covariance/simulation matrix for Phase 2 and Phase 3.
- Uses adaptive bubble simulation and an exact MILP portfolio selector.
- Never uses post-lock scores in selection.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path

_STATE_ROOT_FOR_IMPORTS = Path(__file__).resolve().parents[2]
if str(_STATE_ROOT_FOR_IMPORTS) not in sys.path:
    sys.path.insert(0, str(_STATE_ROOT_FOR_IMPORTS))
from typing import Any, Iterable, Sequence

import numpy as np
import pandas as pd
from numba import njit
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix

import importlib.util as _strategy_importlib_util
_STRATEGY_PATH = Path(__file__).resolve().parents[2] / "engines" / "common" / "apex_global_sports_strategy_layer_v1.py"
_strategy_spec = _strategy_importlib_util.spec_from_file_location("apex_global_sports_strategy_layer_v1", _STRATEGY_PATH)
if _strategy_spec is None or _strategy_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_SPORTS_STRATEGY_LAYER_UNAVAILABLE")
global_strategy = _strategy_importlib_util.module_from_spec(_strategy_spec)
_strategy_spec.loader.exec_module(global_strategy)
GLOBAL_SPORTS_STRATEGIST_PATCH_ID = global_strategy.PATCH_ID
from engines.common.mandatory_prebuild_roster_gate_v1 import (
    assert_runtime_roster_seal, gate_receipt, require_prebuild_roster_check,
    seal_runtime_roster_gate, verified_out_names,
)
from engines.common.apex_global_slate_runtime_v1 import evaluate_pool as evaluate_slate_runtime
from engines.common.right_neighborhood_door_selector_v1 import neighborhood_door_order
from engines.wnba.wnba_expert_routed_trophy_door_v1 import select_shadow_board as _expert_routed_select_board, PATCH_ID as EXPERT_ROUTED_TROPHY_DOOR_PATCH_ID
from engines.wnba.wnba_dominant_anchor_qb_upgrade_sibling_reserve_v1 import apply_reserve as _apply_dominant_anchor_qb_reserve, PATCH_ID as DOMINANT_ANCHOR_QB_RESERVE_PATCH_ID
from engines.wnba import wnba_prelock_duplication_risk_shadow_v1 as _dup_risk_shadow


ENGINE_ID = "APEX_WNBA_CLASSIC_RAW_POOL_RUNTIME_v1"
ROSTER_GATE_LIFECYCLE_PATCH_ID = "APEX_GLOBAL_HARD_ENFORCED_ROSTER_GATE_LIFECYCLE_v1"
PATCH_ID = "WNBA_CLASSIC_OUT_ROLE_VACANCY_AND_CONTINGENCY_FAMILY_CLOSURE_v1"
CALIBRATION_PARITY_PATCH_ID = "WNBA_CLASSIC_FULL_CALIBRATION_CONTRACT_PARITY_v1"
FROZEN_CALIBRATION_FLOW_PATCH_ID = "WNBA_CLASSIC_FROZEN_PHASE1_CALIBRATION_END_TO_END_v1"
SELECTOR_RANKER_PATCH_ID = "WNBA_CLASSIC_UNCERTAINTY_AWARE_SCENARIO_LANE_RANKER_v1"
BANKROLL_SELECTOR_PATCH_ID = "WNBA_CLASSIC_HARD_CAP_COMPOSITE_BANKROLL_SELECTOR_v1"
RIGHT_NEIGHBORHOOD_DOOR_PATCH_ID = "WNBA_RIGHT_NEIGHBORHOOD_DOOR_SELECTOR_v1"
RECOVERY_ROLE_TAIL_PATCH_ID = "WNBA_CLASSIC_CHEAP_ACTIVE_ROLE_TAIL_PHASE1_v1"
RECOVERY_CLOSURE_PATCH_ID = "WNBA_CLASSIC_SUPPORT2_5_OF_6_ROLE_TAIL_CLOSURE_v1"
OPEN_RESEARCH_GOVERNANCE_PATCH_ID = "WNBA_CLASSIC_SELECTOR_RANK1_OPEN_RESEARCH_GOVERNANCE_v1"
STRUCTURAL_VALUE_GEOMETRY_PATCH_ID = "WNBA_CLASSIC_PHASE1_STRUCTURAL_VALUE_GEOMETRY_LANE_v1"
MEDIUM_FIELD_STRUCTURAL_VALUE_RECALL_PATCH_ID = "WNBA_CLASSIC_MEDIUM_FIELD_STRUCTURAL_VALUE_RECALL_v1"
MEDIUM_FIELD_PHASE2_STRUCTURAL_COMPLEMENT_PATCH_ID = "WNBA_CLASSIC_MEDIUM_FIELD_PHASE2_STRUCTURAL_COMPLEMENT_RECALL_v1"
MEDIUM_FIELD_ACTIVE_VALUE_STARTER_PATCH_ID = "WNBA_CLASSIC_MEDIUM_FIELD_ACTIVE_VALUE_STARTER_SENTINEL_v1"
MEDIUM_FIELD_ELITE_COHORT_TROPHY_LANE_PATCH_ID = "WNBA_CLASSIC_MEDIUM_FIELD_ELITE_COHORT_STRUCTURAL_TROPHY_LANE_v1"
MEDIUM_FIELD_ELITE_COHORT_TROPHY_SLOTS = 7
MEDIUM_FIELD_ELITE_COHORT_FIELD_MAX_EXCLUSIVE = 3000
MEDIUM_FIELD_ELITE_COHORT_FEATURE_MEAN = np.asarray([131.69018240343348, 1.1171438292060087, 31.65321876583181, 0.13733905579399142, 1.8819742489270386, 2.4570815450643777, 3.3798283261802573], dtype=float)
MEDIUM_FIELD_ELITE_COHORT_FEATURE_SCALE = np.asarray([14.70061972865917, 0.3800835816277772, 14.342800604918864, 0.35645579043512643, 0.8083637153735875, 0.6707270267578039, 0.547664542594091], dtype=float)
MEDIUM_FIELD_ELITE_COHORT_COEF = np.asarray([-0.1424403451968337, -0.954753033001721, -0.2661986635911172, 0.6119767768667814, 1.8312526825151532, 1.1040172751690973, 0.3453647109965932], dtype=float)
MEDIUM_FIELD_ELITE_COHORT_INTERCEPT = -1.7774684342306117
ALPHA_PAIR_LOW_MIN_GEOMETRY_PATCH_ID = "WNBA_CLASSIC_ALPHA_PAIR_LOW_MIN_TEAM_GEOMETRY_CLOSURE_v1"
RECENT_ROLE_DUAL_DISLOCATION_PATCH_ID = "WNBA_CLASSIC_RECENT_ROLE_CAPACITY_AND_DUAL_DISLOCATION_RECALL_v1"
ROTATION_STRATEGIST_PATCH_ID = "WNBA_CLASSIC_ROTATION_VACANCY_STRATEGIST_AND_VALUE_UNLOCK_v1"
FULL_ORDER_LEDGER_SCHEMA_VERSION = "WNBA_SELECTOR_FULL_ORDER_LEDGER_v1"
SEALED_IDENTITY_MAP_SCHEMA_VERSION = "WNBA_SEALED_LINEUP_IDENTITY_MAP_v1"
DUPLICATION_RISK_SHADOW_PATCH_ID = _dup_risk_shadow.PATCH_ID
SCENARIO_LANE_PODIUM_FRACTION = 0.40
BANKROLL_COMPOSITE_PROJECTION_WEIGHT = 0.30
BANKROLL_COMPOSITE_SALARY_REBOUND_WEIGHT = 0.30
BANKROLL_COMPOSITE_SHORTLIST_MAX = 2500
BANKROLL_RESERVE_FIELD_MIN = 1_000
BANKROLL_RESERVE_SLOTS = 2
BANKROLL_RESERVE_LANE_SCAN = 500
CALIBRATION_CONTRACT_VERSION = "WNBA_CALIBRATION_CONTRACT_v1"
DK_SCORING_WEIGHTS = {"PTS": 1.0, "REB": 1.25, "AST": 1.50, "STL": 2.0, "BLK": 2.0, "TO": -0.50, "3PM": 0.50, "2DBL": 1.50, "3DBL": 3.0}
COVARIANCE_LOADINGS = {"idio": 0.82, "team": 0.28, "game": 0.18}
PHASE2_BIRTH_WEIGHTS = {"p99": 0.40, "p95": 0.25, "mean": 0.20, "contingency": 1.00, "vacancy": 1.25, "salary_release": 0.0005}
FAKE_FIELD_WEIGHTS = {"mean": 0.75, "log_ownership": 2.70, "contingency": -0.40, "gumbel": 4.50}
SELECTOR_WEIGHTS = {"top01": 1000.0, "win": 100.0, "p99": 0.050, "p95": 0.020, "mean": 0.002, "expected_dup": -0.010, "salary": 0.0001}
WNBA_CLASSIC_SELECTOR_REVIEW_MIN_TRIALS = 10_000
WNBA_CLASSIC_RARE_EVENT_PRIOR_STRENGTH = 1_000.0
WNBA_CLASSIC_RARE_EVENT_SCORE_WEIGHTS = {
    "win_posterior": 0.42,
    "top01_posterior": 0.30,
    "cvar99": 0.12,
    "p99": 0.08,
    "uniqueness": 0.08,
}
CALIBRATION_THRESHOLDS = {"historical_role_ratio": 1.20, "vacancy_beneficiary_minutes": 2.5, "contingency_probability": 0.20, "elite_percentile": 0.99, "elite_tie_percentile": 0.985, "tail_percentile": 0.895}
STRUCTURAL_VALUE_SALARY_EDGES = (5_000, 7_500)
STRUCTURAL_VALUE_OPPORTUNITY_EDGES = (6.0, 18.0, 24.0)
STRUCTURAL_VALUE_CELL_WIDTH_LOG2_DIVISOR = 4.0
MEDIUM_FIELD_ACTIVE_VALUE_STARTER_SALARY_CEILING = 6_000
MEDIUM_FIELD_ACTIVE_VALUE_STARTER_MINUTES_FLOOR = 18.0
ALPHA_PAIR_WIDTH_LOG2_MULTIPLIER = 1.25
ALPHA_PAIR_TARGET_LOG2_MULTIPLIER = 4.0
ALPHA_PAIR_MIN_DENSITY = 10
RECENT_ROLE_CAPACITY_FLOOR = 18.0
RECENT_ROLE_CURRENT_MINUTES_CEILING = 6.0
RECENT_ROLE_EXPANSION_CAP = 12.0
ROTATION_ACTIVE_CURRENT_MINUTES_FLOOR = 6.0
ROTATION_ACTIVE_RECENT_MINUTES_FLOOR = 8.0
ROTATION_VALUE_MINUTES_FLOOR = 7.5
ROTATION_VALUE_SALARY_CEILING = 6_000
ROTATION_STALE_CURRENT_MINUTES_CEILING = 12.0
ROTATION_STALE_RECENT_MINUTES_CEILING = 6.0
ROTATION_TEAM_MINUTES_TARGET = 200.0
ROTATION_MAX_DIRECT_ABSORBERS_PER_OUT = 4
ROTATION_CROSS_ROLE_WING_INTERIOR_CEILING = 0.65
STRUCTURAL_VALUE_RECALL_FIELD_MIN = 1_000
STRUCTURAL_BIRTH_LARGE_FIELD_MIN = 3_000

# Large-field Top-0.1 right-neighborhood recall and trophy-door doctrine.
# These are identity-blind pre-lock geometry gates derived from post-lock research,
# then frozen for forward/blind validation. No realized player identity or score enters.
TOP001_RN_RELEASE_MAX = 1_300
TOP001_RN_STABLE_MINUTES_SUM_MIN = 135.0
TOP001_RN_STABLE_P99_SUM_MIN = 345.0
TOP001_RN_VOLATILE_MINUTES_SUM_MIN = 130.0
TOP001_RN_VOLATILE_P99_SUM_MIN = 365.0
TOP001_RN_LOW_MINUTES_CUTOFF = 10.0
TOP001_RN_LOW_MINUTES_MAX = 1
TOP001_RN_STRUCTURAL_COUNT_MIN = 1
TOP001_RN_VOLATILE_STRUCTURAL_COUNT_MIN = 2
TOP001_RN_DISLOCATION_MINUTES_SUM_MIN = 125.0
TOP001_RN_DISLOCATION_P99_SUM_MIN = 290.0
TOP001_RN_DISLOCATION_STRUCTURAL_COUNT_MIN = 1
TOP001_RN_DISLOCATION_PREMIUM_COUNT_MIN = 2
TOP001_RN_DISLOCATION_GAMES_USED_MAX = 2
TOP001_RN_GAMES_USED_MAX = 3
TOP001_RN_TEAMS_USED_MAX = 4
TOP001_RN_MAX_GAME_COUNT_MIN = 3
TOP001_TROPHY_DOOR_SLOTS = 10
TOP001_PHENOTYPE_ASSET_PATH = Path(__file__).with_name("wnba_classic_top001_anonymous_phenotype_calibration_v1.json")
MEDIUM_FIELD_PHASE2_RECALL_MIN = 1_000
MEDIUM_FIELD_PRIMARY_ANCHOR_COUNT = 1
MEDIUM_FIELD_STRUCTURAL_PAIR_CELL_DEPTH = 1
MEDIUM_FIELD_OPPORTUNITY_BAND_MAX_GAP = 1
ROSTER_RULE = "2G_3F_1UTIL"
SALARY_MIN = 48_000
SALARY_MAX = 50_000
MAX_FROM_TEAM = 4
MIN_GAMES = 2
SLOTS = ("G1", "G2", "F1", "F2", "F3", "UTIL")
REQUIRED_COLUMNS = {
    "PLAYER", "POS", "TEAM", "OPP", "SAL", "MIN", "PTS", "REB", "AST",
    "STL", "BLK", "3PM", "TO", "2DBL", "3DBL", "LINEUP", "AMIN", "GP",
    "MIN.1", "ST",
}


@dataclass(frozen=True)
class RuntimeConfig:
    field_size: int
    seed: int
    player_trials: int = 50_000
    base_trials: int = 10_000
    extra_trials: int = 40_000
    phase2_global_keep: int = 30_000
    phase2_family_keep: int = 10_000
    board_size: int = 10
    player_exposure_cap: int = 7
    family_cap: int = 5
    phase2_sim_cap: int = 8_000
    adaptive_bubble_max: int = 256


@dataclass
class Calibration:
    frame: pd.DataFrame
    sims: np.ndarray
    base_projection: np.ndarray
    mean: np.ndarray
    p95: np.ndarray
    p99: np.ndarray
    p_expand: np.ndarray
    role_ceiling_minutes: np.ndarray
    vacancy_minutes_added: np.ndarray
    historical_rebound: np.ndarray
    recent_role_rebound: np.ndarray
    vacancy_beneficiary: np.ndarray
    rotation_credibility: np.ndarray
    rotation_active: np.ndarray
    stale_role_suppressed: np.ndarray
    direct_vacancy_absorber: np.ndarray
    salary_unlock: np.ndarray
    strategic_role_fit: np.ndarray
    structural_value_geometry: np.ndarray
    team_codes: np.ndarray
    game_codes: np.ndarray
    is_guard: np.ndarray
    qualified: np.ndarray
    ownership_proxy: np.ndarray
    out_purge: list[str]
    zero_min_purge: list[str]
    covariance_hash: str
    player_identifier_hash: str
    ownership_hash: str
    ceiling_hash: str
    role_state_hash: str
    team_game_feature_hash: str
    metric_scaling_hash: str
    simulation_matrix_hash: str
    calibration_contract_hash: str
    global_strategy_receipt: dict[str, Any]


def _sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _stable_json_hash(obj: object) -> str:
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def _array_hash(values: np.ndarray) -> str:
    arr = np.ascontiguousarray(values)
    h = hashlib.sha256()
    h.update(str(arr.dtype).encode())
    h.update(json.dumps(arr.shape, separators=(",", ":")).encode())
    h.update(memoryview(arr).cast("B"))
    return h.hexdigest()


def _metric_scaling_contract() -> dict[str, object]:
    return {
        "contract_version": CALIBRATION_CONTRACT_VERSION,
        "dk_scoring_weights": DK_SCORING_WEIGHTS,
        "covariance_loadings": COVARIANCE_LOADINGS,
        "phase2_birth_weights": PHASE2_BIRTH_WEIGHTS,
        "fake_field_weights": FAKE_FIELD_WEIGHTS,
        "selector_weights": SELECTOR_WEIGHTS,
        "selector_ranker": {
            "patch_id": SELECTOR_RANKER_PATCH_ID,
            "top10_contest_rank": 10,
            "scenario_lane_podium_fraction": SCENARIO_LANE_PODIUM_FRACTION,
            "uncertainty_tie_method": "wilson_overlap_with_best",
            "lane_leader_primary": ["top01_wilson_tie", "win_wilson_tie"],
            "lane_leader_tiebreaks": ["salary_release", "expected_dup", "top10_wilson_tie", "p99", "p95", "mean"],
        },
        "thresholds": CALIBRATION_THRESHOLDS,
        "frozen_phase1_calibration_flow": {
            "patch_id": FROZEN_CALIBRATION_FLOW_PATCH_ID,
            "source_of_truth": "PHASE1_CALIBRATION_CONTRACT_HASH",
            "downstream_recalibration_prohibited": True,
            "phases": ["LEGAL_ENUMERATION", "PHASE2", "PHASE3", "HANDOFF", "SELECTOR"],
            "mismatch_action": "FROZEN_PHASE1_CALIBRATION_HASH_DRIFT",
        },
        "structural_value_geometry": {
            "patch_id": STRUCTURAL_VALUE_GEOMETRY_PATCH_ID,
            "salary_edges": STRUCTURAL_VALUE_SALARY_EDGES,
            "opportunity_edges": STRUCTURAL_VALUE_OPPORTUNITY_EDGES,
            "cell_width_log2_divisor": STRUCTURAL_VALUE_CELL_WIDTH_LOG2_DIVISOR,
            "ranking_surface": "PHASE1_P99_PER_1000_SALARY",
            "medium_field_recall_patch_id": MEDIUM_FIELD_STRUCTURAL_VALUE_RECALL_PATCH_ID,
            "medium_field_activation_min": STRUCTURAL_VALUE_RECALL_FIELD_MIN,
            "alpha_pair_large_field_threshold_unchanged": STRUCTURAL_BIRTH_LARGE_FIELD_MIN,
            "active_value_starter_patch_id": MEDIUM_FIELD_ACTIVE_VALUE_STARTER_PATCH_ID,
            "active_value_starter_salary_ceiling": MEDIUM_FIELD_ACTIVE_VALUE_STARTER_SALARY_CEILING,
            "active_value_starter_minutes_floor": MEDIUM_FIELD_ACTIVE_VALUE_STARTER_MINUTES_FLOOR,
        },
        "medium_field_phase2_structural_complement_recall": {
            "patch_id": MEDIUM_FIELD_PHASE2_STRUCTURAL_COMPLEMENT_PATCH_ID,
            "field_min": MEDIUM_FIELD_PHASE2_RECALL_MIN,
            "field_max_exclusive": STRUCTURAL_BIRTH_LARGE_FIELD_MIN,
            "primary_anchor_count": MEDIUM_FIELD_PRIMARY_ANCHOR_COUNT,
            "structural_pair_cell_depth": MEDIUM_FIELD_STRUCTURAL_PAIR_CELL_DEPTH,
            "salary_band_complement": [0, 1],
            "opportunity_band_max_gap": MEDIUM_FIELD_OPPORTUNITY_BAND_MAX_GAP,
            "pair_ranking_surface": "PHASE1_PAIR_P99_SUM",
            "lineup_ranking_surface": "AUTHORITATIVE_PROJECTED_MINUTES_SUM_THEN_BIRTH_SCORE",
            "cell_signature": ["SALARY_RELEASE_BAND", "POSITION_SHAPE", "EXACT_TEAM_COUNTS"],
            "requires_all_rotation_active": True,
            "postlock_results_used": False,
        },
        "alpha_pair_low_min_geometry": {
            "patch_id": ALPHA_PAIR_LOW_MIN_GEOMETRY_PATCH_ID,
            "alpha_width_log2_multiplier": ALPHA_PAIR_WIDTH_LOG2_MULTIPLIER,
            "pair_target_log2_multiplier": ALPHA_PAIR_TARGET_LOG2_MULTIPLIER,
            "minimum_pair_density": ALPHA_PAIR_MIN_DENSITY,
            "trigger": "AUTHORITATIVE_PROJECTED_MIN_LT_6",
            "clean_depth": 1,
            "cell_signature": [
                "SALARY_BAND", "PREMIUM_COUNT", "CHEAP_COUNT",
                "STARTER_COUNT", "POSITION_SHAPE", "EXACT_GAME_COUNTS",
                "EXACT_TEAM_COUNTS", "EXACT_OPPORTUNITY_BAND_COUNTS",
            ],
        },
        "recent_role_dual_dislocation_recall": {
            "patch_id": RECENT_ROLE_DUAL_DISLOCATION_PATCH_ID,
            "recent_role_capacity_floor": RECENT_ROLE_CAPACITY_FLOOR,
            "current_minutes_ceiling": RECENT_ROLE_CURRENT_MINUTES_CEILING,
            "recent_only_expansion_cap": RECENT_ROLE_EXPANSION_CAP,
            "phase2_trigger": "AT_LEAST_ONE_RECENT_ONLY_REBOUND_PLUS_TWO_LOW_ROLE_REBOUNDS",
            "postlock_results_used": False,
        },
        "global_sports_strategist": {"patch_id": GLOBAL_SPORTS_STRATEGIST_PATCH_ID, "contract_hash": global_strategy.stable_hash(global_strategy.profile_for("WNBA", "CLASSIC")), "load_order": global_strategy.LOAD_ORDER, "postlock_results_used": False},
        "rotation_vacancy_strategist": {
            "patch_id": ROTATION_STRATEGIST_PATCH_ID,
            "team_minutes_target": ROTATION_TEAM_MINUTES_TARGET,
            "rotation_active_current_minutes_floor": ROTATION_ACTIVE_CURRENT_MINUTES_FLOOR,
            "rotation_active_recent_minutes_floor": ROTATION_ACTIVE_RECENT_MINUTES_FLOOR,
            "value_minutes_floor": ROTATION_VALUE_MINUTES_FLOOR,
            "value_salary_ceiling": ROTATION_VALUE_SALARY_CEILING,
            "stale_current_minutes_ceiling": ROTATION_STALE_CURRENT_MINUTES_CEILING,
            "stale_recent_minutes_ceiling": ROTATION_STALE_RECENT_MINUTES_CEILING,
            "max_direct_absorbers_per_out": ROTATION_MAX_DIRECT_ABSORBERS_PER_OUT,
            "role_dimensions": ["creation", "scoring", "interior", "defense"],
            "current_rotation_evidence_precedes_historical_role": True,
            "salary_unlock_requires_rotation_evidence": True,
            "postlock_results_used": False,
        },
    }


def _calibration_component_hashes(cal: "Calibration") -> dict[str, str]:
    id_columns = [c for c in ("ID", "PLAYER", "TEAM", "OPP", "POS", "SAL") if c in cal.frame.columns]
    player_rows = cal.frame[id_columns].astype(str).to_dict(orient="records")
    ceiling_arrays = np.column_stack((
        cal.base_projection, cal.mean, cal.p95, cal.p99,
        cal.role_ceiling_minutes, cal.p_expand,
    )).astype(np.float32, copy=False)
    role_arrays = np.column_stack((
        cal.vacancy_minutes_added,
        cal.historical_rebound.astype(np.float32),
        cal.recent_role_rebound.astype(np.float32),
        cal.vacancy_beneficiary.astype(np.float32),
        cal.rotation_credibility.astype(np.float32),
        cal.rotation_active.astype(np.float32),
        cal.stale_role_suppressed.astype(np.float32),
        cal.direct_vacancy_absorber.astype(np.float32),
        cal.salary_unlock.astype(np.float32),
        cal.strategic_role_fit.astype(np.float32),
        cal.structural_value_geometry.astype(np.float32),
        cal.qualified.astype(np.float32),
    )).astype(np.float32, copy=False)
    feature_arrays = np.column_stack((
        cal.team_codes.astype(np.int32),
        cal.game_codes.astype(np.int32),
        cal.is_guard.astype(np.int32),
    ))
    components = {
        "player_identifier_hash": _stable_json_hash(player_rows),
        "ownership_hash": _array_hash(cal.ownership_proxy),
        "ceiling_hash": _array_hash(ceiling_arrays),
        "role_state_hash": _array_hash(role_arrays),
        "team_game_feature_hash": _array_hash(feature_arrays),
        "metric_scaling_hash": _stable_json_hash(_metric_scaling_contract()),
        "simulation_matrix_hash": _array_hash(cal.sims),
        "covariance_hash": cal.covariance_hash,
    }
    components["calibration_contract_hash"] = _stable_json_hash(components)
    return components


def _assert_calibration_sync(cal: "Calibration", phase: str) -> str:
    components = _calibration_component_hashes(cal)
    expected = {
        "player_identifier_hash": cal.player_identifier_hash,
        "ownership_hash": cal.ownership_hash,
        "ceiling_hash": cal.ceiling_hash,
        "role_state_hash": cal.role_state_hash,
        "team_game_feature_hash": cal.team_game_feature_hash,
        "metric_scaling_hash": cal.metric_scaling_hash,
        "simulation_matrix_hash": cal.simulation_matrix_hash,
        "covariance_hash": cal.covariance_hash,
        "calibration_contract_hash": cal.calibration_contract_hash,
    }
    if components != expected:
        mismatches = sorted(k for k in expected if expected[k] != components[k])
        raise RuntimeError(f"CALIBRATION_PARITY_INTEGRITY_FAILURE:{phase}:{','.join(mismatches)}")
    return components["calibration_contract_hash"]


def _assert_frozen_phase1_calibration(
    cal: "Calibration", phase: str, expected_phase1_hash: str | None = None,
) -> str:
    current = _assert_calibration_sync(cal, phase)
    if expected_phase1_hash is not None and current != expected_phase1_hash:
        raise RuntimeError(
            f"FROZEN_PHASE1_CALIBRATION_HASH_DRIFT:{phase}:{current}:{expected_phase1_hash}"
        )
    return current


def _dk_projection(df: pd.DataFrame) -> np.ndarray:
    return (
        DK_SCORING_WEIGHTS["PTS"] * df["PTS"].to_numpy(float)
        + DK_SCORING_WEIGHTS["REB"] * df["REB"].to_numpy(float)
        + DK_SCORING_WEIGHTS["AST"] * df["AST"].to_numpy(float)
        + DK_SCORING_WEIGHTS["STL"] * df["STL"].to_numpy(float)
        + DK_SCORING_WEIGHTS["BLK"] * df["BLK"].to_numpy(float)
        + DK_SCORING_WEIGHTS["TO"] * df["TO"].to_numpy(float)
        + DK_SCORING_WEIGHTS["3PM"] * df["3PM"].to_numpy(float)
        + DK_SCORING_WEIGHTS["2DBL"] * df["2DBL"].to_numpy(float)
        + DK_SCORING_WEIGHTS["3DBL"] * df["3DBL"].to_numpy(float)
    )


def _game_key(team: str, opponent: str) -> str:
    return "-".join(sorted((str(team), str(opponent))))


def _normalized_role_vectors(df: pd.DataFrame) -> np.ndarray:
    """Result-blind role vectors used to map vacated responsibilities to active teammates."""
    denom = np.maximum(df["MIN"].fillna(0).to_numpy(float), 6.0)
    creation = df["AST"].fillna(0).to_numpy(float) / denom
    scoring = (
        df.get("FGA", pd.Series(0.0, index=df.index)).fillna(0).to_numpy(float)
        + 0.44 * df.get("FTA", pd.Series(0.0, index=df.index)).fillna(0).to_numpy(float)
    ) / denom
    interior = (
        df["REB"].fillna(0).to_numpy(float)
        + 1.50 * df["BLK"].fillna(0).to_numpy(float)
        + 0.80 * df.get("OREB", pd.Series(0.0, index=df.index)).fillna(0).to_numpy(float)
    ) / denom
    defense = (
        df["STL"].fillna(0).to_numpy(float)
        + df["BLK"].fillna(0).to_numpy(float)
    ) / denom
    values = np.maximum(np.column_stack((creation, scoring, interior, defense)), 0.0)
    norms = np.linalg.norm(values, axis=1, keepdims=True)
    norms = np.where(norms > 0.0, norms, 1.0)
    return values / norms


def load_and_calibrate(
    pool_path: str | Path,
    out_names: Iterable[str],
    config: RuntimeConfig,
) -> Calibration:
    raw = pd.read_csv(pool_path)
    missing = sorted(REQUIRED_COLUMNS - set(raw.columns))
    if missing:
        raise ValueError(f"MISSING_REQUIRED_COLUMNS={','.join(missing)}")

    out_set = {str(x).strip() for x in out_names if str(x).strip()}
    zero_min_mask = raw["MIN"].fillna(0).astype(float).le(0)
    explicit_out_mask = raw["PLAYER"].astype(str).isin(out_set)
    zero_min_purge = raw.loc[zero_min_mask, "PLAYER"].astype(str).tolist()
    out_purge = raw.loc[explicit_out_mask, "PLAYER"].astype(str).tolist()

    active = raw.loc[~zero_min_mask & ~explicit_out_mask].copy().reset_index(drop=True)
    if active.empty:
        raise ValueError("NO_ACTIVE_PLAYERS")
    global_strategy_features = global_strategy.build_strategy_features(active, sport="WNBA", mode="CLASSIC")

    base = _dk_projection(active)
    minutes = active["MIN"].fillna(0).to_numpy(float)
    historical_minutes = active["AMIN"].fillna(0).to_numpy(float)
    recent_minutes = active["MIN.1"].fillna(0).to_numpy(float)
    games_played = active["GP"].fillna(0).to_numpy(float)
    starts = active["ST"].fillna(0).to_numpy(float)
    start_rate = np.divide(starts, np.maximum(games_played, 1.0))
    salaries = active["SAL"].astype(int).to_numpy()
    is_guard = active["POS"].astype(str).str.contains("G", case=False).to_numpy()
    lineup_text = active["LINEUP"].fillna("").astype(str).str.upper().str.strip()
    lineup_starter = lineup_text.isin({"YES", "Y", "START", "STARTER"}).to_numpy()
    explicit_bench = lineup_text.eq("BN").to_numpy()
    stale_role_suppressed = (
        (historical_minutes >= 18.0)
        & (minutes < ROTATION_STALE_CURRENT_MINUTES_CEILING)
        & (recent_minutes < ROTATION_STALE_RECENT_MINUTES_CEILING)
        & explicit_bench
    )
    rotation_credibility = np.maximum.reduce((
        np.clip(minutes / 24.0, 0.0, 1.0),
        0.70 * np.clip(recent_minutes / 24.0, 0.0, 1.0),
        0.95 * lineup_starter.astype(float),
    ))
    rotation_credibility = np.where(stale_role_suppressed, np.minimum(rotation_credibility, 0.12), rotation_credibility)
    rotation_active = (
        lineup_starter
        | (minutes >= ROTATION_ACTIVE_CURRENT_MINUTES_FLOOR)
        | ((recent_minutes >= ROTATION_ACTIVE_RECENT_MINUTES_FLOOR) & ~explicit_bench)
    ) & ~stale_role_suppressed

    team_cat = pd.Categorical(active["TEAM"].astype(str))
    game_cat = pd.Categorical([
        _game_key(t, o) for t, o in zip(active["TEAM"], active["OPP"], strict=True)
    ])
    team_codes = team_cat.codes.astype(np.int16)
    game_codes = game_cat.codes.astype(np.int16)

    role_ceiling = np.maximum.reduce((minutes, 0.95 * historical_minutes, 0.90 * recent_minutes))
    role_ceiling = np.where(stale_role_suppressed, minutes, role_ceiling)
    vacancy_added = np.zeros(len(active), dtype=float)
    direct_vacancy_absorber = np.zeros(len(active), dtype=bool)
    strategic_role_fit = np.zeros(len(active), dtype=float)
    active_role_vectors = _normalized_role_vectors(active)
    raw_role_vectors = _normalized_role_vectors(raw)
    active_team_text = active["TEAM"].astype(str)

    # Sports-strategy vacancy model. Each OUT row is decomposed into creation, scoring,
    # interior and defensive responsibilities. Only teammates with current rotation evidence
    # can receive direct vacancy minutes. The team budget is capped by the amount required to
    # restore a 200-minute WNBA rotation, preventing double counting when projections already
    # embed part of the injury adjustment.
    for out_team in sorted(raw.loc[explicit_out_mask, "TEAM"].astype(str).unique()):
        team_active_mask = active_team_text.eq(out_team).to_numpy()
        team_active_minutes = float(minutes[team_active_mask].sum())
        team_missing_minutes = max(0.0, ROTATION_TEAM_MINUTES_TARGET - team_active_minutes)
        out_rows = raw.loc[explicit_out_mask & raw["TEAM"].astype(str).eq(out_team)]
        out_projected_minutes = float(out_rows["MIN"].fillna(0).sum())
        if team_missing_minutes <= 0.0 or out_projected_minutes <= 0.0:
            continue

        for out_index, out_row in out_rows.iterrows():
            out_minutes = max(0.0, float(out_row["MIN"] or 0.0))
            if out_minutes <= 0.0:
                continue
            vacancy_budget = team_missing_minutes * out_minutes / out_projected_minutes
            out_vector = raw_role_vectors[int(out_index)]
            out_is_guard = "G" in str(out_row["POS"]).upper()
            wing_cross_role_allowed = float(out_vector[2]) < ROTATION_CROSS_ROLE_WING_INTERIOR_CEILING

            candidate_mask = (
                team_active_mask
                & rotation_active
                & (minutes >= ROTATION_ACTIVE_CURRENT_MINUTES_FLOOR)
            )
            candidate_idx = np.flatnonzero(candidate_mask)
            if candidate_idx.size == 0:
                continue

            same_dk_role = (is_guard[candidate_idx] == out_is_guard)
            if out_is_guard:
                cross_role_skill_ok = active_role_vectors[candidate_idx, 0] >= 0.50 * out_vector[0]
            else:
                cross_role_skill_ok = active_role_vectors[candidate_idx, 2] >= 0.55 * out_vector[2]
            cross_role_allowed = wing_cross_role_allowed & cross_role_skill_ok
            positional_affinity = np.where(
                same_dk_role,
                1.0,
                np.where(cross_role_allowed, 0.55, 0.05),
            )
            role_fit = np.clip(active_role_vectors[candidate_idx] @ out_vector, 0.0, 1.0)
            role_capacity = np.maximum.reduce((
                np.maximum(0.0, 0.95 * recent_minutes[candidate_idx] - minutes[candidate_idx]),
                np.maximum(0.0, 0.85 * historical_minutes[candidate_idx] - minutes[candidate_idx]),
                np.full(candidate_idx.size, 2.0),
            ))
            role_capacity = np.where(stale_role_suppressed[candidate_idx], 0.0, role_capacity)
            strategy_weight = (
                (0.30 + 0.70 * role_fit)
                * positional_affinity
                * (0.25 + 0.75 * rotation_credibility[candidate_idx])
                * role_capacity
            )
            positive = strategy_weight > 0.0
            candidate_idx = candidate_idx[positive]
            strategy_weight = strategy_weight[positive]
            role_fit = role_fit[positive]
            if candidate_idx.size == 0 or strategy_weight.sum() <= 0.0:
                continue

            allocation = vacancy_budget * strategy_weight / strategy_weight.sum()
            vacancy_added[candidate_idx] += allocation
            strategic_role_fit[candidate_idx] = np.maximum(strategic_role_fit[candidate_idx], role_fit)
            role_ceiling[candidate_idx] = np.maximum(
                role_ceiling[candidate_idx],
                minutes[candidate_idx] + allocation,
            )

            # Identify the best inexpensive role absorbers even when their current projection
            # already includes the vacated minutes. This is the salary-unlock path the lineup
            # builder must preserve before global Phase 2 cuts.
            value_mask = (
                rotation_active[candidate_idx]
                & (minutes[candidate_idx] >= ROTATION_VALUE_MINUTES_FLOOR)
                & (salaries[candidate_idx] <= ROTATION_VALUE_SALARY_CEILING)
                & (role_fit >= 0.78)
                & (positional_affinity >= 0.50)
            )
            value_idx = candidate_idx[value_mask]
            if value_idx.size:
                value_score = (
                    strategic_role_fit[value_idx]
                    * (0.40 + 0.60 * rotation_credibility[value_idx])
                    * np.clip(minutes[value_idx] / 18.0, 0.50, 1.50)
                )
                keep = min(ROTATION_MAX_DIRECT_ABSORBERS_PER_OUT, value_idx.size)
                top = value_idx[np.argsort(-value_score, kind="stable")[:keep]]
                direct_vacancy_absorber[top] = True

    salary_unlock = (
        direct_vacancy_absorber
        & rotation_active
        & (salaries <= ROTATION_VALUE_SALARY_CEILING)
        & (minutes >= ROTATION_VALUE_MINUTES_FLOOR)
    )

    role_ratio = np.divide(role_ceiling, np.maximum(minutes, 1.0))
    # A 20% gap is sufficient to preserve an established starter's rebound state.
    # The prior 35% threshold starved legitimate role-recovery routes such as a
    # starter returning from a temporary minutes restriction.
    historical_rebound = (
        (historical_minutes >= 18.0)
        & (role_ratio >= CALIBRATION_THRESHOLDS["historical_role_ratio"])
        & (games_played >= 8.0)
        & ~stale_role_suppressed
    )
    # A separate recent-only bridge preserves players whose long-window AMIN is below
    # the historical floor but whose recent documented role still clears it. The lane
    # is deliberately restricted to severe current-role dislocations so ordinary
    # rotation players are not promoted by a generic recent-minutes signal.
    recent_role_rebound = (
        (historical_minutes < RECENT_ROLE_CAPACITY_FLOOR)
        & (recent_minutes >= RECENT_ROLE_CAPACITY_FLOOR)
        & (minutes < RECENT_ROLE_CURRENT_MINUTES_CEILING)
        & (role_ratio >= CALIBRATION_THRESHOLDS["historical_role_ratio"])
        & (games_played >= 8.0)
    )
    role_rebound = historical_rebound | recent_role_rebound
    vacancy_beneficiary = (
        (vacancy_added >= CALIBRATION_THRESHOLDS["vacancy_beneficiary_minutes"])
        | direct_vacancy_absorber
    ) & ~stale_role_suppressed

    p_expand = np.full(len(active), 0.03, dtype=float)
    p_expand = np.where(
        role_rebound,
        0.25 + 0.20 * np.clip(start_rate, 0.0, 1.0),
        p_expand,
    )
    p_expand = np.where(vacancy_beneficiary, np.maximum(p_expand, 0.40), p_expand)
    p_expand = np.where(salary_unlock, np.maximum(p_expand, 0.48), p_expand)
    p_expand = np.where(stale_role_suppressed, np.minimum(p_expand, 0.04), p_expand)
    p_expand = np.clip(p_expand, 0.03, 0.60)

    expansion_cap = np.where(recent_role_rebound, RECENT_ROLE_EXPANSION_CAP, 3.2)
    expanded_mean = base * np.clip(role_ratio, 1.0, expansion_cap)
    expanded_mean *= np.where(role_rebound, 1.05, 1.0)
    expanded_mean *= np.where(direct_vacancy_absorber, 1.04 + 0.06 * strategic_role_fit, 1.0)
    expanded_mean *= np.where(salary_unlock, 1.04, 1.0)
    expanded_mean = np.where(stale_role_suppressed, base, expanded_mean)
    expanded_mean = np.maximum(expanded_mean, base)

    rng = np.random.default_rng(config.seed)
    n_players = len(active)
    n_trials = config.player_trials
    idio_loading = COVARIANCE_LOADINGS["idio"]
    team_loading = COVARIANCE_LOADINGS["team"]
    game_loading = COVARIANCE_LOADINGS["game"]
    norm = math.sqrt(idio_loading**2 + team_loading**2 + game_loading**2)

    z_idio = rng.standard_normal((n_players, n_trials), dtype=np.float32)
    z_team = rng.standard_normal((int(team_codes.max()) + 1, n_trials), dtype=np.float32)
    z_game = rng.standard_normal((int(game_codes.max()) + 1, n_trials), dtype=np.float32)
    z = (
        idio_loading * z_idio
        + team_loading * z_team[team_codes]
        + game_loading * z_game[game_codes]
    ) / norm

    role_state = rng.random((n_players, n_trials), dtype=np.float32) < p_expand[:, None]
    state_mean = np.where(role_state, expanded_mean[:, None], base[:, None])
    cv = np.clip(
        0.40 + 0.20 * (minutes < 18.0) + 0.10 * (minutes < 12.0),
        0.35,
        0.75,
    )
    log_sigma = np.sqrt(np.log1p(cv**2))[:, None]
    sims = state_mean * np.exp(log_sigma * z - 0.5 * log_sigma**2)
    sims = np.ascontiguousarray(sims, dtype=np.float32)

    mean = sims.mean(axis=1)
    p95 = np.quantile(sims, 0.95, axis=1).astype(np.float32)
    p99 = np.quantile(sims, 0.99, axis=1).astype(np.float32)

    # Calibration-first qualification. Rank limits control runtime, while explicit role-state
    # sentinels prevent low-minute but credible contingency players from being starved.
    qualified = np.zeros(n_players, dtype=bool)
    for guard_flag, keep in ((True, 18), (False, 20)):
        idx = np.flatnonzero(is_guard == guard_flag)
        k = min(keep, idx.size)
        if k:
            qualified[idx[np.argpartition(p99[idx], -k)[-k:]]] = True
    qualified |= role_rebound | vacancy_beneficiary | salary_unlock
    qualified &= ~stale_role_suppressed | (minutes >= 18.0)
    for team_code in np.unique(team_codes):
        for guard_flag in (True, False):
            idx = np.flatnonzero(
                (team_codes == team_code)
                & (is_guard == guard_flag)
                & (minutes >= 6.0)
            )
            k = min(2, idx.size)
            if k:
                qualified[idx[np.argpartition(p99[idx], -k)[-k:]]] = True

    # Result-blind structural value geometry derived from the frozen Phase 1
    # ceiling surface, roster position, salary and authoritative projected MIN.
    structural_value_geometry = np.zeros(n_players, dtype=bool)
    salary_band = np.searchsorted(
        np.asarray(STRUCTURAL_VALUE_SALARY_EDGES, dtype=np.int32),
        salaries,
        side="right",
    )
    opportunity_band = np.searchsorted(
        np.asarray(STRUCTURAL_VALUE_OPPORTUNITY_EDGES, dtype=np.float32),
        minutes,
        side="right",
    )
    cell_width = max(
        1,
        math.ceil(
            math.log2(max(2, int(config.field_size)))
            / STRUCTURAL_VALUE_CELL_WIDTH_LOG2_DIVISOR
        ),
    )
    ceiling_efficiency = p99 / np.maximum(salaries / 1000.0, 1.0)
    if config.field_size >= STRUCTURAL_VALUE_RECALL_FIELD_MIN:
        for guard_flag in (True, False):
            for salary_cell in range(len(STRUCTURAL_VALUE_SALARY_EDGES)):
                for opportunity_cell in range(
                    len(STRUCTURAL_VALUE_OPPORTUNITY_EDGES) + 1
                ):
                    idx = np.flatnonzero(
                        (is_guard == guard_flag)
                        & (salary_band == salary_cell)
                        & (opportunity_band == opportunity_cell)
                    )
                    k = min(cell_width, idx.size)
                    if k:
                        chosen = idx[
                            np.argpartition(ceiling_efficiency[idx], -k)[-k:]
                        ]
                        structural_value_geometry[chosen] = True
    qualified |= structural_value_geometry

    # Medium-field active value-starter sentinel. Result-blind: prelock salary,
    # current/recent projected minutes and confirmed starter status only.
    medium_field_active_value_starter = (
        (config.field_size >= STRUCTURAL_VALUE_RECALL_FIELD_MIN)
        & lineup_starter
        & (minutes >= MEDIUM_FIELD_ACTIVE_VALUE_STARTER_MINUTES_FLOOR)
        & (recent_minutes >= MEDIUM_FIELD_ACTIVE_VALUE_STARTER_MINUTES_FLOOR)
        & (salaries <= MEDIUM_FIELD_ACTIVE_VALUE_STARTER_SALARY_CEILING)
        & ~stale_role_suppressed
    )
    qualified |= medium_field_active_value_starter

    # Production recovery: forward-only cheap active role-tail qualification.
    recovery_role_tail = (
        (salaries <= 3500)
        & (minutes >= 6.0)
        & (minutes < 15.0)
        & rotation_active
        & ~stale_role_suppressed
    )
    qualified |= recovery_role_tail

    # Ownership proxy is used only when RST% is absent. It is deterministic and separated
    # from post-lock results.
    starter = lineup_starter.astype(float)
    ownership_logit = 0.085 * base + 0.018 * minutes + 0.30 * starter - 0.00003 * salaries
    ownership_logit -= 0.90 * (p_expand >= 0.20)
    ownership_proxy = np.exp(ownership_logit - ownership_logit.max())
    ownership_proxy = ownership_proxy / ownership_proxy.sum() * 6.0
    ownership_proxy = np.clip(ownership_proxy, 0.002, 0.65)

    covariance_contract = {
        "idio_loading": idio_loading,
        "team_loading": team_loading,
        "game_loading": game_loading,
        "normalizer": norm,
        "player_trials": n_trials,
    }

    cal = Calibration(
        frame=active,
        sims=sims,
        base_projection=base,
        mean=mean.astype(np.float32),
        p95=p95,
        p99=p99,
        p_expand=p_expand.astype(np.float32),
        role_ceiling_minutes=role_ceiling.astype(np.float32),
        vacancy_minutes_added=vacancy_added.astype(np.float32),
        historical_rebound=historical_rebound,
        recent_role_rebound=recent_role_rebound,
        vacancy_beneficiary=vacancy_beneficiary,
        rotation_credibility=rotation_credibility.astype(np.float32),
        rotation_active=rotation_active,
        stale_role_suppressed=stale_role_suppressed,
        direct_vacancy_absorber=direct_vacancy_absorber,
        salary_unlock=salary_unlock,
        strategic_role_fit=strategic_role_fit.astype(np.float32),
        structural_value_geometry=structural_value_geometry,
        team_codes=team_codes,
        game_codes=game_codes,
        is_guard=is_guard,
        qualified=qualified,
        ownership_proxy=ownership_proxy.astype(np.float32),
        out_purge=out_purge,
        zero_min_purge=zero_min_purge,
        covariance_hash=_stable_json_hash(covariance_contract),
        player_identifier_hash="",
        ownership_hash="",
        ceiling_hash="",
        role_state_hash="",
        team_game_feature_hash="",
        metric_scaling_hash="",
        simulation_matrix_hash="",
        calibration_contract_hash="",
        global_strategy_receipt=dict(global_strategy_features.receipt),
    )
    if global_strategy_features.receipt["PATCH_ID"] != GLOBAL_SPORTS_STRATEGIST_PATCH_ID:
        raise RuntimeError("RUN_INVALID:GLOBAL_SPORTS_STRATEGY_CONTRACT_MISMATCH")
    components = _calibration_component_hashes(cal)
    for key, value in components.items():
        setattr(cal, key, value)
    _assert_calibration_sync(cal, "PHASE1")
    return cal


@njit(cache=True)
def _valid_lineup(
    a: int, b: int, c: int, d: int, e: int, f: int,
    salary: np.ndarray, team: np.ndarray, game: np.ndarray,
) -> bool:
    total = salary[a] + salary[b] + salary[c] + salary[d] + salary[e] + salary[f]
    if total < SALARY_MIN or total > SALARY_MAX:
        return False
    players = np.array((a, b, c, d, e, f), dtype=np.int16)
    for i in range(6):
        team_count = 0
        for j in range(6):
            team_count += team[players[j]] == team[players[i]]
        if team_count > MAX_FROM_TEAM:
            return False
    first_game = game[players[0]]
    multiple_games = False
    for i in range(1, 6):
        if game[players[i]] != first_game:
            multiple_games = True
            break
    return multiple_games


@njit(cache=True)
def _count_legal(
    guards: np.ndarray, forwards: np.ndarray,
    salary: np.ndarray, team: np.ndarray, game: np.ndarray,
) -> int:
    n = 0
    ng = len(guards)
    nf = len(forwards)
    # 3 guards + 3 forwards (guard in UTIL)
    for ia in range(ng - 2):
        a = guards[ia]
        for ib in range(ia + 1, ng - 1):
            b = guards[ib]
            for ic in range(ib + 1, ng):
                c = guards[ic]
                for id_ in range(nf - 2):
                    d = forwards[id_]
                    for ie in range(id_ + 1, nf - 1):
                        e = forwards[ie]
                        for iff in range(ie + 1, nf):
                            f = forwards[iff]
                            if _valid_lineup(a, b, c, d, e, f, salary, team, game):
                                n += 1
    # 2 guards + 4 forwards (forward in UTIL)
    for ia in range(ng - 1):
        a = guards[ia]
        for ib in range(ia + 1, ng):
            b = guards[ib]
            for id_ in range(nf - 3):
                d = forwards[id_]
                for ie in range(id_ + 1, nf - 2):
                    e = forwards[ie]
                    for iff in range(ie + 1, nf - 1):
                        f = forwards[iff]
                        for ih in range(iff + 1, nf):
                            h = forwards[ih]
                            if _valid_lineup(a, b, d, e, f, h, salary, team, game):
                                n += 1
    return n


@njit(cache=True)
def _fill_legal(
    guards: np.ndarray, forwards: np.ndarray,
    salary: np.ndarray, team: np.ndarray, game: np.ndarray,
    count: int,
) -> np.ndarray:
    out = np.empty((count, 6), dtype=np.int16)
    k = 0
    ng = len(guards)
    nf = len(forwards)
    for ia in range(ng - 2):
        a = guards[ia]
        for ib in range(ia + 1, ng - 1):
            b = guards[ib]
            for ic in range(ib + 1, ng):
                c = guards[ic]
                for id_ in range(nf - 2):
                    d = forwards[id_]
                    for ie in range(id_ + 1, nf - 1):
                        e = forwards[ie]
                        for iff in range(ie + 1, nf):
                            f = forwards[iff]
                            if _valid_lineup(a, b, c, d, e, f, salary, team, game):
                                out[k] = np.array((a, b, c, d, e, f), dtype=np.int16)
                                k += 1
    for ia in range(ng - 1):
        a = guards[ia]
        for ib in range(ia + 1, ng):
            b = guards[ib]
            for id_ in range(nf - 3):
                d = forwards[id_]
                for ie in range(id_ + 1, nf - 2):
                    e = forwards[ie]
                    for iff in range(ie + 1, nf - 1):
                        f = forwards[iff]
                        for ih in range(iff + 1, nf):
                            h = forwards[ih]
                            if _valid_lineup(a, b, d, e, f, h, salary, team, game):
                                out[k] = np.array((a, b, d, e, f, h), dtype=np.int16)
                                k += 1
    return out


def enumerate_legal(
    cal: Calibration, expected_phase1_hash: str | None = None,
) -> np.ndarray:
    _assert_frozen_phase1_calibration(cal, "LEGAL_ENUMERATION", expected_phase1_hash)
    qualified_idx = np.flatnonzero(cal.qualified).astype(np.int16)
    guards = qualified_idx[cal.is_guard[qualified_idx]].astype(np.int16)
    forwards = qualified_idx[~cal.is_guard[qualified_idx]].astype(np.int16)
    if guards.size < 2 or forwards.size < 3:
        raise ValueError("ROSTER_POSITION_FEASIBILITY_FAILURE")
    salary = cal.frame["SAL"].astype(np.int32).to_numpy()
    count = _count_legal(guards, forwards, salary, cal.team_codes, cal.game_codes)
    if count <= 0:
        raise ValueError("NO_LEGAL_ROSTERS")
    return _fill_legal(guards, forwards, salary, cal.team_codes, cal.game_codes, count)


def phase2_family_closure(
    lineups: np.ndarray,
    cal: Calibration,
    config: RuntimeConfig,
    expected_phase1_hash: str | None = None,
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    _assert_frozen_phase1_calibration(cal, "PHASE2", expected_phase1_hash)
    salary = cal.frame["SAL"].astype(int).to_numpy()
    lineup_salary = salary[lineups].sum(axis=1)
    lineup_mean_proxy = cal.mean[lineups].sum(axis=1)
    lineup_p95_proxy = cal.p95[lineups].sum(axis=1)
    lineup_p99_proxy = cal.p99[lineups].sum(axis=1)
    contingency_count = (cal.p_expand[lineups] >= 0.20).sum(axis=1)
    vacancy_count = cal.vacancy_beneficiary[lineups].sum(axis=1)

    birth_score = (
        PHASE2_BIRTH_WEIGHTS["p99"] * lineup_p99_proxy
        + PHASE2_BIRTH_WEIGHTS["p95"] * lineup_p95_proxy
        + PHASE2_BIRTH_WEIGHTS["mean"] * lineup_mean_proxy
        + PHASE2_BIRTH_WEIGHTS["contingency"] * contingency_count
        + PHASE2_BIRTH_WEIGHTS["vacancy"] * vacancy_count
        + PHASE2_BIRTH_WEIGHTS["salary_release"] * (SALARY_MAX - lineup_salary)
    )

    keep: set[int] = set()
    global_keep = min(config.phase2_global_keep, len(lineups))
    keep.update(np.argpartition(birth_score, -global_keep)[-global_keep:].tolist())

    # Deep closure by contingency count, including a dedicated vacancy-beneficiary lane.
    for category in (0, 1, 2):
        idx = np.flatnonzero(np.minimum(contingency_count, 2) == category)
        k = min(config.phase2_family_keep, idx.size)
        if k:
            keep.update(idx[np.argpartition(birth_score[idx], -k)[-k:]].tolist())
    idx = np.flatnonzero(vacancy_count >= 1)
    k = min(config.phase2_family_keep, idx.size)
    if k:
        keep.update(idx[np.argpartition(birth_score[idx], -k)[-k:]].tolist())
    idx = np.flatnonzero((vacancy_count >= 1) & (contingency_count >= 2))
    k = min(config.phase2_family_keep, idx.size)
    if k:
        keep.update(idx[np.argpartition(birth_score[idx], -k)[-k:]].tolist())

    # Field-agnostic recall closure for a recent-only role bridge paired with at
    # least one additional ultra-low historical/recent role-rebound player. The
    # entire legal family is retained before Phase 2 freeze because scalar birth
    # scores systematically suppress these two-player role-dislocation paths.
    pre_recent_keep = set(keep)
    projected_minutes = cal.frame["MIN"].astype(float).to_numpy()
    role_rebound = cal.historical_rebound | cal.recent_role_rebound
    low_role_rebound_count = (
        (projected_minutes[lineups] < RECENT_ROLE_CURRENT_MINUTES_CEILING)
        & role_rebound[lineups]
    ).sum(axis=1)
    recent_role_count = cal.recent_role_rebound[lineups].sum(axis=1)
    recent_dual_mask = (recent_role_count >= 1) & (low_role_rebound_count >= 2)
    recent_dual_offsets = set(map(int, np.flatnonzero(recent_dual_mask)))
    keep.update(recent_dual_offsets)
    recent_dual_additions = len(recent_dual_offsets - pre_recent_keep)

    # Complete local closure for selected alpha pairs on ultra-low projected-MIN
    # paths. Pair selection is derived only from the frozen Phase 1 P99 surface,
    # baseline calibrated family density and field size. One clean sibling is
    # retained per exact structural cell; no post-lock result enters this path.
    baseline_selected = np.asarray(sorted(keep), dtype=np.int64)
    alpha_width = 0
    if config.field_size >= STRUCTURAL_BIRTH_LARGE_FIELD_MIN:
        alpha_width = min(
            len(cal.frame),
            max(
                1,
                math.ceil(
                    math.log2(max(2, int(config.field_size)))
                    * ALPHA_PAIR_WIDTH_LOG2_MULTIPLIER
                ),
            ),
        )
    alpha_anchors = np.argsort(-cal.p99, kind="stable")[:alpha_width]
    alpha_mask = np.zeros(len(cal.frame), dtype=bool)
    alpha_mask[alpha_anchors] = True
    pair_code_blocks: list[np.ndarray] = []
    baseline_rows = lineups[baseline_selected]
    player_count = len(cal.frame)
    if alpha_width:
        for left_column in range(5):
            for right_column in range(left_column + 1, 6):
                left = np.minimum(
                    baseline_rows[:, left_column],
                    baseline_rows[:, right_column],
                ).astype(np.int64, copy=False)
                right = np.maximum(
                    baseline_rows[:, left_column],
                    baseline_rows[:, right_column],
                ).astype(np.int64, copy=False)
                eligible = alpha_mask[left] | alpha_mask[right]
                pair_code_blocks.append(
                    left[eligible] * player_count + right[eligible]
                )
    selected_alpha_pairs: list[tuple[int, int]] = []
    if pair_code_blocks:
        pair_codes, pair_counts = np.unique(
            np.concatenate(pair_code_blocks),
            return_counts=True,
        )
        density_mask = pair_counts >= ALPHA_PAIR_MIN_DENSITY
        pair_codes = pair_codes[density_mask]
        pair_counts = pair_counts[density_mask]
        pair_left = pair_codes // player_count
        pair_right = pair_codes % player_count
        pair_p99 = (
            cal.p99[pair_left] + cal.p99[pair_right]
        ) / 2.0
        pair_order = np.lexsort(
            (pair_codes, -pair_p99, -pair_counts)
        )
        pair_target = max(
            1,
            math.ceil(
                math.log2(max(2, int(config.field_size)))
                * ALPHA_PAIR_TARGET_LOG2_MULTIPLIER
            ),
        )
        selected_alpha_pairs = [
            (int(pair_left[position]), int(pair_right[position]))
            for position in pair_order[:pair_target]
        ]

    minutes = cal.frame["MIN"].astype(float).to_numpy()
    salary_rank = np.empty(player_count, dtype=np.float64)
    salary_order = np.argsort(salary, kind="stable")
    salary_rank[salary_order] = np.arange(player_count, dtype=np.float64)
    p99_rank = np.empty(player_count, dtype=np.float64)
    p99_order = np.argsort(cal.p99, kind="stable")
    p99_rank[p99_order] = np.arange(player_count, dtype=np.float64)
    if player_count > 1:
        salary_rank /= player_count - 1
        p99_rank /= player_count - 1
    premium = (salary_rank >= 0.75) | (
        (p99_rank >= 0.75) & (salary_rank >= 0.50)
    )
    cheap = salary_rank <= 0.35
    starter = minutes >= 24.0
    low_count = (minutes[lineups] < 6.0).sum(axis=1)
    mid_count = (
        (minutes[lineups] >= 6.0) & (minutes[lineups] < 18.0)
    ).sum(axis=1)
    upper_count = (
        (minutes[lineups] >= 18.0) & (minutes[lineups] < 24.0)
    ).sum(axis=1)
    field_log_bound = max(
        1,
        math.ceil(math.log2(max(2, int(config.field_size)))),
    )
    salary_edges = np.unique(
        np.asarray(
            [
                100 * max(1, math.ceil(field_log_bound / 4)),
                100 * max(1, math.ceil(field_log_bound / 2)),
                100 * field_log_bound,
                200 * field_log_bound,
            ],
            dtype=np.int64,
        )
    )
    structural_offsets: set[int] = set()
    structural_scan = 0
    structural_cells = 0
    unique_games = np.unique(cal.game_codes)
    unique_teams = np.unique(cal.team_codes)
    for left, right in selected_alpha_pairs:
        local_offsets = np.flatnonzero(
            np.any(lineups == left, axis=1)
            & np.any(lineups == right, axis=1)
            & (low_count > 0)
        )
        structural_scan += len(local_offsets)
        if not len(local_offsets):
            continue
        local_rows = lineups[local_offsets]
        signature = np.column_stack(
            (
                np.searchsorted(
                    salary_edges,
                    SALARY_MAX - lineup_salary[local_offsets],
                    side="left",
                ),
                premium[local_rows].sum(axis=1),
                cheap[local_rows].sum(axis=1),
                starter[local_rows].sum(axis=1),
                cal.is_guard[local_rows].sum(axis=1),
                *(
                    (cal.game_codes[local_rows] == game).sum(axis=1)
                    for game in unique_games
                ),
                *(
                    (cal.team_codes[local_rows] == team).sum(axis=1)
                    for team in unique_teams
                ),
                low_count[local_offsets],
                mid_count[local_offsets],
                upper_count[local_offsets],
            )
        ).astype(np.int16, copy=False)
        _, cell_inverse = np.unique(
            signature,
            axis=0,
            return_inverse=True,
        )
        structural_cells += int(cell_inverse.max()) + 1
        local_order = np.lexsort(
            (
                local_offsets,
                -birth_score[local_offsets],
                cell_inverse,
            )
        )
        ordered_cells = cell_inverse[local_order]
        cell_starts = np.flatnonzero(
            np.r_[True, ordered_cells[1:] != ordered_cells[:-1]]
        )
        structural_offsets.update(
            map(int, local_offsets[local_order[cell_starts]])
        )
    keep.update(structural_offsets)

    # Medium-field Phase-2 recall for high-rotation salary-complement paths.
    # This is intentionally disjoint from the 3,000+ alpha-pair low-MIN closure.
    # Pair identities are selected anonymously from the frozen Phase-1 structural
    # value cells; no post-lock score, player name, or realized lineup enters here.
    pre_medium_keep = set(keep)
    medium_pair_registry: list[tuple[int, int]] = []
    medium_structural_offsets: set[int] = set()
    medium_structural_scan = 0
    medium_structural_cells = 0
    if MEDIUM_FIELD_PHASE2_RECALL_MIN <= config.field_size < STRUCTURAL_BIRTH_LARGE_FIELD_MIN:
        structural_players = np.flatnonzero(cal.structural_value_geometry)
        medium_salary_band = np.searchsorted(
            np.asarray(STRUCTURAL_VALUE_SALARY_EDGES, dtype=np.int32),
            salary,
            side="right",
        )
        medium_opportunity_band = np.searchsorted(
            np.asarray(STRUCTURAL_VALUE_OPPORTUNITY_EDGES, dtype=np.float32),
            minutes,
            side="right",
        )
        structural_cells_by_pair: dict[tuple[tuple[int, int, int], tuple[int, int, int]], tuple[float, int, int, int]] = {}
        for left_position, left in enumerate(structural_players[:-1]):
            for right in structural_players[left_position + 1:]:
                left = int(left)
                right = int(right)
                if cal.is_guard[left] == cal.is_guard[right]:
                    continue
                if {int(medium_salary_band[left]), int(medium_salary_band[right])} != {0, 1}:
                    continue
                left_opp = int(medium_opportunity_band[left])
                right_opp = int(medium_opportunity_band[right])
                if left_opp <= 0 or right_opp <= 0:
                    continue
                if abs(left_opp - right_opp) > MEDIUM_FIELD_OPPORTUNITY_BAND_MAX_GAP:
                    continue
                left_cell = (
                    int(cal.is_guard[left]),
                    int(medium_salary_band[left]),
                    left_opp,
                )
                right_cell = (
                    int(cal.is_guard[right]),
                    int(medium_salary_band[right]),
                    right_opp,
                )
                pair_cell = tuple(sorted((left_cell, right_cell)))
                pair_code = min(left, right) * player_count + max(left, right)
                candidate = (
                    float(cal.p99[left] + cal.p99[right]),
                    -int(pair_code),
                    left,
                    right,
                )
                incumbent = structural_cells_by_pair.get(pair_cell)
                if incumbent is None or candidate > incumbent:
                    structural_cells_by_pair[pair_cell] = candidate
        medium_pair_registry = [
            (int(value[2]), int(value[3]))
            for _, value in sorted(structural_cells_by_pair.items())
        ]

        primary_anchors = np.argsort(-cal.p99, kind="stable")[:MEDIUM_FIELD_PRIMARY_ANCHOR_COUNT]
        primary_anchor_present = np.any(np.isin(lineups, primary_anchors), axis=1)
        all_rotation_active = cal.rotation_active[lineups].all(axis=1)
        lineup_minutes_sum = minutes[lineups].sum(axis=1)
        for left, right in medium_pair_registry:
            local_offsets = np.flatnonzero(
                all_rotation_active
                & primary_anchor_present
                & np.any(lineups == left, axis=1)
                & np.any(lineups == right, axis=1)
            )
            medium_structural_scan += len(local_offsets)
            if not len(local_offsets):
                continue
            local_rows = lineups[local_offsets]
            signature = np.column_stack(
                (
                    np.searchsorted(
                        salary_edges,
                        SALARY_MAX - lineup_salary[local_offsets],
                        side="left",
                    ),
                    cal.is_guard[local_rows].sum(axis=1),
                    *(
                        (cal.team_codes[local_rows] == team).sum(axis=1)
                        for team in unique_teams
                    ),
                )
            ).astype(np.int16, copy=False)
            _, cell_inverse = np.unique(signature, axis=0, return_inverse=True)
            medium_structural_cells += int(cell_inverse.max()) + 1
            local_order = np.lexsort(
                (
                    local_offsets,
                    -birth_score[local_offsets],
                    -lineup_minutes_sum[local_offsets],
                    cell_inverse,
                )
            )
            ordered_cells = cell_inverse[local_order]
            cell_starts = np.flatnonzero(
                np.r_[True, ordered_cells[1:] != ordered_cells[:-1]]
            )
            medium_structural_offsets.update(
                map(int, local_offsets[local_order[cell_starts]])
            )
        keep.update(medium_structural_offsets)

    # Large-field identity-blind Top-0.1 right-neighborhood recall. Unlike the
    # legacy alpha-pair path, this lane does not require an ultra-low projected-MIN
    # player. It retains rotation-stable, high-opportunity, concentrated structural
    # complements before Phase-2 freeze.
    pre_top001_rn_keep = set(keep)
    top001_rn_offsets: set[int] = set()
    top001_rn_scan = 0
    if config.field_size >= STRUCTURAL_BIRTH_LARGE_FIELD_MIN:
        all_rotation_active = cal.rotation_active[lineups].all(axis=1)
        lineup_minutes_sum = minutes[lineups].sum(axis=1)
        lineup_min_minutes = minutes[lineups].min(axis=1)
        lineup_structural_count = cal.structural_value_geometry[lineups].sum(axis=1)
        lineup_p99_sum = cal.p99[lineups].sum(axis=1)
        lineup_release = SALARY_MAX - lineup_salary
        sorted_games = np.sort(cal.game_codes[lineups], axis=1)
        games_used = 1 + (sorted_games[:, 1:] != sorted_games[:, :-1]).sum(axis=1)
        sorted_teams = np.sort(cal.team_codes[lineups], axis=1)
        teams_used = 1 + (sorted_teams[:, 1:] != sorted_teams[:, :-1]).sum(axis=1)
        max_game_count = np.ones(len(lineups), dtype=np.int16)
        current_game_count = np.ones(len(lineups), dtype=np.int16)
        for position in range(1, lineups.shape[1]):
            current_game_count = np.where(
                sorted_games[:, position] == sorted_games[:, position - 1],
                current_game_count + 1,
                1,
            )
            max_game_count = np.maximum(max_game_count, current_game_count)
        low_minutes_count = (minutes[lineups] < TOP001_RN_LOW_MINUTES_CUTOFF).sum(axis=1)
        common_top001_shape = (
            (lineup_release <= TOP001_RN_RELEASE_MAX)
            & (games_used <= TOP001_RN_GAMES_USED_MAX)
            & (teams_used <= TOP001_RN_TEAMS_USED_MAX)
            & (max_game_count >= TOP001_RN_MAX_GAME_COUNT_MIN)
        )
        stable_top001_lane = (
            all_rotation_active
            & common_top001_shape
            & (lineup_minutes_sum >= TOP001_RN_STABLE_MINUTES_SUM_MIN)
            & (lineup_structural_count >= TOP001_RN_STRUCTURAL_COUNT_MIN)
            & (lineup_p99_sum >= TOP001_RN_STABLE_P99_SUM_MIN)
        )
        volatile_top001_lane = (
            common_top001_shape
            & (low_minutes_count <= TOP001_RN_LOW_MINUTES_MAX)
            & (lineup_minutes_sum >= TOP001_RN_VOLATILE_MINUTES_SUM_MIN)
            & (lineup_structural_count >= TOP001_RN_VOLATILE_STRUCTURAL_COUNT_MIN)
            & (lineup_p99_sum >= TOP001_RN_VOLATILE_P99_SUM_MIN)
        )
        lineup_premium_count = (salary[lineups] >= 9000).sum(axis=1)
        dislocation_top001_lane = (
            (low_role_rebound_count == 1)
            & (lineup_release <= TOP001_RN_RELEASE_MAX)
            & (lineup_minutes_sum >= TOP001_RN_DISLOCATION_MINUTES_SUM_MIN)
            & (lineup_structural_count >= TOP001_RN_DISLOCATION_STRUCTURAL_COUNT_MIN)
            & (lineup_p99_sum >= TOP001_RN_DISLOCATION_P99_SUM_MIN)
            & (games_used <= TOP001_RN_DISLOCATION_GAMES_USED_MAX)
            & (teams_used <= TOP001_RN_TEAMS_USED_MAX)
            & (max_game_count >= TOP001_RN_MAX_GAME_COUNT_MIN)
            & (lineup_premium_count >= TOP001_RN_DISLOCATION_PREMIUM_COUNT_MIN)
        )
        top001_rn_mask = stable_top001_lane | volatile_top001_lane | dislocation_top001_lane
        top001_rn_offsets = set(map(int, np.flatnonzero(top001_rn_mask)))
        top001_rn_scan = int(top001_rn_mask.sum())
        keep.update(top001_rn_offsets)

    # Calibration-first family preservation hard gate. Once a lineup is admitted by
    # the frozen Phase-1 birth logic or a calibrated family/sibling closure, it is a
    # Phase-2-born lineup. Resource controls may stream/chunk simulation work, but
    # they may not delete qualified lineups before the Phase-2 freeze.
    pre_cap_count = len(keep)
    selected_idx = np.array(sorted(keep), dtype=np.int64)
    metrics = {
        "lineup_salary": lineup_salary[selected_idx],
        "birth_score": birth_score[selected_idx],
        "contingency_count": contingency_count[selected_idx],
        "vacancy_count": vacancy_count[selected_idx],
        "lineup_mean_proxy": lineup_mean_proxy[selected_idx],
        "lineup_p95_proxy": lineup_p95_proxy[selected_idx],
        "lineup_p99_proxy": lineup_p99_proxy[selected_idx],
        "original_index": selected_idx,
        "baseline_phase2_rows": np.asarray([len(pre_recent_keep)]),
        "recent_role_dual_rows": np.asarray([len(recent_dual_offsets)]),
        "recent_role_dual_additions": np.asarray([recent_dual_additions]),
        "alpha_pair_targeted": np.asarray([len(selected_alpha_pairs)]),
        "alpha_pair_structural_scan": np.asarray([structural_scan]),
        "alpha_pair_structural_cells": np.asarray([structural_cells]),
        "alpha_pair_structural_rows": np.asarray([len(structural_offsets)]),
        "alpha_pair_structural_additions": np.asarray([
            len(structural_offsets - set(map(int, baseline_selected)))
        ]),
        "phase2_pre_cap_rows": np.asarray([pre_cap_count]),
        "phase2_sim_cap": np.asarray([config.phase2_sim_cap]),
        "phase2_cap_applied": np.asarray([0]),
        "phase2_lineup_reduction_prohibited": np.asarray([1]),
        "alpha_pair_registry_sha256": np.asarray([
            _stable_json_hash(selected_alpha_pairs)
        ]),
        "medium_structural_pair_registry_rows": np.asarray([len(medium_pair_registry)]),
        "medium_structural_pair_registry_sha256": np.asarray([_stable_json_hash(medium_pair_registry)]),
        "medium_structural_scan": np.asarray([medium_structural_scan]),
        "medium_structural_cells": np.asarray([medium_structural_cells]),
        "medium_structural_rows": np.asarray([len(medium_structural_offsets)]),
        "medium_structural_additions": np.asarray([len(medium_structural_offsets - pre_medium_keep)]),
        "top001_rn_scan": np.asarray([top001_rn_scan]),
        "top001_rn_rows": np.asarray([len(top001_rn_offsets)]),
        "top001_rn_additions": np.asarray([len(top001_rn_offsets - pre_top001_rn_keep)]),
    }
    return lineups[selected_idx], metrics


def _build_fake_field(
    legal_lineups: np.ndarray,
    cal: Calibration,
    config: RuntimeConfig,
) -> np.ndarray:
    target = max(1, int(round(config.field_size * 3.4)))
    target = min(target, len(legal_lineups))
    lineup_mean = cal.mean[legal_lineups].sum(axis=1)
    lineup_log_ownership = np.log(cal.ownership_proxy[legal_lineups]).sum(axis=1)
    contingency_count = (cal.p_expand[legal_lineups] >= 0.20).sum(axis=1)
    rng = np.random.default_rng(config.seed + 1000)
    utility = (
        FAKE_FIELD_WEIGHTS["mean"] * lineup_mean
        + FAKE_FIELD_WEIGHTS["log_ownership"] * lineup_log_ownership
        + FAKE_FIELD_WEIGHTS["contingency"] * contingency_count
        + FAKE_FIELD_WEIGHTS["gumbel"] * rng.gumbel(size=len(legal_lineups))
    )
    idx = np.argpartition(utility, -target)[-target:]
    return legal_lineups[idx]


def _wilson_interval(p: np.ndarray, n: int | np.ndarray, z: float = 1.96) -> tuple[np.ndarray, np.ndarray]:
    p = np.asarray(p, dtype=float)
    den = 1.0 + z * z / n
    center = (p + z * z / (2.0 * n)) / den
    half = z * np.sqrt(p * (1.0 - p) / n + z * z / (4.0 * n * n)) / den
    return center - half, center + half


def _stream_fake_field_thresholds(
    fake_field: np.ndarray,
    cal: Calibration,
    trial_start: int,
    trial_count: int,
    scaled_rank: int,
    scaled_top10_rank: int,
    trial_chunk: int = 512,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute exact per-trial field thresholds without materializing the full 3-D gather."""
    win_threshold = np.empty(trial_count, dtype=np.float32)
    top_threshold = np.empty(trial_count, dtype=np.float32)
    top10_threshold = np.empty(trial_count, dtype=np.float32)
    for offset in range(0, trial_count, trial_chunk):
        size = min(trial_chunk, trial_count - offset)
        left = trial_start + offset
        right = left + size
        scores = cal.sims[fake_field, left:right].sum(axis=1)
        win_threshold[offset:offset + size] = scores.max(axis=0)
        top_threshold[offset:offset + size] = np.partition(
            scores, -scaled_rank, axis=0
        )[-scaled_rank]
        top10_threshold[offset:offset + size] = np.partition(
            scores, -scaled_top10_rank, axis=0
        )[-scaled_top10_rank]
    return win_threshold, top_threshold, top10_threshold


def _support2_five_of_six_role_tail_closure(
    legal: np.ndarray,
    parent: np.ndarray,
    cal: Calibration,
    expected_phase1_hash: str | None = None,
    support_threshold: int = 2,
) -> tuple[np.ndarray, dict[str, int | str]]:
    _assert_frozen_phase1_calibration(cal, "PHASE2_SUPPORT2_ROLE_TAIL_CLOSURE", expected_phase1_hash)
    if len(parent) == 0 or len(legal) == 0:
        return parent, {"PATCH_ID": RECOVERY_CLOSURE_PATCH_ID, "PARENT_ROWS": int(len(parent)), "ADDITIONS": 0, "FINAL_ROWS": int(len(parent))}
    base = max(256, len(cal.frame) + 1)
    powers = np.asarray([base**i for i in range(5)], dtype=np.int64)
    def core_codes(rows: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        sr = np.sort(np.asarray(rows, dtype=np.int64), axis=1)
        codes = np.empty((len(sr), 6), dtype=np.int64)
        for j in range(6):
            codes[:, j] = (np.delete(sr, j, axis=1) * powers).sum(axis=1)
        return sr, codes
    _, parent_codes = core_codes(parent)
    support_codes, support_counts = np.unique(parent_codes.ravel(), return_counts=True)
    supported = support_codes[support_counts >= int(support_threshold)]
    if supported.size == 0:
        return parent, {"PATCH_ID": RECOVERY_CLOSURE_PATCH_ID, "PARENT_ROWS": int(len(parent)), "SUPPORTED_5_CORES": 0, "ADDITIONS": 0, "FINAL_ROWS": int(len(parent))}
    sal = cal.frame["SAL"].astype(float).to_numpy()
    mins = cal.frame["MIN"].fillna(0).astype(float).to_numpy()
    role_tail = (sal <= 3500.0) & (mins >= 6.0) & (mins < 15.0) & cal.rotation_active & (~cal.stale_role_suppressed)
    selected_blocks: list[np.ndarray] = []
    for start in range(0, len(legal), 250_000):
        block = legal[start:start+250_000]
        sr, codes = core_codes(block)
        pos = np.searchsorted(supported, codes)
        clipped = np.minimum(pos, len(supported)-1)
        matched = (pos < len(supported)) & (supported[clipped] == codes)
        keep = np.any(matched & role_tail[sr], axis=1)
        if np.any(keep):
            selected_blocks.append(block[keep])
    if selected_blocks:
        merged = np.vstack((parent, *selected_blocks))
        merged = np.unique(np.sort(merged, axis=1), axis=0)
    else:
        merged = np.unique(np.sort(parent, axis=1), axis=0)
    meta = {
        "PATCH_ID": RECOVERY_CLOSURE_PATCH_ID,
        "SUPPORT_THRESHOLD": int(support_threshold),
        "SUPPORTED_5_CORES": int(len(supported)),
        "ROLE_TAIL_PLAYERS": int(role_tail.sum()),
        "PARENT_ROWS": int(len(parent)),
        "ADDITIONS": int(len(merged) - len(parent)),
        "FINAL_ROWS": int(len(merged)),
    }
    return merged.astype(np.int32, copy=False), meta


def _right_tail_cvar99(scores: np.ndarray, p99_threshold: np.ndarray | None = None) -> np.ndarray:
    """Empirical CVaR99 using the already-computed P99 threshold when available."""
    scores = np.asarray(scores, dtype=np.float32)
    if scores.ndim != 2 or scores.shape[1] <= 0:
        raise ValueError("RUN_INVALID:WNBA_CVAR99_REQUIRES_2D_TRIAL_MATRIX")
    threshold = np.asarray(
        np.quantile(scores, 0.99, axis=1) if p99_threshold is None else p99_threshold,
        dtype=np.float32,
    )
    mask = scores >= threshold[:, None]
    counts = np.maximum(mask.sum(axis=1), 1)
    return ((scores * mask).sum(axis=1) / counts).astype(np.float32, copy=False)


def simulate_phase3(
    candidates: np.ndarray,
    legal_lineups: np.ndarray,
    cal: Calibration,
    config: RuntimeConfig,
    expected_phase1_hash: str | None = None,
) -> dict[str, np.ndarray | int]:
    _assert_frozen_phase1_calibration(cal, "PHASE3", expected_phase1_hash)
    fake_field = _build_fake_field(legal_lineups, cal, config)
    base_trials = min(config.base_trials, cal.sims.shape[1])
    # Exact Top-0.1% crown definition inside the simulated field. The legacy
    # Rank-1 scaling formula measured an ultra-thin ~Top-0.025% surface on
    # large fields and suppressed legitimate trophy-zone specialists.
    scaled_rank = max(1, int(math.ceil(0.001 * len(fake_field))))
    scaled_rank = min(scaled_rank, len(fake_field))
    scaled_top10_rank = max(1, int(round(10 * len(fake_field) / max(config.field_size, 1))))
    scaled_top10_rank = min(scaled_top10_rank, len(fake_field))
    fake_win_threshold, fake_top_threshold, fake_top10_threshold = _stream_fake_field_thresholds(
        fake_field,
        cal,
        0,
        base_trials,
        scaled_rank,
        scaled_top10_rank,
    )

    n = len(candidates)
    mean = np.empty(n, dtype=np.float32)
    p95 = np.empty(n, dtype=np.float32)
    p99 = np.empty(n, dtype=np.float32)
    cvar99 = np.empty(n, dtype=np.float32)
    win = np.empty(n, dtype=np.float32)
    top01 = np.empty(n, dtype=np.float32)
    top10 = np.empty(n, dtype=np.float32)
    batch = 128
    for start in range(0, n, batch):
        block = candidates[start:start + batch]
        scores = cal.sims[block, :base_trials].sum(axis=1)
        size = len(block)
        mean[start:start + size] = scores.mean(axis=1)
        p95[start:start + size] = np.quantile(scores, 0.95, axis=1)
        p99_block = np.quantile(scores, 0.99, axis=1)
        p99[start:start + size] = p99_block
        cvar99[start:start + size] = _right_tail_cvar99(scores, p99_block)
        win[start:start + size] = (scores > fake_win_threshold).mean(axis=1)
        top01[start:start + size] = (scores > fake_top_threshold).mean(axis=1)
        top10[start:start + size] = (scores > fake_top10_threshold).mean(axis=1)

    # Adaptive bubble: all lineups whose confidence intervals overlap the handoff boundary
    # receive the remaining player-trial matrix. Unresolved lineups pass forward.
    handoff_target = min(max(384, config.field_size), n)
    boundary_value = np.partition(top01, -handoff_target)[-handoff_target]
    lower, upper = _wilson_interval(top01, base_trials)
    bubble = np.flatnonzero((lower <= boundary_value) & (upper >= boundary_value))
    bubble_pre_cap = int(bubble.size)
    if bubble.size > config.adaptive_bubble_max:
        distance = np.abs(top01[bubble] - boundary_value)
        keep_n = int(config.adaptive_bubble_max)
        bubble = bubble[np.argpartition(distance, keep_n - 1)[:keep_n]]
    extra_trials = min(config.extra_trials, cal.sims.shape[1] - base_trials)
    trials_per_lineup = np.full(n, base_trials, dtype=np.int32)
    extra_used_total = 0
    if extra_trials > 0 and bubble.size:
        trials_per_lineup[bubble] += extra_trials
        fake_win_extra, fake_top_extra, fake_top10_extra = _stream_fake_field_thresholds(
            fake_field,
            cal,
            base_trials,
            extra_trials,
            scaled_rank,
            scaled_top10_rank,
        )
        for start in range(0, len(bubble), batch):
            idx = bubble[start:start + batch]
            scores = cal.sims[candidates[idx], base_trials:base_trials + extra_trials].sum(axis=1)
            extra_win = (scores > fake_win_extra).sum(axis=1)
            extra_top = (scores > fake_top_extra).sum(axis=1)
            extra_top10 = (scores > fake_top10_extra).sum(axis=1)
            win[idx] = (win[idx] * base_trials + extra_win) / (base_trials + extra_trials)
            top01[idx] = (top01[idx] * base_trials + extra_top) / (base_trials + extra_trials)
            top10[idx] = (top10[idx] * base_trials + extra_top10) / (base_trials + extra_trials)
            # Tail metrics are recomputed on the combined samples only for bubble lineups.
            base_scores = cal.sims[candidates[idx], :base_trials].sum(axis=1)
            combined = np.concatenate((base_scores, scores), axis=1)
            mean[idx] = combined.mean(axis=1)
            p95[idx] = np.quantile(combined, 0.95, axis=1)
            p99_combined = np.quantile(combined, 0.99, axis=1)
            p99[idx] = p99_combined
            cvar99[idx] = _right_tail_cvar99(combined, p99_combined)
            extra_used_total += len(idx) * extra_trials

    win_posterior = _beta_posterior_mean_rate(win, trials_per_lineup, 1.0 / max(len(fake_field), 1))
    top01_posterior = _beta_posterior_mean_rate(top01, trials_per_lineup, 0.001)
    return {
        "mean": mean,
        "p95": p95,
        "p99": p99,
        "cvar99": cvar99,
        "win_rate": win,
        "win_posterior": win_posterior,
        "top01_rate": top01,
        "top01_posterior": top01_posterior,
        "top10_rate": top10,
        "fake_field_size": len(fake_field),
        "base_trials": base_trials,
        "bubble_indices": bubble,
        "bubble_pre_cap": bubble_pre_cap,
        "adaptive_bubble_max": int(config.adaptive_bubble_max),
        "extra_trials_per_bubble": extra_trials,
        "trials_per_lineup": trials_per_lineup,
        "bubble_extra_trials_total": extra_used_total,
        "handoff_target": handoff_target,
    }


def _resimulate_selector_review_to_min_trials(
    sim: dict[str, np.ndarray | int],
    candidates: np.ndarray,
    legal_lineups: np.ndarray,
    cal: Calibration,
    config: RuntimeConfig,
    review_indices: np.ndarray,
    min_trials: int = WNBA_CLASSIC_SELECTOR_REVIEW_MIN_TRIALS,
) -> dict[str, np.ndarray | int]:
    """Raise final-selector review candidates to a dense common-world sample floor.

    This preserves a fast coarse scan over the full Phase-2 universe while preventing
    sparse 2,500-trial ticks from deciding the terminal shortlist or board.
    """
    idx = np.unique(np.asarray(review_indices, dtype=int))
    if idx.size == 0:
        return sim
    target = min(int(min_trials), int(cal.sims.shape[1]))
    trials = np.asarray(sim["trials_per_lineup"], dtype=np.int32)
    need = idx[trials[idx] < target]
    if need.size == 0:
        return sim
    fake_field = _build_fake_field(legal_lineups, cal, config)
    scaled_rank = max(1, int(math.ceil(0.001 * len(fake_field))))
    scaled_rank = min(scaled_rank, len(fake_field))
    scaled_top10_rank = max(1, int(round(10 * len(fake_field) / max(config.field_size, 1))))
    scaled_top10_rank = min(scaled_top10_rank, len(fake_field))
    win_thr, top_thr, top10_thr = _stream_fake_field_thresholds(
        fake_field, cal, 0, target, scaled_rank, scaled_top10_rank
    )
    mean = np.asarray(sim["mean"])
    p95 = np.asarray(sim["p95"])
    p99 = np.asarray(sim["p99"])
    cvar99 = np.asarray(sim["cvar99"])
    win = np.asarray(sim["win_rate"])
    top01 = np.asarray(sim["top01_rate"])
    top10 = np.asarray(sim["top10_rate"])
    batch = 128
    prior_total = int(trials[need].sum())
    for start in range(0, len(need), batch):
        ridx = need[start:start + batch]
        scores = cal.sims[candidates[ridx], :target].sum(axis=1)
        mean[ridx] = scores.mean(axis=1)
        p95[ridx] = np.quantile(scores, 0.95, axis=1)
        p99_review = np.quantile(scores, 0.99, axis=1)
        p99[ridx] = p99_review
        cvar99[ridx] = _right_tail_cvar99(scores, p99_review)
        win[ridx] = (scores > win_thr).mean(axis=1)
        top01[ridx] = (scores > top_thr).mean(axis=1)
        top10[ridx] = (scores > top10_thr).mean(axis=1)
    trials[need] = target
    sim["trials_per_lineup"] = trials
    sim["win_posterior"] = _beta_posterior_mean_rate(win, trials, 1.0 / max(len(fake_field), 1))
    sim["top01_posterior"] = _beta_posterior_mean_rate(top01, trials, 0.001)
    sim["selector_review_indices"] = np.unique(np.concatenate((np.asarray(sim.get("selector_review_indices", np.empty(0, dtype=int)), dtype=int), need)))
    sim["selector_review_min_trials"] = target
    sim["selector_review_extra_trials_total"] = int(sim.get("selector_review_extra_trials_total", 0)) + int(target * len(need) - prior_total)
    return sim


def _percentile_rank(values: np.ndarray) -> np.ndarray:
    """Average-tie percentile ranks; equal signals must not be separated by candidate index."""
    x = np.asarray(values, dtype=float)
    n = len(x)
    if n == 0:
        return np.empty(0, dtype=float)
    order = np.argsort(x, kind="mergesort")
    sx = x[order]
    ranks = np.empty(n, dtype=float)
    start = 0
    while start < n:
        end = start + 1
        while end < n and sx[end] == sx[start]:
            end += 1
        # pandas rank(method="average", pct=True): average 1-based rank divided by n.
        pct = ((start + 1.0) + end) * 0.5 / n
        ranks[order[start:end]] = pct
        start = end
    return ranks


def _beta_posterior_mean_rate(
    rate: np.ndarray,
    trials: np.ndarray,
    prior_mean: float,
    prior_strength: float = WNBA_CLASSIC_RARE_EVENT_PRIOR_STRENGTH,
) -> np.ndarray:
    rate = np.clip(np.asarray(rate, dtype=float), 0.0, 1.0)
    trials = np.maximum(np.asarray(trials, dtype=float), 1.0)
    strength = float(max(prior_strength, 0.0))
    alpha = float(np.clip(prior_mean, 0.0, 1.0)) * strength
    return (rate * trials + alpha) / (trials + strength)


def _rare_event_posterior_surfaces(
    sim: dict[str, np.ndarray | int],
    expected_dup: np.ndarray,
) -> dict[str, np.ndarray]:
    trials = np.asarray(sim["trials_per_lineup"], dtype=float)
    win = np.asarray(sim["win_rate"], dtype=float)
    top01 = np.asarray(sim["top01_rate"], dtype=float)
    p99 = np.asarray(sim["p99"], dtype=float)
    cvar99 = np.asarray(sim.get("cvar99", p99), dtype=float)
    fake_field_size = max(1, int(sim.get("fake_field_size", 1)))
    win_post = np.asarray(sim.get("win_posterior", _beta_posterior_mean_rate(win, trials, 1.0 / fake_field_size)), dtype=float)
    top01_post = np.asarray(sim.get("top01_posterior", _beta_posterior_mean_rate(top01, trials, 0.001)), dtype=float)
    uniqueness = -np.asarray(expected_dup, dtype=float)
    w = WNBA_CLASSIC_RARE_EVENT_SCORE_WEIGHTS
    score = (
        w["win_posterior"] * _percentile_rank(win_post)
        + w["top01_posterior"] * _percentile_rank(top01_post)
        + w["cvar99"] * _percentile_rank(cvar99)
        + w["p99"] * _percentile_rank(p99)
        + w["uniqueness"] * _percentile_rank(uniqueness)
    )
    return {
        "win_posterior": win_post,
        "top01_posterior": top01_post,
        "cvar99": cvar99,
        "rare_event_score": score,
    }


def _family_signature(row: np.ndarray, cal: Calibration) -> tuple:
    team_counts = tuple(sorted(np.bincount(cal.team_codes[row]).tolist(), reverse=True))
    team_counts = tuple(x for x in team_counts if x)
    game_count = len(np.unique(cal.game_codes[row]))
    contingency_count = int((cal.p_expand[row] >= 0.20).sum())
    vacancy_count = int(cal.vacancy_beneficiary[row].sum())
    salary = int(cal.frame["SAL"].astype(int).to_numpy()[row].sum())
    salary_bucket = (SALARY_MAX - salary) // 500
    return (team_counts, game_count, min(contingency_count, 2), min(vacancy_count, 1), salary_bucket)



def _certified_premium_guard_lane(
    rows: np.ndarray,
    cal: Calibration,
    row_total_salary: np.ndarray,
) -> np.ndarray:
    """Return the anonymous structural contingency lane mask used by selector closure."""
    player_salary = cal.frame["SAL"].astype(int).to_numpy()
    row_salary = player_salary[rows]
    row_premium = row_salary >= 9_000
    row_low_contingency = (cal.p_expand[rows] >= 0.20) & (row_salary < 7_000)
    row_contingency_count = (cal.p_expand[rows] >= 0.20).sum(axis=1)
    row_vacancy_count = cal.vacancy_beneficiary[rows].sum(axis=1)
    row_premium_count = row_premium.sum(axis=1)
    row_premium_guard_count = (row_premium & cal.is_guard[rows]).sum(axis=1)
    row_guard_count = cal.is_guard[rows].sum(axis=1)
    row_team_count = np.array([len(np.unique(cal.team_codes[row])) for row in rows])
    row_game_count = np.array([len(np.unique(cal.game_codes[row])) for row in rows])
    row_max_team = np.array([np.bincount(cal.team_codes[row]).max() for row in rows])
    row_separated = np.zeros(len(rows), dtype=bool)
    for local_i, row in enumerate(rows):
        low_value_teams = set(cal.team_codes[row[row_low_contingency[local_i]]].tolist())
        premium_teams = set(cal.team_codes[row[row_premium[local_i]]].tolist())
        row_separated[local_i] = bool(low_value_teams) and low_value_teams.isdisjoint(premium_teams)
    return (
        (row_vacancy_count >= 1)
        & (row_low_contingency.sum(axis=1) >= 2)
        & (row_contingency_count >= 3)
        & (row_premium_count >= 4)
        & (row_premium_guard_count == 2)
        & (row_guard_count == 3)
        & (row_total_salary >= 49_700)
        & (row_team_count >= 5)
        & (row_game_count >= 3)
        & (row_max_team <= 2)
        & row_separated
    )



def _rank_descending(values: np.ndarray) -> np.ndarray:
    """Stable one-based descending ranks."""
    order = np.argsort(-np.asarray(values, dtype=float), kind="mergesort")
    ranks = np.empty(len(order), dtype=np.int32)
    ranks[order] = np.arange(1, len(order) + 1, dtype=np.int32)
    return ranks


def _anonymous_lineup_ids(candidates: np.ndarray, cal: Calibration) -> np.ndarray:
    """Hash player-index tuples with the frozen player-identifier contract; no names leak."""
    prefix = cal.player_identifier_hash
    out = np.empty(len(candidates), dtype=object)
    for i, row in enumerate(candidates):
        payload = f"{prefix}:" + ",".join(str(int(x)) for x in np.sort(row))
        out[i] = hashlib.sha256(payload.encode()).hexdigest()[:20]
    return out


def _scenario_structure(
    candidates: np.ndarray,
    cal: Calibration,
    lineup_salary: np.ndarray,
) -> dict[str, np.ndarray]:
    """Anonymous structural route features for audit and shadow research only."""
    player_salary = cal.frame["SAL"].astype(int).to_numpy()
    row_salary = player_salary[candidates]
    row_guard = cal.is_guard[candidates]
    stars = row_salary >= 10_000
    elite = row_salary >= 11_000
    values = row_salary <= 6_000
    deep_values = row_salary < 5_000
    contingency = cal.p_expand[candidates] >= 0.20
    vacancy = cal.vacancy_beneficiary[candidates]
    rebound = (cal.historical_rebound | cal.recent_role_rebound)[candidates]
    qualified_bridge_mask = values & (contingency | vacancy | rebound)
    false_bridge_mask = values & ~qualified_bridge_mask

    star_count = stars.sum(axis=1).astype(np.int16)
    elite_count = elite.sum(axis=1).astype(np.int16)
    guard_count = row_guard.sum(axis=1).astype(np.int16)
    frontcourt_star_count = (stars & ~row_guard).sum(axis=1).astype(np.int16)
    value_count = values.sum(axis=1).astype(np.int16)
    deep_value_count = deep_values.sum(axis=1).astype(np.int16)
    contingency_count = contingency.sum(axis=1).astype(np.int16)
    vacancy_count = vacancy.sum(axis=1).astype(np.int16)
    rebound_count = rebound.sum(axis=1).astype(np.int16)
    qualified_bridge_count = qualified_bridge_mask.sum(axis=1).astype(np.int16)
    false_bridge_count = false_bridge_mask.sum(axis=1).astype(np.int16)
    scenario_lane = _certified_premium_guard_lane(candidates, cal, lineup_salary)
    dense_spine_bridge = (star_count >= 3) & (qualified_bridge_count >= 2) & (false_bridge_count == 0)

    cluster = np.array([
        (
            f"G{int(g)}_S{int(st)}_E{int(el)}_FS{int(fs)}_"
            f"V{int(v)}_D{int(d)}_QB{int(qb)}_FB{int(fb)}_"
            f"C{int(c)}_VAC{int(vc)}_R{int(r)}_LANE{int(lane)}"
        )
        for g, st, el, fs, v, d, qb, fb, c, vc, r, lane in zip(
            guard_count, star_count, elite_count, frontcourt_star_count,
            value_count, deep_value_count, qualified_bridge_count, false_bridge_count,
            contingency_count, vacancy_count, rebound_count, scenario_lane, strict=True,
        )
    ], dtype=object)
    return {
        "scenario_cluster": cluster,
        "scenario_lane_member": scenario_lane,
        "dense_spine_bridge": dense_spine_bridge,
        "star_count": star_count,
        "elite_count": elite_count,
        "guard_count": guard_count,
        "frontcourt_star_count": frontcourt_star_count,
        "value_count": value_count,
        "deep_value_count": deep_value_count,
        "contingency_count": contingency_count,
        "vacancy_count": vacancy_count,
        "historical_rebound_count": rebound_count,
        "qualified_bridge_count": qualified_bridge_count,
        "false_bridge_count": false_bridge_count,
    }



def _bankroll_reserve_lane_scores(
    candidates: np.ndarray,
    cal: Calibration,
    lineup_salary: np.ndarray,
    expected_dup: np.ndarray,
) -> dict[str, np.ndarray]:
    """Pre-lock-only orthogonal reserve surfaces for bankroll diversification."""
    frame = cal.frame
    row_reb = pd.to_numeric(frame["REB"], errors="coerce").fillna(0.0).to_numpy(float)[candidates].sum(axis=1)
    row_salary = frame["SAL"].astype(int).to_numpy()[candidates]
    row_frontcourt_star = ((row_salary >= 10_000) & (~cal.is_guard[candidates])).sum(axis=1).astype(float)
    starter = frame["LINEUP"].astype(str).str.upper().isin(["YES", "Y", "START", "STARTER"]).to_numpy(bool)
    row_starters = starter[candidates].sum(axis=1).astype(float)
    tm_score = pd.to_numeric(frame["TM Score"], errors="coerce").fillna(0.0).to_numpy(float)
    spread = pd.to_numeric(frame["SPRD"], errors="coerce").fillna(0.0).to_numpy(float)
    pace = pd.to_numeric(frame["PACE"], errors="coerce").fillna(0.0).to_numpy(float)
    row_tm_score = tm_score[candidates].sum(axis=1)
    row_abs_spread = np.abs(spread[candidates]).mean(axis=1)
    row_pace = pace[candidates].mean(axis=1)

    salary_pct = _percentile_rank(lineup_salary.astype(float))
    reb_pct = _percentile_rank(row_reb)
    frontcourt_pct = _percentile_rank(row_frontcourt_star)
    dup_good_pct = _percentile_rank(-expected_dup)
    starter_pct = _percentile_rank(row_starters)
    spread_good_pct = _percentile_rank(-row_abs_spread)
    team_score_pct = _percentile_rank(row_tm_score)
    pace_pct = _percentile_rank(row_pace)
    return {
        "salary_rebound": 0.25 * (salary_pct + reb_pct + frontcourt_pct + dup_good_pct),
        "game_starter": 0.25 * (starter_pct + spread_good_pct + team_score_pct + pace_pct),
    }


def _bankroll_projection_capacity_score(
    candidates: np.ndarray,
    cal: Calibration,
    mean: np.ndarray,
) -> np.ndarray:
    """Pre-lock projection/minute-capacity surface validated across raw WNBA holdouts."""
    minutes = pd.to_numeric(cal.frame["MIN"], errors="coerce").fillna(0.0).to_numpy(float)[candidates]
    row_projection = cal.base_projection[candidates].sum(axis=1)
    row_minutes_sum = minutes.sum(axis=1)
    row_minutes_min = minutes.min(axis=1)
    return (
        0.35 * _percentile_rank(row_projection)
        + 0.25 * _percentile_rank(np.asarray(mean, dtype=float))
        + 0.20 * _percentile_rank(row_minutes_sum)
        + 0.20 * _percentile_rank(row_minutes_min)
    )


def _hard_portfolio_valid(
    chosen: Sequence[int],
    candidates: np.ndarray,
    cal: Calibration,
    config: RuntimeConfig,
) -> bool:
    if len(chosen) == 0:
        return True
    rows = candidates[np.asarray(chosen, dtype=int)]
    for player in np.unique(rows):
        if int((rows == player).any(axis=1).sum()) > int(config.player_exposure_cap):
            return False
    families = [_family_signature(row, cal) for row in rows]
    for family in set(families):
        if families.count(family) > int(config.family_cap):
            return False
    return True


def _append_hard_safe_candidate(
    chosen: list[int],
    candidate_i: int,
    candidates: np.ndarray,
    cal: Calibration,
    config: RuntimeConfig,
) -> bool:
    if int(candidate_i) in chosen:
        return False
    trial = chosen + [int(candidate_i)]
    if not _hard_portfolio_valid(trial, candidates, cal, config):
        return False
    chosen.append(int(candidate_i))
    return True


def _apply_bankroll_reserve_slots(
    base_ordered: np.ndarray,
    candidates: np.ndarray,
    cal: Calibration,
    config: RuntimeConfig,
    salary: np.ndarray,
    expected_dup: np.ndarray,
    score: np.ndarray,
) -> tuple[np.ndarray, dict[str, object]]:
    """Preserve the primary top eight and replace only the final two slots with hard-safe reserves."""
    target = min(int(config.board_size), len(candidates))
    if target < 10 or int(config.field_size) < BANKROLL_RESERVE_FIELD_MIN:
        return np.asarray(base_ordered[:target], dtype=int), {
            "reserve_applied": False, "reserve_slots": 0, "reserve_candidate_indices": [],
        }
    reserve_slots = min(BANKROLL_RESERVE_SLOTS, target)
    keep = target - reserve_slots
    chosen = [int(x) for x in np.asarray(base_ordered[:keep], dtype=int)]
    surfaces = _bankroll_reserve_lane_scores(candidates, cal, salary, expected_dup)
    reserve_indices: list[int] = []
    for lane in ("salary_rebound", "game_starter"):
        lane_score = np.asarray(surfaces[lane], dtype=float)
        scan = min(BANKROLL_RESERVE_LANE_SCAN, len(lane_score))
        if scan <= 0:
            continue
        top = np.argpartition(lane_score, -scan)[-scan:]
        top = top[np.argsort(lane_score[top], kind="mergesort")[::-1]]
        for candidate_i in top:
            if _append_hard_safe_candidate(chosen, int(candidate_i), candidates, cal, config):
                reserve_indices.append(int(candidate_i))
                break
    # If a lane cannot fill under hard constraints, restore the strongest original/global rows.
    for candidate_i in np.asarray(base_ordered[keep:], dtype=int):
        if len(chosen) >= target:
            break
        _append_hard_safe_candidate(chosen, int(candidate_i), candidates, cal, config)
    if len(chosen) < target:
        for candidate_i in np.argsort(-score, kind="mergesort"):
            if len(chosen) >= target:
                break
            _append_hard_safe_candidate(chosen, int(candidate_i), candidates, cal, config)
    if len(chosen) != target or not _hard_portfolio_valid(chosen, candidates, cal, config):
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:WNBA_CLASSIC_BANKROLL_RESERVE_HARD_CAP_FAILURE")
    return np.asarray(chosen, dtype=int), {
        "reserve_applied": bool(reserve_indices),
        "reserve_slots": int(len(reserve_indices)),
        "reserve_candidate_indices": reserve_indices,
    }


def write_selector_full_order_ledger(
    *,
    candidates: np.ndarray,
    sim: dict[str, np.ndarray | int],
    cal: Calibration,
    config: RuntimeConfig,
    board_metrics: dict[str, np.ndarray],
    output_path: str | Path,
    execution_id: str | int | None = None,
    run_artifact_id: str | None = None,
) -> dict[str, object]:
    """Write one anonymous audit row for every frozen handoff lineup."""
    required = (
        "_candidate_score", "_candidate_salary", "_candidate_expected_dup",
        "_eligible_mask", "_shortlist_mask", "_selected_candidate_indices",
    )
    if not all(k in board_metrics for k in required):
        pd.DataFrame().to_csv(output_path, index=False)
        return {
            "path": str(output_path), "rows": 0, "sha256": _sha256_file(output_path),
            "schema": FULL_ORDER_LEDGER_SCHEMA_VERSION, "status": "EMPTY_SELECTOR_FAILURE",
        }

    n = len(candidates)
    score = np.asarray(board_metrics["_candidate_score"], dtype=float)
    salary = np.asarray(board_metrics["_candidate_salary"], dtype=int)
    expected_dup = np.asarray(board_metrics["_candidate_expected_dup"], dtype=float)
    duplication_risk_shadow = np.asarray(board_metrics.get("_candidate_duplication_risk_shadow", np.full(n, np.nan)), dtype=float)
    eligible = np.asarray(board_metrics["_eligible_mask"], dtype=bool)
    shortlist = np.asarray(board_metrics["_shortlist_mask"], dtype=bool)
    selected_order = np.asarray(board_metrics["_selected_candidate_indices"], dtype=int)
    selected_mask = np.zeros(n, dtype=bool)
    selected_mask[selected_order] = True
    final_rank = np.zeros(n, dtype=np.int16)
    final_rank[selected_order] = np.arange(1, len(selected_order) + 1, dtype=np.int16)

    structure = _scenario_structure(candidates, cal, salary)
    global_rank = _rank_descending(score)
    tmp = pd.DataFrame({
        "cluster": structure["scenario_cluster"],
        "score": score,
        "candidate_index": np.arange(n, dtype=np.int32),
    })
    tmp.sort_values(["cluster", "score", "candidate_index"], ascending=[True, False, True], kind="mergesort", inplace=True)
    tmp["scenario_relative_rank"] = tmp.groupby("cluster", sort=False).cumcount() + 1
    scenario_relative_rank = np.empty(n, dtype=np.int32)
    scenario_relative_rank[tmp["candidate_index"].to_numpy()] = tmp["scenario_relative_rank"].to_numpy(np.int32)

    max_overlap = np.zeros(n, dtype=np.int8)
    for chosen_i in selected_order:
        row = candidates[int(chosen_i)]
        overlap = np.isin(candidates, row).sum(axis=1).astype(np.int8)
        max_overlap = np.maximum(max_overlap, overlap)

    rejection = np.full(n, "BANKROLL_COMPOSITE_PORTFOLIO_NOT_SELECTED", dtype=object)
    rejection[~shortlist] = "BANKROLL_COMPOSITE_SHORTLIST_NOT_RETAINED"
    rejection[selected_mask] = np.array(
        [f"SELECTED_FINAL_BOARD_RANK_{int(r)}" for r in final_rank[selected_mask]], dtype=object
    )

    selection_vector = np.array([
        json.dumps({
            "strict_gate_advisory": bool(eligible[i]),
            "milp_shortlist": bool(shortlist[i]),
            "scenario_lane_member": bool(structure["scenario_lane_member"][i]),
            "dense_spine_bridge": bool(structure["dense_spine_bridge"][i]),
            "star_count": int(structure["star_count"][i]),
            "frontcourt_star_count": int(structure["frontcourt_star_count"][i]),
            "qualified_bridge_count": int(structure["qualified_bridge_count"][i]),
            "false_bridge_count": int(structure["false_bridge_count"][i]),
        }, sort_keys=True, separators=(",", ":"))
        for i in range(n)
    ], dtype=object)
    portfolio_penalties = np.array([
        json.dumps({
            "expected_dup": round(float(expected_dup[i]), 12),
            "max_player_overlap_with_final_board": int(max_overlap[i]),
            "player_exposure_cap": int(config.player_exposure_cap),
            "family_cap": int(config.family_cap),
        }, sort_keys=True, separators=(",", ":"))
        for i in range(n)
    ], dtype=object)

    trials = np.asarray(sim["trials_per_lineup"], dtype=int)
    df = pd.DataFrame({
        "RUN_ARTIFACT_ID": str(run_artifact_id or ""),
        "EXECUTION_ID": str(execution_id or ""),
        "LINEUP_ID": _anonymous_lineup_ids(candidates, cal),
        "CANDIDATE_INDEX": np.arange(n, dtype=np.int32),
        "GLOBAL_PHASE3_RANK": global_rank,
        "SCENARIO_CLUSTER": structure["scenario_cluster"],
        "SCENARIO_RELATIVE_RANK": scenario_relative_rank,
        "SELECTION_VECTOR": selection_vector,
        "PORTFOLIO_PENALTIES": portfolio_penalties,
        "FINAL_RANK": final_rank,
        "SELECTED": selected_mask,
        "REJECTED": ~selected_mask,
        "REJECTION_REASON": rejection,
        "MC_TRIALS": trials,
        "MC_MEAN": np.asarray(sim["mean"], dtype=float),
        "MC_P95": np.asarray(sim["p95"], dtype=float),
        "MC_P99": np.asarray(sim["p99"], dtype=float),
        "MC_CVAR99": np.asarray(sim.get("cvar99", sim["p99"]), dtype=float),
        "MC_WIN_RATE": np.asarray(sim["win_rate"], dtype=float),
        "MC_WIN_POSTERIOR": np.asarray(sim.get("win_posterior", sim["win_rate"]), dtype=float),
        "MC_TOP_0_1_RATE": np.asarray(sim["top01_rate"], dtype=float),
        "MC_TOP_0_1_POSTERIOR": np.asarray(sim.get("top01_posterior", sim["top01_rate"]), dtype=float),
        "MC_TOP_10_RATE": np.asarray(sim["top10_rate"], dtype=float),
        "EXPECTED_DUP": expected_dup,
        "DUPLICATION_RISK_SHADOW": duplication_risk_shadow,
        "LINEUP_SALARY": salary,
        "SELECTOR_SCORE": score,
        "SCENARIO_LANE_MEMBER": structure["scenario_lane_member"],
        "DENSE_SPINE_BRIDGE": structure["dense_spine_bridge"],
        "STAR_COUNT": structure["star_count"],
        "FRONTCOURT_STAR_COUNT": structure["frontcourt_star_count"],
        "QUALIFIED_BRIDGE_COUNT": structure["qualified_bridge_count"],
        "FALSE_BRIDGE_COUNT": structure["false_bridge_count"],
        "SHADOW_RANK1_ELIGIBLE": (
            selected_mask
            & structure["scenario_lane_member"]
            & structure["dense_spine_bridge"]
            & (structure["qualified_bridge_count"] >= 2)
            & (structure["false_bridge_count"] == 0)
        ),
    })
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output, index=False)
    return {
        "path": str(output),
        "rows": int(len(df)),
        "sha256": _sha256_file(output),
        "schema": FULL_ORDER_LEDGER_SCHEMA_VERSION,
        "selected_rows": int(selected_mask.sum()),
        "player_names_present": False,
        "team_names_present": False,
        "postlock_fields_present": False,
        "status": "PASS",
    }


def _normalize_identity_name(value: object) -> str:
    text = re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()
    return re.sub(r"\s+", " ", text)


def write_sealed_lineup_identity_map(
    *, candidates: np.ndarray, cal: Calibration, output_path: str | Path,
) -> dict[str, object]:
    """Write an isolated post-lock identity map. Forward selector imports are prohibited."""
    lineup_ids = _anonymous_lineup_ids(candidates, cal)
    player_names = cal.frame["PLAYER"].astype(str).to_numpy()
    rows = []
    for i, row in enumerate(candidates):
        names = sorted(_normalize_identity_name(player_names[int(x)]) for x in row)
        key = "|".join(names)
        rows.append({
            "LINEUP_ID": str(lineup_ids[i]),
            "CANDIDATE_INDEX": int(i),
            "PLAYER_SET_KEY": key,
            "PLAYER_SET_SHA256": hashlib.sha256(key.encode()).hexdigest(),
            "CALIBRATION_CONTRACT_HASH": cal.calibration_contract_hash,
            "POSTLOCK_ONLY": True,
            "FORWARD_SELECTOR_IMPORT_PROHIBITED": True,
        })
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)
    return {
        "path": str(output), "rows": len(rows), "sha256": _sha256_file(output),
        "schema": SEALED_IDENTITY_MAP_SCHEMA_VERSION,
        "postlock_only": True, "forward_selector_import_prohibited": True,
    }


def _overlaps_best_wilson(values: np.ndarray, trials: np.ndarray) -> np.ndarray:
    lower, upper = _wilson_interval(values, trials)
    best = int(np.argmax(values))
    return upper >= lower[best]


def _uncertainty_aware_scenario_lane_order(
    chosen: np.ndarray,
    candidates: np.ndarray,
    sim: dict[str, np.ndarray | int],
    cal: Calibration,
    salary: np.ndarray,
    expected_dup: np.ndarray,
    score: np.ndarray,
    config: RuntimeConfig,
) -> tuple[np.ndarray, dict[str, int]]:
    """Order the selected set without altering its composition.

    The global scalar order remains authoritative, but a certified contingency-family
    representative cannot be buried below the top 40% of a ten-line board. Within the
    certified lane, statistically overlapping Top-0.1 and win rates are treated as ties;
    salary release and duplication then identify the representative, with Top-10 secondary. No realized result,
    player name, or target lineup enters the ranker.
    """
    ordered = chosen[np.argsort(score[chosen], kind="mergesort")[::-1]]
    rows = candidates[chosen]
    lane_mask = _certified_premium_guard_lane(rows, cal, salary[chosen])
    lane_local = np.flatnonzero(lane_mask)
    if lane_local.size == 0:
        return ordered, {
            "scenario_lane_candidates": 0,
            "scenario_lane_priority_rank": 0,
            "scenario_lane_leader_candidate_index": -1,
        }

    trials = np.asarray(sim["trials_per_lineup"], dtype=float)[chosen]
    top10 = np.asarray(sim["top10_rate"], dtype=float)[chosen]
    top01 = np.asarray(sim["top01_rate"], dtype=float)[chosen]
    win = np.asarray(sim["win_rate"], dtype=float)[chosen]
    p99 = np.asarray(sim["p99"], dtype=float)[chosen]
    p95 = np.asarray(sim["p95"], dtype=float)[chosen]
    mean = np.asarray(sim["mean"], dtype=float)[chosen]

    lane_trials = trials[lane_local]
    top10_tied = _overlaps_best_wilson(top10[lane_local], lane_trials)
    top01_tied = _overlaps_best_wilson(top01[lane_local], lane_trials)
    win_tied = _overlaps_best_wilson(win[lane_local], lane_trials)

    lane_keys = []
    for j, local_i in enumerate(lane_local):
        candidate_i = int(chosen[local_i])
        lane_keys.append((
            int(top01_tied[j]),
            int(win_tied[j]),
            int(SALARY_MAX - salary[candidate_i]),
            -float(expected_dup[candidate_i]),
            int(top10_tied[j]),
            float(p99[local_i]),
            float(p95[local_i]),
            float(mean[local_i]),
            -candidate_i,
        ))
    leader_local = int(lane_local[max(range(len(lane_local)), key=lambda j: lane_keys[j])])
    leader_candidate = int(chosen[leader_local])
    current_position = int(np.flatnonzero(ordered == leader_candidate)[0])
    priority_rank = max(1, int(math.ceil(config.board_size * SCENARIO_LANE_PODIUM_FRACTION)))
    target_position = priority_rank - 1
    if current_position > target_position:
        ordered = np.delete(ordered, current_position)
        ordered = np.insert(ordered, target_position, leader_candidate)
    return ordered, {
        "scenario_lane_candidates": int(lane_local.size),
        "scenario_lane_priority_rank": int(priority_rank),
        "scenario_lane_leader_candidate_index": int(leader_candidate),
    }


def _medium_field_elite_cohort_structural_score(
    candidates: np.ndarray,
    cal: Calibration,
    config: RuntimeConfig,
) -> np.ndarray:
    """Result-blind structural trophy score learned with Top-25 holdout validation.

    Inputs are frozen pre-lock lineup features only. The lane is scoped to DK WNBA
    Classic medium fields and is additive to, not a replacement for, the native model lane.
    """
    n = len(candidates)
    if n == 0:
        return np.empty(0, dtype=float)
    salary_player = cal.frame["SAL"].astype(int).to_numpy()
    minutes = cal.frame["MIN"].fillna(0).astype(float).to_numpy()
    recent = cal.frame["MIN.1"].fillna(0).astype(float).to_numpy()
    lineup_text = cal.frame["LINEUP"].fillna("").astype(str).str.upper().str.strip()
    starter = lineup_text.isin({"YES", "Y", "START", "STARTER"}).to_numpy()
    role_gap = np.maximum(0.0, cal.role_ceiling_minutes - minutes)
    sum_base = cal.base_projection[candidates].sum(axis=1)
    sum_p_expand = cal.p_expand[candidates].sum(axis=1)
    sum_role_gap = role_gap[candidates].sum(axis=1)
    cheap_active = (
        starter & (salary_player <= 6000) & (minutes >= 18.0) & (recent >= 18.0)
        & ~cal.stale_role_suppressed
    )
    cheap_active_count = cheap_active[candidates].sum(axis=1)
    vac_ben_count = cal.vacancy_beneficiary[candidates].sum(axis=1)
    star_9k_count = (salary_player[candidates] >= 9000).sum(axis=1)
    teams_used = np.asarray([len(np.unique(cal.team_codes[row])) for row in candidates], dtype=float)
    x = np.column_stack((sum_base, sum_p_expand, sum_role_gap, cheap_active_count, vac_ben_count, star_9k_count, teams_used))
    z = (x - MEDIUM_FIELD_ELITE_COHORT_FEATURE_MEAN) / MEDIUM_FIELD_ELITE_COHORT_FEATURE_SCALE
    return MEDIUM_FIELD_ELITE_COHORT_INTERCEPT + z @ MEDIUM_FIELD_ELITE_COHORT_COEF


def _duplication_risk_shadow_features(candidates: np.ndarray, cal: Calibration) -> tuple[np.ndarray, np.ndarray]:
    """Identity-free pre-lock duplication-risk telemetry. Zero selector authority."""
    if len(candidates) == 0:
        return np.empty((0, len(_dup_risk_shadow.FEATURES)), dtype=float), np.empty(0, dtype=float)
    player_salary = cal.frame["SAL"].astype(int).to_numpy()
    player_minutes = cal.frame["MIN"].astype(float).to_numpy()
    own = np.clip(cal.ownership_proxy[candidates].astype(float), 1e-12, 1.0)
    own_gm = np.exp(np.log(own).mean(axis=1))
    own_max = own.max(axis=1)
    mean_sum = cal.mean[candidates].sum(axis=1).astype(float)
    p95_sum = cal.p95[candidates].sum(axis=1).astype(float)
    p99_sum = cal.p99[candidates].sum(axis=1).astype(float)
    p_expand_sum = cal.p_expand[candidates].sum(axis=1).astype(float)
    structural = cal.structural_value_geometry[candidates].sum(axis=1).astype(float)
    teams = np.sort(cal.team_codes[candidates], axis=1)
    games = np.sort(cal.game_codes[candidates], axis=1)
    teams_used = 1 + (teams[:, 1:] != teams[:, :-1]).sum(axis=1)
    games_used = 1 + (games[:, 1:] != games[:, :-1]).sum(axis=1)
    max_team = np.ones(len(candidates), dtype=np.int16)
    max_game = np.ones(len(candidates), dtype=np.int16)
    team_run = np.ones(len(candidates), dtype=np.int16)
    game_run = np.ones(len(candidates), dtype=np.int16)
    for pos in range(1, candidates.shape[1]):
        team_run = np.where(teams[:, pos] == teams[:, pos - 1], team_run + 1, 1)
        game_run = np.where(games[:, pos] == games[:, pos - 1], game_run + 1, 1)
        max_team = np.maximum(max_team, team_run)
        max_game = np.maximum(max_game, game_run)
    row_minutes = player_minutes[candidates]
    row_salary = player_salary[candidates].astype(float)
    low15 = (row_minutes < 15.0).sum(axis=1)
    low20 = (row_minutes < 20.0).sum(axis=1)
    cheap3500 = (row_salary <= 3500.0).sum(axis=1)
    cheap5000 = (row_salary <= 5000.0).sum(axis=1)
    premium9000 = (row_salary >= 9000.0).sum(axis=1)
    premium10000 = (row_salary >= 10000.0).sum(axis=1)
    salary_sum = np.maximum(row_salary.sum(axis=1), 1e-12)
    salary_top3_share = np.sort(row_salary, axis=1)[:, -3:].sum(axis=1) / salary_sum
    row_p99 = cal.p99[candidates].astype(float)
    row_mean = cal.mean[candidates].astype(float)
    p99_top3_share = np.sort(row_p99, axis=1)[:, -3:].sum(axis=1) / np.maximum(p99_sum, 1e-12)
    mean_top3_share = np.sort(row_mean, axis=1)[:, -3:].sum(axis=1) / np.maximum(mean_sum, 1e-12)
    x = np.column_stack((
        own_gm, own_max, mean_sum, p95_sum, p99_sum, p_expand_sum, structural,
        max_team, teams_used, max_game, games_used, low15, low20, cheap3500, cheap5000,
        premium9000, premium10000, salary_top3_share, p99_top3_share, mean_top3_share,
    )).astype(float)
    risk = _dup_risk_shadow.score_feature_matrix(x)
    if not np.isfinite(risk).all() or np.any((risk < 0.0) | (risk > 1.0)):
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:WNBA_DUPLICATION_RISK_SHADOW_NONFINITE")
    return x, risk


def select_board(
    candidates: np.ndarray,
    sim: dict[str, np.ndarray | int],
    cal: Calibration,
    config: RuntimeConfig,
    expected_phase1_hash: str | None = None,
) -> tuple[np.ndarray, dict[str, np.ndarray], str]:
    _assert_frozen_phase1_calibration(cal, "HANDOFF", expected_phase1_hash)
    _assert_frozen_phase1_calibration(cal, "SELECTOR", expected_phase1_hash)
    top01 = np.asarray(sim["top01_rate"])
    top10 = np.asarray(sim["top10_rate"])
    win = np.asarray(sim["win_rate"])
    p95 = np.asarray(sim["p95"])
    p99 = np.asarray(sim["p99"])
    cvar99 = np.asarray(sim.get("cvar99", p99))
    mean = np.asarray(sim["mean"])
    salary = cal.frame["SAL"].astype(int).to_numpy()[candidates].sum(axis=1)
    lineup_log_ownership = np.log(cal.ownership_proxy[candidates]).sum(axis=1)
    expected_dup = np.exp(lineup_log_ownership) * config.field_size

    duplication_risk_shadow_features, duplication_risk_shadow = _duplication_risk_shadow_features(candidates, cal)

    top_pct = _percentile_rank(top01)
    win_pct = _percentile_rank(win)
    p95_pct = _percentile_rank(p95)
    p99_pct = _percentile_rank(p99)

    # Strict elite eligibility includes confidence-bound overlap at the global
    # Top-1% boundary. This prevents Monte Carlo sampling noise from deleting a
    # lineup that is statistically indistinguishable from the cutoff after its
    # adaptive bubble trials. Tail cutoffs receive a 0.5-percentile tie band.
    trials_per_lineup = np.asarray(sim["trials_per_lineup"], dtype=float)
    _, top_upper = _wilson_interval(top01, trials_per_lineup)
    _, win_upper = _wilson_interval(win, trials_per_lineup)
    top_cut = float(np.quantile(top01, 0.99))
    win_cut = float(np.quantile(win, 0.99))
    elite_signal = (top_pct >= 0.99) | (win_pct >= 0.99)
    elite_signal |= (top_pct >= 0.985) & (top_upper >= top_cut)
    elite_signal |= (win_pct >= 0.985) & (win_upper >= win_cut)
    tail_signal = (p95_pct >= 0.895) | (p99_pct >= 0.895)
    eligible = elite_signal & tail_signal
    eligible_idx = np.flatnonzero(eligible)
    if len(candidates) <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:WNBA_CLASSIC_ZERO_PHASE3_SURVIVORS")
    target = min(int(config.board_size), len(candidates))

    # Sparse rare-event repair. Raw one-tick WIN/Top-0.1 differences are shrunk toward
    # contest-calibrated priors before ranking. Championship posterior is primary,
    # Top-0.1 posterior secondary, then empirical CVaR99/P99 and uniqueness.
    rare = _rare_event_posterior_surfaces(sim, expected_dup)
    win_posterior = rare["win_posterior"]
    top01_posterior = rare["top01_posterior"]
    rare_event_score = rare["rare_event_score"]
    quantum = np.maximum(1.0 / np.maximum(trials_per_lineup, 1.0), 0.0005)
    top_tied = np.round(top01_posterior / (4.0 * quantum)) * (4.0 * quantum)
    win_tied = np.round(win_posterior / (4.0 * quantum)) * (4.0 * quantum)
    legacy_score = (
        SELECTOR_WEIGHTS["top01"] * top_tied
        + SELECTOR_WEIGHTS["win"] * win_tied
        + SELECTOR_WEIGHTS["p99"] * p99
        + SELECTOR_WEIGHTS["p95"] * p95
        + SELECTOR_WEIGHTS["mean"] * mean
        + SELECTOR_WEIGHTS["expected_dup"] * expected_dup
        + SELECTOR_WEIGHTS["salary"] * salary
    )
    reserve_surfaces = _bankroll_reserve_lane_scores(candidates, cal, salary, expected_dup)
    projection_capacity = _bankroll_projection_capacity_score(candidates, cal, mean)
    salary_rebound = np.asarray(reserve_surfaces["salary_rebound"], dtype=float)
    score = (
        0.70 * rare_event_score
        + 0.15 * projection_capacity
        + 0.15 * salary_rebound
    )

    # The old strict elite/tail gate is retained as diagnostic telemetry only. The bankroll
    # selector shortlists directly from the full frozen handoff using the validated composite.
    vacancy_line = cal.vacancy_beneficiary[candidates].sum(axis=1) >= 1
    dual_contingency = (cal.p_expand[candidates] >= 0.20).sum(axis=1) >= 2
    shortlist: set[int] = set()
    ranking_pool = np.arange(len(candidates), dtype=int)
    k = min(BANKROLL_COMPOSITE_SHORTLIST_MAX, ranking_pool.size)
    if k:
        shortlist.update(ranking_pool[np.argpartition(score, -k)[-k:]].tolist())
    # Preserve feasible vacancy/contingency rows as optional structural constraints, but do not
    # require them to pass the disproven strict elite/tail gate.
    for mask in (vacancy_line, vacancy_line & dual_contingency):
        lane_idx = np.flatnonzero(mask)
        lane_k = min(200, lane_idx.size)
        if lane_k:
            shortlist.update(lane_idx[np.argpartition(score[lane_idx], -lane_k)[-lane_k:]].tolist())
    idx = np.array(sorted(shortlist), dtype=int)
    if idx.size < target:
        idx = np.argsort(-score, kind="stable")[:target]

    rows = candidates[idx]
    n = len(rows)
    constraints_rows: list[np.ndarray] = []
    lower: list[float] = []
    upper: list[float] = []

    constraints_rows.append(np.ones(n))
    lower.append(target)
    upper.append(target)

    # Player exposure cap.
    for player in np.unique(rows):
        incidence = (rows == player).any(axis=1).astype(float)
        constraints_rows.append(incidence)
        lower.append(-np.inf)
        upper.append(config.player_exposure_cap)

    families = [_family_signature(row, cal) for row in rows]
    for family in sorted(set(families), key=str):
        incidence = np.array([f == family for f in families], dtype=float)
        constraints_rows.append(incidence)
        lower.append(-np.inf)
        upper.append(config.family_cap)
    hard_constraint_count = len(constraints_rows)

    # Bankroll selector: vacancy/dual-contingency and premium-sibling structures remain
    # diagnostic features, not hard board quotas. The five-slate raw holdout showed that
    # forcing these optional preferences can displace stronger cross-slate composite lineups.
    vacancy_incidence = cal.vacancy_beneficiary[rows].sum(axis=1).astype(bool).astype(float)
    dual_vacancy_incidence = (
        (cal.vacancy_beneficiary[rows].sum(axis=1) >= 1)
        & ((cal.p_expand[rows] >= 0.20).sum(axis=1) >= 2)
    ).astype(float)
    player_salary = cal.frame["SAL"].astype(int).to_numpy()
    certified_lane = _certified_premium_guard_lane(rows, cal, salary[idx])
    signature_groups: dict[tuple[int, ...], list[int]] = {}
    for local_i in np.flatnonzero(certified_lane):
        row = rows[local_i]
        premium_guards = row[(player_salary[row] >= 9_000) & cal.is_guard[row]]
        signature = tuple(sorted(cal.team_codes[premium_guards].astype(int).tolist()))
        signature_groups.setdefault(signature, []).append(int(local_i))
    feasible_groups = [
        (float(np.max(score[idx[np.asarray(members, dtype=int)]])), signature, members)
        for signature, members in signature_groups.items()
        if len(members) >= 2
    ]
    certified_groups_required = 0
    certified_lineups_required = 0

    # Bankroll objective is top-line capture, not maximizing summed portfolio utility.
    # Preserve the strongest composite lineup first, then diversify sequentially under
    # immutable player-exposure and family caps. This prevents a global MILP trade from
    # sacrificing a high-quality lineup merely to increase the ten-line sum.
    portfolio_relaxation = False
    hard_cap_fallback = False
    reserve_meta: dict[str, object] = {"reserve_applied": False, "reserve_slots": 0, "reserve_candidate_indices": []}
    chosen_list: list[int] = []
    structural_trophy_score = np.full(len(candidates), -np.inf, dtype=float)
    structural_trophy_slots = 0
    if (
        config.field_size >= STRUCTURAL_VALUE_RECALL_FIELD_MIN
        and config.field_size < MEDIUM_FIELD_ELITE_COHORT_FIELD_MAX_EXCLUSIVE
    ):
        structural_trophy_score = _medium_field_elite_cohort_structural_score(candidates, cal, config)
        structural_target = min(MEDIUM_FIELD_ELITE_COHORT_TROPHY_SLOTS, target)
        for candidate_i in np.argsort(-structural_trophy_score, kind="mergesort"):
            before = len(chosen_list)
            _append_hard_safe_candidate(chosen_list, int(candidate_i), candidates, cal, config)
            if len(chosen_list) > before:
                structural_trophy_slots += 1
            if structural_trophy_slots >= structural_target:
                break
    # Large-field Top-0.1 trophy door. This is an identity-blind overlay on the
    # frozen candidate set; it cannot add/delete rows and is evaluated before the
    # generic family door. The score deliberately blends corrected trophy equity
    # with pre-lock geometry so median-safe composite strength cannot fully suppress
    # a right-tail structural specialist.
    top001_trophy_slots = 0
    top001_trophy_eligible = np.zeros(len(candidates), dtype=bool)
    top001_trophy_score = np.full(len(candidates), -np.inf, dtype=float)
    top001_trophy_order = np.empty(0, dtype=np.int64)
    top001_trophy_meta: dict[str, object] = {}
    if config.field_size >= STRUCTURAL_BIRTH_LARGE_FIELD_MIN:
        player_minutes = cal.frame["MIN"].astype(float).to_numpy()
        cand_minutes_sum = player_minutes[candidates].sum(axis=1)
        cand_min_minutes = player_minutes[candidates].min(axis=1)
        cand_structural_count = cal.structural_value_geometry[candidates].sum(axis=1).astype(float)
        cand_p99_proxy = cal.p99[candidates].sum(axis=1)
        cand_release = SALARY_MAX - salary
        cand_games = np.sort(cal.game_codes[candidates], axis=1)
        cand_games_used = 1 + (cand_games[:, 1:] != cand_games[:, :-1]).sum(axis=1)
        cand_teams = np.sort(cal.team_codes[candidates], axis=1)
        cand_teams_used = 1 + (cand_teams[:, 1:] != cand_teams[:, :-1]).sum(axis=1)
        cand_max_game = np.ones(len(candidates), dtype=np.int16)
        cand_game_run = np.ones(len(candidates), dtype=np.int16)
        for position in range(1, candidates.shape[1]):
            cand_game_run = np.where(
                cand_games[:, position] == cand_games[:, position - 1],
                cand_game_run + 1,
                1,
            )
            cand_max_game = np.maximum(cand_max_game, cand_game_run)
        cand_low_minutes_count = (player_minutes[candidates] < TOP001_RN_LOW_MINUTES_CUTOFF).sum(axis=1)
        cand_common_top001_shape = (
            (cand_release <= TOP001_RN_RELEASE_MAX)
            & (cand_games_used <= TOP001_RN_GAMES_USED_MAX)
            & (cand_teams_used <= TOP001_RN_TEAMS_USED_MAX)
            & (cand_max_game >= TOP001_RN_MAX_GAME_COUNT_MIN)
        )
        cand_stable_top001_lane = (
            cal.rotation_active[candidates].all(axis=1)
            & cand_common_top001_shape
            & (cand_minutes_sum >= TOP001_RN_STABLE_MINUTES_SUM_MIN)
            & (cand_structural_count >= TOP001_RN_STRUCTURAL_COUNT_MIN)
            & (cand_p99_proxy >= TOP001_RN_STABLE_P99_SUM_MIN)
        )
        cand_volatile_top001_lane = (
            cand_common_top001_shape
            & (cand_low_minutes_count <= TOP001_RN_LOW_MINUTES_MAX)
            & (cand_minutes_sum >= TOP001_RN_VOLATILE_MINUTES_SUM_MIN)
            & (cand_structural_count >= TOP001_RN_VOLATILE_STRUCTURAL_COUNT_MIN)
            & (cand_p99_proxy >= TOP001_RN_VOLATILE_P99_SUM_MIN)
        )
        cand_role_rebound = cal.historical_rebound[candidates] | cal.recent_role_rebound[candidates]
        cand_low_role_rebound_count = ((player_minutes[candidates] < RECENT_ROLE_CURRENT_MINUTES_CEILING) & cand_role_rebound).sum(axis=1)
        cand_premium_count = (cal.frame["SAL"].astype(int).to_numpy()[candidates] >= 9000).sum(axis=1)
        cand_dislocation_top001_lane = (
            (cand_low_role_rebound_count == 1)
            & (cand_release <= TOP001_RN_RELEASE_MAX)
            & (cand_minutes_sum >= TOP001_RN_DISLOCATION_MINUTES_SUM_MIN)
            & (cand_structural_count >= TOP001_RN_DISLOCATION_STRUCTURAL_COUNT_MIN)
            & (cand_p99_proxy >= TOP001_RN_DISLOCATION_P99_SUM_MIN)
            & (cand_games_used <= TOP001_RN_DISLOCATION_GAMES_USED_MAX)
            & (cand_teams_used <= TOP001_RN_TEAMS_USED_MAX)
            & (cand_max_game >= TOP001_RN_MAX_GAME_COUNT_MIN)
            & (cand_premium_count >= TOP001_RN_DISLOCATION_PREMIUM_COUNT_MIN)
        )
        top001_trophy_eligible = cand_stable_top001_lane | cand_volatile_top001_lane | cand_dislocation_top001_lane
        trophy_idx = np.flatnonzero(top001_trophy_eligible)
        if trophy_idx.size:
            asset_used = False
            phenotype_order = np.empty(0, dtype=np.int64)
            if TOP001_PHENOTYPE_ASSET_PATH.exists():
                asset = json.loads(TOP001_PHENOTYPE_ASSET_PATH.read_text())
                training_hashes = {str(x) for x in asset.get("TRAINING_PLAYER_IDENTIFIER_HASHES", []) if str(x)}
                legacy_training_hash = str(asset.get("TRAINING_PLAYER_IDENTIFIER_HASH", ""))
                if legacy_training_hash:
                    training_hashes.add(legacy_training_hash)
                same_training_slate = cal.player_identifier_hash in training_hashes
                allow_training_replay = os.environ.get("APEX_POSTLOCK_DIAGNOSTIC") == "1"
                if not same_training_slate or allow_training_replay:
                    cand_vacancy = cal.vacancy_beneficiary[candidates].sum(axis=1).astype(float)
                    cand_rebound = (cal.historical_rebound[candidates] | cal.recent_role_rebound[candidates]).sum(axis=1).astype(float)
                    cand_p95_proxy = cal.p95[candidates].sum(axis=1)
                    cand_mean_proxy = cal.mean[candidates].sum(axis=1)
                    cand_max_team = np.ones(len(candidates), dtype=np.int16)
                    cand_team_run = np.ones(len(candidates), dtype=np.int16)
                    for position in range(1, candidates.shape[1]):
                        cand_team_run = np.where(
                            cand_teams[:, position] == cand_teams[:, position - 1],
                            cand_team_run + 1,
                            1,
                        )
                        cand_max_team = np.maximum(cand_max_team, cand_team_run)
                    cand_cheap = (cal.frame["SAL"].astype(int).to_numpy()[candidates] <= 7500).sum(axis=1).astype(float)
                    cand_premium = (cal.frame["SAL"].astype(int).to_numpy()[candidates] >= 9000).sum(axis=1).astype(float)
                    feature_map = {
                        "release": cand_release.astype(float),
                        "min_sum": cand_minutes_sum.astype(float),
                        "min_min": cand_min_minutes.astype(float),
                        "low_min_count": cand_low_minutes_count.astype(float),
                        "low_role_rebound_count": cand_low_role_rebound_count.astype(float),
                        "rotation_all": cal.rotation_active[candidates].all(axis=1).astype(float),
                        "structural_count": cand_structural_count.astype(float),
                        "vacancy_count": cand_vacancy,
                        "rebound_count": cand_rebound,
                        "p99_sum": cand_p99_proxy.astype(float),
                        "p95_sum": cand_p95_proxy.astype(float),
                        "mean_sum": cand_mean_proxy.astype(float),
                        "max_team": cand_max_team.astype(float),
                        "teams_used": cand_teams_used.astype(float),
                        "max_game": cand_max_game.astype(float),
                        "games_used": cand_games_used.astype(float),
                        "cheap_le7500": cand_cheap,
                        "premium_ge9000": cand_premium,
                    }
                    feature_names = list(asset.get("FEATURES", []))
                    prototypes = np.asarray(asset.get("PROTOTYPE_PERCENTILES", []), dtype=float)
                    weights = np.asarray(asset.get("FEATURE_WEIGHTS", []), dtype=float)
                    if prototypes.ndim == 2 and len(feature_names) == prototypes.shape[1] == len(weights):
                        pct = np.column_stack([_percentile_rank(feature_map[name]) for name in feature_names])
                        distance_matrix = ((pct[:, None, :] - prototypes[None, :, :]) ** 2 * weights[None, None, :]).sum(axis=2)
                        phenotype_distance = distance_matrix.min(axis=1)
                        nearest_prototype = distance_matrix.argmin(axis=1)
                        coarse = asset.get("ELIGIBILITY", {})
                        phenotype_mask = top001_trophy_eligible.copy()
                        phenotype_mask &= salary >= int(coarse.get("salary_min", SALARY_MIN))
                        phenotype_mask &= cand_structural_count >= float(coarse.get("structural_count_min", 1))
                        phenotype_mask &= cand_max_game >= int(coarse.get("max_game_min", 1))
                        phenotype_mask &= cand_games_used <= int(coarse.get("games_used_max", TOP001_RN_GAMES_USED_MAX))
                        phenotype_mask &= cand_low_minutes_count <= int(coarse.get("low_min_count_max", TOP001_RN_LOW_MINUTES_MAX))
                        phenotype_idx = np.flatnonzero(phenotype_mask)
                        if phenotype_idx.size:
                            # Trophy-zone objective: use the nearest identity-blind phenotype globally.
                            # Forced one-per-prototype interleaving was too broad and could spend scarce
                            # board slots on distant historical phenotypes while a much closer current-slate
                            # trophy neighbor sat just outside the door. Hard exposure/family caps still
                            # diversify the final portfolio.
                            phenotype_order = phenotype_idx[
                                np.argsort(phenotype_distance[phenotype_idx], kind="stable")
                            ].astype(np.int64, copy=False)
                            top001_trophy_order = phenotype_order
                            top001_trophy_score[top001_trophy_order] = -phenotype_distance[top001_trophy_order]
                            top001_trophy_meta = {
                                "PATCH_ID": asset.get("PATCH_ID"),
                                "ASSET_USED": True,
                                "SAME_TRAINING_SLATE": bool(same_training_slate),
                                "TRAINING_REPLAY_ALLOWED": bool(allow_training_replay),
                                "PROTOTYPE_COUNT": int(len(prototypes)),
                                "PHENOTYPE_ELIGIBLE": int(len(phenotype_idx)),
                                "PLAYER_IDENTITIES_IN_ASSET": False,
                                "REALIZED_POINTS_IN_ASSET": False,
                            }
                            asset_used = True
            if not asset_used:
                trophy_keys = np.asarray([
                    f"G{int(cand_games_used[i])}|T{int(cand_teams_used[i])}|M{int(cand_max_game[i])}|"
                    f"S{int(cand_structural_count[i])}|L{int(cand_low_minutes_count[i])}|"
                    f"R{int(cand_release[i] // 300)}|O{int(cand_minutes_sum[i] // 10)}"
                    for i in trophy_idx
                ], dtype=object)
                local_order, top001_trophy_meta = neighborhood_door_order(
                    trophy_keys,
                    {
                        "proxy_p99": cand_p99_proxy[trophy_idx],
                        "minutes": cand_minutes_sum[trophy_idx],
                        "structural": cand_structural_count[trophy_idx],
                        "max_game": cand_max_game[trophy_idx].astype(float),
                        "salary_spend": salary[trophy_idx].astype(float),
                        "rotation_security": -cand_low_minutes_count[trophy_idx].astype(float),
                        "top01": top01[trophy_idx],
                        "win": win[trophy_idx],
                        "p99": p99[trophy_idx],
                        "uniqueness": -expected_dup[trophy_idx],
                    },
                    {
                        "proxy_p99": 0.24,
                        "minutes": 0.22,
                        "structural": 0.16,
                        "max_game": 0.10,
                        "salary_spend": 0.08,
                        "rotation_security": 0.07,
                        "top01": 0.05,
                        "win": 0.02,
                        "p99": 0.03,
                        "uniqueness": 0.03,
                    },
                    breadth=max(16, min(64, config.board_size * 6)),
                    root_fraction=0.01,
                    max_interleave=len(trophy_idx),
                )
                top001_trophy_order = trophy_idx[local_order]
                top001_trophy_score[top001_trophy_order] = np.arange(len(top001_trophy_order), 0, -1, dtype=float)
            for candidate_i in top001_trophy_order:
                before = len(chosen_list)
                _append_hard_safe_candidate(chosen_list, int(candidate_i), candidates, cal, config)
                if len(chosen_list) > before:
                    top001_trophy_slots += 1
                if top001_trophy_slots >= min(TOP001_TROPHY_DOOR_SLOTS, target):
                    break

    # WNBA right-neighborhood/door authority: structural family admission precedes
    # local lineup-door ranking. Existing hard portfolio caps remain authoritative.
    rn_keys = np.asarray([str(_family_signature(row, cal)) for row in candidates], dtype=object)
    rn_order, rn_meta = neighborhood_door_order(
        rn_keys,
        {
            "composite": score,
            "projection_capacity": projection_capacity,
            "salary_rebound": salary_rebound,
            "top01": top01_posterior,
            "win": win_posterior,
            "cvar99": cvar99,
            "p99": p99,
            "p95": p95,
        },
        {
            "composite": 0.40,
            "projection_capacity": 0.15,
            "salary_rebound": 0.08,
            "top01": 0.10,
            "win": 0.12,
            "cvar99": 0.08,
            "p99": 0.05,
            "p95": 0.02,
        },
        breadth=max(24, min(96, config.board_size * 8)),
        max_interleave=len(candidates),
    )
    for candidate_i in rn_order:
        if len(chosen_list) >= target:
            break
        _append_hard_safe_candidate(chosen_list, int(candidate_i), candidates, cal, config)
    chosen = np.asarray(chosen_list, dtype=int)
    if len(chosen) != target:
        raise RuntimeError(f"ENGINE_INTEGRITY_FAILURE:WNBA_CLASSIC_NONEMPTY_BOARD_CARDINALITY:{len(chosen)}:{target}")
    if not _hard_portfolio_valid(chosen.tolist(), candidates, cal, config):
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:WNBA_CLASSIC_HARD_PORTFOLIO_CAP_VIOLATION")
    chosen, ranker_meta = _uncertainty_aware_scenario_lane_order(
        chosen, candidates, sim, cal, salary, expected_dup, score, config
    )
    expert_chosen, _expert_surfaces, expert_meta = _expert_routed_select_board(candidates, sim, cal, config, base_selected=chosen)
    if len(expert_chosen) == target and _hard_portfolio_valid(expert_chosen.tolist(), candidates, cal, config):
        chosen = np.asarray(expert_chosen, dtype=int)

    # Bounded anonymous reserve: after expert routing and before final core ordering,
    # preserve at most one exact 5-of-6 sibling that adds a qualified structural bridge
    # without sacrificing modeled tail capacity, salary quality, duplication, or hard caps.
    reserve_structure = _scenario_structure(candidates, cal, salary)
    chosen, dominant_anchor_qb_reserve_meta = _apply_dominant_anchor_qb_reserve(
        candidates,
        chosen,
        salary=salary,
        qualified_bridge_count=reserve_structure["qualified_bridge_count"],
        mean=mean,
        p95=p95,
        p99=p99,
        top01=top01_posterior,
        expected_dup=expected_dup,
        selector_score=score,
        portfolio_valid=lambda proposal: _hard_portfolio_valid(proposal, candidates, cal, config),
    )
    if len(chosen) != target or not _hard_portfolio_valid(chosen.tolist(), candidates, cal, config):
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:WNBA_CLASSIC_DOMINANT_ANCHOR_QB_RESERVE_PORTFOLIO_INVALID")

    selected_keys = np.asarray([str(_family_signature(candidates[int(i)], cal)) for i in chosen], dtype=object)
    selected_order, selected_rn_meta = neighborhood_door_order(
        selected_keys,
        {
            "composite": score[chosen],
            "projection_capacity": projection_capacity[chosen],
            "salary_rebound": salary_rebound[chosen],
            "top01": top01_posterior[chosen],
            "win": win_posterior[chosen],
            "cvar99": cvar99[chosen],
            "p99": p99[chosen],
            "p95": p95[chosen],
        },
        {"composite": 0.40, "projection_capacity": 0.15, "salary_rebound": 0.08, "top01": 0.10, "win": 0.12, "cvar99": 0.08, "p99": 0.05, "p95": 0.02},
        breadth=max(12, min(len(chosen), config.board_size)),
        max_interleave=len(chosen),
    )
    chosen = chosen[selected_order]
    metrics = {
        "mean": mean[chosen],
        "p95": p95[chosen],
        "p99": p99[chosen],
        "cvar99": cvar99[chosen],
        "win_rate": win[chosen],
        "win_posterior": win_posterior[chosen],
        "top01_posterior": top01_posterior[chosen],
        "top01_rate": top01[chosen],
        "top10_rate": top10[chosen],
        "expected_dup": expected_dup[chosen],
        "duplication_risk_shadow": duplication_risk_shadow[chosen],
        "score": score[chosen],
        "salary": salary[chosen],
        "eligible_count": np.array([eligible_idx.size]),
        "selector_reviewed": np.array([len(candidates)]),
        "certified_sibling_groups_required": np.array([certified_groups_required]),
        "certified_sibling_lineups_required": np.array([certified_lineups_required]),
        "scenario_lane_candidates": np.array([ranker_meta["scenario_lane_candidates"]]),
        "scenario_lane_priority_rank": np.array([ranker_meta["scenario_lane_priority_rank"]]),
        "scenario_lane_leader_candidate_index": np.array([ranker_meta["scenario_lane_leader_candidate_index"]]),
        "dominant_anchor_qb_reserve_triggered": np.array([int(bool(dominant_anchor_qb_reserve_meta.get("TRIGGERED", False)))]),
        "dominant_anchor_qb_reserve_qualifiers": np.array([int(dominant_anchor_qb_reserve_meta.get("QUALIFYING_SIBLINGS", 0))]),
        "dominant_anchor_qb_reserve_reserved_index": np.array([int(dominant_anchor_qb_reserve_meta.get("RESERVED_SIBLING_INDEX", -1))]),
        "dominant_anchor_qb_reserve_evicted_index": np.array([int(dominant_anchor_qb_reserve_meta.get("EVICTED_INDEX", -1))]),
        "_candidate_score": score,
        "_rare_event_score": rare_event_score,
        "_candidate_win_posterior": win_posterior,
        "_candidate_top01_posterior": top01_posterior,
        "_legacy_candidate_score": legacy_score,
        "_bankroll_projection_capacity": projection_capacity,
        "_bankroll_salary_rebound": salary_rebound,
        "_candidate_salary": salary,
        "_candidate_expected_dup": expected_dup,
        "_candidate_duplication_risk_shadow": duplication_risk_shadow,
        "_candidate_duplication_risk_shadow_features": duplication_risk_shadow_features,
        "_eligible_mask": eligible,
        "_shortlist_mask": np.isin(np.arange(len(candidates)), idx),
        "_selected_candidate_indices": chosen,
        "_structural_trophy_score": structural_trophy_score,
        "structural_trophy_slots": np.array([structural_trophy_slots]),
        "top001_trophy_slots": np.array([top001_trophy_slots]),
        "top001_trophy_eligible": np.array([int(top001_trophy_eligible.sum())]),
        "top001_trophy_order_sha256": np.array([str(top001_trophy_meta.get("ORDER_SHA256", ""))]),
        "_top001_trophy_score": top001_trophy_score,
        "final_board_target": np.array([target]),
        "portfolio_preference_relaxation": np.array([int(portfolio_relaxation)]),
        "hard_cap_fallback": np.array([int(hard_cap_fallback)]),
        "hard_cap_integrity": np.array([1]),
        "right_neighborhood_door_patch": np.array([RIGHT_NEIGHBORHOOD_DOOR_PATCH_ID]),
        "right_neighborhood_count": np.array([int(rn_meta.get("NEIGHBORHOOD_COUNT", 0))]),
        "right_neighborhood_admitted": np.array([int(rn_meta.get("ADMITTED_NEIGHBORHOODS", 0))]),
        "right_neighborhood_order_sha256": np.array([str(rn_meta.get("ORDER_SHA256", ""))]),
        "right_neighborhood_final_order_sha256": np.array([str(selected_rn_meta.get("ORDER_SHA256", ""))]),
        "expert_routed_trophy_door_patch": np.array([EXPERT_ROUTED_TROPHY_DOOR_PATCH_ID]),
        "dominant_anchor_qb_reserve_patch": np.array([DOMINANT_ANCHOR_QB_RESERVE_PATCH_ID]),
        "dominant_anchor_qb_reserve_decision_sha256": np.array([str(dominant_anchor_qb_reserve_meta.get("DECISION_SHA256", ""))]),
        "expert_routed_source_lanes": np.array(["|".join(map(str, expert_meta.get("SOURCE_LANES", [])))]),
        "bankroll_reserve_applied": np.array([int(bool(reserve_meta.get("reserve_applied", False)))]),
        "bankroll_reserve_slots": np.array([int(reserve_meta.get("reserve_slots", 0))]),
        "bankroll_reserve_candidate_indices": np.array(reserve_meta.get("reserve_candidate_indices", []), dtype=int),
    }
    if bool(dominant_anchor_qb_reserve_meta.get("TRIGGERED", False)):
        selector_state = "PASS_DOMINANT_ANCHOR_QB_UPGRADE_SIBLING_RESERVE"
    elif len(expert_meta.get("SELECTED_CANDIDATE_INDICES", [])) == target:
        selector_state = "PASS_EXPERT_ROUTED_TROPHY_DOOR"
    elif top001_trophy_slots:
        selector_state = "PASS_TOP001_RIGHT_NEIGHBORHOOD_TROPHY_DOOR"
    elif structural_trophy_slots:
        selector_state = "PASS_RIGHT_NEIGHBORHOOD_DOOR_PLUS_ELITE_COHORT_STRUCTURAL_TROPHY_LANE"
    else:
        selector_state = "PASS_RIGHT_NEIGHBORHOOD_DOOR_HARD_CAP_TOPLINE_PRESERVED"
    return candidates[chosen], metrics, selector_state


def _assign_slots(row: np.ndarray, cal: Calibration) -> list[tuple[str, int]]:
    guards = [int(i) for i in row if cal.is_guard[i]]
    forwards = [int(i) for i in row if not cal.is_guard[i]]
    guards.sort(key=lambda i: (-int(cal.frame.iloc[i]["SAL"]), str(cal.frame.iloc[i]["PLAYER"])))
    forwards.sort(key=lambda i: (-int(cal.frame.iloc[i]["SAL"]), str(cal.frame.iloc[i]["PLAYER"])))
    assigned: list[tuple[str, int]] = []
    assigned.extend((slot, idx) for slot, idx in zip(("G1", "G2"), guards[:2], strict=True))
    assigned.extend((slot, idx) for slot, idx in zip(("F1", "F2", "F3"), forwards[:3], strict=True))
    util_candidates = guards[2:] + forwards[3:]
    if len(util_candidates) != 1:
        raise RuntimeError("SLOT_ASSIGNMENT_FAILURE")
    assigned.append(("UTIL", util_candidates[0]))
    return assigned


def render_outputs(
    board: np.ndarray,
    board_metrics: dict[str, np.ndarray],
    cal: Calibration,
    config: RuntimeConfig,
    pool_path: str | Path,
    output_board: str | Path,
    output_receipt: str | Path,
    phase2_count: int,
    phase2_meta: dict[str, np.ndarray],
    legal_count: int,
    sim: dict[str, np.ndarray | int],
    selector_state: str,
    runtime_seconds: float,
    ledger_meta: dict[str, object],
    identity_map_meta: dict[str, object],
) -> dict:
    board_rows: list[dict] = []
    board_receipt: list[dict] = []
    for rank, row in enumerate(board, start=1):
        assigned = _assign_slots(row, cal)
        players = []
        for slot, idx in assigned:
            player = cal.frame.iloc[idx]
            players.append({
                "slot": slot,
                "player": str(player["PLAYER"]),
                "team": str(player["TEAM"]),
                "salary": int(player["SAL"]),
                "pos": str(player["POS"]),
                "base_projection": float(cal.base_projection[idx]),
                "role_ceiling_minutes": float(cal.role_ceiling_minutes[idx]),
                "vacancy_minutes_added": float(cal.vacancy_minutes_added[idx]),
            })
            board_rows.append({
                "LINEUP": rank,
                "SLOT": slot,
                "PLAYER": str(player["PLAYER"]),
                "TEAM": str(player["TEAM"]),
                "POS": str(player["POS"]),
                "SALARY": int(player["SAL"]),
                "LINEUP_SALARY": int(board_metrics["salary"][rank - 1]),
                "MC_MEAN": float(board_metrics["mean"][rank - 1]),
                "MC_P95": float(board_metrics["p95"][rank - 1]),
                "MC_P99": float(board_metrics["p99"][rank - 1]),
                "MC_CVAR99": float(board_metrics.get("cvar99", board_metrics["p99"])[rank - 1]),
                "MC_WIN_RATE": float(board_metrics["win_rate"][rank - 1]),
                "MC_WIN_POSTERIOR": float(board_metrics.get("win_posterior", board_metrics["win_rate"])[rank - 1]),
                "MC_TOP_0_1_RATE": float(board_metrics["top01_rate"][rank - 1]),
                "MC_TOP_0_1_POSTERIOR": float(board_metrics.get("top01_posterior", board_metrics["top01_rate"])[rank - 1]),
                "MC_TOP_10_RATE": float(board_metrics["top10_rate"][rank - 1]),
                "EXPECTED_DUP": float(board_metrics["expected_dup"][rank - 1]),
                "DUPLICATION_RISK_SHADOW": float(board_metrics.get("duplication_risk_shadow", np.full(len(board), np.nan))[rank - 1]),
                "SELECTOR_SCORE": float(board_metrics["score"][rank - 1]),
            })
        board_receipt.append({
            "rank": rank,
            "salary": int(board_metrics["salary"][rank - 1]),
            "mean_mc": float(board_metrics["mean"][rank - 1]),
            "p95_mc": float(board_metrics["p95"][rank - 1]),
            "p99_mc": float(board_metrics["p99"][rank - 1]),
            "cvar99_mc": float(board_metrics.get("cvar99", board_metrics["p99"])[rank - 1]),
            "win_rate": float(board_metrics["win_rate"][rank - 1]),
            "win_posterior": float(board_metrics.get("win_posterior", board_metrics["win_rate"])[rank - 1]),
            "top_0_1_rate": float(board_metrics["top01_rate"][rank - 1]),
            "top_10_rate": float(board_metrics["top10_rate"][rank - 1]),
            "expected_dup": float(board_metrics["expected_dup"][rank - 1]),
            "duplication_risk_shadow": float(board_metrics.get("duplication_risk_shadow", np.full(len(board), np.nan))[rank - 1]),
            "players": players,
        })

    pd.DataFrame(board_rows).to_csv(output_board, index=False)
    receipt = {
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED" if selector_state.startswith("PASS") else "FAILED",
        "PRODUCTION_TRIGGER_DIRECT_EXECUTION": "PASS",
        "DIAGNOSTIC_ROUTING": "DISABLED",
        "BOARD_FIRST_RENDERING": "PASS",
        "BOARD_IDENTITY_RECONCILIATION": "PASS",
        "ENGINE_ID": ENGINE_ID,
        "PATCH_ID": PATCH_ID,
        "CALIBRATION_PARITY_PATCH_ID": CALIBRATION_PARITY_PATCH_ID,
        "SELECTOR_RANKER_PATCH_ID": SELECTOR_RANKER_PATCH_ID,
        "OPEN_RESEARCH_GOVERNANCE_PATCH_ID": OPEN_RESEARCH_GOVERNANCE_PATCH_ID,
        "STRUCTURAL_VALUE_GEOMETRY_PATCH_ID": STRUCTURAL_VALUE_GEOMETRY_PATCH_ID,
        "MEDIUM_FIELD_STRUCTURAL_VALUE_RECALL_PATCH_ID": MEDIUM_FIELD_STRUCTURAL_VALUE_RECALL_PATCH_ID,
        "MEDIUM_FIELD_PHASE2_STRUCTURAL_COMPLEMENT_PATCH_ID": MEDIUM_FIELD_PHASE2_STRUCTURAL_COMPLEMENT_PATCH_ID,
        "MEDIUM_FIELD_ACTIVE_VALUE_STARTER_PATCH_ID": MEDIUM_FIELD_ACTIVE_VALUE_STARTER_PATCH_ID,
        "MEDIUM_FIELD_PHASE2_RECALL_MIN": MEDIUM_FIELD_PHASE2_RECALL_MIN,
        "MEDIUM_FIELD_PHASE2_RECALL_MAX_EXCLUSIVE": STRUCTURAL_BIRTH_LARGE_FIELD_MIN,
        "STRUCTURAL_VALUE_RECALL_FIELD_MIN": STRUCTURAL_VALUE_RECALL_FIELD_MIN,
        "ALPHA_PAIR_LOW_MIN_GEOMETRY_PATCH_ID": ALPHA_PAIR_LOW_MIN_GEOMETRY_PATCH_ID,
        "RECENT_ROLE_DUAL_DISLOCATION_PATCH_ID": RECENT_ROLE_DUAL_DISLOCATION_PATCH_ID,
        "GLOBAL_SPORTS_STRATEGIST_PATCH_ID": GLOBAL_SPORTS_STRATEGIST_PATCH_ID,
        "SPORT_STRATEGY_MECHANIC": global_strategy.profile_for("WNBA", "CLASSIC")["mechanic"],
        "STRATEGY_CONTRACT_HASH": cal.global_strategy_receipt["CONTRACT_HASH"],
        "PREDICTIVE_LAYER_PATCH_ID": cal.global_strategy_receipt["PREDICTIVE_LAYER_PATCH_ID"],
        "PREDICTIVE_LAYER_STATUS": cal.global_strategy_receipt["PREDICTIVE_LAYER_STATUS"],
        "PREDICTION_HASH": cal.global_strategy_receipt["PREDICTION_HASH"],
        "RAW_MARKET_INPUT_HASH": cal.global_strategy_receipt["RAW_MARKET_INPUT_HASH"],
        "PLAYER_MARKET_ROWS": cal.global_strategy_receipt["PLAYER_MARKET_ROWS"],
        "GAME_MARKET_ROWS": cal.global_strategy_receipt["GAME_MARKET_ROWS"],
        "MORE_DECISIONS": cal.global_strategy_receipt["MORE_DECISIONS"],
        "LESS_DECISIONS": cal.global_strategy_receipt["LESS_DECISIONS"],
        "PASS_DECISIONS": cal.global_strategy_receipt["PASS_DECISIONS"],
        "STALE_LINE_SIGNALS": cal.global_strategy_receipt["STALE_LINE_SIGNALS"],
        "PREDICTION_FROZEN": cal.global_strategy_receipt["PREDICTION_FROZEN"],
        "STRATEGY_CONSUMED_PREDICTION_HASH": cal.global_strategy_receipt["STRATEGY_CONSUMED_PREDICTION_HASH"],
        "ROTATION_STRATEGIST_PATCH_ID": ROTATION_STRATEGIST_PATCH_ID,
        "DUPLICATION_RISK_SHADOW_PATCH_ID": DUPLICATION_RISK_SHADOW_PATCH_ID,
        "DUPLICATION_RISK_SHADOW_STATUS": "SHADOW_TELEMETRY_ONLY",
        "DUPLICATION_RISK_SHADOW_SELECTION_AUTHORITY": False,
        "DUPLICATION_RISK_SHADOW_SELECTOR_WEIGHT": 0.0,
        "DUPLICATION_RISK_SHADOW_HARD_GATE": False,
        "DUPLICATION_RISK_SHADOW_CANDIDATE_MIN": float(np.nanmin(board_metrics.get("_candidate_duplication_risk_shadow", np.array([np.nan])))),
        "DUPLICATION_RISK_SHADOW_CANDIDATE_MEDIAN": float(np.nanmedian(board_metrics.get("_candidate_duplication_risk_shadow", np.array([np.nan])))),
        "DUPLICATION_RISK_SHADOW_CANDIDATE_MAX": float(np.nanmax(board_metrics.get("_candidate_duplication_risk_shadow", np.array([np.nan])))),
        "FULL_ORDER_LEDGER_SCHEMA_VERSION": FULL_ORDER_LEDGER_SCHEMA_VERSION,
        "FULL_ORDER_LEDGER_PATH": ledger_meta.get("path"),
        "FULL_ORDER_LEDGER_ROWS": int(ledger_meta.get("rows", 0)),
        "FULL_ORDER_LEDGER_SHA256": ledger_meta.get("sha256"),
        "FULL_ORDER_LEDGER_PLAYER_NAMES_PRESENT": bool(ledger_meta.get("player_names_present", False)),
        "FULL_ORDER_LEDGER_POSTLOCK_FIELDS_PRESENT": bool(ledger_meta.get("postlock_fields_present", False)),
        "SEALED_IDENTITY_MAP_SCHEMA_VERSION": SEALED_IDENTITY_MAP_SCHEMA_VERSION,
        "SEALED_IDENTITY_MAP_PATH": identity_map_meta.get("path"),
        "SEALED_IDENTITY_MAP_ROWS": int(identity_map_meta.get("rows", 0)),
        "SEALED_IDENTITY_MAP_SHA256": identity_map_meta.get("sha256"),
        "SEALED_IDENTITY_MAP_POSTLOCK_ONLY": True,
        "SEALED_IDENTITY_MAP_FORWARD_SELECTOR_IMPORT_PROHIBITED": True,
        "RANK1_OPEN_RESEARCH_STATE": "SHADOW_ONLY_PENDING_MULTI_SLATE_RAW_HOLDOUT",
        "PRODUCTION_ORDER_MUTATION_BY_OPEN_RESEARCH": False,
        "PLATFORM": "DK",
        "SPORT": "WNBA",
        "MODE": "CLASSIC",
        "FIELD_SIZE": config.field_size,
        "SEED": config.seed,
        "INPUT": str(pool_path),
        "INPUT_SHA256": _sha256_file(pool_path),
        "INPUT_ROWS": int(len(pd.read_csv(pool_path))),
        "ACTIVE_POOL": int(len(cal.frame)),
        "OUT_PURGE_COUNT": len(cal.out_purge),
        "OUT_PURGE": cal.out_purge,
        "ZERO_MIN_PURGE_COUNT": len(cal.zero_min_purge),
        "ZERO_MIN_PURGE": cal.zero_min_purge,
        "CALIBRATION_QUALIFIED_PLAYERS": int(cal.qualified.sum()),
        "STRUCTURAL_VALUE_GEOMETRY_PLAYERS": cal.frame.loc[
            cal.structural_value_geometry, "PLAYER"
        ].astype(str).tolist(),
        "PHASE1_MC_ITERATIONS": config.player_trials,
        "COVARIANCE_HASH_PHASE1": cal.covariance_hash,
        "COVARIANCE_HASH_PHASE2": cal.covariance_hash,
        "COVARIANCE_HASH_PHASE3": cal.covariance_hash,
        "METRIC_PARITY": "PASS",
        "FULL_CALIBRATION_PARITY": "PASS",
        "FROZEN_CALIBRATION_FLOW_PATCH_ID": FROZEN_CALIBRATION_FLOW_PATCH_ID,
        "PHASE1_CALIBRATION_FROZEN": True,
        "PHASE1_CALIBRATION_SOURCE_OF_TRUTH": "CALIBRATION_CONTRACT_HASH_PHASE1",
        "PHASE2_CALIBRATION_SOURCE": "PHASE1_FROZEN",
        "PHASE3_CALIBRATION_SOURCE": "PHASE1_FROZEN",
        "HANDOFF_CALIBRATION_SOURCE": "PHASE1_FROZEN",
        "SELECTOR_CALIBRATION_SOURCE": "PHASE1_FROZEN",
        "DOWNSTREAM_RECALIBRATION_PROHIBITED": True,
        "CALIBRATION_CONTRACT_VERSION": CALIBRATION_CONTRACT_VERSION,
        "CALIBRATION_CONTRACT_HASH_PHASE1": cal.calibration_contract_hash,
        "CALIBRATION_CONTRACT_HASH_PHASE2": cal.calibration_contract_hash,
        "CALIBRATION_CONTRACT_HASH_PHASE3": cal.calibration_contract_hash,
        "CALIBRATION_CONTRACT_HASH_HANDOFF": cal.calibration_contract_hash,
        "CALIBRATION_CONTRACT_HASH_SELECTOR": cal.calibration_contract_hash,
        "PLAYER_IDENTIFIER_HASH": cal.player_identifier_hash,
        "OWNERSHIP_HASH": cal.ownership_hash,
        "CEILING_HASH": cal.ceiling_hash,
        "ROLE_STATE_HASH": cal.role_state_hash,
        "TEAM_GAME_FEATURE_HASH": cal.team_game_feature_hash,
        "METRIC_SCALING_HASH": cal.metric_scaling_hash,
        "SIMULATION_MATRIX_HASH": cal.simulation_matrix_hash,
        "ROSTER_RULE": ROSTER_RULE,
        "SALARY_MIN": SALARY_MIN,
        "SALARY_MAX": SALARY_MAX,
        "MAX_FROM_TEAM": MAX_FROM_TEAM,
        "MIN_GAMES": MIN_GAMES,
        "LEGAL_LINEUPS_SCANNED": legal_count,
        "PHASE2_BUILT_LINEUPS": phase2_count,
        "PHASE2_BASELINE_FAMILY_ROWS": int(np.asarray(
            phase2_meta.get("baseline_phase2_rows", np.array([0]))
        )[0]),
        "ALPHA_PAIR_LOW_MIN_PAIRS_TARGETED": int(np.asarray(
            phase2_meta.get("alpha_pair_targeted", np.array([0]))
        )[0]),
        "ALPHA_PAIR_LOW_MIN_COMPLETE_LOCAL_SCAN": int(np.asarray(
            phase2_meta.get("alpha_pair_structural_scan", np.array([0]))
        )[0]),
        "ALPHA_PAIR_LOW_MIN_STRUCTURAL_CELLS": int(np.asarray(
            phase2_meta.get("alpha_pair_structural_cells", np.array([0]))
        )[0]),
        "ALPHA_PAIR_LOW_MIN_ROWS_RETAINED": int(np.asarray(
            phase2_meta.get("alpha_pair_structural_rows", np.array([0]))
        )[0]),
        "ALPHA_PAIR_LOW_MIN_NEW_ADDITIONS": int(np.asarray(
            phase2_meta.get("alpha_pair_structural_additions", np.array([0]))
        )[0]),
        "ALPHA_PAIR_LOW_MIN_REGISTRY_SHA256": str(np.asarray(
            phase2_meta.get("alpha_pair_registry_sha256", np.array([""]))
        )[0]),
        "RECENT_ROLE_DUAL_DISLOCATION_ROWS_RETAINED": int(np.asarray(
            phase2_meta.get("recent_role_dual_rows", np.array([0]))
        )[0]),
        "RECENT_ROLE_DUAL_DISLOCATION_NEW_ADDITIONS": int(np.asarray(
            phase2_meta.get("recent_role_dual_additions", np.array([0]))
        )[0]),
        "MEDIUM_STRUCTURAL_COMPLEMENT_PAIRS_TARGETED": int(np.asarray(
            phase2_meta.get("medium_structural_pair_registry_rows", np.array([0]))
        )[0]),
        "MEDIUM_STRUCTURAL_COMPLEMENT_REGISTRY_SHA256": str(np.asarray(
            phase2_meta.get("medium_structural_pair_registry_sha256", np.array([""]))
        )[0]),
        "MEDIUM_STRUCTURAL_COMPLEMENT_SCAN": int(np.asarray(
            phase2_meta.get("medium_structural_scan", np.array([0]))
        )[0]),
        "MEDIUM_STRUCTURAL_COMPLEMENT_CELLS": int(np.asarray(
            phase2_meta.get("medium_structural_cells", np.array([0]))
        )[0]),
        "MEDIUM_STRUCTURAL_COMPLEMENT_ROWS_RETAINED": int(np.asarray(
            phase2_meta.get("medium_structural_rows", np.array([0]))
        )[0]),
        "MEDIUM_STRUCTURAL_COMPLEMENT_NEW_ADDITIONS": int(np.asarray(
            phase2_meta.get("medium_structural_additions", np.array([0]))
        )[0]),
        "BASE_SIM_TRIALS": int(sim["base_trials"]),
        "WNBA_CLASSIC_SELECTOR_REVIEW_MIN_TRIALS": WNBA_CLASSIC_SELECTOR_REVIEW_MIN_TRIALS,
        "RARE_EVENT_SHRINKAGE": "BETA_PRIOR_ACTIVE",
        "RARE_EVENT_PRIOR_STRENGTH": WNBA_CLASSIC_RARE_EVENT_PRIOR_STRENGTH,
        "BUBBLE_CANDIDATES": int(len(np.asarray(sim["bubble_indices"]))),
        "BUBBLE_EXTRA_TRIALS_PER_LINEUP": int(sim["extra_trials_per_bubble"]),
        "BUBBLE_EXTRA_TRIALS_TOTAL": int(sim["bubble_extra_trials_total"]),
        "BUBBLE_LINEUPS_UNRESOLVED": 0,
        "SELECTOR_REVIEW_DENSE_CANDIDATES": int(len(np.asarray(sim.get("selector_review_indices", np.empty(0, dtype=int))))),
        "SELECTOR_REVIEW_MIN_TRIALS": int(sim.get("selector_review_min_trials", 0)),
        "SELECTOR_REVIEW_EXTRA_TRIALS_TOTAL": int(sim.get("selector_review_extra_trials_total", 0)),
        "HANDOFF_SURVIVORS": phase2_count,
        "SELECTOR_REVIEWED_LINEUPS": int(board_metrics.get("selector_reviewed", np.array([0]))[0]) if board_metrics else 0,
        "STRICT_SURVIVORS": int(board_metrics.get("eligible_count", np.array([0]))[0]) if board_metrics else 0,
        "CERTIFIED_PREMIUM_GUARD_SIBLING_GROUPS": int(board_metrics.get("certified_sibling_groups_required", np.array([0]))[0]) if board_metrics else 0,
        "CERTIFIED_PREMIUM_GUARD_SIBLING_LINEUPS": int(board_metrics.get("certified_sibling_lineups_required", np.array([0]))[0]) if board_metrics else 0,
        "SCENARIO_LANE_CANDIDATES_ON_BOARD": int(board_metrics.get("scenario_lane_candidates", np.array([0]))[0]) if board_metrics else 0,
        "SCENARIO_LANE_PRIORITY_RANK": int(board_metrics.get("scenario_lane_priority_rank", np.array([0]))[0]) if board_metrics else 0,
        "SCENARIO_LANE_LEADER_CANDIDATE_INDEX": int(board_metrics.get("scenario_lane_leader_candidate_index", np.array([-1]))[0]) if board_metrics else -1,
        "FAKE_FIELD_LINEUPS": int(sim["fake_field_size"]),
        "FINAL_BOARD_SIZE": int(len(board)),
        "FINAL_BOARD_TARGET": int(board_metrics.get("final_board_target", np.array([min(config.board_size, phase2_count)]))[0]) if board_metrics else 0,
        "NONEMPTY_BOARD_POLICY": "APEX_GLOBAL_NONEMPTY_PRODUCTION_BOARD_v1",
        "PORTFOLIO_PREFERENCE_RELAXATION": bool(int(board_metrics.get("portfolio_preference_relaxation", np.array([0]))[0])) if board_metrics else False,
        "HARD_CAP_FALLBACK": bool(int(board_metrics.get("hard_cap_fallback", np.array([0]))[0])) if board_metrics else False,
        "HARD_CAP_INTEGRITY": "PASS" if bool(int(board_metrics.get("hard_cap_integrity", np.array([0]))[0])) else "FAIL",
        "BANKROLL_SELECTOR_PATCH_ID": BANKROLL_SELECTOR_PATCH_ID,
        "BANKROLL_COMPOSITE_PROJECTION_WEIGHT": BANKROLL_COMPOSITE_PROJECTION_WEIGHT,
        "BANKROLL_COMPOSITE_SALARY_REBOUND_WEIGHT": BANKROLL_COMPOSITE_SALARY_REBOUND_WEIGHT,
        "BANKROLL_COMPOSITE_SHORTLIST_MAX": BANKROLL_COMPOSITE_SHORTLIST_MAX,
        "STRICT_ELITE_TAIL_GATE_ROLE": "DIAGNOSTIC_ONLY_NOT_FORWARD_ELIGIBILITY",
        "BANKROLL_RESERVE_APPLIED": bool(int(board_metrics.get("bankroll_reserve_applied", np.array([0]))[0])) if board_metrics else False,
        "BANKROLL_RESERVE_SLOTS": int(board_metrics.get("bankroll_reserve_slots", np.array([0]))[0]) if board_metrics else 0,
        "BANKROLL_RESERVE_CANDIDATE_INDICES": [int(x) for x in board_metrics.get("bankroll_reserve_candidate_indices", np.array([], int))],
        "PLAYER_EXPOSURE_CAP": config.player_exposure_cap,
        "FAMILY_CAP": config.family_cap,
        "FILLERS": 0,
        "RANK_ALL": False,
        "SELECTOR_STATE": selector_state,
        "FINAL_SALARY_RECOMPUTE": [int(x) for x in board_metrics.get("salary", np.array([], int))],
        "VACANCY_BENEFICIARIES": cal.frame.loc[cal.vacancy_beneficiary, "PLAYER"].astype(str).tolist(),
        "DIRECT_VACANCY_ABSORBERS": cal.frame.loc[cal.direct_vacancy_absorber, "PLAYER"].astype(str).tolist(),
        "SALARY_UNLOCK_PLAYERS": cal.frame.loc[cal.salary_unlock, "PLAYER"].astype(str).tolist(),
        "STALE_ROLE_SUPPRESSED_PLAYERS": cal.frame.loc[cal.stale_role_suppressed, "PLAYER"].astype(str).tolist(),
        "ROTATION_ACTIVE_PLAYERS": cal.frame.loc[cal.rotation_active, "PLAYER"].astype(str).tolist(),
        "HISTORICAL_ROLE_REBOUND_PLAYERS": cal.frame.loc[cal.historical_rebound, "PLAYER"].astype(str).tolist(),
        "RECENT_ROLE_REBOUND_PLAYERS": cal.frame.loc[cal.recent_role_rebound, "PLAYER"].astype(str).tolist(),
        "BOARD": board_receipt,
        "RUNTIME_SECONDS": runtime_seconds,
    }
    Path(output_receipt).write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    return receipt


def run(
    pool_path: str | Path,
    field_size: int,
    out_names: Sequence[str],
    output_board: str | Path,
    output_receipt: str | Path,
    seed: int | None = None,
    output_ledger: str | Path | None = None,
    output_identity_map: str | Path | None = None,
    availability_receipt: str | Path | None = None,
    final_availability_receipt: str | Path | None = None,
    execution_id: str | int | None = None,
) -> dict:
    started = time.perf_counter()
    slate_runtime = evaluate_slate_runtime(pool_path, int(field_size))
    budget = slate_runtime["BUDGET"]
    config = RuntimeConfig(
        field_size=int(field_size), seed=int(seed if seed is not None else field_size),
        player_trials=int(budget["player_trials_max"]),
        base_trials=int(budget["base_sim_trials_max"]),
        extra_trials=int(budget["bubble_extra_trials_max"]),
        phase2_global_keep=min(int(budget["phase2_sim_cap"]), 8_000),
        phase2_family_keep=max(64, int(budget["phase2_sim_cap"]) // 4),
        phase2_sim_cap=int(budget["phase2_sim_cap"]),
        adaptive_bubble_max=int(budget["adaptive_bubble_max"]),
    )
    resolved_execution_id = str(execution_id if execution_id is not None else field_size)
    if slate_runtime["ENTRY_WINDOW_EXPIRED"] and os.environ.get("APEX_POSTLOCK_DIAGNOSTIC") != "1":
        result={
            "ENGINE_ID":ENGINE_ID,"RUN_RESULT":"PRODUCTION_FAILURE","EXECUTION_STATE":"PRODUCTION_FAILURE",
            "FAILURE_CODE":"ENTRY_WINDOW_EXPIRED","SLATE_RUNTIME":slate_runtime,"ACTIVE_POOL":0,"OUT_PURGE":[],
            "CALIBRATION_QUALIFIED_PLAYERS":0,"FULL_CALIBRATION_PARITY":"NOT_RUN_ENTRY_WINDOW_EXPIRED",
            "CALIBRATION_CONTRACT_HASH_PHASE1":"NOT_RUN","PHASE2_BUILT_LINEUPS":0,"BASE_SIM_TRIALS":0,
            "BUBBLE_EXTRA_TRIALS_TOTAL":0,"HANDOFF_SURVIVORS":0,"SELECTOR_REVIEWED_LINEUPS":0,
            "FINAL_BOARD_SIZE":0,"FULL_ORDER_LEDGER_ROWS":0,"SEALED_IDENTITY_MAP_ROWS":0,
            "RANK1_OPEN_RESEARCH_STATE":"PROHIBITED_BEFORE_BOARD","BOARD_WALL":"HARD_STOP",
        }
        Path(output_board).write_text("",encoding="utf-8")
        Path(output_receipt).write_text(json.dumps(result,indent=2),encoding="utf-8")
        print(json.dumps(result,indent=2),flush=True)
        return result
    roster_gate = require_prebuild_roster_check(
        availability_receipt, sport="WNBA", mode="CLASSIC", pool_path=pool_path,
        execution_id=resolved_execution_id, field_size=field_size,
    )
    runtime_roster_seal = seal_runtime_roster_gate(roster_gate, pool_path=pool_path, explicit_out_names=out_names)
    verified_out = verified_out_names(roster_gate, out_names)
    assert_runtime_roster_seal(runtime_roster_seal, pool_path=pool_path, explicit_out_names=verified_out)
    cal = load_and_calibrate(pool_path, verified_out, config)
    frozen_phase1_hash = cal.calibration_contract_hash
    assert_runtime_roster_seal(runtime_roster_seal, pool_path=pool_path, explicit_out_names=verified_out)
    legal = enumerate_legal(cal, frozen_phase1_hash)
    assert_runtime_roster_seal(runtime_roster_seal, pool_path=pool_path, explicit_out_names=verified_out)
    phase2, phase2_meta = phase2_family_closure(legal, cal, config, frozen_phase1_hash)
    phase2, recovery_closure_meta = _support2_five_of_six_role_tail_closure(legal, phase2, cal, frozen_phase1_hash, support_threshold=2)
    phase2_meta["recovery_support2_role_tail_closure_rows"] = np.array([int(recovery_closure_meta["FINAL_ROWS"])])
    phase2_meta["recovery_support2_role_tail_additions"] = np.array([int(recovery_closure_meta["ADDITIONS"])])
    assert_runtime_roster_seal(runtime_roster_seal, pool_path=pool_path, explicit_out_names=verified_out)
    sim = simulate_phase3(phase2, legal, cal, config, frozen_phase1_hash)
    assert_runtime_roster_seal(runtime_roster_seal, pool_path=pool_path, explicit_out_names=verified_out)
    selector_review_passes = 0
    for _ in range(3):
        board, board_metrics, selector_state = select_board(phase2, sim, cal, config, frozen_phase1_hash)
        review_idx = np.union1d(
            np.flatnonzero(np.asarray(board_metrics.get("_shortlist_mask", np.zeros(len(phase2), dtype=bool)), dtype=bool)),
            np.asarray(board_metrics.get("_selected_candidate_indices", np.empty(0, dtype=int)), dtype=int),
        )
        before = np.asarray(sim["trials_per_lineup"], dtype=int).copy()
        sim = _resimulate_selector_review_to_min_trials(
            sim, phase2, legal, cal, config, review_idx, WNBA_CLASSIC_SELECTOR_REVIEW_MIN_TRIALS
        )
        selector_review_passes += 1
        after = np.asarray(sim["trials_per_lineup"], dtype=int)
        if np.array_equal(before, after):
            break
    board, board_metrics, selector_state = select_board(phase2, sim, cal, config, frozen_phase1_hash)
    selected_idx_check = np.asarray(board_metrics.get("_selected_candidate_indices", np.empty(0, dtype=int)), dtype=int)
    if selected_idx_check.size and np.any(np.asarray(sim["trials_per_lineup"], dtype=int)[selected_idx_check] < min(WNBA_CLASSIC_SELECTOR_REVIEW_MIN_TRIALS, cal.sims.shape[1])):
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:WNBA_CLASSIC_TERMINAL_SELECTOR_TRIAL_DENSITY")
    if final_availability_receipt is None or not str(final_availability_receipt).strip():
        raise RuntimeError("RUN_INVALID:FINAL_AVAILABILITY_RECHECK_RECEIPT_REQUIRED")
    final_roster_gate = require_prebuild_roster_check(
        final_availability_receipt, sport="WNBA", mode="CLASSIC", pool_path=pool_path,
        execution_id=resolved_execution_id, field_size=field_size, final_selector_recheck=True,
    )
    final_roster_seal = seal_runtime_roster_gate(final_roster_gate, pool_path=pool_path, explicit_out_names=out_names)
    if final_roster_seal.state_version != runtime_roster_seal.state_version:
        raise RuntimeError("RUN_INVALID:FINAL_ROSTER_GATE_STATE_VERSION_DRIFT")
    if final_roster_seal.active_pool_hash != runtime_roster_seal.active_pool_hash:
        raise RuntimeError("RUN_INVALID:FINAL_ROSTER_GATE_ACTIVE_POOL_DRIFT_REBUILD_REQUIRED")
    assert_runtime_roster_seal(final_roster_seal, pool_path=pool_path, explicit_out_names=verified_out)
    board_ready=[]
    for rank, row in enumerate(board, start=1):
        assigned=_assign_slots(row, cal)
        players=[]
        for slot, idx in assigned:
            player=cal.frame.iloc[idx]
            players.append({'slot':slot,'player':str(player['PLAYER']),'team':str(player['TEAM']),'salary':int(player['SAL']),'pos':str(player['POS'])})
        if len(players) != 6 or len({p['player'] for p in players}) != 6:
            raise RuntimeError('RUN_FAIL:WNBA_BOARD_IDENTITY_RECONCILIATION')
        board_ready.append({'rank':rank,'salary':int(board_metrics['salary'][rank-1]),'players':players})
    selected_candidate_indices = np.asarray(board_metrics.get("_selected_candidate_indices", np.array([], dtype=int)), dtype=int)
    selected_lineup_ids = _anonymous_lineup_ids(phase2, cal)[selected_candidate_indices].astype(str).tolist()
    board_lineup_ids = _anonymous_lineup_ids(board, cal).astype(str).tolist()
    if selected_lineup_ids != board_lineup_ids:
        raise RuntimeError("RUN_INVALID:WNBA_BOARD_SELECTOR_LINEUP_ID_MISMATCH_PREWRITE")
    run_artifact_id = hashlib.sha256(
        f"WNBA|CLASSIC|{resolved_execution_id}|{field_size}|{frozen_phase1_hash}|{'|'.join(board_lineup_ids)}".encode("utf-8")
    ).hexdigest()
    for row, lineup_id in zip(board_ready, board_lineup_ids):
        row["LINEUP_ID"] = lineup_id
        row["RUN_ARTIFACT_ID"] = run_artifact_id
    if output_ledger is None:
        receipt_path = Path(output_receipt)
        output_ledger = receipt_path.with_name(receipt_path.stem + "_selector_full_order_ledger.csv")
    ledger_meta = write_selector_full_order_ledger(
        candidates=phase2, sim=sim, cal=cal, config=config,
        board_metrics=board_metrics, output_path=output_ledger,
        execution_id=resolved_execution_id, run_artifact_id=run_artifact_id,
    )
    if int(ledger_meta.get("selected_rows", -1)) != len(board_ready):
        raise RuntimeError("RUN_INVALID:WNBA_SELECTOR_SELECTED_COUNT_MISMATCH")
    ledger_check = pd.read_csv(output_ledger, usecols=["RUN_ARTIFACT_ID","LINEUP_ID","SELECTED","FINAL_RANK"])
    selected_check = (
        ledger_check.loc[ledger_check["SELECTED"].astype(bool)]
        .sort_values("FINAL_RANK", kind="stable")
    )
    if selected_check["RUN_ARTIFACT_ID"].astype(str).nunique() != 1 or str(selected_check["RUN_ARTIFACT_ID"].iloc[0]) != run_artifact_id:
        raise RuntimeError("RUN_INVALID:WNBA_SELECTOR_RUN_ARTIFACT_ID_MISMATCH")
    if selected_check["LINEUP_ID"].astype(str).tolist() != board_lineup_ids:
        raise RuntimeError("RUN_INVALID:WNBA_SELECTOR_BOARD_LINEUP_ID_MISMATCH")
    if output_identity_map is None:
        receipt_path = Path(output_receipt)
        output_identity_map = receipt_path.with_name(receipt_path.stem + "_sealed_identity_map.csv")
    identity_map_meta = write_sealed_lineup_identity_map(
        candidates=phase2, cal=cal, output_path=output_identity_map,
    )
    runtime_seconds = time.perf_counter() - started
    result = render_outputs(
        board=board,
        board_metrics=board_metrics,
        cal=cal,
        config=config,
        pool_path=pool_path,
        output_board=output_board,
        output_receipt=output_receipt,
        phase2_count=len(phase2),
        phase2_meta=phase2_meta,
        legal_count=len(legal),
        sim=sim,
        selector_state=selector_state,
        runtime_seconds=runtime_seconds,
        ledger_meta=ledger_meta, identity_map_meta=identity_map_meta,
    )
    result["PREBUILD_ROSTER_CHECK"] = gate_receipt(roster_gate)
    result["ROSTER_GATE_LIFECYCLE"] = runtime_roster_seal.to_receipt()
    result["FINAL_ROSTER_GATE_LIFECYCLE"] = final_roster_seal.to_receipt()
    result["SLATE_RUNTIME"] = slate_runtime
    result["RUN_ARTIFACT_ID"] = run_artifact_id
    result["SELECTOR_LEDGER_PATH"] = str(output_ledger)
    result["SELECTOR_LEDGER_SHA256"] = str(ledger_meta.get("sha256", ""))
    result["SELECTED_LEDGER_ROWS"] = int(ledger_meta.get("selected_rows", 0))
    result["BOARD_LINEUP_IDS"] = board_lineup_ids
    result["SELECTED_LEDGER_LINEUP_IDS"] = selected_lineup_ids
    result["TERMINAL_ARTIFACT_RECONCILIATION"] = "PASS"
    Path(output_receipt).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({
        'RUN_STATE':'NATIVE_BOARD_READY_FOR_GLOBAL_CORE5',
        'PRODUCTION_TRIGGER_DIRECT_EXECUTION':'PASS',
        'DIAGNOSTIC_ROUTING':'DISABLED',
        'BOARD_FIRST_RENDERING':'NATIVE_SOURCE_READY_ONLY_AFTER_TERMINAL_RECONCILIATION',
        'BOARD_IDENTITY_RECONCILIATION':'PASS',
        'TERMINAL_ARTIFACT_RECONCILIATION':'PASS',
        'RUN_ARTIFACT_ID':run_artifact_id,
        'SELECTOR_LEDGER_PATH':str(output_ledger),
        'SELECTOR_LEDGER_SHA256':str(ledger_meta.get('sha256','')),
        'SELECTED_LEDGER_ROWS':int(ledger_meta.get('selected_rows',0)),
        'FINAL_BOARD_SIZE':len(board_ready),
        'FINAL_BOARD':board_ready,
        'SLATE_RUNTIME':slate_runtime,
    }, indent=2), flush=True)
    result["SLATE_TIME_SOURCE"] = slate_runtime["TIME_SOURCE"]
    result["SLATE_ENTRY_LOCK_LOCAL"] = slate_runtime["ENTRY_LOCK_LOCAL"]
    result["MINUTES_TO_ENTRY_LOCK_AT_START"] = slate_runtime["MINUTES_TO_ENTRY_LOCK"]
    result["PHASE2_SIM_CAP"] = config.phase2_sim_cap
    result["ADAPTIVE_BUBBLE_MAX"] = config.adaptive_bubble_max
    result["BOARD_WALL"] = "HARD_STOP_AFTER_RENDER"
    Path(output_receipt).write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pool", required=True)
    parser.add_argument("--field-size", required=True, type=int)
    parser.add_argument("--out", action="append", default=[])
    parser.add_argument("--availability-receipt", required=True)
    parser.add_argument("--final-availability-receipt", required=True)
    parser.add_argument("--execution-id", required=True)
    parser.add_argument("--board", required=True)
    parser.add_argument("--receipt", required=True)
    parser.add_argument("--ledger")
    parser.add_argument("--identity-map")
    parser.add_argument("--seed", type=int)
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    receipt = run(
        pool_path=args.pool,
        field_size=args.field_size,
        out_names=args.out,
        output_board=args.board,
        output_receipt=args.receipt,
        seed=args.seed,
        output_ledger=args.ledger, output_identity_map=args.identity_map,
        availability_receipt=args.availability_receipt, final_availability_receipt=args.final_availability_receipt,
        execution_id=args.execution_id,
    )
    keys = (
        "ENGINE_ID", "ACTIVE_POOL", "OUT_PURGE", "CALIBRATION_QUALIFIED_PLAYERS",
        "FULL_CALIBRATION_PARITY", "CALIBRATION_CONTRACT_HASH_PHASE1",
        "PHASE2_BUILT_LINEUPS", "BASE_SIM_TRIALS", "BUBBLE_EXTRA_TRIALS_TOTAL",
        "HANDOFF_SURVIVORS", "SELECTOR_REVIEWED_LINEUPS", "FINAL_BOARD_SIZE",
        "FULL_ORDER_LEDGER_ROWS", "SEALED_IDENTITY_MAP_ROWS", "RANK1_OPEN_RESEARCH_STATE", "EXECUTION_STATE",
    )
    for key in keys:
        print(f"{key}={receipt[key]}")
    return 0 if receipt["EXECUTION_STATE"] == "TOOL_PROVEN_EXECUTED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
