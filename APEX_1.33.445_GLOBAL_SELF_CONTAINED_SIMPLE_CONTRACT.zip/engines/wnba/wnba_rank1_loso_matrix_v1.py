#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def field_band(field: int) -> str:
    if field < 1000:
        return "SMALL"
    if field < 3000:
        return "MEDIUM"
    return "LARGE"


def readiness(inventory: dict, output: Path) -> dict:
    pairs = [r for r in inventory.get("ROWS", []) if r.get("COUNTABLE_LOSO_FOLD")]
    distinct = {r.get("PAIR_SHA256") for r in pairs if r.get("PAIR_SHA256")}
    bands = {field_band(int(r["FIELD_SIZE"])) for r in pairs if r.get("FIELD_SIZE")}
    minimum = int(inventory.get("LOSO_MINIMUM_PAIRS", 5))
    reasons = []
    if len(distinct) < minimum:
        reasons.append(f"BYTE_COMPLETE_DISTINCT_RAW_PAIR_COUNT_{len(distinct)}_LT_{minimum}")
    if len(bands) < 2:
        reasons.append(f"FIELD_BAND_COUNT_{len(bands)}_LT_2")
    ready = not reasons
    receipt = {
        "MATRIX_ID": "WNBA_CLASSIC_RANK1_LEAVE_ONE_SLATE_OUT_MATRIX_v1",
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "MODE": "SHADOW_RESEARCH_ONLY",
        "BYTE_COMPLETE_DISTINCT_RAW_PAIRS": len(distinct),
        "FIELD_BANDS": sorted(bands),
        "MINIMUM_REQUIRED": minimum,
        "PREFERRED": int(inventory.get("LOSO_PREFERRED_PAIRS", 10)),
        "LOSO_READY": ready,
        "LOSO_EXECUTED": False,
        "FAIL_CLOSED": not ready,
        "BLOCK_REASONS": reasons,
        "PRODUCTION_PROMOTION_ALLOWED": False,
        "PRODUCTION_BOARD_MUTATED": False,
        "PRODUCTION_ORDER_MUTATED": False,
        "NEXT_ACTION": (
            "EXECUTE_LEAVE_ONE_SLATE_OUT_MATRIX" if ready
            else "ACQUIRE_MISSING_BYTE_COMPLETE_RAW_WNBA_CLASSIC_POOL_PLUS_CONTEST_PAIRS"
        ),
        "INVENTORY_SHA256": sha256(output.parent / "holdout_inventory.json"),
    }
    output.write_text(json.dumps(receipt, indent=2) + "\n")
    return receipt


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--inventory", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    inventory_path = Path(args.inventory)
    inventory = json.loads(inventory_path.read_text())
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    receipt = readiness(inventory, out)
    print(json.dumps(receipt, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
