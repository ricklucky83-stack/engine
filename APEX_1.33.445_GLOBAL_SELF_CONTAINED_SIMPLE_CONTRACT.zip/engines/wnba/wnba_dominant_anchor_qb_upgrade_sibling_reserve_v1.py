from __future__ import annotations

import hashlib
from typing import Callable
import numpy as np

PATCH_ID = "WNBA_CLASSIC_DOMINANT_ANCHOR_QB_UPGRADE_SIBLING_RESERVE_v1"
CONFIG = {
    "shared_players_required": 5,
    "min_qualified_bridge_gain": 1,
    "min_salary": 48000,
    "max_salary_drop_from_anchor": 1000,
    "min_mean_ratio": 0.985,
    "min_p95_ratio": 0.985,
    "min_p99_ratio": 0.985,
    "min_top01_ratio": 0.65,
    "require_expected_dup_le_anchor": True,
    "max_reserved_siblings": 1,
}


def _shared_count(a: np.ndarray, b: np.ndarray) -> int:
    return int(np.intersect1d(a, b, assume_unique=False).size)


def apply_reserve(
    candidates: np.ndarray,
    chosen: np.ndarray,
    *,
    salary: np.ndarray,
    qualified_bridge_count: np.ndarray,
    mean: np.ndarray,
    p95: np.ndarray,
    p99: np.ndarray,
    top01: np.ndarray,
    expected_dup: np.ndarray,
    selector_score: np.ndarray,
    portfolio_valid: Callable[[list[int]], bool],
) -> tuple[np.ndarray, dict]:
    """Reserve one anonymous 5-of-6 sibling when it is a structural QB upgrade.

    The anchor is the first selected lineup. No player/team identity or post-lock result
    is consumed. A qualifying sibling must preserve nearly all simulated tail capacity,
    improve qualified bridge count, and not increase expected duplication.
    """
    chosen = np.asarray(chosen, dtype=int)
    meta = {
        "PATCH_ID": PATCH_ID,
        "TRIGGERED": False,
        "ANCHOR_INDEX": int(chosen[0]) if chosen.size else -1,
        "D1_NEIGHBORS": 0,
        "QUALIFYING_SIBLINGS": 0,
        "RESERVED_SIBLING_INDEX": -1,
        "EVICTED_INDEX": -1,
    }
    if chosen.size < 2 or candidates.size == 0:
        return chosen, meta

    anchor = int(chosen[0])
    anchor_row = candidates[anchor]
    chosen_set = set(map(int, chosen.tolist()))

    d1 = []
    for i, row in enumerate(candidates):
        if i in chosen_set:
            continue
        if _shared_count(anchor_row, row) == CONFIG["shared_players_required"]:
            d1.append(i)
    meta["D1_NEIGHBORS"] = len(d1)
    if not d1:
        return chosen, meta

    def ratio_ok(v: float, base: float, floor: float) -> bool:
        if not np.isfinite(v) or not np.isfinite(base):
            return False
        if base <= 0:
            return v >= base
        return v >= floor * base

    qualifiers = []
    for i in d1:
        if int(qualified_bridge_count[i]) < int(qualified_bridge_count[anchor]) + CONFIG["min_qualified_bridge_gain"]:
            continue
        if float(salary[i]) < CONFIG["min_salary"]:
            continue
        if float(salary[anchor]) - float(salary[i]) > CONFIG["max_salary_drop_from_anchor"]:
            continue
        if not ratio_ok(float(mean[i]), float(mean[anchor]), CONFIG["min_mean_ratio"]):
            continue
        if not ratio_ok(float(p95[i]), float(p95[anchor]), CONFIG["min_p95_ratio"]):
            continue
        if not ratio_ok(float(p99[i]), float(p99[anchor]), CONFIG["min_p99_ratio"]):
            continue
        if not ratio_ok(float(top01[i]), float(top01[anchor]), CONFIG["min_top01_ratio"]):
            continue
        if CONFIG["require_expected_dup_le_anchor"] and float(expected_dup[i]) > float(expected_dup[anchor]) + 1e-15:
            continue
        qualifiers.append(i)

    meta["QUALIFYING_SIBLINGS"] = len(qualifiers)
    if not qualifiers:
        return chosen, meta

    # Identity-blind deterministic preference: bridge gain, tail retention, uniqueness,
    # then existing selector score and candidate index for stable tie-breaking.
    qualifiers.sort(key=lambda i: (
        -int(qualified_bridge_count[i]),
        -float(p99[i]) / max(float(p99[anchor]), 1e-12),
        -float(p95[i]) / max(float(p95[anchor]), 1e-12),
        -float(mean[i]) / max(float(mean[anchor]), 1e-12),
        float(expected_dup[i]),
        -float(selector_score[i]),
        int(i),
    ))

    for sib in qualifiers[: max(1, CONFIG["max_reserved_siblings"] * len(qualifiers))]:
        # Preserve anchor. Evict the weakest currently-selected non-anchor seat that
        # yields a hard-valid portfolio. Search weakest-to-strongest deterministically.
        eviction_order = sorted(
            [int(i) for i in chosen if int(i) != anchor],
            key=lambda i: (float(selector_score[i]), float(p99[i]), float(p95[i]), int(i)),
        )
        for evict in eviction_order:
            proposal = [int(i) for i in chosen if int(i) != evict] + [int(sib)]
            if len(set(proposal)) != len(chosen):
                continue
            if portfolio_valid(proposal):
                # Preserve the board's existing order except replace the evicted seat.
                out = chosen.copy()
                pos = int(np.where(out == evict)[0][0])
                out[pos] = int(sib)
                meta.update({
                    "TRIGGERED": True,
                    "RESERVED_SIBLING_INDEX": int(sib),
                    "EVICTED_INDEX": int(evict),
                })
                payload = f"{anchor}:{sib}:{evict}:" + ",".join(map(str, out.tolist()))
                meta["DECISION_SHA256"] = hashlib.sha256(payload.encode()).hexdigest()
                return out, meta
    return chosen, meta
