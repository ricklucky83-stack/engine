#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, importlib.util, json, subprocess, sys
from pathlib import Path

RUNNER_ID = "WNBA_LOSO_POSTLOCK_RESEARCH_REPLAY_v1"

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def load_runtime(engine_root: Path):
    engine_dir = engine_root / 'engines/wnba'
    if str(engine_dir) not in sys.path:
        sys.path.insert(0, str(engine_dir))
    # Import by canonical module name so Numba's on-disk cache can be rebuilt/resolved
    # without dynamic-module pickle references.
    import importlib
    return importlib.import_module('wnba_classic_raw_pool_runtime_v1')

def run_replay(*, engine_root: Path, pool: Path, contest: Path, field_size: int, output_dir: Path,
               out_names: list[str], raw_holdout_pairs: int, validation_fast: bool=False) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    runtime=load_runtime(engine_root)
    if validation_fast:
        cfg=runtime.RuntimeConfig(field_size=field_size, seed=field_size, player_trials=250, base_trials=100,
                                  extra_trials=0, phase2_global_keep=300, phase2_family_keep=100,
                                  phase2_sim_cap=150, adaptive_bubble_max=0)
    else:
        cfg=runtime.RuntimeConfig(field_size=field_size, seed=field_size)
    # PRELOCK/RESULT-BLIND PHASE. This runner deliberately calls lower-level engine functions,
    # never the live production run entrypoint, so historical replay cannot weaken production live-clock/availability gates.
    cal=runtime.load_and_calibrate(pool, out_names, cfg)
    phase1_hash=cal.calibration_contract_hash
    legal=runtime.enumerate_legal(cal, phase1_hash)
    phase2, _=runtime.phase2_family_closure(legal, cal, cfg, phase1_hash)
    sim=runtime.simulate_phase3(phase2, legal, cal, cfg, phase1_hash)
    board, board_metrics, _=runtime.select_board(phase2, sim, cal, cfg, phase1_hash)
    ledger=output_dir/'selector_ledger.csv'
    identity=output_dir/'sealed_identity_map.csv'
    runtime.write_selector_full_order_ledger(candidates=phase2, sim=sim, cal=cal, config=cfg,
                                             board_metrics=board_metrics, output_path=ledger)
    runtime.write_sealed_lineup_identity_map(candidates=phase2, cal=cal, output_path=identity)
    preseal={
        'EXECUTION_STATE':'TOOL_PROVEN_EXECUTED','RUNNER_ID':RUNNER_ID,'MODE':'SHADOW_RESEARCH_ONLY',
        'LIVE_PRODUCTION_ENTRYPOINT_USED':False,'LIVE_CLOCK_GATE_BYPASSED_RESEARCH_ONLY':True,
        'AVAILABILITY_GATE_BYPASSED_RESEARCH_ONLY':True,'PRODUCTION_GATES_MUTATED':False,
        'POSTLOCK_RESULTS_READ_PRESEAL':False,'PRODUCTION_MUTATED':False,
        'FIELD_SIZE':field_size,'POOL_SHA256':sha256(pool),'PHASE2_ROWS':int(len(phase2)),
        'SELECTOR_REVIEWED':int(len(phase2)),'BOARD_SIZE':int(len(board)),
        'LEDGER_SHA256':sha256(ledger),'IDENTITY_MAP_SHA256':sha256(identity),
    }
    preseal_path=output_dir/'research_replay_preseal.json'
    preseal_path.write_text(json.dumps(preseal,indent=2)+'\n')
    # POSTLOCK PHASE begins only after prelock artifacts and hashes are sealed.
    shadow=output_dir/'shadow_order.csv'; shadow_receipt=output_dir/'shadow_receipt.json'
    subprocess.run([sys.executable,str(engine_root/'engines/wnba/wnba_rank1_shadow_research_v1.py'),
                    '--ledger',str(ledger),'--output-order',str(shadow),'--output-receipt',str(shadow_receipt),
                    '--raw-holdout-pairs',str(raw_holdout_pairs)],check=True,cwd=engine_root)
    match=output_dir/'postlock_match.json'
    subprocess.run([sys.executable,str(engine_root/'engines/wnba/wnba_postlock_contest_matcher_v1.py'),
                    '--contest',str(contest),'--pool',str(pool),'--identity-map',str(identity),
                    '--ledger',str(ledger),'--shadow-order',str(shadow),'--output',str(match)],check=True,cwd=engine_root)
    matched=json.loads(match.read_text())
    result={**preseal,'POSTLOCK_RESULTS_READ_AFTER_SEAL':True,'POSTLOCK_MATCH':matched,
            'CONTEST_SHA256':sha256(contest),'PRODUCTION_MUTATED':False}
    (output_dir/'research_replay_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument('--engine-root',required=True); p.add_argument('--pool',required=True); p.add_argument('--contest',required=True)
    p.add_argument('--field-size',required=True,type=int); p.add_argument('--output-dir',required=True)
    p.add_argument('--raw-holdout-pairs',required=True,type=int); p.add_argument('--out',action='append',default=[])
    p.add_argument('--validation-fast',action='store_true')
    a=p.parse_args()
    r=run_replay(engine_root=Path(a.engine_root),pool=Path(a.pool),contest=Path(a.contest),field_size=a.field_size,
                 output_dir=Path(a.output_dir),out_names=a.out,raw_holdout_pairs=a.raw_holdout_pairs,validation_fast=a.validation_fast)
    print(json.dumps({'EXECUTION_STATE':r['EXECUTION_STATE'],'FIELD_SIZE':r['FIELD_SIZE'],
                      'PHASE2_ROWS':r['PHASE2_ROWS'],'BOARD_SIZE':r['BOARD_SIZE'],
                      'WINNER_BORN_PHASE2':r['POSTLOCK_MATCH']['WINNER_BORN_PHASE2'],
                      'WINNER_SELECTED_TO_PRODUCTION_BOARD':r['POSTLOCK_MATCH']['WINNER_SELECTED_TO_PRODUCTION_BOARD']},indent=2))
    return 0

if __name__=='__main__': raise SystemExit(main())
