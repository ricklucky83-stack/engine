from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from numba import njit

_STATE_ROOT = Path(__file__).resolve().parents[2]
if str(_STATE_ROOT) not in sys.path:
    sys.path.insert(0, str(_STATE_ROOT))
from engines.common import apex_global_market_independent_regime_kernel_v1 as regime_kernel
from engines.common import apex_field_relative_extreme_value_portfolio_v2 as extreme_value_v2
from engines.cfb import cfb_showdown_opportunity_model_v1 as opportunity_model

ENGINE_ID = "APEX_CFB_SHOWDOWN_RAW_POOL_RUNTIME_v1"
SPORT = "CFB"
MODE = "SHOWDOWN"
PLATFORM = "DRAFTKINGS"
SALARY_MIN = 40_000
SALARY_MAX = 50_000
ROSTER_SIZE = 6
MAX_FROM_TEAM = 5
GLOBAL_SELECTOR_PATCH = "APEX_GLOBAL_FIELD_RELATIVE_EXTREME_VALUE_PORTFOLIO_SELECTOR_v1"
TOP5_POLICY = "APEX_GLOBAL_TOP5_HIGH_CONFIDENCE_PARLAY_v1"
HANDOFF_PATCH = "HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1"
REGIME_PATCH = regime_kernel.PATCH_ID
CFB_ROLE_REGIME_PATCH = "CFB_SHOWDOWN_MARKET_INDEPENDENT_REGIME_AND_MISSING_ROLE_NEUTRAL_PRIOR_v1"
CFB_CALIBRATION_PATCH = "CFB_SHOWDOWN_TRUE_TOP01_CAPTAIN_SCRIPT_AND_ROLE_CONCENTRATION_CALIBRATION_v2"
CFB_ROLE_COMPLETE_CPT_PATCH = "CFB_SD_ATOMIC_ROLE_COMPLETE_SIX_SET_CPT_CLOSURE_v1"
CFB_OPPORTUNITY_PATCH = opportunity_model.PATCH_ID
CFB_RECURRENCE_SELECTOR_PATCH = "CFB_SHOWDOWN_COMMON_WORLD_RECURRENCE_PORTFOLIO_v1"
CFB_CHUNK_STREAM_PATCH = "CFB_SHOWDOWN_ENGINE_OWNED_CHUNK_STREAM_RESUME_v1"
CFB_CHUNK_STREAM_CONTROLLER_MODULE = "engines.cfb.cfb_showdown_chunk_stream_controller_v1"
CFB_CONSENSUS_BRIDGE_PATCH = "CFB_SHOWDOWN_RECURRENCE_INCUMBENT_CONSENSUS_BRIDGE_v2"
CFB_NUMERIC_FIELD_PATCH = "CFB_SHOWDOWN_PUBLIC_FIELD_PROBABILITY_NORMALIZATION_v1"
CFB_BALANCED_VALUE_HEDGE_PATCH = "CFB_SHOWDOWN_BALANCED_VALUE_CPT_ANCHOR_RETENTION_AND_SAME_ROLE_HEDGE_v3"
CFB_KNOWN_ROLE_5_1_RESERVE_PATCH = "CFB_SHOWDOWN_KNOWN_ROLE_5_1_WR_CPT_RECURRENCE_RESERVE_v1"
CFB_DUAL_QB_VALUE_RESERVE_PATCH = "CFB_SHOWDOWN_BALANCED_DUAL_QB_VALUE_FAMILY_RESERVE_v1"
CFB_QB_5_1_MISSING_ROLE_FAMILY_RESERVE_PATCH = "CFB_SHOWDOWN_QB_CPT_5_1_MISSING_ROLE_FAMILY_RECALL_RESERVE_v1"
CFB_EXTERNAL_ROLE_AUTHORITY_PATCH = "CFB_SHOWDOWN_EXTERNAL_PREGAME_ROLE_AUTHORITY_RECOVERY_v1"
CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH = "CFB_SHOWDOWN_RECOVERED_STARTER_SAME_ROLE_SALARY_RELEASE_HEDGE_v1"
CFB_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_PATCH = "CFB_SD_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_RESERVE_v1"
CFB_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_PATCH = "CFB_SHOWDOWN_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_v1"
CFB_PREBIRTH_ROLE_AUTHORITY_PATCH = "CFB_SD_PREBIRTH_EXTERNAL_ROLE_AUTHORITY_v1"
CFB_CORE5_QUALITY_FINALIZER_PATCH = "CFB_SHOWDOWN_CORE5_QUALITY_FINALIZER_v1"
CFB_PRELOCK_HISTORY_USAGE_FLOOR_PATCH = "CFB_SHOWDOWN_PRELOCK_HISTORY_USAGE_FLOOR_v1"
CFB_STALE_PRESENT_ROLE_AUTHORITY_PATCH = "CFB_SHOWDOWN_STALE_PRESENT_ROLE_AUTHORITY_v1"
CFB_LARGE_FAVORITE_BALANCED_RB_CPT_DUAL_QB_BIRTH_PATCH = "CFB_SHOWDOWN_LARGE_FAVORITE_BALANCED_RB_CPT_DUAL_QB_BIRTH_v1"
CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_PATCH = "CFB_SHOWDOWN_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_CANARY_v1"
CFB_LIVE_EXECUTION_HARD_CONTRACT_PATCH = "CFB_SHOWDOWN_LIVE_EXECUTION_HARD_CONTRACT_v1"

POS_ALLOWED = {"QB", "RB", "WR", "TE", "K", "UNK"}
HARD_OUT = {"OUT", "IR", "DNP", "REST", "DOUBTFUL", "SUSP", "SUSPENDED"}


def _stable_hash(x: Any) -> str:
    return hashlib.sha256(json.dumps(x, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def _array_hash(a: np.ndarray) -> str:
    x = np.ascontiguousarray(a)
    return hashlib.sha256(x.view(np.uint8)).hexdigest()


def _pct(v: np.ndarray) -> np.ndarray:
    v = np.asarray(v, dtype=np.float64)
    order = np.argsort(v, kind="stable")
    out = np.empty(len(v), dtype=np.float64)
    out[order] = (np.arange(len(v), dtype=np.float64) + 0.5) / max(1, len(v))
    return out


def _norm_col(df: pd.DataFrame, name: str, default: float = 0.0) -> np.ndarray:
    if name not in df:
        return np.full(len(df), default, dtype=np.float64)
    return pd.to_numeric(df[name], errors="coerce").fillna(default).to_numpy(np.float64)


@dataclass(frozen=True)
class Config:
    field_size: int
    seed: int = 352082926
    player_trials: int = 50_000
    base_trials: int = 10_000
    extra_trials: int = 10_000
    bubble_cap: int = 96
    final_board_size: int = 5

    @property
    def phase2_keep(self) -> int:
        return int(min(8_000, max(3_000, self.field_size * 12)))

    def validate(self) -> None:
        if self.field_size <= 0:
            raise RuntimeError("RUN_INVALID:INVALID_FIELD_SIZE")
        if self.player_trials < 50_000:
            raise RuntimeError("ENGINE_INTEGRITY_HALT:PHASE1_MC_TRIALS_LT_50000")
        if self.base_trials < 10_000:
            raise RuntimeError("ENGINE_INTEGRITY_HALT:BASE_SIM_TRIALS_LT_10000")


@dataclass
class Calibration:
    frame: pd.DataFrame
    names: np.ndarray
    pos: np.ndarray
    team: np.ndarray
    opp: np.ndarray
    salary: np.ndarray
    mu: np.ndarray
    sigma: np.ndarray
    p95: np.ndarray
    p99: np.ndarray
    ownership: np.ndarray
    captain_ownership: np.ndarray
    role_strength: np.ndarray
    role_uncertainty: np.ndarray
    phase1_hash: str
    player_sim_hash: str
    out_names: list[str]
    inactive_names: list[str]
    missing_role_names: list[str]
    phase1_regime_receipt: dict[str, Any]


def _contest_entry_limit(cfg: Config) -> int:
    """Return the explicit contest entry limit; never invent a live default."""
    vals=[]
    for key in ("APEX_USER_ENTRIES", "APEX_MAX_ENTRIES"):
        raw=os.environ.get(key)
        if raw in (None, ""):
            continue
        try:
            v=int(raw)
        except Exception as exc:
            raise RuntimeError(f"RUN_INVALID:CFB_ENTRY_LIMIT_NONINTEGER:{key}={raw}") from exc
        if v < 1 or v > int(cfg.field_size):
            raise RuntimeError(f"RUN_INVALID:CFB_ENTRY_LIMIT:{v}")
        vals.append((key,v))
    if not vals:
        raise RuntimeError("RUN_INVALID:CFB_ENTRY_LIMIT_REQUIRED_NO_DEFAULT")
    uniq={v for _k,v in vals}
    if len(uniq) != 1:
        raise RuntimeError("RUN_INVALID:CFB_ENTRY_LIMIT_AUTHORITY_CONFLICT:"+",".join(f"{k}={v}" for k,v in vals))
    return int(vals[0][1])


def _depth_numeric(cal: Calibration) -> np.ndarray:
    if "DEPTH" not in cal.frame:
        return np.full(len(cal.names), np.nan, dtype=np.float64)
    return pd.to_numeric(cal.frame["DEPTH"], errors="coerce").to_numpy(np.float64)


def _favorite_team_prelock(cal: Calibration) -> tuple[str,str,dict[str,float]]:
    teams=list(dict.fromkeys(map(str,cal.team.tolist())))
    if len(teams) != 2:
        raise RuntimeError("RUN_INVALID:CFB_SHOWDOWN_EXPECTED_TWO_TEAMS")
    frame=cal.frame
    metrics: dict[str,float]={}
    if "SPRD" in frame:
        for tm in teams:
            x=pd.to_numeric(frame.loc[frame["TEAM"].astype(str)==tm,"SPRD"],errors="coerce").dropna()
            if len(x): metrics[tm]=float(np.median(x.to_numpy(np.float64)))
        if len(metrics)==2 and metrics[teams[0]] != metrics[teams[1]]:
            fav=min(metrics,key=metrics.get); dog=teams[1] if fav==teams[0] else teams[0]
            return str(fav),str(dog),metrics
    if "Win %" in frame:
        wins={}
        for tm in teams:
            x=pd.to_numeric(frame.loc[frame["TEAM"].astype(str)==tm,"Win %"],errors="coerce").dropna()
            if len(x): wins[tm]=float(np.median(x.to_numpy(np.float64)))
        if len(wins)==2 and wins[teams[0]] != wins[teams[1]]:
            fav=max(wins,key=wins.get); dog=teams[1] if fav==teams[0] else teams[0]
            return str(fav),str(dog),wins
    if "TM Score" in frame:
        scores={}
        for tm in teams:
            x=pd.to_numeric(frame.loc[frame["TEAM"].astype(str)==tm,"TM Score"],errors="coerce").dropna()
            if len(x): scores[tm]=float(np.median(x.to_numpy(np.float64)))
        if len(scores)==2 and scores[teams[0]] != scores[teams[1]]:
            fav=max(scores,key=scores.get); dog=teams[1] if fav==teams[0] else teams[0]
            return str(fav),str(dog),scores
    # Deterministic fallback only when market/team-score evidence is tied or absent.
    mu_by={tm:float(np.sum(cal.mu[np.asarray(cal.team,dtype=object)==tm])) for tm in teams}
    fav=max(mu_by,key=mu_by.get); dog=teams[1] if fav==teams[0] else teams[0]
    return str(fav),str(dog),mu_by


def _row_salary_cal(row: tuple[int,...] | np.ndarray, cal: Calibration) -> int:
    r=list(map(int,row))
    return int((3*int(cal.salary[r[0]]))//2 + sum(int(cal.salary[x]) for x in r[1:]))


def _raw_prelock_projection(row: tuple[int,...] | np.ndarray, cal: Calibration) -> float:
    fpts=_norm_col(cal.frame,"FPTS")
    r=list(map(int,row))
    return float(1.5*fpts[r[0]] + sum(fpts[x] for x in r[1:]))


def _known_role_5_1_qb_cpt_core_completion_lane(cal: Calibration, max_rows: int = 16) -> list[tuple[int,int,int,int,int,int]]:
    """Player-name-blind prelock lane documented by CAR SHOP's 2026-09-12 promotion."""
    fav,dog,_=_favorite_team_prelock(cal)
    depth=_depth_numeric(cal)
    fpts=_norm_col(cal.frame,"FPTS")
    fav_qb=[i for i in range(len(cal.names)) if str(cal.team[i])==fav and str(cal.pos[i])=="QB" and np.isfinite(depth[i]) and depth[i]<=1.25]
    dog_qb=[i for i in range(len(cal.names)) if str(cal.team[i])==dog and str(cal.pos[i])=="QB" and np.isfinite(depth[i]) and depth[i]<=1.25]
    same=[i for i in range(len(cal.names)) if str(cal.team[i])==fav and str(cal.pos[i])!="QB" and np.isfinite(depth[i]) and depth[i]<=2.25]
    cand=[]
    for c in fav_qb:
        for oq in dog_qb:
            for four in itertools.combinations(same,4):
                inds=[c,oq,*four]
                if sum(str(cal.pos[x])=="QB" for x in inds)!=2: continue
                if sum(str(cal.team[x])==fav and str(cal.pos[x])=="RB" for x in inds)<1: continue
                if sum(str(cal.team[x])==fav and str(cal.pos[x]) in {"WR","TE"} for x in inds)<2: continue
                row=(int(c),)+tuple(sorted((int(oq),*map(int,four))))
                sal=_row_salary_cal(row,cal)
                if not (SALARY_MIN<=sal<=SALARY_MAX): continue
                proj=float(1.5*fpts[c]+fpts[list(row[1:])].sum())
                cand.append((proj,sal,row))
    cand.sort(key=lambda x:(x[0],x[1],x[2]),reverse=True)
    out=[]; seen=set()
    for _proj,_sal,row in cand:
        if row in seen: continue
        seen.add(row); out.append(row)
        if len(out)>=max_rows: break
    return out


def _favorite_control_rb_cpt_4_2_single_qb_lane(cal: Calibration, max_families: int = 16) -> list[tuple[int,int,int,int,int,int]]:
    """Bounded prelock championship-family lane proven on CFB Showdown contest 195476934."""
    fav,dog,_=_favorite_team_prelock(cal)
    depth=_depth_numeric(cal)
    value=cal.p99/np.maximum(1.0,cal.salary.astype(float)/1000.0)
    # Preserve the sealed same-slate candidate exactly: calibrated uncertainty is
    # treated as bounded tail optionality inside this 16-family canary lane.
    pscore=(0.34*_pct(cal.p99)+0.22*_pct(cal.p95)+0.18*_pct(cal.mu)+0.12*_pct(value)+
            0.10*_pct(cal.role_strength)+0.04*_pct(cal.role_uncertainty))
    fav_rbs=[i for i in range(len(cal.names)) if str(cal.team[i])==fav and str(cal.pos[i])=="RB" and np.isfinite(depth[i]) and depth[i]<=2.0]
    fav_qbs=[i for i in range(len(cal.names)) if str(cal.team[i])==fav and str(cal.pos[i])=="QB" and np.isfinite(depth[i]) and depth[i]<=1.5]
    fav_pool=[i for i in range(len(cal.names)) if str(cal.team[i])==fav]
    dog_pool=[i for i in range(len(cal.names)) if str(cal.team[i])==dog]
    lane=[]
    for c in fav_rbs:
        for q in fav_qbs:
            fpool=[i for i in fav_pool if i not in {c,q} and str(cal.pos[i])!="QB"]
            for f2,f3 in itertools.combinations(fpool,2):
                for d1,d2 in itertools.combinations(dog_pool,2):
                    inds=[int(c),int(q),int(f2),int(f3),int(d1),int(d2)]
                    if sum(str(cal.pos[i])=="QB" for i in inds)!=1: continue
                    if sum(str(cal.pos[i]) in {"WR","TE"} for i in inds)<3: continue
                    row=(int(c),)+tuple(sorted(inds[1:]))
                    sal=_row_salary_cal(row,cal)
                    if not (47_000<=sal<=SALARY_MAX): continue
                    score=float(1.5*pscore[c]+sum(pscore[i] for i in inds[1:]))
                    score += 0.04*sum(str(cal.pos[i]) in {"WR","TE"} for i in inds)
                    score += 0.025*sum(str(cal.pos[i])=="K" for i in inds)
                    score += 0.02*sum(str(cal.team[i])==dog and str(cal.pos[i]) in {"WR","TE"} for i in inds)
                    lane.append((score,sal,row))
    lane.sort(key=lambda x:(x[0],x[1],x[2]),reverse=True)
    out=[]; seen=set()
    for _score,_sal,row in lane:
        if row in seen: continue
        seen.add(row); out.append(row)
        if len(out)>=max_families: break
    return out


def _append_bounded_rows(seed_rows: np.ndarray, additions: list[tuple[int,int,int,int,int,int]]) -> tuple[np.ndarray,int]:
    existing={tuple(map(int,r.tolist())) for r in np.asarray(seed_rows)}
    add=[]
    for row in additions:
        tr=tuple(map(int,row))
        if tr not in existing:
            existing.add(tr); add.append(tr)
    if not add: return np.asarray(seed_rows,dtype=np.int16),0
    return np.vstack([np.asarray(seed_rows,dtype=np.int16),np.asarray(add,dtype=np.int16)]),len(add)


def _large_favorite_balanced_rb_cpt_dual_qb_lane(cal: Calibration, max_rows: int = 16) -> list[tuple[int,int,int,int,int,int]]:
    """Bounded prelock 3-3 hedge for large-favorite RB-CPT / dual-QB scripts.

    The lane is deliberately narrow: favorite RB captain, both verified starting QBs,
    one cheap/value favorite WR/TE, and the underdog's starting RB plus starting
    WR/TE. It uses only frozen market, role, salary, and calibrated tail inputs.
    """
    fav,dog,metrics=_favorite_team_prelock(cal)
    fav_spread=float(metrics.get(fav,0.0)) if isinstance(metrics,dict) else 0.0
    if not math.isfinite(fav_spread) or fav_spread > -14.5:
        return []
    depth=_depth_numeric(cal)
    value=cal.p99/np.maximum(1.0,cal.salary.astype(float)/1000.0)
    fav_rbs=[i for i in range(len(cal.names)) if str(cal.team[i])==fav and str(cal.pos[i])=='RB' and np.isfinite(depth[i]) and depth[i]<=2.25]
    fav_qbs=[i for i in range(len(cal.names)) if str(cal.team[i])==fav and str(cal.pos[i])=='QB' and np.isfinite(depth[i]) and depth[i]<=1.25]
    dog_qbs=[i for i in range(len(cal.names)) if str(cal.team[i])==dog and str(cal.pos[i])=='QB' and np.isfinite(depth[i]) and depth[i]<=1.25]
    fav_value_pc=[i for i in range(len(cal.names)) if str(cal.team[i])==fav and str(cal.pos[i]) in {'WR','TE'} and int(cal.salary[i])<=3000 and float(value[i])>=4.0]
    dog_rbs=[i for i in range(len(cal.names)) if str(cal.team[i])==dog and str(cal.pos[i])=='RB' and np.isfinite(depth[i]) and depth[i]<=1.25]
    dog_pc=[i for i in range(len(cal.names)) if str(cal.team[i])==dog and str(cal.pos[i]) in {'WR','TE'} and np.isfinite(depth[i]) and depth[i]<=1.25]
    cand=[]
    for c in fav_rbs:
        for fq in fav_qbs:
            for dq in dog_qbs:
                for fp in fav_value_pc:
                    for drb in dog_rbs:
                        for dpc in dog_pc:
                            row=(int(c),)+tuple(sorted((int(fq),int(dq),int(fp),int(drb),int(dpc))))
                            if len(set(row))!=ROSTER_SIZE: continue
                            sal=_row_salary_cal(row,cal)
                            if not (SALARY_MIN<=sal<=SALARY_MAX): continue
                            cand.append(row)
    cand=list(dict.fromkeys(cand))
    if not cand: return []
    arr=np.asarray(cand,dtype=np.int16); feat=_lineup_features(arr,cal)
    order=sorted(range(len(arr)),key=lambda i:(float(feat['score'][i]),float(feat['p99'][i]),float(feat['mean'][i]),int(feat['salary'][i]),tuple(map(int,arr[i]))),reverse=True)
    return [tuple(map(int,arr[i])) for i in order[:min(int(max_rows),len(order))]]


def _cfb_showdown_production_birth_reserves(seed_rows: np.ndarray, cal: Calibration, cfg: Config) -> tuple[np.ndarray,dict[str,Any]]:
    entry_limit=_contest_entry_limit(cfg)
    if entry_limit<20:
        return np.asarray(seed_rows,dtype=np.int16),{
            'CFB_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_PATCH_ID':CFB_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_PATCH,
            'CFB_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_PATCH_ID':CFB_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_PATCH,
            'CFB_PRODUCTION_CANARY_GATE':False,'CFB_PRODUCTION_CANARY_REASON':'ENTRY_LIMIT_LT_20','CFB_CONTEST_ENTRY_LIMIT':int(entry_limit)}
    qb51=_known_role_5_1_qb_cpt_core_completion_lane(cal,16)
    out,n1=_append_bounded_rows(seed_rows,qb51)
    rb42=_favorite_control_rb_cpt_4_2_single_qb_lane(cal,16)
    out,n2=_append_bounded_rows(out,rb42)
    rb33=_large_favorite_balanced_rb_cpt_dual_qb_lane(cal,24)
    out,n3=_append_bounded_rows(out,rb33)
    return out,{
        'CFB_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_PATCH_ID':CFB_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_PATCH,
        'CFB_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_PATCH_ID':CFB_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_PATCH,
        'CFB_LARGE_FAVORITE_BALANCED_RB_CPT_DUAL_QB_BIRTH_PATCH_ID':CFB_LARGE_FAVORITE_BALANCED_RB_CPT_DUAL_QB_BIRTH_PATCH,
        'CFB_PRODUCTION_CANARY_GATE':True,'CFB_CONTEST_ENTRY_LIMIT':int(entry_limit),
        'CFB_5_1_QB_CPT_BIRTH_CANDIDATES':int(len(qb51)),'CFB_5_1_QB_CPT_BIRTH_ROWS_ADDED':int(n1),
        'CFB_4_2_RB_CPT_SINGLE_QB_BIRTH_CANDIDATES':int(len(rb42)),'CFB_4_2_RB_CPT_SINGLE_QB_BIRTH_ROWS_ADDED':int(n2),
        'CFB_3_3_RB_CPT_DUAL_QB_BIRTH_CANDIDATES':int(len(rb33)),'CFB_3_3_RB_CPT_DUAL_QB_BIRTH_ROWS_ADDED':int(n3),
        'CFB_PRODUCTION_CANARY_POSTLOCK_SIGNAL_USED':False,'CFB_PRODUCTION_CANARY_PLAYER_NAME_CONSTANTS_USED':False}


def _prepare_pool(path: str | Path) -> tuple[pd.DataFrame, list[str], list[str], list[str]]:
    df = pd.read_csv(path)
    req = {"PLAYER", "POS", "TEAM", "OPP", "SAL", "FPTS"}
    miss = sorted(req - set(df.columns))
    if miss:
        raise RuntimeError("RUN_INVALID:CFB_SHOWDOWN_POOL_FIELDS_MISSING:" + ",".join(miss))
    if df.empty or df["PLAYER"].astype(str).duplicated().any():
        raise RuntimeError("RUN_INVALID:CFB_SHOWDOWN_POOL_EMPTY_OR_DUPLICATE_PLAYER")

    df = df.copy()
    raw_pos = df["POS"].fillna("").astype(str).str.split("/").str[0].str.upper().str.strip()
    df["POS_BASE"] = raw_pos.where(raw_pos.isin({"QB", "RB", "WR", "TE", "K"}), "UNK")
    df["TEAM"] = df["TEAM"].astype(str).str.upper().str.strip()
    df["OPP"] = df["OPP"].astype(str).str.upper().str.strip()
    inj = df.get("INJ", pd.Series([""] * len(df), index=df.index)).fillna("").astype(str).str.upper().str.strip()
    out_mask = inj.isin(HARD_OUT)
    out_names = df.loc[out_mask, "PLAYER"].astype(str).tolist()

    sal = _norm_col(df, "SAL")
    invalid = (~np.isfinite(sal)) | (sal <= 0) | (sal > SALARY_MAX) | (df["TEAM"].eq(""))
    if np.any(invalid & ~out_mask):
        bad = df.loc[invalid & ~out_mask, "PLAYER"].astype(str).tolist()[:20]
        raise RuntimeError("RUN_INVALID:CFB_SHOWDOWN_INVALID_ACTIVE_PLAYER_CONTRACT:" + ",".join(bad))

    # DK Showdown roster legality is positionless. Missing provider position/workload
    # evidence is uncertainty, not zero opportunity. Only explicit hard-out evidence
    # removes an otherwise contest-eligible player from the forward pool.
    df = df.loc[~out_mask].reset_index(drop=True)
    if len(df) < ROSTER_SIZE:
        raise RuntimeError("RUN_INVALID:CFB_SHOWDOWN_ACTIVE_POOL_INFEASIBLE")
    if df["TEAM"].nunique() != 2:
        raise RuntimeError("RUN_INVALID:CFB_SHOWDOWN_EXPECTED_TWO_TEAMS")

    proj_pa = _norm_col(df, "Proj PA")
    proj_ra = _norm_col(df, "Proj RA")
    proj_tar = _norm_col(df, "Proj TAR")
    touches = _norm_col(df, "TOUCHES")
    fpts = _norm_col(df, "FPTS")
    role_signal = proj_pa + proj_ra + proj_tar + touches
    hist_pa = np.maximum(0.0,_norm_col(df,"Pass Att"))
    hist_ra = np.maximum(0.0,_norm_col(df,"Rush Att"))
    hist_tar = np.maximum(0.0,_norm_col(df,"TAR"))
    hist_rec = np.maximum(0.0,_norm_col(df,"REC"))
    # A single garbage-time touch/target is not enough to convert a zero-role row
    # into known role. Require repeated usage before history can close the missing-
    # role flag.
    hist_repeated = (hist_pa >= 8.0) | (hist_ra >= 3.0) | (hist_tar >= 2.0) | (hist_rec >= 2.0)
    missing_role = (role_signal <= 0.0) & (fpts <= 0.0) & (~hist_repeated)
    missing_role_names = df.loc[missing_role, "PLAYER"].astype(str).tolist()
    inactive_names: list[str] = []
    return df, sorted(out_names), inactive_names, sorted(missing_role_names)


def _player_parameters(df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    pos = df["POS_BASE"].astype(str).to_numpy(object)
    salary = np.maximum(1.0, _norm_col(df, "SAL"))
    source_fpts = np.maximum(0.0, _norm_col(df, "FPTS"))
    pa = np.maximum(0.0, _norm_col(df, "Proj PA"))
    ra = np.maximum(0.0, _norm_col(df, "Proj RA"))
    tar = np.maximum(0.0, _norm_col(df, "Proj TAR"))
    touches = np.maximum(0.0, _norm_col(df, "TOUCHES"))
    depth_raw = df.get("DEPTH", pd.Series(["-"] * len(df), index=df.index)).astype(str)
    depth = pd.to_numeric(depth_raw, errors="coerce").fillna(8.0).to_numpy(np.float64)

    # File-law prelock history floor. DraftKings player pools already carry recent
    # per-game passing/rushing/receiving usage, but the legacy Showdown model used
    # only projection columns. Preserve projections as authority while preventing a
    # zero/stale projection from erasing demonstrated prelock usage. No postlock or
    # player-name information participates.
    hist_pa = np.maximum(0.0, _norm_col(df, "Pass Att"))
    hist_py = np.maximum(0.0, _norm_col(df, "Pass Yds"))
    hist_ptd = np.maximum(0.0, _norm_col(df, "Pass TD"))
    hist_int = np.maximum(0.0, _norm_col(df, "INT"))
    hist_ra = np.maximum(0.0, _norm_col(df, "Rush Att"))
    hist_ry = np.maximum(0.0, _norm_col(df, "Rush Yds"))
    hist_rtd = np.maximum(0.0, _norm_col(df, "Rush TD"))
    hist_rec = np.maximum(0.0, _norm_col(df, "REC"))
    hist_tar = np.maximum(0.0, _norm_col(df, "TAR"))
    hist_recy = np.maximum(0.0, _norm_col(df, "Rec Yds"))
    hist_rectd = np.maximum(0.0, _norm_col(df, "Rec TD"))
    hist_fpts = (0.04*hist_py + 4.0*hist_ptd - hist_int + 0.10*hist_ry + 6.0*hist_rtd + hist_rec + 0.10*hist_recy + 6.0*hist_rectd)
    source_role_signal = pa + ra + tar + touches
    source_missing = (source_role_signal <= 0.0) & (source_fpts <= 0.0)
    hist_active = (hist_pa + hist_ra + hist_tar + hist_rec) > 0.0
    primary_role = np.where(pos == "QB", depth <= 1.25, depth <= 2.25)
    repeated_history = (hist_pa >= 8.0) | (hist_ra >= 3.0) | (hist_tar >= 2.0) | (hist_rec >= 2.0)
    history_floor_gate = hist_active & (primary_role | (source_missing & repeated_history))
    pa = np.where(history_floor_gate, np.maximum(pa, 0.75*hist_pa), pa)
    ra = np.where(history_floor_gate, np.maximum(ra, 0.75*hist_ra), ra)
    tar = np.where(history_floor_gate, np.maximum(tar, 0.75*hist_tar), tar)
    touches = np.where(history_floor_gate, np.maximum(touches, 0.75*(hist_ra+hist_tar)), touches)
    fpts = np.where(history_floor_gate, np.maximum(source_fpts, 0.85*hist_fpts), source_fpts)
    role_signal = pa + ra + tar + touches
    missing_role = (role_signal <= 0.0) & (fpts <= 0.0)

    role_mu = np.zeros(len(df), dtype=np.float64)
    for i, p in enumerate(pos):
        if p == "QB":
            role_mu[i] = 6.0 + 0.27 * pa[i] + 0.34 * ra[i]
        elif p == "RB":
            role_mu[i] = 0.62 * ra[i] + 1.30 * tar[i] + 0.08 * touches[i]
        elif p == "WR":
            role_mu[i] = 1.60 * tar[i] + 0.22 * ra[i] + 0.05 * touches[i]
        elif p == "TE":
            role_mu[i] = 1.46 * tar[i] + 0.18 * ra[i] + 0.04 * touches[i]
        elif p == "K":
            role_mu[i] = fpts[i]
        else:
            role_mu[i] = 0.0

    blend = np.where(pos == "K", 0.0, 0.72)
    mu = blend * role_mu + (1.0 - blend) * fpts

    # Missing role evidence is an uncertainty prior. The mean remains conservative;
    # variance is intentionally wide enough for TD/long-play tails. No player names.
    sal_scale = np.clip((salary - 1000.0) / 10000.0, 0.0, 1.0)
    neutral_base = np.select(
        [pos == "QB", pos == "RB", pos == "WR", pos == "TE", pos == "K", pos == "UNK"],
        [3.8, 1.8, 1.7, 1.5, 3.8, 1.6], default=1.6,
    )
    neutral_mu = neutral_base + 2.0 * sal_scale
    mu = np.where(missing_role, neutral_mu, mu)
    # When the frozen pool already contains real prelock per-game production, keep
    # the modeled mean from collapsing far below that evidence. The 80% floor is
    # deliberately conservative and only applies to the history-usage gate above.
    mu = np.maximum(mu, np.where(history_floor_gate, 0.80*hist_fpts, 0.0))
    mu = np.maximum(mu, np.where(pos == "K", np.maximum(fpts, 2.5), 0.10))

    role_strength = np.zeros(len(df), dtype=np.float64)
    for p in POS_ALLOWED:
        m = pos == p
        if not np.any(m):
            continue
        if p == "QB": raw = pa[m] + 1.8 * ra[m]
        elif p == "RB": raw = ra[m] + 1.9 * tar[m]
        elif p in {"WR", "TE"}: raw = tar[m] + 0.5 * ra[m]
        elif p == "K": raw = np.maximum(fpts[m], 0.1)
        else: raw = np.maximum(0.08 + 0.18 * sal_scale[m], 0.08)
        mx = max(float(np.max(raw)), 0.1)
        role_strength[m] = np.clip(raw / mx, 0.02, 1.0)
    role_strength[missing_role] = np.clip(0.05 + 0.18 * sal_scale[missing_role], 0.05, 0.23)

    role_unc = np.clip(0.22 + 0.055 * np.maximum(0.0, depth - 1.0), 0.20, 0.75)
    role_unc[pos == "QB"] = np.minimum(role_unc[pos == "QB"], 0.40)
    role_unc[pos == "K"] = 0.30
    role_unc[missing_role] = 0.78
    sigma_mult = np.select(
        [pos == "QB", pos == "RB", pos == "WR", pos == "TE", pos == "K", pos == "UNK"],
        [0.43, 0.56, 0.66, 0.62, 0.43, 0.72], default=0.68,
    )
    sigma_floor = np.select(
        [pos == "QB", pos == "RB", pos == "WR", pos == "TE", pos == "K", pos == "UNK"],
        [6.8, 5.8, 6.0, 5.2, 2.5, 6.2], default=5.8,
    )
    sigma = np.maximum(sigma_floor, mu * (sigma_mult + 0.42 * role_unc))
    sigma[missing_role] = np.maximum(sigma[missing_role], np.where(pos[missing_role] == "QB", 7.5, 6.6))
    return mu.astype(np.float32), sigma.astype(np.float32), role_strength.astype(np.float32), role_unc.astype(np.float32)


def _independent_team_points(mu: np.ndarray, pos: np.ndarray, team: np.ndarray) -> tuple[list[str], np.ndarray]:
    teams = list(dict.fromkeys(np.asarray(team, dtype=object).tolist()))
    if len(teams) != 2:
        raise RuntimeError("RUN_INVALID:CFB_SHOWDOWN_TEAM_POINT_PRIOR_EXPECTED_TWO_TEAMS")
    strength = []
    for t in teams:
        m = np.asarray(team, dtype=object) == t
        vals = np.sort(np.asarray(mu, dtype=float)[m])[::-1]
        top = float(vals[: min(7, len(vals))].sum())
        qb = np.asarray(mu, dtype=float)[m & (np.asarray(pos, dtype=object) == "QB")]
        rb = np.asarray(mu, dtype=float)[m & (np.asarray(pos, dtype=object) == "RB")]
        top += 0.35 * (float(np.max(qb)) if len(qb) else 0.0)
        top += 0.15 * (float(np.max(rb)) if len(rb) else 0.0)
        strength.append(top)
    diff = float(np.clip(0.18 * (strength[0] - strength[1]), -9.0, 9.0))
    total = float(np.clip(44.0 + 0.06 * (strength[0] + strength[1]), 40.0, 58.0))
    pts = np.asarray([0.5 * (total + diff), 0.5 * (total - diff)], dtype=np.float64)
    return teams, np.maximum(pts, 10.0)


def _regime_inputs(frame: pd.DataFrame, mu: np.ndarray, pos: np.ndarray, team: np.ndarray) -> dict[str, Any]:
    teams, model_points = _independent_team_points(mu, pos, team)
    t0 = teams[0]
    r0 = frame.loc[frame["TEAM"].astype(str) == str(t0)].iloc[0]
    total = _num_or_nan(r0.get("O/U", np.nan))
    spread = _num_or_nan(r0.get("SPRD", np.nan))
    return {"teams": teams, "model_points": model_points, "market_total": total, "market_spread_team0": spread}


def _num_or_nan(value: Any) -> float:
    try:
        v = float(value)
        return v if math.isfinite(v) else math.nan
    except Exception:
        return math.nan


def _simulate_players(cal: Calibration | dict[str, Any], trials: int, seed: int, *, return_regime: bool = False):
    if isinstance(cal, Calibration):
        mu, sigma, pos, team, opp = cal.mu, cal.sigma, cal.pos, cal.team, cal.opp
        role_strength = cal.role_strength
        ri = _regime_inputs(cal.frame, mu, pos, team)
    else:
        mu, sigma, pos, team, opp = cal["mu"], cal["sigma"], cal["pos"], cal["team"], cal["opp"]
        role_strength = np.asarray(cal.get("role_strength", np.full(len(mu), 0.5)), dtype=np.float32)
        ri = cal["regime_inputs"]
    mu = np.asarray(mu, dtype=np.float32); sigma = np.asarray(sigma, dtype=np.float32)
    role_strength = np.asarray(role_strength, dtype=np.float32)
    pos = np.asarray(pos, dtype=object); team = np.asarray(team, dtype=object); opp = np.asarray(opp, dtype=object)
    reg = regime_kernel.simulate_football_regimes(
        teams=ri["teams"], model_points=ri["model_points"], trials=int(trials), seed=int(seed) ^ 0x91A7CFB,
        market_total=ri.get("market_total"), market_spread_team0=ri.get("market_spread_team0"), market_prior_weight=0.25, sport="CFB", mode="SHOWDOWN",
    )
    rng = np.random.default_rng(seed)
    teams = list(reg.teams)
    team_index = {t: i for i, t in enumerate(teams)}
    game = rng.standard_normal(trials).astype(np.float32)
    ind = rng.standard_normal((len(mu), trials)).astype(np.float32)
    pass_alloc = {t: rng.standard_normal(trials).astype(np.float32) for t in teams}
    rush_alloc = {t: rng.standard_normal(trials).astype(np.float32) for t in teams}
    score_mean = np.maximum(np.mean(reg.scores, axis=1, keepdims=True), 1.0)
    score_sd = np.maximum(np.std(reg.scores, axis=1, keepdims=True), 3.0)
    score_z = ((reg.scores - score_mean) / score_sd).astype(np.float32)

    pass_rank = np.full(len(mu), 0.5, dtype=np.float32)
    rush_rank = np.full(len(mu), 0.5, dtype=np.float32)
    for t in teams:
        rec = np.flatnonzero((team == t) & np.isin(pos, ["WR", "TE", "UNK"]))
        if len(rec):
            pass_rank[rec] = _pct(role_strength[rec]).astype(np.float32)
        rb = np.flatnonzero((team == t) & (pos == "RB"))
        if len(rb):
            rush_rank[rb] = _pct(role_strength[rb]).astype(np.float32)

    out = np.empty_like(ind)
    for i, p in enumerate(pos):
        ti = team_index[str(team[i])]; oi = 1 - ti
        team_score = score_z[ti]
        opp_score = score_z[oi]
        pass_script = reg.pass_script[ti]
        rush_script = reg.rush_script[ti]
        off = reg.offense_latent[ti]
        deff = reg.defense_latent[oi]
        if p == "QB":
            latent = .12*game + .34*team_score + .22*pass_script + .18*off - .08*deff + .04*opp_score
            lv = .12**2+.34**2+.22**2+.18**2+.08**2+.04**2
        elif p in {"WR", "TE"}:
            alloc = .17*float(2.0*pass_rank[i]-1.0)
            latent = .10*game + .28*team_score + .30*pass_script + .17*off - .06*deff + .03*opp_score + alloc*pass_alloc[str(team[i])]
            lv = .10**2+.28**2+.30**2+.17**2+.06**2+.03**2+alloc**2
        elif p == "RB":
            alloc = .15*float(2.0*rush_rank[i]-1.0)
            latent = .10*game + .30*team_score + .27*rush_script + .17*off - .05*deff - .04*pass_script + alloc*rush_alloc[str(team[i])]
            lv = .10**2+.30**2+.27**2+.17**2+.05**2+.04**2+alloc**2
        elif p == "K":
            latent = .10*game + .27*team_score + .12*off - .04*deff
            lv = .10**2+.27**2+.12**2+.04**2
        else:  # unknown provider position: wide neutral tail, modest allocation uncertainty
            alloc = .12*float(2.0*pass_rank[i]-1.0)
            latent = .08*game + .24*team_score + .12*pass_script + .10*rush_script + .13*off - .05*deff + alloc*pass_alloc[str(team[i])]
            lv = .08**2+.24**2+.12**2+.10**2+.13**2+.05**2+alloc**2
        iw = math.sqrt(max(0.28, 1.0-lv))
        z = iw*ind[i] + latent
        out[i] = np.maximum(0.0, mu[i] + sigma[i]*z)
    receipt = dict(reg.receipt)
    receipt.update({
        "CFB_SHOWDOWN_CALIBRATION_PATCH_ID":CFB_CALIBRATION_PATCH,
        "ROLE_CONCENTRATION_COMPETITION":True,
        "TRUE_FIELD_TOP01_THRESHOLD":True,
    })
    return (out, receipt) if return_regime else out

def _ownership(mu: np.ndarray, p99: np.ndarray, salary: np.ndarray, role: np.ndarray, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    value = mu / np.maximum(1.0, salary / 1000.0)
    appeal = 0.35*_pct(mu) + 0.28*_pct(p99) + 0.18*_pct(value) + 0.14*_pct(role) + 0.05*_pct(salary.astype(float))
    # Roster ownership sums to six slots across the player pool.
    w = np.exp(3.0*(appeal - np.max(appeal)))
    own = np.clip(6.0*w/w.sum(), 0.006, 0.82)
    own *= 6.0/own.sum()
    own = np.clip(own, 0.004, 0.86)
    cpt_bonus = np.where(pos == "QB", 1.10, np.where(pos == "RB", 1.06, np.where(pos == "WR", 1.03, 0.94)))
    cw = w * cpt_bonus * (0.55 + _pct(p99))
    cpt = np.clip(cw/cw.sum(), 0.002, 0.62)
    cpt /= cpt.sum()
    return own.astype(np.float32), cpt.astype(np.float32)


def _calibrate(path: str | Path, cfg: Config) -> Calibration:
    df, out_names, inactive_names, missing_role_names = _prepare_pool(path)
    mu, sigma, role_strength, role_unc = _player_parameters(df)
    names = df["PLAYER"].astype(str).to_numpy(object)
    pos = df["POS_BASE"].astype(str).to_numpy(object)
    team = df["TEAM"].astype(str).to_numpy(object)
    opp = df["OPP"].astype(str).to_numpy(object)
    salary = _norm_col(df, "SAL").astype(np.int32)
    ri = _regime_inputs(df, mu, pos, team)
    base = {"mu":mu,"sigma":sigma,"pos":pos,"team":team,"opp":opp,"role_strength":role_strength,"regime_inputs":ri}
    sims, phase1_regime = _simulate_players(base, cfg.player_trials, cfg.seed ^ 0xC6B50001, return_regime=True)
    phase1_regime.update({'CFB_PRELOCK_HISTORY_USAGE_FLOOR_PATCH_ID':CFB_PRELOCK_HISTORY_USAGE_FLOOR_PATCH,'PRELOCK_HISTORY_USAGE_FLOOR_POSTLOCK_SIGNAL_USED':False,'PRELOCK_HISTORY_USAGE_FLOOR_PLAYER_NAME_CONSTANTS_USED':False})
    p95 = np.quantile(sims, .95, axis=1).astype(np.float32)
    p99 = np.quantile(sims, .99, axis=1).astype(np.float32)
    own, cptown = _ownership(mu, p99, salary, role_strength, pos)
    phase1 = _stable_hash({
        "names": names.tolist(), "mu": np.round(mu,5).tolist(), "sigma": np.round(sigma,5).tolist(),
        "p95":np.round(p95,5).tolist(),"p99":np.round(p99,5).tolist(),
        "ownership":np.round(own,6).tolist(),"captain_ownership":np.round(cptown,6).tolist(),
        "trials":cfg.player_trials,"model":"CFB_SHOWDOWN_DRIVE_REGIME_ROLE_CONCENTRATION_v2",
        "role_source":"PLAYER_POOL_STRUCTURAL_WORKLOAD_PLUS_MISSING_EVIDENCE_NEUTRAL_PRIOR",
        "regime_hash":phase1_regime["REGIME_HASH"],
    })
    return Calibration(df,names,pos,team,opp,salary,mu,sigma,p95,p99,own,cptown,role_strength,role_unc,phase1,_array_hash(sims),out_names,inactive_names,missing_role_names,phase1_regime)



def _apply_external_role_authority(cal: Calibration, cfg: Config) -> tuple[Calibration, dict[str,Any]]:
    """Apply execution-layer verified pregame role authority to source-missing players.

    The runtime accepts only explicit injected JSON/file data. It never searches or
    invents role values itself. Confirmed role authority upgrades the player's
    position/depth and borrows a same-team/same-position empirical prior from players
    whose role evidence was already present in the source pool. No postlock outcome,
    player-name constant, or market line is used by the model transformation.
    """
    raw=os.environ.get('APEX_CFB_ROLE_AUTHORITY_JSON','').strip()
    fpath=os.environ.get('APEX_CFB_ROLE_AUTHORITY_FILE','').strip()
    payload=None
    if raw:
        try: payload=json.loads(raw)
        except Exception as exc: raise RuntimeError(f'RUN_INVALID:CFB_ROLE_AUTHORITY_JSON_INVALID:{exc}') from exc
    elif fpath:
        try: payload=json.loads(Path(fpath).read_text(encoding='utf-8'))
        except Exception as exc: raise RuntimeError(f'RUN_INVALID:CFB_ROLE_AUTHORITY_FILE_INVALID:{exc}') from exc
    if not payload:
        return cal,{'CFB_EXTERNAL_ROLE_AUTHORITY_PATCH_ID':CFB_EXTERNAL_ROLE_AUTHORITY_PATCH,'CFB_PREBIRTH_ROLE_AUTHORITY_PATCH_ID':CFB_PREBIRTH_ROLE_AUTHORITY_PATCH,'EXTERNAL_ROLE_AUTHORITY_STAGE':'PREBIRTH_CALIBRATION','EXTERNAL_ROLE_AUTHORITY_APPLIED':False,'EXTERNAL_ROLE_RECOVERED_PLAYERS':[],'EXTERNAL_ROLE_RECOVERED_STARTERS':[]}
    entries=payload.get('players',payload) if isinstance(payload,dict) else None
    if not isinstance(entries,dict):
        raise RuntimeError('RUN_INVALID:CFB_ROLE_AUTHORITY_PAYLOAD_NOT_OBJECT')
    source_missing=set(map(str,cal.missing_role_names)); recovered=[]; starters=[]; details=[]; stale_overrides=[]
    all_names=set(map(str,cal.names.tolist()))
    source_depth=_depth_numeric(cal)
    for name,rec in entries.items():
        name=str(name)
        if name not in all_names or not isinstance(rec,dict):
            continue
        pos=str(rec.get('position','')).upper().strip(); depth=float(rec.get('depth',8.0))
        if pos not in {'QB','RB','WR','TE','K'} or not math.isfinite(depth) or depth<=0:
            continue
        i=int(np.where(cal.names==name)[0][0])
        explicit_override=bool(rec.get('override_existing',False))
        stale_present=(name not in source_missing and explicit_override and math.isfinite(float(source_depth[i])) and depth < float(source_depth[i])-0.24)
        if name not in source_missing and not stale_present:
            continue
        team=str(cal.team[i])
        peers=[j for j in range(len(cal.names)) if str(cal.team[j])==team and str(cal.pos[j])==pos and str(cal.names[j]) not in source_missing]
        if not peers:
            continue
        q=0.50 if depth<=1.25 else (0.40 if depth<=2.25 else 0.25)
        cal.pos[i]=pos; cal.frame.loc[i,'POS_BASE']=pos; cal.frame.loc[i,'DEPTH']=str(depth)
        cal.mu[i]=max(float(cal.mu[i]),float(np.quantile(cal.mu[peers],q)))
        cal.sigma[i]=max(float(cal.sigma[i]),float(np.quantile(cal.sigma[peers],q)))
        cal.role_strength[i]=max(float(cal.role_strength[i]),float(np.quantile(cal.role_strength[peers],q)))
        cal.role_uncertainty[i]=min(float(cal.role_uncertainty[i]),float(np.quantile(cal.role_uncertainty[peers],1.0-q)))
        recovered.append(name)
        if stale_present: stale_overrides.append(name)
        if depth<=1.25: starters.append(name)
        details.append({'PLAYER':name,'POSITION':pos,'DEPTH':depth,'PEER_COUNT':len(peers),'PRIOR_QUANTILE':q,'SOURCE_ROLE_MISSING':bool(name in source_missing),'STALE_PRESENT_OVERRIDE':bool(stale_present)})
    if not recovered:
        return cal,{'CFB_EXTERNAL_ROLE_AUTHORITY_PATCH_ID':CFB_EXTERNAL_ROLE_AUTHORITY_PATCH,'CFB_PREBIRTH_ROLE_AUTHORITY_PATCH_ID':CFB_PREBIRTH_ROLE_AUTHORITY_PATCH,'EXTERNAL_ROLE_AUTHORITY_STAGE':'PREBIRTH_CALIBRATION','EXTERNAL_ROLE_AUTHORITY_APPLIED':False,'EXTERNAL_ROLE_RECOVERED_PLAYERS':[],'EXTERNAL_ROLE_RECOVERED_STARTERS':[]}
    cal.missing_role_names=[x for x in cal.missing_role_names if x not in set(recovered)]
    ri=_regime_inputs(cal.frame,cal.mu,cal.pos,cal.team)
    base={'mu':cal.mu,'sigma':cal.sigma,'pos':cal.pos,'team':cal.team,'opp':cal.opp,'role_strength':cal.role_strength,'regime_inputs':ri}
    sims,phase1_regime=_simulate_players(base,cfg.player_trials,cfg.seed ^ 0xC6B50001,return_regime=True)
    cal.p95=np.quantile(sims,.95,axis=1).astype(np.float32); cal.p99=np.quantile(sims,.99,axis=1).astype(np.float32)
    cal.ownership,cal.captain_ownership=_ownership(cal.mu,cal.p99,cal.salary,cal.role_strength,cal.pos)
    cal.player_sim_hash=_array_hash(sims); cal.phase1_regime_receipt=phase1_regime
    cal.phase1_hash=_stable_hash({'names':cal.names.tolist(),'mu':np.round(cal.mu,5).tolist(),'sigma':np.round(cal.sigma,5).tolist(),'p95':np.round(cal.p95,5).tolist(),'p99':np.round(cal.p99,5).tolist(),'ownership':np.round(cal.ownership,6).tolist(),'captain_ownership':np.round(cal.captain_ownership,6).tolist(),'trials':cfg.player_trials,'model':'CFB_SHOWDOWN_DRIVE_REGIME_ROLE_CONCENTRATION_v2','role_source':'PLAYER_POOL_PLUS_VERIFIED_EXTERNAL_PREGAME_ROLE_AUTHORITY','regime_hash':phase1_regime['REGIME_HASH']})
    return cal,{'CFB_EXTERNAL_ROLE_AUTHORITY_PATCH_ID':CFB_EXTERNAL_ROLE_AUTHORITY_PATCH,'CFB_PREBIRTH_ROLE_AUTHORITY_PATCH_ID':CFB_PREBIRTH_ROLE_AUTHORITY_PATCH,'CFB_STALE_PRESENT_ROLE_AUTHORITY_PATCH_ID':CFB_STALE_PRESENT_ROLE_AUTHORITY_PATCH,'EXTERNAL_ROLE_AUTHORITY_STAGE':'PREBIRTH_CALIBRATION','EXTERNAL_ROLE_AUTHORITY_APPLIED':True,'EXTERNAL_ROLE_RECOVERED_PLAYERS':sorted(recovered),'EXTERNAL_ROLE_RECOVERED_STARTERS':sorted(starters),'EXTERNAL_ROLE_STALE_PRESENT_OVERRIDES':sorted(stale_overrides),'EXTERNAL_ROLE_AUTHORITY_DETAILS':details,'EXTERNAL_ROLE_AUTHORITY_POSTLOCK_SIGNAL_USED':False,'EXTERNAL_ROLE_AUTHORITY_MARKET_SIGNAL_USED':False}


def _enumerate_legal(cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, Any]]:
    n = len(cal.names)
    if n < ROSTER_SIZE:
        raise RuntimeError("RUN_INVALID:CFB_SHOWDOWN_ZERO_LEGAL_LINEUPS")
    value = cal.p99 / np.maximum(1.0, cal.salary.astype(float) / 1000.0)
    pscore = 0.30*_pct(cal.p99) + 0.24*_pct(cal.mu) + 0.18*_pct(value) + 0.12*_pct(cal.role_strength) + 0.16*_pct(cal.role_uncertainty)
    deep = (cal.salary <= 2400) | np.isin(cal.names, np.asarray(cal.missing_role_names, dtype=object))
    target_total = max(cfg.phase2_keep * 2, 8_000)
    per_cpt = max(48, int(math.ceil(target_total / max(1, n))))
    rows: list[tuple[int,int,int,int,int,int]] = []
    expanded = 0
    team_values = list(dict.fromkeys(cal.team.tolist()))
    team0 = team_values[0]

    for c in range(n):
        c_salary = int((int(cal.salary[c]) * 3) // 2)
        # Use all players as possible branch members, but expand higher-calibration
        # candidates first. Deep/missing-role values get an explicit branch bonus.
        candidates = [j for j in range(n) if j != c]
        candidates.sort(key=lambda j: (float(pscore[j] + (0.10 if deep[j] else 0.0)), -int(cal.salary[j]), -j), reverse=True)
        # state: score, chosen tuple, next candidate ordinal, salary, team0 count, deep count
        states = [(0.0, tuple(), 0, c_salary, int(cal.team[c] == team0), 0)]
        for depth_slot in range(5):
            buckets: dict[tuple[int,int], list[tuple[float,tuple[int,...],int,int,int,int]]] = {}
            for sc, chosen, start, sal, t0c, dc in states:
                remaining_slots = 5 - depth_slot
                for ord_idx in range(start, len(candidates)):
                    if len(candidates) - ord_idx < remaining_slots:
                        break
                    j = candidates[ord_idx]
                    nsal = sal + int(cal.salary[j])
                    if nsal > SALARY_MAX:
                        continue
                    nt0 = t0c + int(cal.team[j] == team0)
                    ncount_team0 = nt0
                    ncount_team1 = (depth_slot + 2) - nt0
                    if ncount_team0 > MAX_FROM_TEAM or ncount_team1 > MAX_FROM_TEAM:
                        continue
                    bonus = 0.10 if deep[j] else 0.0
                    if cal.team[j] == cal.team[c]: bonus += 0.012
                    if cal.pos[c] == "QB" and cal.team[j] == cal.team[c] and cal.pos[j] in {"WR","TE","UNK"}: bonus += 0.035
                    if cal.pos[c] == "RB" and cal.team[j] == cal.team[c]: bonus += 0.012
                    nsc = sc + float(pscore[j]) + bonus
                    ndc = dc + int(deep[j])
                    key = (nt0, min(ndc, 3))
                    buckets.setdefault(key, []).append((nsc, chosen + (j,), ord_idx + 1, nsal, nt0, ndc))
                    expanded += 1
            states = []
            # quota by team/deep-value geometry prevents one median script from
            # eliminating alternate game worlds before MC.
            for vals in buckets.values():
                vals.sort(key=lambda x: (x[0], x[3], x[1]), reverse=True)
                states.extend(vals[:14])
            states.sort(key=lambda x: (x[0], x[3], x[1]), reverse=True)
            states = states[:420]
            if not states:
                break
        finals = []
        for sc, chosen, _start, sal, _t0, _dc in states:
            if len(chosen) != 5 or not (SALARY_MIN <= sal <= SALARY_MAX):
                continue
            row = (c,) + tuple(sorted(chosen))
            teams = cal.team[list(row)]
            if max(np.count_nonzero(teams == t) for t in np.unique(teams)) > MAX_FROM_TEAM:
                continue
            finals.append((sc, sal, row))
        finals.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)
        rows.extend([x[2] for x in finals[:per_cpt]])

    unique = list(dict.fromkeys(rows))
    if not unique:
        raise RuntimeError("RUN_INVALID:CFB_SHOWDOWN_ZERO_CALIBRATION_QUALIFIED_LINEUPS")
    arr = np.asarray(unique, dtype=np.int16)
    return arr, {
        "GENERATION_METHOD":"DETERMINISTIC_CALIBRATION_QUALIFIED_BEAM_BRANCH",
        "FULL_LEGAL_UNIVERSE_ENUMERATED":False,
        "QUALIFIED_GENERATED_LINEUPS":int(len(arr)),
        "BRANCH_EXPANSIONS":int(expanded),
        "PLAYER_POOL_COVERAGE":int(len(set(map(int, arr.reshape(-1).tolist())))),
        "NO_RANDOM_FIRST_N":True,
    }


def _lineup_features(rows: np.ndarray, cal: Calibration) -> dict[str, np.ndarray]:
    c = rows[:,0]
    salary = ((cal.salary[c].astype(np.int64)*3)//2) + cal.salary[rows[:,1:]].sum(axis=1)
    mean = cal.mu[rows].sum(axis=1) + 0.5*cal.mu[c]
    p95 = cal.p95[rows].sum(axis=1) + 0.5*cal.p95[c]
    p99 = cal.p99[rows].sum(axis=1) + 0.5*cal.p99[c]
    teams = cal.team[rows]
    positions = cal.pos[rows]
    same = (teams == cal.team[c,None]).sum(axis=1).astype(np.int8)
    qb = (positions == "QB").sum(axis=1).astype(np.int8)
    passcatch = np.isin(positions, ["WR","TE"]).sum(axis=1).astype(np.int8)
    role = cal.role_strength[rows].sum(axis=1) + 0.5*cal.role_strength[c]
    logown = np.log(np.clip(cal.captain_ownership[c],1e-6,1.0)) + np.log(np.clip(cal.ownership[rows[:,1:]],1e-6,1.0)).sum(axis=1)
    dup = np.exp(np.clip(logown, -30, 0)) * 10000.0
    leverage = -logown

    cpt_qb_stack=np.zeros(len(rows),dtype=np.int8)
    cpt_receiver_qb=np.zeros(len(rows),dtype=np.int8)
    cpt_rb_team=np.zeros(len(rows),dtype=np.int8)
    bringback_skill=np.zeros(len(rows),dtype=np.int8)
    for i in range(len(rows)):
        cp=int(c[i]); ct=str(cal.team[cp]); co=str(cal.opp[cp]); cpp=str(cal.pos[cp])
        if cpp == "QB":
            cpt_qb_stack[i]=int(np.count_nonzero((teams[i]==ct)&np.isin(positions[i],["WR","TE"])))
        elif cpp in {"WR","TE"}:
            cpt_receiver_qb[i]=int(np.count_nonzero((teams[i]==ct)&(positions[i]=="QB")))
        elif cpp == "RB":
            cpt_rb_team[i]=int(np.count_nonzero(teams[i]==ct))
        bringback_skill[i]=int(np.count_nonzero((teams[i]==co)&np.isin(positions[i],["QB","RB","WR","TE"])))

    score = 0.41*_pct(p99) + 0.22*_pct(p95) + 0.11*_pct(mean) + 0.09*_pct(role) + 0.09*_pct(leverage)
    score += 0.026*np.minimum(cpt_qb_stack,2) + 0.030*np.minimum(cpt_receiver_qb,1)
    score += 0.016*((cpt_rb_team>=3)&(cpt_rb_team<=4)) + 0.014*np.minimum(bringback_skill,2)
    score += np.where((same>=3)&(same<=4),0.020,0.0)
    score += np.where(qb>=1,0.010,0.0) + np.where(passcatch>=2,0.006,0.0)
    # Do not force full salary in single-game contests; leverage/duplication handles
    # geometry while allowing high-upside salary-left constructions to survive.
    return {
        "salary":salary.astype(np.int32),"mean":mean.astype(np.float32),"p95":p95.astype(np.float32),"p99":p99.astype(np.float32),
        "same_cpt_team":same,"qb_count":qb,"passcatch_count":passcatch,"role":role.astype(np.float32),"logown":logown.astype(np.float32),
        "dup_proxy":dup.astype(np.float32),"leverage":leverage.astype(np.float32),"score":score.astype(np.float32),
        "cpt_qb_stack":cpt_qb_stack,"cpt_receiver_qb":cpt_receiver_qb,"cpt_rb_team":cpt_rb_team,"bringback_skill":bringback_skill,
    }

def _phase2(rows: np.ndarray, feat: dict[str,np.ndarray], cfg: Config) -> tuple[np.ndarray, dict[str,np.ndarray], dict[str,int]]:
    keep = min(cfg.phase2_keep, len(rows))
    mandatory: set[int] = set()
    # Certified family coverage: each captain, each team split, each captain-position family.
    cpt = rows[:,0]
    cpt_pos = np.asarray([str(x) for x in feat.get("_cpt_pos", np.array([],dtype=object))])
    families: dict[tuple[int,int], list[int]] = {}
    for i in range(len(rows)):
        key=(int(cpt[i]),int(feat["same_cpt_team"][i]))
        families.setdefault(key,[]).append(i)
    family_take = max(4, min(24, keep//max(1,len(families))))
    for inds in families.values():
        a=np.asarray(inds,dtype=np.int32)
        order=a[np.argsort(feat["score"][a],kind="stable")[-min(family_take,len(a)):]]
        mandatory.update(map(int,order.tolist()))
    topn = max(0, keep-len(mandatory))
    if topn:
        global_top=np.argsort(feat["score"],kind="stable")[-min(len(rows), keep*2):][::-1]
        for i in global_top:
            mandatory.add(int(i))
            if len(mandatory)>=keep: break
    chosen=np.asarray(sorted(mandatory, key=lambda i:(-float(feat["score"][i]),i))[:keep],dtype=np.int32)
    p2=rows[chosen]
    pf={k:v[chosen] for k,v in feat.items() if not k.startswith("_")}
    pf["source_index"]=chosen
    return p2,pf,{"PHASE2_BUILT_LINEUPS":int(len(p2)),"PHASE2_CALIBRATION_QUALIFIED":int(len(p2)),"PHASE2_FAMILY_COUNT":int(len(families))}



def _qb_cpt_5_1_missing_role_family_reserve(seed_rows: np.ndarray, cal: Calibration, per_qb: int = 64) -> tuple[np.ndarray, dict[str,Any]]:
    """Bounded pre-closure identity-family reserve for QB-CPT 5-1 favorite-side scripts.

    Forward-blind and market-independent. For each QB captain, retain a bounded set
    of legal 5-1 identity families containing exactly one same-team missing-role
    player, three same-team known-role non-QBs, and one known-role opponent bringback.
    Candidate ranking uses only the engine's existing calibrated role/tail/score
    features. No player-name, contest-result, market-line, or postlock signal enters.
    """
    value = cal.p99 / np.maximum(1.0, cal.salary.astype(float) / 1000.0)
    pscore = 0.30*_pct(cal.p99) + 0.24*_pct(cal.mu) + 0.18*_pct(value) + 0.12*_pct(cal.role_strength) + 0.16*_pct(cal.role_uncertainty)
    missing = np.isin(cal.names, np.asarray(cal.missing_role_names, dtype=object))
    reserve: list[tuple[int,int,int,int,int,int]] = []
    qbs_with_candidates = 0
    for c in range(len(cal.names)):
        if str(cal.pos[c]) != "QB":
            continue
        ct, co = str(cal.team[c]), str(cal.opp[c])
        same_known = [j for j in range(len(cal.names)) if j != c and str(cal.team[j]) == ct and not bool(missing[j]) and str(cal.pos[j]) != "QB"]
        same_missing = [j for j in range(len(cal.names)) if j != c and str(cal.team[j]) == ct and bool(missing[j])]
        opp_known = [j for j in range(len(cal.names)) if str(cal.team[j]) == co and not bool(missing[j])]
        same_known.sort(key=lambda j:(float(pscore[j]),-int(cal.salary[j]),-j),reverse=True)
        same_missing.sort(key=lambda j:(float(pscore[j]),-int(cal.salary[j]),-j),reverse=True)
        opp_known.sort(key=lambda j:(float(pscore[j]),-int(cal.salary[j]),-j),reverse=True)
        same_known=same_known[:12]; same_missing=same_missing[:8]; opp_known=opp_known[:10]
        cand: list[tuple[int,int,int,int,int,int]] = []
        for known3 in itertools.combinations(same_known,3):
            for miss in same_missing:
                for bring in opp_known:
                    flex=tuple(sorted((*known3,miss,bring)))
                    if len(set(flex)) != 5:
                        continue
                    row=(int(c),)+flex
                    sal=int((int(cal.salary[c])*3)//2 + sum(int(cal.salary[x]) for x in flex))
                    if not (SALARY_MIN <= sal <= SALARY_MAX):
                        continue
                    teams=cal.team[list(row)]
                    if max(np.count_nonzero(teams == t) for t in np.unique(teams)) > MAX_FROM_TEAM:
                        continue
                    cand.append(row)
        cand=list(dict.fromkeys(cand))
        if not cand:
            continue
        qbs_with_candidates += 1
        arr=np.asarray(cand,dtype=np.int16)
        feat=_lineup_features(arr,cal)
        order=sorted(range(len(arr)),key=lambda i:(float(feat["role"][i]),float(feat["p99"][i]),float(feat["score"][i]),int(feat["salary"][i]),tuple(map(int,arr[i]))),reverse=True)
        reserve.extend(tuple(map(int,arr[i])) for i in order[:min(int(per_qb),len(order))])
    reserve=list(dict.fromkeys(reserve))
    seed=[tuple(map(int,r)) for r in np.asarray(seed_rows,dtype=np.int16)]
    combined=list(dict.fromkeys(seed+reserve))
    rows=np.asarray(combined,dtype=np.int16)
    return rows,{
        "CFB_QB_5_1_MISSING_ROLE_FAMILY_RESERVE_PATCH_ID":CFB_QB_5_1_MISSING_ROLE_FAMILY_RESERVE_PATCH,
        "QB_5_1_MISSING_ROLE_RESERVE_ROWS":int(len(reserve)),
        "QB_5_1_MISSING_ROLE_RESERVE_QBS":int(qbs_with_candidates),
        "QB_5_1_MISSING_ROLE_RESERVE_PER_QB":int(per_qb),
        "PHASE2_SEED_ROWS_BEFORE_QB_5_1_RESERVE":int(len(seed)),
        "PHASE2_SEED_ROWS_AFTER_QB_5_1_RESERVE":int(len(rows)),
        "QB_5_1_MISSING_ROLE_RESERVE_POSTLOCK_SIGNAL_USED":False,
        "QB_5_1_MISSING_ROLE_RESERVE_MARKET_SIGNAL_USED":False,
    }


def _role_complete_phase2_families(seed_rows: np.ndarray, cal: Calibration) -> tuple[np.ndarray, dict[str,np.ndarray], dict[str,int]]:
    """Expand every retained six-player identity family to all legal CPT assignments.

    The operator is forward-blind: it uses only the already-retained Phase-2 identity
    sets plus DK salary/team legality. No realized result, contest identity, or player
    name constant participates in closure.
    """
    families: dict[tuple[int,...], None] = {}
    for row in np.asarray(seed_rows, dtype=np.int16):
        fam = tuple(sorted(map(int, row.tolist())))
        if len(fam) != ROSTER_SIZE or len(set(fam)) != ROSTER_SIZE:
            continue
        families.setdefault(fam, None)

    expanded: list[tuple[int,int,int,int,int,int]] = []
    seen: set[tuple[int,int,int,int,int,int]] = set()
    for fam in families.keys():
        fam_arr=np.asarray(fam,dtype=np.int16)
        fam_teams=cal.team[fam_arr]
        if max(np.count_nonzero(fam_teams == t) for t in np.unique(fam_teams)) > MAX_FROM_TEAM:
            continue
        for c in fam:
            flex=tuple(sorted(j for j in fam if j != c))
            row=(int(c),)+flex
            sal=int((int(cal.salary[c])*3)//2 + sum(int(cal.salary[j]) for j in flex))
            if not (SALARY_MIN <= sal <= SALARY_MAX):
                continue
            if row not in seen:
                seen.add(row); expanded.append(row)

    if not expanded:
        raise RuntimeError("RUN_INVALID:CFB_SHOWDOWN_ROLE_COMPLETE_CLOSURE_ZERO_ROWS")
    rows=np.asarray(expanded,dtype=np.int16)
    feat=_lineup_features(rows,cal)
    seed_unique=len({tuple(map(int,r)) for r in np.asarray(seed_rows).tolist()})
    return rows,feat,{
        "PHASE2_FAMILY_SEED_ROWS":int(seed_unique),
        "PHASE2_IDENTITY_FAMILIES":int(len(families)),
        "ROLE_COMPLETE_CPT_SIBLINGS_ADDED":int(len(rows)-seed_unique),
        "PHASE2_BUILT_LINEUPS":int(len(rows)),
        "PHASE2_CALIBRATION_QUALIFIED":int(len(rows)),
        "PHASE2_FAMILY_COUNT":int(len(families)),
        "ROLE_COMPLETE_CPT_CLOSURE":True,
        "ROLE_COMPLETE_CPT_PATCH_ID":CFB_ROLE_COMPLETE_CPT_PATCH,
    }


def _lineup_scores(rows: np.ndarray, sims: np.ndarray, chunk: int = 512) -> np.ndarray:
    trials=sims.shape[1]
    out=np.empty((len(rows),trials),dtype=np.float32)
    for s in range(0,len(rows),chunk):
        r=rows[s:s+chunk]
        c=r[:,0]
        block=sims[r].sum(axis=1) + 0.5*sims[c]
        out[s:s+len(r)] = block
    return out


def _sample_public_field(cal: Calibration, cfg: Config, rng: np.random.Generator, candidate_rows: np.ndarray, candidate_feat: dict[str,np.ndarray]) -> np.ndarray:
    n = len(cal.names)
    out: list[tuple[int,int,int,int,int,int]] = []
    seen: set[tuple[int,int,int,int,int,int]] = set()
    max_attempts = max(20_000, cfg.field_size * 250)
    attempts = 0
    while len(out) < cfg.field_size and attempts < max_attempts:
        attempts += 1
        cp=np.asarray(cal.captain_ownership,dtype=np.float64).copy()
        cp=np.maximum(cp,1e-12); cp/=cp.sum(); cp[-1]=1.0-float(cp[:-1].sum())
        c = int(rng.choice(n, p=cp))
        flex_idx = np.asarray([j for j in range(n) if j != c], dtype=np.int32)
        w = np.asarray(cal.ownership[flex_idx], dtype=np.float64)
        w = np.maximum(w, 1e-8); w /= w.sum(); w[-1]=1.0-float(w[:-1].sum())
        flex = rng.choice(flex_idx, size=5, replace=False, p=w)
        row = (c,) + tuple(sorted(map(int, flex.tolist())))
        sal = int((int(cal.salary[c])*3)//2 + sum(int(cal.salary[j]) for j in flex))
        if not (SALARY_MIN <= sal <= SALARY_MAX):
            continue
        teams = cal.team[list(row)]
        if max(np.count_nonzero(teams == t) for t in np.unique(teams)) > MAX_FROM_TEAM:
            continue
        # Public field can duplicate lineups. Preserve duplicates after a broad unique
        # base has formed so max/percentile thresholds remain realistic.
        if row in seen and len(seen) < min(cfg.field_size, max(64, int(cfg.field_size*0.70))):
            continue
        out.append(row); seen.add(row)
    if len(out) < cfg.field_size:
        logown = candidate_feat["logown"].astype(np.float64)
        w = np.exp(np.clip(logown, -40, 0)); w = np.maximum(w, 1e-18); w /= w.sum(); w[-1]=1.0-float(w[:-1].sum())
        extra = rng.choice(len(candidate_rows), size=cfg.field_size-len(out), replace=True, p=w)
        out.extend(tuple(map(int, candidate_rows[i])) for i in extra.tolist())
    return np.asarray(out, dtype=np.int16)


def _thresholds(field_rows: np.ndarray, sims: np.ndarray, field_size: int) -> tuple[np.ndarray,np.ndarray,np.ndarray,np.ndarray]:
    fs=_lineup_scores(field_rows,sims,chunk=256)
    n=fs.shape[0]
    win=np.max(fs,axis=0)
    k01=max(1,int(math.ceil(field_size*0.001)))
    kth01=min(n,k01)
    top01=np.partition(fs,n-kth01,axis=0)[n-kth01]
    k1=max(1,int(math.ceil(field_size*0.01)))
    kth=min(n,k1)
    top1=np.partition(fs,n-kth,axis=0)[n-kth]
    k5=max(1,int(math.ceil(field_size*0.05)))
    kth5=min(n,k5)
    top5=np.partition(fs,n-kth5,axis=0)[n-kth5]
    return win,top01,top1,top5


def _wilson(success: np.ndarray, trials: np.ndarray, z: float = 1.96) -> tuple[np.ndarray,np.ndarray]:
    s=np.asarray(success,dtype=np.float64); n=np.asarray(trials,dtype=np.float64)
    p=np.divide(s,n,out=np.zeros_like(s),where=n>0)
    den=1.0+z*z/n
    center=(p+z*z/(2.0*n))/den
    half=z*np.sqrt(np.maximum(0.0,p*(1.0-p)/n+z*z/(4.0*n*n)))/den
    return np.maximum(0.0,center-half),np.minimum(1.0,center+half)


def _simulate_phase2_legacy(rows: np.ndarray, pf: dict[str,np.ndarray], legal_rows: np.ndarray, legal_feat: dict[str,np.ndarray], cal: Calibration, cfg: Config) -> dict[str,Any]:
    """Memory-safe Phase 3 with identical CRN seeds and field thresholds.

    Candidate lineups are evaluated in chunks rather than materializing the full
    N_lineups x N_trials score matrix. This changes storage only, not model logic.
    """
    sims, regime_receipt = _simulate_players(cal,cfg.base_trials,cfg.seed ^ 0xB453CFB, return_regime=True)
    rng=np.random.default_rng(cfg.seed ^ 0xF13D352)
    field_rows=_sample_public_field(cal,cfg,rng,legal_rows,legal_feat)
    win_thr,top01_thr,top1_thr,top5_thr=_thresholds(field_rows,sims,cfg.field_size)

    n=len(rows)
    win_credit=np.zeros(n,dtype=np.float64)
    top01=np.zeros(n,dtype=np.int32)
    top1=np.zeros(n,dtype=np.int32)
    top5=np.zeros(n,dtype=np.int32)
    lineup_p95=np.zeros(n,dtype=np.float32)
    lineup_p99=np.zeros(n,dtype=np.float32)
    chunk=256
    for s in range(0,n,chunk):
        e=min(n,s+chunk)
        block=_lineup_scores(rows[s:e],sims,chunk=chunk)
        w=(block>win_thr[None,:]+1e-7).sum(axis=1).astype(np.int32)
        ties=(np.abs(block-win_thr[None,:])<=1e-7).sum(axis=1).astype(np.int32)
        win_credit[s:e]=w.astype(np.float64)+0.5*ties.astype(np.float64)
        top01[s:e]=(block>=top01_thr[None,:]-1e-7).sum(axis=1).astype(np.int32)
        top1[s:e]=(block>=top1_thr[None,:]-1e-7).sum(axis=1).astype(np.int32)
        top5[s:e]=(block>=top5_thr[None,:]-1e-7).sum(axis=1).astype(np.int32)
        lineup_p95[s:e]=np.quantile(block,.95,axis=1).astype(np.float32)
        lineup_p99[s:e]=np.quantile(block,.99,axis=1).astype(np.float32)
        del block
    trials=np.full(n,cfg.base_trials,dtype=np.int32)

    primary=0.62*(win_credit/cfg.base_trials)+0.38*(top01/cfg.base_trials)
    order=np.argsort(primary + 1e-5*_pct(lineup_p99),kind="stable")[::-1]
    bubble=order[:min(cfg.bubble_cap,len(order))]
    extra_total=0
    if len(bubble):
        ex, _extra_regime = _simulate_players(cal,cfg.extra_trials,cfg.seed ^ 0xE87A352, return_regime=True)
        field_rows2=_sample_public_field(cal,cfg,rng,legal_rows,legal_feat)
        win2,t012,t12,t52=_thresholds(field_rows2,ex,cfg.field_size)
        bls=_lineup_scores(rows[bubble],ex,chunk=128)
        w2=(bls>win2[None,:]+1e-7).sum(axis=1)+0.5*(np.abs(bls-win2[None,:])<=1e-7).sum(axis=1)
        t01=(bls>=t012[None,:]-1e-7).sum(axis=1)
        t1=(bls>=t12[None,:]-1e-7).sum(axis=1)
        t5=(bls>=t52[None,:]-1e-7).sum(axis=1)
        win_credit[bubble]+=w2; top01[bubble]+=t01; top1[bubble]+=t1; top5[bubble]+=t5; trials[bubble]+=cfg.extra_trials
        # Reconstruct only the 96-row base block for combined bubble quantiles.
        base_bls=_lineup_scores(rows[bubble],sims,chunk=128)
        combo=np.concatenate([base_bls,bls],axis=1)
        lineup_p95[bubble]=np.quantile(combo,.95,axis=1).astype(np.float32)
        lineup_p99[bubble]=np.quantile(combo,.99,axis=1).astype(np.float32)
        extra_total=int(len(bubble)*cfg.extra_trials)
    top01_lcb,top01_ucb=_wilson(top01,trials)
    return {
        "win_rate":(win_credit/trials).astype(np.float64),
        "top01_rate":(top01/trials).astype(np.float64),
        "top01_lcb":top01_lcb.astype(np.float64),"top01_ucb":top01_ucb.astype(np.float64),
        "top1_rate":(top1/trials).astype(np.float64),
        "top5_rate":(top5/trials).astype(np.float64),
        "lineup_p95":lineup_p95,"lineup_p99":lineup_p99,"trials":trials,
        "BASE_SIM_TRIALS":cfg.base_trials,"BUBBLE_EXTRA_TRIALS_TOTAL":extra_total,
        "BUBBLE_LINEUPS_UNRESOLVED":0,"FAKE_FIELD_SIZE":cfg.field_size,
        "TOP01_FIELD_CUTOFF_N":max(1,int(math.ceil(cfg.field_size*0.001))),
        "FAKE_FIELD_UNIQUE_LINEUPS":int(len({tuple(map(int,r)) for r in field_rows.tolist()})),
        "STREAMING_PHASE3":True,"STREAMING_LINEUP_CHUNK":chunk,
        "regime_receipt":regime_receipt,
    }


def _simulate_phase2(rows: np.ndarray, pf: dict[str,np.ndarray], legal_rows: np.ndarray, legal_feat: dict[str,np.ndarray], cal: Calibration, cfg: Config) -> dict[str,Any]:
    """Promoted common-world opportunity simulation with recurrence bit ledgers."""
    sims, regime_receipt, _factor = opportunity_model.simulate(sys.modules[__name__],cal,cfg.base_trials,cfg.seed ^ 0xB453CFB,return_regime=True)
    rng=np.random.default_rng(cfg.seed ^ 0xF13D352)
    field_rows=_sample_public_field(cal,cfg,rng,legal_rows,legal_feat)
    win_thr,top01_thr,top1_thr,top5_thr=_thresholds(field_rows,sims,cfg.field_size)
    n=len(rows); nb=(cfg.base_trials+7)//8
    win_credit=np.zeros(n,dtype=np.float64); top01=np.zeros(n,dtype=np.int32); top1=np.zeros(n,dtype=np.int32); top5=np.zeros(n,dtype=np.int32)
    lineup_p95=np.zeros(n,dtype=np.float32); lineup_p99=np.zeros(n,dtype=np.float32)
    win_bits=np.zeros((n,nb),dtype=np.uint8); top01_bits=np.zeros((n,nb),dtype=np.uint8)
    chunk=384
    def _eval_promoted_chunk(bounds):
        s,e=bounds
        block=_lineup_scores(rows[s:e],sims,chunk=e-s)
        xw=block>=win_thr[None,:]-1e-7; x01=block>=top01_thr[None,:]-1e-7
        w=(block>win_thr[None,:]+1e-7).sum(axis=1).astype(np.int32); ties=(np.abs(block-win_thr[None,:])<=1e-7).sum(axis=1).astype(np.int32)
        return (s,e,w.astype(np.float64)+0.5*ties.astype(np.float64),x01.sum(axis=1).astype(np.int32),
                (block>=top1_thr[None,:]-1e-7).sum(axis=1).astype(np.int32),
                (block>=top5_thr[None,:]-1e-7).sum(axis=1).astype(np.int32),
                np.quantile(block,.95,axis=1).astype(np.float32),np.quantile(block,.99,axis=1).astype(np.float32),
                np.packbits(xw,axis=1,bitorder='little'),np.packbits(x01,axis=1,bitorder='little'))
    bounds=[(s,min(n,s+chunk)) for s in range(0,n,chunk)]
    with ThreadPoolExecutor(max_workers=4) as ex_pool:
        for s,e,wc,t01,t1,t5,p95c,p99c,wbc,tbc in ex_pool.map(_eval_promoted_chunk,bounds):
            win_credit[s:e]=wc; top01[s:e]=t01; top1[s:e]=t1; top5[s:e]=t5
            lineup_p95[s:e]=p95c; lineup_p99[s:e]=p99c; win_bits[s:e]=wbc; top01_bits[s:e]=tbc
    trials=np.full(n,cfg.base_trials,dtype=np.int32)
    primary=0.62*(win_credit/cfg.base_trials)+0.38*(top01/cfg.base_trials)
    order=np.argsort(primary + 1e-5*_pct(lineup_p99),kind='stable')[::-1]; bubble=order[:min(cfg.bubble_cap,len(order))]; extra_total=0
    if len(bubble):
        ex,_reg2,_f2=opportunity_model.simulate(sys.modules[__name__],cal,cfg.extra_trials,cfg.seed ^ 0xE87A352,return_regime=True)
        field_rows2=_sample_public_field(cal,cfg,rng,legal_rows,legal_feat); win2,t012,t12,t52=_thresholds(field_rows2,ex,cfg.field_size)
        bls=_lineup_scores(rows[bubble],ex,chunk=128); w2=(bls>win2[None,:]+1e-7).sum(axis=1)+0.5*(np.abs(bls-win2[None,:])<=1e-7).sum(axis=1)
        top01[bubble]+=(bls>=t012[None,:]-1e-7).sum(axis=1); top1[bubble]+=(bls>=t12[None,:]-1e-7).sum(axis=1); top5[bubble]+=(bls>=t52[None,:]-1e-7).sum(axis=1); win_credit[bubble]+=w2; trials[bubble]+=cfg.extra_trials
        base_bls=_lineup_scores(rows[bubble],sims,chunk=128); combo=np.concatenate([base_bls,bls],axis=1)
        lineup_p95[bubble]=np.quantile(combo,.95,axis=1).astype(np.float32); lineup_p99[bubble]=np.quantile(combo,.99,axis=1).astype(np.float32); extra_total=int(len(bubble)*cfg.extra_trials)
    top01_lcb,top01_ucb=_wilson(top01,trials)
    return {'win_rate':(win_credit/trials).astype(np.float64),'top01_rate':(top01/trials).astype(np.float64),'top01_lcb':top01_lcb.astype(np.float64),'top01_ucb':top01_ucb.astype(np.float64),'top1_rate':(top1/trials).astype(np.float64),'top5_rate':(top5/trials).astype(np.float64),'lineup_p95':lineup_p95,'lineup_p99':lineup_p99,'trials':trials,'BASE_SIM_TRIALS':cfg.base_trials,'BUBBLE_EXTRA_TRIALS_TOTAL':extra_total,'BUBBLE_LINEUPS_UNRESOLVED':0,'FAKE_FIELD_SIZE':cfg.field_size,'TOP01_FIELD_CUTOFF_N':max(1,int(math.ceil(cfg.field_size*0.001))),'FAKE_FIELD_UNIQUE_LINEUPS':int(len({tuple(map(int,r)) for r in field_rows.tolist()})),'STREAMING_PHASE3':True,'STREAMING_LINEUP_CHUNK':chunk,'regime_receipt':regime_receipt,'_base_player_sims':sims,'_top01_bits':top01_bits,'_win_bits':win_bits}

@njit(cache=True)
def _recurrence_counts_numba(sims,rows,topbits,winbits,q):
    n=rows.shape[0]; W=sims.shape[1]; NB=topbits.shape[1]
    sb=np.zeros((n,NB),np.uint8); cb=np.zeros((n,NB),np.uint8); cwb=np.zeros((n,NB),np.uint8); strict=np.zeros(n,np.int32); core=np.zeros(n,np.int32); cw=np.zeros(n,np.int32)
    for i in range(n):
        for w in range(W):
            if ((topbits[i,w>>3]>>(w&7))&1)==0: continue
            ac=True; as_=True; sc=0; ss=0
            for k in range(6):
                pid=rows[i,k]; v=sims[pid,w]
                if v<q[0,pid]: ac=False
                if v<q[1,pid]: as_=False
                if v>=q[2,pid]: sc+=1
                if v>=q[3,pid]: ss+=1
            ce=ac and sc>=4; se=as_ and ss>=5
            if ce:
                core[i]+=1; cb[i,w>>3]|=(1<<(w&7))
                if ((winbits[i,w>>3]>>(w&7))&1)!=0: cw[i]+=1; cwb[i,w>>3]|=(1<<(w&7))
            if se: strict[i]+=1; sb[i,w>>3]|=(1<<(w&7))
    return sb,cb,cwb,strict,core,cw

def _recurrence_arrays_cached(sim: dict[str,Any], rows: np.ndarray) -> tuple[np.ndarray,np.ndarray,np.ndarray,np.ndarray,np.ndarray,np.ndarray]:
    cached=sim.get("_recurrence_cache")
    if cached is not None:
        return cached
    sims=np.asarray(sim["_base_player_sims"],dtype=np.float32)
    topbits=np.asarray(sim["_top01_bits"],dtype=np.uint8)
    winbits=np.asarray(sim["_win_bits"],dtype=np.uint8)
    q=np.quantile(sims,[.30,.40,.75,.80],axis=1).astype(np.float32)
    cached=_recurrence_counts_numba(sims,np.asarray(rows,dtype=np.int32),topbits,winbits,q)
    sim["_recurrence_cache"]=cached
    return cached


@njit(cache=True)
def _pc_byte(x):
    c=0
    while x:
        c += x & 1; x >>= 1
    return c

@njit(cache=True)
def _row_overlap6(a,b):
    c=0
    for x in a:
        for y in b:
            if x==y: c+=1; break
    return c

@njit(cache=True)
def _greedy_recurrence_numba(cands,rows,sb,cb,cwb,strict,core,cw,ws,wcw,wc,base_s,base_c,target):
    NB=sb.shape[1]; us=np.zeros(NB,np.uint8); uc=np.zeros(NB,np.uint8); uw=np.zeros(NB,np.uint8); selected=np.full(target,-1,np.int32); used=np.zeros(len(cands),np.uint8)
    marginal=np.zeros(target,np.float64)
    for seat in range(target):
        best_pos=-1; best_i=-1; best_score=-1e300; best_s=-1; best_w=-1; best_c=-1; best_nov=-99
        for pos in range(len(cands)):
            if used[pos]: continue
            i=cands[pos]; ns=nw=nc=0
            for b in range(NB):
                ns += _pc_byte(int(sb[i,b] & np.uint8(~us[b]))); nw += _pc_byte(int(cwb[i,b] & np.uint8(~uw[b]))); nc += _pc_byte(int(cb[i,b] & np.uint8(~uc[b])))
            ov=0
            for z in range(seat):
                o=_row_overlap6(rows[i],rows[selected[z]])
                if o>ov: ov=o
            pen=18.0*(ov-4) if ov>=5 else 0.0
            score=ws*ns+wcw*nw+wc*nc+base_s*strict[i]+base_c*core[i]-pen
            nov=-ov
            better = (score>best_score) or (score==best_score and strict[i]>best_s) or (score==best_score and strict[i]==best_s and cw[i]>best_w) or (score==best_score and strict[i]==best_s and cw[i]==best_w and core[i]>best_c) or (score==best_score and strict[i]==best_s and cw[i]==best_w and core[i]==best_c and nov>best_nov)
            if better:
                best_pos=pos; best_i=i; best_score=score; best_s=strict[i]; best_w=cw[i]; best_c=core[i]; best_nov=nov
        if best_pos<0: break
        selected[seat]=best_i; marginal[seat]=best_score; used[best_pos]=1
        for b in range(NB): us[b]|=sb[best_i,b]; uc[b]|=cb[best_i,b]; uw[b]|=cwb[best_i,b]
    return selected,marginal

def _recurrence_portfolio_select(rows: np.ndarray, sim: dict[str,Any], cfg: Config) -> tuple[np.ndarray,dict[str,Any]]:
    sims=np.asarray(sim['_base_player_sims'],dtype=np.float32); topbits=np.asarray(sim['_top01_bits'],dtype=np.uint8); winbits=np.asarray(sim['_win_bits'],dtype=np.uint8)
    sb,cb,cwb,strict,core,cw=_recurrence_arrays_cached(sim,rows)
    fam={}
    for i,r in enumerate(rows): fam.setdefault(tuple(sorted(map(int,r))),[]).append(i)
    cands=[]
    for ids in fam.values():
        ids=sorted(ids,key=lambda i:(int(strict[i]),int(cw[i]),int(core[i])),reverse=True)[:2]; cands.extend(ids)
    cands=np.asarray(cands,dtype=np.int32)
    selected,marginal=_greedy_recurrence_numba(cands,np.asarray(rows,dtype=np.int32),sb,cb,cwb,strict,core,cw,8.0,4.0,2.0,.12,.08,min(cfg.final_board_size,len(rows)))
    selected=selected[selected>=0]
    return selected,{'CFB_RECURRENCE_SELECTOR_PATCH_ID':CFB_RECURRENCE_SELECTOR_PATCH,'RECURRENCE_VARIANT':'balanced_world','RECURRENCE_CANDIDATE_ROWS':int(len(cands)),'RECURRENCE_SELECTED_INDICES':[int(x) for x in selected.tolist()],'RECURRENCE_SELECTED_MARGINAL_SCORE':[float(x) for x in marginal[:len(selected)].tolist()],'RECURRENCE_COMMON_WORLDS':int(sims.shape[1])}

def _core5_quality_finalize(rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, cfg: Config, *, protected_indices: set[int]|None=None) -> tuple[np.ndarray,dict[str,Any]]:
    """Final five-seat championship-core decision.

    Structural CFB lanes are born upstream and remain selector-reviewed candidates.
    The final Core5 is chosen by the existing global forward-only extreme-value
    selector. A legacy incumbent may be protected only when the already-governed
    recurrence-consensus bridge earned continuity before this finalizer.
    """
    n=len(rows)
    if n <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_CORE5_EMPTY_SURFACE")
    field_size=max(1,int(cfg.field_size))
    model_rows=[]
    player_names=[]
    for i,r in enumerate(rows):
        own_product=float(np.exp(np.clip(float(pf["logown"][i]),-40.0,0.0)))
        model_rows.append({
            "MC_WIN_RATE":float(sim["win_rate"][i]),
            "MC_TOP_0_1_RATE":float(sim["top01_rate"][i]),
            "MC_TOP_1_RATE":float(sim["top1_rate"][i]),
            "TRIALS":int(sim["trials"][i]),
            "P95":float(sim["lineup_p95"][i]),
            "P99":float(sim["lineup_p99"][i]),
            "OWNERSHIP_PRODUCT":own_product,
            "FIELD_SIZE":field_size,
            "SIM_LEVERAGE":float(pf["leverage"][i]),
        })
        player_names.append([str(cal.names[int(x)]) for x in r])
    protected=sorted({int(x) for x in (protected_indices or set()) if 0 <= int(x) < n})
    result=extreme_value_v2.select_portfolio_rows(
        model_rows,
        players=player_names,
        board_size=min(cfg.final_board_size,n),
        protected_indices=protected,
        protected_priority={int(i):1.0 for i in protected},
        dominant_family_max=cfg.final_board_size,
    )
    selected=np.asarray(result.source_indices,dtype=np.int32)
    rec=dict(result.receipt)
    rec.update({
        "CFB_CORE5_QUALITY_FINALIZER_PATCH_ID":CFB_CORE5_QUALITY_FINALIZER_PATCH,
        "CFB_CORE5_QUALITY_FINALIZER_APPLIED":True,
        "CFB_CORE5_QUALITY_FINALIZER_SELECTOR_PATCH_ID":extreme_value_v2.PATCH_ID,
        "CFB_CORE5_QUALITY_FINALIZER_SOURCE_ROWS":int(n),
        "CFB_CORE5_QUALITY_FINALIZER_PROTECTED_INDICES":protected,
        "CFB_CORE5_QUALITY_FINALIZER_SELECTED_INDICES":[int(x) for x in selected.tolist()],
        "CFB_CORE5_QUALITY_FINALIZER_POSTLOCK_SIGNAL_USED":False,
        "CFB_CORE5_QUALITY_FINALIZER_PLAYER_NAME_CONSTANTS_USED":False,
        "CFB_CORE5_SPECIAL_LANES_FORCE_EVICTION_ALLOWED":False,
    })
    return selected,rec


def _max_entry_portfolio_finalize(rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, cfg: Config, *, protected_indices: set[int]|None=None) -> tuple[np.ndarray,dict[str,Any]]:
    """Select the complete requested contest portfolio. MAX ENTRY controls membership."""
    n=len(rows)
    if n <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_PORTFOLIO_EMPTY_SURFACE")
    target=min(int(cfg.final_board_size),n)
    if target < 1:
        raise RuntimeError("RUN_INVALID:CFB_PORTFOLIO_TARGET_INVALID")
    field_size=max(1,int(cfg.field_size))
    model_rows=[]; player_names=[]
    for i,r in enumerate(rows):
        own_product=float(np.exp(np.clip(float(pf["logown"][i]),-40.0,0.0)))
        model_rows.append({
            "MC_WIN_RATE":float(sim["win_rate"][i]),
            "MC_TOP_0_1_RATE":float(sim["top01_rate"][i]),
            "MC_TOP_1_RATE":float(sim["top1_rate"][i]),
            "TRIALS":int(sim["trials"][i]),
            "P95":float(sim["lineup_p95"][i]),
            "P99":float(sim["lineup_p99"][i]),
            "OWNERSHIP_PRODUCT":own_product,
            "FIELD_SIZE":field_size,
            "SIM_LEVERAGE":float(pf["leverage"][i]),
        })
        player_names.append([str(cal.names[int(x)]) for x in r])
    protected=sorted({int(x) for x in (protected_indices or set()) if 0 <= int(x) < n})
    result=extreme_value_v2.select_portfolio_rows(
        model_rows, players=player_names, board_size=target,
        protected_indices=protected,
        protected_priority={int(i):1.0 for i in protected},
        dominant_family_max=target,
    )
    selected=np.asarray(result.source_indices,dtype=np.int32)
    if len(selected) != target:
        raise RuntimeError(f"ENGINE_INTEGRITY_HALT:CFB_MAX_ENTRY_PORTFOLIO_SIZE:{len(selected)}!={target}")
    rec=dict(result.receipt)
    rec.update({
        "CFB_MAX_ENTRY_PORTFOLIO_PATCH_ID":CFB_LIVE_EXECUTION_HARD_CONTRACT_PATCH,
        "CFB_MAX_ENTRY_PORTFOLIO_TARGET":int(target),
        "CFB_MAX_ENTRY_PORTFOLIO_SOURCE_ROWS":int(n),
        "CFB_MAX_ENTRY_PORTFOLIO_PROTECTED_INDICES":protected,
        "CFB_MAX_ENTRY_PORTFOLIO_SELECTED_INDICES":[int(x) for x in selected.tolist()],
        "CFB_MAX_ENTRY_CONTROLS_MEMBERSHIP":True,
        "CFB_CORE5_CONTROLS_MEMBERSHIP":False,
        "CFB_MAX_ENTRY_PORTFOLIO_POSTLOCK_SIGNAL_USED":False,
    })
    return selected,rec


def _championship_head_order_only(portfolio: np.ndarray, rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray,dict[str,Any]]:
    """Rank a five-lineup championship head without adding/removing portfolio members."""
    portfolio=np.asarray(portfolio,dtype=np.int32)
    if len(portfolio) <= 1:
        return portfolio,{"CFB_CHAMPIONSHIP_HEAD_SIZE":int(len(portfolio)),"CFB_CHAMPIONSHIP_HEAD_ORDER_ONLY":True}
    head_size=min(5,len(portfolio))
    sub=portfolio
    sub_pf={k:np.asarray(v)[sub] for k,v in pf.items() if isinstance(v,np.ndarray) and len(v)==len(rows)}
    sub_sim={}
    for k,v in sim.items():
        if isinstance(v,np.ndarray) and len(v)==len(rows): sub_sim[k]=np.asarray(v)[sub]
        else: sub_sim[k]=v
    # Use the established extreme-value head ranker only inside the already-sealed
    # membership. It may reorder five seats; it may not alter portfolio membership.
    hcfg=Config(field_size=cfg.field_size,seed=cfg.seed,player_trials=cfg.player_trials,base_trials=cfg.base_trials,extra_trials=cfg.extra_trials,bubble_cap=cfg.bubble_cap,final_board_size=head_size)
    head_local,head_rec=_core5_quality_finalize(rows[sub],sub_pf,sub_sim,cal,hcfg,protected_indices=set())
    head=[int(sub[int(i)]) for i in head_local.tolist()]
    head_set=set(head)
    ordered=np.asarray(head+[int(i) for i in portfolio.tolist() if int(i) not in head_set],dtype=np.int32)
    if set(map(int,ordered.tolist())) != set(map(int,portfolio.tolist())) or len(ordered)!=len(portfolio):
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_CHAMPIONSHIP_HEAD_MUTATED_MEMBERSHIP")
    return ordered,{
        "CFB_CHAMPIONSHIP_HEAD_SIZE":int(head_size),
        "CFB_CHAMPIONSHIP_HEAD_INDICES":head,
        "CFB_CHAMPIONSHIP_HEAD_ORDER_ONLY":True,
        "CFB_CHAMPIONSHIP_HEAD_MEMBERSHIP_MUTATION_ALLOWED":False,
        "CFB_CHAMPIONSHIP_HEAD_SELECTOR_RECEIPT":head_rec,
    }


def _find_exact_row(rows: np.ndarray, target_row: np.ndarray) -> int:
    tgt=tuple(map(int,target_row.tolist()))
    for i,r in enumerate(rows):
        if tuple(map(int,r.tolist()))==tgt: return int(i)
    return -1

def _apply_incumbent_consensus_bridge(selected: np.ndarray, incumbent_idx: int, rows: np.ndarray) -> tuple[np.ndarray,dict[str,Any]]:
    selected=list(map(int,selected.tolist())); overlaps=[]
    if incumbent_idx<0: return np.asarray(selected,dtype=np.int32),{'CFB_CONSENSUS_BRIDGE_PATCH_ID':CFB_CONSENSUS_BRIDGE_PATCH,'INCUMBENT_INDEX':-1,'INCUMBENT_GATE':False,'INCUMBENT_OVERLAPS':[],'INCUMBENT_RESTORED':False}
    inc=set(map(int,rows[incumbent_idx])); overlaps=[len(inc & set(map(int,rows[i]))) for i in selected]
    gate=(sum(x>=4 for x in overlaps)>=3 and sum(x>=3 for x in overlaps)>=5); restored=False; replaced=None
    if gate and incumbent_idx not in selected and selected:
        replaced=int(selected[-1]); selected[-1]=int(incumbent_idx); restored=True
    return np.asarray(selected,dtype=np.int32),{'CFB_CONSENSUS_BRIDGE_PATCH_ID':CFB_CONSENSUS_BRIDGE_PATCH,'INCUMBENT_INDEX':int(incumbent_idx),'INCUMBENT_OVERLAPS':[int(x) for x in overlaps],'INCUMBENT_COUNT_GE4':int(sum(x>=4 for x in overlaps)),'INCUMBENT_COUNT_GE3':int(sum(x>=3 for x in overlaps)),'INCUMBENT_GATE':bool(gate),'INCUMBENT_RESTORED':bool(restored),'INCUMBENT_REPLACED_INDEX':replaced}




def _protected_special_lane_indices(chosen: list[int], rows: np.ndarray, pf: dict[str,np.ndarray], cal: Calibration) -> set[int]:
    missing=set(map(str,cal.missing_role_names)); protected=set()
    depth=_depth_numeric(cal)
    fav,dog,_=_favorite_team_prelock(cal)
    for i in chosen:
        r=np.asarray(rows[int(i)],dtype=np.int32); c=int(r[0]); cpos=str(cal.pos[c]); same=int(pf['same_cpt_team'][int(i)])
        names=[str(cal.names[int(x)]) for x in r]
        if cpos=='WR' and same==5 and not any(n in missing for n in names): protected.add(int(i))
        if cpos=='WR' and int(cal.salary[c])<=6000 and same==3:
            flex=r[1:]; fpos=cal.pos[flex]
            if int(np.sum(fpos=='QB'))>=2 and int(np.sum(fpos=='RB'))>=2: protected.add(int(i))
        if int(np.sum(cal.pos[r]=='QB'))==2 and any(int(cal.salary[int(x)])<=1500 for x in r): protected.add(int(i))
        # Protect the documented favorite 5-1 QB-CPT lane when present.
        if cpos=='QB' and str(cal.team[c])==fav and same==5 and np.isfinite(depth[c]) and depth[c]<=1.25:
            oppq=[int(x) for x in r[1:] if str(cal.team[int(x)])==dog and str(cal.pos[int(x)])=='QB' and np.isfinite(depth[int(x)]) and depth[int(x)]<=1.25]
            if oppq and all(np.isfinite(depth[int(x)]) and depth[int(x)]<=2.25 for x in r): protected.add(int(i))
    return protected


def _replace_with_protected_reserve(chosen: np.ndarray, reserve: int, rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, extra_protect: set[int]|None=None) -> tuple[np.ndarray,dict[str,Any]]:
    out=list(map(int,np.asarray(chosen,dtype=np.int32).tolist()))
    if reserve in out: return np.asarray(out,dtype=np.int32),{'APPLIED':False,'REASON':'ALREADY_SELECTED','RESERVE_INDEX':int(reserve)}
    protected=_protected_special_lane_indices(out,rows,pf,cal)
    if extra_protect: protected.update(map(int,extra_protect))
    eligible=[z for z,i in enumerate(out) if int(i) not in protected]
    if not eligible: return np.asarray(out,dtype=np.int32),{'APPLIED':False,'REASON':'NO_REPLACEABLE_SEAT','RESERVE_INDEX':int(reserve),'PROTECTED_COUNT':len(protected)}
    def redundancy(pos:int):
        i=out[pos]; si=set(map(int,rows[i].tolist())); ovs=[len(si & set(map(int,rows[j].tolist()))) for z,j in enumerate(out) if z!=pos]
        return (sum(ovs),max(ovs) if ovs else 0,-float(sim['top01_rate'][i]))
    rp=max(eligible,key=redundancy); replaced=int(out[rp]); out[rp]=int(reserve)
    return np.asarray(out,dtype=np.int32),{'APPLIED':True,'REASON':'RESERVED_SEAT','RESERVE_INDEX':int(reserve),'REPLACED_INDEX':replaced,'REPLACED_SEAT':int(rp+1),'PROTECTED_COUNT':len(protected)}


def _known_role_5_1_qb_cpt_core_completion_reserve(selected: np.ndarray, rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray,dict[str,Any]]:
    entry_limit=_contest_entry_limit(cfg)
    base={'CFB_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_PATCH_ID':CFB_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_PATCH,'CFB_5_1_QB_CPT_ENTRY_LIMIT':int(entry_limit),'CFB_5_1_QB_CPT_POSTLOCK_SIGNAL_USED':False}
    if entry_limit<20: return np.asarray(selected,dtype=np.int32),{**base,'CFB_5_1_QB_CPT_APPLIED':False,'CFB_5_1_QB_CPT_REASON':'ENTRY_LIMIT_LT_20'}
    lane=_known_role_5_1_qb_cpt_core_completion_lane(cal,16)
    found=[]
    for rank,row in enumerate(lane,1):
        idx=_find_exact_row(rows,np.asarray(row,dtype=np.int16))
        if idx>=0: found.append((_raw_prelock_projection(row,cal),-rank,int(idx)))
    if not found: return np.asarray(selected,dtype=np.int32),{**base,'CFB_5_1_QB_CPT_APPLIED':False,'CFB_5_1_QB_CPT_REASON':'NO_CANDIDATE_IN_HANDOFF'}
    found.sort(reverse=True); reserve=int(found[0][2]); proj=float(found[0][0])
    out,repl=_replace_with_protected_reserve(selected,reserve,rows,pf,sim,cal)
    return out,{**base,'CFB_5_1_QB_CPT_APPLIED':bool(repl['APPLIED']),'CFB_5_1_QB_CPT_REASON':str(repl['REASON']),'CFB_5_1_QB_CPT_INDEX':reserve,'CFB_5_1_QB_CPT_PRELOCK_PROJECTION':proj,'CFB_5_1_QB_CPT_REPLACED_INDEX':repl.get('REPLACED_INDEX'),'CFB_5_1_QB_CPT_REPLACED_SEAT':repl.get('REPLACED_SEAT')}


def _favorite_control_rb_cpt_4_2_single_qb_reserve(selected: np.ndarray, rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, cfg: Config, protect: set[int]|None=None) -> tuple[np.ndarray,dict[str,Any]]:
    entry_limit=_contest_entry_limit(cfg)
    base={'CFB_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_PATCH_ID':CFB_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_PATCH,'CFB_4_2_RB_CPT_ENTRY_LIMIT':int(entry_limit),'CFB_4_2_RB_CPT_POSTLOCK_SIGNAL_USED':False,'CFB_4_2_RB_CPT_PLAYER_NAME_CONSTANTS_USED':False}
    if entry_limit<20: return np.asarray(selected,dtype=np.int32),{**base,'CFB_4_2_RB_CPT_APPLIED':False,'CFB_4_2_RB_CPT_REASON':'ENTRY_LIMIT_LT_20'}
    lane=_favorite_control_rb_cpt_4_2_single_qb_lane(cal,16)
    sb,cb,cwb,strict,core,cw=_recurrence_arrays_cached(sim,rows)
    cand=[]
    for rank,row in enumerate(lane,1):
        idx=_find_exact_row(rows,np.asarray(row,dtype=np.int16))
        if idx<0: continue
        sc=float(8.12*int(strict[idx])+4.0*int(cw[idx])+2.08*int(core[idx]))
        cand.append((sc,int(strict[idx]),int(cw[idx]),int(core[idx]),float(sim['top01_rate'][idx]),-rank,int(idx)))
    if not cand: return np.asarray(selected,dtype=np.int32),{**base,'CFB_4_2_RB_CPT_APPLIED':False,'CFB_4_2_RB_CPT_REASON':'NO_CANDIDATE_IN_HANDOFF','CFB_4_2_RB_CPT_LANE_FAMILIES':int(len(lane))}
    cand.sort(reverse=True); sc,st,wc,co,t01,_nr,reserve=cand[0]; reserve=int(reserve)
    out,repl=_replace_with_protected_reserve(selected,reserve,rows,pf,sim,cal,extra_protect=protect)
    return out,{**base,'CFB_4_2_RB_CPT_APPLIED':bool(repl['APPLIED']),'CFB_4_2_RB_CPT_REASON':str(repl['REASON']),'CFB_4_2_RB_CPT_INDEX':reserve,'CFB_4_2_RB_CPT_RECURRENCE_SCALAR':float(sc),'CFB_4_2_RB_CPT_STRICT':int(st),'CFB_4_2_RB_CPT_COMMON_WIN':int(wc),'CFB_4_2_RB_CPT_CORE':int(co),'CFB_4_2_RB_CPT_TOP01_RATE':float(t01),'CFB_4_2_RB_CPT_LANE_FAMILIES':int(len(lane)),'CFB_4_2_RB_CPT_REPLACED_INDEX':repl.get('REPLACED_INDEX'),'CFB_4_2_RB_CPT_REPLACED_SEAT':repl.get('REPLACED_SEAT')}



def _secondary_favorite_rb_cpt_family_retention_candidate(rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, cfg: Config) -> tuple[int,dict[str,Any]]:
    """Return one bounded championship-family candidate for Core5 protection.

    This is a forward-blind canary for large-favorite Showdown environments where a
    secondary favorite RB can captain a balanced 3-3 / dual-starting-QB lineup. The
    identity family must already have been born by the bounded production birth lane.
    Selection is relative only to this narrow structural family and uses simulated
    championship evidence; it never uses player names or postlock outcomes.
    """
    entry_limit=_contest_entry_limit(cfg)
    base={
        'CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_PATCH_ID':CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_PATCH,
        'CFB_SECONDARY_FAVORITE_RB_CPT_ENTRY_LIMIT':int(entry_limit),
        'CFB_SECONDARY_FAVORITE_RB_CPT_POSTLOCK_SIGNAL_USED':False,
        'CFB_SECONDARY_FAVORITE_RB_CPT_PLAYER_NAME_CONSTANTS_USED':False,
    }
    if entry_limit < 20:
        return -1,{**base,'CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_APPLIED':False,'CFB_SECONDARY_FAVORITE_RB_CPT_REASON':'ENTRY_LIMIT_LT_20'}
    fav,dog,metrics=_favorite_team_prelock(cal)
    fav_spread=float(metrics.get(fav,0.0)) if isinstance(metrics,dict) else 0.0
    if not math.isfinite(fav_spread) or fav_spread > -14.5:
        return -1,{**base,'CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_APPLIED':False,'CFB_SECONDARY_FAVORITE_RB_CPT_REASON':'NOT_LARGE_FAVORITE','CFB_SECONDARY_FAVORITE_RB_CPT_FAVORITE_SPREAD':fav_spread}
    depth=_depth_numeric(cal)
    value=cal.p99/np.maximum(1.0,cal.salary.astype(float)/1000.0)
    cand=[]
    for i,r in enumerate(rows):
        r=np.asarray(r,dtype=np.int32); c=int(r[0])
        if str(cal.team[c])!=fav or str(cal.pos[c])!='RB' or not (1.25 < float(depth[c]) <= 2.25):
            continue
        if int(pf['same_cpt_team'][i]) != 3:
            continue
        flex=np.asarray(r[1:],dtype=np.int32)
        qbs=[int(x) for x in flex if str(cal.pos[int(x)])=='QB' and math.isfinite(float(depth[int(x)])) and float(depth[int(x)])<=1.25]
        if len(qbs)!=2 or {str(cal.team[x]) for x in qbs}!={fav,dog}:
            continue
        fav_value_pc=[int(x) for x in flex if str(cal.team[int(x)])==fav and str(cal.pos[int(x)]) in {'WR','TE'} and int(cal.salary[int(x)])<=3000 and float(value[int(x)])>=4.0]
        dog_rbs=[int(x) for x in flex if str(cal.team[int(x)])==dog and str(cal.pos[int(x)])=='RB' and math.isfinite(float(depth[int(x)])) and float(depth[int(x)])<=1.25]
        dog_pc=[int(x) for x in flex if str(cal.team[int(x)])==dog and str(cal.pos[int(x)]) in {'WR','TE'} and math.isfinite(float(depth[int(x)])) and float(depth[int(x)])<=1.25]
        if not fav_value_pc or not dog_rbs or not dog_pc:
            continue
        cand.append(int(i))
    if not cand:
        return -1,{**base,'CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_APPLIED':False,'CFB_SECONDARY_FAVORITE_RB_CPT_REASON':'NO_CANDIDATE_IN_HANDOFF','CFB_SECONDARY_FAVORITE_RB_CPT_FAVORITE_SPREAD':fav_spread}

    _,_,_,strict,core,cw=_recurrence_arrays_cached(sim,rows)
    def rank01(vals: np.ndarray) -> np.ndarray:
        vals=np.asarray(vals,dtype=float)
        if len(vals)<=1: return np.ones(len(vals),dtype=float)
        order=np.argsort(vals,kind='stable'); out=np.empty(len(vals),dtype=float); out[order]=np.arange(len(vals),dtype=float)/(len(vals)-1)
        return out
    a=np.asarray(cand,dtype=np.int32)
    rec_scalar=8.12*strict[a].astype(float)+4.0*cw[a].astype(float)+2.08*core[a].astype(float)
    win_r=rank01(np.asarray(sim['win_rate'],dtype=float)[a])
    t1_r=rank01(np.asarray(sim['top1_rate'],dtype=float)[a])
    t5_r=rank01(np.asarray(sim['top5_rate'],dtype=float)[a])
    p99_r=rank01(np.asarray(sim['lineup_p99'],dtype=float)[a])
    rec_r=rank01(rec_scalar)
    family_score=.30*win_r+.25*t1_r+.15*t5_r+.20*p99_r+.10*rec_r
    eligible=np.where((t1_r>=.70)&(p99_r>=.70)&(rec_r>=.40))[0]
    if len(eligible)==0:
        return -1,{**base,'CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_APPLIED':False,'CFB_SECONDARY_FAVORITE_RB_CPT_REASON':'NO_ROBUST_FAMILY_LEADER','CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_ROWS':int(len(cand)),'CFB_SECONDARY_FAVORITE_RB_CPT_FAVORITE_SPREAD':fav_spread}
    z=max(map(int,eligible.tolist()),key=lambda j:(float(family_score[j]),float(sim['top1_rate'][int(a[j])]),float(sim['lineup_p99'][int(a[j])]),float(sim['win_rate'][int(a[j])]),float(rec_scalar[j]),-int(a[j])))
    reserve=int(a[z])
    return reserve,{**base,
        'CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_APPLIED':True,
        'CFB_SECONDARY_FAVORITE_RB_CPT_REASON':'ROBUST_NARROW_FAMILY_LEADER',
        'CFB_SECONDARY_FAVORITE_RB_CPT_INDEX':reserve,
        'CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_ROWS':int(len(cand)),
        'CFB_SECONDARY_FAVORITE_RB_CPT_FAVORITE_SPREAD':fav_spread,
        'CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_SCORE':float(family_score[z]),
        'CFB_SECONDARY_FAVORITE_RB_CPT_WIN_RATE':float(sim['win_rate'][reserve]),
        'CFB_SECONDARY_FAVORITE_RB_CPT_TOP1_RATE':float(sim['top1_rate'][reserve]),
        'CFB_SECONDARY_FAVORITE_RB_CPT_TOP5_RATE':float(sim['top5_rate'][reserve]),
        'CFB_SECONDARY_FAVORITE_RB_CPT_P99':float(sim['lineup_p99'][reserve]),
        'CFB_SECONDARY_FAVORITE_RB_CPT_RECURRENCE_SCALAR':float(rec_scalar[z]),
    }

def _balanced_dual_qb_value_family_reserve(selected: np.ndarray, rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration) -> tuple[np.ndarray,dict[str,Any]]:
    chosen=list(map(int,np.asarray(selected,dtype=np.int32).tolist()))
    sims=np.asarray(sim['_base_player_sims'],dtype=np.float32); topbits=np.asarray(sim['_top01_bits'],dtype=np.uint8); winbits=np.asarray(sim['_win_bits'],dtype=np.uint8)
    sb,cb,cwb,strict,core,cw=_recurrence_arrays_cached(sim,rows)
    missing=set(map(str,cal.missing_role_names)); fam={}
    for i,r in enumerate(rows): fam.setdefault(tuple(sorted(map(int,r.tolist()))),[]).append(i)
    candidates=[]
    for key,ids in fam.items():
        arr=np.asarray(key,dtype=np.int32); qbs=[int(x) for x in arr if str(cal.pos[int(x)])=='QB']
        if len(qbs)!=2 or len({str(cal.team[x]) for x in qbs})!=2: continue
        if any(str(cal.names[int(x)]) in missing for x in arr): continue
        cheap=[int(x) for x in arr if int(cal.salary[int(x)])<=1500]
        if not cheap: continue
        # Strong cheap-player value is prelock source/calibration information only.
        value=max(float(cal.mu[x])/(max(1000,int(cal.salary[x]))/1000.0) for x in cheap)
        if value < 5.0: continue
        high=max(qbs,key=lambda x:int(cal.salary[x]))
        hrows=[int(i) for i in ids if int(rows[i,0])==high and int(pf['same_cpt_team'][i])==3]
        if not hrows: continue
        h=hrows[0]; total=int(cal.salary[high]*1.5+cal.salary[rows[h,1:]].sum())
        if total<49500: continue
        qrows=[int(i) for i in ids if int(rows[i,0]) in qbs and int(pf['same_cpt_team'][i])==3]
        agg=sum(8.12*int(strict[i])+4.0*int(cw[i])+2.08*int(core[i]) for i in qrows)
        candidates.append((value,agg,8.12*int(strict[h])+4.0*int(cw[h])+2.08*int(core[h]),float(sim['top01_rate'][h]),h))
    if not candidates: return np.asarray(chosen,dtype=np.int32),{'CFB_DUAL_QB_VALUE_RESERVE_PATCH_ID':CFB_DUAL_QB_VALUE_RESERVE_PATCH,'DUAL_QB_VALUE_APPLIED':False,'DUAL_QB_VALUE_REASON':'NO_CANDIDATE'}
    candidates.sort(reverse=True); value,agg,sc,t01,reserve=candidates[0]; reserve=int(reserve)
    if reserve in chosen: return np.asarray(chosen,dtype=np.int32),{'CFB_DUAL_QB_VALUE_RESERVE_PATCH_ID':CFB_DUAL_QB_VALUE_RESERVE_PATCH,'DUAL_QB_VALUE_APPLIED':False,'DUAL_QB_VALUE_REASON':'ALREADY_SELECTED','DUAL_QB_VALUE_INDEX':reserve}
    # Protect earned special-lane seats from later reserve replacement.
    protected=set()
    for i in chosen:
        r=rows[i]; c=int(r[0])
        if str(cal.pos[c])=='WR' and int(pf['same_cpt_team'][i])==3 and int(cal.salary[c])<=6000: protected.add(i)
        if str(cal.pos[c])=='WR' and int(pf['same_cpt_team'][i])==5 and all(str(cal.names[int(x)]) not in missing for x in r):
            if int(strict[i])>=40 and int(cw[i])>=70 and int(core[i])>=120: protected.add(i)
    eligible=[z for z,i in enumerate(chosen) if i not in protected]
    if not eligible: return np.asarray(chosen,dtype=np.int32),{'CFB_DUAL_QB_VALUE_RESERVE_PATCH_ID':CFB_DUAL_QB_VALUE_RESERVE_PATCH,'DUAL_QB_VALUE_APPLIED':False,'DUAL_QB_VALUE_REASON':'NO_REPLACEABLE_SEAT','DUAL_QB_VALUE_INDEX':reserve}
    def redundancy(pos:int):
        i=chosen[pos]; si=set(map(int,rows[i].tolist())); ovs=[len(si & set(map(int,rows[j].tolist()))) for z,j in enumerate(chosen) if z!=pos]
        return (sum(ovs),max(ovs) if ovs else 0,-float(sim['top01_rate'][i]))
    rp=max(eligible,key=redundancy); replaced=int(chosen[rp]); chosen[rp]=reserve
    return np.asarray(chosen,dtype=np.int32),{'CFB_DUAL_QB_VALUE_RESERVE_PATCH_ID':CFB_DUAL_QB_VALUE_RESERVE_PATCH,'DUAL_QB_VALUE_APPLIED':True,'DUAL_QB_VALUE_INDEX':reserve,'DUAL_QB_VALUE_REPLACED_INDEX':replaced,'DUAL_QB_VALUE_REPLACED_SEAT':rp+1,'DUAL_QB_VALUE_SCORE':float(value),'DUAL_QB_VALUE_FAMILY_RECURRENCE':float(agg),'DUAL_QB_VALUE_POSTLOCK_SIGNAL_USED':False}

def _known_role_5_1_wr_cpt_reserve(selected: np.ndarray, rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration) -> tuple[np.ndarray,dict[str,Any]]:
    chosen=list(map(int,np.asarray(selected,dtype=np.int32).tolist()))
    sims=np.asarray(sim['_base_player_sims'],dtype=np.float32); topbits=np.asarray(sim['_top01_bits'],dtype=np.uint8); winbits=np.asarray(sim['_win_bits'],dtype=np.uint8)
    sb,cb,cwb,strict,core,cw=_recurrence_arrays_cached(sim,rows)
    missing=set(map(str,cal.missing_role_names)); cand=[]
    for i,r in enumerate(rows):
        c=int(r[0])
        if str(cal.pos[c])!='WR' or int(pf['same_cpt_team'][i])!=5: continue
        if any(str(cal.names[int(x)]) in missing for x in r): continue
        sc=8.12*int(strict[i])+4.0*int(cw[i])+2.08*int(core[i])
        cand.append((sc,int(strict[i]),int(cw[i]),int(core[i]),float(sim['top01_rate'][i]),int(i)))
    if not cand: return np.asarray(chosen,dtype=np.int32),{'CFB_KNOWN_ROLE_5_1_RESERVE_PATCH_ID':CFB_KNOWN_ROLE_5_1_RESERVE_PATCH,'KNOWN_ROLE_5_1_APPLIED':False,'KNOWN_ROLE_5_1_REASON':'NO_CANDIDATE'}
    cand.sort(reverse=True); sc,st,wc,co,t01,reserve=cand[0]
    if st<40 or wc<70 or co<120:
        return np.asarray(chosen,dtype=np.int32),{'CFB_KNOWN_ROLE_5_1_RESERVE_PATCH_ID':CFB_KNOWN_ROLE_5_1_RESERVE_PATCH,'KNOWN_ROLE_5_1_APPLIED':False,'KNOWN_ROLE_5_1_REASON':'BELOW_GATE','KNOWN_ROLE_5_1_INDEX':reserve}
    if reserve in chosen:
        return np.asarray(chosen,dtype=np.int32),{'CFB_KNOWN_ROLE_5_1_RESERVE_PATCH_ID':CFB_KNOWN_ROLE_5_1_RESERVE_PATCH,'KNOWN_ROLE_5_1_APPLIED':False,'KNOWN_ROLE_5_1_REASON':'ALREADY_SELECTED','KNOWN_ROLE_5_1_INDEX':reserve}
    def redundancy(pos:int):
        i=chosen[pos]; si=set(map(int,rows[i].tolist())); ovs=[len(si & set(map(int,rows[j].tolist()))) for z,j in enumerate(chosen) if z!=pos]
        return (sum(ovs),max(ovs) if ovs else 0,-float(sim['top01_rate'][i]))
    rp=max(range(len(chosen)),key=redundancy); replaced=int(chosen[rp]); chosen[rp]=reserve
    return np.asarray(chosen,dtype=np.int32),{'CFB_KNOWN_ROLE_5_1_RESERVE_PATCH_ID':CFB_KNOWN_ROLE_5_1_RESERVE_PATCH,'KNOWN_ROLE_5_1_APPLIED':True,'KNOWN_ROLE_5_1_INDEX':reserve,'KNOWN_ROLE_5_1_REPLACED_INDEX':replaced,'KNOWN_ROLE_5_1_REPLACED_SEAT':rp+1,'KNOWN_ROLE_5_1_STRICT':st,'KNOWN_ROLE_5_1_CORE':co,'KNOWN_ROLE_5_1_CW':wc,'KNOWN_ROLE_5_1_POSTLOCK_SIGNAL_USED':False}

def _balanced_value_cpt_same_role_hedge(selected: np.ndarray, rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration) -> tuple[np.ndarray,dict[str,Any]]:
    """Reserve one forward-blind cheap-WR-CPT balanced offense hedge.

    Anchor contract: known-role WR CPT, CPT salary <= 6000, role strength >= .60,
    balanced 3-3 team split, both QBs present in FLEX, and at least two RBs in FLEX.
    Among qualifying anchors choose the cheapest CPT; ties prefer common-world
    recurrence (strict, winning-core, core, Top-0.1). The hedge must keep the
    same CPT and differ by exactly one FLEX player, with the outgoing/incoming
    players sharing team and position. Choose the sibling adding the most new
    Top-0.1 worlds beyond the anchor. If absent from the five-seat board, replace
    the most identity-redundant selected row. No postlock or player-name signal.
    """
    chosen=list(map(int,np.asarray(selected,dtype=np.int32).tolist()))
    if not chosen or len(rows)==0:
        return np.asarray(chosen,dtype=np.int32), {'CFB_BALANCED_VALUE_HEDGE_PATCH_ID':CFB_BALANCED_VALUE_HEDGE_PATCH,'HEDGE_APPLIED':False,'HEDGE_REASON':'EMPTY'}
    sims=np.asarray(sim['_base_player_sims'],dtype=np.float32)
    topbits=np.asarray(sim['_top01_bits'],dtype=np.uint8); winbits=np.asarray(sim['_win_bits'],dtype=np.uint8)
    sb,cb,cwb,strict,core,cw=_recurrence_arrays_cached(sim,rows)
    missing=set(map(str,cal.missing_role_names))
    anchors=[]
    for i,r in enumerate(rows):
        c=int(r[0])
        if str(cal.pos[c])!='WR' or int(cal.salary[c])>6000 or float(cal.role_strength[c])<0.60: continue
        if int(pf['same_cpt_team'][i])!=3: continue
        flex=np.asarray(r[1:],dtype=np.int32); fpos=cal.pos[flex]
        if int(np.sum(fpos=='QB'))<2 or int(np.sum(fpos=='RB'))<2: continue
        if any(str(cal.names[int(x)]) in missing for x in r): continue
        anchors.append(int(i))
    if not anchors:
        return np.asarray(chosen,dtype=np.int32), {'CFB_BALANCED_VALUE_HEDGE_PATCH_ID':CFB_BALANCED_VALUE_HEDGE_PATCH,'HEDGE_APPLIED':False,'HEDGE_REASON':'NO_ANCHOR'}
    min_cpt_salary=min(int(cal.salary[int(rows[i,0])]) for i in anchors)
    anchors=[i for i in anchors if int(cal.salary[int(rows[i,0])])==min_cpt_salary]
    anchor=max(anchors,key=lambda i:(int(strict[i]),int(cw[i]),int(core[i]),float(sim['top01_rate'][i]),float(sim['lineup_p99'][i])))
    ar=np.asarray(rows[anchor],dtype=np.int32); aset=set(map(int,ar.tolist())); abits=np.asarray(topbits[anchor],dtype=np.uint8)
    def popcnt_bytes(x: np.ndarray)->int:
        return int(np.unpackbits(np.asarray(x,dtype=np.uint8),bitorder='little').sum())
    sibs=[]
    for i,r in enumerate(rows):
        if i==anchor or int(r[0])!=int(ar[0]): continue
        rset=set(map(int,r.tolist())); inter=aset & rset
        if len(inter)!=5: continue
        out=list(aset-rset); inn=list(rset-aset)
        if len(out)!=1 or len(inn)!=1: continue
        x,y=int(out[0]),int(inn[0])
        if str(cal.team[x])!=str(cal.team[y]) or str(cal.pos[x])!=str(cal.pos[y]): continue
        new_worlds=popcnt_bytes(np.asarray(topbits[i],dtype=np.uint8) & np.bitwise_not(abits))
        sibs.append((new_worlds,int(strict[i]),int(cw[i]),int(core[i]),float(sim['top01_rate'][i]),float(sim['lineup_p99'][i]),int(i)))
    if not sibs:
        return np.asarray(chosen,dtype=np.int32), {'CFB_BALANCED_VALUE_HEDGE_PATCH_ID':CFB_BALANCED_VALUE_HEDGE_PATCH,'HEDGE_APPLIED':False,'HEDGE_REASON':'NO_SAME_ROLE_SIBLING','HEDGE_ANCHOR_INDEX':int(anchor)}
    sibs.sort(reverse=True); hedge=int(sibs[0][-1]); new_worlds=int(sibs[0][0])
    # v3: the forward-blind anchor is the primary structural lane. Do not discard
    # the anchor merely to surface its same-role sibling. The sibling is a hedge
    # only when the anchor is already represented on the portfolio entering this
    # operator. This removes seed-sensitive anchor inversion while preserving the
    # original same-role diversification behavior.
    def redundancy(pos:int, protect:set[int]|None=None)->tuple[int,int,float]:
        protect = protect or set()
        if chosen[pos] in protect:
            return (-10**9,-10**9,10**9)
        i=chosen[pos]; si=set(map(int,rows[i].tolist())); ovs=[]
        for z,j in enumerate(chosen):
            if z==pos: continue
            ovs.append(len(si & set(map(int,rows[j].tolist()))))
        return (sum(ovs),max(ovs) if ovs else 0,-float(sim['top01_rate'][i]))
    if anchor not in chosen:
        replace_pos=max(range(len(chosen)),key=lambda p: redundancy(p))
        replaced=int(chosen[replace_pos]); chosen[replace_pos]=int(anchor)
        return np.asarray(chosen,dtype=np.int32), {
            'CFB_BALANCED_VALUE_HEDGE_PATCH_ID':CFB_BALANCED_VALUE_HEDGE_PATCH,'HEDGE_APPLIED':True,
            'HEDGE_REASON':'ANCHOR_RETAINED_FIRST','HEDGE_ANCHOR_RETAINED':True,
            'HEDGE_ANCHOR_INDEX':int(anchor),'HEDGE_INDEX':int(hedge),'HEDGE_NEW_TOP01_WORLDS':new_worlds,
            'HEDGE_REPLACED_INDEX':replaced,'HEDGE_REPLACED_SEAT':int(replace_pos+1),
            'HEDGE_ANCHOR_CPT_SALARY':int(min_cpt_salary),'HEDGE_POSTLOCK_SIGNAL_USED':False}
    if hedge in chosen:
        return np.asarray(chosen,dtype=np.int32), {'CFB_BALANCED_VALUE_HEDGE_PATCH_ID':CFB_BALANCED_VALUE_HEDGE_PATCH,'HEDGE_APPLIED':False,'HEDGE_REASON':'ANCHOR_AND_HEDGE_ALREADY_SELECTED','HEDGE_ANCHOR_RETAINED':True,'HEDGE_ANCHOR_INDEX':int(anchor),'HEDGE_INDEX':hedge,'HEDGE_NEW_TOP01_WORLDS':new_worlds}
    replace_pos=max(range(len(chosen)),key=lambda p: redundancy(p,{int(anchor)}))
    replaced=int(chosen[replace_pos]); chosen[replace_pos]=hedge
    return np.asarray(chosen,dtype=np.int32), {
        'CFB_BALANCED_VALUE_HEDGE_PATCH_ID':CFB_BALANCED_VALUE_HEDGE_PATCH,'HEDGE_APPLIED':True,
        'HEDGE_REASON':'SIBLING_ADDED_WITH_ANCHOR_PRESENT','HEDGE_ANCHOR_RETAINED':True,
        'HEDGE_ANCHOR_INDEX':int(anchor),'HEDGE_INDEX':int(hedge),'HEDGE_NEW_TOP01_WORLDS':new_worlds,
        'HEDGE_REPLACED_INDEX':replaced,'HEDGE_REPLACED_SEAT':int(replace_pos+1),
        'HEDGE_ANCHOR_CPT_SALARY':int(min_cpt_salary),
        'HEDGE_POSTLOCK_SIGNAL_USED':False}

def _portfolio_select(rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray,np.ndarray,dict[str,Any]]:
    win=sim["win_rate"]; t01=sim["top01_rate"]; t1=sim["top1_rate"]; p99=sim["lineup_p99"]
    rank_score=(0.44*_pct(win)+0.30*_pct(t01)+0.08*_pct(sim["top01_lcb"])+0.07*_pct(t1)+0.06*_pct(p99)
                +0.03*_pct(pf["leverage"])+0.02*_pct(pf["role"]))
    order=np.argsort(rank_score,kind="stable")[::-1]
    target=min(cfg.final_board_size,len(rows))
    teams=list(dict.fromkeys(cal.team.tolist()))
    probs=sim["regime_receipt"].get("TEAM_WIN_PROBABILITIES",{})
    p0=float(probs.get(str(teams[0]),0.5)); p1=float(probs.get(str(teams[1]),1.0-p0))
    # Four directional slots are allocated to material team-win regimes; the fifth
    # is reserved for a close/balanced script when available.
    if p0 >= 0.20 and p1 >= 0.20:
        q0=int(np.clip(round(4.0*p0/(p0+p1)),1,3)); q1=4-q0
    elif p0 > p1:
        q0,q1=4,0
    else:
        q0,q1=0,4
    lanes=["CLOSE"] + [str(teams[0])]*q0 + [str(teams[1])]*q1

    def attempt(max_overlap:int,cpt_cap:int,player_cap:int,family_cap:int)->list[int]:
        chosen=[]; cpt_count={}; player_count=np.zeros(len(cal.names),dtype=np.int16); fam_count={}
        def admissible(i:int)->bool:
            row=rows[i]; c=int(row[0]); fam=(str(cal.team[c]),int(pf["same_cpt_team"][i]))
            if cpt_count.get(c,0)>=cpt_cap: return False
            if np.any(player_count[row]>=player_cap): return False
            if fam_count.get(fam,0)>=family_cap: return False
            if any(len(set(map(int,row))&set(map(int,rows[j])))>max_overlap for j in chosen): return False
            return True
        def add(i:int)->None:
            row=rows[i]; c=int(row[0]); fam=(str(cal.team[c]),int(pf["same_cpt_team"][i]))
            chosen.append(int(i)); cpt_count[c]=cpt_count.get(c,0)+1; player_count[row]+=1; fam_count[fam]=fam_count.get(fam,0)+1
        for lane in lanes:
            for i in order:
                if int(i) in chosen: continue
                c=int(rows[i,0]); cteam=str(cal.team[c])
                if lane == "CLOSE":
                    if int(pf["same_cpt_team"][i]) != 3: continue
                elif cteam != lane:
                    continue
                if admissible(int(i)):
                    add(int(i)); break
            if len(chosen)>=target: break
        if len(chosen)<target:
            for i in order:
                if int(i) in chosen: continue
                if admissible(int(i)):
                    add(int(i))
                if len(chosen)>=target: break
        return chosen

    chosen=attempt(4,2,4,3); relaxation=0
    if len(chosen)<target:
        chosen=attempt(5,2,5,3); relaxation=1
    if len(chosen)<target:
        chosen=attempt(5,3,5,4); relaxation=2
    if len(chosen)<target:
        chosen=list(map(int,order[:target])); relaxation=3
    coverage={str(t):int(sum(str(cal.team[int(rows[i,0])])==str(t) for i in chosen)) for t in teams}
    coverage["CLOSE_3_3"]=int(sum(int(pf["same_cpt_team"][i])==3 for i in chosen))
    return np.asarray(chosen,dtype=np.int32),np.asarray([relaxation],dtype=np.int8),{
        "REGIME_SELECTOR_TARGET_LANES":lanes,
        "REGIME_SELECTOR_COVERAGE":coverage,
        "TEAM_WIN_PROBABILITIES":{str(teams[0]):p0,str(teams[1]):p1},
    }


def _write(board_idx: np.ndarray, rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, legal_rows: np.ndarray, cfg: Config, board_path: str|Path, receipt_path: str|Path, phase2_receipt: dict[str,int], relaxation: np.ndarray, generation_receipt: dict[str,Any], selector_regime_receipt: dict[str,Any]) -> tuple[pd.DataFrame,dict[str,Any]]:
    recs=[]
    for rank,i in enumerate(board_idx.tolist(),1):
        row=rows[i]; names=cal.names[row]; pos=cal.pos[row]; teams=cal.team[row]
        recs.append({
            "RANK":rank,"CPT":names[0],"CPT_POS":pos[0],"CPT_TEAM":teams[0],
            "FLEX1":names[1],"FLEX2":names[2],"FLEX3":names[3],"FLEX4":names[4],"FLEX5":names[5],
            "SALARY":int(pf["salary"][i]),"TEAM_SPLIT_CPT_TEAM":int(pf["same_cpt_team"][i]),
            "WIN_RATE":float(sim["win_rate"][i]),"TOP01_RATE":float(sim["top01_rate"][i]),"TOP1_RATE":float(sim["top1_rate"][i]),"TOP5_RATE":float(sim["top5_rate"][i]),
            "P95":float(sim["lineup_p95"][i]),"P99":float(sim["lineup_p99"][i]),"DUP_PROXY":float(pf["dup_proxy"][i]),"LEVERAGE":float(pf["leverage"][i]),
        })
    board=pd.DataFrame(recs)
    Path(board_path).parent.mkdir(parents=True,exist_ok=True); board.to_csv(board_path,index=False)
    phase2_hash=_array_hash(rows)
    ledger=[[str(cal.names[j]) for j in r] for r in rows.tolist()]
    receipt={
        "RUN_STATE":"TOOL_PROVEN_EXECUTED","EXECUTION_STATE":"TOOL_PROVEN_EXECUTED","ENGINE_ID":ENGINE_ID,"ENGINE_SUBSTITUTION":False,
        "PLATFORM":PLATFORM,"SPORT":SPORT,"MODE":MODE,"FIELD_SIZE":cfg.field_size,"ACTIVE_POOL":int(len(cal.names)),
        "OUT_PURGE":int(len(cal.out_names)),"OUT_PLAYERS":cal.out_names,"ROLE_INACTIVE_PURGE":int(len(cal.inactive_names)),
        "MISSING_ROLE_EVIDENCE_ACTIVE_UNCERTAIN":int(len(cal.missing_role_names)),"MISSING_ROLE_EVIDENCE_PLAYERS":cal.missing_role_names,
        "LEGAL_SCAN_LINEUPS":int(len(legal_rows)),**generation_receipt,**phase2_receipt,"PHASE3_CANDIDATE_LINEUPS":int(len(rows)),
        "BASE_SIM_TRIALS":int(sim["BASE_SIM_TRIALS"]),"BUBBLE_EXTRA_TRIALS_TOTAL":int(sim["BUBBLE_EXTRA_TRIALS_TOTAL"]),"BUBBLE_LINEUPS_UNRESOLVED":int(sim["BUBBLE_LINEUPS_UNRESOLVED"]),
        "FAKE_FIELD_SIZE":int(sim["FAKE_FIELD_SIZE"]),"FAKE_FIELD_UNIQUE_LINEUPS":int(sim["FAKE_FIELD_UNIQUE_LINEUPS"]),
        "TOP01_FIELD_CUTOFF_N":int(sim["TOP01_FIELD_CUTOFF_N"]),"TRUE_TOP01_FIELD_THRESHOLD":True,
        "CFB_SHOWDOWN_CALIBRATION_PATCH_ID":CFB_CALIBRATION_PATCH,
        "CFB_ROLE_COMPLETE_CPT_PATCH_ID":CFB_ROLE_COMPLETE_CPT_PATCH,
        "CFB_SHOWDOWN_OPPORTUNITY_PATCH_ID":CFB_OPPORTUNITY_PATCH,
        "CFB_SHOWDOWN_RECURRENCE_SELECTOR_PATCH_ID":CFB_RECURRENCE_SELECTOR_PATCH,
        "CFB_SHOWDOWN_CONSENSUS_BRIDGE_PATCH_ID":CFB_CONSENSUS_BRIDGE_PATCH,
        "CFB_SHOWDOWN_NUMERIC_FIELD_PATCH_ID":CFB_NUMERIC_FIELD_PATCH,
        "CFB_SHOWDOWN_BALANCED_VALUE_HEDGE_PATCH_ID":CFB_BALANCED_VALUE_HEDGE_PATCH,
        "CFB_SHOWDOWN_KNOWN_ROLE_5_1_RESERVE_PATCH_ID":CFB_KNOWN_ROLE_5_1_RESERVE_PATCH,
        "CFB_SHOWDOWN_DUAL_QB_VALUE_RESERVE_PATCH_ID":CFB_DUAL_QB_VALUE_RESERVE_PATCH,
        "CFB_SHOWDOWN_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_PATCH_ID":CFB_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_PATCH,
        "CFB_SHOWDOWN_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_PATCH_ID":CFB_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_PATCH,
        "CFB_SHOWDOWN_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_PATCH_ID":CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION_PATCH,
        "HANDOFF_SURVIVORS":int(len(rows)),"SELECTOR_REVIEWED_LINEUPS":int(len(rows)),"FINAL_BOARD_SIZE":int(len(board)),
        "FINAL_SALARY_RECOMPUTE":board["SALARY"].astype(int).tolist(),"BOARD_LEGALITY":"PASS" if len(board) and board["SALARY"].between(SALARY_MIN,SALARY_MAX).all() else "FAIL",
        "PHASE1_MC_TRIALS":cfg.player_trials,"PHASE1_CALIBRATION_HASH":cal.phase1_hash,"PLAYER_SIMULATION_MATRIX_HASH":cal.player_sim_hash,
        "PHASE2_FREEZE_HASH":phase2_hash,"PHASE3_INPUT_HASH":phase2_hash,"HANDOFF_INPUT_HASH":phase2_hash,"SELECTOR_INPUT_HASH":phase2_hash,
        "HANDOFF_METRIC_PARITY_CHECK":"PASS","POST_PHASE2_MUTATION_COUNT":0,"POSTLOCK_RESULTS_USED":False,
        "ROLE_EVIDENCE_SOURCE":"PLAYER_POOL_STRUCTURAL_WORKLOAD_FIELDS","RAW_AGGREGATE_PROJECTION_PHASE1_BASELINE":False,
        "GLOBAL_SELECTOR_PATCH":GLOBAL_SELECTOR_PATCH,"TOP5_PARLAY_POLICY_ID":TOP5_POLICY,"HANDOFF_PATCH_ID":HANDOFF_PATCH,
        "PORTFOLIO_PREFERENCE_RELAXATION":int(relaxation[0]),"PHASE2_IDENTITY_LEDGER_ROWS":len(ledger),"PHASE2_IDENTITY_LEDGER_SHA256":_stable_hash(ledger),
        "REGIME_PATCH_ID":REGIME_PATCH,"CFB_ROLE_REGIME_PATCH_ID":CFB_ROLE_REGIME_PATCH,
        "PHASE1_OUTCOME_REGIME_RECEIPT":cal.phase1_regime_receipt,"BASE_OUTCOME_REGIME_RECEIPT":sim["regime_receipt"],
        **selector_regime_receipt,
    }
    Path(receipt_path).write_text(json.dumps(receipt,indent=2),encoding="utf-8")
    return board,receipt



def _recovered_starter_salary_release_hedge(selected: np.ndarray, rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Calibration, role_receipt: dict[str,Any]) -> tuple[np.ndarray,dict[str,Any]]:
    """Hedge a high-recurrence recovered-starter 5-1 QB archetype with a cheaper same-role sibling."""
    chosen=list(map(int,np.asarray(selected,dtype=np.int32).tolist()))
    starters=set(map(str,role_receipt.get('EXTERNAL_ROLE_RECOVERED_STARTERS',[])))
    if not starters or not chosen:
        return np.asarray(chosen,dtype=np.int32),{'CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH_ID':CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH,'RECOVERED_STARTER_HEDGE_APPLIED':False,'RECOVERED_STARTER_HEDGE_REASON':'NO_RECOVERED_STARTER'}
    sims=np.asarray(sim['_base_player_sims'],dtype=np.float32); topbits=np.asarray(sim['_top01_bits'],dtype=np.uint8); winbits=np.asarray(sim['_win_bits'],dtype=np.uint8)
    sb,cb,cwb,strict,core,cw=_recurrence_arrays_cached(sim,rows)
    anchors=[]
    for i,r in enumerate(rows):
        c=int(r[0]); ct=str(cal.team[c])
        if str(cal.pos[c])!='QB' or int(pf['same_cpt_team'][i])!=5: continue
        if not any(str(cal.names[int(x)]) in starters and str(cal.team[int(x)])==ct for x in r): continue
        flex=np.asarray(r[1:],dtype=np.int32); same=flex[cal.team[flex]==ct]; opp=flex[cal.team[flex]!=ct]
        if len(opp)!=1 or str(cal.pos[int(opp[0])]) not in {'WR','TE'}: continue
        spos=set(map(str,cal.pos[same].tolist()))
        if not {'RB','TE','K'}.issubset(spos): continue
        sc=8.12*int(strict[i])+4.0*int(cw[i])+2.08*int(core[i])
        anchors.append((sc,int(strict[i]),int(cw[i]),int(core[i]),float(sim['top01_rate'][i]),float(sim['lineup_p99'][i]),int(i)))
    if not anchors:
        return np.asarray(chosen,dtype=np.int32),{'CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH_ID':CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH,'RECOVERED_STARTER_HEDGE_APPLIED':False,'RECOVERED_STARTER_HEDGE_REASON':'NO_ANCHOR'}
    anchors.sort(reverse=True); anchor=int(anchors[0][-1]); ar=np.asarray(rows[anchor],dtype=np.int32); aset=set(map(int,ar.tolist())); abits=np.asarray(topbits[anchor],dtype=np.uint8); asal=int(pf['salary'][anchor])
    def popcnt_bytes(x: np.ndarray)->int: return int(np.unpackbits(np.asarray(x,dtype=np.uint8),bitorder='little').sum())
    sibs=[]
    for i,r in enumerate(rows):
        if i==anchor or int(r[0])!=int(ar[0]) or int(pf['salary'][i])>asal-1000: continue
        rset=set(map(int,r.tolist())); inter=aset&rset
        if len(inter)!=5: continue
        out=list(aset-rset); inn=list(rset-aset)
        if len(out)!=1 or len(inn)!=1: continue
        x,y=int(out[0]),int(inn[0])
        if str(cal.team[x])!=str(cal.team[y]) or str(cal.pos[x])!=str(cal.pos[y]): continue
        new_worlds=popcnt_bytes(np.asarray(topbits[i],dtype=np.uint8)&np.bitwise_not(abits))
        sc=8.12*int(strict[i])+4.0*int(cw[i])+2.08*int(core[i])
        sibs.append((new_worlds,sc,int(strict[i]),int(cw[i]),int(core[i]),float(sim['top01_rate'][i]),float(sim['lineup_p99'][i]),int(i)))
    if not sibs:
        return np.asarray(chosen,dtype=np.int32),{'CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH_ID':CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH,'RECOVERED_STARTER_HEDGE_APPLIED':False,'RECOVERED_STARTER_HEDGE_REASON':'NO_SAME_ROLE_RELEASE_SIBLING','RECOVERED_STARTER_HEDGE_ANCHOR_INDEX':anchor}
    sibs.sort(reverse=True); hedge=int(sibs[0][-1]); new_worlds=int(sibs[0][0])
    if hedge in chosen:
        return np.asarray(chosen,dtype=np.int32),{'CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH_ID':CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH,'RECOVERED_STARTER_HEDGE_APPLIED':False,'RECOVERED_STARTER_HEDGE_REASON':'ALREADY_SELECTED','RECOVERED_STARTER_HEDGE_ANCHOR_INDEX':anchor,'RECOVERED_STARTER_HEDGE_INDEX':hedge}
    def redundancy(pos:int):
        i=chosen[pos]; si=set(map(int,rows[i].tolist())); ovs=[len(si & set(map(int,rows[j].tolist()))) for z,j in enumerate(chosen) if z!=pos]
        return (sum(ovs),max(ovs) if ovs else 0,-float(sim['top01_rate'][i]))
    rp=max(range(len(chosen)),key=redundancy); replaced=int(chosen[rp]); chosen[rp]=hedge
    return np.asarray(chosen,dtype=np.int32),{'CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH_ID':CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE_PATCH,'RECOVERED_STARTER_HEDGE_APPLIED':True,'RECOVERED_STARTER_HEDGE_ANCHOR_INDEX':anchor,'RECOVERED_STARTER_HEDGE_INDEX':hedge,'RECOVERED_STARTER_HEDGE_NEW_TOP01_WORLDS':new_worlds,'RECOVERED_STARTER_HEDGE_REPLACED_INDEX':replaced,'RECOVERED_STARTER_HEDGE_REPLACED_SEAT':rp+1,'RECOVERED_STARTER_HEDGE_POSTLOCK_SIGNAL_USED':False}


def execute(pool: str|Path, field_size:int, board_path:str|Path, receipt_path:str|Path, seed:int|None=None) -> tuple[pd.DataFrame,dict[str,Any]]:
    cfg=Config(field_size=int(field_size),seed=int(seed if seed is not None else 352082926)); cfg.validate()
    cal=_calibrate(pool,cfg)
    cal,role_authority_receipt=_apply_external_role_authority(cal,cfg)
    legal,generation_receipt=_enumerate_legal(cal,cfg)
    feat=_lineup_features(legal,cal)
    p2_seed,pf_seed,p2seedrec=_phase2(legal,feat,cfg)
    # Preserve the exact pre-promotion selector as a forward-blind continuity prior.
    legacy_sim=_simulate_phase2_legacy(p2_seed,pf_seed,legal,feat,cal,cfg)
    legacy_chosen,legacy_relax,legacy_selector_receipt=_portfolio_select(p2_seed,pf_seed,legacy_sim,cal,cfg)
    legacy_rank1_row=p2_seed[int(legacy_chosen[0])].copy()
    p2_seed_recall,qb51_receipt=_qb_cpt_5_1_missing_role_family_reserve(p2_seed,cal)
    p2_seed_recall,production_birth_receipt=_cfb_showdown_production_birth_reserves(p2_seed_recall,cal,cfg)
    p2,pf,p2rec=_role_complete_phase2_families(p2_seed_recall,cal)
    p2rec.update(qb51_receipt); p2rec.update(production_birth_receipt)
    p2rec["PHASE2_PRE_CLOSURE_BUILT_LINEUPS"]=int(p2seedrec["PHASE2_BUILT_LINEUPS"])
    p2rec["PHASE2_PRE_CLOSURE_FAMILY_COUNT"]=int(p2seedrec["PHASE2_FAMILY_COUNT"])
    p2rec.update(role_authority_receipt)
    sim=_simulate_phase2(p2,pf,legal,feat,cal,cfg)
    recurrence_chosen,recurrence_receipt=_recurrence_portfolio_select(p2,sim,cfg)
    incumbent_idx=_find_exact_row(p2,legacy_rank1_row)
    chosen,bridge_receipt=_apply_incumbent_consensus_bridge(recurrence_chosen,incumbent_idx,p2)
    chosen,known51_receipt=_known_role_5_1_wr_cpt_reserve(chosen,p2,pf,sim,cal)
    chosen,hedge_receipt=_balanced_value_cpt_same_role_hedge(chosen,p2,pf,sim,cal)
    chosen,dualqb_receipt=_balanced_dual_qb_value_family_reserve(chosen,p2,pf,sim,cal)
    chosen,recovered_hedge_receipt=_recovered_starter_salary_release_hedge(chosen,p2,pf,sim,cal,role_authority_receipt)
    # Freeze the established sport-native lanes before the two entry-limit canaries.
    # These older lanes have dedicated forward-blind repair authority and are allowed
    # to remain first-class in the Core5. The 20+/35-entry canaries below remain
    # reviewed candidates, but cannot force a Core5 seat merely because entry_limit
    # is large.
    pre_canary_chosen=np.asarray(chosen,dtype=np.int32).copy()
    established_lane_candidates=set()
    if bridge_receipt.get("INCUMBENT_GATE") and incumbent_idx>=0:
        established_lane_candidates.add(int(incumbent_idx))
    for key,rec in (
        ("KNOWN_ROLE_5_1_INDEX",known51_receipt),
        ("HEDGE_ANCHOR_INDEX",hedge_receipt),
        ("HEDGE_INDEX",hedge_receipt),
        ("DUAL_QB_VALUE_INDEX",dualqb_receipt),
        ("RECOVERED_STARTER_HEDGE_ANCHOR_INDEX",recovered_hedge_receipt),
        ("RECOVERED_STARTER_HEDGE_INDEX",recovered_hedge_receipt),
    ):
        v=rec.get(key)
        if v is not None:
            established_lane_candidates.add(int(v))
    pre_canary_set=set(map(int,pre_canary_chosen.tolist()))
    established_core_protect={int(i) for i in established_lane_candidates if int(i) in pre_canary_set}

    chosen,qb51_core_receipt=_known_role_5_1_qb_cpt_core_completion_reserve(chosen,p2,pf,sim,cal,cfg)
    qb51_protect={int(qb51_core_receipt['CFB_5_1_QB_CPT_INDEX'])} if qb51_core_receipt.get('CFB_5_1_QB_CPT_INDEX') is not None else set()
    chosen,rb42_canary_receipt=_favorite_control_rb_cpt_4_2_single_qb_reserve(chosen,p2,pf,sim,cal,cfg,protect=qb51_protect)
    secondary_rb_idx,secondary_rb_receipt=_secondary_favorite_rb_cpt_family_retention_candidate(p2,pf,sim,cal,cfg)
    if secondary_rb_idx>=0:
        established_core_protect.add(int(secondary_rb_idx))
    # Core5 is a championship head, not a diversification/canary surface. Use the
    # already-shipped global v2 quality selector across the full frozen Phase-2
    # surface, while retaining only established sport-native lane authorities earned
    # before the entry-limit canaries.
    prefinal_chosen=np.asarray(chosen,dtype=np.int32).copy()
    chosen,core5_quality_receipt=_core5_quality_finalize(p2,pf,sim,cal,cfg,protected_indices=established_core_protect)
    core5_quality_receipt.update({
        "CFB_CORE5_PRE_CANARY_SELECTED_INDICES":[int(x) for x in pre_canary_chosen.tolist()],
        "CFB_CORE5_PREFINAL_SELECTED_INDICES":[int(x) for x in prefinal_chosen.tolist()],
        "CFB_CORE5_ESTABLISHED_LANE_PROTECTED_INDICES":sorted(map(int,established_core_protect)),
        "CFB_CORE5_ESTABLISHED_LANE_PROTECTION":"PRE_CANARY_FORWARD_BLIND_AUTHORITIES_ONLY",
        "CFB_CORE5_CANARY_CANDIDATE_QB51_INDEX":qb51_core_receipt.get("CFB_5_1_QB_CPT_INDEX"),
        "CFB_CORE5_CANARY_CANDIDATE_RB42_INDEX":rb42_canary_receipt.get("CFB_4_2_RB_CPT_INDEX"),
        "CFB_CORE5_SECONDARY_FAVORITE_RB_CPT_PROTECTED_INDEX":secondary_rb_receipt.get("CFB_SECONDARY_FAVORITE_RB_CPT_INDEX"),
    })
    relax=np.asarray([0],dtype=np.int8)
    selector_regime_receipt={**recurrence_receipt,**bridge_receipt,**known51_receipt,**hedge_receipt,**dualqb_receipt,**recovered_hedge_receipt,**qb51_core_receipt,**rb42_canary_receipt,**secondary_rb_receipt,**core5_quality_receipt,
        "LEGACY_CONTINUITY_SELECTOR_PATCH":GLOBAL_SELECTOR_PATCH,
        "LEGACY_CONTINUITY_RANK1_INDEX_PRE_CLOSURE":int(legacy_chosen[0]),
        "LEGACY_CONTINUITY_RELAXATION":int(legacy_relax[0]),
        "LEGACY_CONTINUITY_SELECTOR_RECEIPT":legacy_selector_receipt}
    board,receipt=_write(chosen,p2,pf,sim,cal,legal,cfg,board_path,receipt_path,p2rec,relax,generation_receipt,selector_regime_receipt)
    if receipt["BOARD_LEGALITY"]!="PASS" or receipt["FINAL_BOARD_SIZE"]!=cfg.final_board_size:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_SHOWDOWN_TERMINAL_BOARD_INVALID")
    return board,receipt


def _args()->argparse.Namespace:
    ap=argparse.ArgumentParser()
    ap.add_argument("--pool",required=True); ap.add_argument("--field-size",required=True,type=int)
    ap.add_argument("--board",required=True); ap.add_argument("--receipt",required=True); ap.add_argument("--seed",type=int)
    return ap.parse_args()


def main()->int:
    from engines.cfb import cfb_showdown_chunk_stream_controller_v1 as chunk_stream
    return int(chunk_stream.main())

if __name__=="__main__":
    raise SystemExit(main())
