from __future__ import annotations

import hashlib
import json
from typing import Any

import numpy as np
import pandas as pd

PATCH_ID = "CFB_CLASSIC_TWO_GAME_SCRIPT_POSTERIOR_ORDER_v2"
FAVORITE_PRIOR_PATCH_ID = "CFB_CLASSIC_FAVORITE_SIDE_CHAMPIONSHIP_ORDER_PRIOR_v1"
STATUS = "ACTIVE_PRODUCTION_USER_DIRECTED"
SCOPE = "DRAFTKINGS_CFB_CLASSIC_EXACT_TWO_GAME"
MEMBERSHIP_MUTATION_ALLOWED = False
POSTLOCK_FORWARD_INPUT_ALLOWED = False
BASE_CHANNELS = (
    "RAW_PRELOCK_PROJECTION",
    "P99",
    "MARKET_GAME_SCRIPT_AFFINITY",
    "QB_GAME_POSTERIOR_COVERAGE",
)
FAVORITE_CHANNEL = "FAVORITE_SIDE_CHAMPIONSHIP_AFFINITY"
CHANNELS = BASE_CHANNELS + (FAVORITE_CHANNEL,)
FAVORITE_CHANNEL_WEIGHT = 0.10
BASE_CHANNEL_WEIGHT = (1.0 - FAVORITE_CHANNEL_WEIGHT) / len(BASE_CHANNELS)
CHANNEL_WEIGHTS = {name: BASE_CHANNEL_WEIGHT for name in BASE_CHANNELS} | {FAVORITE_CHANNEL: FAVORITE_CHANNEL_WEIGHT}


def _zscore(values: np.ndarray) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64)
    if x.size == 0:
        return x
    finite = np.isfinite(x)
    if not np.all(finite):
        if not np.any(finite):
            return np.zeros_like(x)
        fill = float(np.nanmedian(x[finite]))
        x = np.where(finite, x, fill)
    sd = float(np.std(x))
    if sd <= 1e-12:
        return np.zeros_like(x)
    return (x - float(np.mean(x))) / sd


def _membership_hash(board: np.ndarray) -> str:
    rows = [tuple(sorted(int(x) for x in row)) for row in np.asarray(board, dtype=np.int64)]
    rows.sort()
    return hashlib.sha256(json.dumps(rows, separators=(",", ":")).encode()).hexdigest()


def _game_posterior(game: np.ndarray, game_total: np.ndarray) -> dict[str, float]:
    keys = np.asarray(game, dtype=str)
    gt = np.asarray(game_total, dtype=np.float64)
    unique = sorted(set(keys.tolist()))
    raw = []
    for g in unique:
        vals = gt[keys == g]
        vals = vals[np.isfinite(vals)]
        raw.append(float(np.median(vals)) if vals.size else 1.0)
    arr = np.maximum(np.asarray(raw, dtype=np.float64), 1e-6)
    arr /= arr.sum()
    return {g: float(w) for g, w in zip(unique, arr)}


def _market_affinity(rows: np.ndarray, team_total: np.ndarray, game_total: np.ndarray) -> np.ndarray:
    # Entirely prelock. Team scoring environment carries 65% of the channel and
    # the shared game environment carries 35%; all lineups have the same roster size.
    tm = np.asarray(team_total, dtype=np.float64)[rows]
    gt = np.asarray(game_total, dtype=np.float64)[rows]
    return np.sum(0.65 * tm + 0.35 * (0.5 * gt), axis=1)


def _qb_game_coverage(rows: np.ndarray, pos: np.ndarray, game: np.ndarray, game_weights: dict[str, float]) -> np.ndarray:
    pos = np.asarray(pos, dtype=str)
    game = np.asarray(game, dtype=str)
    out = np.zeros(len(rows), dtype=np.float64)
    for i, row in enumerate(rows):
        qb_ids = [int(pid) for pid in row if pos[int(pid)] == "QB"]
        covered = {str(game[pid]) for pid in qb_ids}
        out[i] = sum(game_weights.get(g, 0.0) for g in covered)
    return out


def _favorite_slot_values(spread: np.ndarray) -> np.ndarray:
    """Map prelock team spread to favorite-side roster value.

    Negative spread = market favorite (1.0), positive = underdog (0.0), pick'em = 0.5.
    This is deliberately not a hard exposure rule; it is only a bounded order feature.
    """
    s = np.asarray(spread, dtype=np.float64)
    out = np.full_like(s, 0.5, dtype=np.float64)
    finite = np.isfinite(s)
    out[finite & (s < -1e-12)] = 1.0
    out[finite & (s > 1e-12)] = 0.0
    return out


def _favorite_side_share(rows: np.ndarray, spread: np.ndarray) -> np.ndarray:
    values = _favorite_slot_values(spread)
    return np.mean(values[np.asarray(rows, dtype=np.int64)], axis=1)


def _favorite_side_affinity(rows: np.ndarray, spread: np.ndarray) -> np.ndarray:
    """Prelock-only championship-side affinity.

    75% of the signal is lineup favorite-side roster share. 25% rewards favorite
    slots more when the market margin is larger, but caps strength at 14 points so
    this cannot become an unbounded spread chase. No historical/postlock target is
    encoded in the formula.
    """
    rows = np.asarray(rows, dtype=np.int64)
    s = np.asarray(spread, dtype=np.float64)
    slot = _favorite_slot_values(s)[rows]
    abs_s = np.abs(np.where(np.isfinite(s), s, 0.0))[rows]
    strength = np.clip(abs_s / 14.0, 0.0, 1.0)
    weighted = slot * (0.75 + 0.25 * strength)
    return np.mean(weighted, axis=1)


def _rank_band_favorite_receipt(rows: np.ndarray, spread: np.ndarray) -> dict[str, Any]:
    shares = _favorite_side_share(rows, spread)
    n = len(shares)
    def band(k: int) -> float | None:
        if n == 0:
            return None
        return float(np.mean(shares[: min(k, n)]))
    if n:
        ranks = np.arange(1, n + 1, dtype=np.float64)
        weights = 1.0 / np.log2(ranks + 1.0)
        rank_weighted = float(np.average(shares, weights=weights))
        all_share = float(np.mean(shares))
    else:
        rank_weighted = None
        all_share = None
    return {
        "FAVORITE_SIDE_SHARE_ALL": all_share,
        "FAVORITE_SIDE_SHARE_TOP10": band(10),
        "FAVORITE_SIDE_SHARE_TOP20": band(20),
        "FAVORITE_SIDE_SHARE_TOP50": band(50),
        "RANK_WEIGHTED_FAVORITE_SIDE_SHARE": rank_weighted,
        "RANK_WEIGHT_METHOD": "DCG_1_OVER_LOG2_RANK_PLUS_1",
    }


def reorder_selected_board(
    board: np.ndarray,
    chosen_indices: np.ndarray,
    *,
    frame: pd.DataFrame,
    p99_player: np.ndarray,
    pos: np.ndarray,
    game: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Order an already-selected CFB Classic board. Membership is immutable.

    v2 keeps the v1 four-channel posterior order as 90% of authority and adds a
    bounded 10% prelock favorite-side championship prior. The favorite signal is
    rank-only: it cannot add/remove lineups or enforce a target exposure quota.
    """
    b = np.asarray(board, dtype=np.int32)
    chosen = np.asarray(chosen_indices, dtype=np.int32)
    if len(b) != len(chosen):
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_TWO_GAME_ORDER_BOARD_INDEX_MISMATCH")

    active_games = sorted(set(np.asarray(game, dtype=str).tolist()))
    before_hash = _membership_hash(b)
    spread_available = "SPRD" in frame.columns
    pre_order_favorite = _rank_band_favorite_receipt(b, frame["SPRD"].to_numpy(dtype=np.float64)) if spread_available else {}
    if len(active_games) != 2 or len(b) <= 1:
        receipt = {
            "PATCH_ID": PATCH_ID,
            "FAVORITE_PRIOR_PATCH_ID": FAVORITE_PRIOR_PATCH_ID,
            "STATUS": STATUS,
            "ACTIVATED": False,
            "SLATE_GAMES": int(len(active_games)),
            "ORDER_ONLY": True,
            "MEMBERSHIP_MUTATION_ALLOWED": False,
            "POSTLOCK_FORWARD_INPUT": False,
            "FAVORITE_SIDE_FIXED_EXPOSURE_QUOTA": False,
            "CHANNELS": list(CHANNELS),
            "CHANNEL_WEIGHTS": CHANNEL_WEIGHTS,
            "MEMBERSHIP_HASH_BEFORE": before_hash,
            "MEMBERSHIP_HASH_AFTER": before_hash,
            "MEMBERSHIP_PARITY": "PASS",
            **pre_order_favorite,
        }
        return b, chosen, np.zeros(len(b), dtype=np.float64), receipt

    required = ("FPTS", "TM Score", "O/U")
    if any(col not in frame.columns for col in required):
        raise RuntimeError("RUN_INVALID:CFB_TWO_GAME_ORDER_REQUIRED_PRELOCK_CHANNEL_MISSING")

    raw_projection = frame["FPTS"].to_numpy(dtype=np.float64)[b].sum(axis=1)
    p99 = np.asarray(p99_player, dtype=np.float64)[b].sum(axis=1)
    team_total = frame["TM Score"].to_numpy(dtype=np.float64)
    game_total = frame["O/U"].to_numpy(dtype=np.float64)
    spread = frame["SPRD"].to_numpy(dtype=np.float64) if spread_available else None
    market = _market_affinity(b, team_total, game_total)
    gp = _game_posterior(np.asarray(game, dtype=str), game_total)
    qb_coverage = _qb_game_coverage(b, np.asarray(pos, dtype=str), np.asarray(game, dtype=str), gp)
    favorite_prior_active = spread is not None
    favorite_affinity = _favorite_side_affinity(b, spread) if favorite_prior_active else np.zeros(len(b), dtype=np.float64)
    effective_weights = CHANNEL_WEIGHTS if favorite_prior_active else ({name: 0.25 for name in BASE_CHANNELS} | {FAVORITE_CHANNEL: 0.0})

    channel_values = {
        "RAW_PRELOCK_PROJECTION": raw_projection,
        "P99": p99,
        "MARKET_GAME_SCRIPT_AFFINITY": market,
        "QB_GAME_POSTERIOR_COVERAGE": qb_coverage,
        FAVORITE_CHANNEL: favorite_affinity,
    }
    standardized = {name: _zscore(vals) for name, vals in channel_values.items()}
    score = sum(effective_weights[name] * standardized[name] for name in CHANNELS)

    # Stable source-order tie break. np.lexsort uses the final key as primary.
    source_order = np.arange(len(b), dtype=np.int64)
    order = np.lexsort((source_order, -score))
    out_board = b[order]
    out_chosen = chosen[order]
    out_score = score[order]

    after_hash = _membership_hash(out_board)
    if after_hash != before_hash:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_TWO_GAME_ORDER_MEMBERSHIP_MUTATION")

    favorite_receipt = _rank_band_favorite_receipt(out_board, spread) if favorite_prior_active else {
        "FAVORITE_SIDE_SHARE_ALL": None,
        "FAVORITE_SIDE_SHARE_TOP10": None,
        "FAVORITE_SIDE_SHARE_TOP20": None,
        "FAVORITE_SIDE_SHARE_TOP50": None,
        "RANK_WEIGHTED_FAVORITE_SIDE_SHARE": None,
        "RANK_WEIGHT_METHOD": "DCG_1_OVER_LOG2_RANK_PLUS_1",
    }
    receipt = {
        "PATCH_ID": PATCH_ID,
        "FAVORITE_PRIOR_PATCH_ID": FAVORITE_PRIOR_PATCH_ID,
        "STATUS": STATUS,
        "ACTIVATED": True,
        "SLATE_GAMES": 2,
        "ORDER_ONLY": True,
        "MEMBERSHIP_MUTATION_ALLOWED": False,
        "POSTLOCK_FORWARD_INPUT": False,
        "PLAYER_NAME_LOGIC": False,
        "FAVORITE_SIDE_FIXED_EXPOSURE_QUOTA": False,
        "FAVORITE_PRIOR_ACTIVE": favorite_prior_active,
        "FAVORITE_PRIOR_DISABLED_REASON": None if favorite_prior_active else "SPRD_COLUMN_UNAVAILABLE_V1_PARITY_FALLBACK",
        "FAVORITE_SIDE_ORDER_WEIGHT": FAVORITE_CHANNEL_WEIGHT if favorite_prior_active else 0.0,
        "FAVORITE_SIDE_ORDER_MODE": "BOUNDED_RANK_PRIOR_NOT_MEMBERSHIP_QUOTA",
        "CHANNELS": list(CHANNELS),
        "CHANNEL_WEIGHTS": CHANNEL_WEIGHTS,
        "EFFECTIVE_CHANNEL_WEIGHTS": effective_weights,
        "GAME_POSTERIOR": gp,
        "SOURCE_BOARD_POSITIONS": (source_order + 1).tolist(),
        "FINAL_SOURCE_BOARD_POSITIONS": (order + 1).tolist(),
        "ORDER_SCORE": [float(x) for x in out_score],
        "FAVORITE_SIDE_AFFINITY": [float(x) for x in favorite_affinity[order]],
        "MEMBERSHIP_HASH_BEFORE": before_hash,
        "MEMBERSHIP_HASH_AFTER": after_hash,
        "MEMBERSHIP_PARITY": "PASS",
        **favorite_receipt,
    }
    return out_board, out_chosen, out_score, receipt
