from __future__ import annotations

import hashlib
import json
from typing import Any

import numpy as np
import pandas as pd

PATCH_ID = "CFB_CLASSIC_TWO_GAME_SCRIPT_POSTERIOR_ORDER_v1"
STATUS = "ACTIVE_PRODUCTION_USER_DIRECTED"
SCOPE = "DRAFTKINGS_CFB_CLASSIC_EXACT_TWO_GAME"
MEMBERSHIP_MUTATION_ALLOWED = False
POSTLOCK_FORWARD_INPUT_ALLOWED = False
CHANNELS = (
    "RAW_PRELOCK_PROJECTION",
    "P99",
    "MARKET_GAME_SCRIPT_AFFINITY",
    "QB_GAME_POSTERIOR_COVERAGE",
)
CHANNEL_WEIGHTS = {name: 0.25 for name in CHANNELS}


def _zscore(values: np.ndarray) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64)
    if x.size == 0:
        return x
    finite = np.isfinite(x)
    if not np.all(finite):
        if not np.any(finite):
            return np.zeros_like(x)
        fill = float(np.nanmedian(x[finite]))
        x = np.where(finite, x, fill)
    sd = float(np.std(x))
    if sd <= 1e-12:
        return np.zeros_like(x)
    return (x - float(np.mean(x))) / sd


def _membership_hash(board: np.ndarray) -> str:
    rows = [tuple(sorted(int(x) for x in row)) for row in np.asarray(board, dtype=np.int64)]
    rows.sort()
    return hashlib.sha256(json.dumps(rows, separators=(",", ":")).encode()).hexdigest()


def _game_posterior(game: np.ndarray, game_total: np.ndarray) -> dict[str, float]:
    keys = np.asarray(game, dtype=str)
    gt = np.asarray(game_total, dtype=np.float64)
    unique = sorted(set(keys.tolist()))
    raw = []
    for g in unique:
        vals = gt[keys == g]
        vals = vals[np.isfinite(vals)]
        raw.append(float(np.median(vals)) if vals.size else 1.0)
    arr = np.maximum(np.asarray(raw, dtype=np.float64), 1e-6)
    arr /= arr.sum()
    return {g: float(w) for g, w in zip(unique, arr)}


def _market_affinity(rows: np.ndarray, team_total: np.ndarray, game_total: np.ndarray) -> np.ndarray:
    # Entirely prelock. Team scoring environment carries 65% of the channel and
    # the shared game environment carries 35%; all lineups have the same roster size.
    tm = np.asarray(team_total, dtype=np.float64)[rows]
    gt = np.asarray(game_total, dtype=np.float64)[rows]
    return np.sum(0.65 * tm + 0.35 * (0.5 * gt), axis=1)


def _qb_game_coverage(rows: np.ndarray, pos: np.ndarray, game: np.ndarray, game_weights: dict[str, float]) -> np.ndarray:
    pos = np.asarray(pos, dtype=str)
    game = np.asarray(game, dtype=str)
    out = np.zeros(len(rows), dtype=np.float64)
    for i, row in enumerate(rows):
        qb_ids = [int(pid) for pid in row if pos[int(pid)] == "QB"]
        covered = {str(game[pid]) for pid in qb_ids}
        out[i] = sum(game_weights.get(g, 0.0) for g in covered)
    return out


def reorder_selected_board(
    board: np.ndarray,
    chosen_indices: np.ndarray,
    *,
    frame: pd.DataFrame,
    p99_player: np.ndarray,
    pos: np.ndarray,
    game: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]:
    """Order an already-selected CFB Classic board. Membership is immutable.

    Activates only when the active player universe contains exactly two games. The
    four frozen prelock channels have equal standardized authority, matching the
    Notion production contract. No contest result or player-name constant is used.
    """
    b = np.asarray(board, dtype=np.int32)
    chosen = np.asarray(chosen_indices, dtype=np.int32)
    if len(b) != len(chosen):
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_TWO_GAME_ORDER_BOARD_INDEX_MISMATCH")

    active_games = sorted(set(np.asarray(game, dtype=str).tolist()))
    before_hash = _membership_hash(b)
    if len(active_games) != 2 or len(b) <= 1:
        receipt = {
            "PATCH_ID": PATCH_ID,
            "STATUS": STATUS,
            "ACTIVATED": False,
            "SLATE_GAMES": int(len(active_games)),
            "ORDER_ONLY": True,
            "MEMBERSHIP_MUTATION_ALLOWED": False,
            "POSTLOCK_FORWARD_INPUT": False,
            "CHANNELS": list(CHANNELS),
            "CHANNEL_WEIGHTS": CHANNEL_WEIGHTS,
            "MEMBERSHIP_HASH_BEFORE": before_hash,
            "MEMBERSHIP_HASH_AFTER": before_hash,
            "MEMBERSHIP_PARITY": "PASS",
        }
        return b, chosen, np.zeros(len(b), dtype=np.float64), receipt

    if "FPTS" not in frame.columns or "TM Score" not in frame.columns or "O/U" not in frame.columns:
        raise RuntimeError("RUN_INVALID:CFB_TWO_GAME_ORDER_REQUIRED_PRELOCK_CHANNEL_MISSING")

    raw_projection = frame["FPTS"].to_numpy(dtype=np.float64)[b].sum(axis=1)
    p99 = np.asarray(p99_player, dtype=np.float64)[b].sum(axis=1)
    team_total = frame["TM Score"].to_numpy(dtype=np.float64)
    game_total = frame["O/U"].to_numpy(dtype=np.float64)
    market = _market_affinity(b, team_total, game_total)
    gp = _game_posterior(np.asarray(game, dtype=str), game_total)
    qb_coverage = _qb_game_coverage(b, np.asarray(pos, dtype=str), np.asarray(game, dtype=str), gp)

    channel_values = {
        "RAW_PRELOCK_PROJECTION": raw_projection,
        "P99": p99,
        "MARKET_GAME_SCRIPT_AFFINITY": market,
        "QB_GAME_POSTERIOR_COVERAGE": qb_coverage,
    }
    standardized = {name: _zscore(vals) for name, vals in channel_values.items()}
    score = sum(CHANNEL_WEIGHTS[name] * standardized[name] for name in CHANNELS)

    # Stable source-order tie break. np.lexsort uses the final key as primary.
    source_order = np.arange(len(b), dtype=np.int64)
    order = np.lexsort((source_order, -score))
    out_board = b[order]
    out_chosen = chosen[order]
    out_score = score[order]

    after_hash = _membership_hash(out_board)
    if after_hash != before_hash:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_TWO_GAME_ORDER_MEMBERSHIP_MUTATION")

    receipt = {
        "PATCH_ID": PATCH_ID,
        "STATUS": STATUS,
        "ACTIVATED": True,
        "SLATE_GAMES": 2,
        "ORDER_ONLY": True,
        "MEMBERSHIP_MUTATION_ALLOWED": False,
        "POSTLOCK_FORWARD_INPUT": False,
        "PLAYER_NAME_LOGIC": False,
        "CHANNELS": list(CHANNELS),
        "CHANNEL_WEIGHTS": CHANNEL_WEIGHTS,
        "GAME_POSTERIOR": gp,
        "SOURCE_BOARD_POSITIONS": (source_order + 1).tolist(),
        "FINAL_SOURCE_BOARD_POSITIONS": (order + 1).tolist(),
        "ORDER_SCORE": [float(x) for x in out_score],
        "MEMBERSHIP_HASH_BEFORE": before_hash,
        "MEMBERSHIP_HASH_AFTER": after_hash,
        "MEMBERSHIP_PARITY": "PASS",
    }
    return out_board, out_chosen, out_score, receipt
