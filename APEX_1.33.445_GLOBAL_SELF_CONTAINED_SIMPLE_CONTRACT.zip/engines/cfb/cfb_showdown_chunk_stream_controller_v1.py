#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
import pickle
import shutil
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np

_STATE_ROOT = Path(__file__).resolve().parents[2]
if str(_STATE_ROOT) not in sys.path:
    sys.path.insert(0, str(_STATE_ROOT))

from engines.cfb import cfb_showdown_raw_pool_runtime_v1 as eng
from engines.common import apex_deadline_resumable_execution_v1 as resume
from engines.common import apex_terminal_ai_hybrid_selector_v6 as terminal_ai

PATCH_ID = "CFB_SHOWDOWN_ENGINE_OWNED_CHUNK_STREAM_RESUME_v1"
ENTRY_LIMIT_CONTRACT_PATCH = "CFB_SHOWDOWN_EXPLICIT_ENTRY_LIMIT_CHECKPOINT_IDENTITY_v1"
LIVE_EXECUTION_CONTRACT_PATCH = "CFB_SHOWDOWN_LIVE_EXECUTION_HARD_CONTRACT_v1"
SCHEMA_VERSION = "1.1.0"
CONTINUE_CODE = 75




def _binom_lcb(p: float, n: int) -> float:
    p=float(p); n=max(1,int(n))
    return max(0.0,p-1.96*math.sqrt(max(0.0,p*(1.0-p))/n))

def _sport_native_lane_annotations(*, chosen: np.ndarray, recurrence_receipt: dict[str,Any], bridge_receipt: dict[str,Any], known51_receipt: dict[str,Any], hedge_receipt: dict[str,Any], dualqb_receipt: dict[str,Any], recovered_hedge_receipt: dict[str,Any], qb51_core_receipt: dict[str,Any]|None=None, rb42_canary_receipt: dict[str,Any]|None=None, secondary_rb_receipt: dict[str,Any]|None=None) -> dict[int,dict[str,Any]]:
    """Translate the sport-native selector's earned special lanes into terminal-AI context.

    The global AI remains the last-step authority. These annotations preserve why a
    sport-native seat survived the forward selector so generic metric dominance cannot
    silently erase a structurally earned championship hedge. Only final chosen rows are
    annotated; no post-lock result, player name, or team name is introduced.
    """
    final=set(map(int,np.asarray(chosen,dtype=np.int32).tolist()))
    qb51_core_receipt = qb51_core_receipt or {}
    rb42_canary_receipt = rb42_canary_receipt or {}
    secondary_rb_receipt = secondary_rb_receipt or {}
    ann: dict[int,dict[str,Any]]={}
    def put(idx: Any, lane: str, reason: str, priority: int, *, protected: bool=False, family: str='', marginal_top01_worlds: int|None=None) -> None:
        try: i=int(idx)
        except Exception: return
        if i < 0 or i not in final: return
        rec=ann.setdefault(i,{})
        # Later operators are closer to the terminal sport-native decision and may
        # supersede an earlier lane label for the same retained row.
        rec.update({
            'SELECTION_LANE':lane,
            'SELECTOR_REASON':reason,
            'SPORT_NATIVE_LANE_AUTHORITY':True,
            'GLOBAL_CORE_PRIORITY':int(priority),
            'GLOBAL_CORE_FAMILY_ID':family or lane,
        })
        if protected:
            rec['GLOBAL_CORE_PROTECTED']=True
        if marginal_top01_worlds is not None:
            rec['CFB_NATIVE_MARGINAL_TOP01_WORLDS']=int(marginal_top01_worlds)

    for i in recurrence_receipt.get('RECURRENCE_SELECTED_INDICES',[]) or []:
        put(i,'CFB_RECURRENCE_CORE','CROSS_WORLD_RECURRENCE_BREADTH',50,family='CFB_RECURRENCE_CORE')
    if bridge_receipt.get('INCUMBENT_RESTORED'):
        put(bridge_receipt.get('INCUMBENT_INDEX'),'CFB_INCUMBENT_CONSENSUS_BRIDGE','SPORT_NATIVE_INCUMBENT_CONSENSUS',65,family='CFB_INCUMBENT_CONSENSUS')
    if known51_receipt.get('KNOWN_ROLE_5_1_APPLIED'):
        put(known51_receipt.get('KNOWN_ROLE_5_1_INDEX'),'CFB_KNOWN_ROLE_5_1_RESERVE','SPORT_NATIVE_KNOWN_ROLE_5_1_RECURRENCE_RESERVE',80,protected=True,family='CFB_KNOWN_ROLE_5_1')
    if hedge_receipt.get('HEDGE_APPLIED'):
        if hedge_receipt.get('HEDGE_REASON')=='ANCHOR_RETAINED_FIRST':
            idx=hedge_receipt.get('HEDGE_ANCHOR_INDEX'); lane='CFB_BALANCED_VALUE_ANCHOR'
            reason='SPORT_NATIVE_BALANCED_VALUE_ANCHOR_RETENTION'
        else:
            idx=hedge_receipt.get('HEDGE_INDEX'); lane='CFB_BALANCED_VALUE_SAME_ROLE_HEDGE'
            reason='SPORT_NATIVE_BALANCED_VALUE_SAME_ROLE_HEDGE'
        put(idx,lane,reason,85,protected=True,family='CFB_BALANCED_VALUE_FAMILY',marginal_top01_worlds=hedge_receipt.get('HEDGE_NEW_TOP01_WORLDS'))
    if dualqb_receipt.get('DUAL_QB_VALUE_APPLIED'):
        put(dualqb_receipt.get('DUAL_QB_VALUE_INDEX'),'CFB_DUAL_QB_VALUE_RESERVE','SPORT_NATIVE_DUAL_QB_VALUE_FAMILY_RESERVE',82,protected=True,family='CFB_DUAL_QB_VALUE_FAMILY')
    if recovered_hedge_receipt.get('RECOVERED_STARTER_HEDGE_APPLIED'):
        put(recovered_hedge_receipt.get('RECOVERED_STARTER_HEDGE_INDEX'),'CFB_RECOVERED_STARTER_SALARY_RELEASE_HEDGE','SPORT_NATIVE_RECOVERED_STARTER_MARGINAL_TOP01_HEDGE',100,protected=True,family='CFB_RECOVERED_STARTER_HEDGE',marginal_top01_worlds=recovered_hedge_receipt.get('RECOVERED_STARTER_HEDGE_NEW_TOP01_WORLDS'))
    if qb51_core_receipt.get('CFB_5_1_QB_CPT_INDEX') is not None:
        put(qb51_core_receipt.get('CFB_5_1_QB_CPT_INDEX'),'CFB_5_1_QB_CPT_CORE_COMPLETION_RESERVE','SPORT_NATIVE_5_1_QB_CPT_PRODUCTION_RESERVE',110,protected=True,family='CFB_5_1_QB_CPT_CORE_COMPLETION')
    if rb42_canary_receipt.get('CFB_4_2_RB_CPT_INDEX') is not None:
        put(rb42_canary_receipt.get('CFB_4_2_RB_CPT_INDEX'),'CFB_4_2_RB_CPT_SINGLE_QB_CANARY','SPORT_NATIVE_FAVORITE_CONTROL_RB_CPT_CANARY',120,protected=True,family='CFB_4_2_RB_CPT_SINGLE_QB')
    if secondary_rb_receipt.get('CFB_SECONDARY_FAVORITE_RB_CPT_INDEX') is not None:
        put(secondary_rb_receipt.get('CFB_SECONDARY_FAVORITE_RB_CPT_INDEX'),'CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY_RETENTION','SPORT_NATIVE_SECONDARY_FAVORITE_RB_CPT_CHAMPIONSHIP_FAMILY',125,protected=True,family='CFB_SECONDARY_FAVORITE_RB_CPT_FAMILY')
    return ann


def _build_ai_terminal_rows(*, rows: np.ndarray, pf: dict[str,np.ndarray], sim: dict[str,Any], cal: Any, chosen: np.ndarray, lane_annotations: dict[int,dict[str,Any]]|None=None) -> list[dict[str,Any]]:
    """Publish the complete CFB selector-reviewed handoff for global terminal AI.

    This is a terminal-surface adapter only. It does not alter birth, simulation,
    recurrence, native selector scoring, or the sport-native advisory Core-5.
    """
    sb,cb,cwb,strict,core,cw=eng._recurrence_arrays_cached(sim,rows)
    selected_rank={int(idx):rank+1 for rank,idx in enumerate(map(int,np.asarray(chosen,dtype=np.int32).tolist()))}
    n=max(100,int(sim.get('BASE_SIM_TRIALS',10000) or 10000))
    out=[]
    for i,r in enumerate(rows):
        r=np.asarray(r,dtype=np.int32)
        score=float(8.12*int(strict[i])+4.0*int(cw[i])+2.08*int(core[i]))
        rec={
            'LINEUP_ID':str(i),'LINEUP_INDEX':int(i),
            'CPT':str(cal.names[int(r[0])]),
            'UTIL1':str(cal.names[int(r[1])]),'UTIL2':str(cal.names[int(r[2])]),'UTIL3':str(cal.names[int(r[3])]),
            'UTIL4':str(cal.names[int(r[4])]),'UTIL5':str(cal.names[int(r[5])]),
            'SALARY':int(pf['salary'][i]),'TEAM_SPLIT_CPT_TEAM':int(pf['same_cpt_team'][i]),
            'MC_TRIALS':n,
            'MC_WIN_RATE':float(sim['win_rate'][i]),'MC_WIN_LCB':_binom_lcb(float(sim['win_rate'][i]),n),
            'MC_TOP_0_1_RATE':float(sim['top01_rate'][i]),'MC_TOP_0_1_LCB':_binom_lcb(float(sim['top01_rate'][i]),n),
            'MC_TOP_1_RATE':float(sim['top1_rate'][i]),'MC_TOP_5_RATE':float(sim['top5_rate'][i]),
            'MC_P95':float(sim['lineup_p95'][i]),'MC_P99':float(sim['lineup_p99'][i]),
            'PROJECTED_EXACT_MATCH_DUPLICATION':float(pf['dup_proxy'][i]),
            'LEVERAGE':float(pf['leverage'][i]),
            'WORLD_COVERAGE_COUNT':int(strict[i]),
            'TOTAL_RECURRENCE':int(strict[i])+int(core[i])+int(cw[i]),
            'COMMON_WORLD_WIN_COUNT':int(cw[i]),'CORE_RECURRENCE_COUNT':int(core[i]),
            'CURRENT_SELECTOR_SELECTED':bool(i in selected_rank),
            'CURRENT_SELECTOR_RANK':int(selected_rank.get(i,999999)),
            'CURRENT_SELECTOR_SCORE':score,
            'BRANCH':f"{int(pf['same_cpt_team'][i])}-{6-int(pf['same_cpt_team'][i])}",
            'CPT_ROLE':str(cal.pos[int(r[0])]),
        }
        for slot,j in (('CPT',int(r[0])),('UTIL1',int(r[1])),('UTIL2',int(r[2])),('UTIL3',int(r[3])),('UTIL4',int(r[4])),('UTIL5',int(r[5]))):
            rec[f'{slot}_TEAM']=str(cal.team[j]); rec[f'{slot}_ROLE']=str(cal.pos[j])
        if lane_annotations and i in lane_annotations:
            rec.update(dict(lane_annotations[i]))
        out.append(rec)
    return out

def _sha256_file(path: Path) -> str:
    return resume.sha256_file(Path(path))


def _atomic_pickle(path: Path, obj: Any) -> str:
    return resume.atomic_pickle(Path(path), obj)


def _load_pickle(path: Path) -> Any:
    with Path(path).open("rb") as f:
        return pickle.load(f)


def _atomic_npy(path: Path, arr: np.ndarray) -> str:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as f:
        np.save(f, np.asarray(arr), allow_pickle=False)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)
    return _sha256_file(path)


def _atomic_npz(path: Path, **arrays: Any) -> str:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as f:
        np.savez(f, **arrays)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)
    return _sha256_file(path)


def _role_authority_identity() -> dict[str,Any]:
    raw=os.environ.get('APEX_CFB_ROLE_AUTHORITY_JSON','').strip()
    fpath=os.environ.get('APEX_CFB_ROLE_AUTHORITY_FILE','').strip()
    if raw:
        return {'ROLE_AUTHORITY_SOURCE':'ENV_JSON','ROLE_AUTHORITY_SHA256':hashlib.sha256(raw.encode('utf-8')).hexdigest()}
    if fpath:
        p=Path(fpath)
        if not p.exists():
            return {'ROLE_AUTHORITY_SOURCE':'FILE_MISSING','ROLE_AUTHORITY_FILE':str(p),'ROLE_AUTHORITY_SHA256':'MISSING'}
        return {'ROLE_AUTHORITY_SOURCE':'FILE','ROLE_AUTHORITY_FILE':str(p),'ROLE_AUTHORITY_SHA256':_sha256_file(p)}
    return {'ROLE_AUTHORITY_SOURCE':'NONE','ROLE_AUTHORITY_SHA256':'NONE'}


def _identity(pool: Path, field_size: int, seed: int, entry_limit: int) -> dict[str, Any]:
    runtime_path = Path(eng.__file__).resolve()
    controller_path = Path(__file__).resolve()
    return {
        "SCHEMA_VERSION": SCHEMA_VERSION,
        "PATCH_ID": PATCH_ID,
        "LIVE_EXECUTION_CONTRACT_PATCH_ID": LIVE_EXECUTION_CONTRACT_PATCH,
        "LIVE_PHASE_ORDER": "CALIBRATION>QUALIFIED_BIRTH>SIMULATION>SELECTOR>MAX_ENTRY_PORTFOLIO",
        "POOL_SHA256": _sha256_file(pool),
        "FIELD_SIZE": int(field_size),
        "ENTRY_LIMIT": int(entry_limit),
        "SEED": int(seed),
        "STATE_VERSION": str(os.environ.get("APEX_RESUMABLE_STATE_VERSION") or os.environ.get("APEX_GLOBAL_STATE_VERSION") or "UNSPECIFIED"),
        "RUNTIME_SHA256": _sha256_file(runtime_path),
        "CONTROLLER_SHA256": _sha256_file(controller_path),
        **_role_authority_identity(),
    }


def _state_root(board: Path) -> Path:
    parent = os.environ.get("APEX_RESUMABLE_RUN_ROOT")
    if parent:
        root = Path(parent) / "cfb_showdown_chunk_stream_v1"
    else:
        key = hashlib.sha256(str(board.resolve()).encode()).hexdigest()[:16]
        root = board.parent / f".cfb_showdown_chunk_stream_{key}"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _load_state(root: Path, identity: dict[str, Any]) -> dict[str, Any]:
    state_path = root / "controller_state.json"
    if state_path.exists():
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
        except Exception:
            state = {}
        if state.get("IDENTITY") != identity:
            stale = root.with_name(root.name + f".stale.{time.time_ns()}")
            os.replace(root, stale)
            root.mkdir(parents=True, exist_ok=True)
            state = {}
    else:
        state = {}
    if not state:
        state = {
            "PATCH_ID": PATCH_ID,
            "SCHEMA_VERSION": SCHEMA_VERSION,
            "IDENTITY": identity,
            "STAGE": "PREP",
            "STAGE_INDEX": 0,
            "COMPLETED_CHUNKS": 0,
            "SAFE_YIELD_COUNT": 0,
            "CHUNK_COMMITS": [],
            "EXECUTION_STATE": "RUNNING",
        }
        resume.atomic_json(state_path, state)
    return state


def _save_state(root: Path, state: dict[str, Any]) -> None:
    resume.atomic_json(root / "controller_state.json", state)


def _commit(state: dict[str, Any], root: Path, *, stage: str, cursor: int, path: Path, sha256: str, rows: int = 0, trials: int = 0) -> None:
    state["SUBSTAGE"] = stage
    state.setdefault("CURSORS", {})[stage] = int(cursor)
    state["COMPLETED_CHUNKS"] = int(state.get("COMPLETED_CHUNKS", 0)) + 1
    state["LAST_COMMIT"] = {
        "STAGE": stage,
        "CURSOR": int(cursor),
        "PATH": str(path),
        "SHA256": str(sha256),
        "ROWS": int(rows),
        "TRIALS": int(trials),
    }
    # Keep only a bounded control-plane history. Large payloads live in sidecars.
    history = list(state.get("CHUNK_COMMITS", []))
    history.append(state["LAST_COMMIT"])
    state["CHUNK_COMMITS"] = history[-64:]
    _save_state(root, state)


def _advance(root: Path, state: dict[str, Any], stage: str, stage_index: int) -> None:
    state["STAGE"] = stage
    state["STAGE_INDEX"] = int(stage_index)
    state["SUBSTAGE"] = ""
    _save_state(root, state)


def _yield(root: Path, state: dict[str, Any], budget: resume.RuntimeBudget) -> int:
    state["EXECUTION_STATE"] = "RESUMABLE"
    state["SAFE_YIELD_COUNT"] = int(state.get("SAFE_YIELD_COUNT", 0)) + 1
    state["CHUNK_EMA_SECONDS"] = budget.chunk_ema_seconds
    _save_state(root, state)
    obj = {
        "RUN_STATE": "CHECKPOINTED_CONTINUE",
        "EXECUTION_STATE": "RESUMABLE",
        "PATCH_ID": PATCH_ID,
        "COMPLETED_STAGE": state.get("STAGE"),
        "NEXT_STAGE": state.get("STAGE"),
        "STAGE_INDEX": int(state.get("STAGE_INDEX", 0)),
        "NEXT_CHUNK": int((state.get("CURSORS", {}) or {}).get(str(state.get("SUBSTAGE") or state.get("STAGE")), 0)),
        "CHECKPOINT": str(state.get("LAST_COMMIT", {}).get("PATH", "")),
        "CONTROLLER_STATE": str(root / "controller_state.json"),
        "COMPLETED_CHUNKS": int(state.get("COMPLETED_CHUNKS", 0)),
        "SAFE_YIELD_COUNT": int(state.get("SAFE_YIELD_COUNT", 0)),
        "EXTERNAL_RESUME_REQUIRED": False,
    }
    print(json.dumps(obj, separators=(",", ":")), flush=True)
    return CONTINUE_CODE


def _should_yield(budget: resume.RuntimeBudget) -> bool:
    return budget.completed_chunks > 0 and budget.should_yield()


def _threshold_chunk(field_rows: np.ndarray, sims: np.ndarray, field_size: int, ts: int, te: int) -> dict[str, np.ndarray]:
    fs = eng._lineup_scores(field_rows, sims[:, ts:te], chunk=512)
    n = fs.shape[0]
    win = np.max(fs, axis=0)
    k01 = min(n, max(1, int(math.ceil(field_size * 0.001))))
    k1 = min(n, max(1, int(math.ceil(field_size * 0.01))))
    k5 = min(n, max(1, int(math.ceil(field_size * 0.05))))
    # One partition call obtains all three order statistics exactly.
    ks = sorted({n-k01, n-k1, n-k5})
    part = np.partition(fs, ks, axis=0)
    out = {
        "win": win.astype(np.float32, copy=False),
        "top01": part[n-k01].astype(np.float32, copy=False),
        "top1": part[n-k1].astype(np.float32, copy=False),
        "top5": part[n-k5].astype(np.float32, copy=False),
    }
    del fs, part
    return out


def _concat_thresholds(path_dir: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    files = sorted(path_dir.glob("threshold_*.npz"))
    if not files:
        raise RuntimeError("RUN_INVALID:CFB_CHUNK_STREAM_THRESHOLD_CHUNKS_MISSING")
    wins=[]; t01=[]; t1=[]; t5=[]
    for p in files:
        with np.load(p, allow_pickle=False) as z:
            wins.append(z["win"]); t01.append(z["top01"]); t1.append(z["top1"]); t5.append(z["top5"])
    return (np.concatenate(wins), np.concatenate(t01), np.concatenate(t1), np.concatenate(t5))


def _build_thresholds(root: Path, state: dict[str, Any], budget: resume.RuntimeBudget, *, lane: str, field_rows: np.ndarray, sims: np.ndarray, field_size: int, trial_chunk: int) -> bool:
    d = root / lane / "threshold_chunks"
    d.mkdir(parents=True, exist_ok=True)
    total = sims.shape[1]
    cursor = int((state.get("CURSORS", {}) or {}).get(f"{lane.upper()}_THRESHOLDS", 0))
    for ts in range(cursor, total, trial_chunk):
        te = min(total, ts + trial_chunk)
        p = d / f"threshold_{ts:08d}_{te:08d}.npz"
        t0 = time.monotonic()
        if not p.exists():
            rec = _threshold_chunk(field_rows, sims, field_size, ts, te)
            digest = _atomic_npz(p, **rec)
            del rec
        else:
            digest = _sha256_file(p)
        dt = time.monotonic() - t0
        budget.update_chunk_runtime(dt)
        _commit(state, root, stage=f"{lane.upper()}_THRESHOLDS", cursor=te, path=p, sha256=digest, trials=te-ts)
        gc.collect()
        if te < total and _should_yield(budget):
            return False
    return True


def _lineup_chunk_metrics(rows: np.ndarray, sims: np.ndarray, win: np.ndarray, t01: np.ndarray, t1: np.ndarray, t5: np.ndarray, *, promoted: bool) -> dict[str, np.ndarray]:
    block = eng._lineup_scores(rows, sims, chunk=max(1, len(rows)))
    w = (block > win[None,:] + 1e-7).sum(axis=1).astype(np.int32)
    ties = (np.abs(block-win[None,:]) <= 1e-7).sum(axis=1).astype(np.int32)
    out = {
        "win_credit": w.astype(np.float64) + 0.5*ties.astype(np.float64),
        "top01": (block >= t01[None,:]-1e-7).sum(axis=1).astype(np.int32),
        "top1": (block >= t1[None,:]-1e-7).sum(axis=1).astype(np.int32),
        "top5": (block >= t5[None,:]-1e-7).sum(axis=1).astype(np.int32),
        "p95": np.quantile(block,.95,axis=1).astype(np.float32),
        "p99": np.quantile(block,.99,axis=1).astype(np.float32),
    }
    if promoted:
        xw = block >= win[None,:]-1e-7
        x01 = block >= t01[None,:]-1e-7
        out["win_bits"] = np.packbits(xw, axis=1, bitorder="little")
        out["top01_bits"] = np.packbits(x01, axis=1, bitorder="little")
    del block
    return out


def _build_lineup_chunks(root: Path, state: dict[str, Any], budget: resume.RuntimeBudget, *, lane: str, rows: np.ndarray, sims: np.ndarray, thresholds: tuple[np.ndarray,np.ndarray,np.ndarray,np.ndarray], lineup_chunk: int, promoted: bool) -> bool:
    d = root / lane / "lineup_chunks"
    d.mkdir(parents=True, exist_ok=True)
    n = len(rows)
    cursor = int((state.get("CURSORS", {}) or {}).get(f"{lane.upper()}_LINEUPS", 0))
    win,t01,t1,t5 = thresholds
    for s in range(cursor, n, lineup_chunk):
        e = min(n, s+lineup_chunk)
        p = d / f"lineup_{s:08d}_{e:08d}.npz"
        t0 = time.monotonic()
        if not p.exists():
            rec = _lineup_chunk_metrics(rows[s:e], sims, win, t01, t1, t5, promoted=promoted)
            digest = _atomic_npz(p, **rec)
            del rec
        else:
            digest = _sha256_file(p)
        dt = time.monotonic()-t0
        budget.update_chunk_runtime(dt)
        _commit(state, root, stage=f"{lane.upper()}_LINEUPS", cursor=e, path=p, sha256=digest, rows=e-s, trials=sims.shape[1])
        gc.collect()
        if e < n and _should_yield(budget):
            return False
    return True


def _assemble_base_metrics(root: Path, lane: str, n: int, base_trials: int, promoted: bool) -> dict[str, Any]:
    d = root / lane / "lineup_chunks"
    files = sorted(d.glob("lineup_*.npz"))
    if not files:
        raise RuntimeError("RUN_INVALID:CFB_CHUNK_STREAM_LINEUP_CHUNKS_MISSING")
    nb=(base_trials+7)//8
    vals = {
        "win_credit": np.zeros(n,dtype=np.float64), "top01": np.zeros(n,dtype=np.int32),
        "top1": np.zeros(n,dtype=np.int32), "top5": np.zeros(n,dtype=np.int32),
        "p95": np.zeros(n,dtype=np.float32), "p99": np.zeros(n,dtype=np.float32),
    }
    if promoted:
        vals["win_bits"] = np.zeros((n,nb),dtype=np.uint8)
        vals["top01_bits"] = np.zeros((n,nb),dtype=np.uint8)
    for p in files:
        stem=p.stem.split("_")
        s=int(stem[1]); e=int(stem[2])
        with np.load(p,allow_pickle=False) as z:
            for k in vals:
                vals[k][s:e]=z[k]
    return vals


def _save_sim_artifacts(root: Path, lane: str, sim: dict[str, Any]) -> None:
    d=root/lane/"final"; d.mkdir(parents=True,exist_ok=True)
    meta={}
    for k,v in sim.items():
        if isinstance(v,np.ndarray):
            p=d/f"{k}.npy"; meta[k]={"path":str(p),"sha256":_atomic_npy(p,v),"dtype":str(v.dtype),"shape":list(v.shape)}
        else:
            meta[k]=v
    resume.atomic_json(d/"sim_meta.json",meta)


def _load_sim_artifacts(root: Path, lane: str) -> dict[str, Any]:
    d=root/lane/"final"; meta=json.loads((d/"sim_meta.json").read_text())
    out={}
    for k,v in meta.items():
        if isinstance(v,dict) and "path" in v:
            p=Path(v["path"])
            if _sha256_file(p)!=v["sha256"]:
                raise RuntimeError(f"RUN_INVALID:CFB_CHUNK_STREAM_SIM_HASH_MISMATCH:{lane}:{k}")
            out[k]=np.load(p,mmap_mode="r")
        else:
            out[k]=v
    return out


def _finalize_sim(root: Path, *, lane: str, rows: np.ndarray, legal: np.ndarray, legal_feat: dict[str,np.ndarray], cal: eng.Calibration, cfg: eng.Config, opportunity: bool) -> dict[str, Any]:
    base_sims=np.load(root/lane/"base_sims.npy",mmap_mode="r")
    vals=_assemble_base_metrics(root,lane,len(rows),cfg.base_trials,promoted=opportunity)
    win_credit=vals["win_credit"]; top01=vals["top01"]; top1=vals["top1"]; top5=vals["top5"]; p95=vals["p95"]; p99=vals["p99"]
    trials=np.full(len(rows),cfg.base_trials,dtype=np.int32)
    primary=.62*(win_credit/cfg.base_trials)+.38*(top01/cfg.base_trials)
    order=np.argsort(primary+1e-5*eng._pct(p99),kind="stable")[::-1]
    bubble=order[:min(cfg.bubble_cap,len(order))]
    extra_total=0
    if len(bubble):
        extra_sims=np.load(root/lane/"extra_sims.npy",mmap_mode="r")
        ext=_concat_thresholds(root/lane/"extra_threshold_chunks")
        w2,t012,t12,t52=ext
        bls=eng._lineup_scores(rows[bubble],extra_sims,chunk=128)
        win_credit[bubble]+=(bls>w2[None,:]+1e-7).sum(axis=1)+.5*(np.abs(bls-w2[None,:])<=1e-7).sum(axis=1)
        top01[bubble]+=(bls>=t012[None,:]-1e-7).sum(axis=1)
        top1[bubble]+=(bls>=t12[None,:]-1e-7).sum(axis=1)
        top5[bubble]+=(bls>=t52[None,:]-1e-7).sum(axis=1)
        trials[bubble]+=cfg.extra_trials
        base_bls=eng._lineup_scores(rows[bubble],base_sims,chunk=128)
        combo=np.concatenate([base_bls,bls],axis=1)
        p95[bubble]=np.quantile(combo,.95,axis=1).astype(np.float32)
        p99[bubble]=np.quantile(combo,.99,axis=1).astype(np.float32)
        extra_total=int(len(bubble)*cfg.extra_trials)
    lcb,ucb=eng._wilson(top01,trials)
    field_rows=np.load(root/lane/"field_rows.npy",mmap_mode="r")
    regime_receipt=json.loads((root/lane/"regime_receipt.json").read_text())
    sim={
        "win_rate":(win_credit/trials).astype(np.float64),"top01_rate":(top01/trials).astype(np.float64),
        "top01_lcb":lcb.astype(np.float64),"top01_ucb":ucb.astype(np.float64),"top1_rate":(top1/trials).astype(np.float64),"top5_rate":(top5/trials).astype(np.float64),
        "lineup_p95":p95,"lineup_p99":p99,"trials":trials,"BASE_SIM_TRIALS":cfg.base_trials,
        "BUBBLE_EXTRA_TRIALS_TOTAL":extra_total,"BUBBLE_LINEUPS_UNRESOLVED":0,"FAKE_FIELD_SIZE":cfg.field_size,
        "TOP01_FIELD_CUTOFF_N":max(1,int(math.ceil(cfg.field_size*.001))),
        "FAKE_FIELD_UNIQUE_LINEUPS":int(len({tuple(map(int,r)) for r in np.asarray(field_rows).tolist()})),
        "STREAMING_PHASE3":True,"STREAMING_LINEUP_CHUNK":int(os.environ.get("APEX_CFB_SHOWDOWN_LINEUP_CHUNK","384")),
        "ENGINE_OWNED_CHUNK_STREAM":True,"CHUNK_STREAM_PATCH_ID":PATCH_ID,"regime_receipt":regime_receipt,
    }
    if opportunity:
        sim["_base_player_sims"]=np.asarray(base_sims,dtype=np.float32)
        sim["_top01_bits"]=vals["top01_bits"]
        sim["_win_bits"]=vals["win_bits"]
    _save_sim_artifacts(root,lane,sim)
    return sim


def _prepare_extra_context(root: Path, state: dict[str, Any], budget: resume.RuntimeBudget, *, lane: str, cal: eng.Calibration, legal: np.ndarray, legal_feat: dict[str,np.ndarray], cfg: eng.Config, opportunity: bool, trial_chunk: int) -> bool:
    d=root/lane; d.mkdir(parents=True,exist_ok=True)
    extra_path=d/"extra_sims.npy"
    if not extra_path.exists():
        t0=time.monotonic()
        if opportunity:
            ex,reg2,_=eng.opportunity_model.simulate(eng,cal,cfg.extra_trials,cfg.seed ^ 0xE87A352,return_regime=True)
        else:
            ex,reg2=eng._simulate_players(cal,cfg.extra_trials,cfg.seed ^ 0xE87A352,return_regime=True)
        digest=_atomic_npy(extra_path,ex)
        resume.atomic_json(d/"extra_regime_receipt.json",reg2)
        budget.update_chunk_runtime(time.monotonic()-t0)
        _commit(state,root,stage=f"{lane.upper()}_EXTRA_CONTEXT",cursor=1,path=extra_path,sha256=digest,trials=cfg.extra_trials)
        del ex; gc.collect()
        if _should_yield(budget): return False
    field2_path=d/"extra_field_rows.npy"
    if not field2_path.exists():
        t0=time.monotonic()
        rng=np.random.default_rng(cfg.seed ^ 0xF13D352)
        state_after=_load_pickle(d/"rng_after_base.pkl")
        rng.bit_generator.state=state_after
        field2=eng._sample_public_field(cal,cfg,rng,legal,legal_feat)
        digest=_atomic_npy(field2_path,field2)
        budget.update_chunk_runtime(time.monotonic()-t0)
        _commit(state,root,stage=f"{lane.upper()}_EXTRA_FIELD",cursor=1,path=field2_path,sha256=digest,rows=len(field2))
        del field2; gc.collect()
        if _should_yield(budget): return False
    # Build extra thresholds into a separate directory using the same chunk contract.
    dthr=d/"extra_threshold_chunks"; dthr.mkdir(parents=True,exist_ok=True)
    ex=np.load(extra_path,mmap_mode="r"); field2=np.load(field2_path,mmap_mode="r")
    total=ex.shape[1]
    existing=sorted(dthr.glob("threshold_*.npz"))
    cursor=0
    if existing:
        last=existing[-1].stem.split("_"); cursor=int(last[-1])
    for ts in range(cursor,total,trial_chunk):
        te=min(total,ts+trial_chunk); p=dthr/f"threshold_{ts:08d}_{te:08d}.npz"; t0=time.monotonic()
        rec=_threshold_chunk(field2,ex,cfg.field_size,ts,te); digest=_atomic_npz(p,**rec); del rec
        budget.update_chunk_runtime(time.monotonic()-t0)
        _commit(state,root,stage=f"{lane.upper()}_EXTRA_THRESHOLDS",cursor=te,path=p,sha256=digest,trials=te-ts)
        gc.collect()
        if te<total and _should_yield(budget): return False
    return True


def _prepare_lane_context(root: Path, state: dict[str, Any], budget: resume.RuntimeBudget, *, lane: str, cal: eng.Calibration, legal: np.ndarray, legal_feat: dict[str,np.ndarray], cfg: eng.Config, opportunity: bool) -> bool:
    d=root/lane; d.mkdir(parents=True,exist_ok=True)
    sims_path=d/"base_sims.npy"
    if not sims_path.exists():
        t0=time.monotonic()
        if opportunity:
            sims,reg,_=eng.opportunity_model.simulate(eng,cal,cfg.base_trials,cfg.seed ^ 0xB453CFB,return_regime=True)
        else:
            sims,reg=eng._simulate_players(cal,cfg.base_trials,cfg.seed ^ 0xB453CFB,return_regime=True)
        digest=_atomic_npy(sims_path,sims); resume.atomic_json(d/"regime_receipt.json",reg)
        budget.update_chunk_runtime(time.monotonic()-t0)
        _commit(state,root,stage=f"{lane.upper()}_PLAYER_WORLDS",cursor=cfg.base_trials,path=sims_path,sha256=digest,trials=cfg.base_trials)
        del sims; gc.collect()
        if _should_yield(budget): return False
    field_path=d/"field_rows.npy"
    if not field_path.exists():
        t0=time.monotonic(); rng=np.random.default_rng(cfg.seed ^ 0xF13D352)
        field=eng._sample_public_field(cal,cfg,rng,legal,legal_feat)
        digest=_atomic_npy(field_path,field); _atomic_pickle(d/"rng_after_base.pkl",rng.bit_generator.state)
        budget.update_chunk_runtime(time.monotonic()-t0)
        _commit(state,root,stage=f"{lane.upper()}_PUBLIC_FIELD",cursor=len(field),path=field_path,sha256=digest,rows=len(field))
        del field; gc.collect()
        if _should_yield(budget): return False
    return True


def _recurrence_chunk(root: Path, state: dict[str, Any], budget: resume.RuntimeBudget, *, rows: np.ndarray, sim: dict[str,Any], chunk: int) -> bool:
    d=root/"recurrence"/"chunks"; d.mkdir(parents=True,exist_ok=True)
    sims=np.asarray(sim["_base_player_sims"],dtype=np.float32); topbits=np.asarray(sim["_top01_bits"],dtype=np.uint8); winbits=np.asarray(sim["_win_bits"],dtype=np.uint8)
    q=np.quantile(sims,[.30,.40,.75,.80],axis=1).astype(np.float32)
    n=len(rows); cursor=int((state.get("CURSORS", {}) or {}).get("RECURRENCE_STREAM",0))
    for s in range(cursor,n,chunk):
        e=min(n,s+chunk); p=d/f"recurrence_{s:08d}_{e:08d}.npz"; t0=time.monotonic()
        if not p.exists():
            sb,cb,cwb,strict,core,cw=eng._recurrence_counts_numba(sims,np.asarray(rows[s:e],dtype=np.int32),topbits[s:e],winbits[s:e],q)
            digest=_atomic_npz(p,sb=sb,cb=cb,cwb=cwb,strict=strict,core=core,cw=cw)
            del sb,cb,cwb,strict,core,cw
        else: digest=_sha256_file(p)
        budget.update_chunk_runtime(time.monotonic()-t0)
        _commit(state,root,stage="RECURRENCE_STREAM",cursor=e,path=p,sha256=digest,rows=e-s,trials=sims.shape[1])
        gc.collect()
        if e<n and _should_yield(budget): return False
    return True


def _load_recurrence_cache(root: Path, n: int, nb: int) -> tuple[np.ndarray,...]:
    vals={"sb":np.zeros((n,nb),np.uint8),"cb":np.zeros((n,nb),np.uint8),"cwb":np.zeros((n,nb),np.uint8),"strict":np.zeros(n,np.int32),"core":np.zeros(n,np.int32),"cw":np.zeros(n,np.int32)}
    files=sorted((root/"recurrence"/"chunks").glob("recurrence_*.npz"))
    if not files: raise RuntimeError("RUN_INVALID:CFB_RECURRENCE_STREAM_EMPTY")
    for p in files:
        stem=p.stem.split("_"); s=int(stem[1]); e=int(stem[2])
        with np.load(p,allow_pickle=False) as z:
            for k in vals: vals[k][s:e]=z[k]
    return vals["sb"],vals["cb"],vals["cwb"],vals["strict"],vals["core"],vals["cw"]


def _run(a: argparse.Namespace) -> int:
    pool=Path(a.pool).resolve(); board=Path(a.board).resolve(); receipt=Path(a.receipt).resolve()
    field_size=int(a.field_size); entry_limit=int(a.entry_limit)
    if entry_limit < 1 or entry_limit > field_size:
        raise RuntimeError(f"RUN_INVALID:CFB_ENTRY_LIMIT:{entry_limit}")
    # Critical run parameters have no silent defaults. Hidden/session state may agree
    # with the explicit command, but it may never override or contradict it.
    for key in ("APEX_USER_ENTRIES","APEX_MAX_ENTRIES"):
        raw=os.environ.get(key)
        if raw not in (None,""):
            try: prior=int(raw)
            except Exception as exc: raise RuntimeError(f"RUN_INVALID:CFB_ENTRY_LIMIT_NONINTEGER:{key}={raw}") from exc
            if prior != entry_limit:
                raise RuntimeError(f"RUN_INVALID:CFB_ENTRY_LIMIT_AUTHORITY_CONFLICT:{key}={prior}:EXPLICIT={entry_limit}")
    os.environ["APEX_MAX_ENTRIES"]=str(entry_limit)
    os.environ.pop("APEX_USER_ENTRIES",None)
    seed=int(a.seed if a.seed is not None else 352082926)
    cfg=eng.Config(field_size=field_size,seed=seed,final_board_size=entry_limit); cfg.validate()
    root=_state_root(board); identity=_identity(pool,cfg.field_size,seed,entry_limit); state=_load_state(root,identity)
    state["EXECUTION_STATE"]="RUNNING"; _save_state(root,state)
    soft=float(os.environ.get("APEX_CFB_SHOWDOWN_CHUNK_STREAM_SOFT_SECONDS","42"))
    reserve_seconds=float(os.environ.get("APEX_CFB_SHOWDOWN_CHUNK_STREAM_RESERVE_SECONDS","5"))
    budget=resume.RuntimeBudget(time.monotonic(),soft_limit_seconds=soft,reserve_seconds=reserve_seconds,chunk_ema_seconds=state.get("CHUNK_EMA_SECONDS"))
    lineup_chunk=max(32,int(os.environ.get("APEX_CFB_SHOWDOWN_LINEUP_CHUNK","384")))
    trial_chunk=max(32,int(os.environ.get("APEX_CFB_SHOWDOWN_TRIAL_CHUNK","256")))
    recurrence_chunk=max(32,int(os.environ.get("APEX_CFB_SHOWDOWN_RECURRENCE_CHUNK","512")))

    while True:
        stage=state["STAGE"]
        if stage=="PREP":
            t0=time.monotonic()
            cal=eng._calibrate(pool,cfg)
            cal,role_authority_receipt=eng._apply_external_role_authority(cal,cfg)
            legal,generation_receipt=eng._enumerate_legal(cal,cfg)
            if generation_receipt.get("FULL_LEGAL_UNIVERSE_ENUMERATED") is not False:
                raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_LIVE_FULL_ENUMERATION_PROHIBITED")
            if generation_receipt.get("GENERATION_METHOD") != "DETERMINISTIC_CALIBRATION_QUALIFIED_BEAM_BRANCH":
                raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_LIVE_GENERATION_METHOD_UNAUTHORIZED")
            feat=eng._lineup_features(legal,cal)
            p2_seed,pf_seed,p2seedrec=eng._phase2(legal,feat,cfg)
            prep={"cal":cal,"legal":legal,"generation_receipt":generation_receipt,"feat":feat,"p2_seed":p2_seed,"pf_seed":pf_seed,"p2seedrec":p2seedrec,"role_authority_receipt":role_authority_receipt}
            p=root/"prep.pkl"; digest=_atomic_pickle(p,prep); budget.update_chunk_runtime(time.monotonic()-t0)
            _commit(state,root,stage="PREP",cursor=1,path=p,sha256=digest,rows=len(p2_seed)); _advance(root,state,"ROLE_COMPLETE",1)
            del prep; gc.collect()
            if _should_yield(budget): return _yield(root,state,budget)
            continue

        prep=_load_pickle(root/"prep.pkl")
        cal=prep["cal"]; legal=prep["legal"]; generation_receipt=prep["generation_receipt"]; feat=prep["feat"]; p2_seed=prep["p2_seed"]; pf_seed=prep["pf_seed"]; p2seedrec=prep["p2seedrec"]; role_authority_receipt=prep.get("role_authority_receipt",{})

        if stage.startswith("LEGACY_"):
            raise RuntimeError("RUN_INVALID:CFB_LIVE_CONTRACT_LEGACY_SELECTOR_PATH_PROHIBITED")

        if stage=="ROLE_COMPLETE":
            t0=time.monotonic(); p2_seed_recall,qb51_receipt=eng._qb_cpt_5_1_missing_role_family_reserve(p2_seed,cal); p2_seed_recall,production_birth_receipt=eng._cfb_showdown_production_birth_reserves(p2_seed_recall,cal,cfg); p2,pf,p2rec=eng._role_complete_phase2_families(p2_seed_recall,cal)
            p2rec.update(qb51_receipt); p2rec.update(production_birth_receipt); p2rec["PHASE2_PRE_CLOSURE_BUILT_LINEUPS"]=int(p2seedrec["PHASE2_BUILT_LINEUPS"]); p2rec["PHASE2_PRE_CLOSURE_FAMILY_COUNT"]=int(p2seedrec["PHASE2_FAMILY_COUNT"])
            cal2=cal; feat2=feat
            p2rec.update(role_authority_receipt)
            obj={"p2":p2,"pf":pf,"p2rec":p2rec,"cal":cal2,"feat":feat2,"role_authority_receipt":role_authority_receipt}
            p=root/"role_complete.pkl"; digest=_atomic_pickle(p,obj); budget.update_chunk_runtime(time.monotonic()-t0); _commit(state,root,stage="ROLE_COMPLETE",cursor=1,path=p,sha256=digest,rows=len(p2)); _advance(root,state,"PROMOTED_CONTEXT",2)
            del obj; gc.collect()
            if _should_yield(budget): return _yield(root,state,budget)
            continue

        role=_load_pickle(root/"role_complete.pkl"); p2=role["p2"]; pf=role["pf"]; p2rec=role["p2rec"]; cal2=role["cal"]; feat2=role["feat"]; role_authority_receipt=role["role_authority_receipt"]
        if stage=="PROMOTED_CONTEXT":
            if not _prepare_lane_context(root,state,budget,lane="promoted",cal=cal2,legal=legal,legal_feat=feat2,cfg=cfg,opportunity=True): return _yield(root,state,budget)
            _advance(root,state,"PROMOTED_THRESHOLDS",3); continue
        if stage=="PROMOTED_THRESHOLDS":
            sims=np.load(root/"promoted"/"base_sims.npy",mmap_mode="r"); field=np.load(root/"promoted"/"field_rows.npy",mmap_mode="r")
            if not _build_thresholds(root,state,budget,lane="promoted",field_rows=field,sims=sims,field_size=cfg.field_size,trial_chunk=trial_chunk): return _yield(root,state,budget)
            _advance(root,state,"PROMOTED_LINEUPS",4); continue
        if stage=="PROMOTED_LINEUPS":
            sims=np.load(root/"promoted"/"base_sims.npy",mmap_mode="r"); thresholds=_concat_thresholds(root/"promoted"/"threshold_chunks")
            if not _build_lineup_chunks(root,state,budget,lane="promoted",rows=p2,sims=sims,thresholds=thresholds,lineup_chunk=lineup_chunk,promoted=True): return _yield(root,state,budget)
            _advance(root,state,"PROMOTED_EXTRA",5); continue
        if stage=="PROMOTED_EXTRA":
            if not _prepare_extra_context(root,state,budget,lane="promoted",cal=cal2,legal=legal,legal_feat=feat2,cfg=cfg,opportunity=True,trial_chunk=trial_chunk): return _yield(root,state,budget)
            _advance(root,state,"PROMOTED_FINALIZE",6); continue
        if stage=="PROMOTED_FINALIZE":
            t0=time.monotonic(); sim=_finalize_sim(root,lane="promoted",rows=p2,legal=legal,legal_feat=feat2,cal=cal2,cfg=cfg,opportunity=True); budget.update_chunk_runtime(time.monotonic()-t0)
            p=root/"promoted"/"final"/"sim_meta.json"; _commit(state,root,stage="PROMOTED_FINALIZE",cursor=1,path=p,sha256=_sha256_file(p),rows=len(p2)); _advance(root,state,"RECURRENCE_STREAM",7)
            del sim; gc.collect()
            if _should_yield(budget): return _yield(root,state,budget)
            continue
        if stage=="RECURRENCE_STREAM":
            sim=_load_sim_artifacts(root,"promoted")
            if not _recurrence_chunk(root,state,budget,rows=p2,sim=sim,chunk=recurrence_chunk): return _yield(root,state,budget)
            _advance(root,state,"SELECT_AND_SEAL",8); continue
        if stage=="SELECT_AND_SEAL":
            t0=time.monotonic(); sim=_load_sim_artifacts(root,"promoted")
            nb=(cfg.base_trials+7)//8; sim["_recurrence_cache"]=_load_recurrence_cache(root,len(p2),nb)
            recurrence_chosen,recurrence_receipt=eng._recurrence_portfolio_select(p2,sim,cfg)
            incumbent_idx=-1
            chosen=np.asarray(recurrence_chosen,dtype=np.int32)
            bridge_receipt={
                "INCUMBENT_GATE":False,
                "INCUMBENT_RESTORED":False,
                "INCUMBENT_INDEX":-1,
                "LIVE_CONTRACT_LEGACY_SELECTOR_DISABLED":True,
                "LIVE_CONTRACT_PATCH_ID":LIVE_EXECUTION_CONTRACT_PATCH,
            }
            chosen,known51_receipt=eng._known_role_5_1_wr_cpt_reserve(chosen,p2,pf,sim,cal2)
            chosen,hedge_receipt=eng._balanced_value_cpt_same_role_hedge(chosen,p2,pf,sim,cal2)
            chosen,dualqb_receipt=eng._balanced_dual_qb_value_family_reserve(chosen,p2,pf,sim,cal2)
            chosen,recovered_hedge_receipt=eng._recovered_starter_salary_release_hedge(chosen,p2,pf,sim,cal2,role_authority_receipt)

            # Freeze established sport-native authorities before entry-limit canaries.
            pre_canary_chosen=np.asarray(chosen,dtype=np.int32).copy()
            established_lane_candidates=set()
            if bridge_receipt.get('INCUMBENT_GATE') and incumbent_idx>=0:
                established_lane_candidates.add(int(incumbent_idx))
            for key,rec in (
                ('KNOWN_ROLE_5_1_INDEX',known51_receipt),
                ('HEDGE_ANCHOR_INDEX',hedge_receipt),('HEDGE_INDEX',hedge_receipt),
                ('DUAL_QB_VALUE_INDEX',dualqb_receipt),
                ('RECOVERED_STARTER_HEDGE_ANCHOR_INDEX',recovered_hedge_receipt),
                ('RECOVERED_STARTER_HEDGE_INDEX',recovered_hedge_receipt),
            ):
                v=rec.get(key)
                if v is not None:
                    established_lane_candidates.add(int(v))
            pre_canary_set=set(map(int,pre_canary_chosen.tolist()))
            established_core_protect={int(i) for i in established_lane_candidates if int(i) in pre_canary_set}

            chosen,qb51_core_receipt=eng._known_role_5_1_qb_cpt_core_completion_reserve(chosen,p2,pf,sim,cal2,cfg)
            qb51_protect={int(qb51_core_receipt['CFB_5_1_QB_CPT_INDEX'])} if qb51_core_receipt.get('CFB_5_1_QB_CPT_INDEX') is not None else set()
            chosen,rb42_canary_receipt=eng._favorite_control_rb_cpt_4_2_single_qb_reserve(chosen,p2,pf,sim,cal2,cfg,protect=qb51_protect)
            secondary_rb_idx,secondary_rb_receipt=eng._secondary_favorite_rb_cpt_family_retention_candidate(p2,pf,sim,cal2,cfg)
            if secondary_rb_idx>=0:
                established_core_protect.add(int(secondary_rb_idx))
            prefinal_chosen=np.asarray(chosen,dtype=np.int32).copy()
            portfolio_chosen,portfolio_receipt=eng._max_entry_portfolio_finalize(
                p2,pf,sim,cal2,cfg,protected_indices=established_core_protect)
            chosen,head_receipt=eng._championship_head_order_only(portfolio_chosen,p2,pf,sim,cal2,cfg)
            portfolio_receipt.update({
                'CFB_PRE_CANARY_SELECTED_INDICES':[int(x) for x in pre_canary_chosen.tolist()],
                'CFB_PREFINAL_SELECTED_INDICES':[int(x) for x in prefinal_chosen.tolist()],
                'CFB_ESTABLISHED_LANE_PROTECTED_INDICES':sorted(map(int,established_core_protect)),
                'CFB_ESTABLISHED_LANE_PROTECTION':'FORWARD_BLIND_AUTHORITIES_ONLY',
                'CFB_CANARY_CANDIDATE_QB51_INDEX':qb51_core_receipt.get('CFB_5_1_QB_CPT_INDEX'),
                'CFB_CANARY_CANDIDATE_RB42_INDEX':rb42_canary_receipt.get('CFB_4_2_RB_CPT_INDEX'),
                'CFB_SECONDARY_FAVORITE_RB_CPT_PROTECTED_INDEX':secondary_rb_receipt.get('CFB_SECONDARY_FAVORITE_RB_CPT_INDEX'),
            })
            relax=np.asarray([0],dtype=np.int8)
            selector_regime_receipt={**recurrence_receipt,**bridge_receipt,**known51_receipt,**hedge_receipt,**dualqb_receipt,**recovered_hedge_receipt,**qb51_core_receipt,**rb42_canary_receipt,**secondary_rb_receipt,**portfolio_receipt,**head_receipt,
                "CFB_LIVE_EXECUTION_CONTRACT_PATCH_ID":LIVE_EXECUTION_CONTRACT_PATCH,
                "CFB_LIVE_PHASE_ORDER":"CALIBRATION>QUALIFIED_BIRTH>SIMULATION>SELECTOR>MAX_ENTRY_PORTFOLIO",
                "CFB_LIVE_LEGACY_SELECTOR_PATH":False,
                "CFB_LIVE_FULL_ENUMERATION_ALLOWED":False,
                "CFB_CHUNK_STREAM_PATCH_ID":PATCH_ID,"CFB_CHUNK_STREAM_COMPLETED_CHUNKS":int(state.get("COMPLETED_CHUNKS",0)),"CFB_CHUNK_STREAM_SAFE_YIELDS":int(state.get("SAFE_YIELD_COUNT",0))}
            final_board,final_receipt=eng._write(chosen,p2,pf,sim,cal2,legal,cfg,board,receipt,p2rec,relax,generation_receipt,selector_regime_receipt)
            if final_receipt["BOARD_LEGALITY"]!="PASS" or final_receipt["FINAL_BOARD_SIZE"]!=cfg.final_board_size: raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_SHOWDOWN_TERMINAL_BOARD_INVALID")

            # Live production authority ends at the deterministic engine-owned MAX-ENTRY
            # portfolio. The five-lineup championship head is order-only and cannot
            # add/remove requested portfolio members.
            execution_mode=str(os.environ.get('APEX_EXECUTION_MODE','PRODUCTION')).upper()
            if execution_mode != 'DIAGNOSTIC':
                state["STAGE"]="COMPLETE"; state["STAGE_INDEX"]=9; state["EXECUTION_STATE"]="COMPLETED"
                state["FINAL_BOARD_SHA256"]=_sha256_file(board); state["FINAL_RECEIPT_SHA256"]=_sha256_file(receipt); _save_state(root,state)
                budget.update_chunk_runtime(time.monotonic()-t0)
                obj={
                    'RUN_STATE':'NATIVE_BOARD_READY_FOR_MAX_ENTRY_PORTFOLIO','EXECUTION_STATE':'TOOL_PROVEN_EXECUTED',
                    'ENGINE_ID':eng.ENGINE_ID,'SPORT':'CFB','MODE':'SHOWDOWN','FIELD_SIZE':cfg.field_size,'ENTRY_LIMIT':int(entry_limit),'ENTRY_LIMIT_CONTRACT_PATCH_ID':ENTRY_LIMIT_CONTRACT_PATCH,
                    'TERMINAL_PLAYABLE_BOARD':True,'MAX_ENTRY_PORTFOLIO_REQUIRED':True,'REQUESTED_PORTFOLIO_SIZE':int(entry_limit),'GLOBAL_CHAMPIONSHIP_CORE_REQUIRED':True,'GLOBAL_CHAMPIONSHIP_CORE_SIZE':min(5,int(entry_limit)),'GLOBAL_CHAMPIONSHIP_CORE_MEMBERSHIP_AUTHORITY':False,
                    'NATIVE_BOARD_SIZE':len(final_board),'FINAL_BOARD_SIZE':len(final_board),'FINAL_BOARD':final_board.to_dict('records'),
                    'AI_TERMINAL_AUTHORITY_REQUIRED':False,'AI_TERMINAL_MODE':'DIAGNOSTIC_ONLY',
                    'OPENAI_LIVE_AUTHORITY':False,'CHAT_EXECUTION_AUTHORITY':False,
                    'SELECTOR_REVIEWED_LINEUPS':len(p2),'CFB_CHUNK_STREAM_PATCH_ID':PATCH_ID,
                    'CFB_CHUNK_STREAM_COMPLETED_CHUNKS':int(state.get('COMPLETED_CHUNKS',0)),
                    'CFB_CHUNK_STREAM_SAFE_YIELDS':int(state.get('SAFE_YIELD_COUNT',0)),
                    'CFB_CHUNK_STREAM_CONTROLLER_STATE':str(root/'controller_state.json'),
                }
                print(json.dumps(obj,separators=(",",":")),flush=True); return 0

            lane_annotations=_sport_native_lane_annotations(
                chosen=chosen,recurrence_receipt=recurrence_receipt,bridge_receipt=bridge_receipt,
                known51_receipt=known51_receipt,hedge_receipt=hedge_receipt,dualqb_receipt=dualqb_receipt,
                recovered_hedge_receipt=recovered_hedge_receipt,qb51_core_receipt=qb51_core_receipt,rb42_canary_receipt=rb42_canary_receipt,secondary_rb_receipt=secondary_rb_receipt)
            ai_rows=_build_ai_terminal_rows(rows=p2,pf=pf,sim=sim,cal=cal2,chosen=chosen,lane_annotations=lane_annotations)
            ai_surface=Path(board).parent/f"DK_CFB_SHOWDOWN_{cfg.field_size}_AI_TERMINAL_CANDIDATES.csv"
            ai_receipt_path=Path(board).parent/f"DK_CFB_SHOWDOWN_{cfg.field_size}_AI_TERMINAL_CANDIDATES_RECEIPT.json"
            ai_receipt=terminal_ai.write_review_surface(
                ai_rows,csv_path=ai_surface,receipt_path=ai_receipt_path,sport='CFB',mode='SHOWDOWN',execution_id=str(cfg.field_size),
                context={
                    'GLOBAL_FULL_HANDOFF':True,'NO_PRUNING':True,'DECLARED_SELECTOR_REVIEWED_LINEUPS':len(ai_rows),
                    'SOURCE':'CFB_SHOWDOWN_ENGINE_OWNED_SELECTOR_CHECKPOINT','CURRENT_CODE_SELECTOR_ROLE':'ADVISORY_COMPARATOR_ONLY',
                    'CFB_NATIVE_SELECTOR_PATCH':eng.CFB_RECURRENCE_SELECTOR_PATCH,
                    'CFB_SPORT_NATIVE_LANE_AUTHORITY':True,
                    'CFB_SPORT_NATIVE_PROTECTED_LANES':sorted({str(v.get('SELECTION_LANE')) for v in lane_annotations.values() if v.get('GLOBAL_CORE_PROTECTED')}),
                    'CFB_SPORT_NATIVE_SELECTED_LANE_COUNT':len(lane_annotations),
                    'CFB_SPORT_NATIVE_SELECTOR_RECEIPT':selector_regime_receipt,
                },
            )
            state["STAGE"]="COMPLETE"; state["STAGE_INDEX"]=9; state["EXECUTION_STATE"]="COMPLETED"; state["FINAL_BOARD_SHA256"]=_sha256_file(board); state["FINAL_RECEIPT_SHA256"]=_sha256_file(receipt); state['AI_TERMINAL_CANDIDATE_SURFACE_SHA256']=_sha256_file(ai_surface); _save_state(root,state)
            budget.update_chunk_runtime(time.monotonic()-t0)
            obj={
                'RUN_STATE':'NATIVE_BOARD_READY_FOR_MAX_ENTRY_PORTFOLIO','EXECUTION_STATE':'TOOL_PROVEN_EXECUTED_TO_FROZEN_SELECTOR_HANDOFF',
                'ENGINE_ID':eng.ENGINE_ID,'SPORT':'CFB','MODE':'SHOWDOWN','FIELD_SIZE':cfg.field_size,'ENTRY_LIMIT':int(entry_limit),'ENTRY_LIMIT_CONTRACT_PATCH_ID':ENTRY_LIMIT_CONTRACT_PATCH,
                'TERMINAL_PLAYABLE_BOARD':False,'MAX_ENTRY_PORTFOLIO_REQUIRED':True,'REQUESTED_PORTFOLIO_SIZE':int(entry_limit),'GLOBAL_CHAMPIONSHIP_CORE_REQUIRED':True,'GLOBAL_CHAMPIONSHIP_CORE_SIZE':min(5,int(entry_limit)),'GLOBAL_CHAMPIONSHIP_CORE_MEMBERSHIP_AUTHORITY':False,
                'NATIVE_BOARD_SIZE':len(final_board),'FINAL_BOARD_SIZE':len(final_board),'FINAL_BOARD':final_board.to_dict('records'),
                'AI_TERMINAL_AUTHORITY_REQUIRED':False,'AI_TERMINAL_PATCH_ID':terminal_ai.PATCH_ID,
                'AI_TERMINAL_CANDIDATE_SURFACE_PATH':str(ai_surface),'AI_TERMINAL_CANDIDATE_RECEIPT_PATH':str(ai_receipt_path),
                'AI_TERMINAL_CANDIDATE_FREEZE_SHA256':ai_receipt['CANDIDATE_FREEZE_SHA256'],'AI_TERMINAL_CANDIDATE_COUNT':len(ai_rows),
                'SELECTOR_REVIEWED_LINEUPS':len(ai_rows),'AI_TERMINAL_NO_PRUNING':True,
                'CFB_CHUNK_STREAM_PATCH_ID':PATCH_ID,'CFB_CHUNK_STREAM_COMPLETED_CHUNKS':int(state.get('COMPLETED_CHUNKS',0)),
                'CFB_CHUNK_STREAM_SAFE_YIELDS':int(state.get('SAFE_YIELD_COUNT',0)),'CFB_CHUNK_STREAM_CONTROLLER_STATE':str(root/'controller_state.json'),
            }
            print(json.dumps(obj,separators=(",",":")),flush=True); return 0
        if stage=="COMPLETE":
            if not board.exists() or not receipt.exists(): raise RuntimeError("RUN_INVALID:CFB_CHUNK_STREAM_COMPLETE_ARTIFACT_MISSING")
            final_receipt=json.loads(receipt.read_text()); print(json.dumps(final_receipt,separators=(",",":")),flush=True); return 0
        raise RuntimeError(f"RUN_INVALID:CFB_CHUNK_STREAM_UNKNOWN_STAGE:{stage}")


def _args() -> argparse.Namespace:
    ap=argparse.ArgumentParser()
    ap.add_argument("--pool",required=True); ap.add_argument("--field-size",required=True,type=int)
    ap.add_argument("--entry-limit",required=True,type=int,help="Contest max-entry limit; required live authority and included in checkpoint identity")
    ap.add_argument("--board",required=True); ap.add_argument("--receipt",required=True); ap.add_argument("--seed",type=int)
    return ap.parse_args()


def main() -> int:
    a=_args()
    try:
        return _run(a)
    except Exception as exc:
        print(json.dumps({"RUN_STATE":"RUN_INVALID","EXECUTION_STATE":"FAILED","ENGINE_ID":eng.ENGINE_ID,"FINAL_BOARD_SIZE":0,"ENGINE_SUBSTITUTION":False,"FAILURE_CODE":f"{type(exc).__name__}:{exc}","PATCH_ID":PATCH_ID},separators=(",",":")),flush=True)
        return 2


if __name__=="__main__":
    raise SystemExit(main())
