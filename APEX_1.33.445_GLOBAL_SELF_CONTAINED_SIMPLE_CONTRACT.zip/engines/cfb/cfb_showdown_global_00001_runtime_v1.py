from __future__ import annotations

import itertools
import json
import os
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Iterator

import numpy as np

from engines.common.apex_global_exhaustive_championship_pipeline_v2 import run_global_contract
from engines.cfb import cfb_showdown_raw_pool_runtime_v1 as native

PATCH_ID = "CFB_SHOWDOWN_GLOBAL_EXACT_TARGET_RANK_ADAPTER_v1"


class CFBShowdownAdapter:
    sport = "CFB"
    mode = "SHOWDOWN"
    roster_size = 6
    core_size = 4
    has_cpt = True

    def __init__(self, pool: str | Path, field_size: int, output_dir: str | Path, execution_id: str, seed: int):
        self.pool = Path(pool).resolve()
        self.field_size = int(field_size)
        self.output_dir = Path(output_dir).resolve()
        self.execution_id = str(execution_id)
        self.seed = int(seed)
        cfg = native.Config(
            field_size=self.field_size,
            seed=self.seed,
            player_trials=50_000,
            base_trials=200_000,
            extra_trials=0,
            bubble_cap=0,
            final_board_size=1,
        )
        cfg.validate()
        cal = native._calibrate(self.pool, cfg)
        cal, role_receipt = native._apply_external_role_authority(cal, cfg)
        self.cal = cal
        self.role_receipt = role_receipt
        self.player_count = int(len(self.cal.names))

    def simulate(self, worlds: int, seed: int) -> tuple[np.ndarray, dict[str, Any]]:
        sims, receipt = native._simulate_players(self.cal, int(worlds), int(seed) ^ 0xC6B50001, return_regime=True)
        return np.asarray(sims, dtype=np.float32), {
            "PATCH_ID": PATCH_ID,
            "SPORT_NATIVE_RECEIPT": receipt,
            "ROLE_AUTHORITY_RECEIPT": self.role_receipt,
            "SELECTION_PIPELINE_USED": False,
        }

    def _legal(self, row: tuple[int, ...]) -> bool:
        ids = [int(x) for x in row]
        if len(ids) != 6 or len(set(ids)) != 6:
            return False
        cpt = ids[0]
        salary = int((int(self.cal.salary[cpt]) * 3) // 2 + sum(int(self.cal.salary[x]) for x in ids[1:]))
        if salary < int(native.SALARY_MIN) or salary > int(native.SALARY_MAX):
            return False
        teams = self.cal.team[np.asarray(ids, dtype=np.int32)]
        for team in np.unique(teams):
            if int(np.count_nonzero(teams == team)) > int(native.MAX_FROM_TEAM):
                return False
        return True

    def iter_legal_rows(self, chunk_size: int = 128) -> Iterator[np.ndarray]:
        buf: list[tuple[int, ...]] = []
        active = tuple(range(self.player_count))
        for six in itertools.combinations(active, 6):
            for cpt in six:
                flex = tuple(sorted(x for x in six if x != cpt))
                row = (int(cpt),) + flex
                if not self._legal(row):
                    continue
                buf.append(row)
                if len(buf) >= int(chunk_size):
                    yield np.asarray(buf, dtype=np.int32); buf = []
        if buf:
            yield np.asarray(buf, dtype=np.int32)

    def score_rows(self, rows: np.ndarray, sims: np.ndarray) -> np.ndarray:
        return native._lineup_scores(np.asarray(rows, dtype=np.int32), np.asarray(sims, dtype=np.float32))

    def lineup_identity(self, row: np.ndarray) -> tuple[int, ...]:
        return tuple(sorted(int(x) for x in row.tolist()))

    def cpt_player(self, row: np.ndarray) -> int | None:
        return int(row[0])

    def player_name(self, player_id: int) -> str:
        return str(self.cal.names[int(player_id)])

    def render_row(self, row: np.ndarray) -> dict[str, Any]:
        ids = [int(x) for x in row.tolist()]
        names = [self.player_name(x) for x in ids]
        salary = int((int(self.cal.salary[ids[0]]) * 3) // 2 + sum(int(self.cal.salary[x]) for x in ids[1:]))
        feat = native._lineup_features(np.asarray([ids], dtype=np.int32), self.cal)
        return {
            "CPT": names[0], "FLEX1": names[1], "FLEX2": names[2], "FLEX3": names[3], "FLEX4": names[4], "FLEX5": names[5],
            "SALARY": salary,
            "TEAM_SPLIT_CPT_TEAM": int(feat["same_cpt_team"][0]),
            "QB_COUNT": int(feat["qb_count"][0]),
        }


def run(pool: str | Path, field_size: int, role_evidence: str | Path | None = None, market_evidence: str | Path | None = None,
        board_path: str | Path | None = None, receipt_path: str | Path | None = None, seed: int | None = None,
        config: Any | None = None, availability_receipt: str | Path | None = None,
        execution_id: str | int | None = None, **_kwargs: Any):
    out = Path(os.environ.get("APEX_OUTPUT_DIR") or (Path(board_path).parent if board_path else "/tmp/apex_cfb_showdown")).resolve()
    out.mkdir(parents=True, exist_ok=True)
    board = Path(board_path or out / "FINAL_BOARD.csv")
    receipt = Path(receipt_path or out / "SPORT_ENGINE_TERMINAL.json")
    eid = str(execution_id if execution_id is not None else field_size)
    adapter = CFBShowdownAdapter(pool, int(field_size), out, eid, int(seed if seed is not None else field_size))
    return run_global_contract(adapter, field_size=int(field_size), execution_id=eid, board_path=board, receipt_path=receipt, seed=int(seed if seed is not None else field_size))


def _args() -> SimpleNamespace:
    out = Path(os.environ.get("APEX_OUTPUT_DIR") or "/tmp/apex_cfb_showdown").resolve(); out.mkdir(parents=True, exist_ok=True)
    pool = os.environ.get("APEX_PLAYER_POOL") or os.environ.get("APEX_PLAYER_CSV")
    if not pool:
        raise RuntimeError("RUN_INVALID:PLAYER_POOL_ENV_MISSING")
    field = int(os.environ.get("APEX_FIELD_SIZE") or os.environ.get("APEX_CONTEST_ID") or 0)
    return SimpleNamespace(
        pool=str(Path(pool).resolve()), field_size=field,
        role_evidence=None, market_evidence=None, availability_receipt=None,
        execution_id=str(os.environ.get("APEX_EXECUTION_ID") or os.environ.get("APEX_CONTEST_ID") or field),
        board=str(out / "FINAL_BOARD.csv"), receipt=str(out / "SPORT_ENGINE_TERMINAL.json"), seed=field,
    )


if __name__ == "__main__":
    a = _args()
    _, payload = run(a.pool, a.field_size, a.role_evidence, a.market_evidence, a.board, a.receipt, a.seed, availability_receipt=a.availability_receipt, execution_id=a.execution_id)
    print(json.dumps(payload, default=str), flush=True)
