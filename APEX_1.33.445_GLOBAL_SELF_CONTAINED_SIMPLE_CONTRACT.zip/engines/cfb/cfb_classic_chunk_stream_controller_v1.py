#!/usr/bin/env python3
from __future__ import annotations
import os
import sys
from pathlib import Path

# Production controllers may be launched by absolute path from any working
# directory. Ensure the engine bundle root is importable before package imports.
_ENGINE_ROOT = str(Path(__file__).resolve().parents[2])
if _ENGINE_ROOT not in sys.path:
    sys.path.insert(0, _ENGINE_ROOT)

from engines.common.apex_generic_python_chunk_stream_controller_v1 import main

PATCH_ID = "CFB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_v1"

if __name__ == "__main__":
    os.environ.setdefault("APEX_CFB_CLASSIC_FORCE_CANDIDATE_CHUNK_STREAM", "1")
    raise SystemExit(main())
