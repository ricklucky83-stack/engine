from __future__ import annotations

import itertools
import json
import math
import os
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Iterator

import numpy as np
import pandas as pd

from engines.common.apex_global_exhaustive_championship_pipeline_v2 import run_global_contract
from engines.cfb import cfb_classic_raw_pool_runtime_v1 as native

PATCH_ID = "CFB_CLASSIC_GLOBAL_EXACT_TARGET_RANK_ADAPTER_v1"


def _num(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or (isinstance(v, float) and math.isnan(v)):
            return float(default)
        s = str(v).strip()
        if not s or s in {"-", "nan", "None"}:
            return float(default)
        return float(s)
    except Exception:
        return float(default)


def _write_role_evidence(pool_path: Path, out_path: Path) -> Path:
    df = pd.read_csv(pool_path)
    players: dict[str, dict[str, Any]] = {}
    hard = {"OUT", "IR", "IR-", "INA", "NFI", "PUP", "SUSP", "REST", "DNP"}
    for team, grp in df.groupby("TEAM", dropna=False):
        tar_total = max(1.0, sum(max(0.0, _num(v)) for v in grp.get("TAR", pd.Series(dtype=float)).tolist()))
        car_total = max(1.0, sum(max(0.0, _num(v)) for v in grp.get("Rush Att", pd.Series(dtype=float)).tolist()))
        for _, r in grp.iterrows():
            name = str(r.get("PLAYER", "")).strip()
            if not name:
                continue
            pos = str(r.get("POS", "")).split("/")[0].strip().upper()
            inj = str(r.get("INJ", "")).strip().upper()
            status = "OUT" if inj in hard else "ACTIVE"
            pass_att = max(0.0, _num(r.get("Pass Att", 0.0)))
            tar = max(0.0, _num(r.get("TAR", 0.0)))
            car = max(0.0, _num(r.get("Rush Att", 0.0)))
            snap_raw = _num(r.get("SNAP%", r.get("Snap %", r.get("SNAPS", 0.0))))
            route_raw = _num(r.get("ROUTE%", r.get("Route %", r.get("ROUTES", 0.0))))
            snap = snap_raw / 100.0 if snap_raw > 1.0 else snap_raw
            route = route_raw / 100.0 if route_raw > 1.0 else route_raw
            target_share = tar / tar_total if tar_total > 0 else 0.0
            carry_share = car / car_total if car_total > 0 else 0.0
            if status == "OUT":
                snap = route = target_share = carry_share = 0.0
                unc = 0.05
            else:
                if snap <= 0.0:
                    if pos == "QB": snap = 1.0 if pass_att >= 10 else (0.25 if pass_att > 0 else 0.0)
                    elif pos == "RB": snap = max(carry_share, target_share, 0.18 if (car > 0 or tar > 0) else 0.0)
                    elif pos in {"WR", "TE"}: snap = max(target_share, 0.18 if tar > 0 else 0.0)
                if route <= 0.0 and pos in {"WR", "TE", "RB"}: route = target_share
                unc = 0.30
            players[name] = {
                "source_ref": "PLAYER_POOL_PRELOCK_STATS",
                "status": status,
                "availability_confirmed": status == "ACTIVE",
                "expected_meaningful_snaps": bool(status == "ACTIVE" and max(snap, route, target_share, carry_share) > 0.0),
                "snap_share": float(np.clip(snap, 0.0, 1.0)),
                "route_share": float(np.clip(route, 0.0, 1.0)),
                "target_share": float(max(0.0, target_share)),
                "carry_share": float(max(0.0, carry_share)),
                "role_uncertainty": float(unc),
            }
    payload = {
        "source": "PLAYER_POOL_PRELOCK_STATS",
        "evidence_mode": "CURRENT_PLAYER_POOL_ROLE_STATS",
        "players": players,
        "postlock_results_used": False,
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return out_path


class CFBClassicAdapter:
    sport = "CFB"
    mode = "CLASSIC"
    roster_size = 8
    core_size = 5
    has_cpt = False

    def __init__(self, pool: str | Path, field_size: int, output_dir: str | Path, execution_id: str, seed: int,
                 role_evidence: str | Path | None = None, market_evidence: str | Path | None = None,
                 availability_receipt: str | Path | None = None):
        self.pool = Path(pool).resolve()
        self.field_size = int(field_size)
        self.output_dir = Path(output_dir).resolve()
        self.execution_id = str(execution_id)
        self.seed = int(seed)
        role_path = Path(role_evidence).resolve() if role_evidence else _write_role_evidence(self.pool, self.output_dir / "CFB_CLASSIC_ROLE_EVIDENCE.json")
        market_path = Path(market_evidence).resolve() if market_evidence else self.output_dir / "CFB_CLASSIC_MARKET_EVIDENCE.json"
        if not market_path.exists():
            market_path.write_text("{}\n", encoding="utf-8")
        cfg = native.Config(
            field_size=self.field_size, seed=self.seed, player_trials=50_000,
            base_trials=200_000, extra_batch_trials=10_000, max_trials=200_000,
            board_size=1,
        )
        cfg.validate()
        roster_gate = native.require_prebuild_roster_check(
            availability_receipt, sport="CFB", mode="CLASSIC", pool_path=self.pool,
            execution_id=self.execution_id, field_size=self.field_size,
        )
        self.cal = native._load_calibration(self.pool, role_path, market_path, cfg, roster_gate)
        self.player_count = int(len(self.cal.ids))

    def simulate(self, worlds: int, seed: int) -> tuple[np.ndarray, dict[str, Any]]:
        base = {
            "mu": self.cal.mu, "sigma": self.cal.sigma,
            "pos": self.cal.pos, "team": self.cal.team, "opp": self.cal.opp, "game": self.cal.game,
            "role_snap": self.cal.role_snap, "role_routes": self.cal.role_routes,
            "role_targets": self.cal.role_targets, "role_carries": self.cal.role_carries,
            "team_total": self.cal.frame["TM Score"].to_numpy(float),
            "game_total": self.cal.frame["O/U"].to_numpy(float),
        }
        sims, receipt = native._simulate_players(base, int(worlds), int(seed) ^ 0xB453C1A5, return_regime=True)
        return np.asarray(sims, dtype=np.float32), {"PATCH_ID": PATCH_ID, "SPORT_NATIVE_RECEIPT": receipt, "SELECTION_PIPELINE_USED": False}

    def iter_legal_rows(self, chunk_size: int = 128) -> Iterator[np.ndarray]:
        by_pos = {p: [int(i) for i in np.flatnonzero(self.cal.pos == p)] for p in ("QB", "RB", "WR", "TE")}
        patterns = [
            (0, 2, 3, 3, 0), (1, 2, 2, 4, 0), (2, 2, 2, 3, 1),
            (3, 1, 4, 3, 0), (4, 1, 3, 4, 0), (5, 1, 3, 3, 1),
            (6, 1, 2, 5, 0), (7, 1, 2, 4, 1), (8, 1, 2, 3, 2),
        ]
        buf: list[np.ndarray] = []
        seen: set[tuple[int, ...]] = set()
        for pattern, qbc, rbc, wrc, tec in patterns:
            for qbs in itertools.combinations(by_pos["QB"], qbc):
                if qbc == 2 and str(self.cal.team[qbs[0]]) == str(self.cal.team[qbs[1]]):
                    continue
                for rbs in itertools.combinations(by_pos["RB"], rbc):
                    for wrs in itertools.combinations(by_pos["WR"], wrc):
                        te_iter = itertools.combinations(by_pos["TE"], tec) if tec else [tuple()]
                        for tes in te_iter:
                            selected = tuple(int(x) for x in (qbs + rbs + wrs + tes))
                            if len(selected) != 8 or len(set(selected)) != 8:
                                continue
                            try:
                                row = native._canonical_row(selected, int(pattern), self.cal)
                            except Exception:
                                continue
                            if not native._board_legality(row, self.cal):
                                continue
                            key = tuple(int(x) for x in row.tolist())
                            if key in seen:
                                continue
                            seen.add(key)
                            buf.append(np.asarray(row, dtype=np.int32))
                            if len(buf) >= int(chunk_size):
                                yield np.vstack(buf).astype(np.int32); buf = []
        if buf:
            yield np.vstack(buf).astype(np.int32)

    def score_rows(self, rows: np.ndarray, sims: np.ndarray) -> np.ndarray:
        return native._score_rows(np.asarray(rows, dtype=np.int32), np.asarray(sims, dtype=np.float32))

    def lineup_identity(self, row: np.ndarray) -> tuple[int, ...]:
        return tuple(sorted(int(x) for x in row.tolist()))

    def cpt_player(self, row: np.ndarray) -> int | None:
        return None

    def player_name(self, player_id: int) -> str:
        return str(self.cal.frame.iloc[int(player_id)]["PLAYER"])

    def render_row(self, row: np.ndarray) -> dict[str, Any]:
        rec = native._row_slot_names(np.asarray(row, dtype=np.int32), self.cal)
        rec["SALARY"] = int(self.cal.salary[np.asarray(row, dtype=np.int32)].sum())
        rec["GAME_COUNT"] = int(len(set(self.cal.game[np.asarray(row, dtype=np.int32)].tolist())))
        return rec


def run(pool: str | Path, field_size: int, role_evidence: str | Path | None = None, market_evidence: str | Path | None = None,
        board_path: str | Path | None = None, receipt_path: str | Path | None = None, seed: int | None = None,
        config: Any | None = None, availability_receipt: str | Path | None = None,
        execution_id: str | int | None = None, **_kwargs: Any):
    out = Path(os.environ.get("APEX_OUTPUT_DIR") or (Path(board_path).parent if board_path else "/tmp/apex_cfb_classic")).resolve()
    out.mkdir(parents=True, exist_ok=True)
    board = Path(board_path or out / "FINAL_BOARD.csv")
    receipt = Path(receipt_path or out / "SPORT_ENGINE_TERMINAL.json")
    eid = str(execution_id if execution_id is not None else field_size)
    adapter = CFBClassicAdapter(
        pool, int(field_size), out, eid, int(seed if seed is not None else field_size),
        role_evidence=role_evidence, market_evidence=market_evidence, availability_receipt=availability_receipt,
    )
    return run_global_contract(adapter, field_size=int(field_size), execution_id=eid, board_path=board, receipt_path=receipt, seed=int(seed if seed is not None else field_size))


def _args() -> SimpleNamespace:
    out = Path(os.environ.get("APEX_OUTPUT_DIR") or "/tmp/apex_cfb_classic").resolve(); out.mkdir(parents=True, exist_ok=True)
    pool = os.environ.get("APEX_PLAYER_POOL") or os.environ.get("APEX_PLAYER_CSV")
    if not pool:
        raise RuntimeError("RUN_INVALID:PLAYER_POOL_ENV_MISSING")
    field = int(os.environ.get("APEX_FIELD_SIZE") or os.environ.get("APEX_CONTEST_ID") or 0)
    return SimpleNamespace(
        pool=str(Path(pool).resolve()), field_size=field,
        role_evidence=os.environ.get("APEX_CFB_ROLE_EVIDENCE_FILE"),
        market_evidence=os.environ.get("APEX_CFB_MARKET_EVIDENCE_FILE"),
        availability_receipt=os.environ.get("APEX_AVAILABILITY_RECEIPT"),
        execution_id=str(os.environ.get("APEX_EXECUTION_ID") or os.environ.get("APEX_CONTEST_ID") or field),
        board=str(out / "FINAL_BOARD.csv"), receipt=str(out / "SPORT_ENGINE_TERMINAL.json"), seed=field,
    )


if __name__ == "__main__":
    a = _args()
    _, payload = run(a.pool, a.field_size, a.role_evidence, a.market_evidence, a.board, a.receipt, a.seed, availability_receipt=a.availability_receipt, execution_id=a.execution_id)
    print(json.dumps(payload, default=str), flush=True)
