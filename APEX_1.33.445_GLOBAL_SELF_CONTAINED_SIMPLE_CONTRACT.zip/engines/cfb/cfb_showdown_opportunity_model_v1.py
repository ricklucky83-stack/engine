from __future__ import annotations
import math, numpy as np
from engines.common import apex_global_market_independent_regime_kernel_v1 as regime_kernel
PATCH_ID='CFB_SHOWDOWN_WORLD_CONDITIONED_OPPORTUNITY_REALLOCATION_v1'
PROFILE={
'lead_rb':.12,'trail_rb':.62,'blow_group_rb':.06,'rb_rot1':.35,'rb_rot2':.65,'rb_rot3':.90,
'trail_rec':.38,'lead_rec':.02,'blow_group_rec':.02,'rec_rot1':.06,'rec_rot2':.20,'rec_rot3':.85,
'trail_qb':.24,'blow_qb':.05,'backup_qb_blow':.40,
}
def _pct(a):
    a=np.asarray(a,float); o=np.argsort(a,kind='stable'); r=np.empty(len(a),float); r[o]=np.arange(len(a)); return r/max(1,len(a)-1)
def simulate(rt,cal,trials,seed,profile=None,return_regime=False):
    p=PROFILE if profile is None else profile
    mu=np.asarray(cal.mu,np.float32); sigma=np.asarray(cal.sigma,np.float32); pos=np.asarray(cal.pos,object); team=np.asarray(cal.team,object); role=np.asarray(cal.role_strength,np.float32)
    ri=rt._regime_inputs(cal.frame,mu,pos,team)
    reg=regime_kernel.simulate_football_regimes(teams=ri['teams'],model_points=ri['model_points'],trials=int(trials),seed=int(seed)^0x91A7CFB,market_total=ri.get('market_total'),market_spread_team0=ri.get('market_spread_team0'),market_prior_weight=0.25,sport='CFB',mode='SHOWDOWN')
    rng=np.random.default_rng(seed); teams=list(reg.teams); ti_map={t:i for i,t in enumerate(teams)}
    game=rng.standard_normal(trials).astype(np.float32); ind=rng.standard_normal((len(mu),trials)).astype(np.float32)
    pass_alloc={t:rng.standard_normal(trials).astype(np.float32) for t in teams}; rush_alloc={t:rng.standard_normal(trials).astype(np.float32) for t in teams}
    score_mean=np.maximum(np.mean(reg.scores,axis=1,keepdims=True),1.0); score_sd=np.maximum(np.std(reg.scores,axis=1,keepdims=True),3.0); score_z=((reg.scores-score_mean)/score_sd).astype(np.float32)
    pass_rank=np.full(len(mu),.5,np.float32); rush_rank=np.full(len(mu),.5,np.float32)
    for t in teams:
        rec=np.flatnonzero((team==t)&np.isin(pos,['WR','TE','UNK'])); rb=np.flatnonzero((team==t)&(pos=='RB'))
        if len(rec): pass_rank[rec]=_pct(role[rec]).astype(np.float32)
        if len(rb): rush_rank[rb]=_pct(role[rb]).astype(np.float32)
    raw_depth=cal.frame.get('DEPTH').astype(str)
    depth=np.array([float(x) if str(x).replace('.','',1).isdigit() else 8.0 for x in raw_depth],dtype=np.float32)
    missing=np.isin(cal.names,np.asarray(cal.missing_role_names,dtype=object))
    factor=np.ones((len(mu),trials),dtype=np.float32)
    for t in teams:
        ti=ti_map[t]; oi=1-ti; margin=(reg.scores[ti]-reg.scores[oi]).astype(np.float32)
        trail=np.clip((-margin-3.0)/21.0,0,1).astype(np.float32); lead=np.clip((margin-3.0)/21.0,0,1).astype(np.float32); blow=np.clip((margin-17.0)/17.0,0,1).astype(np.float32)
        ids=np.flatnonzero((team==t)&(pos=='RB')&(~missing))
        if len(ids):
            group=(1.0+p['lead_rb']*lead-p['trail_rb']*trail-p['blow_group_rb']*blow).astype(np.float32)
            alloc=np.ones((len(ids),trials),np.float32)
            for k,i in enumerate(ids):
                d=depth[i]
                if d<=1.25: alloc[k]=1.0-p['rb_rot1']*blow
                elif d<=2.25: alloc[k]=1.0+p['rb_rot2']*blow
                else: alloc[k]=1.0+p['rb_rot3']*blow
            w=mu[ids,None]; norm=(w*alloc).sum(axis=0)/max(float(mu[ids].sum()),1e-6); alloc/=np.maximum(norm[None,:],.25); factor[ids]=group[None,:]*alloc
        ids=np.flatnonzero((team==t)&np.isin(pos,['WR','TE'])&(~missing))
        if len(ids):
            group=(1.0+p['trail_rec']*trail+p['lead_rec']*lead-p['blow_group_rec']*blow).astype(np.float32)
            alloc=np.ones((len(ids),trials),np.float32)
            for k,i in enumerate(ids):
                d=depth[i]
                if d<=1.25: alloc[k]=1.0-p['rec_rot1']*blow
                elif d<=2.25: alloc[k]=1.0+p['rec_rot2']*blow
                else: alloc[k]=1.0+p['rec_rot3']*blow
            w=mu[ids,None]; norm=(w*alloc).sum(axis=0)/max(float(mu[ids].sum()),1e-6); alloc/=np.maximum(norm[None,:],.25); factor[ids]=group[None,:]*alloc
        ids=np.flatnonzero((team==t)&(pos=='QB')&(~missing))
        for i in ids:
            if depth[i]<=1.25: factor[i]=1.0+p['trail_qb']*trail-p['blow_qb']*blow
            else: factor[i]=1.0+p['backup_qb_blow']*blow
        ids=np.flatnonzero((team==t)&(pos=='K'))
        for i in ids: factor[i]=1.0+0.04*lead-0.08*trail
    factor=np.clip(factor,.35,1.75)
    out=np.empty_like(ind)
    for i,pp in enumerate(pos):
        ti=ti_map[str(team[i])]; oi=1-ti; team_score=score_z[ti]; opp_score=score_z[oi]; pass_script=reg.pass_script[ti]; rush_script=reg.rush_script[ti]; off=reg.offense_latent[ti]; deff=reg.defense_latent[oi]
        if pp=='QB': latent=.12*game+.34*team_score+.22*pass_script+.18*off-.08*deff+.04*opp_score; lv=.12**2+.34**2+.22**2+.18**2+.08**2+.04**2
        elif pp in {'WR','TE'}:
            alloc=.17*float(2*pass_rank[i]-1); latent=.10*game+.28*team_score+.30*pass_script+.17*off-.06*deff+.03*opp_score+alloc*pass_alloc[str(team[i])]; lv=.10**2+.28**2+.30**2+.17**2+.06**2+.03**2+alloc**2
        elif pp=='RB':
            alloc=.15*float(2*rush_rank[i]-1); latent=.10*game+.30*team_score+.27*rush_script+.17*off-.05*deff-.04*pass_script+alloc*rush_alloc[str(team[i])]; lv=.10**2+.30**2+.27**2+.17**2+.05**2+.04**2+alloc**2
        elif pp=='K': latent=.10*game+.27*team_score+.12*off-.04*deff; lv=.10**2+.27**2+.12**2+.04**2
        else:
            alloc=.12*float(2*pass_rank[i]-1); latent=.08*game+.24*team_score+.12*pass_script+.10*rush_script+.13*off-.05*deff+alloc*pass_alloc[str(team[i])]; lv=.08**2+.24**2+.12**2+.10**2+.13**2+.05**2+alloc**2
        iw=math.sqrt(max(.28,1-lv)); out[i]=np.maximum(0,mu[i]*factor[i]+sigma[i]*factor[i]*(iw*ind[i]+latent))
    receipt=dict(reg.receipt); receipt.update({'CFB_SHOWDOWN_OPPORTUNITY_PATCH_ID':PATCH_ID,'PLAYER_NAME_CONSTANTS_USED':False,'POSTLOCK_RESULTS_USED':False,'OPPORTUNITY_CONSERVED_WITHIN_RB_AND_RECEIVER_POOLS':True,'WORLD_CONDITIONED_ROLE_MEANS':True,'WORLD_CONDITIONED_ROLE_VARIANCE':True,'OPPORTUNITY_VARIANCE_ALPHA':1.0})
    return (out,receipt,factor) if return_regime else out
