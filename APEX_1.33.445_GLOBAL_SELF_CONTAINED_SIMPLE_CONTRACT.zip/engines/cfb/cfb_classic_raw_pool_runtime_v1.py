from __future__ import annotations

import argparse
import hashlib
import importlib.util
import itertools
import json
import math
import os
import pickle
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

_STATE_ROOT_FOR_IMPORTS = Path(__file__).resolve().parents[2]
if str(_STATE_ROOT_FOR_IMPORTS) not in sys.path:
    sys.path.insert(0, str(_STATE_ROOT_FOR_IMPORTS))

from engines.common.mandatory_prebuild_roster_gate_v1 import gate_receipt, require_prebuild_roster_check
from engines.cfb import cfb_classic_frozen_calibration_hybrid_selector_v1 as hybrid_selector
from engines.cfb import cfb_classic_two_game_script_posterior_order_v2 as two_game_order
from engines.common import right_neighborhood_door_selector_v1 as rn_door
from engines.common import apex_global_market_independent_regime_kernel_v1 as regime_kernel
from engines.common import apex_entry_limit_game_theory_v1 as entry_limit_game

ENGINE_ID = "APEX_CFB_CLASSIC_RAW_POOL_RUNTIME_v1"
SPORT = "CFB"
MODE = "CLASSIC"
DOCTRINE_ID = "CFB_CLASSIC_DRIVE_SCRIPT_AND_ROLE_CONCENTRATION_CALIBRATION_v2"
HANDOFF_PATCH_ID = "HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1"
ROSTER_LEGALITY_PATCH_ID = "CFB_CLASSIC_MIN_TWO_GAMES_ROSTER_LEGALITY_v1"
CFB_CLASSIC_PRE_PHASE2_LOCAL_DOOR_CLOSURE_PATCH_ID = "CFB_CLASSIC_PRE_PHASE2_LOCAL_DOOR_CLOSURE_v4"
CFB_CLASSIC_FAST_PATH_CALIBRATION_FIRST_PRE_PHASE2_PATCH_ID = "CFB_CLASSIC_FAST_PATH_CALIBRATION_FIRST_PRE_PHASE2_v1"
CFB_CLASSIC_PASS_EVENT_TAIL_MODEL_PATCH_ID = "CFB_CLASSIC_SHARED_PASS_EVENT_TAIL_MODEL_v2"
CFB_CLASSIC_FAMILY_FIRST_PORTFOLIO_PATCH_ID = "CFB_CLASSIC_FAMILY_FIRST_GAME_GEOMETRY_PORTFOLIO_v1"
CFB_CLASSIC_PRE_PHASE2_ONE_SWAP_CHAMPIONSHIP_CLOSURE_PATCH_ID = "CFB_CLASSIC_PRE_PHASE2_ONE_SWAP_CHAMPIONSHIP_CLOSURE_v1"
CFB_CLASSIC_STRICT_ELITE_SELECTOR_GATE_PATCH_ID = "CFB_CLASSIC_STRICT_ELITE_SELECTOR_GATE_v1"
CFB_CLASSIC_TWO_GAME_BALANCE_ESCAPE_RESERVE_PATCH_ID = "CFB_CLASSIC_TWO_GAME_BALANCE_ESCAPE_RESERVE_v1"
CFB_CLASSIC_GLOBAL_CORE_NATIVE_AUTHORITY_PARITY_PATCH_ID = "CFB_CLASSIC_GLOBAL_CORE_NATIVE_AUTHORITY_PARITY_v1"
CFB_CLASSIC_PREBIRTH_EXTERNAL_ROLE_AUTHORITY_PATCH_ID = "CFB_CLASSIC_PREBIRTH_EXTERNAL_ROLE_AUTHORITY_v1"
CFB_CLASSIC_ROLE_STATUS_ALIAS_NORMALIZATION_PATCH_ID = "CFB_CLASSIC_ROLE_STATUS_ALIAS_NORMALIZATION_v1"
CFB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_PATCH_ID = "CFB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_v1"
CFB_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_PATCH_ID = "CFB_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_v1"


class CFBClassicCandidateGenerationYield(BaseException):
    """Engine-owned cooperative yield inside the expensive candidate-birth statement."""
    APEX_CHUNK_STREAM_YIELD = True

    def __init__(self, *, checkpoint: str, progress: dict[str, Any]):
        super().__init__(CFB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_PATCH_ID)
        self.apex_chunk_stream_checkpoint = str(checkpoint)
        self.apex_chunk_stream_progress = dict(progress)
        self.apex_chunk_stream_patch_id = CFB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_PATCH_ID


def _resolve_native_portfolio_budget(field_size: int) -> tuple[int, dict[str, Any]]:
    """Resolve the playable CFB Classic portfolio size from the contest entry budget.

    MAX ENTRY / USER ENTRIES is a membership budget, not a presentation hint.
    The native selector must see the same budget that the global sealer enforces so
    no pre-seal 10-line compression can occur.
    """
    raw_max = os.environ.get("APEX_MAX_ENTRIES")
    raw_user = os.environ.get("APEX_USER_ENTRIES")
    if raw_max not in (None, ""):
        profile = entry_limit_game.build_entry_limit_profile(
            field_size=int(field_size), max_entries=raw_max, user_entries=raw_user
        )
        return int(profile.our_entry_budget), {
            "PATCH_ID": CFB_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_PATCH_ID,
            "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
            "CONTEST_MAX_ENTRIES": int(profile.contest_max_entries),
            "USER_ENTRY_BUDGET": int(profile.our_entry_budget),
            "REGIME": str(profile.regime),
            "SOURCE": "APEX_MAX_ENTRIES/APEX_USER_ENTRIES",
        }
    # Explicit config/test callers retain their supplied/default board_size. Live
    # production commands provide APEX_MAX_ENTRIES and therefore never take this path.
    return 10, {
        "PATCH_ID": CFB_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_PATCH_ID,
        "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
        "SOURCE": "LEGACY_EXPLICIT_CONFIG_OR_TEST_DEFAULT",
        "USER_ENTRY_BUDGET": 10,
    }


def _scaled_portfolio_caps(cfg: "Config", target: int) -> tuple[int, int, int]:
    """Preserve the original 10-seat exposure geometry at larger entry budgets."""
    target = max(1, int(target))
    base = max(1, int(cfg.board_size))
    # The historical defaults 7/3/4 represented 70%/30%/40% of a 10-line board.
    # Scale by target rather than leaving absolute caps that would silently force
    # relaxation on every large-max contest.
    player_ratio = float(cfg.player_exposure_cap) / float(base)
    qb_ratio = float(cfg.qb_exposure_cap) / float(base)
    family_ratio = float(cfg.family_exposure_cap) / float(base)
    return (
        max(1, int(math.ceil(player_ratio * target))),
        max(1, int(math.ceil(qb_ratio * target))),
        max(1, int(math.ceil(family_ratio * target))),
    )

MIN_GAMES = 2
SALARY_MAX = 50_000
SALARY_MIN = 48_000
ROSTER_SIZE = 8

ROOT = Path(__file__).resolve().parents[2]
_STRATEGY_PATH = ROOT / "engines" / "common" / "apex_global_sports_strategy_layer_v1.py"
_spec = importlib.util.spec_from_file_location("apex_global_sports_strategy_layer_v1_cfb_classic", _STRATEGY_PATH)
if _spec is None or _spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_SPORTS_STRATEGY_LAYER_UNAVAILABLE")
strategy_mod = importlib.util.module_from_spec(_spec)
sys.modules.setdefault(_spec.name, strategy_mod)
_spec.loader.exec_module(strategy_mod)


def _stable_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def _array_hash(a: np.ndarray) -> str:
    x = np.ascontiguousarray(a)
    return hashlib.sha256(x.view(np.uint8)).hexdigest()


def _pct(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    n = values.size
    if n == 0:
        return np.asarray([], dtype=np.float64)
    order = np.argsort(values, kind="stable")
    out = np.empty(n, dtype=np.float64)
    sorted_v = values[order]
    i = 0
    while i < n:
        j = i + 1
        while j < n and sorted_v[j] == sorted_v[i]:
            j += 1
        out[order[i:j]] = ((i + j - 1) / 2.0 + 0.5) / n
        i = j
    return out


def _wilson(success: np.ndarray, trials: np.ndarray | int, z: float = 1.96) -> tuple[np.ndarray, np.ndarray]:
    s = np.asarray(success, dtype=np.float64)
    n = np.asarray(trials, dtype=np.float64)
    p = np.divide(s, n, out=np.zeros_like(s), where=n > 0)
    den = 1.0 + z * z / n
    center = (p + z * z / (2.0 * n)) / den
    half = z * np.sqrt(np.maximum(0.0, p * (1.0 - p) / n + z * z / (4.0 * n * n))) / den
    return np.maximum(0.0, center - half), np.minimum(1.0, center + half)


def _pos_base(raw: str) -> str:
    return str(raw).split("/")[0].strip().upper()


def _game_key(team: str, opp: str) -> str:
    a, b = sorted((str(team).upper(), str(opp).upper()))
    return f"{a}@{b}"


@dataclass(frozen=True)
class Config:
    field_size: int
    seed: int
    player_trials: int = 50_000
    base_trials: int = 10_000
    extra_batch_trials: int = 10_000
    max_trials: int = 50_000
    phase2_keep: int = 20_000
    candidate_global_keep: int = 16_000
    family_keep: int = 180
    qb_family_keep: int = 180
    fill_beam_width: int = 20
    fill_pool_rb: int = 32
    fill_pool_wr: int = 48
    fill_pool_te: int = 32
    seed_pass_catchers: int = 5
    seed_rbs: int = 2
    seed_bringbacks: int = 3
    selector_primary_tie_width: float = 0.001
    bubble_cap: int = 96
    board_size: int = 10
    player_exposure_cap: int = 7
    qb_exposure_cap: int = 3
    family_exposure_cap: int = 4
    max_pairwise_overlap: int = 6
    fake_field_multiplier: float = 4.0
    local_door_core_floor: int = 24
    local_door_depth: int = 20
    family_first_min_field_size: int = 1000
    family_first_min_slate_games: int = 4
    one_swap_global_seed_keep: int = 128
    one_swap_family_seed_keep: int = 4
    one_swap_primary_qb_seed_keep: int = 4
    one_swap_seed_cap: int = 256
    one_swap_local_depth: int = 64
    two_game_balance_escape_seed_keep: int = 16
    two_game_balance_escape_slots: int = 2
    two_game_balance_escape_concentration_min: int = 6
    two_game_balance_escape_p95_floor: float = 0.95
    two_game_balance_escape_p99_floor: float = 0.90
    test_mode: bool = False

    def validate(self) -> None:
        if self.field_size <= 0:
            raise RuntimeError("RUN_INVALID:INVALID_FIELD_SIZE")
        if not self.test_mode and self.player_trials < 50_000:
            raise RuntimeError("ENGINE_INTEGRITY_HALT:PHASE1_MC_TRIALS_LT_50000")
        if not self.test_mode and self.base_trials < 10_000:
            raise RuntimeError("ENGINE_INTEGRITY_HALT:BASE_SIM_TRIALS_LT_10000")
        if self.max_trials < self.base_trials or self.extra_batch_trials <= 0:
            raise RuntimeError("RUN_INVALID:INVALID_ADAPTIVE_SIM_CONFIG")
        if self.phase2_keep <= 0 or self.board_size <= 0:
            raise RuntimeError("RUN_INVALID:INVALID_PORTFOLIO_CONFIG")


@dataclass
class Calibration:
    frame: pd.DataFrame
    ids: np.ndarray
    pos: np.ndarray
    team: np.ndarray
    opp: np.ndarray
    game: np.ndarray
    salary: np.ndarray
    role_snap: np.ndarray
    role_routes: np.ndarray
    role_targets: np.ndarray
    role_carries: np.ndarray
    role_uncertainty: np.ndarray
    strategy: Any
    mu: np.ndarray
    sigma: np.ndarray
    floor: np.ndarray
    p95: np.ndarray
    p99: np.ndarray
    ownership: np.ndarray
    correlation: np.ndarray
    covariance: np.ndarray
    phase1_hash: str
    shared_metric_bundle_id: str
    prediction_hash: str
    role_evidence_hash: str
    market_evidence_hash: str
    role_evidence_payload: dict[str, Any]
    market_evidence_payload: dict[str, Any]
    out_names: list[str]
    zero_role_names: list[str]
    player_sim_matrix_hash: str
    phase1_regime_receipt: dict[str, Any]


def _load_json(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        raise RuntimeError(f"RUN_INVALID:EVIDENCE_FILE_MISSING:{p}")
    return json.loads(p.read_text(encoding="utf-8"))


HARD_ROLE_STATUSES = {"OUT", "IR", "DNP", "REST", "CONFIRMED_OUT", "DOUBTFUL"}
UNRESOLVED_PRESEASON_STATUSES = {"QUESTIONABLE", "ACTIVE_UNCERTAIN", "UNKNOWN", "UNCONFIRMED"}
ROLE_STATUS_ALIASES = {
    "Q": "QUESTIONABLE", "QUE": "QUESTIONABLE", "QUES": "QUESTIONABLE",
    "QUESTION": "QUESTIONABLE", "QUESTIONABLE": "QUESTIONABLE",
    "D": "DOUBTFUL", "DBT": "DOUBTFUL", "DOUBT": "DOUBTFUL",
    "O": "OUT", "OUT": "OUT", "PROB": "ACTIVE", "PROBABLE": "ACTIVE",
}
SYNTHETIC_TEST_EVIDENCE_MODES = {"SYNTHETIC_TEST_ROLE_PRIORS", "TEST_SYNTHETIC_ROLE_PRIORS", "TEST_FIXTURE"}


def _normalize_role_status(value: Any, default: str = "UNCONFIRMED") -> str:
    raw = str(value if value not in (None, "") else default).strip().upper().replace("-", "_").replace(" ", "_")
    return ROLE_STATUS_ALIASES.get(raw, raw)


def _production_role_eligibility(name: str, pos: str, ev: dict[str, Any], evidence_mode: str) -> tuple[bool, str]:
    """Fail closed on unverified CFB role uncertainty in live production."""
    if evidence_mode in SYNTHETIC_TEST_EVIDENCE_MODES:
        return True, "SYNTHETIC_TEST_MODE"
    if not ev:
        return False, "ROLE_EVIDENCE_MISSING"
    source_ref = str(ev.get("source_ref") or "").strip()
    if not source_ref:
        return False, "ROLE_SOURCE_MISSING"
    st = _normalize_role_status(ev.get("status"), "UNCONFIRMED")
    if st in HARD_ROLE_STATUSES:
        return False, f"STATUS_{st}"
    if st in UNRESOLVED_PRESEASON_STATUSES:
        restored = ev.get("availability_confirmed") is True and ev.get("expected_meaningful_snaps") is True
        if not restored:
            return False, f"STATUS_{st}_UNRESOLVED"
    s = float(ev.get("snap_share", 0.0) or 0.0)
    r = float(ev.get("route_share", 0.0) or 0.0)
    t = float(ev.get("target_share", 0.0) or 0.0)
    c = float(ev.get("carry_share", 0.0) or 0.0)
    if pos == "QB":
        meaningful = s >= 0.20
    elif pos == "RB":
        meaningful = s >= 0.18 or c >= 0.12 or t >= 0.06
    elif pos in {"WR", "TE"}:
        meaningful = s >= 0.18 or r >= 0.15 or t >= 0.06
    else:
        meaningful = False
    if not meaningful:
        return False, "NO_MEANINGFUL_ROLE_EVIDENCE"
    return True, "VERIFIED_CURRENT_ROLE"

def _reconcile_role_evidence_with_availability(role_evidence: dict[str, Any], roster_gate: Any) -> dict[str, Any]:
    """Make the verified prebuild availability gate the hard OUT authority."""
    payload = json.loads(json.dumps(role_evidence))
    players = payload.get("players", {})
    if not isinstance(players, dict):
        raise RuntimeError("RUN_INVALID:ROLE_EVIDENCE_PLAYERS_INVALID")
    gate_out = set(roster_gate.out_players)
    released_stale_out: list[str] = []
    forced_out: list[str] = []
    for name, raw in list(players.items()):
        ev = raw if isinstance(raw, dict) else {}
        st = _normalize_role_status(ev.get("status"), "ACTIVE")
        if name in gate_out:
            ev["status"] = "OUT"
            ev["AVAILABILITY_RECONCILED"] = "CFB_PREBUILD_GATE_HARD_OUT"
            players[name] = ev
            forced_out.append(name)
        elif st in HARD_ROLE_STATUSES:
            ev["status"] = "ACTIVE_UNCERTAIN"
            ev["role_uncertainty"] = max(float(ev.get("role_uncertainty", 0.0) or 0.0), 0.70)
            ev["AVAILABILITY_RECONCILED"] = "STALE_OR_UNPROVEN_ROLE_OUT_RELEASED"
            players[name] = ev
            released_stale_out.append(name)
    for name in gate_out:
        if name not in players:
            players[name] = {
                "status": "OUT",
                "source_ref": "PREBUILD_AVAILABILITY_GATE",
                "AVAILABILITY_RECONCILED": "CFB_PREBUILD_GATE_HARD_OUT",
            }
            forced_out.append(name)
    payload["players"] = players
    payload["availability_reconciliation"] = {
        "CFB_GATE_ID": getattr(roster_gate, "gate_id", "APEX_UNIVERSAL_PREBUILD_AVAILABILITY_AND_LINEUP_GATE_v2"),
        "ROLE_EVIDENCE_RELEASED_STALE_OUT": sorted(released_stale_out),
        "ROLE_EVIDENCE_FORCED_OUT": sorted(set(forced_out)),
        "GATE_OUT_PLAYERS": sorted(gate_out),
        "POSTLOCK_RESULTS_USED": False,
        "PLAYER_NAME_FORWARD_LOGIC": False,
    }
    return payload


def _apply_external_role_authority_to_role_evidence(role_evidence: dict[str, Any], pool: str | Path) -> tuple[dict[str, Any], dict[str, Any]]:
    """Merge explicitly verified pregame position/depth authority before Phase 1.

    The runtime never searches for role data.  It accepts only an execution-layer
    injected JSON/file payload and only recovers source-missing players when the
    injected record carries a source reference plus explicit positive availability
    and meaningful-snap confirmation.  Role shares are borrowed conservatively
    from same-team/same-position peers already present in frozen role evidence.
    """
    raw = os.environ.get("APEX_CFB_ROLE_AUTHORITY_JSON", "").strip()
    fpath = os.environ.get("APEX_CFB_ROLE_AUTHORITY_FILE", "").strip()
    payload = None
    source = "NONE"
    if raw:
        source = "ENV_JSON"
        try:
            payload = json.loads(raw)
        except Exception as exc:
            raise RuntimeError(f"RUN_INVALID:CFB_ROLE_AUTHORITY_JSON_INVALID:{exc}") from exc
    elif fpath:
        source = "FILE"
        try:
            payload = json.loads(Path(fpath).read_text(encoding="utf-8"))
        except Exception as exc:
            raise RuntimeError(f"RUN_INVALID:CFB_ROLE_AUTHORITY_FILE_INVALID:{exc}") from exc
    base_receipt = {
        "PATCH_ID": CFB_CLASSIC_PREBIRTH_EXTERNAL_ROLE_AUTHORITY_PATCH_ID,
        "EXTERNAL_ROLE_AUTHORITY_STAGE": "PRE_PHASE1_CALIBRATION_BEFORE_CANDIDATE_BIRTH",
        "EXTERNAL_ROLE_AUTHORITY_SOURCE": source,
        "EXTERNAL_ROLE_AUTHORITY_APPLIED": False,
        "EXTERNAL_ROLE_RECOVERED_PLAYERS": [],
        "POSTLOCK_RESULTS_USED": False,
        "PLAYER_NAME_CONSTANTS_USED": False,
    }
    if not payload:
        out = json.loads(json.dumps(role_evidence))
        out["external_role_authority_reconciliation"] = base_receipt
        return out, base_receipt
    entries = payload.get("players", payload) if isinstance(payload, dict) else None
    if not isinstance(entries, dict):
        raise RuntimeError("RUN_INVALID:CFB_ROLE_AUTHORITY_PAYLOAD_NOT_OBJECT")
    out = json.loads(json.dumps(role_evidence))
    players = out.setdefault("players", {})
    if not isinstance(players, dict):
        raise RuntimeError("RUN_INVALID:ROLE_EVIDENCE_PLAYERS_INVALID")
    frame = pd.read_csv(pool, usecols=lambda c: c in {"PLAYER", "POS", "TEAM"})
    if not {"PLAYER", "POS", "TEAM"}.issubset(frame.columns):
        raise RuntimeError("RUN_INVALID:CFB_ROLE_AUTHORITY_POOL_IDENTITY_FIELDS_MISSING")
    frame = frame.copy()
    frame["PLAYER"] = frame["PLAYER"].astype(str)
    frame["TEAM"] = frame["TEAM"].astype(str).str.upper().str.strip()
    frame["POS_BASE"] = frame["POS"].map(_pos_base)
    by_name = {str(r["PLAYER"]): r for _, r in frame.iterrows()}

    def meaningful(ev: dict[str, Any]) -> bool:
        return max(float(ev.get("snap_share", 0.0) or 0.0), float(ev.get("route_share", 0.0) or 0.0),
                   float(ev.get("target_share", 0.0) or 0.0), float(ev.get("carry_share", 0.0) or 0.0)) > 0.0

    recovered: list[str] = []
    details: list[dict[str, Any]] = []
    for raw_name, rec in entries.items():
        name = str(raw_name)
        if name not in by_name or not isinstance(rec, dict):
            continue
        existing = players.get(name, {}) if isinstance(players.get(name, {}), dict) else {}
        existing_status = _normalize_role_status(existing.get("status"), "UNCONFIRMED")
        if existing_status in HARD_ROLE_STATUSES or meaningful(existing):
            continue
        pos = str(rec.get("position", "")).upper().strip()
        try:
            depth = float(rec.get("depth", 0.0))
        except Exception:
            continue
        source_ref = str(rec.get("source_ref") or "").strip()
        positive_availability = rec.get("availability_confirmed") is True and rec.get("expected_meaningful_snaps") is True
        pool_row = by_name[name]
        if pos not in {"QB", "RB", "WR", "TE"} or pos != str(pool_row["POS_BASE"]) or not math.isfinite(depth) or depth <= 0 or not source_ref or not positive_availability:
            continue
        team = str(pool_row["TEAM"])
        peer_evidence: list[dict[str, Any]] = []
        for peer_name, peer_raw in players.items():
            if peer_name == name or peer_name not in by_name or not isinstance(peer_raw, dict):
                continue
            pr = by_name[peer_name]
            if str(pr["TEAM"]) != team or str(pr["POS_BASE"]) != pos:
                continue
            if not str(peer_raw.get("source_ref") or "").strip() or not meaningful(peer_raw):
                continue
            pst = _normalize_role_status(peer_raw.get("status"), "UNCONFIRMED")
            if pst in HARD_ROLE_STATUSES or pst in UNRESOLVED_PRESEASON_STATUSES:
                continue
            peer_evidence.append(peer_raw)
        if not peer_evidence:
            continue
        q = 0.50 if depth <= 1.25 else (0.40 if depth <= 2.25 else 0.25)
        def qv(key: str) -> float:
            vals = np.asarray([float(e.get(key, 0.0) or 0.0) for e in peer_evidence], dtype=float)
            return float(np.quantile(vals, q)) if vals.size else 0.0
        unc_vals = np.asarray([float(e.get("role_uncertainty", 0.35) or 0.35) for e in peer_evidence], dtype=float)
        uncertainty_floor = 0.38 if depth <= 1.25 else (0.50 if depth <= 2.25 else 0.62)
        role_unc = min(0.90, max(uncertainty_floor, float(np.quantile(unc_vals, min(0.95, 1.0 - q))) if unc_vals.size else uncertainty_floor))
        recovered_ev = {
            **existing,
            "status": "ACTIVE",
            "source_ref": source_ref,
            "availability_confirmed": True,
            "expected_meaningful_snaps": True,
            "snap_share": qv("snap_share"),
            "route_share": qv("route_share"),
            "target_share": qv("target_share"),
            "carry_share": qv("carry_share"),
            "role_uncertainty": role_unc,
            "EXTERNAL_ROLE_AUTHORITY": True,
            "EXTERNAL_ROLE_AUTHORITY_DEPTH": depth,
            "EXTERNAL_ROLE_AUTHORITY_POSITION": pos,
        }
        if not meaningful(recovered_ev):
            continue
        players[name] = recovered_ev
        recovered.append(name)
        details.append({"PLAYER": name, "POSITION": pos, "DEPTH": depth, "PEER_COUNT": len(peer_evidence), "PRIOR_QUANTILE": q})
    receipt = {
        **base_receipt,
        "EXTERNAL_ROLE_AUTHORITY_APPLIED": bool(recovered),
        "EXTERNAL_ROLE_RECOVERED_PLAYERS": sorted(recovered),
        "EXTERNAL_ROLE_AUTHORITY_DETAILS": details,
    }
    out["players"] = players
    out["external_role_authority_reconciliation"] = receipt
    return out, receipt


def _default_role(pos: str) -> tuple[float, float, float, float, float]:
    # Broad priors are test-fixture only. Production requires player-specific evidence.
    if pos == "QB": return 0.86, 0.00, 0.00, 0.12, 0.30
    if pos == "RB": return 0.58, 0.18, 0.12, 0.38, 0.34
    if pos == "WR": return 0.67, 0.60, 0.25, 0.01, 0.36
    if pos == "TE": return 0.60, 0.48, 0.18, 0.01, 0.38
    return 0.0, 0.0, 0.0, 0.0, 0.90

def _prepare_frame(pool: str | Path, role_evidence: dict[str, Any], market_evidence: dict[str, Any]) -> tuple[pd.DataFrame, list[str], list[str]]:
    df = pd.read_csv(pool)
    required = {"PLAYER", "POS", "TEAM", "OPP", "SAL", "FPTS"}
    missing = sorted(required - set(df.columns))
    if missing:
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_POOL_FIELDS_MISSING:" + ",".join(missing))
    if df.empty or df["PLAYER"].astype(str).duplicated().any():
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_POOL_EMPTY_OR_DUPLICATE_PLAYER")
    df = df.copy()
    df["POS_BASE"] = df["POS"].map(_pos_base)
    df = df[df["POS_BASE"].isin(["QB", "RB", "WR", "TE"])].reset_index(drop=True)
    if df.empty:
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_NO_ELIGIBLE_POSITIONS")
    df["TEAM"] = df["TEAM"].astype(str).str.upper().str.strip()
    df["OPP"] = df["OPP"].astype(str).str.upper().str.strip()
    df["GAME_KEY"] = [_game_key(t, o) for t, o in zip(df["TEAM"], df["OPP"])]

    players = role_evidence.get("players", {})
    if not isinstance(players, dict):
        raise RuntimeError("RUN_INVALID:ROLE_EVIDENCE_PLAYERS_INVALID")
    evidence_mode = str(role_evidence.get("evidence_mode", "UNSPECIFIED")).upper()
    if evidence_mode in {"RAW_PROJECTION_ONLY", "AGGREGATE_PROJECTION_ONLY", "FPTS_ONLY"}:
        raise RuntimeError("RUN_INVALID:RAW_AGGREGATE_PROJECTION_PHASE1_PROHIBITED")
    production_mode = evidence_mode not in SYNTHETIC_TEST_EVIDENCE_MODES

    status, snap, routes, targets, carries, role_unc = [], [], [], [], [], []
    out_names, zero_role, role_gate_reason = [], [], []
    for _, row in df.iterrows():
        name = str(row["PLAYER"])
        pos = str(row["POS_BASE"])
        base = _default_role(pos)
        ev = players.get(name, {}) or {}
        raw_status = _normalize_role_status(ev.get("status"), "UNCONFIRMED" if production_mode else "ACTIVE")
        if raw_status in HARD_ROLE_STATUSES:
            st = raw_status
            s = r = t = c = 0.0
            u = 0.85
            reason = f"STATUS_{raw_status}"
            out_names.append(name)
        else:
            eligible, reason = _production_role_eligibility(name, pos, ev, evidence_mode)
            if production_mode and not eligible:
                st = "ROLE_UNVERIFIED"
                s = r = t = c = 0.0
                u = 0.90
            else:
                st = _normalize_role_status(ev.get("status"), "ACTIVE")
                if production_mode:
                    s = float(ev.get("snap_share", 0.0) or 0.0)
                    r = float(ev.get("route_share", 0.0) or 0.0)
                    t = float(ev.get("target_share", 0.0) or 0.0)
                    c = float(ev.get("carry_share", 0.0) or 0.0)
                    u = float(ev.get("role_uncertainty", 0.30) or 0.30)
                else:
                    s = float(ev.get("snap_share", base[0]))
                    r = float(ev.get("route_share", base[1]))
                    t = float(ev.get("target_share", base[2]))
                    c = float(ev.get("carry_share", base[3]))
                    u = float(ev.get("role_uncertainty", base[4]))
                if st == "EXPECTED_REST":
                    s *= 0.25; r *= 0.25; t *= 0.25; c *= 0.25; u = max(u, 0.60)
        role_gate_reason.append(reason)
        if max(s, r, t, c) <= 0.0:
            zero_role.append(name)
        status.append(st)
        snap.append(np.clip(s, 0.0, 1.0)); routes.append(np.clip(r, 0.0, 1.0))
        targets.append(max(0.0, t)); carries.append(max(0.0, c)); role_unc.append(np.clip(u, 0.02, 0.95))
    df["ROLE_STATUS"] = status
    df["SNAPS"] = np.asarray(snap) * 100.0
    df["ROUTES"] = np.asarray(routes) * 100.0
    df["TARGETS"] = np.asarray(targets) * 20.0
    df["CARRIES"] = np.asarray(carries) * 25.0
    df["ROLE_UNCERTAINTY"] = role_unc
    df["ROLE_GATE_REASON"] = role_gate_reason

    teams_ev = market_evidence.get("teams", {}) if isinstance(market_evidence, dict) else {}
    tm_score = df.get("TM Score", pd.Series(np.full(len(df), 27.0), index=df.index)).astype(float).to_numpy()
    ou = df.get("O/U", pd.Series(np.full(len(df), 54.0), index=df.index)).astype(float).to_numpy()
    if isinstance(teams_ev, dict):
        for i, team in enumerate(df["TEAM"].astype(str)):
            ev = teams_ev.get(team, {}) or {}
            if "implied_total" in ev: tm_score[i] = float(ev["implied_total"])
            if "game_total" in ev: ou[i] = float(ev["game_total"])
    df["TM Score"] = tm_score
    df["O/U"] = ou
    df["PROJECTION_MARKET_STATUS"] = "RAW_MODEL_WEAK_PRIOR"
    return df, sorted(set(out_names)), sorted(set(zero_role))

def _phase1_player_parameters(df: pd.DataFrame, strategy: Any) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    pos = df["POS_BASE"].astype(str).to_numpy(object)
    snap = df["SNAPS"].to_numpy(float) / 100.0
    route = df["ROUTES"].to_numpy(float) / 100.0
    target = df["TARGETS"].to_numpy(float) / 20.0
    carry = df["CARRIES"].to_numpy(float) / 25.0
    proj = np.maximum(0.0, df["FPTS"].to_numpy(float))
    team_total = df.get("TM Score", pd.Series(np.full(len(df), 27.0))).to_numpy(float)
    game_total = df.get("O/U", pd.Series(np.full(len(df), 54.0))).to_numpy(float)
    env = np.clip(0.55 * ((team_total - 14.0) / 28.0) + 0.45 * ((game_total - 38.0) / 32.0), 0.0, 1.0)
    opp_score = np.asarray(strategy.opportunity_score, dtype=float)
    predictive = np.asarray(strategy.predictive_features.dfs_upside_score, dtype=float)

    role_mu = np.zeros(len(df), dtype=np.float64)
    role_sigma_floor = np.zeros(len(df), dtype=np.float64)
    for p, base, sig in [("QB", 22.0, 8.0), ("RB", 13.0, 7.2), ("WR", 12.5, 7.6), ("TE", 9.5, 6.1)]:
        m = pos == p
        if p == "QB":
            cap = 0.86 * snap[m] + 0.14 * np.minimum(1.0, carry[m] * 2.4)
        elif p == "RB":
            cap = 0.40 * snap[m] + 0.45 * carry[m] + 0.15 * target[m]
        else:
            cap = 0.31 * snap[m] + 0.43 * route[m] + 0.26 * target[m]
        role_mu[m] = base * np.clip(cap, 0.0, 1.20)
        role_sigma_floor[m] = sig

    # Role/opportunity owns the baseline; raw projection is only a weak prior.
    role_blend = np.clip(0.76 + 0.07 * opp_score + 0.04 * predictive + 0.04 * env, 0.74, 0.91)
    mu = role_blend * role_mu + (1.0 - role_blend) * proj
    role_unc = df["ROLE_UNCERTAINTY"].to_numpy(float)
    # Ceiling/floor are outputs of Phase 1 Monte Carlo, never raw pool inputs.
    # Variance is driven by role shape, uncertainty, and the weak projection prior only.
    proj_gap = np.abs(proj - mu)
    sigma = np.maximum.reduce((
        role_sigma_floor * (0.52 + role_unc),
        np.maximum(1.4, mu * (0.43 + 0.42 * role_unc)),
        0.55 * proj_gap + 0.18 * np.maximum(mu, 1.0),
    ))
    # CFB tails are role-shape dependent. Rushing QBs and concentrated touch/target
    # players retain more championship-side variance than static position floors imply.
    qb_rush = np.clip(carry * 2.6, 0.0, 1.0)
    rb_conc = np.clip(0.70 * carry + 0.30 * target, 0.0, 1.0)
    rec_conc = np.clip(0.62 * target + 0.38 * route, 0.0, 1.0)
    sigma *= np.where(pos == "QB", 1.0 + 0.20 * qb_rush, 1.0)
    sigma *= np.where(pos == "RB", 1.0 + 0.10 * rb_conc, 1.0)
    sigma *= np.where(np.isin(pos, ["WR", "TE"]), 1.0 + 0.12 * rec_conc, 1.0)
    zero_role = (snap <= 0.0) & (route <= 0.0) & (target <= 0.0) & (carry <= 0.0)
    mu[zero_role] = 0.0
    sigma[zero_role] = 0.05
    return mu.astype(np.float32), sigma.astype(np.float32), role_mu.astype(np.float32)

def _load_cfb_event_tail_prior() -> dict[str, Any]:
    path = ROOT / "engines" / "cfb" / "cfb_classic_event_tail_prior_v1.json"
    if not path.exists():
        raise RuntimeError(f"RUN_INVALID:CFB_EVENT_TAIL_PRIOR_MISSING:{path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if str(payload.get("PATCH_ID")) != CFB_CLASSIC_PASS_EVENT_TAIL_MODEL_PATCH_ID:
        raise RuntimeError("RUN_INVALID:CFB_EVENT_TAIL_PRIOR_PATCH_ID_MISMATCH")
    return payload


def _apply_shared_pass_event_tail_v2(out: np.ndarray, cal_base: dict[str, Any], team_state: dict[str, dict[str, np.ndarray]], trials: int, seed: int) -> tuple[np.ndarray, dict[str, Any]]:
    """Add sparse shared QB/receiver championship-tail events using only prelock inputs.

    The same incremental pass-yard and pass-TD ledger is credited to the team QB and
    the selected receiver(s). Only one or two pass catchers receive each event, so
    the model does not mechanically lift an entire receiving corps. No player-name
    constants or postlock results are used.
    """
    prior = _load_cfb_event_tail_prior()
    mu = np.asarray(cal_base["mu"], dtype=np.float32)
    pos = np.asarray(cal_base["pos"], dtype=object)
    team = np.asarray(cal_base["team"], dtype=object)
    role_snap = np.asarray(cal_base.get("role_snap", np.ones(len(mu))), dtype=np.float32)
    role_routes = np.asarray(cal_base.get("role_routes", np.zeros(len(mu))), dtype=np.float32)
    role_targets = np.asarray(cal_base.get("role_targets", np.zeros(len(mu))), dtype=np.float32)
    rng = np.random.default_rng(int(seed) ^ 0xC0FB153)
    base_p = float(prior.get("BASE_EVENT_PROBABILITY", 0.028))
    pass_w = float(prior.get("PASS_SCRIPT_LOGIT_WEIGHT", 0.52))
    pace_w = float(prior.get("PACE_LOGIT_WEIGHT", 0.20))
    off_w = float(prior.get("OFFENSE_LOGIT_WEIGHT", 0.18))
    y_mean = float(prior.get("BONUS_PASS_YARDS_MEAN", 92.0))
    y_sd = float(prior.get("BONUS_PASS_YARDS_SD", 32.0))
    second_p = float(prior.get("SECOND_RECEIVER_PROBABILITY", 0.42))
    td2_p = float(prior.get("SECOND_PASS_TD_PROBABILITY", 0.30))
    min_weight = float(prior.get("MIN_RECEIVER_WEIGHT", 0.02))
    teams_activated = 0
    events_total = 0
    shared_yard_mismatch = 0
    shared_td_mismatch = 0
    for t in dict.fromkeys(team.tolist()):
        tidx = np.flatnonzero(team == t)
        qbs = tidx[pos[tidx] == "QB"]
        rec = tidx[np.isin(pos[tidx], ["WR", "TE"])]
        if len(qbs) == 0 or len(rec) == 0 or str(t) not in team_state:
            continue
        qscore = mu[qbs] * (0.70 + 0.30 * np.clip(role_snap[qbs], 0.0, 1.0))
        qb = int(qbs[int(np.argmax(qscore))])
        rec_weight = (0.56 * np.maximum(role_targets[rec], 0.0) + 0.24 * np.maximum(role_routes[rec], 0.0) + 0.20 * _pct(mu[rec]))
        rec_weight = np.maximum(rec_weight.astype(np.float64), min_weight)
        rec_weight /= rec_weight.sum()
        st = team_state[str(t)]
        latent = pass_w * np.asarray(st["pass"], dtype=np.float64) + pace_w * np.asarray(st["pace"], dtype=np.float64) + off_w * np.asarray(st["off"], dtype=np.float64)
        base_logit = math.log(max(1e-6, base_p) / max(1e-6, 1.0 - base_p))
        prob = 1.0 / (1.0 + np.exp(-(base_logit + latent)))
        event_mask = rng.random(trials) < np.clip(prob, 0.002, 0.18)
        ev = np.flatnonzero(event_mask)
        if not len(ev):
            continue
        teams_activated += 1
        events_total += int(len(ev))
        yards = np.maximum(25.0, rng.normal(y_mean + 10.0 * np.maximum(latent[ev], 0.0), y_sd, len(ev))).astype(np.float32)
        tds = np.ones(len(ev), dtype=np.int8) + (rng.random(len(ev)) < td2_p).astype(np.int8)
        primary = rng.choice(rec, size=len(ev), replace=True, p=rec_weight).astype(np.int32)
        use_second = (rng.random(len(ev)) < second_p) & (len(rec) > 1)
        second = np.full(len(ev), -1, dtype=np.int32)
        if len(rec) > 1 and np.any(use_second):
            for k in np.flatnonzero(use_second):
                pidx = int(primary[k])
                mask = rec != pidx
                opts = rec[mask]
                w = rec_weight[mask]
                w = w / w.sum()
                second[k] = int(rng.choice(opts, p=w))
        share1 = np.where(use_second, rng.uniform(0.58, 0.78, len(ev)), 1.0).astype(np.float32)
        y1 = yards * share1
        y2 = yards - y1
        td1 = np.where(use_second, 1, tds).astype(np.int8)
        td2 = tds - td1
        # Shared ledger: QB receives the exact incremental yards/TDs allocated to receivers.
        out[qb, ev] += yards / 25.0 + 4.0 * tds.astype(np.float32)
        for k, tr in enumerate(ev.tolist()):
            r1 = int(primary[k]); yy1 = float(y1[k]); tt1 = int(td1[k])
            rec1 = max(1.0, round(yy1 / 18.0))
            out[r1, tr] += yy1 / 10.0 + float(rec1) + 6.0 * tt1
            alloc_y = yy1; alloc_td = tt1
            if int(second[k]) >= 0 and y2[k] > 0.0:
                r2 = int(second[k]); yy2 = float(y2[k]); tt2 = int(td2[k])
                rec2 = max(1.0, round(yy2 / 18.0))
                out[r2, tr] += yy2 / 10.0 + float(rec2) + 6.0 * tt2
                alloc_y += yy2; alloc_td += tt2
            if abs(alloc_y - float(yards[k])) > 1e-3:
                shared_yard_mismatch += 1
            if alloc_td != int(tds[k]):
                shared_td_mismatch += 1
    receipt = {
        "PATCH_ID": CFB_CLASSIC_PASS_EVENT_TAIL_MODEL_PATCH_ID,
        "STATUS": str(prior.get("STATUS", "PROVISIONAL_EARLY_SEASON")),
        "TEAMS_WITH_EVENTS": int(teams_activated),
        "PASS_EVENTS": int(events_total),
        "TARGET_CONSERVATION": "PASS" if shared_yard_mismatch == 0 else "FAIL",
        "QB_WR_SHARED_YARD_LEDGER": "PASS" if shared_yard_mismatch == 0 else "FAIL",
        "QB_WR_SHARED_TD_LEDGER": "PASS" if shared_td_mismatch == 0 else "FAIL",
        "PLAYER_NAME_CONSTANTS": 0,
        "POSTLOCK_INPUTS": 0,
    }
    if shared_yard_mismatch or shared_td_mismatch:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_SHARED_PASS_EVENT_LEDGER_MISMATCH")
    return out, receipt


def _simulate_players(cal_base: dict[str, Any], trials: int, seed: int, *, return_regime: bool = False):
    """Drive-level multi-game CFB simulation with role concentration and script response.

    Market totals/spreads can initialize only a weak prior in the common football regime
    kernel. State transitions themselves are market-independent. Within a team, target
    and carry concentration introduce allocation competition so all WRs/RBs are not
    mechanically pushed in the same direction by one team latent.
    """
    mu = np.asarray(cal_base["mu"], dtype=np.float32)
    sigma = np.asarray(cal_base["sigma"], dtype=np.float32)
    pos = np.asarray(cal_base["pos"], dtype=object)
    team = np.asarray(cal_base["team"], dtype=object)
    opp = np.asarray(cal_base["opp"], dtype=object)
    game = np.asarray(cal_base["game"], dtype=object)
    role_snap = np.asarray(cal_base.get("role_snap", np.ones(len(mu))), dtype=np.float32)
    role_routes = np.asarray(cal_base.get("role_routes", np.zeros(len(mu))), dtype=np.float32)
    role_targets = np.asarray(cal_base.get("role_targets", np.zeros(len(mu))), dtype=np.float32)
    role_carries = np.asarray(cal_base.get("role_carries", np.zeros(len(mu))), dtype=np.float32)
    team_total = np.asarray(cal_base.get("team_total", np.full(len(mu), np.nan)), dtype=np.float64)
    game_total = np.asarray(cal_base.get("game_total", np.full(len(mu), np.nan)), dtype=np.float64)
    n = len(mu)
    rng = np.random.default_rng(seed)
    ind = rng.standard_normal((n, trials), dtype=np.float32)
    out = np.empty((n, trials), dtype=np.float32)

    team_state: dict[str, dict[str, np.ndarray]] = {}
    game_receipts: dict[str, Any] = {}
    for gi, g in enumerate(dict.fromkeys(game.tolist())):
        gidx = np.flatnonzero(game == g)
        teams = list(dict.fromkeys(team[gidx].tolist()))
        if len(teams) != 2:
            raise RuntimeError(f"RUN_INVALID:CFB_CLASSIC_GAME_EXPECTED_TWO_TEAMS:{g}:{teams}")
        strengths: list[float] = []
        for t in teams:
            tidx = np.flatnonzero(team == t)
            vals = np.sort(mu[tidx].astype(np.float64))[::-1]
            top = float(vals[: min(8, len(vals))].sum())
            qb = mu[tidx][pos[tidx] == "QB"]
            rb = mu[tidx][pos[tidx] == "RB"]
            top += 0.30 * (float(np.max(qb)) if len(qb) else 0.0)
            top += 0.12 * (float(np.max(rb)) if len(rb) else 0.0)
            strengths.append(top)
        total_model = float(np.clip(40.0 + 0.10 * sum(strengths), 38.0, 76.0))
        margin_model = float(np.clip(0.13 * (strengths[0] - strengths[1]), -16.0, 16.0))
        model_points = [max(10.0, 0.5 * (total_model + margin_model)), max(10.0, 0.5 * (total_model - margin_model))]

        gt = game_total[gidx]
        market_total = float(np.nanmedian(gt)) if np.any(np.isfinite(gt) & (gt > 0)) else None
        t0_vals = team_total[(team == teams[0]) & (game == g)]
        t1_vals = team_total[(team == teams[1]) & (game == g)]
        spread0 = None
        if np.any(np.isfinite(t0_vals)) and np.any(np.isfinite(t1_vals)):
            a = float(np.nanmedian(t0_vals)); b = float(np.nanmedian(t1_vals))
            if math.isfinite(a) and math.isfinite(b):
                spread0 = -(a - b)
        reg = regime_kernel.simulate_football_regimes(
            teams=teams, model_points=model_points, trials=int(trials), seed=int(seed) ^ (0xCFB10000 + gi * 104729),
            market_total=market_total, market_spread_team0=spread0, market_prior_weight=0.20, sport="CFB", mode="CLASSIC",
        )
        game_receipts[str(g)] = reg.receipt
        score_mean = np.maximum(np.mean(reg.scores, axis=1, keepdims=True), 1.0)
        score_sd = np.maximum(np.std(reg.scores, axis=1, keepdims=True), 3.0)
        score_z = ((reg.scores - score_mean) / score_sd).astype(np.float32)
        for ti, t in enumerate(teams):
            oi = 1 - ti
            margin = reg.scores[ti] - reg.scores[oi]
            blowout = (margin >= 21.0).astype(np.float32)
            blowout -= np.float32(blowout.mean())
            team_state[str(t)] = {
                "score": score_z[ti],
                "opp_score": score_z[oi],
                "pass": reg.pass_script[ti].astype(np.float32),
                "rush": reg.rush_script[ti].astype(np.float32),
                "pace": reg.pace_script.astype(np.float32),
                "off": reg.offense_latent[ti].astype(np.float32),
                "def_opp": reg.defense_latent[oi].astype(np.float32),
                "blowout": blowout,
                "pass_alloc": rng.standard_normal(trials, dtype=np.float32),
                "rush_alloc": rng.standard_normal(trials, dtype=np.float32),
            }

    # Within-team role percentiles drive signed allocation factors. This preserves
    # primary receiver/bellcow concentration while allowing sibling competition.
    pass_rank = np.full(n, 0.5, dtype=np.float32)
    rush_rank = np.full(n, 0.5, dtype=np.float32)
    for t in dict.fromkeys(team.tolist()):
        rec = np.flatnonzero((team == t) & np.isin(pos, ["WR", "TE"]))
        if len(rec):
            x = 0.65 * role_targets[rec] + 0.35 * role_routes[rec]
            pass_rank[rec] = _pct(x).astype(np.float32)
        rbs = np.flatnonzero((team == t) & (pos == "RB"))
        if len(rbs):
            x = 0.78 * role_carries[rbs] + 0.22 * role_targets[rbs]
            rush_rank[rbs] = _pct(x).astype(np.float32)

    for i in range(n):
        st = team_state[str(team[i])]
        p = str(pos[i])
        if p == "QB":
            rush_qb = float(np.clip(role_carries[i] * 2.6, 0.0, 1.0))
            pass_w = 0.27 * (1.0 - 0.40 * rush_qb)
            rush_w = 0.20 * rush_qb
            latent = 0.30*st["score"] + 0.12*st["pace"] + 0.18*st["off"] - 0.07*st["def_opp"] + pass_w*st["pass"] + rush_w*st["rush"] + 0.04*st["opp_score"]
            lv = .30**2 + .12**2 + .18**2 + .07**2 + pass_w**2 + rush_w**2 + .04**2
        elif p in {"WR", "TE"}:
            alloc = 0.18 * float(2.0 * pass_rank[i] - 1.0)
            latent = 0.28*st["score"] + 0.13*st["pace"] + 0.16*st["off"] - 0.05*st["def_opp"] + 0.31*st["pass"] + 0.04*st["opp_score"] + alloc*st["pass_alloc"]
            lv = .28**2 + .13**2 + .16**2 + .05**2 + .31**2 + .04**2 + alloc**2
        elif p == "RB":
            alloc = 0.16 * float(2.0 * rush_rank[i] - 1.0)
            latent = 0.29*st["score"] + 0.09*st["pace"] + 0.17*st["off"] - 0.05*st["def_opp"] + 0.29*st["rush"] - 0.05*st["pass"] + alloc*st["rush_alloc"]
            lv = .29**2 + .09**2 + .17**2 + .05**2 + .29**2 + .05**2 + alloc**2
        else:
            latent = 0.18*st["score"] + 0.08*st["pace"] + 0.10*st["off"]
            lv = .18**2 + .08**2 + .10**2
        # Leading by 21+ introduces mild starter opportunity decay without erasing
        # the scoring already produced to create the lead.
        latent = latent - (0.08 * float(np.clip(role_snap[i], 0.0, 1.0))) * st["blowout"]
        iw = math.sqrt(max(0.28, 1.0 - lv))
        out[i] = np.maximum(0.0, mu[i] + sigma[i] * (iw * ind[i] + latent))

    out, pass_event_receipt = _apply_shared_pass_event_tail_v2(out, cal_base, team_state, trials, seed)

    receipt = {
        "PATCH_ID": "CFB_CLASSIC_DRIVE_SCRIPT_AND_ROLE_CONCENTRATION_CALIBRATION_v2",
        "GLOBAL_REGIME_PATCH_ID": regime_kernel.PATCH_ID,
        "MARKET_PRIOR_MAX_WEIGHT_USED": 0.20,
        "MARKET_LINES_IN_STATE_TRANSITIONS": False,
        "GAME_COUNT": len(game_receipts),
        "GAME_RECEIPTS": game_receipts,
        "ROLE_CONCENTRATION_COMPETITION": True,
        "QB_RUSH_ARCHETYPE_TAIL": True,
        "BLOWOUT_STARTER_DECAY": True,
        "SHARED_PASS_EVENT_TAIL_MODEL": pass_event_receipt,
    }
    return (out, receipt) if return_regime else out

def _validate_classic_feasibility(df: pd.DataFrame) -> None:
    counts = df["POS_BASE"].value_counts().to_dict()
    req = {"QB": 1, "RB": 2, "WR": 3}
    missing = [p for p, n in req.items() if int(counts.get(p, 0)) < n]
    if missing:
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_POSITION_POOL_INFEASIBLE:" + ",".join(missing))
    if len(df) < ROSTER_SIZE or df["TEAM"].nunique() < 2:
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_ACTIVE_POOL_INFEASIBLE")
    # One additional FLEX and one SUPERFLEX must remain after QB/RB/RB/WR/WR/WR.
    if int(counts.get("QB", 0) + counts.get("RB", 0) + counts.get("WR", 0) + counts.get("TE", 0)) < 8:
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_FLEX_POOL_INFEASIBLE")

def _derive_native_ownership(mu: np.ndarray, p99: np.ndarray, salary: np.ndarray, role_snap: np.ndarray, role_routes: np.ndarray, role_targets: np.ndarray, role_carries: np.ndarray, pos: np.ndarray) -> np.ndarray:
    """Generate CFB Classic field ownership without provider RST%.

    Ownership is a contest-field model output. It uses simulated Phase-1 ceiling,
    role concentration, value, salary appeal, and position structure. It sums to
    the eight DraftKings Classic roster slots across the active player pool.
    """
    value = np.asarray(mu, dtype=np.float64) / np.maximum(1.0, np.asarray(salary, dtype=np.float64) / 1000.0)
    pos = np.asarray(pos, dtype=object)
    role_strength = np.where(
        pos == "QB",
        0.82 * role_snap + 0.18 * np.clip(role_carries * 2.6, 0.0, 1.0),
        np.where(
            pos == "RB",
            0.48 * role_carries + 0.32 * role_snap + 0.20 * role_targets,
            0.48 * role_targets + 0.32 * role_routes + 0.20 * role_snap,
        ),
    )
    appeal = (
        0.31 * _pct(np.asarray(mu, dtype=np.float64))
        + 0.30 * _pct(np.asarray(p99, dtype=np.float64))
        + 0.18 * _pct(value)
        + 0.16 * _pct(role_strength)
        + 0.05 * _pct(np.asarray(salary, dtype=np.float64))
    )
    pos_mult = np.where(pos == "QB", 0.84, np.where(pos == "RB", 1.04, np.where(pos == "WR", 1.06, 0.94)))
    w = np.exp(3.0 * (appeal - np.max(appeal))) * pos_mult
    own = np.maximum(w, 1e-12)
    own *= float(ROSTER_SIZE) / own.sum()
    own = np.clip(own, 0.0015, 0.78)
    own *= float(ROSTER_SIZE) / own.sum()
    return np.clip(own, 0.001, 0.82).astype(np.float32)


def _load_calibration(pool: str | Path, role_evidence_path: str | Path, market_evidence_path: str | Path | None, cfg: Config, roster_gate: Any | None = None) -> Calibration:
    role_ev = _load_json(role_evidence_path)
    if roster_gate is not None:
        role_ev = _reconcile_role_evidence_with_availability(role_ev, roster_gate)
    role_ev, _external_role_receipt = _apply_external_role_authority_to_role_evidence(role_ev, pool)
    market_ev = _load_json(market_evidence_path)
    df, out_names, zero_role = _prepare_frame(pool, role_ev, market_ev)
    active = ~df["ROLE_STATUS"].isin(["OUT", "IR", "DNP", "REST", "CONFIRMED_OUT", "DOUBTFUL", "ROLE_UNVERIFIED"])
    df = df.loc[active].reset_index(drop=True)
    _validate_classic_feasibility(df)
    if not np.all((df["SAL"].astype(int) > 0) & (df["SAL"].astype(int) <= SALARY_MAX)):
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_INVALID_SALARY")

    strategy = strategy_mod.build_strategy_features(df, sport=SPORT, mode=MODE)
    mu, sigma, _ = _phase1_player_parameters(df, strategy)
    ids = np.arange(len(df), dtype=np.int32)
    pos = df["POS_BASE"].astype(str).to_numpy(object)
    team = df["TEAM"].astype(str).to_numpy(object)
    opp = df["OPP"].astype(str).to_numpy(object)
    game = df["GAME_KEY"].astype(str).to_numpy(object)
    salary = df["SAL"].astype(int).to_numpy(np.int32)
    base = {
        "mu": mu, "sigma": sigma, "pos": pos, "team": team, "opp": opp, "game": game,
        "role_snap": df["SNAPS"].to_numpy(float) / 100.0, "role_routes": df["ROUTES"].to_numpy(float) / 100.0,
        "role_targets": df["TARGETS"].to_numpy(float) / 20.0, "role_carries": df["CARRIES"].to_numpy(float) / 25.0,
        "team_total": df["TM Score"].to_numpy(float), "game_total": df["O/U"].to_numpy(float),
    }
    sims, phase1_regime_receipt = _simulate_players(base, cfg.player_trials, cfg.seed ^ 0xC1A551C, return_regime=True)
    floor = np.quantile(sims, 0.05, axis=1).astype(np.float32)
    p95 = np.quantile(sims, 0.95, axis=1).astype(np.float32)
    p99 = np.quantile(sims, 0.99, axis=1).astype(np.float32)
    covariance = np.cov(sims.astype(np.float64)).astype(np.float32)
    std = np.sqrt(np.maximum(np.diag(covariance), 1e-8))
    correlation = covariance / np.maximum(np.outer(std, std), 1e-8)
    correlation = np.clip(correlation, -1.0, 1.0).astype(np.float32)
    own = _derive_native_ownership(
        mu, p99, salary,
        df["SNAPS"].to_numpy(float) / 100.0,
        df["ROUTES"].to_numpy(float) / 100.0,
        df["TARGETS"].to_numpy(float) / 20.0,
        df["CARRIES"].to_numpy(float) / 25.0,
        pos,
    )
    role_hash = _stable_hash(role_ev); market_hash = _stable_hash(market_ev)
    phase1_payload = {
        "ids": ids.tolist(), "mu": np.round(mu, 6).tolist(), "sigma": np.round(sigma, 6).tolist(),
        "floor_p05": np.round(floor, 6).tolist(), "p95": np.round(p95, 6).tolist(), "p99": np.round(p99, 6).tolist(),
        "ownership": np.round(own, 6).tolist(), "ownership_authority": "CFB_NATIVE_FIELD_MODEL",
        "role_evidence_hash": role_hash, "market_evidence_hash": market_hash,
        "prediction_hash": strategy.receipt["PREDICTION_HASH"], "player_trials": cfg.player_trials,
        "multi_game_latent_model": "CFB_DRIVE_SCRIPT_ROLE_CONCENTRATION_v2",
        "regime_receipt_hash": _stable_hash(phase1_regime_receipt),
    }
    phase1_hash = _stable_hash(phase1_payload)
    shared = {
        "PLAYER_ID_ORDER_HASH": _array_hash(ids),
        "CORRELATION_MATRIX_HASH": _array_hash(correlation),
        "COVARIANCE_MATRIX_HASH": _array_hash(covariance),
        "OWNERSHIP_VECTOR_HASH": _array_hash(own),
        "OWNERSHIP_AUTHORITY": "CFB_NATIVE_FIELD_MODEL",
        "FLOOR_VECTOR_HASH": _array_hash(floor),
        "CEILING_VECTOR_HASH": _array_hash(p99),
        "TAIL_DEFINITION_HASH": _stable_hash({"FLOOR_PERCENTILE": 5, "CEILING_PERCENTILES": [95, 99], "METHOD": "PHASE1_MC", "TRIALS": cfg.player_trials}),
        "STACK_FEATURES_HASH": _stable_hash({"CFB_CLASSIC": "DUAL_QB_PASS_CATCHER_BRINGBACK_DRIVE_SCRIPT_ROLE_CONCENTRATION"}),
        "METRIC_SCALING_HASH": _stable_hash({"TOP01": "RATE", "WIN": "RATE", "P95": "RAW", "P99": "RAW"}),
        "ROLE_STATUS_STATE_HASH": _stable_hash(df[["PLAYER", "ROLE_STATUS", "SNAPS", "ROUTES", "TARGETS", "CARRIES"]].to_dict("records")),
        "BASE_SIM_TRIALS_HASH": _stable_hash(cfg.base_trials),
    }
    shared_id = _stable_hash(shared)
    return Calibration(
        frame=df, ids=ids, pos=pos, team=team, opp=opp, game=game, salary=salary,
        role_snap=df["SNAPS"].to_numpy(float) / 100.0, role_routes=df["ROUTES"].to_numpy(float) / 100.0,
        role_targets=df["TARGETS"].to_numpy(float) / 20.0, role_carries=df["CARRIES"].to_numpy(float) / 25.0,
        role_uncertainty=df["ROLE_UNCERTAINTY"].to_numpy(float), strategy=strategy,
        mu=mu, sigma=sigma, floor=floor, p95=p95, p99=p99, ownership=own, correlation=correlation, covariance=covariance,
        phase1_hash=phase1_hash, shared_metric_bundle_id=shared_id, prediction_hash=strategy.receipt["PREDICTION_HASH"],
        role_evidence_hash=role_hash, market_evidence_hash=market_hash, role_evidence_payload=role_ev,
        market_evidence_payload=market_ev, out_names=out_names, zero_role_names=zero_role,
        player_sim_matrix_hash=_array_hash(sims), phase1_regime_receipt=phase1_regime_receipt,
    )


def _salary_combo_counts(values: Iterable[int], kmax: int) -> list[dict[int, int]]:
    dp: list[dict[int, int]] = [{0: 1}] + [dict() for _ in range(kmax)]
    for raw in values:
        sal = int(raw)
        for k in range(kmax, 0, -1):
            prev = list(dp[k - 1].items())
            cur = dp[k]
            for s, c in prev:
                ns = s + sal
                if ns <= SALARY_MAX:
                    cur[ns] = cur.get(ns, 0) + c
    return dp


def _convolve_counts(parts: list[dict[int, int]]) -> int:
    total = {0: 1}
    for part in parts:
        nxt: dict[int, int] = {}
        for a, ca in total.items():
            for b, cb in part.items():
                s = a + b
                if s <= SALARY_MAX:
                    nxt[s] = nxt.get(s, 0) + ca * cb
        total = nxt
    return int(sum(c for s, c in total.items() if SALARY_MIN <= s <= SALARY_MAX))


def _salary_legal_count_for_frame(df: pd.DataFrame) -> int:
    groups = {p: df.loc[df["POS_BASE"] == p, "SAL"].astype(int).tolist() for p in ["QB", "RB", "WR", "TE"]}
    dps = {p: _salary_combo_counts(v, 5) for p, v in groups.items()}
    patterns = [
        (2, 3, 3, 0), (2, 2, 4, 0), (2, 2, 3, 1),
        (1, 4, 3, 0), (1, 3, 4, 0), (1, 3, 3, 1),
        (1, 2, 5, 0), (1, 2, 4, 1), (1, 2, 3, 2),
    ]
    total = 0
    qb_rows = df.loc[df["POS_BASE"] == "QB", ["TEAM", "SAL"]].reset_index(drop=True)
    for qbc, rb, wr, te in patterns:
        if qbc == 1:
            total += _convolve_counts([dps["QB"][1], dps["RB"][rb], dps["WR"][wr], dps["TE"][te]])
        else:
            # S-FLEX quarterback may not be a second quarterback from the same team.
            for i in range(len(qb_rows)):
                for j in range(i + 1, len(qb_rows)):
                    if str(qb_rows.iloc[i]["TEAM"]) == str(qb_rows.iloc[j]["TEAM"]):
                        continue
                    qsal = int(qb_rows.iloc[i]["SAL"]) + int(qb_rows.iloc[j]["SAL"])
                    total += _convolve_counts([{qsal: 1}, dps["RB"][rb], dps["WR"][wr], dps["TE"][te]])
    return int(total)


def _legal_scan_count_for_frame(df: pd.DataFrame) -> int:
    total = _salary_legal_count_for_frame(df)
    # DraftKings CFB Classic requires every lineup to contain players from at least
    # two distinct games. Subtract every salary/position-legal lineup whose entire
    # roster is contained inside one GAME_KEY. Single-game sets are disjoint, so
    # this is an exact subtraction rather than an approximation.
    single_game = 0
    for _, sub in df.groupby("GAME_KEY"):
        single_game += _salary_legal_count_for_frame(sub)
    return int(max(0, total - single_game))

def _legal_scan_count(cal: Calibration) -> int:
    return _legal_scan_count_for_frame(cal.frame)


def _player_birth_score(cal: Calibration) -> np.ndarray:
    p99p = _pct(cal.p99); p95p = _pct(cal.p95)
    opp = np.asarray(cal.strategy.opportunity_score, dtype=float)
    lev = np.asarray(cal.strategy.strategic_leverage, dtype=float)
    role_cap = np.where(cal.pos == "QB", cal.role_snap,
                np.where(cal.pos == "RB", 0.45 * cal.role_snap + 0.40 * cal.role_carries + 0.15 * cal.role_targets,
                np.where(np.isin(cal.pos, ["WR", "TE"]), 0.35 * cal.role_snap + 0.40 * cal.role_routes + 0.25 * cal.role_targets, 1.0)))
    return (0.52 * p99p + 0.18 * p95p + 0.14 * opp + 0.08 * lev + 0.08 * role_cap).astype(np.float64)


def _top_position_pool(cal: Calibration, pos: str, score: np.ndarray, cap: int) -> np.ndarray:
    idx = np.flatnonzero(cal.pos == pos)
    if idx.size <= cap:
        return idx[np.argsort(score[idx], kind="stable")[::-1]]
    top = idx[np.argpartition(score[idx], -cap)[-cap:]]
    return top[np.argsort(score[top], kind="stable")[::-1]]


def _rank_team_pool(cal: Calibration, score: np.ndarray, team: str, positions: tuple[str, ...], keep: int) -> np.ndarray:
    idx = np.flatnonzero((cal.team == team) & np.isin(cal.pos, positions))
    if idx.size == 0: return np.asarray([], dtype=np.int32)
    order = idx[np.argsort(score[idx], kind="stable")[::-1]]
    return order[:keep].astype(np.int32)


FAMILY_CODES = {
    "DUAL_QB_DUAL_STACK": 1,
    "DUAL_QB_PRIMARY_BRING": 2,
    "DUAL_QB_DOUBLE_PASS": 3,
    "DUAL_QB_RUSH_STACK": 4,
    "SINGLE_QB_BELLCOW_SFLEX": 5,
    "SHOOTOUT_DUAL_QB_GAME_STACK": 6,
}


def _generate_seeds(cal: Calibration, score: np.ndarray, cfg: Config) -> list[tuple[int, tuple[int, ...]]]:
    seeds: list[tuple[int, tuple[int, ...]]] = []
    qbs = _top_position_pool(cal, "QB", score, max(64, int(np.count_nonzero(cal.pos == "QB"))))
    global_qbs = qbs[:min(len(qbs), 24)]
    for qb in qbs:
        t, o = str(cal.team[qb]), str(cal.opp[qb])
        pc = _rank_team_pool(cal, score, t, ("WR", "TE"), cfg.seed_pass_catchers)
        rb = _rank_team_pool(cal, score, t, ("RB",), cfg.seed_rbs)
        bring = _rank_team_pool(cal, score, o, ("RB", "WR", "TE"), cfg.seed_bringbacks)
        opp_pc = _rank_team_pool(cal, score, o, ("WR", "TE"), cfg.seed_pass_catchers)
        opp_qbs = _rank_team_pool(cal, score, o, ("QB",), 2)
        other_qbs = np.asarray([int(x) for x in global_qbs if str(cal.team[int(x)]) != t], dtype=np.int32)
        qb2_pool = np.unique(np.concatenate([opp_qbs, other_qbs[:12]])).astype(np.int32) if len(other_qbs) or len(opp_qbs) else np.asarray([], dtype=np.int32)

        for q2 in qb2_pool:
            if int(q2) == int(qb) or str(cal.team[q2]) == t:
                continue
            for p in pc[:2]:
                seeds.append((FAMILY_CODES["DUAL_QB_PRIMARY_BRING"], (int(qb), int(p), int(q2))))
            for p in pc[:2]:
                for p2 in _rank_team_pool(cal, score, str(cal.team[q2]), ("WR", "TE"), 2):
                    seeds.append((FAMILY_CODES["DUAL_QB_DUAL_STACK"], (int(qb), int(p), int(q2), int(p2))))
            for a, b in itertools.combinations(pc.tolist(), 2):
                seeds.append((FAMILY_CODES["DUAL_QB_DOUBLE_PASS"], (int(qb), int(a), int(b), int(q2))))
            for r in rb[:1]:
                seeds.append((FAMILY_CODES["DUAL_QB_RUSH_STACK"], (int(qb), int(r), int(q2))))
        for oq in opp_qbs:
            for p in pc[:2]:
                for op in opp_pc[:2]:
                    seeds.append((FAMILY_CODES["SHOOTOUT_DUAL_QB_GAME_STACK"], (int(qb), int(p), int(oq), int(op))))
        for p in pc[:2]:
            for r in rb[:2]:
                if bring.size:
                    for br in bring[:2]:
                        seeds.append((FAMILY_CODES["SINGLE_QB_BELLCOW_SFLEX"], (int(qb), int(p), int(r), int(br))))
                else:
                    seeds.append((FAMILY_CODES["SINGLE_QB_BELLCOW_SFLEX"], (int(qb), int(p), int(r))))
    seen = set()
    out: list[tuple[int, tuple[int, ...]]] = []
    for fam, seed in seeds:
        key = (fam, tuple(sorted(seed)))
        if key in seen:
            continue
        seen.add(key)
        out.append((fam, seed))
    return out

def _pair_increment(candidate: int, selected: tuple[int, ...], cal: Calibration) -> float:
    if not selected:
        return 0.0
    p, t, o = str(cal.pos[candidate]), str(cal.team[candidate]), str(cal.opp[candidate])
    inc = 0.0
    for j in selected:
        pj, tj, oj = str(cal.pos[j]), str(cal.team[j]), str(cal.opp[j])
        corr = float(cal.correlation[candidate, j])
        inc += 0.12 * max(-0.35, min(0.60, corr))
        if p == "QB" and pj == "QB":
            if t == tj:
                inc -= 1.50
            elif o == tj and oj == t:
                inc += 0.16
            elif str(cal.game[candidate]) == str(cal.game[j]):
                inc += 0.10
        if pj == "QB" and tj == t and p in {"WR", "TE"}:
            inc += 0.36
        if p == "QB" and t == tj and pj in {"WR", "TE"}:
            inc += 0.36
        if pj == "QB" and oj == t and p in {"RB", "WR", "TE"}:
            inc += 0.14
        if p == "QB" and o == tj and pj in {"RB", "WR", "TE"}:
            inc += 0.14
        if pj == "QB" and tj == t and p == "RB":
            inc += 0.05
        if p == "QB" and t == tj and pj == "RB":
            inc += 0.05
    return inc

def _pattern_counts(code: int) -> dict[str, int]:
    patterns = {
        0: {"QB": 2, "RB": 3, "WR": 3, "TE": 0},
        1: {"QB": 2, "RB": 2, "WR": 4, "TE": 0},
        2: {"QB": 2, "RB": 2, "WR": 3, "TE": 1},
        3: {"QB": 1, "RB": 4, "WR": 3, "TE": 0},
        4: {"QB": 1, "RB": 3, "WR": 4, "TE": 0},
        5: {"QB": 1, "RB": 3, "WR": 3, "TE": 1},
        6: {"QB": 1, "RB": 2, "WR": 5, "TE": 0},
        7: {"QB": 1, "RB": 2, "WR": 4, "TE": 1},
        8: {"QB": 1, "RB": 2, "WR": 3, "TE": 2},
    }
    if code not in patterns:
        raise RuntimeError(f"RUN_INVALID:CFB_CLASSIC_UNKNOWN_ROSTER_PATTERN:{code}")
    return patterns[code]

def _canonical_row(selected: tuple[int, ...], pattern: int, cal: Calibration) -> np.ndarray:
    by = {p: sorted([int(i) for i in selected if cal.pos[int(i)] == p]) for p in ["QB", "RB", "WR", "TE"]}
    if len(by["QB"]) not in {1, 2} or len(by["RB"]) < 2 or len(by["WR"]) < 3:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_CLASSIC_CANONICAL_ROSTER_FAILURE")
    row = [by["QB"][0], by["RB"][0], by["RB"][1], by["WR"][0], by["WR"][1], by["WR"][2]]
    used = set(row)
    extras = sorted([int(i) for i in selected if int(i) not in used and cal.pos[int(i)] != "QB"])
    if len(by["QB"]) == 2:
        if len(extras) != 1:
            raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_CLASSIC_DUAL_QB_FLEX_FAILURE")
        row.extend([extras[0], by["QB"][1]])
    else:
        if len(extras) != 2:
            raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_CLASSIC_SINGLE_QB_FLEX_FAILURE")
        row.extend(extras)
    return np.asarray(row, dtype=np.int32)

def _complete_seed(seed: tuple[int, ...], family: int, pattern: int, cal: Calibration, score: np.ndarray, pools: dict[str, np.ndarray], cfg: Config) -> list[np.ndarray]:
    target = _pattern_counts(pattern)
    counts = {p: sum(1 for i in seed if cal.pos[i] == p) for p in target}
    if any(counts[p] > target[p] for p in target):
        return []
    if len(set(seed)) != len(seed):
        return []
    states: list[tuple[tuple[int, ...], int, float]] = [(tuple(seed), int(cal.salary[list(seed)].sum()), float(score[list(seed)].sum()))]
    slots: list[str] = []
    for pos in ["QB", "TE", "RB", "WR"]:
        slots.extend([pos] * (target[pos] - counts[pos]))
    for pos in slots:
        expanded: dict[tuple[int, ...], tuple[int, float]] = {}
        for chosen, sal, val in states:
            chosen_set = set(chosen)
            for c in pools[pos]:
                ci = int(c)
                if ci in chosen_set:
                    continue
                nsal = sal + int(cal.salary[ci])
                if nsal > SALARY_MAX:
                    continue
                nchosen = tuple(sorted((*chosen, ci)))
                nval = val + float(score[ci]) + _pair_increment(ci, chosen, cal)
                prev = expanded.get(nchosen)
                if prev is None or nval > prev[1]:
                    expanded[nchosen] = (nsal, nval)
        if not expanded:
            return []
        states = sorted(((k, v[0], v[1]) for k, v in expanded.items()), key=lambda x: (-x[2], x[0]))[:cfg.fill_beam_width]
    out = []
    for chosen, sal, _ in states:
        if len(chosen) != ROSTER_SIZE or not (SALARY_MIN <= sal <= SALARY_MAX):
            continue
        if len({str(cal.team[i]) for i in chosen}) < 2:
            continue
        if len({str(cal.game[i]) for i in chosen}) < 2:
            continue
        out.append(_canonical_row(chosen, pattern, cal))
    return out

def _structural_lineup_features(rows: np.ndarray, cal: Calibration) -> dict[str, np.ndarray]:
    teams = cal.team[rows]
    pos = cal.pos[rows]
    n = len(rows)
    same_pass = np.zeros(n, dtype=np.int8)
    bring = np.zeros(n, dtype=np.int8)
    same_rb = np.zeros(n, dtype=np.int8)
    qb_count = (pos == "QB").sum(axis=1).astype(np.int8)
    dual_qb_same_game = np.zeros(n, dtype=np.int8)
    dual_qb_opponents = np.zeros(n, dtype=np.int8)
    same_team_dual_qb = np.zeros(n, dtype=np.int8)
    for i in range(n):
        qloc = np.flatnonzero(pos[i] == "QB")
        for qslot in qloc:
            qid = int(rows[i, qslot])
            qt, qo = str(cal.team[qid]), str(cal.opp[qid])
            same_pass[i] += int(np.count_nonzero((teams[i] == qt) & np.isin(pos[i], ["WR", "TE"])))
            bring[i] += int(np.count_nonzero((teams[i] == qo) & np.isin(pos[i], ["RB", "WR", "TE"])))
            same_rb[i] += int(np.count_nonzero((teams[i] == qt) & (pos[i] == "RB")))
        if len(qloc) == 2:
            qa, qb = int(rows[i, qloc[0]]), int(rows[i, qloc[1]])
            same_team_dual_qb[i] = int(str(cal.team[qa]) == str(cal.team[qb]))
            dual_qb_same_game[i] = int(str(cal.game[qa]) == str(cal.game[qb]))
            dual_qb_opponents[i] = int(str(cal.opp[qa]) == str(cal.team[qb]) and str(cal.opp[qb]) == str(cal.team[qa]))
    team_count = np.asarray([len(set(x.tolist())) for x in teams], dtype=np.int8)
    games = cal.game[rows]
    game_count = np.asarray([len(set(x.tolist())) for x in games], dtype=np.int8)
    family = (
        np.minimum(same_pass, 4).astype(np.int64) * 100000
        + np.minimum(bring, 4).astype(np.int64) * 10000
        + np.minimum(same_rb, 3).astype(np.int64) * 1000
        + qb_count.astype(np.int64) * 100
        + dual_qb_same_game.astype(np.int64) * 10
        + dual_qb_opponents.astype(np.int64)
    )
    macro = (qb_count.astype(np.int32) * 1000 + np.minimum(same_pass, 4).astype(np.int32) * 100 + np.minimum(bring, 4).astype(np.int32) * 10 + dual_qb_same_game.astype(np.int32))
    return {
        "same_pass": same_pass,
        "bringback": bring,
        "same_rb": same_rb,
        "qb_count": qb_count,
        "dual_qb_same_game": dual_qb_same_game,
        "dual_qb_opponents": dual_qb_opponents,
        "same_team_dual_qb": same_team_dual_qb,
        "team_count": team_count,
        "game_count": game_count,
        "family": family,
        "macro": macro,
    }

def _lineup_calibration_score(rows: np.ndarray, cal: Calibration) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    f = _structural_lineup_features(rows, cal)
    base = cal.p99[rows].sum(axis=1).astype(np.float64)
    p95 = cal.p95[rows].sum(axis=1).astype(np.float64)
    opportunity = np.asarray(cal.strategy.opportunity_score, dtype=float)
    leverage = np.asarray(cal.strategy.strategic_leverage, dtype=float)
    role = opportunity[rows].sum(axis=1)
    lev = leverage[rows].sum(axis=1)
    synergy = (
        2.4 * np.minimum(f["same_pass"], 3)
        + 1.1 * np.minimum(f["bringback"], 2)
        + 0.35 * np.minimum(f["same_rb"], 2)
        + 0.80 * f["dual_qb_same_game"]
        + 0.90 * f["dual_qb_opponents"]
        + 0.55 * (f["qb_count"] == 2)
        - 3.0 * f["same_team_dual_qb"]
    )
    cov_bonus = np.zeros(len(rows), dtype=np.float64)
    for k in range(rows.shape[1]):
        for j in range(k + 1, rows.shape[1]):
            cov_bonus += np.clip(cal.correlation[rows[:, k], rows[:, j]], -0.35, 0.60)
    score = base + 0.18 * p95 + 1.30 * role + 0.35 * lev + synergy + 0.28 * cov_bonus
    return score, f

def _build_calibration_qualified_birth_plan(cal: Calibration, cfg: Config) -> dict[str, Any]:
    """Freeze the Phase-1-qualified seed surface before expensive lineup completion.

    Qualification is multi-world and family-aware.  It is intentionally upstream of
    candidate completion so FAST_PATH never builds a broad raw seed lattice and then
    tries to prune it after the expensive work has already happened.
    """
    score = _player_birth_score(cal)
    pools = {
        "QB": _top_position_pool(cal, "QB", score, max(64, int(np.count_nonzero(cal.pos == "QB")))),
        "RB": _top_position_pool(cal, "RB", score, cfg.fill_pool_rb),
        "WR": _top_position_pool(cal, "WR", score, cfg.fill_pool_wr),
        "TE": _top_position_pool(cal, "TE", score, cfg.fill_pool_te),
    }
    for pos in ["RB", "WR", "TE"]:
        extra: list[int] = []
        for team in np.unique(cal.team):
            extra.extend(_rank_team_pool(cal, score, str(team), (pos,), 3).tolist())
        if extra:
            pools[pos] = np.unique(np.concatenate([pools[pos], np.asarray(extra, dtype=np.int32)])).astype(np.int32)
            pools[pos] = pools[pos][np.argsort(score[pools[pos]], kind="stable")[::-1]]

    # QB admission is role/calibration based: preserve each team's strongest Phase-1
    # QB plus any genuinely meaningful rotation QB.  Low-snap backup-only paths are
    # not qualified merely because they exist in the raw pool.
    qualified_qbs: set[int] = set()
    for team in np.unique(cal.team):
        q = np.flatnonzero((cal.team == team) & (cal.pos == "QB"))
        if len(q):
            qualified_qbs.add(int(q[np.argmax(score[q])]))
    for q in np.flatnonzero((cal.pos == "QB") & (cal.role_snap >= 0.75)):
        qualified_qbs.add(int(q))

    raw_seeds = _generate_seeds(cal, score, cfg)
    seeds: list[tuple[int, tuple[int, ...]]] = []
    for fam, seed in raw_seeds:
        qbs = [int(x) for x in seed if str(cal.pos[int(x)]) == "QB"]
        if qbs and all(q in qualified_qbs for q in qbs):
            seeds.append((fam, seed))
    if not seeds:
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_ZERO_CALIBRATION_QUALIFIED_SEEDS")

    opportunity = np.asarray(cal.strategy.opportunity_score, dtype=np.float64)
    leverage = np.asarray(cal.strategy.strategic_leverage, dtype=np.float64)
    feats = np.empty((len(seeds), 6), dtype=np.float64)
    for i, (_, seed) in enumerate(seeds):
        ids = np.asarray(seed, dtype=np.int32)
        corr = 0.0
        for a in range(len(ids)):
            for b in range(a + 1, len(ids)):
                corr += float(np.clip(cal.correlation[int(ids[a]), int(ids[b])], -0.35, 0.60))
        feats[i] = (
            float(cal.p99[ids].sum()), float(cal.p95[ids].sum()),
            float(opportunity[ids].sum()), float(leverage[ids].sum()),
            float(score[ids].sum()), corr,
        )
    pct_feats = np.column_stack([_pct(feats[:, j]) for j in range(feats.shape[1])])
    weights = np.asarray([
        [.34,.18,.16,.08,.18,.06],
        [.26,.24,.18,.08,.18,.06],
        [.30,.16,.20,.12,.16,.06],
        [.24,.18,.16,.16,.20,.06],
        [.28,.18,.14,.10,.18,.12],
    ], dtype=np.float64)
    world_scores = pct_feats @ weights.T

    family_groups: dict[int, list[int]] = {}
    qb_family_groups: dict[tuple[int, int], list[int]] = {}
    for i, (fam, seed) in enumerate(seeds):
        family_groups.setdefault(int(fam), []).append(i)
        for q in seed:
            if str(cal.pos[int(q)]) == "QB":
                qb_family_groups.setdefault((int(fam), int(q)), []).append(i)

    admitted: set[int] = set()
    family_receipt: dict[str, Any] = {}
    for fam, idxs in sorted(family_groups.items()):
        n = len(idxs)
        depth = min(n, max(24, int(math.ceil(math.sqrt(max(1, n)) * math.log(max(2, n)) * 0.65))))
        idxa = np.asarray(idxs, dtype=np.int32)
        ranks = np.empty((n, len(weights)), dtype=np.int32)
        for wi in range(len(weights)):
            order = np.argsort(world_scores[idxa, wi], kind="stable")[::-1]
            rr = np.empty(n, dtype=np.int32); rr[order] = np.arange(1, n + 1)
            ranks[:, wi] = rr
        recurrence = (ranks <= depth).sum(axis=1)
        avg_rank = ranks.mean(axis=1)
        peak = world_scores[idxa].max(axis=1)
        order = sorted(range(n), key=lambda j: (-int(recurrence[j]), float(avg_rank[j]), -float(peak[j]), int(idxa[j])))
        chosen = [idxs[j] for j in order if int(recurrence[j]) >= 2]
        if len(chosen) < depth:
            chosen = [idxs[j] for j in order[:depth]]
        admitted.update(chosen)
        family_receipt[str(fam)] = {"RAW_SEEDS": n, "WORLD_DEPTH": int(depth), "QUALIFIED_SEEDS": int(len(chosen))}

    # Do not erase a qualified QB/family route solely because the global family is deep.
    for _, idxs in sorted(qb_family_groups.items()):
        idxa = np.asarray(idxs, dtype=np.int32)
        agg = world_scores[idxa].mean(axis=1)
        k = min(len(idxs), 2)
        admitted.update(idxa[np.argsort(agg, kind="stable")[::-1][:k]].tolist())

    selected = [seeds[i] for i in sorted(admitted)]
    if not selected:
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_ZERO_CALIBRATION_QUALIFIED_SEEDS_AFTER_WORLD_GATE")
    receipt = {
        "GLOBAL_FAST_PATH_CALIBRATION_BIRTH_GATE_ID": "APEX_GLOBAL_FAST_PATH_CALIBRATION_QUALIFIED_BIRTH_HARD_GATE_v1",
        "PHASE1_MC_BEFORE_CANDIDATE_BIRTH": True,
        "CALIBRATION_QUALIFIED_BIRTH_PLAN": True,
        "RAW_SEEDS_VISIBILITY_ONLY": int(len(raw_seeds)),
        "ROLE_QUALIFIED_SEEDS": int(len(seeds)),
        "CALIBRATION_QUALIFIED_SEEDS": int(len(selected)),
        "QUALIFIED_QBS": int(len(qualified_qbs)),
        "UNQUALIFIED_CANDIDATE_BIRTHS": 0,
        "FULL_LEGAL_UNIVERSE_ENUMERATED": False,
        "PRE_PHASE2_RAW_LATTICE_MATERIALIZED": False,
        "WORLD_BLOCKS": int(len(weights)),
        "FAMILY_RECEIPT": family_receipt,
    }
    return {"score": score, "pools": pools, "seeds": selected, "receipt": receipt}


def _candidate_chunk_atomic_pickle(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as f:
        pickle.dump(obj, f, protocol=5)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def _candidate_chunk_identity(cal: Calibration, cfg: Config, seeds: list[tuple[int, tuple[int, ...]]]) -> dict[str, Any]:
    return {
        "PATCH_ID": CFB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_PATCH_ID,
        "EXECUTION_ID": str(os.environ.get("APEX_EXECUTION_ID") or "UNSET"),
        "STATE_VERSION": str(os.environ.get("APEX_GLOBAL_STATE_VERSION") or os.environ.get("APEX_RESUMABLE_STATE_VERSION") or "UNSPECIFIED"),
        "PHASE1_HASH": str(cal.phase1_hash),
        "ROLE_EVIDENCE_HASH": str(cal.role_evidence_hash),
        "MARKET_EVIDENCE_HASH": str(cal.market_evidence_hash),
        "FIELD_SIZE": int(cfg.field_size),
        "SEED": int(cfg.seed),
        "SEED_SURFACE_HASH": _stable_hash([(int(f), tuple(int(x) for x in seed)) for f, seed in seeds]),
    }


def _candidate_chunk_root() -> Path | None:
    raw = os.environ.get("APEX_RESUMABLE_RUN_ROOT")
    forced = str(os.environ.get("APEX_CFB_CLASSIC_FORCE_CANDIDATE_CHUNK_STREAM") or "").strip().lower() in {"1", "true", "yes", "on"}
    if not raw and not forced:
        return None
    base = Path(raw or os.environ.get("APEX_OUTPUT_DIR") or "/mnt/data")
    return base / "cfb_classic_candidate_generation_v1"


def _generate_candidates(cal: Calibration, cfg: Config, birth_plan: dict[str, Any] | None = None) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    if birth_plan is None:
        birth_plan = _build_calibration_qualified_birth_plan(cal, cfg)
    if not birth_plan or not bool((birth_plan.get("receipt") or {}).get("CALIBRATION_QUALIFIED_BIRTH_PLAN")):
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_CALIBRATION_QUALIFIED_BIRTH_PLAN_REQUIRED")
    score = np.asarray(birth_plan["score"], dtype=np.float64)
    pools = {k: np.asarray(v, dtype=np.int32) for k, v in dict(birth_plan["pools"]).items()}
    seeds = list(birth_plan["seeds"])

    # Production FAST_PATH candidate birth is itself chunked. The outer generic
    # statement controller can therefore safely re-enter this statement without
    # replaying completed seed/pattern work.
    chunk_root = _candidate_chunk_root()
    identity = _candidate_chunk_identity(cal, cfg, seeds)
    checkpoint_path = (chunk_root / "candidate_state.pkl") if chunk_root is not None else None
    unit_index = 0
    rows_parts: list[np.ndarray] = []
    seed_family: list[int] = []
    if checkpoint_path is not None and checkpoint_path.exists():
        try:
            with checkpoint_path.open("rb") as f:
                saved = pickle.load(f)
            if saved.get("IDENTITY") == identity:
                unit_index = int(saved.get("NEXT_UNIT_INDEX", 0))
                saved_rows = saved.get("ROWS")
                if isinstance(saved_rows, np.ndarray) and saved_rows.size:
                    rows_parts = [np.asarray(r, dtype=np.int32) for r in saved_rows]
                seed_family = [int(x) for x in np.asarray(saved.get("SEED_FAMILY", []), dtype=np.int16).tolist()]
                if bool(saved.get("COMPLETE")) and isinstance(saved_rows, np.ndarray) and saved_rows.size:
                    rows = np.asarray(saved_rows, dtype=np.int32)
                    seed_family_arr = np.asarray(seed_family, dtype=np.int16)
                    salary = cal.salary[rows].sum(axis=1)
                    feat = _structural_lineup_features(rows, cal)
                    keep = ((salary >= SALARY_MIN) & (salary <= SALARY_MAX) & (feat["team_count"] >= 2) & (feat["game_count"] >= MIN_GAMES))
                    rows = rows[keep]; seed_family_arr = seed_family_arr[keep]; salary = salary[keep]
                    if not len(rows):
                        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_ZERO_SALARY_LEGAL_CANDIDATES")
                    line_score, feat = _lineup_calibration_score(rows, cal)
                    return rows, {"score": line_score, "seed_family": seed_family_arr, "salary": salary.astype(np.int32), **feat}
            else:
                checkpoint_path.unlink(missing_ok=True)
        except CFBClassicCandidateGenerationYield:
            raise
        except Exception:
            checkpoint_path.unlink(missing_ok=True)
            unit_index = 0; rows_parts = []; seed_family = []

    total_units = len(seeds) * 9
    chunk_units = max(1, int(os.environ.get("APEX_CFB_CLASSIC_CANDIDATE_CHUNK_UNITS") or 24))
    completed_this_call = 0
    for flat in range(unit_index, total_units):
        seed_i, pat = divmod(flat, 9)
        fam, seed = seeds[seed_i]
        completed = _complete_seed(seed, fam, pat, cal, score, pools, cfg)
        if completed:
            rows_parts.extend(completed)
            seed_family.extend([fam] * len(completed))
        completed_this_call += 1
        next_unit = flat + 1
        if checkpoint_path is not None and (completed_this_call >= chunk_units or next_unit >= total_units):
            rows_snapshot = np.vstack(rows_parts).astype(np.int32) if rows_parts else np.empty((0, ROSTER_SIZE), dtype=np.int32)
            fam_snapshot = np.asarray(seed_family, dtype=np.int16)
            _candidate_chunk_atomic_pickle(checkpoint_path, {
                "PATCH_ID": CFB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_PATCH_ID,
                "IDENTITY": identity,
                "NEXT_UNIT_INDEX": int(next_unit),
                "TOTAL_UNITS": int(total_units),
                "ROWS": rows_snapshot,
                "SEED_FAMILY": fam_snapshot,
                "COMPLETE": bool(next_unit >= total_units),
            })
            if next_unit < total_units:
                raise CFBClassicCandidateGenerationYield(
                    checkpoint=str(checkpoint_path),
                    progress={
                        "NEXT_UNIT_INDEX": int(next_unit),
                        "TOTAL_UNITS": int(total_units),
                        "ROWS_BORN": int(len(rows_snapshot)),
                    },
                )
            completed_this_call = 0

    if not rows_parts:
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_ZERO_CALIBRATED_CANDIDATES")
    rows = np.vstack(rows_parts).astype(np.int32)
    seed_family_arr = np.asarray(seed_family, dtype=np.int16)
    _, first = np.unique(rows, axis=0, return_index=True)
    first = np.sort(first)
    rows = rows[first]
    seed_family_arr = seed_family_arr[first]
    salary = cal.salary[rows].sum(axis=1)
    feat = _structural_lineup_features(rows, cal)
    keep = (
        (salary >= SALARY_MIN) & (salary <= SALARY_MAX)
        & (feat["team_count"] >= 2)
        & (feat["game_count"] >= MIN_GAMES)
    )
    rows = rows[keep]; seed_family_arr = seed_family_arr[keep]; salary = salary[keep]
    if not len(rows):
        raise RuntimeError("RUN_INVALID:CFB_CLASSIC_ZERO_SALARY_LEGAL_CANDIDATES")
    line_score, feat = _lineup_calibration_score(rows, cal)
    if checkpoint_path is not None:
        _candidate_chunk_atomic_pickle(checkpoint_path, {
            "PATCH_ID": CFB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_PATCH_ID,
            "IDENTITY": identity, "NEXT_UNIT_INDEX": int(total_units), "TOTAL_UNITS": int(total_units),
            "ROWS": rows, "SEED_FAMILY": seed_family_arr, "COMPLETE": True,
        })
    return rows, {"score": line_score, "seed_family": seed_family_arr, "salary": salary.astype(np.int32), **feat}

def _five_man_passing_core(row: np.ndarray, cal: Calibration) -> tuple[int, ...]:
    ids = [int(x) for x in np.asarray(row, dtype=np.int32).tolist()]
    qbs = sorted([x for x in ids if str(cal.pos[x]) == "QB"])
    pcs = [x for x in ids if str(cal.pos[x]) in {"WR", "TE"}]
    pcs = sorted(pcs, key=lambda x: (float(cal.role_targets[x]), float(cal.p99[x]), float(cal.mu[x]), -int(cal.salary[x]), -x), reverse=True)
    need = max(0, 5 - len(qbs))
    core = qbs + pcs[:need]
    return tuple(sorted(core))


def _game_geometry(row: np.ndarray, cal: Calibration) -> str:
    vals = cal.game[np.asarray(row, dtype=np.int32)].tolist()
    counts: dict[str, int] = {}
    for g in vals:
        counts[str(g)] = counts.get(str(g), 0) + 1
    return "-".join(str(x) for x in sorted(counts.values(), reverse=True))


def _cross_world_core_order(candidate_rows: np.ndarray, cmeta: dict[str, Any], cal: Calibration, cfg: Config) -> tuple[list[tuple[int, ...]], dict[str, Any]]:
    if not len(candidate_rows):
        return [], {"CORE_COUNT": 0, "ADMITTED_CORES": 0}
    cores = [_five_man_passing_core(r, cal) for r in candidate_rows]
    groups: dict[tuple[int, ...], list[int]] = {}
    for i, k in enumerate(cores):
        groups.setdefault(k, []).append(i)
    mu = cal.mu[candidate_rows].sum(axis=1).astype(np.float64)
    p95 = cal.p95[candidate_rows].sum(axis=1).astype(np.float64)
    p99 = cal.p99[candidate_rows].sum(axis=1).astype(np.float64)
    opp = np.asarray(cal.strategy.opportunity_score, dtype=np.float64)[candidate_rows].sum(axis=1)
    lev = np.asarray(cal.strategy.strategic_leverage, dtype=np.float64)[candidate_rows].sum(axis=1)
    base = np.asarray(cmeta["score"], dtype=np.float64)
    feats = np.column_stack([_pct(mu), _pct(p95), _pct(p99), _pct(opp), _pct(lev), _pct(base)])
    weights = np.asarray([
        [.10,.14,.40,.14,.08,.14], [.14,.22,.28,.14,.10,.12], [.12,.12,.34,.20,.12,.10],
        [.18,.14,.26,.14,.16,.12], [.10,.18,.30,.18,.14,.10], [.16,.16,.28,.12,.10,.18], [.12,.14,.32,.16,.10,.16],
    ], dtype=np.float64)
    core_keys = list(groups)
    ranks = np.empty((len(weights), len(core_keys)), dtype=np.int32)
    best_scores = np.empty((len(weights), len(core_keys)), dtype=np.float64)
    for b, w in enumerate(weights):
        row_score = feats @ w
        vals = np.asarray([float(np.max(row_score[groups[k]])) + 0.002 * math.log1p(len(groups[k])) for k in core_keys])
        order = np.argsort(vals, kind="stable")[::-1]
        rr = np.empty(len(core_keys), dtype=np.int32); rr[order] = np.arange(1, len(core_keys)+1)
        ranks[b] = rr; best_scores[b] = vals
    ncore = len(core_keys)
    depth = min(ncore, max(int(cfg.local_door_core_floor), int(math.ceil(math.sqrt(max(1,ncore))*math.log(max(2,ncore))))))
    recurrence = (ranks <= depth).sum(axis=0)
    avg_rank = ranks.mean(axis=0)
    peak = best_scores.max(axis=0)
    order = sorted(range(ncore), key=lambda i: (-int(recurrence[i]), float(avg_rank[i]), -float(peak[i]), str(core_keys[i])))
    admitted = [core_keys[i] for i in order[:depth]]
    return admitted, {
        "PATCH_ID": CFB_CLASSIC_PRE_PHASE2_LOCAL_DOOR_CLOSURE_PATCH_ID,
        "WORLD_BLOCKS": int(len(weights)), "CORE_COUNT": int(ncore), "CORE_DEPTH": int(depth),
        "ADMITTED_CORES": int(len(admitted)), "RANKING": "CROSS_WORLD_RECURRENCE_AVG_RANK",
    }


def _rebuild_candidate_meta(rows: np.ndarray, cal: Calibration, native_rows: np.ndarray, native_meta: dict[str, Any]) -> dict[str, np.ndarray]:
    score, feat = _lineup_calibration_score(rows, cal)
    salary = cal.salary[rows].sum(axis=1).astype(np.int32)
    native_map = {tuple(map(int, r.tolist())): int(native_meta["seed_family"][i]) for i, r in enumerate(native_rows)}
    seed_family = np.asarray([native_map.get(tuple(map(int, r.tolist())), -1) for r in rows], dtype=np.int16)
    return {"score":score, "seed_family":seed_family, "salary":salary, **feat}



def _fast_path_calibration_first_pre_phase2_v1(candidate_rows: np.ndarray, cmeta: dict[str, Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, np.ndarray], dict[str, Any]]:
    """FAST_PATH authority: preserve native calibrated births; prohibit pre-Phase2 Cartesian closure."""
    return candidate_rows, cmeta, {
        "PATCH_ID": CFB_CLASSIC_FAST_PATH_CALIBRATION_FIRST_PRE_PHASE2_PATCH_ID,
        "CALIBRATION_FIRST_BIRTH_PRESERVED": True,
        "PRE_PHASE2_CARTESIAN_ENUMERATION": 0,
        "PRE_PHASE2_LOCAL_DOOR_CLOSURE_v4_EXECUTED": False,
        "NATIVE_CANDIDATES_DELETED": 0,
        "POSTLOCK_INPUTS": 0,
        "PLAYER_NAME_CONSTANTS": 0,
        "AUTHORITY": "APEX_FAST_PATH_ENGINE_EXECUTION_v2",
    }

def _pre_phase2_local_door_closure_v4(candidate_rows: np.ndarray, cmeta: dict[str, Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, np.ndarray], dict[str, Any]]:
    """Bounded pre-Phase2 local RB/WR/TE door closure around recurrent passing cores."""
    admitted, core_receipt = _cross_world_core_order(candidate_rows, cmeta, cal, cfg)
    if not admitted:
        return candidate_rows, cmeta, {**core_receipt, "ADDITIVE_ROWS": 0, "LOCAL_DEPTH": int(cfg.local_door_depth)}
    player_score = _player_birth_score(cal)
    pools: dict[str, np.ndarray] = {}
    for p in ["QB","RB","WR","TE"]:
        idx = np.flatnonzero(cal.pos == p)
        pools[p] = idx[np.argsort(player_score[idx], kind="stable")[::-1]].astype(np.int32)
    native_by_core: dict[tuple[int,...], list[int]] = {}
    for i, r in enumerate(candidate_rows):
        native_by_core.setdefault(_five_man_passing_core(r, cal), []).append(i)
    additive: list[np.ndarray] = []
    scanned = 0
    depth = max(1, int(cfg.local_door_depth))
    for core in admitted:
        idxs = native_by_core.get(core, [])
        if not idxs:
            continue
        core_set = set(core)
        patterns = sorted(set(tuple(int(np.count_nonzero(cal.pos[candidate_rows[i]] == p)) for p in ["QB","RB","WR","TE"]) for i in idxs))
        local_rows: list[np.ndarray] = []
        for pat_counts in patterns:
            target = dict(zip(["QB","RB","WR","TE"], pat_counts))
            have = {p: sum(1 for x in core if str(cal.pos[x]) == p) for p in target}
            need = {p: target[p]-have[p] for p in target}
            if any(v < 0 for v in need.values()) or sum(need.values()) != ROSTER_SIZE-len(core):
                continue
            combo_lists: list[list[tuple[int,...]]] = []
            for p in ["QB","RB","WR","TE"]:
                k = need[p]
                if k == 0:
                    combo_lists.append([tuple()]); continue
                # Preserve enough local doors to avoid the old beam trap; active CFB pools are small enough for bounded all-position enumeration.
                cap = 14 if p == "QB" else (22 if p == "RB" else 28)
                cand = [int(x) for x in pools[p][:cap] if int(x) not in core_set]
                combo_lists.append(list(itertools.combinations(cand, k)))
            for qx, rx, wx, tx in itertools.product(*combo_lists):
                chosen = tuple(sorted((*core, *qx, *rx, *wx, *tx)))
                if len(chosen) != ROSTER_SIZE or len(set(chosen)) != ROSTER_SIZE:
                    continue
                scanned += 1
                sal = int(cal.salary[list(chosen)].sum())
                if not (SALARY_MIN <= sal <= SALARY_MAX):
                    continue
                if len(set(cal.team[list(chosen)].tolist())) < 2 or len(set(cal.game[list(chosen)].tolist())) < MIN_GAMES:
                    continue
                qids = [x for x in chosen if str(cal.pos[x]) == "QB"]
                if len(qids) == 2 and str(cal.team[qids[0]]) == str(cal.team[qids[1]]):
                    continue
                try:
                    row = _canonical_row(chosen, 0, cal)
                except RuntimeError:
                    continue
                local_rows.append(row)
        if not local_rows:
            continue
        arr = np.unique(np.vstack(local_rows).astype(np.int32), axis=0)
        lscore, _ = _lineup_calibration_score(arr, cal)
        sal = cal.salary[arr].sum(axis=1)
        mean = cal.mu[arr].sum(axis=1)
        p99 = cal.p99[arr].sum(axis=1)
        order = sorted(range(len(arr)), key=lambda i:(int(sal[i]), float(mean[i]), float(p99[i]), float(lscore[i]), -i), reverse=True)[:depth]
        additive.extend(arr[order])
    if not additive:
        return candidate_rows, cmeta, {**core_receipt, "ADDITIVE_ROWS": 0, "LOCAL_DEPTH": depth, "LEGAL_LOCAL_DOORS_SCANNED": int(scanned)}
    union = np.unique(np.vstack([candidate_rows, np.vstack(additive)]).astype(np.int32), axis=0)
    meta = _rebuild_candidate_meta(union, cal, candidate_rows, cmeta)
    native_set = {tuple(map(int,r.tolist())) for r in candidate_rows}
    added = sum(tuple(map(int,r.tolist())) not in native_set for r in union)
    receipt = {**core_receipt, "LOCAL_DEPTH": depth, "LEGAL_LOCAL_DOORS_SCANNED": int(scanned), "ADDITIVE_ROWS": int(added), "TOTAL_CANDIDATES": int(len(union)), "NATIVE_CANDIDATES_DELETED": 0, "PLAYER_NAME_CONSTANTS": 0, "POSTLOCK_INPUTS": 0}
    return union, meta, receipt


def _top_group_seed_indices(group: np.ndarray, score: np.ndarray, keep: int) -> np.ndarray:
    chosen: list[np.ndarray] = []
    for g in np.unique(group):
        idx = np.flatnonzero(group == g)
        if idx.size <= int(keep):
            chosen.append(idx)
        else:
            order = idx[np.argsort(score[idx], kind="stable")[::-1][:int(keep)]]
            chosen.append(order)
    return np.unique(np.concatenate(chosen)).astype(np.int32) if chosen else np.asarray([], dtype=np.int32)


def _pre_phase2_one_swap_championship_closure_v1(
    candidate_rows: np.ndarray,
    cmeta: dict[str, Any],
    cal: Calibration,
    cfg: Config,
) -> tuple[np.ndarray, dict[str, np.ndarray], dict[str, Any]]:
    """Prelock-only bounded one-swap closure around the strongest calibrated doors.

    This is a recall layer only. It does not use contest results, player-name rules, or
    selector/terminal metrics. Every admitted sibling is re-scored by the same frozen
    Phase-1 calibration inputs before Phase 2.
    """
    n = int(len(candidate_rows))
    if n == 0:
        return candidate_rows, cmeta, {
            "PATCH_ID": CFB_CLASSIC_PRE_PHASE2_ONE_SWAP_CHAMPIONSHIP_CLOSURE_PATCH_ID,
            "SEED_ROWS": 0, "ADDITIVE_ROWS": 0, "LEGAL_ONE_SWAP_ROWS_SCANNED": 0,
            "POSTLOCK_INPUTS": 0, "PLAYER_NAME_CONSTANTS": 0,
        }
    score = np.asarray(cmeta["score"], dtype=np.float64)
    global_keep = min(n, max(1, int(cfg.one_swap_global_seed_keep)))
    global_seeds = np.argsort(score, kind="stable")[::-1][:global_keep].astype(np.int32)
    family_seeds = _top_group_seed_indices(np.asarray(cmeta["family"]), score, max(1, int(cfg.one_swap_family_seed_keep)))
    primary_qb_seeds = _top_group_seed_indices(candidate_rows[:, 0], score, max(1, int(cfg.one_swap_primary_qb_seed_keep)))
    seeds = np.unique(np.concatenate([global_seeds, family_seeds, primary_qb_seeds])).astype(np.int32)
    seeds = seeds[np.argsort(score[seeds], kind="stable")[::-1]]
    seeds = seeds[:max(1, int(cfg.one_swap_seed_cap))]

    additive: list[np.ndarray] = []
    scanned = 0
    depth = max(1, int(cfg.one_swap_local_depth))
    for seed_i in seeds.tolist():
        seed = candidate_rows[int(seed_i)]
        seed_set = set(int(x) for x in seed.tolist())
        local_rows: list[np.ndarray] = []
        for outgoing in seed.tolist():
            base = seed_set - {int(outgoing)}
            for incoming in range(len(cal.frame)):
                if int(incoming) in base:
                    continue
                chosen = tuple(sorted((*base, int(incoming))))
                if len(chosen) != ROSTER_SIZE or len(set(chosen)) != ROSTER_SIZE:
                    continue
                scanned += 1
                sal = int(cal.salary[list(chosen)].sum())
                if not (SALARY_MIN <= sal <= SALARY_MAX):
                    continue
                if len(set(cal.team[list(chosen)].tolist())) < 2 or len(set(cal.game[list(chosen)].tolist())) < MIN_GAMES:
                    continue
                qids = [x for x in chosen if str(cal.pos[x]) == "QB"]
                if len(qids) == 2 and str(cal.team[qids[0]]) == str(cal.team[qids[1]]):
                    continue
                try:
                    row = _canonical_row(chosen, 0, cal)
                except RuntimeError:
                    continue
                local_rows.append(row)
        if not local_rows:
            continue
        arr = np.unique(np.vstack(local_rows).astype(np.int32), axis=0)
        lscore, _ = _lineup_calibration_score(arr, cal)
        sal = cal.salary[arr].sum(axis=1)
        mean = cal.mu[arr].sum(axis=1)
        p99 = cal.p99[arr].sum(axis=1)
        order = sorted(
            range(len(arr)),
            key=lambda i: (int(sal[i]), float(mean[i]), float(p99[i]), float(lscore[i]), -i),
            reverse=True,
        )[:depth]
        additive.extend(arr[order])

    if not additive:
        return candidate_rows, cmeta, {
            "PATCH_ID": CFB_CLASSIC_PRE_PHASE2_ONE_SWAP_CHAMPIONSHIP_CLOSURE_PATCH_ID,
            "SEED_ROWS": int(len(seeds)), "GLOBAL_SEED_KEEP": int(global_keep),
            "LOCAL_DEPTH": int(depth), "LEGAL_ONE_SWAP_ROWS_SCANNED": int(scanned),
            "ADDITIVE_ROWS": 0, "TOTAL_CANDIDATES": int(n), "NATIVE_CANDIDATES_DELETED": 0,
            "POSTLOCK_INPUTS": 0, "PLAYER_NAME_CONSTANTS": 0,
        }
    union = np.unique(np.vstack([candidate_rows, np.vstack(additive)]).astype(np.int32), axis=0)
    meta = _rebuild_candidate_meta(union, cal, candidate_rows, cmeta)
    native_set = {tuple(map(int, r.tolist())) for r in candidate_rows}
    added = sum(tuple(map(int, r.tolist())) not in native_set for r in union)
    return union, meta, {
        "PATCH_ID": CFB_CLASSIC_PRE_PHASE2_ONE_SWAP_CHAMPIONSHIP_CLOSURE_PATCH_ID,
        "SEED_ROWS": int(len(seeds)), "GLOBAL_SEED_KEEP": int(global_keep),
        "FAMILY_SEED_KEEP": int(cfg.one_swap_family_seed_keep),
        "PRIMARY_QB_SEED_KEEP": int(cfg.one_swap_primary_qb_seed_keep),
        "SEED_CAP": int(cfg.one_swap_seed_cap), "LOCAL_DEPTH": int(depth),
        "LEGAL_ONE_SWAP_ROWS_SCANNED": int(scanned), "ADDITIVE_ROWS": int(added),
        "TOTAL_CANDIDATES": int(len(union)), "NATIVE_CANDIDATES_DELETED": 0,
        "POSTLOCK_INPUTS": 0, "PLAYER_NAME_CONSTANTS": 0,
        "SELECTION_AUTHORITY": False, "RECALL_LAYER": True,
    }


CFB_CLASSIC_SECONDARY_ROLE_SIGNATURE_ADAPTIVE_RESERVE_PATCH_ID = "CFB_CLASSIC_SECONDARY_ROLE_SIGNATURE_ADAPTIVE_RESERVE_v3"

def _secondary_role_signature_adaptive_reserve(candidate_rows: np.ndarray, cmeta: dict[str, Any], cal: Calibration) -> tuple[np.ndarray, dict[str, Any]]:
    """Prelock-only cross-family reserve. No postlock/result inputs or player-name constants."""
    n = len(candidate_rows)
    if n == 0:
        return np.asarray([], dtype=np.int32), {"PATCH_ID": CFB_CLASSIC_SECONDARY_ROLE_SIGNATURE_ADAPTIVE_RESERVE_PATCH_ID, "RESERVED": 0}
    score = np.asarray(cmeta["score"], dtype=float)
    # Core = sorted QB pair/singleton + primary WR/TE by role target evidence.
    core_groups: dict[tuple[Any, ...], list[int]] = {}
    sig_by_idx: dict[int, tuple[Any, ...]] = {}
    for i, row in enumerate(candidate_rows):
        qbs = [int(x) for x in row if str(cal.pos[int(x)]) == "QB"]
        qkey = tuple(sorted(qbs))
        pcs = [int(x) for x in row if str(cal.pos[int(x)]) in {"WR","TE"}]
        pcs_sorted = sorted(pcs, key=lambda x: (float(cal.role_targets[x]), float(cal.p99[x]), -int(cal.salary[x]), -x), reverse=True)
        primary = pcs_sorted[0] if pcs_sorted else -1
        core=(qkey, primary)
        core_groups.setdefault(core, []).append(i)
        sec=[]
        for x in pcs_sorted[1:]:
            sal=int(cal.salary[x]); tgt=float(cal.role_targets[x])
            sb='L' if sal < 4500 else ('M' if sal < 6000 else 'H')
            tb='L' if tgt < .15 else ('M' if tgt < .25 else 'H')
            sec.append((str(cal.team[x]), sb, tb))
        sig_by_idx[i]=tuple(sorted(sec))
    # Rank cores by their best prelock calibration door and breadth; reserve top five.
    core_ranked=sorted(core_groups.items(), key=lambda kv:(-max(score[kv[1]]), -len(set(sig_by_idx[i] for i in kv[1])), str(kv[0])))[:5]
    reserved=[]
    core_details=[]
    for core, idxs in core_ranked:
        sig_groups: dict[tuple[Any,...], list[int]]={}
        for i in idxs: sig_groups.setdefault(sig_by_idx[i], []).append(i)
        sigs=sorted(sig_groups.items(), key=lambda kv:(-max(score[kv[1]]), -len(kv[1]), str(kv[0])))
        N=max(1,len(sigs))
        depth=min(N, max(12, int(math.ceil(math.sqrt(N)*math.log(max(N,2))))))
        selected_sigs=sigs[:depth]
        for _, members in selected_sigs:
            # At most two family doors/signature; local order salary -> prelock mean -> sum P99 -> calibration score.
            ordered=sorted(members, key=lambda i:(int(cmeta['salary'][i]), float(cal.mu[candidate_rows[i]].sum()), float(cal.p99[candidate_rows[i]].sum()), float(score[i]), -i), reverse=True)
            reserved.extend(ordered[:2])
        core_details.append({"CORE": str(core), "SIGNATURES": N, "DEPTH": depth})
    out=np.unique(np.asarray(reserved,dtype=np.int32)) if reserved else np.asarray([],dtype=np.int32)
    return out, {"PATCH_ID": CFB_CLASSIC_SECONDARY_ROLE_SIGNATURE_ADAPTIVE_RESERVE_PATCH_ID, "TOP_CORES": len(core_ranked), "RESERVED": int(len(out)), "CORE_DETAILS": core_details}

def _select_top_by_group(group: np.ndarray, score: np.ndarray, per_group: int) -> np.ndarray:
    chosen: list[np.ndarray] = []
    for g in np.unique(group):
        idx = np.flatnonzero(group == g)
        if idx.size <= per_group: chosen.append(idx)
        else:
            local = np.argpartition(score[idx], -per_group)[-per_group:]
            chosen.append(idx[local])
    return np.unique(np.concatenate(chosen)) if chosen else np.asarray([], dtype=np.int32)


def _phase2(candidate_rows: np.ndarray, cmeta: dict[str, Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, np.ndarray], dict[str, int]]:
    score = np.asarray(cmeta["score"], dtype=float)
    global_k = min(cfg.candidate_global_keep, len(score))
    global_idx = np.argpartition(score, -global_k)[-global_k:] if global_k else np.asarray([], dtype=np.int32)
    family_idx = _select_top_by_group(np.asarray(cmeta["family"]), score, cfg.family_keep)
    primary_qb_idx = _select_top_by_group(candidate_rows[:, 0], score, cfg.qb_family_keep)
    # Preserve S-FLEX quarterback pathways independently from primary-QB pathways.
    sf_qb = np.where(cal.pos[candidate_rows[:, 7]] == "QB", candidate_rows[:, 7], -1)
    sf_qb_idx = _select_top_by_group(sf_qb[sf_qb >= 0], score[sf_qb >= 0], cfg.qb_family_keep) if np.any(sf_qb >= 0) else np.asarray([], dtype=np.int32)
    if np.any(sf_qb >= 0):
        sf_rows = np.flatnonzero(sf_qb >= 0)
        sf_qb_idx = sf_rows[sf_qb_idx]
    adaptive_reserve_idx, adaptive_reserve_receipt = _secondary_role_signature_adaptive_reserve(candidate_rows, cmeta, cal)
    chosen = np.unique(np.concatenate([global_idx, family_idx, primary_qb_idx, sf_qb_idx, adaptive_reserve_idx]))
    if len(chosen) > cfg.phase2_keep:
        mandatory = np.unique(np.concatenate([family_idx, primary_qb_idx, sf_qb_idx, adaptive_reserve_idx]))
        if len(mandatory) > cfg.phase2_keep:
            mandatory = mandatory[np.argpartition(score[mandatory], -cfg.phase2_keep)[-cfg.phase2_keep:]]
        remain = cfg.phase2_keep - len(mandatory)
        rest = np.setdiff1d(chosen, mandatory, assume_unique=False)
        extra = rest[np.argpartition(score[rest], -remain)[-remain:]] if remain > 0 and len(rest) > remain else rest[:max(0, remain)]
        chosen = np.unique(np.concatenate([mandatory, extra]))
    order = chosen[np.argsort(score[chosen], kind="stable")[::-1]]
    rows = candidate_rows[order]
    keys = [
        "score", "seed_family", "salary", "same_pass", "bringback", "same_rb",
        "qb_count", "dual_qb_same_game", "dual_qb_opponents", "same_team_dual_qb",
        "team_count", "game_count", "family", "macro",
    ]
    pmeta = {k: np.asarray(cmeta[k])[order] for k in keys}
    pmeta["phase2_index"] = np.arange(len(rows), dtype=np.int32)
    receipt = {
        "CALIBRATION_CANDIDATE_LINEUPS": int(len(candidate_rows)),
        "BASE_CALIBRATION_QUALIFIED_LINEUPS": int(len(global_idx)),
        "CALIBRATED_FAMILY_CLOSURE_LINEUPS": int(len(family_idx)),
        "CALIBRATED_PRIMARY_QB_CLOSURE_LINEUPS": int(len(primary_qb_idx)),
        "CALIBRATED_SFLEX_QB_CLOSURE_LINEUPS": int(len(sf_qb_idx)),
        "PHASE2_BUILT_LINEUPS": int(len(rows)),
        "CFB_CLASSIC_SECONDARY_ROLE_SIGNATURE_ADAPTIVE_RESERVE": adaptive_reserve_receipt,
    }
    return rows, pmeta, receipt

def _append_scenario_birth_phase2(rows: np.ndarray, pmeta: dict[str, np.ndarray], p2rec: dict[str, int], cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, np.ndarray], dict[str, Any]]:
    # CFB v1 has no undocumented scenario-birth fallback. Phase 2 is native calibrated-family birth only.
    receipt = dict(p2rec)
    receipt.update({
        "SCENARIO_BIRTH_PATCH_ID": None,
        "SCENARIO_BIRTH_ACTIVATED": False,
        "SCENARIO_ADDITIVE_PHASE2_LINEUPS": 0,
        "BASELINE_PHASE2_LINEUPS_PRESERVED": int(len(rows)),
        "PHASE2_BUILT_LINEUPS": int(len(rows)),
    })
    return rows, pmeta, receipt

def _score_rows(rows: np.ndarray, sims: np.ndarray) -> np.ndarray:
    return sims[rows].sum(axis=1)


def _public_field_indices(rows: np.ndarray, cal: Calibration, field_size: int, seed: int) -> np.ndarray:
    own = np.clip(cal.ownership, 0.0005, 0.98)
    logw = np.log(own[rows]).sum(axis=1)
    role = np.asarray(cal.strategy.opportunity_score, dtype=float)
    logw += 0.18 * role[rows].sum(axis=1)
    feat = _structural_lineup_features(rows, cal)
    logw += 0.10 * np.minimum(feat["same_pass"], 2) + 0.04 * np.minimum(feat["bringback"], 1)
    logw -= np.max(logw)
    w = np.exp(np.clip(logw, -40, 0)); w = w / w.sum()
    rng = np.random.default_rng(seed ^ 0xF13DCAFE)
    return rng.choice(len(rows), size=int(field_size), replace=True, p=w).astype(np.int32)


def _field_thresholds(field_rows: np.ndarray, sims: np.ndarray, top01_n: int, batch: int = 320) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    trials = sims.shape[1]
    keep_n = max(10, int(top01_n))
    # The public field is sampled with replacement. Exact duplicate lineups have
    # identical scores, so score each unique row once and restore only the
    # multiplicity capable of affecting the top keep_n order statistics.
    unique_rows, counts = np.unique(field_rows, axis=0, return_counts=True)
    top = np.full((keep_n, trials), -np.inf, dtype=np.float32)
    for start in range(0, len(unique_rows), batch):
        sc = _score_rows(unique_rows[start:start + batch], sims)
        reps = np.minimum(counts[start:start + batch], keep_n)
        if np.any(reps > 1):
            sc = np.repeat(sc, reps, axis=0)
        comb = np.concatenate([top, sc], axis=0)
        top = np.partition(comb, -keep_n, axis=0)[-keep_n:]
    ordered = np.sort(top, axis=0)
    win = ordered[-1]
    top10 = ordered[-10] if keep_n >= 10 else ordered[0]
    top01 = ordered[-top01_n]
    return win, top10, top01


def _evaluate(rows: np.ndarray, sims: np.ndarray, thresholds: tuple[np.ndarray, np.ndarray, np.ndarray], batch: int = 160) -> dict[str, np.ndarray]:
    win_t, top10_t, top01_t = thresholds
    n = len(rows); trials = sims.shape[1]
    win = np.zeros(n, dtype=np.int32); top10 = np.zeros(n, dtype=np.int32); top01 = np.zeros(n, dtype=np.int32)
    mean = np.zeros(n, dtype=np.float32); p95 = np.zeros(n, dtype=np.float32); p99 = np.zeros(n, dtype=np.float32)
    k95 = max(0, int(math.ceil(.95 * trials)) - 1); k99 = max(0, int(math.ceil(.99 * trials)) - 1)
    for start in range(0, n, batch):
        r = rows[start:start + batch]
        sc = _score_rows(r, sims)
        sl = slice(start, start + len(r))
        win[sl] = (sc >= win_t).sum(axis=1); top10[sl] = (sc >= top10_t).sum(axis=1); top01[sl] = (sc >= top01_t).sum(axis=1)
        mean[sl] = sc.mean(axis=1)
        part = np.partition(sc, (k95, k99), axis=1)
        p95[sl] = part[:, k95]; p99[sl] = part[:, k99]
    return {"win_count": win, "top10_count": top10, "top01_count": top01, "mean": mean, "p95": p95, "p99": p99, "trials": np.full(n, trials, dtype=np.int32)}


def _simulate_phase2(rows: np.ndarray, cal: Calibration, cfg: Config) -> dict[str, Any]:
    base = {
        "mu": cal.mu, "sigma": cal.sigma, "pos": cal.pos, "team": cal.team, "opp": cal.opp, "game": cal.game,
        "role_snap": cal.role_snap, "role_routes": cal.role_routes, "role_targets": cal.role_targets, "role_carries": cal.role_carries,
        "team_total": cal.frame["TM Score"].to_numpy(float), "game_total": cal.frame["O/U"].to_numpy(float),
    }
    fake_field_size = max(cfg.field_size, int(math.ceil(cfg.field_size * cfg.fake_field_multiplier)))
    field_idx = _public_field_indices(rows, cal, fake_field_size, cfg.seed)
    top01_n = max(1, int(math.ceil(fake_field_size * 0.001)))
    sims = _simulate_players(base, cfg.base_trials, cfg.seed ^ 0xB453C1A5)
    thresholds = _field_thresholds(rows[field_idx], sims, top01_n)
    metrics = _evaluate(rows, sims, thresholds)
    n = len(rows)
    trials = metrics["trials"].copy(); top01 = metrics["top01_count"].copy(); top10 = metrics["top10_count"].copy(); win = metrics["win_count"].copy()
    rates = top01 / trials
    cutoff_target = min(max(1, max(cfg.board_size * 5, int(math.ceil(n * .01)))), n)
    cutoff_idx = np.argsort(rates, kind="stable")[-cutoff_target]
    lcb, ucb = _wilson(top01, trials)
    cutoff_l = float(lcb[cutoff_idx]); cutoff_u = float(ucb[cutoff_idx]); cutoff_rate = float(rates[cutoff_idx])
    overlap = (ucb >= cutoff_l) & (lcb <= cutoff_u)
    bubble = np.flatnonzero(overlap)
    if bubble.size > cfg.bubble_cap:
        dist = np.abs(rates[bubble] - cutoff_rate)
        tail = -_pct(metrics["p99"])[bubble] * 1e-6
        bubble = bubble[np.argsort(dist + tail, kind="stable")[:cfg.bubble_cap]]
    extra_total = 0; unresolved = bubble.copy(); batch_no = 0
    while unresolved.size and int(trials[unresolved].max()) < cfg.max_trials:
        batch_no += 1
        batch_trials = min(cfg.extra_batch_trials, cfg.max_trials - int(trials[unresolved].min()))
        if batch_trials <= 0: break
        exsims = _simulate_players(base, batch_trials, (cfg.seed ^ 0xB453C1A5) + batch_no * 104729)
        exthr = _field_thresholds(rows[field_idx], exsims, top01_n)
        ev = _evaluate(rows[unresolved], exsims, exthr)
        top01[unresolved] += ev["top01_count"]; top10[unresolved] += ev["top10_count"]; win[unresolved] += ev["win_count"]
        trials[unresolved] += batch_trials; extra_total += int(len(unresolved) * batch_trials)
        rates = top01 / trials
        cutoff_idx = np.argsort(rates, kind="stable")[-cutoff_target]
        lcb, ucb = _wilson(top01, trials)
        cutoff_l = float(lcb[cutoff_idx]); cutoff_u = float(ucb[cutoff_idx])
        fail = ucb[unresolved] < cutoff_l; pas = lcb[unresolved] > cutoff_u; maxed = trials[unresolved] >= cfg.max_trials
        unresolved = unresolved[~(fail | pas | maxed)]
    lcb, ucb = _wilson(top01, trials)
    metrics.update({"win_count": win, "top10_count": top10, "top01_count": top01, "trials": trials, "win_rate": win / trials, "top10_rate": top10 / trials, "top01_rate": top01 / trials, "top01_lcb": lcb, "top01_ucb": ucb})
    return {"metrics": metrics, "field_idx": field_idx, "top01_n": top01_n, "bubble_found": int(len(bubble)), "bubble_unresolved": int(len(unresolved)), "extra_total": int(extra_total), "cutoff_lcb": float(cutoff_l), "cutoff_ucb": float(cutoff_u), "fake_field_size": int(len(field_idx))}


def _family_first_geometry_preference(rows: np.ndarray, m: dict[str, Any], cal: Calibration, cfg: Config, base_order: list[int]) -> tuple[list[int], dict[str, Any]]:
    slate_games = len(set(cal.game.tolist()))
    activate = int(cfg.field_size) >= int(cfg.family_first_min_field_size) and slate_games >= int(cfg.family_first_min_slate_games) and len(rows) >= 5
    if not activate:
        return base_order, {"PATCH_ID": CFB_CLASSIC_FAMILY_FIRST_PORTFOLIO_PATCH_ID, "ACTIVATED": False, "SLATE_GAMES": int(slate_games)}
    core_groups: dict[tuple[int,...], list[int]] = {}
    for i, row in enumerate(rows):
        core_groups.setdefault(_five_man_passing_core(row, cal), []).append(i)
    top01 = np.asarray(m["top01_rate"], dtype=np.float64)
    p99 = np.asarray(m["p99"], dtype=np.float64)
    top10 = np.asarray(m["top10_rate"], dtype=np.float64)
    family_rank=[]
    for core, idxs in core_groups.items():
        arr=np.asarray(idxs,dtype=np.int32)
        best=float(np.max(top01[arr])); mass=float(np.mean(np.sort(top01[arr])[-min(5,len(arr)):]))
        tail=float(np.max(p99[arr])); breadth=len({_game_geometry(rows[i],cal) for i in idxs})
        family_rank.append((best, mass, tail, breadth, core))
    family_rank.sort(key=lambda x:(-x[0],-x[1],-x[2],-x[3],str(x[4])))
    top_core=family_rank[0][4]
    members=core_groups[top_core]
    base_pos={idx:k for k,idx in enumerate(base_order)}
    def ranked(indices):
        return sorted(indices, key=lambda i:(-float(top01[i]), -float(top10[i]), -float(p99[i]), base_pos.get(i,10**9), i))
    by_geom: dict[str,list[int]]={}
    for i in members:
        by_geom.setdefault(_game_geometry(rows[i],cal),[]).append(i)
    for g in list(by_geom): by_geom[g]=ranked(by_geom[g])
    chosen: list[int]=[]
    lanes: list[str]=[]
    # Two doors from the strongest 4-2-2 family when available; this is portfolio hedging inside one recurrent core, not a legality gate.
    for g, take in [("4-2-2",2),("3-3-2",1),("3-2-2-1",1)]:
        for i in by_geom.get(g,[])[:take]:
            if i not in chosen:
                chosen.append(i); lanes.append(g)
    for i in ranked(members):
        if len(chosen) >= 5: break
        if i not in chosen:
            chosen.append(i); lanes.append("WILDCARD")
    # If one core cannot supply five legal doors, fill from the global order without forcing geometry.
    for i in base_order:
        if len(chosen) >= 5: break
        if i not in chosen:
            chosen.append(i); lanes.append("GLOBAL_FILL")
    rest=[i for i in base_order if i not in chosen]
    order=chosen+rest
    return order, {
        "PATCH_ID": CFB_CLASSIC_FAMILY_FIRST_PORTFOLIO_PATCH_ID, "ACTIVATED": True, "SLATE_GAMES": int(slate_games),
        "TOP_CORE": [str(cal.frame.iloc[x]["PLAYER"]) for x in top_core], "TOP_CORE_SIZE": int(len(top_core)),
        "TOP_CORE_MEMBER_COUNT": int(len(members)), "TOP5_LANES": lanes[:5], "GLOBAL_MIN_GAMES_UNCHANGED": int(MIN_GAMES),
    }



def _two_game_balance_escape_reserve_v1(
    rows: np.ndarray,
    cal: Calibration,
    cfg: Config,
    *,
    strict: np.ndarray,
    p95_percentile: np.ndarray,
    p99_percentile: np.ndarray,
) -> tuple[list[int], dict[str, Any]]:
    """Reserve balanced one-swap siblings from elite concentrated two-game scripts.

    The reserve is prelock-only and portfolio-scoped. It never births a lineup,
    uses no contest result, and never uses player-name constants. A candidate must
    already exist in frozen Phase 2, be a same-position cross-game one-swap sibling
    of an elite script-posterior seed, move one player toward a more balanced game
    allocation, and clear lineup-level P95/P99 percentile floors.
    """
    n = int(len(rows))
    active_games = sorted(set(np.asarray(cal.game, dtype=str).tolist()))
    slots = max(0, min(int(cfg.two_game_balance_escape_slots), int(cfg.board_size)))
    base_receipt: dict[str, Any] = {
        "PATCH_ID": CFB_CLASSIC_TWO_GAME_BALANCE_ESCAPE_RESERVE_PATCH_ID,
        "ACTIVATED": False,
        "SLATE_GAMES": int(len(active_games)),
        "RESERVE_SLOTS_CONFIGURED": int(slots),
        "SCRIPT_SEED_KEEP": int(cfg.two_game_balance_escape_seed_keep),
        "CONCENTRATION_MIN": int(cfg.two_game_balance_escape_concentration_min),
        "P95_PERCENTILE_FLOOR": float(cfg.two_game_balance_escape_p95_floor),
        "P99_PERCENTILE_FLOOR": float(cfg.two_game_balance_escape_p99_floor),
        "POSTLOCK_INPUTS": 0,
        "PLAYER_NAME_CONSTANTS": 0,
        "PHASE2_MEMBERSHIP_MUTATION": False,
        "ROLE": "PORTFOLIO_CHAMPIONSHIP_ESCAPE_RESERVE",
    }
    if n == 0 or len(active_games) != 2 or slots <= 0:
        return [], base_receipt
    required_cols = {"FPTS", "TM Score", "O/U"}
    if not required_cols.issubset(set(cal.frame.columns)):
        raise RuntimeError("RUN_INVALID:CFB_TWO_GAME_BALANCE_ESCAPE_REQUIRED_PRELOCK_CHANNEL_MISSING")

    raw_projection = cal.frame["FPTS"].to_numpy(dtype=np.float64)[rows].sum(axis=1)
    p99_sum = np.asarray(cal.p99, dtype=np.float64)[rows].sum(axis=1)
    team_total = cal.frame["TM Score"].to_numpy(dtype=np.float64)
    game_total = cal.frame["O/U"].to_numpy(dtype=np.float64)
    market = two_game_order._market_affinity(rows, team_total, game_total)
    game_posterior = two_game_order._game_posterior(np.asarray(cal.game, dtype=str), game_total)
    qb_coverage = two_game_order._qb_game_coverage(rows, np.asarray(cal.pos, dtype=str), np.asarray(cal.game, dtype=str), game_posterior)
    script_score = (
        0.25 * two_game_order._zscore(raw_projection)
        + 0.25 * two_game_order._zscore(p99_sum)
        + 0.25 * two_game_order._zscore(market)
        + 0.25 * two_game_order._zscore(qb_coverage)
    )
    seed_keep = min(n, max(1, int(cfg.two_game_balance_escape_seed_keep)))
    seed_order = np.argsort(-script_score, kind="stable")[:seed_keep]
    row_sets = [set(int(x) for x in row.tolist()) for row in rows]
    candidate_seed_rank: dict[int, int] = {}

    def game_counts(row: np.ndarray) -> tuple[int, int]:
        vals = np.asarray(cal.game, dtype=str)[row].tolist()
        counts: dict[str, int] = {}
        for g in vals:
            counts[str(g)] = counts.get(str(g), 0) + 1
        ordered = sorted(counts.values(), reverse=True)
        return (int(ordered[0]), int(ordered[1])) if len(ordered) == 2 else (0, 0)

    for seed_rank, seed_i_raw in enumerate(seed_order.tolist(), 1):
        seed_i = int(seed_i_raw)
        seed_counts = game_counts(rows[seed_i])
        if seed_counts[0] < int(cfg.two_game_balance_escape_concentration_min):
            continue
        desired_counts = tuple(sorted((seed_counts[0] - 1, seed_counts[1] + 1), reverse=True))
        seed_set = row_sets[seed_i]
        for j in range(n):
            if bool(strict[j]):
                continue
            if float(p95_percentile[j]) < float(cfg.two_game_balance_escape_p95_floor):
                continue
            if float(p99_percentile[j]) < float(cfg.two_game_balance_escape_p99_floor):
                continue
            if game_counts(rows[j]) != desired_counts:
                continue
            inter = seed_set & row_sets[j]
            if len(inter) != ROSTER_SIZE - 1:
                continue
            outgoing = next(iter(seed_set - inter))
            incoming = next(iter(row_sets[j] - seed_set))
            if str(cal.pos[outgoing]) != str(cal.pos[incoming]):
                continue
            if str(cal.game[outgoing]) == str(cal.game[incoming]):
                continue
            prev = candidate_seed_rank.get(j)
            if prev is None or seed_rank < prev:
                candidate_seed_rank[j] = int(seed_rank)

    if not candidate_seed_rank:
        return [], {**base_receipt, "ACTIVATED": True, "QUALIFIED_CANDIDATES": 0, "SELECTED": 0}

    idx = np.asarray(sorted(candidate_seed_rank), dtype=np.int32)
    opportunity = np.asarray(cal.strategy.opportunity_score, dtype=np.float64)
    role_components = np.column_stack([
        _pct(np.asarray(cal.role_targets, dtype=np.float64)[rows[idx]].sum(axis=1)),
        _pct(np.asarray(cal.role_routes, dtype=np.float64)[rows[idx]].sum(axis=1)),
        _pct(opportunity[rows[idx]].sum(axis=1)),
        _pct(np.asarray(cal.role_snap, dtype=np.float64)[rows[idx]].sum(axis=1)),
    ])
    role_score = role_components.mean(axis=1)
    seed_quality = np.asarray([
        1.0 - (candidate_seed_rank[int(j)] - 1) / max(1, seed_keep)
        for j in idx.tolist()
    ], dtype=np.float64)
    reserve_score = 0.85 * role_score + 0.15 * seed_quality
    order = idx[np.argsort(-reserve_score, kind="stable")]

    chosen: list[int] = []
    chosen_sets: list[set[int]] = []
    for raw_i in order.tolist():
        i = int(raw_i)
        si = row_sets[i]
        if any(len(si & sj) > int(cfg.max_pairwise_overlap) for sj in chosen_sets):
            continue
        chosen.append(i)
        chosen_sets.append(si)
        if len(chosen) >= slots:
            break
    score_map = {int(i): float(reserve_score[k]) for k, i in enumerate(idx.tolist())}
    return chosen, {
        **base_receipt,
        "ACTIVATED": True,
        "QUALIFIED_CANDIDATES": int(len(idx)),
        "SELECTED": int(len(chosen)),
        "SELECTED_PHASE2_INDICES": [int(x) for x in chosen],
        "SELECTED_SCORES": [score_map[int(x)] for x in chosen],
        "SELECTED_SOURCE_SEED_RANKS": [int(candidate_seed_rank[int(x)]) for x in chosen],
        "SCRIPT_SCORE_AUTHORITY": "EXISTING_TWO_GAME_FOUR_CHANNEL_PRELOCK_SIGNAL",
        "ROLE_SCORE_CHANNELS": ["ROLE_TARGETS", "ROLE_ROUTES", "OPPORTUNITY_SCORE", "ROLE_SNAP"],
        "ROLE_SCORE_WEIGHT": 0.85,
        "SCRIPT_SEED_QUALITY_WEIGHT": 0.15,
    }


def _select(rows: np.ndarray, pmeta: dict[str, np.ndarray], sim: dict[str, Any], cal: Calibration, cfg: Config) -> tuple[np.ndarray, dict[str, Any], str]:
    m = sim["metrics"]; n = len(rows)
    top01p = _pct(m["top01_rate"]); winp = _pct(m["win_rate"]); top10p = _pct(m["top10_rate"]); p95p = _pct(m["p95"]); p99p = _pct(m["p99"])
    own = np.clip(cal.ownership, 0.0005, 0.98)
    ownprod = np.exp(np.clip(np.log(own[rows]).sum(axis=1), -50, 0)); leverage = 1.0 - _pct(ownprod)
    strict = ((top01p >= .99) | (winp >= .99)) & (p95p >= .99) & (p99p >= .985) & (top10p >= .90)
    selector_metrics = {
        "top01_rate": np.asarray(m["top01_rate"], dtype=np.float64), "top01_lcb": np.asarray(m["top01_lcb"], dtype=np.float64),
        "win_rate": np.asarray(m["win_rate"], dtype=np.float64), "p99": np.asarray(m["p99"], dtype=np.float64),
        "p95": np.asarray(m["p95"], dtype=np.float64), "top10_rate": np.asarray(m["top10_rate"], dtype=np.float64), "leverage": np.asarray(leverage, dtype=np.float64),
    }
    plan = hybrid_selector.HybridRankingPlan(primary_metric="top01_rate", tiebreak_metrics=("top01_lcb", "win_rate", "p99", "p95", "top10_rate", "leverage"), primary_tie_width=float(cfg.selector_primary_tie_width))
    global_order = hybrid_selector.ranking_order(plan, selector_metrics).astype(np.int32, copy=False)

    # Neighborhood/family diagnostics remain visible, but neither may reorder the
    # championship head. Terminal membership follows the strict gate + hybrid rank.
    _rn_order, rn_receipt = rn_door.neighborhood_door_order(
        np.asarray(pmeta["family"]), selector_metrics,
        {"top01_rate":.26,"top01_lcb":.12,"win_rate":.16,"p99":.18,"p95":.10,"top10_rate":.08,"leverage":.10},
    )
    rn_receipt = {**rn_receipt, "TERMINAL_ORDER_AUTHORITY": False, "ORDER_APPLIED": False, "ROLE": "RECALL_CONTEXT_ONLY"}
    _family_pref, family_first_receipt = _family_first_geometry_preference(rows, m, cal, cfg, [int(i) for i in global_order])
    family_first_receipt = {**family_first_receipt, "TERMINAL_ORDER_AUTHORITY": False, "ORDER_APPLIED": False, "ROLE": "PORTFOLIO_CONTEXT_ONLY"}

    if n <= 0:
        raise RuntimeError("ENGINE_INTEGRITY_FAILURE:CFB_CLASSIC_ZERO_PHASE3_SURVIVORS")
    target = min(int(cfg.board_size), n)
    player_exposure_cap, qb_exposure_cap, family_exposure_cap = _scaled_portfolio_caps(cfg, target)
    strict_idx = np.flatnonzero(strict).astype(np.int32)
    strict_count = int(len(strict_idx))
    strict_ranked = [int(i) for i in global_order if bool(strict[int(i)])]
    nonstrict_ranked = [int(i) for i in global_order if not bool(strict[int(i)])]
    portfolio_relaxation = False

    escape_ranked, escape_receipt = _two_game_balance_escape_reserve_v1(
        rows, cal, cfg, strict=strict, p95_percentile=p95p, p99_percentile=p99p
    )
    max_escape = min(len(escape_ranked), int(cfg.two_game_balance_escape_slots), target)
    if strict_count < target:
        # All strict rows remain mandatory when strict eligibility is scarce.
        max_escape = min(max_escape, target - strict_count)
    escape = [int(i) for i in escape_ranked[:max_escape]]
    escape_receipt = {**escape_receipt, "SELECTED_AFTER_STRICT_PRESERVATION": int(len(escape)), "SELECTED_PHASE2_INDICES": escape}

    chosen: list[int] = list(escape)
    selected_sets = [set(int(x) for x in rows[i]) for i in chosen]
    exposure = np.zeros(int(rows.max()) + 1 if rows.size else 0, dtype=np.int16)
    qb_exposure = np.zeros_like(exposure)
    family_count: dict[int, int] = {}
    for i in chosen:
        players = rows[i]; exposure[players] += 1
        qb_players = players[cal.pos[players] == "QB"]
        if qb_players.size: qb_exposure[qb_players] += 1
        fam = int(np.asarray(pmeta["family"])[i]); family_count[fam] = family_count.get(fam, 0) + 1

    strict_target = min(strict_count, target - len(chosen))
    strict_added = 0
    for i in strict_ranked:
        if strict_added >= strict_target: break
        if i in chosen: continue
        players = rows[i]
        if np.any(exposure[players] >= int(player_exposure_cap)): continue
        qb_players = players[cal.pos[players] == "QB"]
        if qb_players.size and np.any(qb_exposure[qb_players] >= int(qb_exposure_cap)): continue
        fam = int(np.asarray(pmeta["family"])[i]
        )
        if family_count.get(fam, 0) >= int(family_exposure_cap): continue
        si = set(int(x) for x in players)
        if any(len(si & sj) > int(cfg.max_pairwise_overlap) for sj in selected_sets): continue
        chosen.append(i); selected_sets.append(si); exposure[players] += 1
        if qb_players.size: qb_exposure[qb_players] += 1
        family_count[fam] = family_count.get(fam, 0) + 1
        strict_added += 1
    if strict_added < strict_target:
        for i in strict_ranked:
            if i in chosen: continue
            chosen.append(i); strict_added += 1
            if strict_added >= strict_target: break
        portfolio_relaxation = True

    if len(chosen) < target:
        gate_mode = "STRICT_PLUS_CONTROLLED_FALLBACK" if not escape else "STRICT_CORE_PLUS_TWO_GAME_BALANCE_ESCAPE_AND_FALLBACK"
        for i in nonstrict_ranked:
            if len(chosen) >= target: break
            if i in chosen: continue
            players = rows[i]
            if np.any(exposure[players] >= int(player_exposure_cap)): continue
            qb_players = players[cal.pos[players] == "QB"]
            if qb_players.size and np.any(qb_exposure[qb_players] >= int(qb_exposure_cap)): continue
            fam = int(np.asarray(pmeta["family"])[i]
            )
            if family_count.get(fam, 0) >= int(family_exposure_cap): continue
            si = set(int(x) for x in players)
            if any(len(si & sj) > int(cfg.max_pairwise_overlap) for sj in selected_sets): continue
            chosen.append(i); selected_sets.append(si); exposure[players] += 1
            if qb_players.size: qb_exposure[qb_players] += 1
            family_count[fam] = family_count.get(fam, 0) + 1
        if len(chosen) < target:
            chosen.extend([i for i in nonstrict_ranked if i not in chosen][:target-len(chosen)])
            portfolio_relaxation = True
    else:
        gate_mode = "STRICT_CORE_PLUS_TWO_GAME_BALANCE_ESCAPE" if escape else ("STRICT_ONLY" if strict_count >= target else "STRICT_PLUS_CONTROLLED_FALLBACK")

    if len(chosen) != target:
        raise RuntimeError(f"ENGINE_INTEGRITY_FAILURE:CFB_CLASSIC_NONEMPTY_BOARD_CARDINALITY:{len(chosen)}:{target}")
    chosen_arr = np.asarray(chosen, dtype=np.int32)
    strict_selected = int(np.count_nonzero(strict[chosen_arr]))
    expected_strict = min(strict_count, target - len(escape))
    if strict_selected != expected_strict:
        raise RuntimeError(f"ENGINE_INTEGRITY_HALT:CFB_STRICT_CORE_PARITY:{strict_selected}:{expected_strict}")
    if strict_count < target and strict_selected != strict_count:
        raise RuntimeError(f"ENGINE_INTEGRITY_HALT:CFB_STRICT_GATE_MANDATORY_ROWS_DROPPED:{strict_selected}:{strict_count}")
    if any(i not in chosen for i in escape):
        raise RuntimeError("ENGINE_INTEGRITY_HALT:CFB_TWO_GAME_BALANCE_ESCAPE_DROPPED")

    ordinal = np.zeros(n, dtype=np.float64)
    if n: ordinal[global_order] = (n - np.arange(n, dtype=np.float64)) / n
    state = "NONEMPTY_PHASE3_BOARD_COMPLETE_RELAXED" if portfolio_relaxation else "NONEMPTY_PHASE3_BOARD_COMPLETE"
    selector_receipt = hybrid_selector.selector_receipt(plan, n, cal.phase1_hash)
    selector_receipt.update({
        "STRICT_GATE_PATCH_ID": CFB_CLASSIC_STRICT_ELITE_SELECTOR_GATE_PATCH_ID,
        "STRICT_GATE_MODE": gate_mode,
        "STRICT_ELIGIBLE": strict_count,
        "STRICT_SELECTED": strict_selected,
        "STRICT_TARGET": int(target),
        "STRICT_SHORTFALL": int(max(0, target - strict_count)),
        "STRICT_CORE_SELECTED": int(strict_selected),
        "TWO_GAME_BALANCE_ESCAPE_PATCH_ID": CFB_CLASSIC_TWO_GAME_BALANCE_ESCAPE_RESERVE_PATCH_ID,
        "TWO_GAME_BALANCE_ESCAPE_SELECTED": int(len(escape)),
        "STRICT_DISPLACED_BY_BALANCE_ESCAPE": int(len(escape) if strict_count >= target else 0),
        "RIGHT_NEIGHBORHOOD_TERMINAL_AUTHORITY": False,
        "FAMILY_FIRST_TERMINAL_ORDER_AUTHORITY": False,
        "ORDER_BEFORE_PORTFOLIO_DIVERSIFICATION": True,
        "NATIVE_PORTFOLIO_TARGET": int(target),
        "PLAYER_EXPOSURE_CAP_EFFECTIVE": int(player_exposure_cap),
        "QB_EXPOSURE_CAP_EFFECTIVE": int(qb_exposure_cap),
        "FAMILY_EXPOSURE_CAP_EFFECTIVE": int(family_exposure_cap),
        "MAX_ENTRY_NATIVE_PORTFOLIO_PATCH_ID": CFB_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_PATCH_ID,
    })
    metrics: dict[str, Any] = {
        **{k: np.asarray(v) for k, v in m.items()}, "top01_percentile": top01p, "win_percentile": winp, "top10_percentile": top10p,
        "p95_percentile": p95p, "p99_percentile": p99p, "ownership_product": ownprod, "leverage": leverage,
        "selector_score": ordinal, "strict_eligible": strict_idx, "chosen": chosen_arr, "selector_receipt": selector_receipt, "right_neighborhood_receipt": rn_receipt, "family_first_receipt": family_first_receipt, "two_game_balance_escape_receipt": escape_receipt,
        "final_board_target": np.array([target], dtype=np.int32), "portfolio_preference_relaxation": np.array([int(portfolio_relaxation)], dtype=np.int8),
    }
    return rows[chosen_arr] if chosen_arr.size else np.empty((0, 8), dtype=np.int32), metrics, state


def _row_slot_names(row: np.ndarray, cal: Calibration) -> dict[str, str]:
    names = cal.frame.iloc[row]["PLAYER"].astype(str).tolist()
    return {
        "QB": names[0], "RB1": names[1], "RB2": names[2],
        "WR1": names[3], "WR2": names[4], "WR3": names[5],
        "FLEX": names[6], "SFLEX": names[7],
    }

def _board_legality(row: np.ndarray, cal: Calibration) -> bool:
    if len(set(row.tolist())) != 8:
        return False
    if not (SALARY_MIN <= int(cal.salary[row].sum()) <= SALARY_MAX):
        return False
    pos = cal.pos[row]
    if pos[0] != "QB" or pos[1] != "RB" or pos[2] != "RB":
        return False
    if pos[3] != "WR" or pos[4] != "WR" or pos[5] != "WR":
        return False
    if pos[6] not in {"RB", "WR", "TE"} or pos[7] not in {"QB", "RB", "WR", "TE"}:
        return False
    qbs = row[pos == "QB"]
    if len(qbs) > 2:
        return False
    if len(set(cal.team[row].tolist())) < 2:
        return False
    if len(set(cal.game[row].tolist())) < MIN_GAMES:
        return False
    return True

def _write_outputs(board: np.ndarray, rows: np.ndarray, metrics: dict[str, Any], pmeta: dict[str, np.ndarray], cal: Calibration, cfg: Config,
                   phase2_receipt: dict[str, int], sim: dict[str, Any], legal_scan: int, board_path: str | Path, receipt_path: str | Path) -> tuple[pd.DataFrame, dict[str, Any]]:
    chosen = np.asarray(metrics["chosen"], dtype=np.int32)
    strict_set = {int(x) for x in np.asarray(metrics.get("strict_eligible", np.empty(0, dtype=np.int32))).tolist()}
    escape_set = {int(x) for x in (metrics.get("two_game_balance_escape_receipt") or {}).get("SELECTED_PHASE2_INDICES", [])}
    records = []
    for rank, (row, idx) in enumerate(zip(board, chosen), 1):
        phase2_idx = int(idx)
        is_escape = phase2_idx in escape_set
        is_strict = phase2_idx in strict_set
        protected = bool(is_escape or is_strict)
        lane = "TWO_GAME_BALANCE_ESCAPE" if is_escape else ("STRICT_ELITE" if is_strict else "UNPROTECTED")
        priority = 120 if is_escape else (110 if is_strict else 0)
        rec = {"RANK": rank, **_row_slot_names(row, cal), "SALARY": int(cal.salary[row].sum()),
               "QB_STACK_PASS": int(pmeta["same_pass"][idx]), "BRINGBACK": int(pmeta["bringback"][idx]),
               "TOP01_RATE": float(metrics["top01_rate"][idx]), "WIN_RATE": float(metrics["win_rate"][idx]), "TOP10_RATE": float(metrics["top10_rate"][idx]),
               "P95": float(metrics["p95"][idx]), "P99": float(metrics["p99"][idx]), "SELECTOR_SCORE": float(metrics["selector_score"][idx]),
               "TWO_GAME_ORDER_SCORE": float(np.asarray(metrics.get("two_game_order_score", np.zeros(len(board))))[rank - 1]),
               "CFB_STRICT_ELIGIBLE": bool(is_strict), "CFB_TWO_GAME_BALANCE_ESCAPE": bool(is_escape),
               "GLOBAL_CORE_PROTECTED": protected, "GLOBAL_CORE_PRIORITY": int(priority),
               "GLOBAL_CORE_FAMILY_ID": f"CFB_CLASSIC_{lane}_SOURCE_{rank}" if protected else "",
               "GLOBAL_CORE_SCENARIO_ID": f"CFB_CLASSIC_{lane}" if protected else "",
               "GLOBAL_CORE_FAMILY_CAP": 1 if protected else 0,
               "CFB_NATIVE_BOARD_RANK": int(rank)}
        records.append(rec)
    board_df = pd.DataFrame(records)
    Path(board_path).parent.mkdir(parents=True, exist_ok=True); board_df.to_csv(board_path, index=False)
    phase2_hash = _array_hash(rows)
    identity_ledger = [[str(cal.ids[j]) for j in row] for row in rows.tolist()]
    identity_hash = hashlib.sha256(json.dumps(identity_ledger, separators=(",", ":")).encode()).hexdigest()
    board_legal = all(_board_legality(row, cal) for row in board)
    receipt = {
        "RUN_STATE": "TOOL_PROVEN_EXECUTED", "ENGINE_ID": ENGINE_ID, "SPORT": SPORT, "MODE": MODE, "FIELD_SIZE": cfg.field_size,
        "CFB_CALIBRATION_PATCH_ID": "CFB_CLASSIC_DRIVE_SCRIPT_AND_ROLE_CONCENTRATION_CALIBRATION_v2",
        "PHASE1_REGIME_RECEIPT_HASH": _stable_hash(cal.phase1_regime_receipt),
        "FAST_PATH_DOCTRINE_ID": "APEX_FAST_PATH_ENGINE_EXECUTION_v2", "FAST_PATH_METHODS": ["VECTORIZED_NUMPY_PANDAS", "CALIBRATED_FAMILY_BEAM_BIRTH", "NO_PRE_PHASE2_CARTESIAN_LOCAL_DOOR_CLOSURE", "STREAMING_FIXED_MEMORY_FIELD_SIM", "ARGPARTITION_GROUP_CLOSURE"],
        "SLOW_FALLBACK": False, "STRUCTURAL_FEASIBILITY_PRECHECK": "PASS", "PREDICTIVE_LAYER": "APEX_GLOBAL_PREDICTIVE_MARKET_LAYER_v1",
        "PREDICTION_HASH": cal.prediction_hash, "ROLE_EVIDENCE_HASH": cal.role_evidence_hash, "MARKET_EVIDENCE_HASH": cal.market_evidence_hash,
        "ROLE_EVIDENCE_SNAPSHOT": cal.role_evidence_payload, "MARKET_EVIDENCE_SNAPSHOT": cal.market_evidence_payload,
        "ACTIVE_POOL": int(len(cal.frame)), "OUT_PURGE": cal.out_names, "ZERO_ROLE_SUPPRESSED": cal.zero_role_names,
        "LEGAL_SCAN_LINEUPS": int(legal_scan), **phase2_receipt, "PHASE3_CANDIDATE_LINEUPS": int(len(rows)), "HANDOFF_SURVIVORS": int(len(rows)), "SELECTOR_REVIEWED_LINEUPS": int(len(rows)),
        "POST_PHASE2_MUTATION_COUNT": 0, "POST_PHASE1_RECALIBRATION_COUNT": 0, "PHASE1_MC_TRIALS": int(cfg.player_trials), "PHASE1_CALIBRATION_HASH": cal.phase1_hash,
        "PHASE2_CALIBRATION_HASH": cal.phase1_hash, "PHASE3_CALIBRATION_HASH": cal.phase1_hash, "HANDOFF_CALIBRATION_HASH": cal.phase1_hash,
        "SELECTOR_INPUT_CALIBRATION_HASH": cal.phase1_hash, "FINAL_BOARD_CALIBRATION_HASH": cal.phase1_hash, "CALIBRATION_PARITY": "PASS",
        "PLAYER_SIMULATION_MATRIX_HASH": cal.player_sim_matrix_hash, "PHASE2_IDENTITY_LEDGER": identity_ledger, "PHASE2_IDENTITY_LEDGER_ROWS": int(len(identity_ledger)), "PHASE2_IDENTITY_LEDGER_SHA256": identity_hash,
        "PHASE2_FREEZE_HASH": phase2_hash, "PHASE3_INPUT_HASH": phase2_hash, "HANDOFF_INPUT_HASH": phase2_hash, "SELECTOR_INPUT_HASH": phase2_hash, "HANDOFF_METRIC_PARITY_CHECK": "PASS",
        "SHARED_METRIC_BUNDLE_ID": cal.shared_metric_bundle_id, "HANDOFF_PATCH_ID": HANDOFF_PATCH_ID, "BASE_SIM_TRIALS": int(cfg.base_trials), "FAKE_FIELD_LINEUPS": int(sim["fake_field_size"]),
        "BUBBLE_LINEUPS_FOUND": int(sim["bubble_found"]), "BUBBLE_EXTRA_TRIALS_TOTAL": int(sim["extra_total"]), "BUBBLE_LINEUPS_UNRESOLVED": int(sim["bubble_unresolved"]),
        "SELECTOR_REVIEWED_STRICT_ELIGIBLE": int(len(metrics["strict_eligible"])), **metrics["selector_receipt"], "RIGHT_NEIGHBORHOOD_DOOR_SELECTOR": metrics.get("right_neighborhood_receipt"), "CFB_CLASSIC_FAMILY_FIRST_PORTFOLIO": metrics.get("family_first_receipt"), "CFB_CLASSIC_TWO_GAME_BALANCE_ESCAPE_RESERVE": metrics.get("two_game_balance_escape_receipt"), "CFB_CLASSIC_TWO_GAME_SCRIPT_POSTERIOR_ORDER": metrics.get("two_game_order_receipt"), "FAMILY_STRUCTURE_PRESERVED": True,
        "CFB_CLASSIC_ROSTER": ["QB", "RB", "RB", "WR", "WR", "WR", "FLEX", "SFLEX"], "SALARY_MIN": SALARY_MIN, "SALARY_MAX": SALARY_MAX, "MIN_GAMES": MIN_GAMES, "ROSTER_LEGALITY_PATCH_ID": ROSTER_LEGALITY_PATCH_ID,
        "MULTI_GAME_CORRELATION_MODEL": "CFB_GAME_TEAM_PASS_RUSH_PACE_BLOWOUT_v1", "RAW_AGGREGATE_PROJECTION_PHASE1": "WEAK_PRIOR_ONLY",
        "CFB_RAW_CEILING_FLOOR_INPUT_REQUIRED": False, "CFB_CEILING_FLOOR_AUTHORITY": "PHASE1_MC_SIMULATED", "CFB_RST_INPUT_REQUIRED": False, "OWNERSHIP_AUTHORITY": "CFB_NATIVE_FIELD_MODEL",
        "FINAL_BOARD_SIZE": int(len(board_df)), "FINAL_SALARY_RECOMPUTE": board_df["SALARY"].astype(int).tolist() if len(board_df) else [],
        "CFB_CLASSIC_GLOBAL_CORE_NATIVE_AUTHORITY_PARITY_PATCH_ID": CFB_CLASSIC_GLOBAL_CORE_NATIVE_AUTHORITY_PARITY_PATCH_ID,
        "GLOBAL_CORE_PROTECTED_ROWS": int(board_df["GLOBAL_CORE_PROTECTED"].sum()) if len(board_df) else 0,
        "GLOBAL_CORE_STRICT_PROTECTED_ROWS": int(board_df["CFB_STRICT_ELIGIBLE"].sum()) if len(board_df) else 0,
        "GLOBAL_CORE_BALANCE_ESCAPE_PROTECTED_ROWS": int(board_df["CFB_TWO_GAME_BALANCE_ESCAPE"].sum()) if len(board_df) else 0,
        "CFB_CLASSIC_ROLE_STATUS_ALIAS_NORMALIZATION_PATCH_ID": CFB_CLASSIC_ROLE_STATUS_ALIAS_NORMALIZATION_PATCH_ID,
        "CFB_CLASSIC_PREBIRTH_EXTERNAL_ROLE_AUTHORITY": cal.role_evidence_payload.get("external_role_authority_reconciliation"),
        "BOARD_LEGALITY": "PASS" if board_legal else "FAIL", "SELECTOR_STATE": "NONEMPTY_PHASE3_BOARD_COMPLETE", "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "FINAL_BOARD_TARGET": int(np.asarray(metrics.get("final_board_target", np.array([min(cfg.board_size, len(rows))])))[0]),
        "NONEMPTY_BOARD_POLICY": "APEX_GLOBAL_NONEMPTY_PRODUCTION_BOARD_v1",
        "PORTFOLIO_PREFERENCE_RELAXATION": bool(int(np.asarray(metrics.get("portfolio_preference_relaxation", np.array([0])))[0])),
    }
    Path(receipt_path).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return board_df, receipt


def run(pool: str | Path, field_size: int, role_evidence: str | Path, market_evidence: str | Path | None, board_path: str | Path, receipt_path: str | Path,
        seed: int | None = None, config: Config | None = None, availability_receipt: str | Path | None = None, execution_id: str | int | None = None) -> tuple[pd.DataFrame, dict[str, Any]]:
    entry_budget_receipt: dict[str, Any] = {}
    if config is None:
        native_budget, entry_budget_receipt = _resolve_native_portfolio_budget(int(field_size))
        cfg = Config(field_size=int(field_size), seed=int(seed if seed is not None else field_size), board_size=int(native_budget))
    else:
        cfg = config
        entry_budget_receipt = {
            "PATCH_ID": CFB_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO_PATCH_ID,
            "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
            "SOURCE": "EXPLICIT_CONFIG",
            "USER_ENTRY_BUDGET": int(cfg.board_size),
        }
    cfg.validate()
    resolved_execution_id = str(execution_id if execution_id is not None else field_size)
    roster_gate = require_prebuild_roster_check(availability_receipt, sport="CFB", mode="CLASSIC", pool_path=pool, execution_id=resolved_execution_id, field_size=field_size)
    cal = _load_calibration(pool, role_evidence, market_evidence, cfg, roster_gate)
    if set(cal.out_names) != set(roster_gate.out_players):
        raise RuntimeError("RUN_INVALID:CFB_ROLE_EVIDENCE_ROSTER_GATE_OUT_PARITY_MISMATCH")
    legal_scan = _legal_scan_count(cal)
    birth_plan = _build_calibration_qualified_birth_plan(cal, cfg)
    candidates, cmeta = _generate_candidates(cal, cfg, birth_plan)
    candidates, cmeta, fast_path_pre_phase2_receipt = _fast_path_calibration_first_pre_phase2_v1(candidates, cmeta, cal, cfg)
    fast_path_pre_phase2_receipt.update(dict(birth_plan.get("receipt") or {}))
    candidates, cmeta, one_swap_receipt = _pre_phase2_one_swap_championship_closure_v1(candidates, cmeta, cal, cfg)
    phase2, pmeta, p2rec = _phase2(candidates, cmeta, cal, cfg)
    p2rec["CFB_CLASSIC_FAST_PATH_CALIBRATION_FIRST_PRE_PHASE2"] = fast_path_pre_phase2_receipt
    p2rec["CFB_CLASSIC_PRE_PHASE2_ONE_SWAP_CHAMPIONSHIP_CLOSURE"] = one_swap_receipt
    phase2, pmeta, p2rec = _append_scenario_birth_phase2(phase2, pmeta, p2rec, cal, cfg)
    if not len(phase2): raise RuntimeError("RUN_INVALID:CFB_CLASSIC_PHASE2_ZERO")
    phase2_hash = _array_hash(phase2)
    sim = _simulate_phase2(phase2, cal, cfg)
    board, metrics, state = _select(phase2, pmeta, sim, cal, cfg)
    board, reordered_chosen, two_game_order_score, two_game_order_receipt = two_game_order.reorder_selected_board(
        board, np.asarray(metrics["chosen"], dtype=np.int32), frame=cal.frame, p99_player=cal.p99, pos=cal.pos, game=cal.game
    )
    metrics["chosen"] = reordered_chosen
    metrics["two_game_order_score"] = np.asarray(two_game_order_score, dtype=np.float64)
    metrics["two_game_order_receipt"] = two_game_order_receipt
    board_df, receipt = _write_outputs(board, phase2, metrics, pmeta, cal, cfg, p2rec, sim, legal_scan, board_path, receipt_path)
    receipt["SELECTOR_STATE"] = state; receipt["PREBUILD_ROSTER_CHECK"] = gate_receipt(roster_gate)
    receipt["CFB_CLASSIC_MAX_ENTRY_NATIVE_PORTFOLIO"] = entry_budget_receipt
    receipt["NATIVE_PORTFOLIO_TARGET"] = int(cfg.board_size)
    Path(receipt_path).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    if receipt["PHASE2_FREEZE_HASH"] != phase2_hash or receipt["POST_PHASE2_MUTATION_COUNT"] != 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:PHASE2_PARITY_DRIFT")
    return board_df, receipt


def _args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pool", required=True); ap.add_argument("--field-size", required=True, type=int)
    ap.add_argument("--role-evidence", required=True); ap.add_argument("--market-evidence")
    ap.add_argument("--availability-receipt", required=True); ap.add_argument("--execution-id", required=True)
    ap.add_argument("--board", required=True); ap.add_argument("--receipt", required=True); ap.add_argument("--seed", type=int)
    return ap.parse_args()


def main() -> int:
    a = _args()
    try:
        board, receipt = run(a.pool, a.field_size, a.role_evidence, a.market_evidence, a.board, a.receipt, a.seed, availability_receipt=a.availability_receipt, execution_id=a.execution_id)
        print(json.dumps({k: receipt[k] for k in ["ENGINE_ID", "ACTIVE_POOL", "OUT_PURGE", "LEGAL_SCAN_LINEUPS", "PHASE2_BUILT_LINEUPS", "BASE_SIM_TRIALS", "BUBBLE_EXTRA_TRIALS_TOTAL", "BUBBLE_LINEUPS_UNRESOLVED", "HANDOFF_SURVIVORS", "SELECTOR_REVIEWED_LINEUPS", "FINAL_BOARD_SIZE", "EXECUTION_STATE"]}, indent=2))
        if len(board): print(board.to_string(index=False))
        return 0
    except Exception as exc:
        print(json.dumps({"RUN_STATE": "RUN_INVALID", "ENGINE_ID": ENGINE_ID, "FINAL_BOARD_SIZE": 0, "ENGINE_SUBSTITUTION": False, "FAILURE_CODE": f"{type(exc).__name__}:{exc}"}, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
