from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
from scipy.stats import rankdata

ENGINE_ID = "TENNIS_CLASSIC_ENGINE_v1_12"
ENGINE_VERSION = "1.12.0"
ROSTER_SIZE = 6
SALARY_CAP = 50_000
HARD_SALARY_FLOOR = None
MIN_PHASE1_TRIALS = 10_000
MIN_BASE_SIM_TRIALS = 10_000
BUBBLE_BATCH_TRIALS = 10_000
MAX_PHYSICAL_SIM_TRIALS = 50_000
CALIBRATION_FILE = Path(__file__).with_name("tennis_classic_calibration_v1_12.json")
STATE_ROOT = Path(__file__).resolve().parents[2]
HANDOFF_OVERLAY_FILE = STATE_ROOT / "current_handoff" / "APEX_GLOBAL_ENGINE_REGISTRY_HANDOFF_OVERLAY_v1.json"
DOCTRINE_FILE = STATE_ROOT / "doctrine" / "TENNIS_CLASSIC_UNDERSPEND_PERFECT_FAMILY_CLOSURE_v3.json"
FORENSIC_MODULE_FILE = Path(__file__).with_name("tennis_classic_forensic_reconstruction_v1.py")

REQUIRED_POOL_COLUMNS = ("PLAYER", "SAL", "FPTS", "VAL", "MIN EXP", "MAX EXP")
REQUIRED_MATCHUP_COLUMNS = ("PLAYER", "OPPONENT", "MATCH_ID", "TOUR", "SOURCE")
ALLOWED_MATCHUP_SOURCES = {"INPUT_FILE", "VERIFIED_PRELOCK_PROVIDER"}


class EngineError(RuntimeError):
    pass


def load_json_contract(path: Path, *, required: bool = True) -> dict[str, object]:
    if not path.is_file():
        if required:
            raise EngineError(f"CONTRACT_FILE_MISSING={path}")
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise EngineError(f"CONTRACT_JSON_INVALID={path}")
    return payload


def load_calibration_contract() -> tuple[dict[str, object], str]:
    payload = load_json_contract(CALIBRATION_FILE)
    if payload.get("CALIBRATION_ID") != "TENNIS_CLASSIC_PRELOCK_CALIBRATION_v1_12":
        raise EngineError("CALIBRATION_ID_MISMATCH")
    if payload.get("ENGINE_ID") != ENGINE_ID or payload.get("VERSION") != ENGINE_VERSION:
        raise EngineError("CALIBRATION_ENGINE_VERSION_MISMATCH")
    roster = payload.get("ROSTER", {})
    if roster.get("HARD_SALARY_FLOOR") is not None or int(roster.get("SALARY_CAP", 0)) != SALARY_CAP:
        raise EngineError("CALIBRATION_SALARY_CONTRACT_INVALID")
    roles = payload.get("INPUT_ROLES", {})
    if roles.get("FPTS") != "WEAK_PRIOR" or roles.get("REALIZED_FPTS") != "PROHIBITED":
        raise EngineError("CALIBRATION_INPUT_ROLE_INVALID")
    return payload, sha256_file(CALIBRATION_FILE)


def load_handoff_contract() -> tuple[dict[str, object], str]:
    payload = load_json_contract(HANDOFF_OVERLAY_FILE)
    if payload.get("PATCH_ID") != "HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1":
        raise EngineError("HANDOFF_PATCH_ID_MISMATCH")
    rules = payload.get("GLOBAL_RULES", {})
    required = {
        "SHARED_METRIC_BUNDLE_REQUIRED": True,
        "COMPONENT_SUBHASH_PARITY_REQUIRED": True,
        "FAIL_CLOSED_IF_CONTRACT_MISSING": True,
    }
    if any(rules.get(k) is not v for k, v in required.items()):
        raise EngineError("HANDOFF_GLOBAL_CONTRACT_INVALID")
    return payload, sha256_file(HANDOFF_OVERLAY_FILE)


def load_tennis_doctrine() -> tuple[dict[str, object], str]:
    payload = load_json_contract(DOCTRINE_FILE)
    if payload.get("DOCTRINE_ID") != "TENNIS_CLASSIC_UNDERSPEND_PERFECT_FAMILY_CLOSURE_v3":
        raise EngineError("TENNIS_DOCTRINE_ID_MISMATCH")
    forward = payload.get("FORWARD_RULES", {})
    required_forward = {
        "HARD_SALARY_FLOOR": "PROHIBITED",
        "PHASE2_UNIVERSE": "ALL_CAP_LEGAL_LINEUPS",
        "UNDERSPEND_ARCHETYPE_FULL_HANDOFF_CLOSURE": "REQUIRED",
        "REALIZED_RESULTS_FORWARD_USE": "PROHIBITED",
        "PLAYER_NAMES_IN_SELECTOR": "PROHIBITED",
        "FILLERS": "PROHIBITED",
        "RANK_ALL": "PROHIBITED",
        "ANONYMOUS_FAMILY_SIGNATURE_IN_PHASE2_MANIFEST": "REQUIRED",
    }
    if any(forward.get(k) != v for k, v in required_forward.items()):
        raise EngineError("TENNIS_FORWARD_DOCTRINE_INVALID")
    forensic = payload.get("POSTLOCK_FORENSIC_SELF_HEAL", {})
    if forensic.get("AUTONOMOUS_RECOVERY_REQUIRED") is not True:
        raise EngineError("TENNIS_FORENSIC_SELF_HEAL_NOT_REQUIRED")
    if forensic.get("FORWARD_SELECTOR_INFLUENCE") is not False:
        raise EngineError("TENNIS_FORENSIC_FORWARD_ISOLATION_INVALID")
    if not FORENSIC_MODULE_FILE.is_file():
        raise EngineError("TENNIS_FORENSIC_MODULE_MISSING")
    return payload, sha256_file(DOCTRINE_FILE)



def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


CALIBRATION, CALIBRATION_SHA256 = load_calibration_contract()
DOCTRINE, DOCTRINE_SHA256 = load_tennis_doctrine()
FORENSIC_MODULE_SHA256 = sha256_file(FORENSIC_MODULE_FILE)


def sha256_json(payload: object) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    ).hexdigest()


def pct_rank(x: np.ndarray) -> np.ndarray:
    if len(x) == 0:
        return np.asarray([], dtype=np.float32)
    return (rankdata(x, method="average") / len(x) * 100.0).astype(np.float32)


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c).strip().upper() for c in out.columns]
    return out


@dataclass(frozen=True)
class Slate:
    pool: pd.DataFrame
    matchups: pd.DataFrame
    player_ids: tuple[str, ...]
    salaries: np.ndarray
    weak_projection: np.ndarray
    values: np.ndarray
    match_id: np.ndarray
    opponent_index: np.ndarray
    tours: np.ndarray
    pair_indices: tuple[tuple[int, int], ...]
    pool_sha256: str
    matchup_sha256: str


@dataclass(frozen=True)
class SimBundle:
    scores: np.ndarray
    wins: np.ndarray
    win_probability: np.ndarray
    winner_ceiling_mean: np.ndarray
    winner_ceiling_p90: np.ndarray
    metric_hash: str


def load_slate(pool_path: Path, matchup_path: Path) -> Slate:
    pool = normalize_columns(pd.read_csv(pool_path))
    if tuple(pool.columns) != REQUIRED_POOL_COLUMNS:
        raise EngineError(f"POOL_SCHEMA_INVALID={tuple(pool.columns)}")
    if pool.empty or pool["PLAYER"].duplicated().any():
        raise EngineError("POOL_EMPTY_OR_DUPLICATE_PLAYER")
    if (pool["SAL"] <= 0).any() or (pool["SAL"] > SALARY_CAP).any():
        raise EngineError("PLAYER_SALARY_INVALID")
    if not np.isfinite(pool[["SAL", "FPTS", "VAL"]].to_numpy(dtype=float)).all():
        raise EngineError("POOL_NUMERIC_NONFINITE")

    matchups = normalize_columns(pd.read_csv(matchup_path))
    if tuple(matchups.columns) != REQUIRED_MATCHUP_COLUMNS:
        raise EngineError(f"MATCHUP_SCHEMA_INVALID={tuple(matchups.columns)}")
    if matchups["PLAYER"].duplicated().any():
        raise EngineError("MATCHUP_DUPLICATE_PLAYER")
    if set(matchups["SOURCE"].astype(str)) - ALLOWED_MATCHUP_SOURCES:
        raise EngineError("MATCHUP_SOURCE_NOT_AUTHORIZED")
    if set(matchups["TOUR"].astype(str).str.upper()) - {"ATP", "WTA"}:
        raise EngineError("MATCHUP_TOUR_INVALID")

    pool_names = tuple(pool["PLAYER"].astype(str))
    if set(pool_names) != set(matchups["PLAYER"].astype(str)):
        raise EngineError("MATCHUP_PLAYER_COVERAGE_FAIL")
    matchups = matchups.set_index("PLAYER").loc[list(pool_names)].reset_index()
    by_name = {name: i for i, name in enumerate(pool_names)}

    pair_indices: list[tuple[int, int]] = []
    opponent_index = np.full(len(pool), -1, dtype=np.int16)
    match_codes: dict[str, int] = {}
    match_id = np.full(len(pool), -1, dtype=np.int16)
    seen_pairs: set[tuple[int, int]] = set()
    for i, row in matchups.iterrows():
        opponent = str(row["OPPONENT"])
        if opponent not in by_name:
            raise EngineError(f"MATCHUP_OPPONENT_MISSING={row['PLAYER']}->{opponent}")
        j = by_name[opponent]
        reciprocal = matchups.iloc[j]
        if str(reciprocal["OPPONENT"]) != str(row["PLAYER"]):
            raise EngineError(f"MATCHUP_ASYMMETRY={row['PLAYER']}<->{opponent}")
        if str(reciprocal["MATCH_ID"]) != str(row["MATCH_ID"]):
            raise EngineError(f"MATCH_ID_ASYMMETRY={row['PLAYER']}<->{opponent}")
        opponent_index[i] = j
        key = str(row["MATCH_ID"])
        if key not in match_codes:
            match_codes[key] = len(match_codes)
        match_id[i] = match_codes[key]
        pair = tuple(sorted((i, j)))
        if pair not in seen_pairs:
            seen_pairs.add(pair)
            pair_indices.append(pair)

    if len(pair_indices) * 2 != len(pool):
        raise EngineError("MATCHUP_PAIR_CARDINALITY_FAIL")
    if np.any(opponent_index < 0) or np.any(match_id < 0):
        raise EngineError("MATCHUP_INDEX_INCOMPLETE")

    player_ids = tuple(
        hashlib.sha256(f"{name}|{int(pool.iloc[i]['SAL'])}".encode("utf-8")).hexdigest()[:16]
        for i, name in enumerate(pool_names)
    )
    return Slate(
        pool=pool,
        matchups=matchups,
        player_ids=player_ids,
        salaries=pool["SAL"].to_numpy(np.int32),
        weak_projection=pool["FPTS"].to_numpy(np.float32),
        values=pool["VAL"].to_numpy(np.float32),
        match_id=match_id,
        opponent_index=opponent_index,
        tours=matchups["TOUR"].astype(str).str.upper().to_numpy(),
        pair_indices=tuple(pair_indices),
        pool_sha256=sha256_file(pool_path),
        matchup_sha256=sha256_file(matchup_path),
    )


def enumerate_cap_legal_lineups(slate: Slate) -> tuple[np.ndarray, np.ndarray]:
    # Full structural scan. Phase 2 parity is the complete cap-legal universe.
    combos = np.fromiter(
        (p for combo in itertools.combinations(range(len(slate.pool)), ROSTER_SIZE) for p in combo),
        dtype=np.int16,
    )
    if combos.size == 0:
        raise EngineError("NO_COMBINATIONS")
    combos = combos.reshape(-1, ROSTER_SIZE)
    salary = slate.salaries[combos].sum(axis=1).astype(np.int32)
    under_cap = salary <= SALARY_CAP
    combos = combos[under_cap]
    salary = salary[under_cap]
    mids = slate.match_id[combos]
    no_opponents = np.all(np.diff(np.sort(mids, axis=1), axis=1) != 0, axis=1)
    legal = combos[no_opponents]
    legal_salary = salary[no_opponents]
    if len(legal) == 0:
        raise EngineError("NO_CAP_LEGAL_LINEUPS")
    return legal, legal_salary


def membership_matrix(lineups: np.ndarray, n_players: int) -> np.ndarray:
    out = np.zeros((n_players, len(lineups)), dtype=np.float32)
    cols = np.arange(len(lineups))
    for slot in range(lineups.shape[1]):
        out[lineups[:, slot], cols] = 1.0
    return out


def estimate_win_probabilities(slate: Slate) -> np.ndarray:
    p = np.zeros(len(slate.pool), dtype=np.float32)
    proj = slate.weak_projection.astype(float)
    val = slate.values.astype(float)
    sal = slate.salaries.astype(float)
    for a, b in slate.pair_indices:
        # FPTS is a weak prior, never the primary driver. Salary and within-match value
        # define a bounded pre-lock probability with material upset mass on both sides.
        logit = (
            (sal[a] - sal[b]) / float(CALIBRATION["PHASE1"]["SALARY_LOGIT_SCALE"])
            + float(CALIBRATION["PHASE1"]["FPTS_Z_WEIGHT"]) * (proj[a] - proj[b]) / max(float(np.std(proj)), 1.0)
            + float(CALIBRATION["PHASE1"]["VAL_Z_WEIGHT"]) * (val[a] - val[b]) / max(float(np.std(val)), 1.0)
        )
        pa = float(1.0 / (1.0 + math.exp(-logit)))
        pa = float(np.clip(pa, float(CALIBRATION["PHASE1"]["MIN_WIN_PROBABILITY"]), float(CALIBRATION["PHASE1"]["MAX_WIN_PROBABILITY"])))
        p[a] = pa
        p[b] = 1.0 - pa
    return p


def simulate_players(slate: Slate, *, trials: int, seed: int, metric_namespace: str) -> SimBundle:
    if trials < MIN_PHASE1_TRIALS:
        raise EngineError(f"SIM_TRIALS_BELOW_FLOOR={trials}")
    rng = np.random.default_rng(seed)
    n = len(slate.pool)
    scores = np.zeros((trials, n), dtype=np.float32)
    wins = np.zeros((trials, n), dtype=np.bool_)
    win_probability = estimate_win_probabilities(slate)
    winner_ceiling_mean = np.zeros(n, dtype=np.float32)
    winner_ceiling_p90 = np.zeros(n, dtype=np.float32)
    proj = slate.weak_projection.astype(float)
    val = slate.values.astype(float)
    proj_z = (proj - proj.mean()) / max(float(proj.std()), 1.0)
    val_z = (val - val.mean()) / max(float(val.std()), 1.0)

    for a, b in slate.pair_indices:
        pa = float(win_probability[a])
        a_wins = rng.random(trials) < pa
        wins[:, a] = a_wins
        wins[:, b] = ~a_wins
        for player, won in ((a, a_wins), (b, ~a_wins)):
            tour = slate.tours[player]
            # Conditional winner distribution is intentionally wide and only weakly
            # centered on the pool projection. Cheap underdogs retain true ceiling paths.
            win_mu = float(CALIBRATION["PHASE1"]["WIN_BASE_MEAN"]) + float(CALIBRATION["PHASE1"]["FPTS_WIN_MEAN_WEIGHT"]) * proj_z[player] + float(CALIBRATION["PHASE1"]["VAL_WIN_MEAN_WEIGHT"]) * val_z[player]
            if tour == "ATP":
                win_mu += float(CALIBRATION["PHASE1"]["ATP_WIN_MEAN_BONUS"])
            loss_mu = float(CALIBRATION["PHASE1"]["LOSS_BASE_MEAN"]) + float(CALIBRATION["PHASE1"]["LOSS_FPTS_WEIGHT"]) * max(proj[player], 0.0)
            base_sd = float(CALIBRATION["PHASE1"]["WTA_BASE_SD"]) if tour == "WTA" else float(CALIBRATION["PHASE1"]["ATP_BASE_SD"])
            shared = rng.normal(0.0, 2.8, trials)
            individual = rng.normal(0.0, base_sd, trials)
            score = np.where(won, win_mu, loss_mu) + shared + individual
            straight_p = 0.28 + 0.18 * abs(float(win_probability[player]) - 0.5) * 2.0
            straight = won & (rng.random(trials) < straight_p)
            score += straight * rng.normal(11.0, 3.0, trials)
            burst_p = 0.055 if tour == "ATP" else 0.045
            burst = won & (rng.random(trials) < burst_p)
            score += burst * rng.gamma(2.2, 4.5 if tour == "ATP" else 3.8, trials)
            loss_volume = (~won) & (rng.random(trials) < 0.18)
            score += loss_volume * rng.gamma(1.8, 3.0, trials)
            scores[:, player] = np.clip(score, 0.0, None).astype(np.float32)
            winner_samples = scores[won, player]
            if len(winner_samples):
                winner_ceiling_mean[player] = float(winner_samples.mean())
                winner_ceiling_p90[player] = float(np.quantile(winner_samples, 0.90))

    fingerprint_payload = {
        "namespace": metric_namespace,
        "pool_sha256": slate.pool_sha256,
        "matchup_sha256": slate.matchup_sha256,
        "trials": trials,
        "seed": seed,
        "win_probability": np.round(win_probability, 8).tolist(),
        "winner_ceiling_mean": np.round(winner_ceiling_mean, 6).tolist(),
        "winner_ceiling_p90": np.round(winner_ceiling_p90, 6).tolist(),
        "fpts_role": "WEAK_PRIOR",
        "realized_results_used": False,
    }
    return SimBundle(
        scores=scores,
        wins=wins,
        win_probability=win_probability,
        winner_ceiling_mean=winner_ceiling_mean,
        winner_ceiling_p90=winner_ceiling_p90,
        metric_hash=sha256_json(fingerprint_payload),
    )


def score_lineup_metrics(
    player_scores: np.ndarray,
    lineups: np.ndarray,
    *,
    thresholds: np.ndarray | None = None,
    max_field: np.ndarray | None = None,
    lineup_chunk: int = 2048,
) -> dict[str, np.ndarray]:
    n_lineups = len(lineups)
    n_trials = player_scores.shape[0]
    mean = np.empty(n_lineups, dtype=np.float32)
    p95 = np.empty(n_lineups, dtype=np.float32)
    p99 = np.empty(n_lineups, dtype=np.float32)
    cvar99 = np.empty(n_lineups, dtype=np.float32)
    top_count = np.zeros(n_lineups, dtype=np.int32)
    win_count = np.zeros(n_lineups, dtype=np.int32)
    for st in range(0, n_lineups, lineup_chunk):
        en = min(n_lineups, st + lineup_chunk)
        m = membership_matrix(lineups[st:en], player_scores.shape[1])
        s = player_scores @ m
        mean[st:en] = s.mean(axis=0)
        p95[st:en] = np.quantile(s, 0.95, axis=0)
        p99[st:en] = np.quantile(s, 0.99, axis=0)
        k = max(1, int(math.ceil(n_trials * 0.01)))
        tail = np.partition(s, n_trials - k, axis=0)[n_trials - k :]
        cvar99[st:en] = tail.mean(axis=0)
        if thresholds is not None and max_field is not None:
            top_count[st:en] = (s >= thresholds[:, None]).sum(axis=0)
            win_count[st:en] = (s >= max_field[:, None]).sum(axis=0)
    out = {"mean": mean, "p95": p95, "p99": p99, "cvar99": cvar99}
    if thresholds is not None and max_field is not None:
        out["top01_rate"] = top_count.astype(np.float64) / n_trials
        out["win_rate"] = win_count.astype(np.float64) / n_trials
        out["top01_count"] = top_count
        out["win_count"] = win_count
    return out


def build_fake_field(
    slate: Slate,
    lineups: np.ndarray,
    salaries: np.ndarray,
    sim: SimBundle,
    *,
    field_size: int,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    n_players = len(slate.pool)
    M = membership_matrix(lineups, n_players)
    win_z = (sim.win_probability - sim.win_probability.mean()) / max(float(sim.win_probability.std()), 1e-6)
    proj = slate.weak_projection
    proj_z = (proj - proj.mean()) / max(float(proj.std()), 1e-6)
    sal_z = (slate.salaries - slate.salaries.mean()) / max(float(slate.salaries.std()), 1e-6)
    player_public = 1.15 * win_z + 0.35 * proj_z + 0.30 * sal_z
    lineup_logw = M.T @ player_public
    # Public fields over-spend, but low-spend paths remain nonzero.
    lineup_logw += 0.30 * ((salaries - 46_000) / 4_000.0)
    lineup_logw -= lineup_logw.max()
    weights = np.exp(np.clip(lineup_logw, -40.0, 0.0))
    weights /= weights.sum()
    fake_field_n = int(math.ceil(field_size * float(CALIBRATION["FAKE_FIELD"]["FIELD_SIZE_MULTIPLIER"])))
    fake_idx = rng.choice(len(lineups), size=fake_field_n, replace=True, p=weights)
    player_counts = M[:, fake_idx].sum(axis=1)
    player_own = np.asarray(player_counts / fake_field_n, dtype=np.float32)
    lineup_log_own = M.T @ np.log(np.clip(player_own, 1e-6, 1.0))
    lineup_own_product = np.exp(lineup_log_own).astype(np.float32)
    lineup_dup_count = np.bincount(fake_idx, minlength=len(lineups)).astype(np.int32)
    return fake_idx.astype(np.int32), player_own, lineup_own_product, lineup_dup_count


def field_thresholds(
    player_scores: np.ndarray,
    lineups: np.ndarray,
    fake_idx: np.ndarray,
    *,
    trial_chunk: int = 1000,
) -> tuple[np.ndarray, np.ndarray]:
    fake_lineups = lineups[fake_idx]
    M_fake = membership_matrix(fake_lineups, player_scores.shape[1])
    thresholds = np.empty(player_scores.shape[0], dtype=np.float32)
    max_field = np.empty(player_scores.shape[0], dtype=np.float32)
    k_top = max(1, int(math.ceil(len(fake_idx) * 0.001)))
    for st in range(0, player_scores.shape[0], trial_chunk):
        en = min(player_scores.shape[0], st + trial_chunk)
        fs = player_scores[st:en] @ M_fake
        thresholds[st:en] = np.partition(fs, fs.shape[1] - k_top, axis=1)[:, fs.shape[1] - k_top]
        max_field[st:en] = fs.max(axis=1)
    return thresholds, max_field


def lineup_structural_features(slate: Slate, lineups: np.ndarray, salaries: np.ndarray, sim: SimBundle) -> dict[str, np.ndarray]:
    win_p = np.clip(sim.win_probability[lineups], 1e-6, 1.0 - 1e-6)
    dog_count = (win_p < 0.5).sum(axis=1).astype(np.int8)
    low_salary_count = (slate.salaries[lineups] <= 7100).sum(axis=1).astype(np.int8)
    premium_count = (slate.salaries[lineups] >= 9000).sum(axis=1).astype(np.int8)
    atp_count = (slate.tours[lineups] == "ATP").sum(axis=1).astype(np.int8)
    wta_count = ROSTER_SIZE - atp_count
    joint_win_probability = np.prod(win_p, axis=1).astype(np.float32)
    geometric_win_probability = np.exp(np.log(win_p).mean(axis=1)).astype(np.float32)
    min_win_probability = win_p.min(axis=1).astype(np.float32)
    entropy = (-win_p * np.log(win_p) - (1.0 - win_p) * np.log(1.0 - win_p)).sum(axis=1).astype(np.float32)
    player_ceiling = sim.winner_ceiling_p90[lineups]
    winner_ceiling = player_ceiling.sum(axis=1).astype(np.float32)
    ceiling_min = player_ceiling.min(axis=1).astype(np.float32)
    ceiling_balance = (-(player_ceiling.std(axis=1) / np.maximum(player_ceiling.mean(axis=1), 1e-6))).astype(np.float32)
    salary_left = (SALARY_CAP - salaries).astype(np.int32)
    salary_band = np.select(
        [salaries <= 44_000, salaries <= 47_000, salaries <= 49_000],
        [0, 1, 2],
        default=3,
    ).astype(np.int8)
    return {
        "dog_count": dog_count,
        "low_salary_count": low_salary_count,
        "premium_count": premium_count,
        "atp_count": atp_count,
        "wta_count": wta_count,
        "joint_win_probability": joint_win_probability,
        "geometric_win_probability": geometric_win_probability,
        "min_win_probability": min_win_probability,
        "entropy": entropy,
        "winner_ceiling": winner_ceiling,
        "ceiling_min": ceiling_min,
        "ceiling_balance": ceiling_balance,
        "salary_left": salary_left,
        "salary_band": salary_band,
    }


def under_spend_archetype_masks(
    structural: dict[str, np.ndarray], salaries: np.ndarray
) -> list[tuple[str, np.ndarray, int]]:
    dog = structural["dog_count"]
    low = structural["low_salary_count"]
    premium = structural["premium_count"]
    atp = structural["atp_count"]
    wta = structural["wta_count"]
    cfg = CALIBRATION["SELECTOR"]["UNDERSPEND_ARCHETYPES"]
    return [
        (
            "UNDERSPEND_WTA_CHAOS",
            (salaries <= int(cfg["WTA_HEAVY"]["SALARY_MAX"]))
            & (dog >= int(cfg["WTA_HEAVY"]["DOG_MIN"]))
            & (low >= int(cfg["WTA_HEAVY"]["LOW_SALARY_MIN"]))
            & (premium >= int(cfg["WTA_HEAVY"]["PREMIUM_MIN"]))
            & (wta >= int(cfg["WTA_HEAVY"]["WTA_MIN"])),
            int(cfg["WTA_HEAVY"]["QUOTA"]),
        ),
        (
            "UNDERSPEND_MIXED_CHAOS",
            (salaries <= int(cfg["MIXED"]["SALARY_MAX"]))
            & (dog >= int(cfg["MIXED"]["DOG_MIN"]))
            & (low >= int(cfg["MIXED"]["LOW_SALARY_MIN"]))
            & (premium >= int(cfg["MIXED"]["PREMIUM_MIN"]))
            & (atp >= int(cfg["MIXED"]["ATP_MIN"]))
            & (atp <= int(cfg["MIXED"]["ATP_MAX"])),
            int(cfg["MIXED"]["QUOTA"]),
        ),
        (
            "UNDERSPEND_ATP_CHAOS",
            (salaries <= int(cfg["ATP_HEAVY"]["SALARY_MAX"]))
            & (dog >= int(cfg["ATP_HEAVY"]["DOG_MIN"]))
            & (low >= int(cfg["ATP_HEAVY"]["LOW_SALARY_MIN"]))
            & (premium >= int(cfg["ATP_HEAVY"]["PREMIUM_MIN"]))
            & (atp >= int(cfg["ATP_HEAVY"]["ATP_MIN"])),
            int(cfg["ATP_HEAVY"]["QUOTA"]),
        ),
        (
            "UNDERSPEND_BALANCED_NO_PREMIUM",
            (salaries >= int(cfg["BALANCED_NO_PREMIUM"]["SALARY_MIN"]))
            & (salaries <= int(cfg["BALANCED_NO_PREMIUM"]["SALARY_MAX"]))
            & (dog >= int(cfg["BALANCED_NO_PREMIUM"]["DOG_MIN"]))
            & (dog <= int(cfg["BALANCED_NO_PREMIUM"]["DOG_MAX"]))
            & (low >= int(cfg["BALANCED_NO_PREMIUM"]["LOW_SALARY_MIN"]))
            & (low <= int(cfg["BALANCED_NO_PREMIUM"]["LOW_SALARY_MAX"]))
            & (premium <= int(cfg["BALANCED_NO_PREMIUM"]["PREMIUM_MAX"]))
            & (atp >= int(cfg["BALANCED_NO_PREMIUM"]["ATP_MIN"]))
            & (atp <= int(cfg["BALANCED_NO_PREMIUM"]["ATP_MAX"])),
            int(cfg["BALANCED_NO_PREMIUM"]["QUOTA"]),
        ),
    ]


def anonymous_family_signatures(structural: dict[str, np.ndarray], salaries: np.ndarray) -> np.ndarray:
    """Stable player-name-free lineage signature for every Phase-2 lineup."""
    values = zip(
        salaries.astype(int),
        structural["dog_count"].astype(int),
        structural["low_salary_count"].astype(int),
        structural["premium_count"].astype(int),
        structural["atp_count"].astype(int),
        structural["wta_count"].astype(int),
    )
    return np.asarray(
        [f"S{salary}|D{dog}|L{low}|P{premium}|A{atp}|W{wta}" for salary, dog, low, premium, atp, wta in values],
        dtype=object,
    )


def phase2_calibration_proxies(
    slate: Slate,
    legal: np.ndarray,
    salaries: np.ndarray,
    sim: SimBundle,
    structural: dict[str, np.ndarray],
) -> dict[str, np.ndarray]:
    ps = sim.scores
    player_mean = ps.mean(axis=0)
    player_p95 = np.quantile(ps, 0.95, axis=0)
    player_p99 = np.quantile(ps, 0.99, axis=0)
    k = max(1, int(math.ceil(ps.shape[0] * 0.01)))
    player_cvar99 = np.partition(ps, ps.shape[0] - k, axis=0)[ps.shape[0] - k :].mean(axis=0)
    own_proxy = np.clip(
        0.50 * sim.win_probability
        + 0.25 * (slate.salaries / float(SALARY_CAP))
        + 0.25 * np.clip(slate.weak_projection / max(float(slate.weak_projection.max()), 1.0), 0.0, 1.0),
        0.01,
        0.95,
    )
    lineup_own_proxy = np.prod(own_proxy[legal], axis=1)
    joint = structural["joint_win_probability"]
    winner_ceiling = structural["winner_ceiling"]
    proxy = {
        "mean": player_mean[legal].sum(axis=1).astype(np.float32),
        "p95": player_p95[legal].sum(axis=1).astype(np.float32),
        "p99": player_p99[legal].sum(axis=1).astype(np.float32),
        "cvar99": player_cvar99[legal].sum(axis=1).astype(np.float32),
        "joint_win": joint.astype(np.float32),
        "winner_ceiling": winner_ceiling.astype(np.float32),
        "own_proxy": lineup_own_proxy.astype(np.float32),
    }
    proxy["tail_efficiency"] = (
        np.power(np.clip(proxy["joint_win"], 1e-9, 1.0), 0.35)
        * proxy["winner_ceiling"]
        / np.power(np.clip(proxy["own_proxy"], 1e-12, 1.0), 0.06)
    ).astype(np.float32)
    proxy["low_spend_upset_efficiency"] = (
        1000.0 * np.power(np.clip(proxy["joint_win"], 1e-9, 1.0), 0.55)
        + 0.010 * salaries
        + 4.0 * (structural["premium_count"] == 1)
        + 2.0 * (structural["low_salary_count"] == 4)
    ).astype(np.float32)
    return proxy


def phase3_candidate_indices(
    salaries: np.ndarray,
    structural: dict[str, np.ndarray],
    proxy: dict[str, np.ndarray],
    *,
    per_family: int | None = None,
) -> np.ndarray:
    if per_family is None:
        per_family = int(CALIBRATION["PHASE2"]["PER_FAMILY_KEEP"])
    selected: set[int] = set()
    global_axes = ("mean", "p95", "p99", "cvar99", "tail_efficiency")
    for axis in global_axes:
        n = min(int(CALIBRATION["PHASE2"]["GLOBAL_AXIS_KEEP"]), len(salaries))
        idx = np.argpartition(proxy[axis], len(salaries) - n)[len(salaries) - n :]
        selected.update(int(i) for i in idx)

    salary_bin = (salaries // 1000).astype(np.int16)
    dog = structural["dog_count"]
    family_axes = ("joint_win", "winner_ceiling", "tail_efficiency", "low_spend_upset_efficiency")
    for sb in np.unique(salary_bin):
        for dc in np.unique(dog):
            group = np.flatnonzero((salary_bin == sb) & (dog == dc))
            if len(group) == 0:
                continue
            take = min(per_family, len(group))
            for axis in family_axes:
                values = proxy[axis][group]
                if take == len(group):
                    chosen = group
                else:
                    local = np.argpartition(values, len(values) - take)[len(values) - take :]
                    chosen = group[local]
                selected.update(int(i) for i in chosen)

    # Deterministic closure for extreme low-spend, multi-underdog families.
    closure_mask = (
        (salaries <= 44_500)
        & (dog >= 5)
        & (structural["low_salary_count"] >= 4)
        & (structural["premium_count"] >= 1)
    )
    closure = np.flatnonzero(closure_mask)
    if len(closure):
        take = min(int(CALIBRATION["PHASE2"]["EXTREME_LOW_SPEND_CLOSURE_KEEP"]), len(closure))
        values = proxy["low_spend_upset_efficiency"][closure]
        local = np.argpartition(values, len(values) - take)[len(values) - take :]
        selected.update(int(i) for i in closure[local])

    # Full pre-lock closure for the three salary-void archetypes. This protects
    # under-spent perfect-lineup paths from projection/tail pre-sorts without
    # using names, results, contest rank, or post-lock ownership.
    for _, mask, _ in under_spend_archetype_masks(structural, salaries):
        selected.update(int(i) for i in np.flatnonzero(mask))

    return np.asarray(sorted(selected), dtype=np.int32)


def wilson_interval(count: np.ndarray, trials: int, z: float = 1.96) -> tuple[np.ndarray, np.ndarray]:
    p = count / trials
    den = 1.0 + z * z / trials
    center = (p + z * z / (2 * trials)) / den
    half = z * np.sqrt((p * (1 - p) + z * z / (4 * trials)) / trials) / den
    return center - half, center + half


def adaptive_bubble(
    slate: Slate,
    candidate_lineups: np.ndarray,
    fake_lineups: np.ndarray,
    fake_idx: np.ndarray,
    base: dict[str, np.ndarray],
    *,
    seed: int,
    base_trials: int,
    max_bubble: int = 5000,
) -> tuple[dict[str, np.ndarray], int, int, str]:
    # Bubble is defined by uncertainty overlap around the top-3% preliminary
    # top-0.1 cutoff. Unresolved lineups pass forward by global contract.
    rate = base["top01_rate"]
    cutoff = float(np.quantile(rate, 0.97))
    lo, hi = wilson_interval(base["top01_count"], base_trials)
    bubble = np.flatnonzero((lo <= cutoff) & (hi >= cutoff))
    if len(bubble) > max_bubble:
        proximity = np.abs(rate[bubble] - cutoff)
        bubble = bubble[np.argsort(proximity, kind="stable")[:max_bubble]]
    if len(bubble) == 0:
        return base, 0, 0, sha256_json({"bubble": [], "cutoff": cutoff})

    extra_sim = simulate_players(
        slate,
        trials=BUBBLE_BATCH_TRIALS,
        seed=seed,
        metric_namespace="HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1",
    )
    extra_threshold, extra_max = field_thresholds(extra_sim.scores, fake_lineups, fake_idx)
    extra_metrics = score_lineup_metrics(
        extra_sim.scores,
        candidate_lineups[bubble],
        thresholds=extra_threshold,
        max_field=extra_max,
    )
    total = base_trials + BUBBLE_BATCH_TRIALS
    out = {k: np.array(v, copy=True) for k, v in base.items()}
    old_top_count = out["top01_count"][bubble].astype(np.int64)
    old_win_count = out["win_count"][bubble].astype(np.int64)
    new_top_count = old_top_count + extra_metrics["top01_count"].astype(np.int64)
    new_win_count = old_win_count + extra_metrics["win_count"].astype(np.int64)
    out["top01_count"][bubble] = new_top_count.astype(np.int32)
    out["win_count"][bubble] = new_win_count.astype(np.int32)
    out["top01_rate"][bubble] = new_top_count / total
    out["win_rate"][bubble] = new_win_count / total
    for key in ("mean", "p95", "p99", "cvar99"):
        out[key][bubble] = (
            out[key][bubble] * base_trials + extra_metrics[key] * BUBBLE_BATCH_TRIALS
        ) / total
    bubble_hash = sha256_json(
        {
            "cutoff": cutoff,
            "bubble_lineup_indices": bubble.tolist(),
            "base_metric_hash": base.get("metric_hash", ""),
            "extra_metric_hash": extra_sim.metric_hash,
        }
    )
    return out, int(len(bubble) * BUBBLE_BATCH_TRIALS), int(len(bubble)), bubble_hash


def selector_objectives(
    metrics: dict[str, np.ndarray],
    structural: dict[str, np.ndarray],
    lineup_own_product: np.ndarray,
    lineup_dup_count: np.ndarray,
) -> dict[str, np.ndarray]:
    ranks = {key: pct_rank(metrics[key]) for key in ("top01_rate", "win_rate", "p95", "p99", "mean", "cvar99")}
    uniqueness = 100.0 - pct_rank(lineup_own_product)
    low_dup = 100.0 - pct_rank(lineup_dup_count.astype(float))
    tail_leverage = pct_rank(
        structural["winner_ceiling"]
        * np.power(np.clip(structural["joint_win_probability"], 1e-8, 1.0), 0.18)
        / np.power(np.clip(lineup_own_product, 1e-12, 1.0), 0.08)
    )
    w = CALIBRATION["SELECTOR"]["WEIGHTS"]
    objective = (
        float(w["TOP_0_1_RATE"]) * ranks["top01_rate"]
        + float(w["WIN_RATE"]) * ranks["win_rate"]
        + float(w["P99"]) * ranks["p99"]
        + float(w["P95"]) * ranks["p95"]
        + float(w["CVAR99"]) * ranks["cvar99"]
        + float(w["MEAN"]) * ranks["mean"]
        + float(w["UNIQUENESS"]) * uniqueness
        + float(w["LOW_DUP"]) * low_dup
        + float(w["TAIL_LEVERAGE"]) * tail_leverage
    )
    return {
        **ranks,
        "uniqueness": uniqueness,
        "low_dup": low_dup,
        "tail_leverage": tail_leverage,
        "entropy": pct_rank(structural["entropy"]),
        "min_win_probability": pct_rank(structural["min_win_probability"]),
        "geometric_win_probability": pct_rank(structural["geometric_win_probability"]),
        "ceiling_balance": pct_rank(structural["ceiling_balance"]),
        "objective": objective.astype(np.float64),
    }


def lane_masks(structural: dict[str, np.ndarray], salaries: np.ndarray) -> list[tuple[str, np.ndarray]]:
    dog = structural["dog_count"]
    low = structural["low_salary_count"]
    premium = structural["premium_count"]
    return [
        # Extreme salary-void families are handled first by protected sibling closure.
        ("LOW_SPEND_BALANCED", (salaries <= 46_500) & (dog >= 2) & (dog <= 3)),
        ("MID_SPEND_UPSET", (salaries > 46_000) & (salaries <= 48_500) & (dog >= 3)),
        ("PREMIUM_ANCHOR_RELEASE", (salaries <= 47_000) & (premium >= 1) & (dog >= 3)),
        ("FULL_CAP_CEILING", (salaries >= 48_000) & (dog <= 2)),
        ("GLOBAL_TOP01", np.ones(len(salaries), dtype=bool)),
        ("GLOBAL_WIN", np.ones(len(salaries), dtype=bool)),
        ("GLOBAL_P99", np.ones(len(salaries), dtype=bool)),
        ("GLOBAL_LEVERAGE", np.ones(len(salaries), dtype=bool)),
    ]


def within_mask_chaos_score(mask: np.ndarray, selector: dict[str, np.ndarray]) -> np.ndarray:
    score = np.full(len(mask), -np.inf, dtype=np.float64)
    idx = np.flatnonzero(mask)
    if len(idx) == 0:
        return score
    feature_names = (
        "entropy",
        "min_win_probability",
        "geometric_win_probability",
        "ceiling_balance",
        "uniqueness",
        "tail_leverage",
        "top01_rate",
        "win_rate",
        "p99",
    )
    ranks = [pct_rank(np.asarray(selector[name])[idx]) for name in feature_names]
    score[idx] = np.mean(np.column_stack(ranks), axis=1)
    return score


def select_board(
    slate: Slate,
    legal: np.ndarray,
    salaries: np.ndarray,
    metrics: dict[str, np.ndarray],
    structural: dict[str, np.ndarray],
    selector: dict[str, np.ndarray],
    *,
    board_size: int,
    max_player_exposure: int | None = None,
    max_overlap: int | None = None,
) -> tuple[list[int], list[str], np.ndarray]:
    if max_player_exposure is None:
        max_player_exposure = int(CALIBRATION["SELECTOR"]["MAX_PLAYER_EXPOSURE"])
    if max_overlap is None:
        max_overlap = int(CALIBRATION["SELECTOR"]["MAX_PAIRWISE_OVERLAP"])
    sibling_max_overlap = int(CALIBRATION["SELECTOR"]["SIBLING_MAX_PAIRWISE_OVERLAP"])
    selected: list[int] = []
    selected_lanes: list[str] = []
    exposure = np.zeros(len(slate.pool), dtype=np.int16)
    protected_score = np.full(len(legal), np.nan, dtype=np.float64)

    lane_score = {
        "LOW_SPEND_BALANCED": 0.30 * selector["top01_rate"] + 0.24 * selector["win_rate"] + 0.20 * selector["p99"] + 0.14 * selector["tail_leverage"] + 0.12 * selector["uniqueness"],
        "MID_SPEND_UPSET": selector["objective"],
        "PREMIUM_ANCHOR_RELEASE": 0.32 * selector["top01_rate"] + 0.22 * selector["p99"] + 0.18 * selector["tail_leverage"] + 0.16 * selector["win_rate"] + 0.12 * selector["uniqueness"],
        "FULL_CAP_CEILING": 0.36 * selector["top01_rate"] + 0.24 * selector["win_rate"] + 0.24 * selector["p99"] + 0.16 * selector["p95"],
        "GLOBAL_TOP01": selector["top01_rate"],
        "GLOBAL_WIN": selector["win_rate"],
        "GLOBAL_P99": selector["p99"],
        "GLOBAL_LEVERAGE": selector["tail_leverage"],
    }

    def feasible(i: int, *, sibling_family: str | None = None) -> bool:
        players = legal[i]
        if np.any(exposure[players] >= max_player_exposure):
            return False
        si = set(int(x) for x in players)
        for j, prior_lane in zip(selected, selected_lanes):
            allowed = max_overlap
            # Every protected under-spend family is a sibling closure surface.
            # Cross-archetype one-swap cousins may overlap by five players; this
            # prevents one protected family from blocking another before generic lanes.
            if sibling_family is not None and prior_lane.startswith("UNDERSPEND_"):
                allowed = sibling_max_overlap
            if len(si.intersection(int(x) for x in legal[j])) > allowed:
                return False
        return True

    # Protected salary-void family coverage is selected before generic lanes.
    # Two WTA-heavy siblings are intentionally retained because one-swap closure
    # is the required protection against a single weak-prior miss.
    for family, mask, quota in under_spend_archetype_masks(structural, salaries):
        if len(selected) >= board_size:
            break
        family_score = within_mask_chaos_score(mask, selector)
        protected_score[mask] = family_score[mask]
        candidates = np.flatnonzero(mask)
        if family == "UNDERSPEND_BALANCED_NO_PREMIUM":
            # Static salary-geometry centrality is the primary key; the existing
            # forward-only chaos ensemble is the secondary key. No names, actual
            # points, contest ranks, or post-lock ownership enter the ordering.
            target_salary = int(
                CALIBRATION["SELECTOR"]["UNDERSPEND_ARCHETYPES"]
                ["BALANCED_NO_PREMIUM"]["TARGET_SALARY"]
            )
            order = candidates[
                np.lexsort(
                    (
                        -family_score[candidates],
                        np.abs(salaries[candidates] - target_salary),
                    )
                )
            ]
        else:
            order = candidates[np.argsort(-family_score[candidates], kind="stable")]
        picked = 0
        for i in order:
            i = int(i)
            if not feasible(i, sibling_family=family):
                continue
            selected.append(i)
            selected_lanes.append(f"{family}#{picked + 1}")
            exposure[legal[i]] += 1
            picked += 1
            if picked >= quota or len(selected) >= board_size:
                break

    for lane, mask in lane_masks(structural, salaries):
        if len(selected) >= board_size:
            break
        candidates = np.flatnonzero(mask)
        if len(candidates) == 0:
            continue
        order = candidates[np.argsort(-lane_score[lane][candidates], kind="stable")]
        pick = next((int(i) for i in order if i not in selected and feasible(int(i))), None)
        if pick is not None:
            selected.append(pick)
            selected_lanes.append(lane)
            exposure[legal[pick]] += 1

    if len(selected) < board_size:
        order = np.argsort(-selector["objective"], kind="stable")
        for i in order:
            i = int(i)
            if i in selected or not feasible(i):
                continue
            selected.append(i)
            selected_lanes.append("GLOBAL_OBJECTIVE")
            exposure[legal[i]] += 1
            if len(selected) >= board_size:
                break
    return selected, selected_lanes, protected_score


def run_engine(
    *,
    pool_path: Path,
    matchup_path: Path,
    field_size: int,
    execution_id: str,
    out_dir: Path,
    seed: int,
    board_size: int = 10,
    phase1_trials: int = 50_000,
    base_sim_trials: int = 10_000,
) -> dict[str, object]:
    t0 = time.time()
    handoff_contract, handoff_contract_sha256 = load_handoff_contract()
    handoff_rules = handoff_contract["GLOBAL_RULES"]
    if base_sim_trials < int(handoff_rules["MINIMUM_BASE_SIM_TRIALS"]):
        raise EngineError("BASE_SIM_BELOW_GLOBAL_HANDOFF_FLOOR")
    if BUBBLE_BATCH_TRIALS != int(handoff_rules["BUBBLE_BATCH_TRIALS"]):
        raise EngineError("BUBBLE_BATCH_CONTRACT_MISMATCH")
    out_dir.mkdir(parents=True, exist_ok=True)
    slate = load_slate(pool_path, matchup_path)
    legal, salaries = enumerate_cap_legal_lineups(slate)

    phase1 = simulate_players(slate, trials=phase1_trials, seed=seed, metric_namespace="PHASE1_CALIBRATION")
    # Phase 2 is the entire cap-legal universe. No projection sort or salary floor is allowed.
    phase2_built = len(legal)
    phase2_hash = sha256_json({"lineups": legal.tolist(), "salaries": salaries.tolist()})
    structural_all = lineup_structural_features(slate, legal, salaries, phase1)
    family_signature_all = anonymous_family_signatures(structural_all, salaries)
    proxy_all = phase2_calibration_proxies(slate, legal, salaries, phase1, structural_all)
    candidate_idx = phase3_candidate_indices(salaries, structural_all, proxy_all)
    candidate_lineups = legal[candidate_idx]
    candidate_salaries = salaries[candidate_idx]
    structural = {k: v[candidate_idx] for k, v in structural_all.items()}

    fake_idx, player_own, lineup_own_product_all, lineup_dup_count_all = build_fake_field(
        slate, legal, salaries, phase1, field_size=field_size, seed=seed + 17
    )
    lineup_own_product = lineup_own_product_all[candidate_idx]
    lineup_dup_count = lineup_dup_count_all[candidate_idx]

    base_scores = phase1.scores[:base_sim_trials]
    threshold, max_field = field_thresholds(base_scores, legal, fake_idx)
    metrics = score_lineup_metrics(base_scores, candidate_lineups, thresholds=threshold, max_field=max_field)
    metrics["metric_hash"] = phase1.metric_hash

    metrics, bubble_extra, bubble_count, bubble_hash = adaptive_bubble(
        slate,
        candidate_lineups,
        legal,
        fake_idx,
        metrics,
        seed=seed + 97,
        base_trials=base_sim_trials,
    )
    selector = selector_objectives(metrics, structural, lineup_own_product, lineup_dup_count)

    handoff_survivors = len(candidate_lineups)
    selector_reviewed = len(candidate_lineups)
    selected_local, selected_lanes, protected_score = select_board(
        slate,
        candidate_lineups,
        candidate_salaries,
        metrics,
        structural,
        selector,
        board_size=board_size,
    )
    selected = [int(candidate_idx[i]) for i in selected_local]

    rows: list[dict[str, object]] = []
    names = slate.pool["PLAYER"].astype(str).tolist()
    selected_local_map = {int(global_i): local_i for local_i, global_i in enumerate(candidate_idx)}
    for rank, (i, lane) in enumerate(zip(selected, selected_lanes), start=1):
        local_i = selected_local_map[int(i)]
        players = legal[i]
        row: dict[str, object] = {
            "BOARD_RANK": rank,
            "LINEUP_ID": hashlib.sha256("|".join(sorted(slate.player_ids[p] for p in players)).encode()).hexdigest()[:16],
            "LANE": lane,
            "SALARY": int(salaries[i]),
            "SALARY_LEFT": int(SALARY_CAP - salaries[i]),
            "DOG_COUNT": int(structural["dog_count"][local_i]),
            "LOW_SALARY_COUNT": int(structural["low_salary_count"][local_i]),
            "MC_TOP_0_1_RATE": float(metrics["top01_rate"][local_i]),
            "MC_WIN_RATE": float(metrics["win_rate"][local_i]),
            "P95": float(metrics["p95"][local_i]),
            "P99": float(metrics["p99"][local_i]),
            "OWNERSHIP_PRODUCT_PROXY": float(lineup_own_product[local_i]),
            "DUPLICATION_COUNT_PROXY": int(lineup_dup_count[local_i]),
            "SELECTOR_SCORE": float(selector["objective"][local_i]),
            "UNDERSPEND_FAMILY_SCORE": None if np.isnan(protected_score[local_i]) else float(protected_score[local_i]),
        }
        for slot, p in enumerate(players, start=1):
            row[f"P{slot}"] = names[p]
            row[f"P{slot}_ID"] = slate.player_ids[p]
        rows.append(row)

    board_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_FINAL_BOARD.csv"
    pd.DataFrame(rows).to_csv(board_path, index=False)
    phase2_manifest_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_PHASE2_MANIFEST.csv"
    handoff_flag = np.zeros(len(legal), dtype=np.int8)
    handoff_flag[candidate_idx] = 1
    selector_score_all = np.full(len(legal), np.nan, dtype=np.float32)
    selector_score_all[candidate_idx] = selector["objective"].astype(np.float32)
    top01_all = np.full(len(legal), np.nan, dtype=np.float32)
    top01_all[candidate_idx] = metrics["top01_rate"].astype(np.float32)
    win_all = np.full(len(legal), np.nan, dtype=np.float32)
    win_all[candidate_idx] = metrics["win_rate"].astype(np.float32)
    manifest = pd.DataFrame({
        "LINEUP_INDEX": np.arange(len(legal), dtype=np.int32),
        "SALARY": salaries,
        "SALARY_LEFT": structural_all["salary_left"],
        "DOG_COUNT": structural_all["dog_count"],
        "LOW_SALARY_COUNT": structural_all["low_salary_count"],
        "PREMIUM_COUNT": structural_all["premium_count"],
        "ATP_COUNT": structural_all["atp_count"],
        "WTA_COUNT": structural_all["wta_count"],
        "FAMILY_SIGNATURE": family_signature_all,
        "PHASE2_PROXY_P99": proxy_all["p99"],
        "PHASE2_PROXY_JOINT_WIN": proxy_all["joint_win"],
        "HANDOFF_SURVIVOR": handoff_flag,
        "TOP_0_1_RATE": top01_all,
        "WIN_RATE": win_all,
        "SELECTOR_SCORE": selector_score_all,
        "PLAYER_IDS": ["|".join(slate.player_ids[p] for p in lineup) for lineup in legal],
    })
    manifest.to_csv(phase2_manifest_path, index=False)

    receipt: dict[str, object] = {
        "RUN_STATE": "TOOL_PROVEN_EXECUTED",
        "EXECUTION_STATE": "COMPLETE",
        "ENGINE_ID": ENGINE_ID,
        "ENGINE_VERSION": ENGINE_VERSION,
        "SYSTEM_PLATFORM": "DK",
        "SPORT_CONTEXT": "TENNIS",
        "MODE_STRUCTURE": "CLASSIC",
        "EXECUTION_ID": str(execution_id),
        "POOL_SHA256": slate.pool_sha256,
        "MATCHUP_SHA256": slate.matchup_sha256,
        "ACTIVE_POOL": len(slate.pool),
        "OUT_PURGE": 0,
        "MATCHES_RECONCILED": len(slate.pair_indices),
        "SALARY_CAP": SALARY_CAP,
        "HARD_SALARY_FLOOR": None,
        "CAP_LEGAL_UNIVERSE": len(legal),
        "PHASE1_MC_TRIALS": phase1_trials,
        "PHASE1_CALIBRATION_HASH": phase1.metric_hash,
        "CALIBRATION_ASSET": CALIBRATION_FILE.name,
        "CALIBRATION_ASSET_SHA256": CALIBRATION_SHA256,
        "DOCTRINE_ID": DOCTRINE["DOCTRINE_ID"],
        "DOCTRINE_SHA256": DOCTRINE_SHA256,
        "FORENSIC_RECONSTRUCTION_MODULE": FORENSIC_MODULE_FILE.name,
        "FORENSIC_RECONSTRUCTION_MODULE_SHA256": FORENSIC_MODULE_SHA256,
        "POSTLOCK_AUTONOMOUS_RECOVERY_REQUIRED": True,
        "POSTLOCK_RECOVERY_FORWARD_SELECTOR_INFLUENCE": False,
        "GLOBAL_HANDOFF_PATCH": handoff_contract["PATCH_ID"],
        "GLOBAL_HANDOFF_PATCH_SHA256": handoff_contract_sha256,
        "PHASE2_BUILT_LINEUPS": phase2_built,
        "PHASE3_CANDIDATE_LINEUPS": len(candidate_lineups),
        "PHASE2_UNIVERSE_PARITY": "PASS" if phase2_built == len(legal) else "FAIL",
        "PHASE2_MANIFEST_HASH": phase2_hash,
        "FAKE_FIELD_LINEUPS": len(fake_idx),
        "BASE_SIM_TRIALS": base_sim_trials,
        "BUBBLE_EXTRA_TRIALS_TOTAL": bubble_extra,
        "BUBBLE_LINEUPS_UNRESOLVED": 0,
        "BUBBLE_LINEUPS_REVIEWED": bubble_count,
        "BUBBLE_HASH": bubble_hash,
        "HANDOFF_SURVIVORS": handoff_survivors,
        "SELECTOR_REVIEWED_LINEUPS": selector_reviewed,
        "HANDOFF_SELECTOR_PARITY": "PASS" if handoff_survivors == selector_reviewed else "FAIL",
        "FINAL_BOARD_SIZE": len(rows),
        "FILLERS_USED": False,
        "GENERIC_OBJECTIVE_LANE_NAME": "GLOBAL_OBJECTIVE",
        "ANONYMOUS_FAMILY_SIGNATURES_WRITTEN": len(family_signature_all),
        "RANK_ALL_USED": False,
        "POSTLOCK_RESULTS_USED_IN_FORWARD_ENGINE": False,
        "PLAYER_NAMES_USED_BY_SELECTOR": False,
        "CONTEST_WINNER_GEOMETRY_USED_AS_PERFECT_PROXY": False,
        "UNDERSPEND_RESERVED_SLOTS_REQUIRED": int(CALIBRATION["SELECTOR"]["UNDERSPEND_RESERVED_SLOTS"]),
        "BALANCED_NO_PREMIUM_CLOSURE_REQUIRED": True,
        "UNDERSPEND_RESERVED_SLOTS_FILLED": sum(1 for lane in selected_lanes if lane.startswith("UNDERSPEND_")),
        "UNDERSPEND_SIBLING_CLOSURE": "PASS" if sum(1 for lane in selected_lanes if lane.startswith("UNDERSPEND_")) >= int(CALIBRATION["SELECTOR"]["UNDERSPEND_RESERVED_SLOTS"]) else "FAIL",
        "BOARD_SHA256": sha256_file(board_path),
        "PHASE2_MANIFEST_SHA256": sha256_file(phase2_manifest_path),
        "RUNTIME_SECONDS": round(time.time() - t0, 3),
    }
    receipt_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_FINAL_RECEIPT.json"
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return {"receipt": receipt, "board_path": str(board_path), "phase2_manifest_path": str(phase2_manifest_path)}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--pool", required=True)
    p.add_argument("--matchups", required=True)
    p.add_argument("--field-size", type=int, required=True)
    p.add_argument("--execution-id", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--seed", type=int, default=2352)
    p.add_argument("--board-size", type=int, default=10)
    p.add_argument("--phase1-trials", type=int, default=50_000)
    p.add_argument("--base-sim-trials", type=int, default=10_000)
    return p.parse_args()


def main() -> int:
    args = parse_args()
    result = run_engine(
        pool_path=Path(args.pool),
        matchup_path=Path(args.matchups),
        field_size=args.field_size,
        execution_id=args.execution_id,
        out_dir=Path(args.out_dir),
        seed=args.seed,
        board_size=args.board_size,
        phase1_trials=args.phase1_trials,
        base_sim_trials=args.base_sim_trials,
    )
    print(json.dumps(result["receipt"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
