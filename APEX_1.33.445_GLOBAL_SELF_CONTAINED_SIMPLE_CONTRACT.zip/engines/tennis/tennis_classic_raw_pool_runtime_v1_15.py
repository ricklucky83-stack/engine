from __future__ import annotations

import argparse
import dataclasses
import hashlib
import importlib.util
import itertools
import json
import math
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from numba import njit, prange

import importlib.util as _strategy_importlib_util
_STRATEGY_PATH = Path(__file__).resolve().parents[2] / "engines" / "common" / "apex_global_sports_strategy_layer_v1.py"
_strategy_spec = _strategy_importlib_util.spec_from_file_location("apex_global_sports_strategy_layer_v1", _STRATEGY_PATH)
if _strategy_spec is None or _strategy_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_SPORTS_STRATEGY_LAYER_UNAVAILABLE")
global_strategy = _strategy_importlib_util.module_from_spec(_strategy_spec)
_strategy_spec.loader.exec_module(global_strategy)
GLOBAL_SPORTS_STRATEGIST_PATCH_ID = global_strategy.PATCH_ID

STATE_ROOT = Path(__file__).resolve().parents[2]
BASE_ROOT = Path(os.environ.get("APEX_TENNIS_V114_ROOT", str(STATE_ROOT)))
BASE_PATH = BASE_ROOT / "engines" / "tennis" / "tennis_classic_raw_pool_runtime_v1_14.py"
if str(BASE_ROOT) not in sys.path:
    sys.path.insert(0, str(BASE_ROOT))
spec = importlib.util.spec_from_file_location("apex_tennis_v114_base_for_v115", BASE_PATH)
base = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = base
assert spec.loader is not None
spec.loader.exec_module(base)

ENGINE_ID = "TENNIS_CLASSIC_ENGINE_v1_15"
ENGINE_VERSION = "1.15.0"
CALIBRATION_FILE = Path(__file__).with_name("tennis_classic_calibration_v1_15.json")
DOCTRINE_FILE = STATE_ROOT / "doctrine" / "TENNIS_CLASSIC_UNDERSPEND_PERFECT_FAMILY_CLOSURE_v6.json"

def _load_v115_contracts() -> tuple[dict[str, Any], dict[str, Any]]:
    calibration = json.loads(CALIBRATION_FILE.read_text(encoding="utf-8"))
    doctrine = json.loads(DOCTRINE_FILE.read_text(encoding="utf-8"))
    if calibration.get("CALIBRATION_ID") != "TENNIS_CLASSIC_PRELOCK_CALIBRATION_v1_15":
        raise base.EngineError("CALIBRATION_ID_MISMATCH")
    if calibration.get("ENGINE_ID") != ENGINE_ID or calibration.get("VERSION") != ENGINE_VERSION:
        raise base.EngineError("CALIBRATION_ENGINE_VERSION_MISMATCH")
    if calibration.get("ROSTER", {}).get("OPPONENT_COLLISION_PROHIBITED") is not False:
        raise base.EngineError("SAME_MATCH_COEXISTENCE_CONTRACT_MISMATCH")
    if doctrine.get("DOCTRINE_ID") != "TENNIS_CLASSIC_UNDERSPEND_PERFECT_FAMILY_CLOSURE_v6":
        raise base.EngineError("TENNIS_DOCTRINE_ID_MISMATCH")
    forward = doctrine.get("FORWARD_RULES", {})
    required = {
        "CALIBRATION_FIRST": "REQUIRED",
        "COMPLETE_CAP_LEGAL_SCAN_BEFORE_BIRTH": "REQUIRED",
        "SAME_MATCH_COOCCURRENCE": "ALLOWED",
        "MISSING_WEAK_PRIOR_POLICY": "SALARY_NEAREST_10_OBSERVED_MEAN",
        "DETERMINISTIC_SCENARIO_CLOSURE": "REQUIRED",
        "ORDINAL_PERCENTILE_TIE_HANDLING": "REQUIRED",
        "WTA_HEAVY_SALARY_BAND_PORTFOLIO": "REQUIRED",
        "FIXED_MEMORY_THREADED_SCORING": "REQUIRED",
        "REALIZED_RESULTS_FORWARD_USE": "PROHIBITED",
        "PLAYER_NAMES_IN_SELECTOR": "PROHIBITED",
    }
    if any(forward.get(k) != v for k, v in required.items()):
        raise base.EngineError("TENNIS_V115_FORWARD_DOCTRINE_INVALID")
    return calibration, doctrine

CALIBRATION, DOCTRINE = _load_v115_contracts()
CALIBRATION_SHA256 = base.sha256_file(CALIBRATION_FILE)
DOCTRINE_SHA256 = base.sha256_file(DOCTRINE_FILE)
base.CALIBRATION = CALIBRATION
base.CALIBRATION_SHA256 = CALIBRATION_SHA256
base.DOCTRINE = DOCTRINE
base.DOCTRINE_SHA256 = DOCTRINE_SHA256
ROSTER_SIZE = 6
SALARY_CAP = 50_000
SCENARIO_BINS = 64
SCENARIOS_PER_BIN = 24
SCENARIO_PAIR_KEEP = 32
PHASE2_STREAM_CHUNK = int(os.environ.get("APEX_TENNIS_PHASE2_STREAM_CHUNK", "250000"))
LINEUP_SCORE_CHUNK = int(os.environ.get("APEX_TENNIS_LINEUP_SCORE_CHUNK", "4096"))
_LAST_STRATEGY_RECEIPT: dict[str, Any] = {}


@njit(cache=False)
def _count_cap_legal_no_collision(salaries: np.ndarray) -> int:
    n = len(salaries)
    count = 0
    for a in range(n - 5):
        for b in range(a + 1, n - 4):
            for c in range(b + 1, n - 3):
                for d in range(c + 1, n - 2):
                    for e in range(d + 1, n - 1):
                        s5 = salaries[a] + salaries[b] + salaries[c] + salaries[d] + salaries[e]
                        for f in range(e + 1, n):
                            if s5 + salaries[f] <= SALARY_CAP:
                                count += 1
    return count


@njit(cache=False)
def _fill_cap_legal_no_collision(salaries: np.ndarray, lineups: np.ndarray, lineup_salary: np.ndarray) -> int:
    n = len(salaries)
    z = 0
    for a in range(n - 5):
        for b in range(a + 1, n - 4):
            for c in range(b + 1, n - 3):
                for d in range(c + 1, n - 2):
                    for e in range(d + 1, n - 1):
                        s5 = salaries[a] + salaries[b] + salaries[c] + salaries[d] + salaries[e]
                        for f in range(e + 1, n):
                            salary = s5 + salaries[f]
                            if salary > SALARY_CAP:
                                continue
                            lineups[z, 0] = a; lineups[z, 1] = b; lineups[z, 2] = c
                            lineups[z, 3] = d; lineups[z, 4] = e; lineups[z, 5] = f
                            lineup_salary[z] = salary
                            z += 1
    return z


def enumerate_cap_legal_lineups(slate: Any, work_dir: Path) -> tuple[np.ndarray, np.ndarray]:
    work_dir.mkdir(parents=True, exist_ok=True)
    salaries = slate.salaries.astype(np.int32)
    count = int(_count_cap_legal_no_collision(salaries))
    if count <= 0:
        raise base.EngineError("NO_CAP_LEGAL_LINEUPS")
    lineup_path = work_dir / "cap_legal_lineups.i16.mmap"
    salary_path = work_dir / "cap_legal_salary.i32.mmap"
    legal = np.memmap(lineup_path, mode="w+", dtype=np.int16, shape=(count, ROSTER_SIZE))
    legal_salary = np.memmap(salary_path, mode="w+", dtype=np.int32, shape=(count,))
    written = int(_fill_cap_legal_no_collision(salaries, legal, legal_salary))
    if written != count:
        raise base.EngineError(f"CAP_LEGAL_SCAN_COUNT_MISMATCH={written}!={count}")
    legal.flush(); legal_salary.flush()
    return legal, legal_salary


def load_slate(pool_path: Path, matchup_path: Path, availability_gate: Any) -> tuple[Any, np.ndarray]:
    global _LAST_STRATEGY_RECEIPT
    slate = base.load_slate(pool_path, matchup_path, availability_gate)
    missing = slate.pool["FPTS"].to_numpy(dtype=float) <= 0.0
    projection = slate.weak_projection.astype(float).copy()
    values = slate.values.astype(float).copy()
    observed = ~missing
    strategy_frame = slate.pool.copy()
    if "TOUR" not in strategy_frame.columns:
        strategy_frame["TOUR"] = slate.tours
    strategy_features = global_strategy.build_strategy_features(strategy_frame, sport="TENNIS", mode="CLASSIC")
    _LAST_STRATEGY_RECEIPT = strategy_features.receipt
    if np.any(missing):
        if int(observed.sum()) < 10:
            raise base.EngineError("INSUFFICIENT_OBSERVED_WEAK_PRIORS_FOR_NEUTRAL_IMPUTATION")
        observed_idx = np.flatnonzero(observed)
        for i in np.flatnonzero(missing):
            nearest = observed_idx[np.argsort(np.abs(slate.salaries[observed_idx] - slate.salaries[i]), kind="stable")[:10]]
            imputed = float(np.mean(projection[nearest]))
            projection[i] = imputed
            values[i] = imputed / max(float(slate.salaries[i]) / 1000.0, 0.1)
    strategy_multiplier = global_strategy.projection_multiplier(strategy_features, minimum=0.985, maximum=1.025)
    projection *= strategy_multiplier
    values = projection / np.maximum(slate.salaries.astype(float) / 1000.0, 0.1)
    return dataclasses.replace(
        slate,
        weak_projection=projection.astype(np.float32),
        values=values.astype(np.float32),
    ), missing.astype(np.bool_)


def _update_top(
    old_values: np.ndarray | None,
    old_indices: np.ndarray | None,
    new_values: np.ndarray,
    new_indices: np.ndarray,
    keep: int,
) -> tuple[np.ndarray, np.ndarray]:
    if len(new_values) == 0 or keep <= 0:
        if old_values is None:
            return np.asarray([], dtype=np.float32), np.asarray([], dtype=np.int32)
        return old_values, old_indices  # type: ignore[return-value]
    nv = np.asarray(new_values)
    ni = np.asarray(new_indices, dtype=np.int32)
    if old_values is not None and len(old_values):
        values = np.concatenate((old_values, nv))
        indices = np.concatenate((old_indices, ni))  # type: ignore[arg-type]
    else:
        values = nv.copy()
        indices = ni.copy()
    if len(values) > keep:
        local = np.argpartition(values, len(values) - keep)[len(values) - keep:]
        values = values[local]
        indices = indices[local]
    return values, indices


def _player_phase2_arrays(slate: Any, sim: Any) -> dict[str, np.ndarray]:
    ps = sim.scores
    mean = ps.mean(axis=0).astype(np.float32)
    partition = np.partition(ps, (int(math.floor(ps.shape[0] * 0.95)), int(math.floor(ps.shape[0] * 0.99)), ps.shape[0] - max(1, int(math.ceil(ps.shape[0] * 0.01)))), axis=0)
    p95 = partition[int(math.floor(ps.shape[0] * 0.95))].astype(np.float32)
    p99 = partition[int(math.floor(ps.shape[0] * 0.99))].astype(np.float32)
    k = max(1, int(math.ceil(ps.shape[0] * 0.01)))
    cvar99 = partition[ps.shape[0] - k:].mean(axis=0).astype(np.float32)
    own_proxy = np.clip(
        0.50 * sim.win_probability
        + 0.25 * (slate.salaries / float(SALARY_CAP))
        + 0.25 * np.clip(slate.weak_projection / max(float(slate.weak_projection.max()), 1.0), 0.0, 1.0),
        0.01, 0.95,
    ).astype(np.float32)
    return {
        "mean": mean,
        "p95": p95,
        "p99": p99,
        "cvar99": cvar99,
        "own_proxy": own_proxy,
        "log_own": np.log(np.clip(own_proxy, 1e-12, 1.0)).astype(np.float32),
    }


def _proxy_chunk(
    legal_chunk: np.ndarray,
    salaries: np.ndarray,
    structural: dict[str, np.ndarray],
    player: dict[str, np.ndarray],
) -> dict[str, np.ndarray]:
    n = len(legal_chunk)
    mean = np.empty(n, dtype=np.float32); p95 = np.empty(n, dtype=np.float32)
    p99 = np.empty(n, dtype=np.float32); cvar99 = np.empty(n, dtype=np.float32)
    own = np.empty(n, dtype=np.float32)
    base._phase2_proxy_kernel(
        legal_chunk, player["mean"], player["p95"], player["p99"], player["cvar99"],
        player["log_own"], mean, p95, p99, cvar99, own,
    )
    joint = structural["joint_win_probability"].astype(np.float32, copy=False)
    winner_ceiling = structural["winner_ceiling"].astype(np.float32, copy=False)
    tail = (
        np.power(np.clip(joint, 1e-9, 1.0), 0.35)
        * winner_ceiling
        / np.power(np.clip(own, 1e-12, 1.0), 0.06)
    ).astype(np.float32)
    low_eff = (
        1000.0 * np.power(np.clip(joint, 1e-9, 1.0), 0.55)
        + 0.010 * np.asarray(salaries)
        + 4.0 * (structural["premium_count"] == 1)
        + 2.0 * (structural["low_salary_count"] == 4)
    ).astype(np.float32)
    return {
        "mean": mean, "p95": p95, "p99": p99, "cvar99": cvar99,
        "joint_win": joint, "winner_ceiling": winner_ceiling,
        "own_proxy": own, "tail_efficiency": tail,
        "low_spend_upset_efficiency": low_eff,
    }


def _canonical_core_codes_chunk(slate: Any, lineups: np.ndarray, sim: Any, player_own: np.ndarray) -> np.ndarray:
    player_core_score = (
        np.power(np.clip(sim.win_probability, 1e-9, 1.0), 0.35)
        * sim.winner_ceiling_p90
        / np.power(np.clip(player_own, 1e-12, 1.0), 0.06)
    ).astype(np.float32)
    local_scores = player_core_score[np.asarray(lineups)]
    top4_pos = np.argpartition(local_scores, 2, axis=1)[:, 2:]
    core_players = np.take_along_axis(np.asarray(lineups), top4_pos, axis=1)
    core_players.sort(axis=1)
    n = np.uint64(len(slate.pool))
    return (
        core_players[:, 0].astype(np.uint64)
        + n * core_players[:, 1].astype(np.uint64)
        + n**2 * core_players[:, 2].astype(np.uint64)
        + n**3 * core_players[:, 3].astype(np.uint64)
    )


@njit(cache=False, parallel=True)
def _scenario_optimize(scores: np.ndarray, salary_units: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    nsc, n = scores.shape
    out_lo = np.zeros(nsc, dtype=np.uint64)
    out_hi = np.zeros(nsc, dtype=np.uint64)
    best_salary = np.zeros(nsc, dtype=np.int16)
    for t in prange(nsc):
        dp = np.full((7, 501), -1e20, dtype=np.float32)
        lo = np.zeros((7, 501), dtype=np.uint64)
        hi = np.zeros((7, 501), dtype=np.uint64)
        dp[0, 0] = 0.0
        for i in range(n):
            su = int(salary_units[i]); val = scores[t, i]
            bit_lo = np.uint64(0); bit_hi = np.uint64(0)
            if i < 64:
                bit_lo = np.uint64(1) << np.uint64(i)
            else:
                bit_hi = np.uint64(1) << np.uint64(i - 64)
            for k in range(6, 0, -1):
                for b in range(500, su - 1, -1):
                    prev = dp[k - 1, b - su]
                    if prev <= -1e19:
                        continue
                    candidate = prev + val
                    if candidate > dp[k, b]:
                        dp[k, b] = candidate
                        lo[k, b] = lo[k - 1, b - su] | bit_lo
                        hi[k, b] = hi[k - 1, b - su] | bit_hi
        best = -1e20; best_b = 0
        for b in range(501):
            if dp[6, b] > best:
                best = dp[6, b]; best_b = b
        out_lo[t] = lo[6, best_b]; out_hi[t] = hi[6, best_b]; best_salary[t] = best_b
    return out_lo, out_hi, best_salary


def _masks_to_lineups(lo: np.ndarray, hi: np.ndarray, n_players: int) -> np.ndarray:
    rows: list[list[int]] = []
    seen: set[tuple[int, ...]] = set()
    for a, b in zip(lo.tolist(), hi.tolist()):
        ids = [i for i in range(min(n_players, 64)) if (int(a) >> i) & 1]
        if n_players > 64:
            ids.extend(64 + i for i in range(n_players - 64) if (int(b) >> i) & 1)
        if len(ids) != 6:
            raise base.EngineError("SCENARIO_CHAMPION_CARDINALITY_INVALID")
        row = tuple(sorted(ids))
        if row not in seen:
            seen.add(row); rows.append(list(row))
    return np.asarray(rows, dtype=np.int16)


@njit(cache=False, parallel=True)
def _one_swap_refs(
    champions: np.ndarray,
    salary: np.ndarray,
    missing: np.ndarray,
    tours_atp: np.ndarray,
    wp: np.ndarray,
) -> np.ndarray:
    nc = champions.shape[0]; n = len(salary)
    out = np.full((nc * 6 * n, 6), -1, dtype=np.int16)
    for ci in prange(nc):
        row = champions[ci]
        for drop in range(6):
            for add in range(n):
                idx = (ci * 6 + drop) * n + add
                exists = False
                for z in range(6):
                    if z != drop and int(row[z]) == add:
                        exists = True
                if exists:
                    continue
                arr = np.empty(6, dtype=np.int16); q = 0; total_salary = salary[add]
                for z in range(6):
                    if z != drop:
                        arr[q] = row[z]; total_salary += salary[int(row[z])]; q += 1
                if total_salary > 48_000 or total_salary < 43_000:
                    continue
                if salary[add] > salary[int(row[drop])] - 1_000:
                    continue
                arr[5] = add
                miss = 0; atp = 0; dog = 0
                for z in range(6):
                    x = int(arr[z]); miss += missing[x]; atp += tours_atp[x]; dog += wp[x] < 0.5
                if miss != 1 or atp < 3 or atp > 5 or dog < 1 or dog > 3:
                    continue
                arr.sort(); out[idx] = arr
    return out


@njit(cache=False, parallel=True)
def _core_pair_top(
    cores: np.ndarray,
    salary: np.ndarray,
    wp: np.ndarray,
    wc: np.ndarray,
    own: np.ndarray,
    missing: np.ndarray,
    tours_atp: np.ndarray,
    keep: int,
) -> np.ndarray:
    nc = cores.shape[0]
    out = np.full((nc, 2, keep, 2), -1, dtype=np.int16)
    out_score = np.full((nc, 2, keep), -1e300, dtype=np.float64)
    n = len(salary)
    for ci in prange(nc):
        c0 = int(cores[ci, 0]); c1 = int(cores[ci, 1]); c2 = int(cores[ci, 2]); c3 = int(cores[ci, 3])
        if missing[c0] + missing[c1] + missing[c2] + missing[c3] != 0:
            continue
        core_salary = salary[c0] + salary[c1] + salary[c2] + salary[c3]
        core_joint = wp[c0] * wp[c1] * wp[c2] * wp[c3]
        core_wc = wc[c0] + wc[c1] + wc[c2] + wc[c3]
        core_own = own[c0] * own[c1] * own[c2] * own[c3]
        for a in range(n - 1):
            if a == c0 or a == c1 or a == c2 or a == c3:
                continue
            for b in range(a + 1, n):
                if b == c0 or b == c1 or b == c2 or b == c3:
                    continue
                if missing[a] + missing[b] != 1:
                    continue
                final_salary = core_salary + salary[a] + salary[b]
                if final_salary < 47_000 or final_salary > 50_000:
                    continue
                atp = tours_atp[c0] + tours_atp[c1] + tours_atp[c2] + tours_atp[c3] + tours_atp[a] + tours_atp[b]
                if atp < 3 or atp > 5:
                    continue
                dog = (wp[c0] < 0.5) + (wp[c1] < 0.5) + (wp[c2] < 0.5) + (wp[c3] < 0.5) + (wp[a] < 0.5) + (wp[b] < 0.5)
                if dog < 1 or dog > 2:
                    continue
                joint = core_joint * wp[a] * wp[b]
                tail = (joint ** 0.35) * (core_wc + wc[a] + wc[b]) / ((core_own * own[a] * own[b]) ** 0.06)
                value0 = joint; value1 = tail
                for axis in range(2):
                    value = value0 if axis == 0 else value1
                    minimum_index = 0; minimum_value = out_score[ci, axis, 0]
                    for z in range(1, keep):
                        if out_score[ci, axis, z] < minimum_value:
                            minimum_index = z; minimum_value = out_score[ci, axis, z]
                    if value > minimum_value:
                        out_score[ci, axis, minimum_index] = value
                        out[ci, axis, minimum_index, 0] = a
                        out[ci, axis, minimum_index, 1] = b
    return out


@njit(cache=False, parallel=True)
def _core_pair_top_mid_p99(
    cores: np.ndarray,
    salary: np.ndarray,
    player_p99: np.ndarray,
    wp: np.ndarray,
    missing: np.ndarray,
    tours_atp: np.ndarray,
    keep: int,
) -> np.ndarray:
    nc = cores.shape[0]
    out = np.full((nc, keep, 2), -1, dtype=np.int16)
    out_score = np.full((nc, keep), -1e300, dtype=np.float64)
    n = len(salary)
    for ci in prange(nc):
        c0 = int(cores[ci, 0]); c1 = int(cores[ci, 1]); c2 = int(cores[ci, 2]); c3 = int(cores[ci, 3])
        if missing[c0] + missing[c1] + missing[c2] + missing[c3] != 0:
            continue
        core_salary = salary[c0] + salary[c1] + salary[c2] + salary[c3]
        core_p99 = player_p99[c0] + player_p99[c1] + player_p99[c2] + player_p99[c3]
        for a in range(n - 1):
            if a == c0 or a == c1 or a == c2 or a == c3:
                continue
            for b in range(a + 1, n):
                if b == c0 or b == c1 or b == c2 or b == c3:
                    continue
                if missing[a] + missing[b] != 1:
                    continue
                final_salary = core_salary + salary[a] + salary[b]
                if final_salary < 45_000 or final_salary > 47_000:
                    continue
                atp = tours_atp[c0] + tours_atp[c1] + tours_atp[c2] + tours_atp[c3] + tours_atp[a] + tours_atp[b]
                if atp < 4 or atp > 5:
                    continue
                dog = (wp[c0] < 0.5) + (wp[c1] < 0.5) + (wp[c2] < 0.5) + (wp[c3] < 0.5) + (wp[a] < 0.5) + (wp[b] < 0.5)
                if dog < 1 or dog > 3:
                    continue
                low = (salary[c0] <= 7100) + (salary[c1] <= 7100) + (salary[c2] <= 7100) + (salary[c3] <= 7100) + (salary[a] <= 7100) + (salary[b] <= 7100)
                if low < 1 or low > 3:
                    continue
                premium = (salary[c0] >= 9000) + (salary[c1] >= 9000) + (salary[c2] >= 9000) + (salary[c3] >= 9000) + (salary[a] >= 9000) + (salary[b] >= 9000)
                if premium < 1 or premium > 2:
                    continue
                value = core_p99 + player_p99[a] + player_p99[b]
                minimum_index = 0; minimum_value = out_score[ci, 0]
                for z in range(1, keep):
                    if out_score[ci, z] < minimum_value:
                        minimum_index = z; minimum_value = out_score[ci, z]
                if value > minimum_value:
                    out_score[ci, minimum_index] = value
                    out[ci, minimum_index, 0] = a
                    out[ci, minimum_index, 1] = b
    return out


def scenario_closure(slate: Any, sim: Any, missing_prior: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, int]]:
    totals = sim.scores.sum(axis=1)
    order = np.argsort(totals, kind="stable")
    selected_trials: list[int] = []
    for bin_no in range(SCENARIO_BINS):
        lo = bin_no * len(order) // SCENARIO_BINS
        hi = (bin_no + 1) * len(order) // SCENARIO_BINS
        group = order[lo:hi]
        positions = np.linspace(0, len(group) - 1, SCENARIOS_PER_BIN, dtype=int)
        selected_trials.extend(group[positions].tolist())
    scenario_scores = sim.scores[np.asarray(selected_trials, dtype=np.int64)].astype(np.float32, copy=False)
    lo_mask, hi_mask, _ = _scenario_optimize(scenario_scores, (slate.salaries // 100).astype(np.int16))
    champions = _masks_to_lineups(lo_mask, hi_mask, len(slate.pool))

    core_set: set[tuple[int, int, int, int]] = set()
    for row in champions:
        for core in itertools.combinations(row.tolist(), 4):
            core_set.add(tuple(int(x) for x in core))
    cores = np.asarray(sorted(core_set), dtype=np.int16)
    one_raw = _one_swap_refs(
        champions, slate.salaries.astype(np.int32), missing_prior.astype(np.uint8),
        (slate.tours == "ATP").astype(np.uint8), sim.win_probability.astype(np.float64),
    )
    one_swap = one_raw[one_raw[:, 0] >= 0]
    player_own = np.clip(
        0.50 * sim.win_probability
        + 0.25 * (slate.salaries / float(SALARY_CAP))
        + 0.25 * np.clip(slate.weak_projection / max(float(slate.weak_projection.max()), 1.0), 0.0, 1.0),
        0.01, 0.95,
    ).astype(np.float64)
    pair_top = _core_pair_top(
        cores, slate.salaries.astype(np.int32), sim.win_probability.astype(np.float64),
        sim.winner_ceiling_p90.astype(np.float64), player_own,
        missing_prior.astype(np.uint8), (slate.tours == "ATP").astype(np.uint8),
        SCENARIO_PAIR_KEEP,
    )
    player_p99 = np.partition(sim.scores, int(math.floor(sim.scores.shape[0] * 0.99)), axis=0)[int(math.floor(sim.scores.shape[0] * 0.99))].astype(np.float64)
    mid_pair_top = _core_pair_top_mid_p99(
        cores, slate.salaries.astype(np.int32), player_p99,
        sim.win_probability.astype(np.float64), missing_prior.astype(np.uint8),
        (slate.tours == "ATP").astype(np.uint8), 24,
    )
    pair_rows: list[np.ndarray] = []
    for ci, core in enumerate(cores):
        for axis in range(2):
            for z in range(SCENARIO_PAIR_KEEP):
                a, b = pair_top[ci, axis, z]
                if a < 0:
                    continue
                pair_rows.append(np.sort(np.r_[core, [a, b]]).astype(np.int16))
    pair_array = np.asarray(pair_rows, dtype=np.int16) if pair_rows else np.empty((0, 6), dtype=np.int16)
    mid_rows: list[np.ndarray] = []
    for ci, core in enumerate(cores):
        for a, b in mid_pair_top[ci]:
            if a < 0:
                continue
            mid_rows.append(np.sort(np.r_[core, [a, b]]).astype(np.int16))
    mid_array = np.asarray(mid_rows, dtype=np.int16) if mid_rows else np.empty((0, 6), dtype=np.int16)
    closure = np.unique(np.vstack((champions, one_swap, pair_array, mid_array)), axis=0)
    one_unique = np.unique(one_swap, axis=0) if len(one_swap) else np.empty((0, 6), dtype=np.int16)
    mid_unique = np.unique(mid_array, axis=0) if len(mid_array) else np.empty((0, 6), dtype=np.int16)
    receipt = {
        "SCENARIO_TRIALS": int(len(selected_trials)),
        "SCENARIO_CHAMPIONS": int(len(champions)),
        "SCENARIO_CORES": int(len(cores)),
        "SCENARIO_ONE_SWAP_REFS": int(len(one_swap)),
        "SCENARIO_PAIR_REFS": int(len(pair_array)),
        "SCENARIO_MID_PAIR_REFS": int(len(mid_array)),
        "SCENARIO_MID_PAIR_UNIQUE": int(len(mid_unique)),
        "SCENARIO_CLOSURE_UNIQUE": int(len(closure)),
    }
    return closure, one_unique, mid_unique, receipt


@njit(cache=False)
def _binary_search_rows(legal: np.ndarray, targets: np.ndarray) -> np.ndarray:
    out = np.full(len(targets), -1, dtype=np.int32)
    n = len(legal)
    for t in range(len(targets)):
        lo = 0; hi = n - 1
        while lo <= hi:
            mid = (lo + hi) // 2
            cmp = 0
            for j in range(6):
                a = int(legal[mid, j]); b = int(targets[t, j])
                if a < b:
                    cmp = -1; break
                if a > b:
                    cmp = 1; break
            if cmp == 0:
                out[t] = mid; break
            if cmp < 0:
                lo = mid + 1
            else:
                hi = mid - 1
    return out


def streaming_phase2_candidates(
    slate: Any,
    legal: np.ndarray,
    salaries: np.ndarray,
    sim: Any,
    missing_prior: np.ndarray,
    stage,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict[str, int]]:
    player = _player_phase2_arrays(slate, sim)
    global_keep = int(base.CALIBRATION["PHASE2"]["GLOBAL_AXIS_KEEP"])
    per_family = int(base.CALIBRATION["PHASE2"]["PER_FAMILY_KEEP"])
    global_track: dict[str, tuple[np.ndarray | None, np.ndarray | None]] = {
        key: (None, None) for key in ("mean", "p95", "p99", "cvar99", "tail_efficiency")
    }
    family_track: dict[tuple[int, str], tuple[np.ndarray | None, np.ndarray | None]] = {}
    extreme_track: tuple[np.ndarray | None, np.ndarray | None] = (None, None)
    deep_track: dict[str, tuple[np.ndarray | None, np.ndarray | None]] = {
        "UNDERSPEND_MIXED_CHAOS": (None, None),
        "UNDERSPEND_ATP_CHAOS": (None, None),
    }
    deep_all: list[np.ndarray] = []
    moderate_idx_parts: list[np.ndarray] = []
    moderate_code_parts: list[np.ndarray] = []
    moderate_axis_parts: list[np.ndarray] = []

    for st in range(0, len(legal), PHASE2_STREAM_CHUNK):
        en = min(len(legal), st + PHASE2_STREAM_CHUNK)
        lineups = np.asarray(legal[st:en])
        sal = np.asarray(salaries[st:en])
        structural = base.lineup_structural_features(slate, lineups, sal, sim)
        proxy = _proxy_chunk(lineups, sal, structural, player)
        global_indices = np.arange(st, en, dtype=np.int32)

        for axis in global_track:
            ov, oi = global_track[axis]
            global_track[axis] = _update_top(ov, oi, proxy[axis], global_indices, global_keep)

        salary_bin = (sal // 1000).astype(np.int16)
        dog = structural["dog_count"].astype(np.int16, copy=False)
        codes = salary_bin.astype(np.int32) * 8 + dog.astype(np.int32)
        for code in np.unique(codes):
            local_group = np.flatnonzero(codes == code)
            idx = global_indices[local_group]
            for axis in ("joint_win", "winner_ceiling", "tail_efficiency", "low_spend_upset_efficiency"):
                key = (int(code), axis)
                ov, oi = family_track.get(key, (None, None))
                family_track[key] = _update_top(ov, oi, proxy[axis][local_group], idx, per_family)

        extreme_mask = (
            (sal <= 44_500) & (dog >= 5)
            & (structural["low_salary_count"] >= 4)
            & (structural["premium_count"] >= 1)
        )
        hit = np.flatnonzero(extreme_mask)
        if len(hit):
            ov, oi = extreme_track
            extreme_track = _update_top(
                ov, oi, proxy["low_spend_upset_efficiency"][hit], global_indices[hit],
                int(base.CALIBRATION["PHASE2"]["EXTREME_LOW_SPEND_CLOSURE_KEEP"]),
            )

        for family_name, mask, _ in base.under_spend_archetype_masks(structural, sal):
            hit = np.flatnonzero(mask)
            if len(hit) == 0:
                continue
            if family_name in {"UNDERSPEND_WTA_CHAOS", "UNDERSPEND_BALANCED_NO_PREMIUM"}:
                deep_all.append(global_indices[hit])
            else:
                keep_key = "MIXED_KEEP" if family_name == "UNDERSPEND_MIXED_CHAOS" else "ATP_HEAVY_KEEP"
                keep = int(base.CALIBRATION["PHASE2"]["UNDERSPEND_ARCHETYPE_DEEP_CLOSURE"][keep_key])
                ov, oi = deep_track[family_name]
                deep_track[family_name] = _update_top(
                    ov, oi, proxy["low_spend_upset_efficiency"][hit], global_indices[hit], keep,
                )

        moderate_mask = base.moderate_dog_mixed_core_mask(sal, structural)
        hit = np.flatnonzero(moderate_mask)
        if len(hit):
            moderate_idx_parts.append(global_indices[hit])
            moderate_code_parts.append(_canonical_core_codes_chunk(slate, lineups[hit], sim, player["own_proxy"]))
            moderate_axis_parts.append(proxy["mean"][hit])
        if st == 0 or en == len(legal) or (st // PHASE2_STREAM_CHUNK) % 8 == 7:
            stage("PHASE2_STREAM_PROGRESS", scanned=en, total=len(legal))

    parts: list[np.ndarray] = []
    for _, idx in global_track.values():
        if idx is not None and len(idx): parts.append(idx.astype(np.int32, copy=False))
    for _, idx in family_track.values():
        if idx is not None and len(idx): parts.append(idx.astype(np.int32, copy=False))
    if extreme_track[1] is not None and len(extreme_track[1]): parts.append(extreme_track[1].astype(np.int32))
    for _, idx in deep_track.values():
        if idx is not None and len(idx): parts.append(idx.astype(np.int32, copy=False))
    parts.extend(deep_all)

    moderate_selected = np.asarray([], dtype=np.int32)
    if moderate_idx_parts:
        midx = np.concatenate(moderate_idx_parts).astype(np.int32)
        mcode = np.concatenate(moderate_code_parts).astype(np.uint64)
        maxis = np.concatenate(moderate_axis_parts).astype(np.float32)
        order = np.lexsort((midx, -maxis, mcode))
        ordered_code = mcode[order]
        starts = np.r_[0, np.flatnonzero(ordered_code[1:] != ordered_code[:-1]) + 1]
        ends = np.r_[starts[1:], len(order)]
        siblings = int(base.CALIBRATION["PHASE2"]["MODERATE_DOG_MIXED_TOUR_CORE_CLOSURE"]["SIBLINGS_PER_CORE"])
        valid = (ends - starts) >= siblings
        starts = starts[valid]
        if len(starts):
            family_score = maxis[order[starts + siblings - 1]]
            keep = min(int(base.CALIBRATION["PHASE2"]["MODERATE_DOG_MIXED_TOUR_CORE_CLOSURE"]["CORE_FAMILIES_KEEP"]), len(starts))
            if keep < len(starts):
                top = np.argpartition(family_score, len(family_score) - keep)[len(family_score) - keep:]
                starts = starts[top]
            positions = (starts[:, None] + np.arange(siblings, dtype=np.int64)[None, :]).ravel()
            moderate_selected = np.sort(midx[order[positions]]).astype(np.int32)
            parts.append(moderate_selected)

    scenario_lines, one_swap_lines, mid_pair_lines, scenario_receipt = scenario_closure(slate, sim, missing_prior)
    scenario_idx = _binary_search_rows(legal, scenario_lines)
    if np.any(scenario_idx < 0):
        raise base.EngineError(f"SCENARIO_CLOSURE_LEGAL_INDEX_MISSING={int(np.sum(scenario_idx < 0))}")
    scenario_idx = np.unique(scenario_idx).astype(np.int32)
    one_swap_idx = _binary_search_rows(legal, one_swap_lines)
    if np.any(one_swap_idx < 0):
        raise base.EngineError(f"SCENARIO_ONE_SWAP_LEGAL_INDEX_MISSING={int(np.sum(one_swap_idx < 0))}")
    one_swap_idx = np.unique(one_swap_idx).astype(np.int32)
    mid_pair_idx = _binary_search_rows(legal, mid_pair_lines)
    if np.any(mid_pair_idx < 0):
        raise base.EngineError(f"SCENARIO_MID_PAIR_LEGAL_INDEX_MISSING={int(np.sum(mid_pair_idx < 0))}")
    mid_pair_idx = np.unique(mid_pair_idx).astype(np.int32)
    parts.append(scenario_idx)

    if not parts:
        raise base.EngineError("NO_CALIBRATION_QUALIFIED_LINEUPS")
    candidates = np.unique(np.concatenate(parts)).astype(np.int32)
    scenario_receipt["SCENARIO_CLOSURE_MAPPED"] = int(len(scenario_idx))
    scenario_receipt["SCENARIO_ONE_SWAP_MAPPED"] = int(len(one_swap_idx))
    scenario_receipt["SCENARIO_MID_PAIR_MAPPED"] = int(len(mid_pair_idx))
    return candidates, moderate_selected, one_swap_idx, mid_pair_idx, scenario_receipt


def build_fake_field_fixed_memory(
    slate: Any,
    lineups: np.ndarray,
    salaries: np.ndarray,
    sim: Any,
    *,
    field_size: int,
    seed: int,
    lineup_chunk: int = 262_144,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Byte-identical base fake-field construction with contiguous row-chunk reads."""
    rng = np.random.default_rng(seed)
    n_lineups = len(lineups)
    n_players = len(slate.pool)
    win_z = (sim.win_probability - sim.win_probability.mean()) / max(float(sim.win_probability.std()), 1e-6)
    proj = slate.weak_projection
    proj_z = (proj - proj.mean()) / max(float(proj.std()), 1e-6)
    sal_z = (slate.salaries - slate.salaries.mean()) / max(float(slate.salaries.std()), 1e-6)
    player_public = (1.15 * win_z + 0.35 * proj_z + 0.30 * sal_z).astype(np.float32)

    chunk_size = max(1, int(lineup_chunk))
    lineup_logw = np.empty(n_lineups, dtype=np.float32)
    for st in range(0, n_lineups, chunk_size):
        en = min(n_lineups, st + chunk_size)
        block = np.asarray(lineups[st:en])
        values = player_public[block[:, 0]].copy()
        for slot in range(1, ROSTER_SIZE):
            values += player_public[block[:, slot]]
        values += 0.30 * ((np.asarray(salaries[st:en]) - 46_000) / 4_000.0)
        lineup_logw[st:en] = values
    lineup_logw -= float(lineup_logw.max())
    weights = np.exp(np.clip(lineup_logw, -40.0, 0.0), dtype=np.float64)
    cdf = np.cumsum(weights, dtype=np.float64)
    fake_field_n = int(math.ceil(field_size * float(CALIBRATION["FAKE_FIELD"]["FIELD_SIZE_MULTIPLIER"])))
    draws = rng.random(fake_field_n) * cdf[-1]
    fake_idx = np.searchsorted(cdf, draws, side="right").astype(np.int32)
    fake_lineups = np.asarray(lineups[fake_idx])
    player_counts = np.bincount(fake_lineups.ravel(), minlength=n_players)
    player_own = np.asarray(player_counts / fake_field_n, dtype=np.float32)
    log_player_own = np.log(np.clip(player_own, 1e-6, 1.0)).astype(np.float32)

    lineup_log_own = np.empty(n_lineups, dtype=np.float32)
    for st in range(0, n_lineups, chunk_size):
        en = min(n_lineups, st + chunk_size)
        block = np.asarray(lineups[st:en])
        values = log_player_own[block[:, 0]].copy()
        for slot in range(1, ROSTER_SIZE):
            values += log_player_own[block[:, slot]]
        lineup_log_own[st:en] = values
    lineup_own_product = np.exp(lineup_log_own).astype(np.float32)
    lineup_dup_count = np.bincount(fake_idx, minlength=n_lineups).astype(np.int32)
    return fake_idx, player_own, lineup_own_product, lineup_dup_count


def _score_lineup_block(
    player_scores: np.ndarray,
    lineups: np.ndarray,
    thresholds: np.ndarray | None,
    max_field: np.ndarray | None,
) -> dict[str, np.ndarray]:
    n_lineups = len(lineups); n_trials = player_scores.shape[0]
    mean = np.empty(n_lineups, dtype=np.float32); p95 = np.empty(n_lineups, dtype=np.float32)
    p99 = np.empty(n_lineups, dtype=np.float32); cvar99 = np.empty(n_lineups, dtype=np.float32)
    top_count = np.zeros(n_lineups, dtype=np.int32); win_count = np.zeros(n_lineups, dtype=np.int32)
    # Match NumPy's interpolated quantile contract exactly while retaining
    # fixed-memory block scoring. NumPy 2.x evaluates the virtual index in
    # the input floating dtype, so preserve that dtype before partitioning.
    dtype_type = scores_dtype = player_scores.dtype.type
    q95_index = scores_dtype(n_trials - 1) * scores_dtype(0.95)
    q99_index = scores_dtype(n_trials - 1) * scores_dtype(0.99)
    q95_lo = int(math.floor(float(q95_index))); q95_hi = int(math.ceil(float(q95_index)))
    q99_lo = int(math.floor(float(q99_index))); q99_hi = int(math.ceil(float(q99_index)))
    q95_weight = scores_dtype(q95_index - scores_dtype(q95_lo))
    q99_weight = scores_dtype(q99_index - scores_dtype(q99_lo))
    k = max(1, int(math.ceil(n_trials * 0.01))); itail = n_trials - k
    scores = player_scores[:, lineups[:, 0]].copy()
    for slot in range(1, ROSTER_SIZE):
        scores += player_scores[:, lineups[:, slot]]
    mean[:] = scores.mean(axis=0)
    kth = tuple(sorted({q95_lo, q95_hi, q99_lo, q99_hi, itail}))
    partition = np.partition(scores, kth, axis=0)
    p95[:] = partition[q95_lo] + (partition[q95_hi] - partition[q95_lo]) * q95_weight
    p99[:] = partition[q99_lo] + (partition[q99_hi] - partition[q99_lo]) * q99_weight
    cvar99[:] = partition[itail:].mean(axis=0)
    if thresholds is not None and max_field is not None:
        top_count[:] = (scores >= thresholds[:, None]).sum(axis=0)
        win_count[:] = (scores >= max_field[:, None]).sum(axis=0)
    return {
        "mean": mean, "p95": p95, "p99": p99, "cvar99": cvar99,
        "top01_count": top_count, "win_count": win_count,
    }


def score_lineup_metrics(
    player_scores: np.ndarray,
    lineups: np.ndarray,
    *,
    thresholds: np.ndarray | None = None,
    max_field: np.ndarray | None = None,
    lineup_chunk: int = LINEUP_SCORE_CHUNK,
) -> dict[str, np.ndarray]:
    n_lineups = len(lineups); n_trials = player_scores.shape[0]
    mean = np.empty(n_lineups, dtype=np.float32); p95 = np.empty(n_lineups, dtype=np.float32)
    p99 = np.empty(n_lineups, dtype=np.float32); cvar99 = np.empty(n_lineups, dtype=np.float32)
    top_count = np.zeros(n_lineups, dtype=np.int32); win_count = np.zeros(n_lineups, dtype=np.int32)
    if n_lineups == 0:
        result = {"mean": mean, "p95": p95, "p99": p99, "cvar99": cvar99}
        if thresholds is not None and max_field is not None:
            result.update({
                "top01_rate": top_count.astype(np.float64), "win_rate": win_count.astype(np.float64),
                "top01_count": top_count, "win_count": win_count,
            })
        return result
    workers = max(1, min(int(os.environ.get("APEX_TENNIS_SCORE_WORKERS", "5")), os.cpu_count() or 1))
    task_chunk = max(128, min(int(lineup_chunk), int(os.environ.get("APEX_TENNIS_SCORE_TASK_CHUNK", "1024"))))
    ranges = [(st, min(n_lineups, st + task_chunk)) for st in range(0, n_lineups, task_chunk)]

    def process(bounds: tuple[int, int]) -> tuple[int, int, dict[str, np.ndarray]]:
        st, en = bounds
        block = _score_lineup_block(player_scores, np.asarray(lineups[st:en]), thresholds, max_field)
        return st, en, block

    if workers == 1 or len(ranges) == 1:
        completed = map(process, ranges)
        executor = None
    else:
        executor = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="tennis-score")
        completed = executor.map(process, ranges)
    try:
        for st, en, block in completed:
            mean[st:en] = block["mean"]
            p95[st:en] = block["p95"]
            p99[st:en] = block["p99"]
            cvar99[st:en] = block["cvar99"]
            top_count[st:en] = block["top01_count"]
            win_count[st:en] = block["win_count"]
    finally:
        if executor is not None:
            executor.shutdown(wait=True)
    result = {"mean": mean, "p95": p95, "p99": p99, "cvar99": cvar99}
    if thresholds is not None and max_field is not None:
        result.update({
            "top01_rate": top_count.astype(np.float64) / n_trials,
            "win_rate": win_count.astype(np.float64) / n_trials,
            "top01_count": top_count,
            "win_count": win_count,
        })
    return result



def rebalance_wta_salary_bands(
    slate: Any,
    lineups: np.ndarray,
    salaries: np.ndarray,
    structural: dict[str, np.ndarray],
    selector: dict[str, np.ndarray],
    selected: list[int],
    lanes: list[str],
) -> tuple[list[int], list[str]]:
    wta_positions = [i for i, lane in enumerate(lanes) if lane.startswith("UNDERSPEND_WTA_CHAOS")]
    quota = len(wta_positions)
    if quota < 2:
        return selected, lanes
    wta_mask = next(mask for family, mask, _ in base.under_spend_archetype_masks(structural, salaries) if family == "UNDERSPEND_WTA_CHAOS")
    family_score = base.within_mask_chaos_score(wta_mask, selector)
    cfg = base.CALIBRATION["SELECTOR"]["UNDERSPEND_ARCHETYPES"]["WTA_HEAVY"]
    upper_min = int(cfg["SALARY_MAX"]) - int(cfg.get("UPPER_SALARY_BAND_WIDTH", 1000)) + 1
    upper_quota = min(int(cfg.get("UPPER_SALARY_BAND_QUOTA", 2)), quota)
    lower_quota = quota - upper_quota
    fixed_positions = [i for i in range(len(selected)) if i not in wta_positions]
    fixed = [int(selected[i]) for i in fixed_positions]
    fixed_lanes = [str(lanes[i]) for i in fixed_positions]
    exposure = np.zeros(len(slate.pool), dtype=np.int16)
    for i in fixed:
        exposure[lineups[i]] += 1
    max_exposure = int(base.CALIBRATION["SELECTOR"]["MAX_PLAYER_EXPOSURE"])
    sibling_overlap = int(base.CALIBRATION["SELECTOR"]["SIBLING_MAX_PAIRWISE_OVERLAP"])

    chosen: list[int] = []
    def feasible(i: int) -> bool:
        players = lineups[i]
        if np.any(exposure[players] >= max_exposure):
            return False
        si = set(int(x) for x in players)
        for prior in fixed + chosen:
            if len(si.intersection(int(x) for x in lineups[prior])) > sibling_overlap:
                return False
        return True

    candidates = np.flatnonzero(wta_mask)
    lower = candidates[np.asarray(salaries[candidates]) < upper_min]
    upper = candidates[np.asarray(salaries[candidates]) >= upper_min]
    lower_order = lower[np.argsort(-family_score[lower], kind="stable")]
    upper_order = upper[np.argsort(-family_score[upper], kind="stable")]
    for order, need in ((lower_order, lower_quota), (upper_order, upper_quota)):
        picked = 0
        for i in order:
            i = int(i)
            if i in chosen or not feasible(i):
                continue
            chosen.append(i); exposure[lineups[i]] += 1; picked += 1
            if picked >= need:
                break
    if len(chosen) < quota:
        all_order = candidates[np.argsort(-family_score[candidates], kind="stable")]
        for i in all_order:
            i = int(i)
            if i in chosen or not feasible(i):
                continue
            chosen.append(i); exposure[lineups[i]] += 1
            if len(chosen) >= quota:
                break
    if len(chosen) != quota:
        return selected, lanes
    updated_selected = list(selected); updated_lanes = list(lanes)
    for ordinal, (position, pick) in enumerate(zip(wta_positions, chosen), start=1):
        updated_selected[position] = int(pick)
        updated_lanes[position] = f"UNDERSPEND_WTA_CHAOS_BANDED#{ordinal}"
    return updated_selected, updated_lanes


def select_board_banded_base(
    slate: Any,
    legal: np.ndarray,
    salaries: np.ndarray,
    metrics: dict[str, np.ndarray],
    structural: dict[str, np.ndarray],
    selector: dict[str, np.ndarray],
    *,
    moderate_core_mask: np.ndarray | None,
    moderate_core_code: np.ndarray | None,
    board_size: int,
) -> tuple[list[int], list[str], np.ndarray]:
    max_player_exposure = int(base.CALIBRATION["SELECTOR"]["MAX_PLAYER_EXPOSURE"])
    max_overlap = int(base.CALIBRATION["SELECTOR"]["MAX_PAIRWISE_OVERLAP"])
    sibling_max_overlap = int(base.CALIBRATION["SELECTOR"]["SIBLING_MAX_PAIRWISE_OVERLAP"])
    selected: list[int] = []; selected_lanes: list[str] = []
    exposure = np.zeros(len(slate.pool), dtype=np.int16)
    protected_score = np.full(len(legal), np.nan, dtype=np.float64)
    lane_score = {
        "LOW_SPEND_BALANCED": 0.30 * selector["top01_rate"] + 0.24 * selector["win_rate"] + 0.20 * selector["p99"] + 0.14 * selector["tail_leverage"] + 0.12 * selector["uniqueness"],
        "MID_SPEND_UPSET": selector["objective"],
        "PREMIUM_ANCHOR_RELEASE": 0.32 * selector["top01_rate"] + 0.22 * selector["p99"] + 0.18 * selector["tail_leverage"] + 0.16 * selector["win_rate"] + 0.12 * selector["uniqueness"],
        "FULL_CAP_CEILING": 0.36 * selector["top01_rate"] + 0.24 * selector["win_rate"] + 0.24 * selector["p99"] + 0.16 * selector["p95"],
        "GLOBAL_TOP01": selector["top01_rate"], "GLOBAL_WIN": selector["win_rate"],
        "GLOBAL_P99": selector["p99"], "GLOBAL_LEVERAGE": selector["tail_leverage"],
    }
    def feasible(i: int, *, sibling_family: str | None = None) -> bool:
        players = legal[i]
        if np.any(exposure[players] >= max_player_exposure): return False
        si = set(int(x) for x in players)
        for j, prior_lane in zip(selected, selected_lanes):
            allowed = sibling_max_overlap if sibling_family is not None and prior_lane.startswith("UNDERSPEND_") else max_overlap
            if len(si.intersection(int(x) for x in legal[j])) > allowed: return False
        return True
    if moderate_core_mask is not None and moderate_core_code is not None:
        cfg = base.CALIBRATION["SELECTOR"]["MODERATE_BALANCED_RELEASE_CORE_PORTFOLIO"]
        families = base.moderate_balanced_release_core_families(
            salaries, metrics, structural, selector, np.asarray(moderate_core_mask, bool), np.asarray(moderate_core_code, np.uint64)
        )
        direct = int(cfg["DIRECT_ANCHOR_FAMILIES"]); bands = int(cfg["BREADTH_BANDS"]); band_size = int(cfg["BREADTH_BAND_SIZE"])
        for no, family in enumerate(families[:direct], 1):
            pick = int(family["low_i"])
            if feasible(pick, sibling_family="UNDERSPEND_BALANCED_RELEASE_CORE"):
                selected.append(pick); selected_lanes.append(f"UNDERSPEND_BALANCED_RELEASE_CORE_ANCHOR#{no}")
                exposure[legal[pick]] += 1; protected_score[pick] = float(selector["top01_rate"][pick])
            if len(selected) >= board_size: break
        breadth = families[direct:]
        for band_no in range(bands):
            band = breadth[band_no*band_size:(band_no+1)*band_size]
            if not band: break
            band = sorted(band, key=lambda x:(int(salaries[int(x["low_i"])]),-float(x["floor_top01"]),-float(x["avg_top01"]),-float(x["min_objective"]),int(x["core_code"])))
            pick = next((int(f["low_i"]) for f in band if feasible(int(f["low_i"]), sibling_family="UNDERSPEND_BALANCED_RELEASE_CORE")), None)
            if pick is not None:
                selected.append(pick); selected_lanes.append(f"UNDERSPEND_BALANCED_RELEASE_CORE_BREADTH_BAND#{band_no+1}")
                exposure[legal[pick]] += 1; protected_score[pick] = float(selector["top01_rate"][pick])
            if len(selected) >= board_size: break
    for family, mask, quota in base.under_spend_archetype_masks(structural, salaries):
        if len(selected) >= board_size: break
        family_score = base.within_mask_chaos_score(mask, selector); protected_score[mask] = family_score[mask]
        candidates = np.flatnonzero(mask)
        if family == "UNDERSPEND_WTA_CHAOS":
            cfg = base.CALIBRATION["SELECTOR"]["UNDERSPEND_ARCHETYPES"]["WTA_HEAVY"]
            upper_min = int(cfg["SALARY_MAX"]) - int(cfg.get("UPPER_SALARY_BAND_WIDTH", 1000)) + 1
            upper_quota = min(int(cfg.get("UPPER_SALARY_BAND_QUOTA", 2)), int(quota)); lower_quota = int(quota)-upper_quota
            bands = (
                (candidates[np.asarray(salaries[candidates]) < upper_min], lower_quota, "LOWER"),
                (candidates[np.asarray(salaries[candidates]) >= upper_min], upper_quota, "UPPER"),
            )
            picked = 0
            for band_candidates, need, band_name in bands:
                order = band_candidates[np.argsort(-family_score[band_candidates], kind="stable")]
                got = 0
                for i in order:
                    i=int(i)
                    if not feasible(i, sibling_family=family): continue
                    selected.append(i); picked += 1; got += 1
                    selected_lanes.append(f"UNDERSPEND_WTA_CHAOS_{band_name}_BAND#{got}")
                    exposure[legal[i]] += 1
                    if got >= need or len(selected) >= board_size: break
            if picked < int(quota) and len(selected) < board_size:
                order = candidates[np.argsort(-family_score[candidates], kind="stable")]
                for i in order:
                    i=int(i)
                    if i in selected or not feasible(i, sibling_family=family): continue
                    selected.append(i); picked += 1; selected_lanes.append(f"UNDERSPEND_WTA_CHAOS_FALLBACK#{picked}"); exposure[legal[i]] += 1
                    if picked >= int(quota) or len(selected) >= board_size: break
            continue
        if family == "UNDERSPEND_BALANCED_NO_PREMIUM":
            target_salary = int(base.CALIBRATION["SELECTOR"]["UNDERSPEND_ARCHETYPES"]["BALANCED_NO_PREMIUM"]["TARGET_SALARY"])
            order = candidates[np.lexsort((-family_score[candidates], np.abs(salaries[candidates]-target_salary)))]
        else:
            order = candidates[np.argsort(-family_score[candidates], kind="stable")]
        picked=0
        for i in order:
            i=int(i)
            if not feasible(i, sibling_family=family): continue
            selected.append(i); picked += 1; selected_lanes.append(f"{family}#{picked}"); exposure[legal[i]] += 1
            if picked >= int(quota) or len(selected) >= board_size: break
    for lane, mask in base.lane_masks(structural, salaries):
        if len(selected) >= board_size: break
        candidates=np.flatnonzero(mask)
        if len(candidates)==0: continue
        order=candidates[np.argsort(-lane_score[lane][candidates],kind="stable")]
        pick=next((int(i) for i in order if i not in selected and feasible(int(i))),None)
        if pick is not None:
            selected.append(pick); selected_lanes.append(lane); exposure[legal[pick]] += 1
    if len(selected)<board_size:
        for i in np.argsort(-selector["objective"],kind="stable"):
            i=int(i)
            if i in selected or not feasible(i): continue
            selected.append(i); selected_lanes.append("GLOBAL_OBJECTIVE"); exposure[legal[i]] += 1
            if len(selected)>=board_size: break
    return selected, selected_lanes, protected_score

def select_board(
    slate: Any,
    candidate_lineups: np.ndarray,
    candidate_salaries: np.ndarray,
    metrics: dict[str, np.ndarray],
    structural: dict[str, np.ndarray],
    proxy: dict[str, np.ndarray],
    selector: dict[str, np.ndarray],
    moderate_core_mask: np.ndarray,
    moderate_core_code: np.ndarray,
    scenario_one_swap_mask: np.ndarray,
    scenario_mid_pair_mask: np.ndarray,
    missing_prior: np.ndarray,
    board_size: int,
) -> tuple[list[int], list[str], np.ndarray]:
    original_selected, original_lanes, protected = select_board_banded_base(
        slate, candidate_lineups, candidate_salaries, metrics, structural, selector,
        moderate_core_mask=moderate_core_mask,
        moderate_core_code=moderate_core_code,
        board_size=board_size,
    )
    if board_size < 2:
        return original_selected, original_lanes, protected
    keep_n = max(0, board_size - 2)
    selected = list(original_selected[:keep_n]); lanes = list(original_lanes[:keep_n])
    exposure = np.zeros(len(slate.pool), dtype=np.int16)
    for i in selected:
        exposure[candidate_lineups[i]] += 1
    max_exposure = int(base.CALIBRATION["SELECTOR"]["MAX_PLAYER_EXPOSURE"])
    max_overlap = int(base.CALIBRATION["SELECTOR"]["MAX_PAIRWISE_OVERLAP"])
    sibling_overlap = int(base.CALIBRATION["SELECTOR"]["SIBLING_MAX_PAIRWISE_OVERLAP"])

    missing_count = missing_prior[candidate_lineups].sum(axis=1)
    missing_index = np.full(len(candidate_lineups), -1, dtype=np.int16)
    one_missing = np.flatnonzero(missing_count == 1)
    if len(one_missing):
        rows = candidate_lineups[one_missing]
        pos = np.argmax(missing_prior[rows], axis=1)
        missing_index[one_missing] = rows[np.arange(len(rows)), pos]
    eligible = (
        scenario_mid_pair_mask
        & (candidate_salaries >= 45_000) & (candidate_salaries <= 47_000)
        & (structural["dog_count"] == 2)
        & (structural["low_salary_count"] == 2)
        & (structural["premium_count"] == 1)
        & (structural["atp_count"] == 5)
        & (missing_count == 1)
    )
    eligible_idx = np.flatnonzero(eligible)
    scenario_order = np.asarray([], dtype=np.int32)
    if len(eligible_idx):
        missing_ids = np.unique(missing_index[eligible_idx])
        best_missing = int(
            missing_ids[np.argmax(np.asarray([float(_CURRENT_SIM.win_probability[x]) for x in missing_ids]))]
        )
        family = eligible_idx[missing_index[eligible_idx] == best_missing]
        salary_midpoint = 46_000
        salary_values = np.unique(candidate_salaries[family])
        best_salary = int(salary_values[np.argmin(np.abs(salary_values - salary_midpoint))])
        group = family[candidate_salaries[family] == best_salary]
        group_lineups = candidate_lineups[group]
        player_wp = _CURRENT_SIM.win_probability[group_lineups].astype(np.float64)
        player_salary = slate.salaries[group_lineups].astype(np.float64)
        compact_features = (
            proxy["mean"][group],
            proxy["tail_efficiency"][group],
            structural["joint_win_probability"][group],
            structural["entropy"][group],
            player_wp.min(axis=1),
            player_wp.max(axis=1),
            player_salary.std(axis=1),
            player_salary.min(axis=1),
            player_salary.max(axis=1),
        )
        percentile_columns = []
        for feature in compact_features:
            values = np.asarray(feature)
            order = np.argsort(values, kind="stable")
            ranks = np.empty(len(values), dtype=np.float64)
            ranks[order] = (np.arange(len(values), dtype=np.float64) + 0.5) / max(len(values), 1) * 100.0
            percentile_columns.append(ranks)
        percentile_matrix = np.column_stack(percentile_columns)
        centrality = np.mean(np.abs(percentile_matrix - 50.0), axis=1)
        scenario_order = group[np.lexsort((group, -proxy["tail_efficiency"][group], centrality))].astype(np.int32)

    def feasible(i: int) -> bool:
        players = candidate_lineups[i]
        if np.any(exposure[players] >= max_exposure):
            return False
        player_set = set(int(x) for x in players)
        for prior, lane in zip(selected, lanes):
            allowed = sibling_overlap if lane.startswith("UNDERSPEND_") else max_overlap
            if len(player_set.intersection(int(x) for x in candidate_lineups[prior])) > allowed:
                return False
        return True

    for i in scenario_order:
        i = int(i)
        if i in selected or not feasible(i):
            continue
        selected.append(i)
        lanes.append(f"UNDERSPEND_SCENARIO_MEDIAN_UNCERTAINTY_CORE#{len(selected) - keep_n}")
        exposure[candidate_lineups[i]] += 1
        protected[i] = float(proxy["tail_efficiency"][i])
        if len(selected) >= board_size:
            break
    for i, lane in zip(original_selected[keep_n:], original_lanes[keep_n:]):
        if len(selected) >= board_size:
            break
        if i in selected or not feasible(int(i)):
            continue
        selected.append(int(i)); lanes.append(lane); exposure[candidate_lineups[int(i)]] += 1
    if len(selected) < board_size:
        for i in np.argsort(-selector["objective"], kind="stable"):
            i = int(i)
            if i in selected or not feasible(i):
                continue
            selected.append(i); lanes.append("GLOBAL_OBJECTIVE"); exposure[candidate_lineups[i]] += 1
            if len(selected) >= board_size: break
    return selected, lanes, protected


_CURRENT_SIM: Any = None


def run_engine(
    *, pool_path: Path, matchup_path: Path, field_size: int, execution_id: str,
    out_dir: Path, seed: int, availability_receipt: Path, board_size: int = 10,
    phase1_trials: int = 50_000, base_sim_trials: int = 10_000,
) -> dict[str, Any]:
    global _CURRENT_SIM
    t0 = time.time(); out_dir.mkdir(parents=True, exist_ok=True)
    stage_path = out_dir / "runtime_stage.log"; stage_path.write_text("", encoding="utf-8")
    def stage(name: str, **values: Any) -> None:
        payload = {"stage": name, "elapsed_seconds": round(time.time() - t0, 3), **values}
        with stage_path.open("a", encoding="utf-8") as handle: handle.write(json.dumps(payload, sort_keys=True) + "\n")
        print(json.dumps(payload, sort_keys=True), flush=True)

    stage("START", engine_id=ENGINE_ID, execution_id=str(execution_id))
    handoff_contract, handoff_sha = base.load_handoff_contract()
    availability_gate = base.validate_prebuild_availability_receipt(
        availability_receipt, sport="TENNIS", mode="CLASSIC", pool_path=pool_path,
        execution_id=execution_id, field_size=field_size,
    )
    slate, missing_prior = load_slate(pool_path, matchup_path, availability_gate)
    stage("SLATE_LOADED", active_pool=len(slate.pool), matches=len(slate.pair_indices), missing_weak_priors=int(missing_prior.sum()), global_sports_strategist_patch_id=GLOBAL_SPORTS_STRATEGIST_PATCH_ID, strategy_contract_hash=_LAST_STRATEGY_RECEIPT.get("CONTRACT_HASH"))
    legal, salaries = enumerate_cap_legal_lineups(slate, out_dir / "work")
    stage("CAP_LEGAL_SCAN_COMPLETE", lineups=len(legal), opponent_collision_prohibited=False)
    phase1 = base.simulate_players(slate, trials=phase1_trials, seed=seed, metric_namespace="PHASE1_CALIBRATION")
    _CURRENT_SIM = phase1
    stage("PHASE1_CALIBRATION_COMPLETE", trials=phase1_trials)

    candidate_idx, moderate_core_idx, one_swap_global, mid_pair_global, scenario_receipt = streaming_phase2_candidates(
        slate, legal, salaries, phase1, missing_prior, stage
    )
    candidate_lineups = np.asarray(legal[candidate_idx]); candidate_salaries = np.asarray(salaries[candidate_idx])
    structural = base.lineup_structural_features(slate, candidate_lineups, candidate_salaries, phase1)
    player_arrays = _player_phase2_arrays(slate, phase1)
    proxy = _proxy_chunk(candidate_lineups, candidate_salaries, structural, player_arrays)
    moderate_set = set(int(x) for x in moderate_core_idx)
    moderate_mask = np.asarray([int(x) in moderate_set for x in candidate_idx], dtype=bool)
    moderate_code = base.canonical_core_codes(slate, candidate_lineups, phase1)
    one_swap_set = set(int(x) for x in one_swap_global)
    one_swap_mask = np.asarray([int(x) in one_swap_set for x in candidate_idx], dtype=bool)
    mid_pair_set = set(int(x) for x in mid_pair_global)
    mid_pair_mask = np.asarray([int(x) in mid_pair_set for x in candidate_idx], dtype=bool)
    family_signature = base.anonymous_family_signatures(structural, candidate_salaries)
    phase2_hash = base.sha256_json({"candidate_indices": candidate_idx.tolist(), "candidate_salaries": candidate_salaries.tolist()})
    stage("PHASE2_BIRTH_COMPLETE", phase2_built=len(candidate_idx), moderate_core_births=len(moderate_core_idx), **scenario_receipt)

    fake_idx, player_own, lineup_own_all, lineup_dup_all = build_fake_field_fixed_memory(
        slate, legal, salaries, phase1, field_size=field_size, seed=seed + 17
    )
    lineup_own = lineup_own_all[candidate_idx]; lineup_dup = lineup_dup_all[candidate_idx]
    stage("FAKE_FIELD_COMPLETE", fake_field_lineups=len(fake_idx))
    base_scores = phase1.scores[:base_sim_trials]
    threshold, max_field = base.field_thresholds(base_scores, legal, fake_idx)
    stage("FIELD_THRESHOLDS_COMPLETE")
    metrics = score_lineup_metrics(base_scores, candidate_lineups, thresholds=threshold, max_field=max_field)
    metrics["metric_hash"] = phase1.metric_hash
    stage("BASE_SIM_SCORING_COMPLETE", candidate_lineups=len(candidate_lineups), base_trials=base_sim_trials)
    original_score = base.score_lineup_metrics
    base.score_lineup_metrics = score_lineup_metrics
    try:
        metrics, bubble_extra, bubble_count, bubble_hash = base.adaptive_bubble(
            slate, candidate_lineups, legal, fake_idx, metrics,
            seed=seed + 97, base_trials=base_sim_trials,
        )
    finally:
        base.score_lineup_metrics = original_score
    stage("ADAPTIVE_BUBBLE_COMPLETE", bubble_extra_trials=bubble_extra, bubble_lineups=bubble_count)
    selector = base.selector_objectives(metrics, structural, lineup_own, lineup_dup)
    base.validate_prebuild_availability_receipt(
        availability_receipt, sport="TENNIS", mode="CLASSIC", pool_path=pool_path,
        execution_id=execution_id, field_size=field_size, final_selector_recheck=True,
    )
    selected_local, selected_lanes, protected = select_board(
        slate, candidate_lineups, candidate_salaries, metrics, structural, proxy, selector,
        moderate_mask, moderate_code, one_swap_mask, mid_pair_mask, missing_prior, board_size,
    )
    stage("BOARD_SELECTION_COMPLETE", final_board_size=len(selected_local), lanes=selected_lanes)

    names = slate.pool["PLAYER"].astype(str).tolist(); rows: list[dict[str, Any]] = []
    for rank, (local_i, lane) in enumerate(zip(selected_local, selected_lanes), start=1):
        players = candidate_lineups[local_i]
        row: dict[str, Any] = {
            "BOARD_RANK": rank,
            "LINEUP_ID": hashlib.sha256("|".join(sorted(slate.player_ids[p] for p in players)).encode()).hexdigest()[:16],
            "LANE": lane,
            "SALARY": int(candidate_salaries[local_i]),
            "SALARY_LEFT": int(SALARY_CAP - candidate_salaries[local_i]),
            "DOG_COUNT": int(structural["dog_count"][local_i]),
            "LOW_SALARY_COUNT": int(structural["low_salary_count"][local_i]),
            "MC_TOP_0_1_RATE": float(metrics["top01_rate"][local_i]),
            "MC_WIN_RATE": float(metrics["win_rate"][local_i]),
            "P95": float(metrics["p95"][local_i]),
            "P99": float(metrics["p99"][local_i]),
            "OWNERSHIP_PRODUCT_PROXY": float(lineup_own[local_i]),
            "DUPLICATION_COUNT_PROXY": int(lineup_dup[local_i]),
            "SELECTOR_SCORE": float(selector["objective"][local_i]),
            "UNDERSPEND_FAMILY_SCORE": None if np.isnan(protected[local_i]) else float(protected[local_i]),
        }
        for slot, p in enumerate(players, 1):
            row[f"P{slot}"] = names[p]; row[f"P{slot}_ID"] = slate.player_ids[p]
        rows.append(row)
    if len(rows) != board_size or any(len({row[f'P{i}_ID'] for i in range(1, 7)}) != 6 for row in rows):
        raise RuntimeError('RUN_FAIL:TENNIS_BOARD_IDENTITY_RECONCILIATION')
    print(json.dumps({
        'RUN_STATE':'BOARD_READY',
        'PRODUCTION_TRIGGER_DIRECT_EXECUTION':'PASS',
        'DIAGNOSTIC_ROUTING':'DISABLED',
        'BOARD_FIRST_RENDERING':'PASS',
        'BOARD_FIRST_DOCTRINE':'BOARD_FIRST_RENDERING_v2',
        'BOARD_IDENTITY_RECONCILIATION':'PASS',
        'FINAL_BOARD_SIZE':len(rows),
        'FINAL_BOARD':rows,
    }, indent=2), flush=True)
    board_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_FINAL_BOARD.csv"
    pd.DataFrame(rows).to_csv(board_path, index=False)
    manifest_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_PHASE2_MANIFEST.csv"
    pd.DataFrame({
        "LINEUP_INDEX": candidate_idx,
        "SALARY": candidate_salaries,
        "SALARY_LEFT": structural["salary_left"],
        "DOG_COUNT": structural["dog_count"],
        "LOW_SALARY_COUNT": structural["low_salary_count"],
        "PREMIUM_COUNT": structural["premium_count"],
        "ATP_COUNT": structural["atp_count"],
        "WTA_COUNT": structural["wta_count"],
        "MISSING_WEAK_PRIOR_COUNT": missing_prior[candidate_lineups].sum(axis=1),
        "FAMILY_SIGNATURE": family_signature,
        "PHASE2_PROXY_P99": proxy["p99"],
        "PHASE2_PROXY_JOINT_WIN": proxy["joint_win"],
        "MODERATE_DOG_MIXED_CORE_CLOSURE": moderate_mask.astype(np.int8),
        "SCENARIO_ONE_SWAP_CLOSURE": one_swap_mask.astype(np.int8),
        "SCENARIO_MID_PAIR_CLOSURE": mid_pair_mask.astype(np.int8),
        "CANONICAL_CORE_CODE": moderate_code,
        "HANDOFF_SURVIVOR": np.ones(len(candidate_idx), dtype=np.int8),
        "TOP_0_1_RATE": metrics["top01_rate"],
        "WIN_RATE": metrics["win_rate"],
        "SELECTOR_SCORE": selector["objective"],
        "PLAYER_IDS": ["|".join(slate.player_ids[p] for p in lineup) for lineup in candidate_lineups],
    }).to_csv(manifest_path, index=False)
    receipt = {
        "RUN_STATE": "TOOL_PROVEN_EXECUTED", "EXECUTION_STATE": "COMPLETE",
        "PRODUCTION_TRIGGER_DIRECT_EXECUTION": "PASS", "DIAGNOSTIC_ROUTING": "DISABLED",
        "BOARD_FIRST_RENDERING": "PASS", "BOARD_IDENTITY_RECONCILIATION": "PASS",
        "ENGINE_ID": ENGINE_ID, "ENGINE_VERSION": ENGINE_VERSION,
        "SYSTEM_PLATFORM": "DK", "SPORT_CONTEXT": "TENNIS", "MODE_STRUCTURE": "CLASSIC",
        "EXECUTION_ID": str(execution_id), "EXECUTION_SEED": int(seed),
        "POOL_SHA256": slate.pool_sha256, "MATCHUP_SHA256": slate.matchup_sha256,
        "ACTIVE_POOL": len(slate.pool), "OUT_PURGE": 0, "MATCHES_RECONCILED": len(slate.pair_indices),
        "MISSING_WEAK_PRIORS_IMPUTED": int(missing_prior.sum()),
        "MISSING_WEAK_PRIOR_POLICY": "SALARY_NEAREST_10_OBSERVED_MEAN",
        "SALARY_CAP": SALARY_CAP, "HARD_SALARY_FLOOR": None,
        "OPPONENT_COLLISION_PROHIBITED": False,
        "CAP_LEGAL_SCANNED": len(legal), "PHASE1_MC_TRIALS": phase1_trials,
        "PHASE1_CALIBRATION_HASH": phase1.metric_hash,
        "PREDICTIVE_LAYER_PATCH_ID": _LAST_STRATEGY_RECEIPT["PREDICTIVE_LAYER_PATCH_ID"],
        "PREDICTIVE_LAYER_STATUS": _LAST_STRATEGY_RECEIPT["PREDICTIVE_LAYER_STATUS"],
        "PREDICTION_HASH": _LAST_STRATEGY_RECEIPT["PREDICTION_HASH"],
        "RAW_MARKET_INPUT_HASH": _LAST_STRATEGY_RECEIPT["RAW_MARKET_INPUT_HASH"],
        "PLAYER_MARKET_ROWS": _LAST_STRATEGY_RECEIPT["PLAYER_MARKET_ROWS"],
        "GAME_MARKET_ROWS": _LAST_STRATEGY_RECEIPT["GAME_MARKET_ROWS"],
        "MORE_DECISIONS": _LAST_STRATEGY_RECEIPT["MORE_DECISIONS"],
        "LESS_DECISIONS": _LAST_STRATEGY_RECEIPT["LESS_DECISIONS"],
        "PASS_DECISIONS": _LAST_STRATEGY_RECEIPT["PASS_DECISIONS"],
        "STALE_LINE_SIGNALS": _LAST_STRATEGY_RECEIPT["STALE_LINE_SIGNALS"],
        "PREDICTION_FROZEN": _LAST_STRATEGY_RECEIPT["PREDICTION_FROZEN"],
        "STRATEGY_CONSUMED_PREDICTION_HASH": _LAST_STRATEGY_RECEIPT["STRATEGY_CONSUMED_PREDICTION_HASH"],
        "PHASE2_BUILT_LINEUPS": len(candidate_idx),
        "PHASE2_BUILD_MODE": "CALIBRATION_FIRST_STREAMING_PLUS_DETERMINISTIC_SCENARIO_CLOSURE",
        "PHASE3_CANDIDATE_LINEUPS": len(candidate_idx), "POST_PHASE2_MUTATION_COUNT": 0,
        "PHASE2_PHASE3_PARITY": "PASS", "HANDOFF_SURVIVORS": len(candidate_idx),
        "SELECTOR_REVIEWED_LINEUPS": len(candidate_idx), "HANDOFF_SELECTOR_PARITY": "PASS",
        "MODERATE_DOG_MIXED_CORE_CLOSURE_BIRTHS": len(moderate_core_idx),
        **scenario_receipt,
        "SCENARIO_ONE_SWAP_SELECTOR_SLOTS": sum(lane.startswith("UNDERSPEND_SCENARIO_") for lane in selected_lanes),
        "FAKE_FIELD_LINEUPS": len(fake_idx), "BASE_SIM_TRIALS": base_sim_trials,
        "BUBBLE_EXTRA_TRIALS_TOTAL": bubble_extra, "BUBBLE_LINEUPS_REVIEWED": bubble_count,
        "BUBBLE_LINEUPS_UNRESOLVED": 0, "BUBBLE_HASH": bubble_hash,
        "FINAL_BOARD_SIZE": len(rows), "FILLERS_USED": False, "RANK_ALL_USED": False,
        "POSTLOCK_RESULTS_USED_IN_FORWARD_ENGINE": False, "PLAYER_NAMES_USED_BY_SELECTOR": False,
        "PHASE2_MANIFEST_HASH": phase2_hash,
        "BOARD_SHA256": base.sha256_file(board_path), "PHASE2_MANIFEST_SHA256": base.sha256_file(manifest_path),
        "GLOBAL_HANDOFF_PATCH": handoff_contract["PATCH_ID"], "GLOBAL_HANDOFF_PATCH_SHA256": handoff_sha,
        "RUNTIME_SECONDS": round(time.time() - t0, 3),
    }
    receipt_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_FINAL_RECEIPT.json"
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    stage("COMPLETE", final_board_size=len(rows), receipt_path=str(receipt_path))
    return {"receipt": receipt, "board_path": str(board_path), "phase2_manifest_path": str(manifest_path)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pool", required=True, type=Path)
    parser.add_argument("--matchups", required=True, type=Path)
    parser.add_argument("--availability-receipt", required=True, type=Path)
    parser.add_argument("--field-size", required=True, type=int)
    parser.add_argument("--execution-id", required=True)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--phase1-trials", type=int, default=50_000)
    parser.add_argument("--base-sim-trials", type=int, default=10_000)
    args = parser.parse_args()
    seed = int(args.seed if args.seed is not None else base.resolve_execution_seed(args.execution_id, None))
    result = run_engine(
        pool_path=args.pool, matchup_path=args.matchups, field_size=args.field_size,
        execution_id=args.execution_id, out_dir=args.out_dir, seed=seed,
        availability_receipt=args.availability_receipt,
        phase1_trials=args.phase1_trials, base_sim_trials=args.base_sim_trials,
    )
    print(json.dumps(result["receipt"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
