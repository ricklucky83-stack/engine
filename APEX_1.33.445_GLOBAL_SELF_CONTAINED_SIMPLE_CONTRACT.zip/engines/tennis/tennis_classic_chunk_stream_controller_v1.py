#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, json, os, sys, time
from pathlib import Path
from typing import Any

STATE_ROOT=Path(__file__).resolve().parents[2]
if str(STATE_ROOT) not in sys.path: sys.path.insert(0,str(STATE_ROOT))
from engines.tennis import tennis_classic_raw_pool_runtime_v2 as eng
from engines.common import apex_deadline_resumable_execution_v1 as resume
from engines.common.build_prebuild_availability_receipt_v1 import build_receipt

PATCH_ID='TENNIS_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_v1'
SCHEMA_VERSION='1.0.0'
CONTINUE_CODE=75

def sha(p:Path)->str: return resume.sha256_file(Path(p))
def atomic_json(p:Path,obj:Any)->str:
    resume.atomic_json(p,obj); return sha(p)

def env_path(key:str,required=True)->Path|None:
    v=str(os.environ.get(key) or '').strip()
    if not v:
        if required: raise RuntimeError(f'RUN_INVALID:TENNIS_CHUNK_STREAM_ENV_MISSING:{key}')
        return None
    p=Path(v).resolve()
    if required and not p.exists(): raise RuntimeError(f'RUN_INVALID:TENNIS_CHUNK_STREAM_FILE_MISSING:{key}:{p}')
    return p

def identity(pool:Path,field:int,execution_id:str)->dict[str,Any]:
    return {'PATCH_ID':PATCH_ID,'SCHEMA_VERSION':SCHEMA_VERSION,'POOL_SHA256':sha(pool),'FIELD_SIZE':field,'EXECUTION_ID':execution_id,
            'STATE_VERSION':str(os.environ.get('APEX_GLOBAL_STATE_VERSION') or os.environ.get('APEX_RESUMABLE_STATE_VERSION') or 'UNSPECIFIED'),
            'RUNTIME_SHA256':sha(Path(eng.__file__).resolve()),'CONTROLLER_SHA256':sha(Path(__file__).resolve())}

def state_root(out:Path)->Path:
    base=str(os.environ.get('APEX_RESUMABLE_RUN_ROOT') or '').strip()
    root=(Path(base)/'tennis_classic_chunk_stream_v1') if base else (out/'.tennis_classic_chunk_stream_v1')
    root.mkdir(parents=True,exist_ok=True); return root

def load_state(root:Path, ident:dict[str,Any])->dict[str,Any]:
    p=root/'controller_state.json'; st={}
    if p.exists():
        try: st=json.loads(p.read_text())
        except Exception: st={}
        if st.get('IDENTITY') != ident:
            stale=root.with_name(root.name+f'.stale.{time.time_ns()}'); os.replace(root,stale); root.mkdir(parents=True,exist_ok=True); st={}
    if not st:
        st={'PATCH_ID':PATCH_ID,'SCHEMA_VERSION':SCHEMA_VERSION,'IDENTITY':ident,'STAGE':'PREP','CURSORS':{},'COMPLETED_CHUNKS':0,'SAFE_YIELD_COUNT':0,'EXECUTION_STATE':'RUNNING','CHUNK_COMMITS':[]}
        resume.atomic_json(p,st)
    return st

def save(root:Path,st:dict[str,Any])->None: resume.atomic_json(root/'controller_state.json',st)

def commit(root:Path,st:dict[str,Any],stage:str,path:Path,*,trials:int=0,rows:int=0)->None:
    rec={'STAGE':stage,'CURSOR':1,'PATH':str(path),'SHA256':sha(path),'TRIALS':int(trials),'ROWS':int(rows)}
    st['CURSORS'][stage]=1; st['COMPLETED_CHUNKS']=int(st.get('COMPLETED_CHUNKS',0))+1; st['LAST_COMMIT']=rec
    h=list(st.get('CHUNK_COMMITS',[])); h.append(rec); st['CHUNK_COMMITS']=h[-32:]; save(root,st)

def build_runtime_inputs(pool:Path,out:Path,source_receipt:Path)->tuple[Path,Path]:
    payload=json.loads(source_receipt.read_text())
    snap={k:v for k,v in payload.items() if k not in {'SCHEMA_VERSION','STATUS','POOL_SHA256','GENERATED_AT_UTC','MAX_AGE_MINUTES','CODE_GENERATED','GENERATOR_ID','GENERATOR_SOURCE_SHA256','DK_SOURCE_UNIVERSE_ANCHOR_SHA256','DK_SOURCE_UNIVERSE_PLAYER_COUNT'}}
    snap_path=out/'DK_TENNIS_CLASSIC_RUNTIME_AVAILABILITY_SOURCE.json'; atomic_json(snap_path,snap)
    receipt=out/'DK_TENNIS_CLASSIC_RUNTIME_AVAILABILITY_RECEIPT.json'; build_receipt(pool_path=pool,snapshot_path=snap_path,output_path=receipt,max_age_minutes=45)
    card=payload.get('MATCH_CARD') or snap.get('MATCH_CARD') or []
    if not isinstance(card,list) or not card: raise RuntimeError('RUN_INVALID:TENNIS_AUTHORITATIVE_MATCH_CARD_MISSING')
    by={str(x.get('PLAYER') or '').strip():x for x in card if isinstance(x,dict)}
    rows=[]
    with pool.open(newline='',encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            name=str(r.get('PLAYER') or '').strip(); x=by.get(name)
            if not x or not str(x.get('OPPONENT') or '').strip(): raise RuntimeError(f'RUN_INVALID:TENNIS_AUTHORITATIVE_MATCHUP_COVERAGE:{name}')
            rows.append({'PLAYER':name,'OPPONENT':str(x['OPPONENT']).strip(),'TOUR':str(x.get('TOUR') or '').strip(),'BEST_OF':str(x.get('BEST_OF') or '').strip()})
    matchup=out/'DK_TENNIS_CLASSIC_RUNTIME_MATCHUPS.csv'
    with matchup.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['PLAYER','OPPONENT','TOUR','BEST_OF']); w.writeheader(); w.writerows(rows)
    return receipt,matchup

def main()->int:
    try:
        pool=env_path('APEX_PLAYER_POOL'); source_receipt=env_path('APEX_PREBUILD_AVAILABILITY_RECEIPT')
        out=Path(str(os.environ.get('APEX_OUTPUT_DIR') or '/mnt/data')).resolve(); out.mkdir(parents=True,exist_ok=True)
        field=int(os.environ.get('APEX_FIELD_SIZE') or 0); execution_id=str(os.environ.get('APEX_EXECUTION_ID') or field)
        if field<=0: raise RuntimeError('RUN_INVALID:TENNIS_CHUNK_STREAM_FIELD_SIZE')
        root=state_root(out); ident=identity(pool,field,execution_id); st=load_state(root,ident)
        if st['STAGE']=='PREP':
            runtime_receipt,matchup=build_runtime_inputs(pool,out,source_receipt)
            prep=root/'prep.json'; atomic_json(prep,{'POOL':str(pool),'AVAILABILITY_RECEIPT':str(runtime_receipt),'MATCHUPS':str(matchup),'POOL_SHA256':sha(pool),'RECEIPT_SHA256':sha(runtime_receipt),'MATCHUPS_SHA256':sha(matchup)})
            commit(root,st,'PREP',prep,rows=sum(1 for _ in pool.open())-1); st['STAGE']='RUN_ENGINE'; st['EXECUTION_STATE']='RESUMABLE'; st['SAFE_YIELD_COUNT']=int(st.get('SAFE_YIELD_COUNT',0))+1; save(root,st)
            print(json.dumps({'RUN_STATE':'CHECKPOINTED_CONTINUE','EXECUTION_STATE':'RESUMABLE','PATCH_ID':PATCH_ID,'COMPLETED_STAGE':'PREP','NEXT_STAGE':'RUN_ENGINE','NEXT_CHUNK':0,'CHECKPOINT':str(prep),'CONTROLLER_STATE':str(root/'controller_state.json'),'COMPLETED_CHUNKS':st['COMPLETED_CHUNKS'],'SAFE_YIELD_COUNT':st['SAFE_YIELD_COUNT'],'EXTERNAL_RESUME_REQUIRED':False},separators=(',',':')),flush=True)
            return CONTINUE_CODE
        if st['STAGE']=='RUN_ENGINE':
            import subprocess
            prep=json.loads((root/'prep.json').read_text()); board_size=int(os.environ.get('APEX_BOARD_SIZE') or 5)
            generic=STATE_ROOT/'engines/common/apex_generic_python_chunk_stream_controller_v1.py'
            cmd=[sys.executable,str(generic),'--pool',str(pool),'--field-size',str(field),'--execution-id',str(execution_id),'--out-dir',str(out),'--matchups',str(prep['MATCHUPS']),'--availability-receipt',str(prep['AVAILABILITY_RECEIPT']),'--roster-size','auto','--board-size',str(board_size)]
            cp=subprocess.run(cmd,cwd=str(STATE_ROOT),env=dict(os.environ),check=False,text=True,capture_output=True)
            if cp.stderr: sys.stderr.write(cp.stderr); sys.stderr.flush()
            if cp.stdout: sys.stdout.write(cp.stdout); sys.stdout.flush()
            if cp.returncode==CONTINUE_CODE:
                st['EXECUTION_STATE']='RESUMABLE'; st['SAFE_YIELD_COUNT']=int(st.get('SAFE_YIELD_COUNT',0))+1; save(root,st)
                return CONTINUE_CODE
            if cp.returncode!=0: return int(cp.returncode)
            st['STAGE']='COMPLETE'; st['EXECUTION_STATE']='COMPLETED'; st['COMPLETED_CHUNKS']=int(st.get('COMPLETED_CHUNKS',0))+1; save(root,st)
            return 0
        if st['STAGE']=='COMPLETE':
            import subprocess
            prep=json.loads((root/'prep.json').read_text()); board_size=int(os.environ.get('APEX_BOARD_SIZE') or 5)
            generic=STATE_ROOT/'engines/common/apex_generic_python_chunk_stream_controller_v1.py'
            cmd=[sys.executable,str(generic),'--pool',str(pool),'--field-size',str(field),'--execution-id',str(execution_id),'--out-dir',str(out),'--matchups',str(prep['MATCHUPS']),'--availability-receipt',str(prep['AVAILABILITY_RECEIPT']),'--roster-size','auto','--board-size',str(board_size)]
            cp=subprocess.run(cmd,cwd=str(STATE_ROOT),env=dict(os.environ),check=False,text=True,capture_output=True)
            if cp.stderr: sys.stderr.write(cp.stderr); sys.stderr.flush()
            if cp.stdout: sys.stdout.write(cp.stdout); sys.stdout.flush()
            return int(cp.returncode)
        raise RuntimeError(f'RUN_INVALID:TENNIS_CHUNK_STREAM_UNKNOWN_STAGE:{st["STAGE"]}')
    except Exception as exc:
        print(json.dumps({'RUN_STATE':'RUN_INVALID','EXECUTION_STATE':'FAILED','ENGINE_ID':eng.ENGINE_ID,'FINAL_BOARD_SIZE':0,'ENGINE_SUBSTITUTION':False,'FAILURE_CODE':f'{type(exc).__name__}:{exc}','PATCH_ID':PATCH_ID},separators=(',',':')),flush=True); return 2
if __name__=='__main__': raise SystemExit(main())
