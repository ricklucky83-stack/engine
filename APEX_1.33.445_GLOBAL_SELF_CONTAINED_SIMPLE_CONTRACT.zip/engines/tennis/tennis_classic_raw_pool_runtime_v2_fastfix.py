from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor

import argparse
import hashlib
import itertools
import json
import math
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
from numba import njit

STATE_ROOT = Path(__file__).resolve().parents[2]
if str(STATE_ROOT) not in sys.path:
    sys.path.insert(0, str(STATE_ROOT))

from engines.common.mandatory_prebuild_roster_gate_v1 import (  # noqa: E402
    require_prebuild_roster_check,
)
from engines.common import apex_global_sports_strategy_layer_v1 as global_strategy  # noqa: E402
from engines.common import apex_pipeline_identity_ledger_v1 as pipeline_ledger  # noqa: E402

ENGINE_ID = "APEX_TENNIS_CLASSIC_RAW_POOL_RUNTIME_v2"
ENGINE_VERSION = "2.0.0"
PLATFORM = "DRAFTKINGS"
SPORT = "TENNIS"
MODE = "CLASSIC"
SALARY_CAP = 50_000
CALIBRATION_FILE = Path(__file__).with_name("tennis_classic_calibration_v2.json")
DOCTRINE_FILE = STATE_ROOT / "doctrine" / "TENNIS_CLASSIC_FULL_REBUILD_v2.json"
ROTOWIRE_DOCTRINE_FILE = STATE_ROOT / "doctrine" / "ROTOWIRE_MISSING_SIGNAL_NEUTRAL_NOT_ZERO_v1.json"
EVENT_NATIVE_DOCTRINE_FILE = STATE_ROOT / "doctrine" / "TENNIS_POINT_GAME_SET_MATCH_PROBABILITY_ENGINE_v1.json"
HANDOFF_FILE = STATE_ROOT / "current_handoff" / "APEX_GLOBAL_ENGINE_REGISTRY_HANDOFF_OVERLAY_v1.json"
REGISTRY_FILE = STATE_ROOT / "engine_registry.json"
ACTIVE_STATE_VERSION = str(json.loads(REGISTRY_FILE.read_text(encoding="utf-8")).get("STATE_VERSION", "UNRESOLVED"))
GLOBAL_SPORTS_STRATEGIST_PATCH_ID = "APEX_GLOBAL_SPORTS_STRATEGIST_AND_VALUE_UNLOCK_v1"
GLOBAL_PREDICTIVE_MARKET_LAYER_PATCH_ID = "APEX_GLOBAL_PREDICTIVE_MARKET_LAYER_v1"
MANDATORY_PREBUILD_ROSTER_PATCH_ID = "APEX_GLOBAL_MANDATORY_PREBUILD_ROSTER_CHECK_v1"
ROTOWIRE_NEUTRAL_NOT_ZERO_PATCH_ID = "ROTOWIRE_MISSING_SIGNAL_NEUTRAL_NOT_ZERO_v1"
MISSING_PRIOR_SELECTOR_PATCH_ID = "TENNIS_MISSING_PRIOR_UPSET_SENTINEL_SELECTOR_v2"
MISSING_PRIOR_SIBLING_PATCH_ID = "TENNIS_MISSING_PRIOR_NEAR_TIE_FULL_ONE_SWAP_CLOSURE_v1"
EVENT_NATIVE_PROBABILITY_PATCH_ID = "TENNIS_POINT_GAME_SET_MATCH_PROBABILITY_ENGINE_v1"
BOARD_IDENTITY_RECONCILIATION = "PHASE2_FROZEN_LINEUP_ID_PARITY"
BOARD_READY_RECEIPT = {'RUN_STATE':'BOARD_READY', 'BOARD_IDENTITY_RECONCILIATION':'PHASE2_FROZEN_LINEUP_ID_PARITY'}


class EngineError(RuntimeError):
    pass


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def stable_hash(payload: Any) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    ).hexdigest()


def _load_contracts() -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    cal = json.loads(CALIBRATION_FILE.read_text(encoding="utf-8"))
    doctrine = json.loads(DOCTRINE_FILE.read_text(encoding="utf-8"))
    handoff = json.loads(HANDOFF_FILE.read_text(encoding="utf-8"))
    rotowire_doctrine = json.loads(ROTOWIRE_DOCTRINE_FILE.read_text(encoding="utf-8"))
    event_native_doctrine = json.loads(EVENT_NATIVE_DOCTRINE_FILE.read_text(encoding="utf-8"))
    if cal.get("CALIBRATION_ID") != "TENNIS_CLASSIC_PRELOCK_CALIBRATION_v2":
        raise EngineError("RUN_INVALID:TENNIS_CALIBRATION_ID_MISMATCH")
    if cal.get("ENGINE_ID") != ENGINE_ID or cal.get("VERSION") != ENGINE_VERSION:
        raise EngineError("RUN_INVALID:TENNIS_CALIBRATION_ENGINE_MISMATCH")
    if doctrine.get("DOCTRINE_ID") != "TENNIS_CLASSIC_FULL_REBUILD_v2":
        raise EngineError("RUN_INVALID:TENNIS_DOCTRINE_ID_MISMATCH")
    arch = doctrine.get("ARCHITECTURE", {})
    required = {
        "STANDALONE_RAW_POOL_RUNTIME": "REQUIRED",
        "LEGACY_RUNTIME_IMPORT": "PROHIBITED",
        "CALIBRATION_FIRST": "REQUIRED",
        "SELECTOR_REVIEW": "EVERY_PHASE2_LINEUP",
        "RUNTIME_TELEMETRY": "PROHIBITED",
    }
    if any(arch.get(k) != v for k, v in required.items()):
        raise EngineError("RUN_INVALID:TENNIS_REBUILD_DOCTRINE_CONTRACT_FAIL")
    if handoff.get("PATCH_ID") != "HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1":
        raise EngineError("RUN_INVALID:HANDOFF_PATCH_ID_MISMATCH")
    input_contract = doctrine.get("INPUT_CONTRACT", {})
    if input_contract.get("MISSING_PRIOR_PATCH_ID") != ROTOWIRE_NEUTRAL_NOT_ZERO_PATCH_ID:
        raise EngineError("RUN_INVALID:TENNIS_MISSING_PRIOR_DOCTRINE_MISMATCH")
    if input_contract.get("NEUTRAL_IMPUTATION", {}).get("MARKER_RULE") != "FIELDWISE_NONPOSITIVE_OR_NONFINITE_IS_MISSING":
        raise EngineError("RUN_INVALID:TENNIS_MISSING_PRIOR_MARKER_RULE_MISMATCH")
    if rotowire_doctrine.get("DOCTRINE_ID") != ROTOWIRE_NEUTRAL_NOT_ZERO_PATCH_ID:
        raise EngineError("RUN_INVALID:TENNIS_ROTOWIRE_DOCTRINE_ID_MISMATCH")
    holdout = rotowire_doctrine.get("HOLDOUT_VALIDATION", {})
    if holdout.get("STATUS") != "PASS" or holdout.get("PARSER_STATUS") != "PASS_HISTORICAL_MULTI_SLATE":
        raise EngineError("RUN_INVALID:TENNIS_ROTOWIRE_HISTORICAL_VALIDATION_NOT_SEALED")
    if rotowire_doctrine.get("GLOBAL_PROMOTION_STATUS") != "APPROVED_HISTORICAL_MULTI_SLATE":
        raise EngineError("RUN_INVALID:TENNIS_ROTOWIRE_GLOBAL_PROMOTION_NOT_APPROVED")
    if doctrine.get("PHASE2", {}).get("MISSING_PRIOR_SIBLING_PATCH_ID") != MISSING_PRIOR_SIBLING_PATCH_ID:
        raise EngineError("RUN_INVALID:TENNIS_MISSING_PRIOR_SIBLING_DOCTRINE_MISMATCH")
    if doctrine.get("SELECTOR", {}).get("MISSING_PRIOR_UPSET_SENTINEL", {}).get("PATCH_ID") != MISSING_PRIOR_SELECTOR_PATCH_ID:
        raise EngineError("RUN_INVALID:TENNIS_MISSING_PRIOR_SELECTOR_DOCTRINE_MISMATCH")
    if event_native_doctrine.get("DOCTRINE_ID") != EVENT_NATIVE_PROBABILITY_PATCH_ID:
        raise EngineError("RUN_INVALID:TENNIS_EVENT_NATIVE_DOCTRINE_ID_MISMATCH")
    if doctrine.get("PHASE1", {}).get("EVENT_NATIVE_PROBABILITY_ENGINE") != EVENT_NATIVE_PROBABILITY_PATCH_ID:
        raise EngineError("RUN_INVALID:TENNIS_EVENT_NATIVE_PHASE1_DOCTRINE_MISMATCH")
    return cal, doctrine, handoff, rotowire_doctrine, event_native_doctrine


CALIBRATION, DOCTRINE, HANDOFF, ROTOWIRE_DOCTRINE, EVENT_NATIVE_DOCTRINE = _load_contracts()
CALIBRATION_SHA256 = sha256_file(CALIBRATION_FILE)
DOCTRINE_SHA256 = sha256_file(DOCTRINE_FILE)
ROTOWIRE_DOCTRINE_SHA256 = sha256_file(ROTOWIRE_DOCTRINE_FILE)
EVENT_NATIVE_DOCTRINE_SHA256 = sha256_file(EVENT_NATIVE_DOCTRINE_FILE)
HANDOFF_SHA256 = sha256_file(HANDOFF_FILE)


ALIASES: dict[str, tuple[str, ...]] = {
    "PLAYER": ("PLAYER", "NAME", "ATHLETE"),
    "SAL": ("SAL", "SALARY"),
    "FPTS": ("FPTS", "PROJ", "PROJECTION", "PROJECTED_FPTS"),
    "VAL": ("VAL", "VALUE"),
    "MIN_EXP": ("MIN EXP", "MIN_EXP", "MINEXPOSURE"),
    "MAX_EXP": ("MAX EXP", "MAX_EXP", "MAXEXPOSURE"),
    "OPPONENT": ("OPPONENT", "OPP", "OPPONENT_NAME"),
    "MATCH_ID": ("MATCH_ID", "MATCH", "GAME_ID", "GAME"),
    "TOUR": ("TOUR", "LEAGUE"),
    "SURFACE": ("SURFACE", "COURT_SURFACE"),
    "BEST_OF": ("BEST_OF", "BEST OF", "SETS"),
    "ACE": ("ACE", "ACES", "ACE_RATE", "ACES_PER_MATCH"),
    "DBLF": ("DBLF", "DOUBLE_FAULT", "DOUBLE FAULT", "DOUBLE_FAULTS"),
    "W": ("W", "WINS"),
    "L": ("L", "LOSSES"),
    "H2H_W": ("H2H W", "H2H_W", "H2H_WINS"),
    "H2H_L": ("H2H L", "H2H_L", "H2H_LOSSES"),
    "MATCH_WIN_PROB": ("MATCH_WIN_PROB", "MATCH WIN PROB", "WIN_PROBABILITY", "WIN %", "WIN%"),
    "SET_WIN_PROB": ("SET_WIN_PROB", "SET WIN PROB", "SET_WIN_PROBABILITY"),
    "RST": ("RST%", "RST", "OWNERSHIP", "OWN%", "OWNERSHIP%"),
    "HOLD": ("HOLD%", "HOLD", "HOLD_PERCENT"),
    "BREAK": ("BREAK%", "BREAK", "BREAK_PERCENT"),
    "FIRST_SERVE_IN": ("FIRST_SERVE_IN", "1ST_SERVE_IN", "FIRST SERVE IN%", "1ST IN%", "1ST_IN"),
    "FIRST_SERVE_PTS_WON": ("FIRST_SERVE_PTS_WON", "1ST_SERVE_PTS_WON", "1ST SERVE PTS WON%", "1ST WON%"),
    "SECOND_SERVE_PTS_WON": ("SECOND_SERVE_PTS_WON", "2ND_SERVE_PTS_WON", "2ND SERVE PTS WON%", "2ND WON%"),
    "SERVICE_PTS_WON": ("SERVICE_PTS_WON", "SERVE_PTS_WON", "SERVICE POINTS WON%", "SERVE POINTS WON%"),
    "RETURN_FIRST_PTS_WON": ("RETURN_FIRST_PTS_WON", "1ST_RETURN_PTS_WON", "1ST RETURN PTS WON%"),
    "RETURN_SECOND_PTS_WON": ("RETURN_SECOND_PTS_WON", "2ND_RETURN_PTS_WON", "2ND RETURN PTS WON%"),
    "RETURN_PTS_WON": ("RETURN_PTS_WON", "RETURN POINTS WON%", "RETURN_POINTS_WON"),
    "TIEBREAK_WIN": ("TIEBREAK_WIN", "TB_WIN", "TIEBREAK WIN%", "TB WIN%"),
    "SURFACE_WIN": ("SURFACE_WIN%", "SURFACE WIN%", "SURFACE_WIN_PERCENT"),
    "STATUS": ("STATUS", "INJURY_STATUS", "PARTICIPATION_STATUS"),
}
FORBIDDEN_FORWARD = {
    "ACTUAL_FPTS", "REALIZED_FPTS", "FINAL_RANK", "CONTEST_RANK", "WINNING_LINEUP", "POSTLOCK_SCORE"
}


def _norm(name: Any) -> str:
    return str(name or "").strip().upper().replace("-", "_").replace(" ", "_")


def _normalize_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    normalized = {_norm(c): c for c in out.columns}
    forbidden = sorted(set(normalized) & FORBIDDEN_FORWARD)
    if forbidden:
        raise EngineError("RUN_INVALID:POSTLOCK_FIELDS_IN_FORWARD_POOL:" + ",".join(forbidden))
    rename: dict[str, str] = {}
    for canonical, aliases in ALIASES.items():
        for alias in aliases:
            key = _norm(alias)
            if key in normalized:
                rename[normalized[key]] = canonical
                break
    out = out.rename(columns=rename)
    return out


def _numeric(df: pd.DataFrame, col: str, default: float = np.nan) -> np.ndarray:
    if col not in df:
        return np.full(len(df), default, dtype=np.float64)
    s = pd.to_numeric(df[col], errors="coerce").to_numpy(dtype=np.float64)
    return s


def _prob_array(values: np.ndarray) -> np.ndarray:
    out = values.astype(np.float64, copy=True)
    finite = np.isfinite(out)
    if finite.any() and np.nanmax(out[finite]) > 1.0:
        out[finite] /= 100.0
    return out


def _pct(values: np.ndarray) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64)
    n = len(x)
    if n == 0:
        return np.asarray([], dtype=np.float32)
    finite = np.isfinite(x)
    if not finite.all():
        med = float(np.nanmedian(x[finite])) if finite.any() else 0.0
        x = np.where(finite, x, med)
    order = np.argsort(x, kind="stable")
    out = np.empty(n, dtype=np.float64)
    sorted_x = x[order]
    i = 0
    while i < n:
        j = i + 1
        while j < n and sorted_x[j] == sorted_x[i]:
            j += 1
        out[order[i:j]] = ((i + j - 1) / 2.0 + 0.5) / n
        i = j
    return out.astype(np.float32)


def _z(values: np.ndarray) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64)
    finite = np.isfinite(x)
    med = float(np.nanmedian(x[finite])) if finite.any() else 0.0
    x = np.where(finite, x, med)
    sd = float(np.std(x))
    if sd < 1e-9:
        return np.zeros(len(x), dtype=np.float32)
    return ((x - float(np.mean(x))) / sd).astype(np.float32)


def _salary_neutral_impute(values: np.ndarray, salary: np.ndarray, minimum_observed: int = 6, nearest_k: int = 10) -> tuple[np.ndarray, np.ndarray]:
    v = values.astype(np.float64, copy=True)
    missing = ~np.isfinite(v)
    observed = ~missing
    if observed.sum() == 0:
        raise EngineError("RUN_INVALID:TENNIS_NEUTRAL_IMPUTATION_NO_OBSERVED_PRIORS")
    if observed.sum() < minimum_observed:
        v[missing] = float(np.nanmedian(v[observed]))
        return v.astype(np.float32), missing
    obs_idx = np.flatnonzero(observed)
    for i in np.flatnonzero(missing):
        dist = np.abs(salary[obs_idx] - salary[i])
        k = min(int(nearest_k), len(obs_idx))
        near = obs_idx[np.argpartition(dist, k - 1)[:k]]
        v[i] = float(np.mean(v[near]))
    return v.astype(np.float32), missing


def _clip_probability(x: float, lo: float = 0.01, hi: float = 0.99) -> float:
    return float(np.clip(float(x), lo, hi))


def _logit_probability(x: float) -> float:
    p = _clip_probability(x, 1e-5, 1.0 - 1e-5)
    return float(math.log(p / (1.0 - p)))


def _sigmoid_scalar(x: float) -> float:
    return float(1.0 / (1.0 + math.exp(-float(np.clip(x, -20.0, 20.0)))))


def _hold_probability_from_service_point(p: float) -> float:
    """Exact no-ad game-to-deuce hold probability from iid service-point win probability."""
    p = _clip_probability(p, 0.01, 0.99)
    q = 1.0 - p
    pre_deuce = p**4 * (1.0 + 4.0*q + 10.0*q*q)
    deuce_reach = 20.0 * p**3 * q**3
    deuce_win = p*p / max(p*p + q*q, 1e-12)
    return _clip_probability(pre_deuce + deuce_reach * deuce_win, 0.001, 0.999)


def _service_point_from_hold_probability(hold: float) -> float:
    target = _clip_probability(hold, 0.001, 0.999)
    lo, hi = 0.20, 0.90
    for _ in range(48):
        mid = (lo + hi) / 2.0
        if _hold_probability_from_service_point(mid) < target:
            lo = mid
        else:
            hi = mid
    return float((lo + hi) / 2.0)


def _set_win_probability_from_games(hold_a: float, hold_b: float, tb_a: float) -> float:
    from functools import lru_cache
    hold_a = _clip_probability(hold_a, 0.001, 0.999)
    hold_b = _clip_probability(hold_b, 0.001, 0.999)
    tb_a = _clip_probability(tb_a, 0.05, 0.95)

    def solve(start_a_serves: bool) -> float:
        @lru_cache(None)
        def rec(ga: int, gb: int, a_serves: bool) -> float:
            if ga >= 6 and ga - gb >= 2:
                return 1.0
            if gb >= 6 and gb - ga >= 2:
                return 0.0
            if ga == 6 and gb == 6:
                return tb_a
            pg = hold_a if a_serves else (1.0 - hold_b)
            return pg * rec(ga + 1, gb, not a_serves) + (1.0 - pg) * rec(ga, gb + 1, not a_serves)
        return rec(0, 0, start_a_serves)

    return _clip_probability(0.5 * (solve(True) + solve(False)), 0.01, 0.99)


def _match_win_from_set_probability(set_p: float, best_of: int) -> float:
    p = _clip_probability(set_p, 0.01, 0.99)
    if int(best_of) == 5:
        return _clip_probability(p**3 * (10.0 - 15.0*p + 6.0*p*p), 0.01, 0.99)
    return _clip_probability(p*p * (3.0 - 2.0*p), 0.01, 0.99)


def _conditional_sweep_probability(set_p: float, match_p: float, best_of: int) -> float:
    p = _clip_probability(set_p, 0.01, 0.99)
    m = _clip_probability(match_p, 0.01, 0.99)
    sweep_unconditional = p**3 if int(best_of) == 5 else p**2
    return _clip_probability(sweep_unconditional / max(m, 1e-9), 0.01, 0.99)


def _event_native_projection_recovery(
    *, pairs: tuple[tuple[int, int], ...], best_of: np.ndarray, raw_fpts: np.ndarray,
    salary: np.ndarray, first_serve_in: np.ndarray, first_serve_pts_won: np.ndarray,
    second_serve_pts_won: np.ndarray, service_pts_won: np.ndarray,
    return_first_pts_won: np.ndarray, return_second_pts_won: np.ndarray,
    return_pts_won: np.ndarray, hold: np.ndarray, break_rate: np.ndarray,
    explicit_match_win: np.ndarray, explicit_set_win: np.ndarray, tiebreak_win: np.ndarray,
) -> dict[str, np.ndarray]:
    n = len(salary)
    service_base = np.full(n, np.nan, dtype=np.float64)
    return_base = np.full(n, np.nan, dtype=np.float64)
    service_vs = np.full(n, np.nan, dtype=np.float64)
    hold_vs = np.full(n, np.nan, dtype=np.float64)
    break_vs = np.full(n, np.nan, dtype=np.float64)
    set_win = np.full(n, np.nan, dtype=np.float64)
    match_win = np.full(n, np.nan, dtype=np.float64)
    sweep_cond = np.full(n, np.nan, dtype=np.float64)
    source = np.full(n, "UNRESOLVED", dtype=object)

    for i in range(n):
        if np.isfinite(service_pts_won[i]):
            service_base[i] = _clip_probability(service_pts_won[i])
        elif np.isfinite(first_serve_in[i]) and np.isfinite(first_serve_pts_won[i]) and np.isfinite(second_serve_pts_won[i]):
            fs = _clip_probability(first_serve_in[i])
            service_base[i] = _clip_probability(fs * first_serve_pts_won[i] + (1.0 - fs) * second_serve_pts_won[i])
        elif np.isfinite(hold[i]):
            service_base[i] = _service_point_from_hold_probability(float(hold[i]))

        if np.isfinite(return_pts_won[i]):
            return_base[i] = _clip_probability(return_pts_won[i])
        elif np.isfinite(return_first_pts_won[i]) and np.isfinite(return_second_pts_won[i]):
            # When opponent first-serve share is unavailable, neutral 60/40 serve mix is used only for aggregation.
            return_base[i] = _clip_probability(0.60 * return_first_pts_won[i] + 0.40 * return_second_pts_won[i])
        elif np.isfinite(break_rate[i]):
            opponent_service_point = _service_point_from_hold_probability(1.0 - float(break_rate[i]))
            return_base[i] = _clip_probability(1.0 - opponent_service_point)

    cfg = EVENT_NATIVE_DOCTRINE["MODEL"]
    return_baseline = float(cfg["TOUR_NEUTRAL_RETURN_POINT_BASELINE"])
    for a, b in pairs:
        point_path = np.isfinite(service_base[a]) and np.isfinite(service_base[b])
        if point_path:
            pa = float(service_base[a])
            pb = float(service_base[b])
            if np.isfinite(return_base[b]):
                pa = _sigmoid_scalar(_logit_probability(pa) - (_logit_probability(float(return_base[b])) - _logit_probability(return_baseline)))
            if np.isfinite(return_base[a]):
                pb = _sigmoid_scalar(_logit_probability(pb) - (_logit_probability(float(return_base[a])) - _logit_probability(return_baseline)))
            service_vs[a], service_vs[b] = pa, pb
            ha, hb = _hold_probability_from_service_point(pa), _hold_probability_from_service_point(pb)
            hold_vs[a], hold_vs[b] = ha, hb
            break_vs[a], break_vs[b] = 1.0 - hb, 1.0 - ha
            if np.isfinite(tiebreak_win[a]) or np.isfinite(tiebreak_win[b]):
                ta, tb = tiebreak_win[a], tiebreak_win[b]
                if np.isfinite(ta) and np.isfinite(tb) and ta + tb > 0:
                    tba = float(ta / (ta + tb))
                elif np.isfinite(ta):
                    tba = float(ta)
                else:
                    tba = float(1.0 - tb)
            else:
                neutral_point = 0.5 * (pa + (1.0 - pb))
                tba = _clip_probability(0.5 + float(cfg["TIEBREAK_POINT_EDGE_MULTIPLIER"]) * (neutral_point - 0.5), 0.05, 0.95)
            spa = _set_win_probability_from_games(ha, hb, tba)
            spb = 1.0 - spa
            mpa = _match_win_from_set_probability(spa, int(best_of[a]))
            mpb = 1.0 - mpa
            set_win[a], set_win[b] = spa, spb
            match_win[a], match_win[b] = mpa, mpb
            sweep_cond[a] = _conditional_sweep_probability(spa, mpa, int(best_of[a]))
            sweep_cond[b] = _conditional_sweep_probability(spb, mpb, int(best_of[b]))
            source[a] = source[b] = "POINT_GAME_SET_MATCH"
            continue

        ea, eb = explicit_match_win[a], explicit_match_win[b]
        if np.isfinite(ea) or np.isfinite(eb):
            if np.isfinite(ea) and np.isfinite(eb) and ea + eb > 0:
                mpa = float(ea / (ea + eb))
            elif np.isfinite(ea):
                mpa = float(ea)
            else:
                mpa = float(1.0 - eb)
            mpa = _clip_probability(mpa)
            mpb = 1.0 - mpa
            match_win[a], match_win[b] = mpa, mpb
            for p, mp in ((a, mpa), (b, mpb)):
                if np.isfinite(explicit_set_win[p]):
                    sp = _clip_probability(explicit_set_win[p])
                else:
                    sp = _clip_probability(0.5 + float(cfg["MATCH_TO_SET_SHRINK"]) * (mp - 0.5))
                set_win[p] = sp
                sweep_cond[p] = _conditional_sweep_probability(sp, mp, int(best_of[p]))
                source[p] = "MATCH_SET_PROBABILITY"
            continue

        if np.isfinite(explicit_set_win[a]) or np.isfinite(explicit_set_win[b]):
            if np.isfinite(explicit_set_win[a]) and np.isfinite(explicit_set_win[b]) and explicit_set_win[a] + explicit_set_win[b] > 0:
                spa = float(explicit_set_win[a] / (explicit_set_win[a] + explicit_set_win[b]))
            elif np.isfinite(explicit_set_win[a]):
                spa = float(explicit_set_win[a])
            else:
                spa = float(1.0 - explicit_set_win[b])
            spa = _clip_probability(spa); spb = 1.0 - spa
            for p, sp in ((a, spa), (b, spb)):
                mp = _match_win_from_set_probability(sp, int(best_of[p]))
                set_win[p], match_win[p] = sp, mp
                sweep_cond[p] = _conditional_sweep_probability(sp, mp, int(best_of[p]))
                source[p] = "SET_TO_MATCH_PROBABILITY"

    ph = CALIBRATION["PHASE1"]
    event_mean = np.full(n, np.nan, dtype=np.float64)
    resolved = np.isfinite(match_win) & np.isfinite(sweep_cond)
    event_mean[resolved] = (
        float(ph["LOSS_BASE_MEAN"])
        + (float(ph["WIN_BASE_MEAN"]) - float(ph["LOSS_BASE_MEAN"])) * match_win[resolved]
        + float(ph["SWEEP_BONUS_MEAN"]) * match_win[resolved] * sweep_cond[resolved]
        + np.where(best_of[resolved] == 5, float(cfg["BEST_OF_FIVE_EXPECTED_VOLUME_BONUS"]) * match_win[resolved], 0.0)
    )

    # Scale only; ranking signal remains event-native. Positive provider rows are never overwritten.
    observed = np.isfinite(raw_fpts) & (raw_fpts > 0.0) & np.isfinite(event_mean)
    calibrated = event_mean.copy()
    calibration_used = False
    min_cal = int(cfg["MIN_PROVIDER_ROWS_FOR_SCALE_CALIBRATION"])
    if int(observed.sum()) >= min_cal and float(np.std(event_mean[observed])) > 1e-6:
        slope, intercept = np.polyfit(event_mean[observed], raw_fpts[observed], 1)
        slope = float(np.clip(slope, float(cfg["SCALE_SLOPE_MIN"]), float(cfg["SCALE_SLOPE_MAX"])))
        pred = slope * event_mean + float(intercept)
        lo = max(0.0, float(np.nanpercentile(raw_fpts[observed], 5)) * float(cfg["CALIBRATED_FPTS_FLOOR_MULTIPLIER"]))
        hi = float(np.nanpercentile(raw_fpts[observed], 95)) * float(cfg["CALIBRATED_FPTS_CEILING_MULTIPLIER"])
        calibrated = np.where(np.isfinite(pred), np.clip(pred, lo, max(hi, lo + 1.0)), np.nan)
        calibration_used = True

    missing_fpts_marker = (~np.isfinite(raw_fpts)) | (raw_fpts <= 0.0)
    recovered = missing_fpts_marker & np.isfinite(calibrated)
    recovery_source = np.asarray(source, dtype=object).copy()
    recovery_source[~missing_fpts_marker] = "PROVIDER"
    recovery_source[missing_fpts_marker & ~recovered] = "SALARY_NEUTRAL_FALLBACK"
    if calibration_used:
        recovery_source[recovered] = np.asarray([f"EVENT_NATIVE_CALIBRATED:{source[i]}" for i in np.flatnonzero(recovered)], dtype=object)

    return {
        "service_point_win": service_vs.astype(np.float32),
        "hold_probability": hold_vs.astype(np.float32),
        "break_probability": break_vs.astype(np.float32),
        "set_win_probability": set_win.astype(np.float32),
        "match_win_probability": match_win.astype(np.float32),
        "sweep_probability": sweep_cond.astype(np.float32),
        "event_projection": calibrated.astype(np.float32),
        "recovered_mask": recovered.astype(np.bool_),
        "recovery_source": recovery_source,
        "scale_calibration_used": np.asarray([calibration_used], dtype=np.bool_),
    }


@dataclass(frozen=True)
class Slate:
    pool: pd.DataFrame
    player_names: tuple[str, ...]
    player_ids: tuple[str, ...]
    salaries: np.ndarray
    weak_projection: np.ndarray
    values: np.ndarray
    opponent_index: np.ndarray
    match_id: np.ndarray
    pair_indices: tuple[tuple[int, int], ...]
    tours: np.ndarray
    surfaces: np.ndarray
    best_of: np.ndarray
    ace: np.ndarray
    dblf: np.ndarray
    wins_record: np.ndarray
    losses_record: np.ndarray
    h2h_w: np.ndarray
    h2h_l: np.ndarray
    explicit_match_win_prob: np.ndarray
    set_win_prob: np.ndarray
    rst: np.ndarray
    hold: np.ndarray
    break_rate: np.ndarray
    surface_win: np.ndarray
    event_service_point_win: np.ndarray
    event_hold_probability: np.ndarray
    event_break_probability: np.ndarray
    event_set_win_probability: np.ndarray
    event_match_win_probability: np.ndarray
    event_sweep_probability: np.ndarray
    event_projection: np.ndarray
    event_recovered_prior: np.ndarray
    prior_source: np.ndarray
    missing_weak_prior: np.ndarray
    pool_sha256: str
    matchup_source: str
    out_purge: int
    strategy: Any


@dataclass(frozen=True)
class Phase1:
    player_scores: np.ndarray
    wins: np.ndarray
    sweeps: np.ndarray
    win_probability: np.ndarray
    sweep_probability: np.ndarray
    serve_index: np.ndarray
    player_mean: np.ndarray
    player_p95: np.ndarray
    player_p99: np.ndarray
    player_cvar99: np.ndarray
    tail_efficiency: np.ndarray
    metric_hash: str


@dataclass(frozen=True)
class RuntimeConfig:
    execution_id: str
    field_size: int
    seed: int
    roster_size: int
    phase1_trials: int
    base_sim_trials: int
    board_size: int
    salary_cap: int = SALARY_CAP


def resolve_seed(execution_id: str, explicit: int | None = None) -> int:
    if explicit is not None:
        return int(explicit) & 0x7FFFFFFF
    text = str(execution_id).strip()
    if text.isdigit():
        return int(text) & 0x7FFFFFFF
    return int(hashlib.sha256(text.encode()).hexdigest()[:8], 16) & 0x7FFFFFFF


def resolve_roster_size(active_pool: int, requested: str | int = "auto") -> int:
    if str(requested).lower() != "auto":
        size = int(requested)
        if size not in (3, 6):
            raise EngineError(f"RUN_INVALID:TENNIS_ROSTER_SIZE_UNSUPPORTED:{size}")
        return size
    small_max = int(CALIBRATION["ROSTER"]["SMALL_SLATE_AUTO_POOL_MAX"])
    return int(CALIBRATION["ROSTER"]["SMALL_SLATE_SIZE"] if active_pool <= small_max else CALIBRATION["ROSTER"]["STANDARD_SIZE"])


def _merge_matchups(pool: pd.DataFrame, matchup_path: Path | None) -> tuple[pd.DataFrame, str]:
    if matchup_path is None:
        if "OPPONENT" not in pool:
            raise EngineError("RUN_INVALID:TENNIS_OPPONENT_COLUMN_MISSING")
        return pool, "PLAYER_POOL_RECIPROCAL_OPPONENT"
    m = _normalize_frame(pd.read_csv(matchup_path))
    if "PLAYER" not in m or "OPPONENT" not in m:
        raise EngineError("RUN_INVALID:TENNIS_MATCHUP_FILE_SCHEMA")
    matchup_columns = (
        "OPPONENT", "MATCH_ID", "TOUR", "SURFACE", "BEST_OF",
        "FIRST_SERVE_IN", "FIRST_SERVE_PTS_WON", "SECOND_SERVE_PTS_WON", "SERVICE_PTS_WON",
        "RETURN_FIRST_PTS_WON", "RETURN_SECOND_PTS_WON", "RETURN_PTS_WON", "TIEBREAK_WIN",
        "MATCH_WIN_PROB", "SET_WIN_PROB", "HOLD", "BREAK", "SURFACE_WIN", "ACE", "DBLF",
        "W", "L", "H2H_W", "H2H_L", "RST",
    )
    cols = ["PLAYER"] + [c for c in matchup_columns if c in m]
    m = m[cols].drop_duplicates("PLAYER")
    # When an authoritative matchup/enrichment file supplies a signal, it replaces the pool copy.
    base = pool.drop(columns=[c for c in matchup_columns if c in m and c in pool], errors="ignore")
    merged = base.merge(m, on="PLAYER", how="left", validate="one_to_one")
    if merged["OPPONENT"].isna().any():
        raise EngineError("RUN_INVALID:TENNIS_MATCHUP_FILE_COVERAGE")
    return merged, "AUTHORITATIVE_MATCHUP_FILE"


def load_slate(pool_path: Path, *, matchup_path: Path | None = None, availability_receipt: Path | None = None,
               execution_id: str | None = None, field_size: int | None = None) -> Slate:
    raw = pd.read_csv(pool_path)
    pool = _normalize_frame(raw)
    if "PLAYER" not in pool or "SAL" not in pool:
        raise EngineError("RUN_INVALID:TENNIS_POOL_REQUIRES_PLAYER_AND_SALARY")
    pool["PLAYER"] = pool["PLAYER"].astype(str).str.strip()
    if pool["PLAYER"].eq("").any() or pool["PLAYER"].duplicated().any():
        raise EngineError("RUN_INVALID:TENNIS_POOL_EMPTY_OR_DUPLICATE_PLAYER")
    pool["SAL"] = pd.to_numeric(pool["SAL"], errors="coerce")
    if pool["SAL"].isna().any() or (pool["SAL"] <= 0).any() or (pool["SAL"] > SALARY_CAP).any():
        raise EngineError("RUN_INVALID:TENNIS_PLAYER_SALARY_INVALID")
    pool, matchup_source = _merge_matchups(pool, matchup_path)

    pre_purge_n = len(pool)
    out_names: set[str] = set()
    if availability_receipt is not None:
        gate = require_prebuild_roster_check(
            availability_receipt, sport=SPORT, mode=MODE, pool_path=pool_path,
            execution_id=execution_id, field_size=int(field_size or 0),
        )
        out_names = set(gate.out_players)
    elif os.environ.get("APEX_TENNIS_TEST_MODE") != "1":
        raise EngineError("RUN_INVALID:TENNIS_PREBUILD_AVAILABILITY_RECEIPT_REQUIRED")

    if "STATUS" in pool:
        unavailable = {"OUT", "WD", "WITHDRAWN", "INACTIVE", "SCRATCHED", "DNP"}
        out_names |= set(pool.loc[pool["STATUS"].astype(str).str.upper().isin(unavailable), "PLAYER"].astype(str))
    if out_names:
        blocked = set(out_names)
        blocked |= set(pool.loc[pool["OPPONENT"].astype(str).isin(out_names), "PLAYER"].astype(str))
        pool = pool.loc[~pool["PLAYER"].astype(str).isin(blocked)].copy().reset_index(drop=True)
    purged_count = int(pre_purge_n - len(pool))
    if pool.empty:
        raise EngineError("RUN_INVALID:NO_ACTIVE_TENNIS_PARTICIPANTS")

    names = tuple(pool["PLAYER"].astype(str))
    by_name = {name: i for i, name in enumerate(names)}
    opponent_index = np.full(len(pool), -1, dtype=np.int16)
    pairs: list[tuple[int, int]] = []
    seen: set[tuple[int, int]] = set()
    match_labels: list[str] = [""] * len(pool)
    for i, row in pool.iterrows():
        opponent = str(row["OPPONENT"]).strip()
        if opponent not in by_name:
            raise EngineError(f"RUN_INVALID:TENNIS_OPPONENT_NOT_IN_ACTIVE_POOL:{names[i]}->{opponent}")
        j = by_name[opponent]
        if str(pool.iloc[j]["OPPONENT"]).strip() != names[i]:
            raise EngineError(f"RUN_INVALID:TENNIS_MATCHUP_NOT_RECIPROCAL:{names[i]}<->{opponent}")
        opponent_index[i] = j
        pair = tuple(sorted((i, j)))
        if pair not in seen:
            seen.add(pair)
            pairs.append(pair)
        if "MATCH_ID" in pool and pd.notna(row.get("MATCH_ID")):
            match_labels[i] = str(row.get("MATCH_ID"))
        else:
            match_labels[i] = "|".join(sorted((names[i], opponent)))
    if len(pairs) * 2 != len(pool):
        raise EngineError("RUN_INVALID:TENNIS_MATCH_CARDINALITY_NOT_PAIRS")
    label_to_code: dict[str, int] = {}
    match_id = np.empty(len(pool), dtype=np.int16)
    for i, label in enumerate(match_labels):
        if label not in label_to_code:
            label_to_code[label] = len(label_to_code)
        match_id[i] = label_to_code[label]

    salary = pool["SAL"].to_numpy(np.int32)
    impute_cfg = DOCTRINE["INPUT_CONTRACT"]["NEUTRAL_IMPUTATION"]
    raw_fpts = _numeric(pool, "FPTS")
    raw_val = _numeric(pool, "VAL")
    missing_fpts_marker = (~np.isfinite(raw_fpts)) | (raw_fpts <= float(impute_cfg["NONPOSITIVE_THRESHOLD"]))
    missing_val_marker = (~np.isfinite(raw_val)) | (raw_val <= float(impute_cfg["NONPOSITIVE_THRESHOLD"]))

    tours = np.asarray(pool["TOUR"].fillna("UNKNOWN").astype(str).str.upper() if "TOUR" in pool else ["UNKNOWN"] * len(pool), dtype=object)
    surfaces = np.asarray(pool["SURFACE"].fillna("UNKNOWN").astype(str).str.upper() if "SURFACE" in pool else ["UNKNOWN"] * len(pool), dtype=object)
    best_of = _numeric(pool, "BEST_OF", 3.0)
    best_of = np.where(np.isfinite(best_of) & np.isin(best_of.astype(int), [3, 5]), best_of, 3).astype(np.int8)
    ace = _numeric(pool, "ACE", np.nan)
    dblf = _numeric(pool, "DBLF", np.nan)
    wins_record = _numeric(pool, "W", np.nan)
    losses_record = _numeric(pool, "L", np.nan)
    h2h_w = _numeric(pool, "H2H_W", np.nan)
    h2h_l = _numeric(pool, "H2H_L", np.nan)
    explicit = _prob_array(_numeric(pool, "MATCH_WIN_PROB", np.nan))
    set_win = _prob_array(_numeric(pool, "SET_WIN_PROB", np.nan))
    rst = _prob_array(_numeric(pool, "RST", np.nan))
    hold = _prob_array(_numeric(pool, "HOLD", np.nan))
    break_rate = _prob_array(_numeric(pool, "BREAK", np.nan))
    surface_win = _prob_array(_numeric(pool, "SURFACE_WIN", np.nan))
    first_serve_in = _prob_array(_numeric(pool, "FIRST_SERVE_IN", np.nan))
    first_serve_pts_won = _prob_array(_numeric(pool, "FIRST_SERVE_PTS_WON", np.nan))
    second_serve_pts_won = _prob_array(_numeric(pool, "SECOND_SERVE_PTS_WON", np.nan))
    service_pts_won = _prob_array(_numeric(pool, "SERVICE_PTS_WON", np.nan))
    return_first_pts_won = _prob_array(_numeric(pool, "RETURN_FIRST_PTS_WON", np.nan))
    return_second_pts_won = _prob_array(_numeric(pool, "RETURN_SECOND_PTS_WON", np.nan))
    return_pts_won = _prob_array(_numeric(pool, "RETURN_PTS_WON", np.nan))
    tiebreak_win = _prob_array(_numeric(pool, "TIEBREAK_WIN", np.nan))

    event = _event_native_projection_recovery(
        pairs=tuple(pairs), best_of=best_of, raw_fpts=raw_fpts, salary=salary,
        first_serve_in=first_serve_in, first_serve_pts_won=first_serve_pts_won,
        second_serve_pts_won=second_serve_pts_won, service_pts_won=service_pts_won,
        return_first_pts_won=return_first_pts_won, return_second_pts_won=return_second_pts_won,
        return_pts_won=return_pts_won, hold=hold, break_rate=break_rate,
        explicit_match_win=explicit, explicit_set_win=set_win, tiebreak_win=tiebreak_win,
    )

    fpts_pre_impute = raw_fpts.astype(np.float64, copy=True)
    fpts_pre_impute[missing_fpts_marker] = np.nan
    fpts_pre_impute[event["recovered_mask"]] = event["event_projection"][event["recovered_mask"]]
    weak, residual_missing_fpts = _salary_neutral_impute(
        fpts_pre_impute, salary,
        minimum_observed=int(impute_cfg["MINIMUM_OBSERVED"]),
        nearest_k=int(impute_cfg["NEAREST_SALARY_PEERS"]),
    )

    val_pre_impute = raw_val.astype(np.float64, copy=True)
    val_pre_impute[missing_val_marker] = np.nan
    recovered_val = missing_val_marker & event["recovered_mask"]
    val_pre_impute[recovered_val] = event["event_projection"][recovered_val] / np.maximum(salary[recovered_val] / 1000.0, 1.0)
    val, residual_missing_val = _salary_neutral_impute(
        val_pre_impute, salary,
        minimum_observed=int(impute_cfg["MINIMUM_OBSERVED"]),
        nearest_k=int(impute_cfg["NEAREST_SALARY_PEERS"]),
    )
    missing_weak = missing_fpts_marker | missing_val_marker
    prior_source = np.asarray(event["recovery_source"], dtype=object)
    neutral_fallback = missing_fpts_marker & ~event["recovered_mask"]
    prior_source[neutral_fallback] = "SALARY_NEUTRAL_FALLBACK"

    strategy_frame = pool.copy()
    if "FPTS" not in strategy_frame:
        strategy_frame["FPTS"] = weak
    else:
        strategy_frame["FPTS"] = weak
    if "VAL" not in strategy_frame:
        strategy_frame["VAL"] = val
    else:
        strategy_frame["VAL"] = val
    strategy_frame["SAL"] = salary
    strategy = global_strategy.build_strategy_features(strategy_frame, sport=SPORT, mode=MODE)
    player_ids = tuple(
        hashlib.sha256(f"{name}|{int(salary[i])}|{str(pool.iloc[i]['OPPONENT'])}".encode()).hexdigest()[:16]
        for i, name in enumerate(names)
    )
    return Slate(
        pool=pool, player_names=names, player_ids=player_ids, salaries=salary,
        weak_projection=weak, values=val, opponent_index=opponent_index, match_id=match_id,
        pair_indices=tuple(pairs), tours=tours, surfaces=surfaces, best_of=best_of,
        ace=ace, dblf=dblf, wins_record=wins_record, losses_record=losses_record,
        h2h_w=h2h_w, h2h_l=h2h_l, explicit_match_win_prob=explicit,
        set_win_prob=set_win, rst=rst, hold=hold, break_rate=break_rate,
        surface_win=surface_win, event_service_point_win=event["service_point_win"],
        event_hold_probability=event["hold_probability"], event_break_probability=event["break_probability"],
        event_set_win_probability=event["set_win_probability"], event_match_win_probability=event["match_win_probability"],
        event_sweep_probability=event["sweep_probability"], event_projection=event["event_projection"],
        event_recovered_prior=event["recovered_mask"], prior_source=prior_source, missing_weak_prior=missing_weak,
        pool_sha256=sha256_file(pool_path), matchup_source=matchup_source,
        out_purge=purged_count, strategy=strategy,
    )


def estimate_win_probabilities(slate: Slate) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = len(slate.player_names)
    cfg = CALIBRATION["PHASE1"]
    salary_z = _z(slate.salaries.astype(float))
    fpts_z = _z(slate.weak_projection)
    val_z = _z(slate.values)
    ace_z = _z(slate.ace)
    dblf_z = _z(slate.dblf)
    hold_z = _z(slate.hold)
    break_z = _z(slate.break_rate)
    surface_z = _z(slate.surface_win)
    serve_index = (0.52 * ace_z - 0.28 * dblf_z + 0.12 * hold_z + 0.08 * break_z).astype(np.float32)
    rec = np.full(n, 0.5, dtype=np.float64)
    valid_rec = np.isfinite(slate.wins_record) & np.isfinite(slate.losses_record) & ((slate.wins_record + slate.losses_record) >= 1)
    rec[valid_rec] = (slate.wins_record[valid_rec] + 1.0) / (slate.wins_record[valid_rec] + slate.losses_record[valid_rec] + 2.0)
    h2h = np.full(n, 0.5, dtype=np.float64)
    valid_h2h = np.isfinite(slate.h2h_w) & np.isfinite(slate.h2h_l) & ((slate.h2h_w + slate.h2h_l) >= 1)
    h2h[valid_h2h] = (slate.h2h_w[valid_h2h] + 1.0) / (slate.h2h_w[valid_h2h] + slate.h2h_l[valid_h2h] + 2.0)
    leverage = np.asarray(slate.strategy.strategic_leverage, dtype=np.float64)
    win = np.full(n, 0.5, dtype=np.float64)
    lo = float(cfg["WIN_PROB_MIN"]); hi = float(cfg["WIN_PROB_MAX"])
    for a, b in slate.pair_indices:
        ea, eb = slate.explicit_match_win_prob[a], slate.explicit_match_win_prob[b]
        na, nb = slate.event_match_win_probability[a], slate.event_match_win_probability[b]
        if np.isfinite(ea) or np.isfinite(eb):
            if np.isfinite(ea) and np.isfinite(eb) and ea + eb > 0:
                pa = float(ea / (ea + eb))
            elif np.isfinite(ea):
                pa = float(ea)
            else:
                pa = float(1.0 - eb)
        elif np.isfinite(na) or np.isfinite(nb):
            if np.isfinite(na) and np.isfinite(nb) and na + nb > 0:
                pa = float(na / (na + nb))
            elif np.isfinite(na):
                pa = float(na)
            else:
                pa = float(1.0 - nb)
        else:
            logit = (
                (slate.salaries[a] - slate.salaries[b]) / float(cfg["SALARY_LOGIT_SCALE"])
                + float(cfg["RECORD_LOGIT_WEIGHT"]) * ((rec[a] - rec[b]) * 2.0)
                + float(cfg["H2H_LOGIT_WEIGHT"]) * ((h2h[a] - h2h[b]) * 2.0)
                + float(cfg["SERVE_LOGIT_WEIGHT"]) * float(serve_index[a] - serve_index[b])
                + float(cfg["WEAK_FPTS_LOGIT_WEIGHT"]) * float(fpts_z[a] - fpts_z[b])
                + float(cfg["WEAK_VAL_LOGIT_WEIGHT"]) * float(val_z[a] - val_z[b])
                + float(cfg["STRATEGY_LOGIT_WEIGHT"]) * float(leverage[a] - leverage[b])
                + 0.12 * float(surface_z[a] - surface_z[b])
                + 0.05 * float(salary_z[a] - salary_z[b])
            )
            pa = float(1.0 / (1.0 + math.exp(-np.clip(logit, -8.0, 8.0))))
        pa = float(np.clip(pa, lo, hi))
        win[a] = pa; win[b] = 1.0 - pa
    provided_set = slate.set_win_prob.copy()
    set_base = np.where(np.isfinite(provided_set), provided_set, 0.5 + 0.62 * (win - 0.5))
    sweep_fallback = 0.18 + 0.48 * np.abs(set_base - 0.5) * 2.0 + 0.035 * np.maximum(serve_index, -2.0)
    sweep = np.where(np.isfinite(slate.event_sweep_probability), slate.event_sweep_probability, sweep_fallback)
    sweep = np.clip(sweep, 0.16, 0.90).astype(np.float32)
    return win.astype(np.float32), sweep, serve_index


def simulate_phase1(slate: Slate, *, trials: int, seed: int) -> Phase1:
    minimum = int(CALIBRATION["PHASE1"]["MINIMUM_TRIALS"])
    if trials < minimum:
        raise EngineError(f"RUN_INVALID:PHASE1_TRIALS_BELOW_MINIMUM:{trials}<{minimum}")
    win_prob, sweep_prob, serve_index = estimate_win_probabilities(slate)
    n = len(slate.player_names)
    rng = np.random.default_rng(seed)
    scores = np.zeros((trials, n), dtype=np.float32)
    wins = np.zeros((trials, n), dtype=np.bool_)
    sweeps = np.zeros((trials, n), dtype=np.bool_)
    fz = _z(slate.weak_projection); vz = _z(slate.values)
    ace_z = _z(slate.ace); dblf_z = _z(slate.dblf)
    leverage_z = _z(np.asarray(slate.strategy.strategic_leverage, dtype=float))
    cfg = CALIBRATION["PHASE1"]
    for a, b in slate.pair_indices:
        a_wins = rng.random(trials) < float(win_prob[a])
        wins[:, a] = a_wins; wins[:, b] = ~a_wins
        for p, won in ((a, a_wins), (b, ~a_wins)):
            tour = str(slate.tours[p]).upper()
            sd = float(cfg["ATP_BASE_SD"] if tour == "ATP" else cfg["WTA_BASE_SD"] if tour == "WTA" else cfg["UNKNOWN_TOUR_BASE_SD"])
            win_mu = (
                float(cfg["WIN_BASE_MEAN"]) + 2.0 * float(fz[p]) + 1.5 * float(vz[p])
                + 2.6 * float(leverage_z[p]) + 2.2 * float(serve_index[p])
            )
            loss_mu = float(cfg["LOSS_BASE_MEAN"]) + 0.11 * max(float(slate.weak_projection[p]), 0.0) + 0.8 * float(serve_index[p])
            sweep_evt = won & (rng.random(trials) < float(sweep_prob[p]))
            sweeps[:, p] = sweep_evt
            shared = rng.normal(0.0, 2.4, trials)
            individual = rng.normal(0.0, sd, trials)
            score = np.where(won, win_mu, loss_mu) + shared + individual
            score += sweep_evt * rng.normal(float(cfg["SWEEP_BONUS_MEAN"]), 2.8, trials)
            ace_scale = max(0.15, 0.65 + float(ace_z[p]) * 0.22)
            score += rng.gamma(1.8, ace_scale, trials) * float(cfg["ACE_TAIL_WEIGHT"])
            dblf_risk = max(0.0, 0.8 + float(dblf_z[p]) * 0.3)
            score -= rng.poisson(dblf_risk, trials) * float(cfg["DOUBLE_FAULT_PENALTY_WEIGHT"])
            upset = won & (float(win_prob[p]) < 0.45)
            if np.any(upset):
                score += upset * rng.gamma(1.7, float(cfg["UPSET_TAIL_BONUS"]) / 1.7, trials)
            # Best-of-five creates additional game/ace volume but also more variance.
            if int(slate.best_of[p]) == 5:
                score += won * rng.normal(4.0, 2.2, trials) + (~won) * rng.normal(1.5, 1.8, trials)
            scores[:, p] = np.clip(score, 0.0, None).astype(np.float32)
    player_mean = scores.mean(axis=0).astype(np.float32)
    player_p95 = np.quantile(scores, 0.95, axis=0).astype(np.float32)
    player_p99 = np.quantile(scores, 0.99, axis=0).astype(np.float32)
    k = max(1, int(math.ceil(trials * 0.01)))
    player_cvar99 = np.partition(scores, trials - k, axis=0)[trials - k:].mean(axis=0).astype(np.float32)
    tail_eff = (player_p99 / np.maximum(slate.salaries.astype(np.float32) / 1000.0, 1.0)).astype(np.float32)
    metric_hash = stable_hash({
        "engine": ENGINE_ID, "pool": slate.pool_sha256, "trials": trials, "seed": seed,
        "win_probability": np.round(win_prob, 8).tolist(), "sweep_probability": np.round(sweep_prob, 8).tolist(),
        "serve_index": np.round(serve_index, 8).tolist(), "p99": np.round(player_p99, 6).tolist(),
        "predictive_hash": slate.strategy.receipt.get("PREDICTION_HASH"),
        "event_native_patch": EVENT_NATIVE_PROBABILITY_PATCH_ID,
        "event_native_recovered": int(slate.event_recovered_prior.sum()),
        "event_match_probability": np.round(slate.event_match_win_probability, 8).tolist(),
        "realized_results_used": False,
    })
    return Phase1(scores, wins, sweeps, win_prob, sweep_prob, serve_index, player_mean,
                  player_p95, player_p99, player_cvar99, tail_eff, metric_hash)


@njit(cache=False)
def _count_legal_6(sal: np.ndarray, cap: int) -> int:
    n = len(sal); c = 0
    for a in range(n - 5):
        sa = sal[a]
        for b in range(a + 1, n - 4):
            sab = sa + sal[b]
            for d in range(b + 1, n - 3):
                sabd = sab + sal[d]
                for e in range(d + 1, n - 2):
                    sabde = sabd + sal[e]
                    for f in range(e + 1, n - 1):
                        sabdef = sabde + sal[f]
                        for g in range(f + 1, n):
                            if sabdef + sal[g] <= cap:
                                c += 1
    return c


@njit(cache=False)
def _fill_legal_6(sal: np.ndarray, cap: int, rows: np.ndarray, salaries: np.ndarray) -> int:
    n = len(sal); c = 0
    for a in range(n - 5):
        sa = sal[a]
        for b in range(a + 1, n - 4):
            sab = sa + sal[b]
            for d in range(b + 1, n - 3):
                sabd = sab + sal[d]
                for e in range(d + 1, n - 2):
                    sabde = sabd + sal[e]
                    for f in range(e + 1, n - 1):
                        sabdef = sabde + sal[f]
                        for g in range(f + 1, n):
                            total = sabdef + sal[g]
                            if total <= cap:
                                rows[c, 0] = a; rows[c, 1] = b; rows[c, 2] = d
                                rows[c, 3] = e; rows[c, 4] = f; rows[c, 5] = g
                                salaries[c] = total; c += 1
    return c


@njit(cache=False)
def _count_legal_3(sal: np.ndarray, cap: int) -> int:
    n = len(sal); c = 0
    for a in range(n - 2):
        for b in range(a + 1, n - 1):
            ab = sal[a] + sal[b]
            for d in range(b + 1, n):
                if ab + sal[d] <= cap:
                    c += 1
    return c


@njit(cache=False)
def _fill_legal_3(sal: np.ndarray, cap: int, rows: np.ndarray, salaries: np.ndarray) -> int:
    n = len(sal); c = 0
    for a in range(n - 2):
        for b in range(a + 1, n - 1):
            ab = sal[a] + sal[b]
            for d in range(b + 1, n):
                total = ab + sal[d]
                if total <= cap:
                    rows[c, 0] = a; rows[c, 1] = b; rows[c, 2] = d
                    salaries[c] = total; c += 1
    return c


def enumerate_legal(slate: Slate, config: RuntimeConfig, work_dir: Path) -> tuple[np.memmap, np.memmap, int]:
    if len(slate.player_names) < config.roster_size:
        raise EngineError("RUN_INVALID:TENNIS_POOL_SMALLER_THAN_ROSTER")
    if config.roster_size == 6:
        count = int(_count_legal_6(slate.salaries, config.salary_cap))
    else:
        count = int(_count_legal_3(slate.salaries, config.salary_cap))
    if count <= 0:
        raise EngineError("RUN_INVALID:NO_CAP_LEGAL_TENNIS_LINEUPS")
    work_dir.mkdir(parents=True, exist_ok=True)
    rows_path = work_dir / f"tennis_legal_{config.execution_id}_{config.roster_size}.i16"
    sal_path = work_dir / f"tennis_legal_{config.execution_id}_{config.roster_size}.i32"
    rows = np.memmap(rows_path, dtype=np.int16, mode="w+", shape=(count, config.roster_size))
    salaries = np.memmap(sal_path, dtype=np.int32, mode="w+", shape=(count,))
    filled = int(_fill_legal_6(slate.salaries, config.salary_cap, rows, salaries) if config.roster_size == 6
                 else _fill_legal_3(slate.salaries, config.salary_cap, rows, salaries))
    if filled != count:
        raise EngineError(f"ENGINE_INTEGRITY_HALT:TENNIS_LEGAL_COUNT_FILL_MISMATCH:{count}!={filled}")
    rows.flush(); salaries.flush()
    return rows, salaries, count


def _lineup_sum(values: np.ndarray, rows: np.ndarray) -> np.ndarray:
    out = values[rows[:, 0]].astype(np.float64, copy=True)
    for s in range(1, rows.shape[1]):
        out += values[rows[:, s]]
    return out


def _same_match_pairs(rows: np.ndarray, opponent_index: np.ndarray) -> np.ndarray:
    n = len(rows); out = np.zeros(n, dtype=np.int8)
    for s in range(rows.shape[1]):
        p = rows[:, s]
        opp = opponent_index[p]
        for t in range(s + 1, rows.shape[1]):
            out += (rows[:, t] == opp).astype(np.int8)
    return out


def structural_features(slate: Slate, phase1: Phase1, rows: np.ndarray, salaries: np.ndarray) -> dict[str, np.ndarray]:
    dog_thresh = float(CALIBRATION["PHASE2"]["DOG_PROBABILITY"])
    low_sal = int(CALIBRATION["PHASE2"]["PLAYER_LOW_SALARY"])
    premium_sal = int(CALIBRATION["PHASE2"]["PLAYER_PREMIUM_SALARY"])
    dogs = (phase1.win_probability < dog_thresh).astype(np.int8)
    lows = (slate.salaries <= low_sal).astype(np.int8)
    premiums = (slate.salaries >= premium_sal).astype(np.int8)
    atp = (slate.tours == "ATP").astype(np.int8)
    wta = (slate.tours == "WTA").astype(np.int8)
    missing = slate.missing_weak_prior.astype(np.int8)
    return {
        "salary": np.asarray(salaries, dtype=np.int32),
        "salary_left": (SALARY_CAP - np.asarray(salaries, dtype=np.int32)),
        "dog_count": _lineup_sum(dogs, rows).astype(np.int8),
        "low_salary_count": _lineup_sum(lows, rows).astype(np.int8),
        "premium_count": _lineup_sum(premiums, rows).astype(np.int8),
        "atp_count": _lineup_sum(atp, rows).astype(np.int8),
        "wta_count": _lineup_sum(wta, rows).astype(np.int8),
        "same_match_pair_count": _same_match_pairs(rows, slate.opponent_index),
        "missing_prior_count": _lineup_sum(missing, rows).astype(np.int8),
    }


def _family_codes(struct: dict[str, np.ndarray]) -> np.ndarray:
    bands = np.digitize(struct["salary"], np.asarray(CALIBRATION["PHASE2"]["SALARY_BANDS"], dtype=np.int32), right=False)
    return (
        bands.astype(np.int64)
        + 8 * struct["dog_count"].astype(np.int64)
        + 64 * struct["premium_count"].astype(np.int64)
        + 512 * struct["low_salary_count"].astype(np.int64)
        + 4096 * struct["atp_count"].astype(np.int64)
        + 32768 * struct["same_match_pair_count"].astype(np.int64)
    )


def _top_merge(existing_idx: np.ndarray, existing_val: np.ndarray, idx: np.ndarray, val: np.ndarray, keep: int) -> tuple[np.ndarray, np.ndarray]:
    if len(idx) > keep:
        take = np.argpartition(val, len(val) - keep)[len(val) - keep:]
        idx = idx[take]; val = val[take]
    if len(existing_idx) == 0:
        order = np.argsort(val, kind="stable")[::-1]
        return idx[order], val[order]
    mi = np.concatenate((existing_idx, idx)); mv = np.concatenate((existing_val, val))
    if len(mi) > keep:
        take = np.argpartition(mv, len(mv) - keep)[len(mv) - keep:]
        mi = mi[take]; mv = mv[take]
    order = np.argsort(mv, kind="stable")[::-1]
    return mi[order], mv[order]




# --- TENNIS_CLASSIC_DETERMINISTIC_SCENARIO_MID_PAIR_CLOSURE_v1 (production) ---
SCENARIO_BINS = 64
SCENARIOS_PER_BIN = 24
SCENARIO_PAIR_KEEP = 32

@njit(cache=False)
def _scenario_optimize_v2(scores: np.ndarray, salary_units: np.ndarray):
    nsc, n = scores.shape
    out = np.full((nsc, 6), -1, dtype=np.int16)
    for t in range(nsc):
        dp = np.full((7, 501), -1e20, dtype=np.float32)
        picks = np.full((7, 501, 6), -1, dtype=np.int16)
        dp[0, 0] = 0.0
        for i in range(n):
            su = int(salary_units[i]); val = scores[t, i]
            for k in range(6, 0, -1):
                for b in range(500, su - 1, -1):
                    prev = dp[k-1, b-su]
                    if prev <= -1e19: continue
                    cand = prev + val
                    if cand > dp[k, b]:
                        dp[k, b] = cand
                        for z in range(6): picks[k,b,z] = picks[k-1,b-su,z]
                        picks[k,b,k-1] = i
        best_b = 0; best = -1e20
        for b in range(501):
            if dp[6,b] > best: best=dp[6,b]; best_b=b
        for z in range(6): out[t,z]=picks[6,best_b,z]
        out[t].sort()
    return out

@njit(cache=False)
def _core_pair_top_v2(cores, salary, wp, ceiling, missing, tours_atp, keep):
    ncores=cores.shape[0]; n=len(salary)
    out=np.full((ncores,keep,2),-1,dtype=np.int16)
    score=np.full((ncores,keep),-1e30,dtype=np.float32)
    for ci in range(ncores):
        c0,c1,c2,c3=[int(x) for x in cores[ci]]
        core_salary=salary[c0]+salary[c1]+salary[c2]+salary[c3]
        core_ceiling=ceiling[c0]+ceiling[c1]+ceiling[c2]+ceiling[c3]
        for a in range(n-1):
            if a==c0 or a==c1 or a==c2 or a==c3: continue
            for b in range(a+1,n):
                if b==c0 or b==c1 or b==c2 or b==c3: continue
                total=core_salary+salary[a]+salary[b]
                if total>50000: continue
                # same-match coexistence remains allowed under v2 contract.
                val=core_ceiling+ceiling[a]+ceiling[b] + 3.0*(wp[a]+wp[b])
                mi=0; mv=score[ci,0]
                for z in range(1,keep):
                    if score[ci,z]<mv: mi=z; mv=score[ci,z]
                if val>mv:
                    score[ci,mi]=val; out[ci,mi,0]=a; out[ci,mi,1]=b
    return out

@njit(cache=False)
def _core_pair_top_mid_p99_v2(cores, salary, p99, wp, missing, tours_atp, keep):
    ncores=cores.shape[0]; n=len(salary)
    out=np.full((ncores,keep,2),-1,dtype=np.int16)
    score=np.full((ncores,keep),-1e30,dtype=np.float32)
    for ci in range(ncores):
        c0,c1,c2,c3=[int(x) for x in cores[ci]]
        core_salary=salary[c0]+salary[c1]+salary[c2]+salary[c3]
        core_p99=p99[c0]+p99[c1]+p99[c2]+p99[c3]
        for a in range(n-1):
            if a==c0 or a==c1 or a==c2 or a==c3: continue
            for b in range(a+1,n):
                if b==c0 or b==c1 or b==c2 or b==c3: continue
                final_salary=core_salary+salary[a]+salary[b]
                if final_salary<40000 or final_salary>50000: continue
                dog=(wp[c0]<0.5)+(wp[c1]<0.5)+(wp[c2]<0.5)+(wp[c3]<0.5)+(wp[a]<0.5)+(wp[b]<0.5)
                if dog<1: continue
                val=core_p99+p99[a]+p99[b]
                mi=0; mv=score[ci,0]
                for z in range(1,keep):
                    if score[ci,z]<mv: mi=z; mv=score[ci,z]
                if val>mv:
                    score[ci,mi]=val; out[ci,mi,0]=a; out[ci,mi,1]=b
    return out

def deterministic_scenario_mid_pair_closure_v2(slate: Slate, phase1: Phase1):
    totals=phase1.player_scores.sum(axis=1)
    order=np.argsort(totals,kind='stable')
    selected=[]
    for bn in range(SCENARIO_BINS):
        lo=bn*len(order)//SCENARIO_BINS; hi=(bn+1)*len(order)//SCENARIO_BINS
        g=order[lo:hi]
        pos=np.linspace(0,len(g)-1,SCENARIOS_PER_BIN,dtype=int)
        selected.extend(g[pos].tolist())
    scenario_scores=phase1.player_scores[np.asarray(selected,dtype=np.int64)].astype(np.float32,copy=False)
    champions=_scenario_optimize_v2(scenario_scores,(slate.salaries//100).astype(np.int16))
    champions=np.unique(champions,axis=0)
    core_set=set()
    for row in champions:
        for core in itertools.combinations(row.tolist(),4): core_set.add(tuple(int(x) for x in core))
    cores=np.asarray(sorted(core_set),dtype=np.int16)
    # Preserve the richer pre-lock completion lanes from the prior production route.
    pair_top=_core_pair_top_v2(cores,slate.salaries.astype(np.int32),phase1.win_probability.astype(np.float64),phase1.player_p99.astype(np.float64),slate.missing_weak_prior.astype(np.uint8),(slate.tours=='ATP').astype(np.uint8),SCENARIO_PAIR_KEEP)
    mid_top=_core_pair_top_mid_p99_v2(cores,slate.salaries.astype(np.int32),phase1.player_p99.astype(np.float64),phase1.win_probability.astype(np.float64),slate.missing_weak_prior.astype(np.uint8),(slate.tours=='ATP').astype(np.uint8),24)
    rows=[]
    for ci,core in enumerate(cores):
        for a,b in pair_top[ci]:
            if a>=0: rows.append(np.sort(np.r_[core,[a,b]]).astype(np.int16))
        for a,b in mid_top[ci]:
            if a>=0: rows.append(np.sort(np.r_[core,[a,b]]).astype(np.int16))
    closure=np.unique(np.vstack([champions,np.asarray(rows,dtype=np.int16)]),axis=0) if rows else champions
    receipt={'SCENARIO_TRIALS':int(len(selected)),'SCENARIO_CHAMPIONS':int(len(champions)),'SCENARIO_CORES':int(len(cores)),'SCENARIO_CLOSURE_UNIQUE':int(len(closure)),'SCENARIO_MID_PAIR_CLOSURE':'ACTIVE_PRODUCTION','POSTLOCK_INPUT_USED':False,'PLAYER_NAME_INPUT_USED':False}
    return closure,receipt

def missing_prior_near_tie_one_swap_closure(
    slate: Slate, rows: np.ndarray, salaries: np.ndarray, config: RuntimeConfig
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    cfg = DOCTRINE["PHASE2"]["MISSING_PRIOR_NEAR_TIE_CLOSURE"]
    if not bool(cfg.get("ENABLED", True)):
        return rows, salaries, {"MISSING_PRIOR_SIBLING_CLOSURE": "DISABLED", "MISSING_PRIOR_SIBLING_ADDITIONS": 0}
    missing = np.flatnonzero(slate.missing_weak_prior).astype(np.int16)
    if len(missing) < 2 or len(rows) == 0:
        return rows, salaries, {
            "MISSING_PRIOR_SIBLING_CLOSURE": "NO_EQUIVALENCE_CLASS",
            "MISSING_PRIOR_EQUIVALENCE_PLAYERS": int(len(missing)),
            "MISSING_PRIOR_SIBLING_ADDITIONS": 0,
        }
    proj_eps = float(cfg["PROJECTION_EPSILON"])
    val_eps = float(cfg["VALUE_EPSILON"])
    additions: list[np.ndarray] = []
    addition_salary: list[np.ndarray] = []
    for p in missing:
        p = int(p)
        base_mask = np.any(rows == p, axis=1)
        if not np.any(base_mask):
            continue
        base_rows = rows[base_mask]
        base_salary = salaries[base_mask]
        for qv in missing:
            q = int(qv)
            if q == p:
                continue
            if abs(float(slate.weak_projection[q]) - float(slate.weak_projection[p])) > proj_eps:
                continue
            if abs(float(slate.values[q]) - float(slate.values[p])) > val_eps:
                continue
            eligible = ~np.any(base_rows == q, axis=1)
            new_salary = base_salary - int(slate.salaries[p]) + int(slate.salaries[q])
            eligible &= new_salary <= SALARY_CAP
            if not np.any(eligible):
                continue
            block = base_rows[eligible].copy()
            block[block == p] = q
            block.sort(axis=1)
            additions.append(block)
            addition_salary.append(new_salary[eligible].astype(np.int32, copy=False))
    if not additions:
        return rows, salaries, {
            "MISSING_PRIOR_SIBLING_CLOSURE": "PASS_NO_ADDITIONS",
            "MISSING_PRIOR_EQUIVALENCE_PLAYERS": int(len(missing)),
            "MISSING_PRIOR_SIBLING_ADDITIONS": 0,
        }
    add_rows = np.vstack(additions).astype(rows.dtype, copy=False)
    add_salary = np.concatenate(addition_salary).astype(np.int32, copy=False)
    all_rows = np.vstack([rows, add_rows])
    all_salary = np.concatenate([salaries, add_salary])
    view = np.ascontiguousarray(all_rows).view(np.dtype((np.void, all_rows.dtype.itemsize * all_rows.shape[1]))).ravel()
    _, first = np.unique(view, return_index=True)
    first.sort()
    unique_rows = all_rows[first]
    unique_salary = all_salary[first]
    additions_unique = int(len(unique_rows) - len(rows))
    return unique_rows, unique_salary, {
        "MISSING_PRIOR_SIBLING_PATCH_ID": MISSING_PRIOR_SIBLING_PATCH_ID,
        "MISSING_PRIOR_SIBLING_CLOSURE": "PASS",
        "MISSING_PRIOR_EQUIVALENCE_PLAYERS": int(len(missing)),
        "MISSING_PRIOR_PROJECTION_EPSILON": proj_eps,
        "MISSING_PRIOR_VALUE_EPSILON": val_eps,
        "MISSING_PRIOR_SIBLING_ADDITIONS": additions_unique,
    }


def phase2_birth(slate: Slate, phase1: Phase1, legal: np.memmap, legal_salary: np.memmap, config: RuntimeConfig) -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray], dict[str, Any]]:
    p2 = CALIBRATION["PHASE2"]
    keep_axis = int(p2["GLOBAL_AXIS_KEEP"])
    per_family = int(p2["PER_FAMILY_KEEP"])
    chunk = int(p2["LINEUP_SCAN_CHUNK"])
    axes: dict[str, tuple[np.ndarray, np.ndarray]] = {
        k: (np.asarray([], dtype=np.int64), np.asarray([], dtype=np.float64))
        for k in ("p99", "cvar99", "win_path", "sweep", "serve", "upset_eff", "leverage")
    }
    families: dict[int, tuple[np.ndarray, np.ndarray]] = {}
    logwin = np.log(np.clip(phase1.win_probability.astype(np.float64), 1e-6, 1.0))
    sal_k = np.maximum(slate.salaries.astype(np.float64) / 1000.0, 1.0)
    upset_player = ((1.0 - phase1.win_probability) * phase1.player_p99 / sal_k).astype(np.float64)
    leverage_player = np.asarray(slate.strategy.strategic_leverage, dtype=np.float64)
    scanned = 0
    for st in range(0, len(legal), chunk):
        en = min(len(legal), st + chunk)
        rows = np.asarray(legal[st:en])
        salaries = np.asarray(legal_salary[st:en])
        struct = structural_features(slate, phase1, rows, salaries)
        p99 = _lineup_sum(phase1.player_p99, rows)
        cvar = _lineup_sum(phase1.player_cvar99, rows)
        same = struct["same_match_pair_count"].astype(np.float64)
        win_path = np.exp(_lineup_sum(logwin, rows) / rows.shape[1]) * np.power(0.55, same)
        sweep = _lineup_sum(phase1.sweep_probability * phase1.player_p99, rows) / rows.shape[1]
        serve = _lineup_sum(phase1.serve_index, rows)
        upset_eff = _lineup_sum(upset_player, rows)
        leverage = _lineup_sum(leverage_player, rows) + 0.12 * (SALARY_CAP - salaries) / 1000.0
        vals = {"p99": p99, "cvar99": cvar, "win_path": win_path, "sweep": sweep, "serve": serve,
                "upset_eff": upset_eff, "leverage": leverage}
        global_idx = np.arange(st, en, dtype=np.int64)
        for k, v in vals.items():
            axes[k] = _top_merge(axes[k][0], axes[k][1], global_idx, np.asarray(v, dtype=np.float64), keep_axis)
        family_code = _family_codes(struct)
        composite = (
            0.34 * _pct(p99) + 0.20 * _pct(cvar) + 0.18 * _pct(win_path)
            + 0.10 * _pct(sweep) + 0.07 * _pct(upset_eff) + 0.06 * _pct(leverage) + 0.05 * _pct(serve)
        ).astype(np.float64)
        for code in np.unique(family_code):
            m = family_code == code
            idx = global_idx[m]; val = composite[m]
            prev = families.get(int(code), (np.asarray([], dtype=np.int64), np.asarray([], dtype=np.float64)))
            families[int(code)] = _top_merge(prev[0], prev[1], idx, val, per_family)
        scanned += len(rows)
    if scanned != len(legal):
        raise EngineError("ENGINE_INTEGRITY_HALT:TENNIS_FULL_LEGAL_SCAN_INCOMPLETE")
    parts = [x[0] for x in axes.values()] + [v[0] for v in families.values()]
    candidate_idx = np.unique(np.concatenate(parts)).astype(np.int64)
    candidate_rows = np.asarray(legal[candidate_idx]).copy()
    candidate_salary = np.asarray(legal_salary[candidate_idx]).copy()

    # Deterministic family sibling closure: add the strongest legal one-swap sibling
    # for the best calibration seeds. This uses only frozen Phase-1 metrics.
    sibling_keep = int(p2["FAMILY_SIBLING_KEEP"])
    seed_cap = min(3000, len(candidate_rows))
    p99_sum = _lineup_sum(phase1.player_p99, candidate_rows)
    seed_order = np.argsort(p99_sum, kind="stable")[::-1][:seed_cap]
    player_order = np.argsort(phase1.player_p99 + 0.35 * phase1.player_cvar99 + 0.15 * phase1.tail_efficiency, kind="stable")[::-1][:min(40, len(slate.player_names))]
    siblings: list[np.ndarray] = []
    sibling_salary: list[int] = []
    for si in seed_order:
        row = candidate_rows[si]
        existing = set(map(int, row))
        scored: list[tuple[float, np.ndarray, int]] = []
        for slot in range(config.roster_size):
            removed = int(row[slot])
            base_salary = int(candidate_salary[si]) - int(slate.salaries[removed])
            for newp in player_order:
                npid = int(newp)
                if npid in existing:
                    continue
                total = base_salary + int(slate.salaries[npid])
                if total > SALARY_CAP:
                    continue
                nr = row.copy(); nr[slot] = npid; nr.sort()
                sc = float(np.sum(phase1.player_p99[nr]) + 0.45 * np.sum(phase1.player_cvar99[nr]) + 3.0 * np.mean(phase1.win_probability[nr]))
                scored.append((sc, nr, total))
                if len(scored) >= sibling_keep * 6:
                    break
            if len(scored) >= sibling_keep * 6:
                break
        scored.sort(key=lambda x: x[0], reverse=True)
        for _, nr, total in scored[:sibling_keep]:
            siblings.append(nr); sibling_salary.append(total)
    if siblings:
        all_rows = np.vstack([candidate_rows, np.asarray(siblings, dtype=candidate_rows.dtype)])
        all_salary = np.concatenate([candidate_salary, np.asarray(sibling_salary, dtype=np.int32)])
        view = np.ascontiguousarray(all_rows).view(np.dtype((np.void, all_rows.dtype.itemsize * all_rows.shape[1]))).ravel()
        _, first = np.unique(view, return_index=True)
        first.sort()
        candidate_rows = all_rows[first]
        all_salary = all_salary[first]
        candidate_salary = all_salary
    # Production repair: restore deterministic scenario + mid-pair closure and preserve all
    # calibration-qualified rows. Arbitrary Phase-2 hard truncation is prohibited.
    if config.roster_size == 6:
        scenario_rows, scenario_receipt = deterministic_scenario_mid_pair_closure_v2(slate, phase1)
    else:
        scenario_rows = np.empty((0, config.roster_size), dtype=candidate_rows.dtype)
        scenario_receipt = {"STATUS": "SKIP_NONSTANDARD_ROSTER", "ROSTER_SIZE": int(config.roster_size)}
    if len(scenario_rows):
        all_rows = np.vstack([candidate_rows, scenario_rows.astype(candidate_rows.dtype, copy=False)])
        all_salary = np.concatenate([candidate_salary, slate.salaries[scenario_rows].sum(axis=1).astype(np.int32)])
        view = np.ascontiguousarray(all_rows).view(np.dtype((np.void, all_rows.dtype.itemsize * all_rows.shape[1]))).ravel()
        _, first = np.unique(view, return_index=True)
        first.sort(); candidate_rows = all_rows[first]; candidate_salary = all_salary[first]
    candidate_rows, candidate_salary, missing_prior_receipt = missing_prior_near_tie_one_swap_closure(
        slate, candidate_rows, candidate_salary, config
    )
    max_candidates = int(p2.get("MAX_CANDIDATES", 0))
    if False and max_candidates > 0 and len(candidate_rows) > max_candidates:
        # Calibration-qualified capacity seal, not a selector truncation: preserve
        # family representation first, then fill by frozen Phase-1 right-tail score.
        struct = structural_features(slate, phase1, candidate_rows, candidate_salary)
        fam = _family_codes(struct)
        score = _lineup_sum(phase1.player_p99 + 0.45 * phase1.player_cvar99 + 0.10 * phase1.tail_efficiency, candidate_rows)
        protected: list[int] = []
        for code in np.unique(fam):
            ids = np.flatnonzero(fam == code)
            k = min(per_family, len(ids))
            if k:
                top = ids[np.argpartition(score[ids], len(ids) - k)[len(ids) - k:]] if k < len(ids) else ids
                protected.extend(map(int, top))
        protected = sorted(set(protected))
        remain = max_candidates - min(len(protected), max_candidates)
        if len(protected) >= max_candidates:
            chosen = np.asarray(protected, dtype=np.int64)
            chosen = chosen[np.argsort(score[chosen], kind="stable")[::-1][:max_candidates]]
        else:
            mask = np.ones(len(candidate_rows), dtype=bool); mask[protected] = False
            rest = np.flatnonzero(mask)
            top_rest = rest[np.argsort(score[rest], kind="stable")[::-1][:remain]]
            chosen = np.asarray(protected + list(map(int, top_rest)), dtype=np.int64)
        candidate_rows = candidate_rows[chosen]; candidate_salary = candidate_salary[chosen]
    struct_final = structural_features(slate, phase1, candidate_rows, candidate_salary)
    receipt = {
        "CAP_LEGAL_SCANNED": int(len(legal)), "FULL_LEGAL_VISIBILITY_SCAN": "PASS",
        "GLOBAL_AXIS_BIRTHS_UNION": int(len(candidate_idx)), "STRUCTURAL_FAMILIES_SEEN": int(len(families)),
        "FAMILY_SIBLING_ADDITIONS": int(max(0, len(candidate_rows) - len(candidate_idx))),
        **scenario_receipt,
        **missing_prior_receipt,
        "ARBITRARY_MAX_CANDIDATE_CULL": "DISABLED_PRODUCTION",
        "PHASE2_BUILT_LINEUPS": int(len(candidate_rows)), "PHASE2_FREEZE": "PASS",
    }
    return candidate_rows.astype(np.int16, copy=False), candidate_salary.astype(np.int32, copy=False), struct_final, receipt


def build_fake_field(slate: Slate, phase1: Phase1, rows: np.ndarray, salaries: np.ndarray, *, field_size: int, seed: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    n = len(rows)
    if n == 0:
        raise EngineError("ENGINE_INTEGRITY_HALT:TENNIS_PHASE2_EMPTY")
    rst = slate.rst.copy()
    rst_missing = ~np.isfinite(rst)
    public_player = 1.15 * _z(phase1.win_probability) + 0.38 * _z(slate.salaries) + 0.28 * _z(slate.weak_projection)
    if (~rst_missing).any():
        imputed = rst.copy(); imputed[rst_missing] = float(np.nanmedian(rst[~rst_missing]))
        public_player += 0.72 * _z(imputed)
    logw = _lineup_sum(public_player.astype(np.float64), rows) + 0.18 * (salaries - 46000) / 4000.0
    logw -= float(np.max(logw))
    w = np.exp(np.clip(logw, -45.0, 0.0))
    cdf = np.cumsum(w, dtype=np.float64)
    if cdf[-1] <= 0:
        raise EngineError("ENGINE_INTEGRITY_HALT:TENNIS_FAKE_FIELD_ZERO_WEIGHT")
    fake_n = min(int(math.ceil(field_size * float(CALIBRATION["FAKE_FIELD"]["FIELD_SIZE_MULTIPLIER"]))), int(CALIBRATION["FAKE_FIELD"]["MAX_FIELD_SAMPLE"]))
    fake_n = max(fake_n, min(200, n))
    rng = np.random.default_rng(seed)
    fake_idx = np.searchsorted(cdf, rng.random(fake_n) * cdf[-1], side="right").astype(np.int32)
    fake_rows = rows[fake_idx]
    counts = np.bincount(fake_rows.ravel(), minlength=len(slate.player_names)).astype(np.float64)
    player_own = (counts / fake_n).astype(np.float32)
    logown = np.log(np.clip(player_own, 1e-6, 1.0))
    lineup_own_product = np.exp(_lineup_sum(logown, rows)).astype(np.float32)
    dup = np.bincount(fake_idx, minlength=n).astype(np.int32)
    return fake_idx, player_own, lineup_own_product, dup


def _score_matrix(player_scores: np.ndarray, rows: np.ndarray) -> np.ndarray:
    s = player_scores[:, rows[:, 0]].copy()
    for slot in range(1, rows.shape[1]):
        s += player_scores[:, rows[:, slot]]
    return s


def field_thresholds(player_scores: np.ndarray, field_rows: np.ndarray, *, quantile: float = 0.001, chunk: int = 384) -> tuple[np.ndarray, np.ndarray]:
    trials = player_scores.shape[0]
    k = max(1, int(math.ceil(len(field_rows) * quantile)))
    top = np.full((trials, k), -np.inf, dtype=np.float32)
    max_field = np.full(trials, -np.inf, dtype=np.float32)
    for st in range(0, len(field_rows), chunk):
        block = field_rows[st:st + chunk]
        scores = _score_matrix(player_scores, block)
        max_field = np.maximum(max_field, np.max(scores, axis=1))
        combined = np.concatenate((top, scores), axis=1)
        top = np.partition(combined, combined.shape[1] - k, axis=1)[:, -k:]
    threshold = np.min(top, axis=1)
    return threshold.astype(np.float32), max_field.astype(np.float32)


def _score_lineup_block_fast(player_scores: np.ndarray, lineups: np.ndarray, threshold: np.ndarray | None, max_field: np.ndarray | None) -> dict[str, np.ndarray]:
    n_lineups=len(lineups); n_trials=player_scores.shape[0]
    mean=np.empty(n_lineups,dtype=np.float32); p95=np.empty(n_lineups,dtype=np.float32); p99=np.empty(n_lineups,dtype=np.float32); cvar99=np.empty(n_lineups,dtype=np.float32)
    top_count=np.zeros(n_lineups,dtype=np.int32); win_count=np.zeros(n_lineups,dtype=np.int32)
    dt=player_scores.dtype.type
    q95=dt(n_trials-1)*dt(0.95); q99=dt(n_trials-1)*dt(0.99)
    i95=int(math.floor(float(q95))); j95=int(math.ceil(float(q95))); a95=dt(q95-dt(i95))
    i99=int(math.floor(float(q99))); j99=int(math.ceil(float(q99))); a99=dt(q99-dt(i99))
    k=max(1,int(math.ceil(n_trials*0.01))); tail0=n_trials-k
    scores=_score_matrix(player_scores,lineups)
    mean[:]=scores.mean(axis=0)
    part=np.partition(scores,tuple(sorted({i95,j95,i99,j99,tail0})),axis=0)
    p95[:]=part[i95]+(part[j95]-part[i95])*a95
    p99[:]=part[i99]+(part[j99]-part[i99])*a99
    cvar99[:]=part[tail0:].mean(axis=0)
    if threshold is not None and max_field is not None:
        top_count[:]=(scores>=threshold[:,None]).sum(axis=0)
        win_count[:]=(scores>=max_field[:,None]).sum(axis=0)
    return {"mean":mean,"p95":p95,"p99":p99,"cvar99":cvar99,"top01_count":top_count,"win_count":win_count}

def score_lineups(player_scores: np.ndarray, rows: np.ndarray, *, threshold: np.ndarray | None = None, max_field: np.ndarray | None = None, chunk: int = 4096) -> dict[str, np.ndarray]:
    n=len(rows); trials=player_scores.shape[0]
    mean=np.empty(n,dtype=np.float32); p95=np.empty(n,dtype=np.float32); p99=np.empty(n,dtype=np.float32); cvar99=np.empty(n,dtype=np.float32)
    top_count=np.zeros(n,dtype=np.int32); win_count=np.zeros(n,dtype=np.int32)
    workers=max(1,min(int(os.environ.get("APEX_TENNIS_SCORE_WORKERS","5")),os.cpu_count() or 1))
    task_chunk=max(128,min(int(chunk),int(os.environ.get("APEX_TENNIS_SCORE_TASK_CHUNK","4096"))))
    ranges=[(st,min(n,st+task_chunk)) for st in range(0,n,task_chunk)]
    def process(bounds):
        st,en=bounds; return st,en,_score_lineup_block_fast(player_scores,np.asarray(rows[st:en]),threshold,max_field)
    executor=None
    completed=map(process,ranges) if workers==1 or len(ranges)<=1 else (executor:=ThreadPoolExecutor(max_workers=workers,thread_name_prefix="tennis-score")).map(process,ranges)
    try:
        for st,en,b in completed:
            mean[st:en]=b["mean"]; p95[st:en]=b["p95"]; p99[st:en]=b["p99"]; cvar99[st:en]=b["cvar99"]
            top_count[st:en]=b["top01_count"]; win_count[st:en]=b["win_count"]
    finally:
        if executor is not None: executor.shutdown(wait=True)
    return {"mean":mean,"p95":p95,"p99":p99,"cvar99":cvar99,"top01_count":top_count,"win_count":win_count,
            "top01_rate":top_count.astype(np.float64)/max(trials,1),"win_rate":win_count.astype(np.float64)/max(trials,1),
            "trials":np.full(n,trials,dtype=np.int32)}

def _wilson(count: np.ndarray, trials: np.ndarray | int, z: float = 1.96) -> tuple[np.ndarray, np.ndarray]:
    c = np.asarray(count, dtype=np.float64); n = np.asarray(trials, dtype=np.float64)
    p = c / np.maximum(n, 1.0); den = 1.0 + z * z / np.maximum(n, 1.0)
    center = (p + z * z / (2.0 * np.maximum(n, 1.0))) / den
    half = z * np.sqrt((p * (1.0 - p) / np.maximum(n, 1.0)) + (z * z / (4.0 * np.maximum(n, 1.0) ** 2))) / den
    return np.maximum(0.0, center - half), np.minimum(1.0, center + half)


def adaptive_bubble(phase1: Phase1, rows: np.ndarray, fake_rows: np.ndarray, metrics: dict[str, np.ndarray], *, base_trials: int, config: RuntimeConfig) -> tuple[dict[str, np.ndarray], int, int, int, str]:
    max_trials = min(int(CALIBRATION["HANDOFF"]["MAX_PHYSICAL_SIM_TRIALS"]), phase1.player_scores.shape[0])
    if max_trials <= base_trials or len(rows) == 0:
        return metrics, 0, 0, 0, stable_hash({"bubble": "none", "base": base_trials})
    preliminary = (0.42 * _pct(metrics["p99"]) + 0.24 * _pct(metrics["cvar99"]) + 0.20 * _pct(metrics["p95"]) + 0.14 * _pct(metrics["top01_rate"]))
    frontier_n = min(len(rows), max(config.board_size * int(CALIBRATION["HANDOFF"]["BUBBLE_FRONTIER_MULTIPLIER"]), 64))
    frontier = np.argsort(preliminary, kind="stable")[::-1][:frontier_n]
    lo, hi = _wilson(metrics["top01_count"], metrics["trials"])
    cutoff = frontier[-1] if len(frontier) else 0
    cutoff_lo = lo[cutoff] if len(frontier) else 0.0
    bubble = frontier[hi[frontier] >= cutoff_lo - 1e-12]
    if len(bubble) == 0:
        bubble = frontier
    extra_scores = phase1.player_scores[base_trials:max_trials]
    threshold_extra, max_extra = field_thresholds(extra_scores, fake_rows, quantile=float(CALIBRATION["FAKE_FIELD"]["TOP_0_1_QUANTILE"]))
    extra = score_lineups(extra_scores, rows[bubble], threshold=threshold_extra, max_field=max_extra)
    total_trials = max_trials
    # Counts combine exactly; tail metrics are recomputed over full trials for bubble rows.
    metrics["top01_count"][bubble] += extra["top01_count"]
    metrics["win_count"][bubble] += extra["win_count"]
    metrics["trials"][bubble] = total_trials
    metrics["top01_rate"][bubble] = metrics["top01_count"][bubble] / total_trials
    metrics["win_rate"][bubble] = metrics["win_count"][bubble] / total_trials
    full_threshold = None; full_max = None
    full = score_lineups(phase1.player_scores[:max_trials], rows[bubble], threshold=full_threshold, max_field=full_max)
    for k in ("mean", "p95", "p99", "cvar99"):
        metrics[k][bubble] = full[k]
    extra_total = int((max_trials - base_trials) * len(bubble))
    bubble_hash = stable_hash({"rows": bubble.tolist(), "base": base_trials, "max": max_trials, "metric_hash": phase1.metric_hash})
    return metrics, extra_total, int(len(bubble)), 0, bubble_hash


def lineup_calibration_features(slate: Slate, phase1: Phase1, rows: np.ndarray, struct: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    logwin = np.log(np.clip(phase1.win_probability.astype(np.float64), 1e-6, 1.0))
    win_path = np.exp(_lineup_sum(logwin, rows) / rows.shape[1]) * np.power(0.55, struct["same_match_pair_count"].astype(np.float64))
    sweep = _lineup_sum(phase1.sweep_probability * phase1.player_p99, rows) / rows.shape[1]
    serve = _lineup_sum(phase1.serve_index, rows)
    return {"win_path": win_path.astype(np.float32), "sweep_ceiling": sweep.astype(np.float32), "serve_ceiling": serve.astype(np.float32)}


def selector_full_order(slate: Slate, phase1: Phase1, rows: np.ndarray, salaries: np.ndarray, struct: dict[str, np.ndarray], metrics: dict[str, np.ndarray], lineup_own: np.ndarray, dup: np.ndarray) -> tuple[np.ndarray, dict[str, np.ndarray], np.ndarray]:
    calfeat = lineup_calibration_features(slate, phase1, rows, struct)
    weights = CALIBRATION["SELECTOR"]["WEIGHTS"]
    uniqueness = -np.log(np.clip(lineup_own.astype(np.float64), 1e-12, 1.0))
    lowdup = -dup.astype(np.float64)
    parts = {
        "TOP_0_1_RATE": _pct(metrics["top01_rate"]),
        "WIN_RATE": _pct(metrics["win_rate"]),
        "P99": _pct(metrics["p99"]),
        "CVAR99": _pct(metrics["cvar99"]),
        "P95": _pct(metrics["p95"]),
        "WIN_PATH": _pct(calfeat["win_path"]),
        "SWEEP_CEILING": _pct(calfeat["sweep_ceiling"]),
        "SERVE_CEILING": _pct(calfeat["serve_ceiling"]),
        "UNIQUENESS": _pct(uniqueness),
        "LOW_DUP": _pct(lowdup),
    }
    objective = np.zeros(len(rows), dtype=np.float64)
    for k, w in weights.items():
        objective += float(w) * parts[k]
    order = np.argsort(objective, kind="stable")[::-1]
    strict = (
        (parts["P99"] >= 0.80)
        & ((metrics["top01_count"] > 0) | (metrics["win_count"] > 0) | (parts["WIN_PATH"] >= 0.80) | (parts["SWEEP_CEILING"] >= 0.85))
    )
    repair_cfg = DOCTRINE["SELECTOR"]["MISSING_PRIOR_UPSET_SENTINEL"]
    salary_pct = _pct(salaries)
    repair_score = np.zeros(len(rows), dtype=np.float64)
    repair_eligible = np.zeros(len(rows), dtype=bool)
    if bool(repair_cfg.get("ENABLED", True)) and rows.shape[1] == int(repair_cfg["ROSTER_SIZE"]):
        w = repair_cfg["WEIGHTS"]
        repair_score = (
            float(w["WIN_PATH"]) * parts["WIN_PATH"]
            + float(w["SALARY_PERCENTILE"]) * salary_pct
            + float(w["LOW_DUP"]) * parts["LOW_DUP"]
            + float(w["UNIQUENESS"]) * parts["UNIQUENESS"]
        )
        repair_eligible = (
            (struct["missing_prior_count"] >= int(repair_cfg["MIN_MISSING_PRIORS"]))
            & (struct["same_match_pair_count"] == int(repair_cfg["SAME_MATCH_PAIR_COUNT"]))
            & (struct["dog_count"] == int(repair_cfg["DOG_COUNT"]))
            & (struct["low_salary_count"] == int(repair_cfg["LOW_SALARY_COUNT"]))
            & (struct["premium_count"] >= int(repair_cfg["MIN_PREMIUM_COUNT"]))
            & (salary_pct >= float(repair_cfg["MIN_SALARY_PERCENTILE"]))
        )
    out = {
        **parts,
        "objective": objective.astype(np.float32),
        "strict_eligible": strict.astype(np.int8),
        "repair_eligible": repair_eligible.astype(np.int8),
        "repair_score": repair_score.astype(np.float32),
        **calfeat,
    }
    return order.astype(np.int32), out, strict


def _max_overlap(row: np.ndarray, selected: list[np.ndarray]) -> int:
    s = set(map(int, row)); return max((len(s & set(map(int, x))) for x in selected), default=0)


def select_board(rows: np.ndarray, order: np.ndarray, selector: dict[str, np.ndarray], strict: np.ndarray, config: RuntimeConfig) -> tuple[np.ndarray, list[str]]:
    max_exp = int(CALIBRATION["SELECTOR"]["MAX_PLAYER_EXPOSURE"])
    max_overlap = int(CALIBRATION["SELECTOR"]["MAX_PAIRWISE_OVERLAP_SMALL"] if config.roster_size == 3 else CALIBRATION["SELECTOR"]["MAX_PAIRWISE_OVERLAP_STANDARD"])
    exposure = np.zeros(int(rows.max()) + 1, dtype=np.int16)
    selected: list[int] = []
    selected_set: set[int] = set()
    selected_rows: list[np.ndarray] = []
    reasons: list[str] = []

    def try_add(i: int, reason: str) -> bool:
        row = rows[i]
        if np.any(exposure[row] >= max_exp):
            return False
        if _max_overlap(row, selected_rows) > max_overlap:
            return False
        selected.append(i)
        selected_set.add(i)
        selected_rows.append(row.copy())
        exposure[row] += 1
        reasons.append(reason)
        return True

    repair_cfg = DOCTRINE["SELECTOR"]["MISSING_PRIOR_UPSET_SENTINEL"]
    if bool(repair_cfg.get("ENABLED", True)) and config.roster_size == int(repair_cfg["ROSTER_SIZE"]):
        repair_ids = np.flatnonzero(selector["repair_eligible"])
        repair_order = repair_ids[np.argsort(selector["repair_score"][repair_ids], kind="stable")[::-1]]
        repair_quota = min(int(repair_cfg["BOARD_QUOTA"]), config.board_size)
        repaired = 0
        for idx in repair_order:
            if try_add(int(idx), str(repair_cfg["REASON_CODE"])):
                repaired += 1
                if repaired >= repair_quota:
                    break

    for idx in order:
        if len(selected) >= config.board_size:
            break
        i = int(idx)
        if i in selected_set or not strict[i]:
            continue
        reason = "TOP01_SIGNAL" if selector["TOP_0_1_RATE"][i] >= 0.80 else "RIGHT_TAIL_WIN_PATH"
        try_add(i, reason)
    return np.asarray(selected, dtype=np.int32), reasons


def _lineup_player_ids(row: np.ndarray, slate: Slate) -> list[str]:
    return [slate.player_ids[int(p)] for p in row]


def _lineup_id(row: np.ndarray, slate: Slate) -> str:
    # Tennis Classic is a flat UTIL roster. Preserve order-insensitive lineup
    # identity while using the global player+role canonicalization contract.
    return pipeline_ledger.canonical_lineup_id(
        _lineup_player_ids(row, slate), ["UTIL"] * len(row), digest_chars=16
    )


def run_engine(*, pool_path: Path, field_size: int, execution_id: str, out_dir: Path,
               matchup_path: Path | None = None, availability_receipt: Path | None = None,
               roster_size: str | int = "auto", seed: int | None = None,
               phase1_trials: int | None = None, base_sim_trials: int | None = None,
               board_size: int | None = None) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    slate = load_slate(pool_path, matchup_path=matchup_path, availability_receipt=availability_receipt,
                       execution_id=execution_id, field_size=field_size)
    rsize = resolve_roster_size(len(slate.player_names), roster_size)
    cfg = RuntimeConfig(
        execution_id=str(execution_id), field_size=int(field_size), seed=resolve_seed(str(execution_id), seed), roster_size=rsize,
        phase1_trials=int(phase1_trials or CALIBRATION["PHASE1"]["DEFAULT_TRIALS"]),
        base_sim_trials=int(base_sim_trials or CALIBRATION["HANDOFF"]["BASE_SIM_TRIALS"]),
        board_size=int(board_size or CALIBRATION["SELECTOR"]["BOARD_SIZE"]),
    )
    if cfg.base_sim_trials < 10000 or cfg.base_sim_trials > cfg.phase1_trials:
        raise EngineError("RUN_INVALID:TENNIS_BASE_SIM_TRIALS_CONTRACT")
    phase1 = simulate_phase1(slate, trials=cfg.phase1_trials, seed=cfg.seed)
    legal, legal_salary, legal_count = enumerate_legal(slate, cfg, out_dir / "_tennis_work")
    phase2_rows, phase2_salary, struct, p2_receipt = phase2_birth(slate, phase1, legal, legal_salary, cfg)

    # STEP-2 PIPELINE FREEZE: seal the raw Phase-2 identity universe before any
    # handoff scoring, field simulation, selector ordering, or board assembly.
    phase2_identity_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_PHASE2_IDENTITY_LEDGER.csv"
    phase2_seal = pipeline_ledger.seal_stage_ledger(
        stage="PHASE2",
        path=phase2_identity_path,
        lineup_player_ids=[_lineup_player_ids(r, slate) for r in phase2_rows],
        slot_labels=["UTIL"] * cfg.roster_size,
        extra_columns={
            "SALARY": phase2_salary.tolist(),
            "SALARY_LEFT": struct["salary_left"].tolist(),
            "FAMILY_SIGNATURE": _family_codes(struct).tolist(),
        },
    )

    fake_idx, player_own, lineup_own, dup = build_fake_field(slate, phase1, phase2_rows, phase2_salary, field_size=cfg.field_size, seed=cfg.seed + 31)
    fake_rows = phase2_rows[fake_idx]
    base_scores = phase1.player_scores[:cfg.base_sim_trials]
    threshold, max_field = field_thresholds(base_scores, fake_rows, quantile=float(CALIBRATION["FAKE_FIELD"]["TOP_0_1_QUANTILE"]))
    metrics = score_lineups(base_scores, phase2_rows, threshold=threshold, max_field=max_field)
    metrics, bubble_extra, bubble_reviewed, bubble_unresolved, bubble_hash = adaptive_bubble(
        phase1, phase2_rows, fake_rows, metrics, base_trials=cfg.base_sim_trials, config=cfg
    )

    # Handoff snapshot is the exact Phase-3 input matrix. Tennis v2 currently
    # retains every frozen Phase-2 birth; adaptive bubble refines metrics only.
    handoff_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_HANDOFF_SNAPSHOT.csv"
    handoff_seal = pipeline_ledger.seal_stage_ledger(
        stage="HANDOFF",
        path=handoff_path,
        lineup_player_ids=[_lineup_player_ids(r, slate) for r in phase2_rows],
        slot_labels=["UTIL"] * cfg.roster_size,
        extra_columns={
            "SALARY": phase2_salary.tolist(),
            "TOP_0_1_RATE": metrics["top01_rate"].tolist(),
            "WIN_RATE": metrics["win_rate"].tolist(),
            "P95": metrics["p95"].tolist(),
            "P99": metrics["p99"].tolist(),
            "CVAR99": metrics["cvar99"].tolist(),
        },
    )

    final_availability_recheck = "TEST_MODE_BYPASS"
    if availability_receipt is not None:
        require_prebuild_roster_check(
            availability_receipt, sport=SPORT, mode=MODE, pool_path=pool_path,
            execution_id=execution_id, field_size=field_size, final_selector_recheck=True,
        )
        final_availability_recheck = "PASS"
    order, selector, strict = selector_full_order(slate, phase1, phase2_rows, phase2_salary, struct, metrics, lineup_own, dup)

    rank_pos = np.empty(len(order), dtype=np.int32)
    rank_pos[order] = np.arange(1, len(order) + 1)
    selector_review_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_SELECTOR_REVIEW_LEDGER.csv"
    selector_seal = pipeline_ledger.seal_stage_ledger(
        stage="SELECTOR_REVIEW",
        path=selector_review_path,
        lineup_player_ids=[_lineup_player_ids(r, slate) for r in phase2_rows],
        slot_labels=["UTIL"] * cfg.roster_size,
        extra_columns={
            "FULL_ORDER_RANK": rank_pos.tolist(),
            "STRICT_ELIGIBLE": strict.astype(np.int8).tolist(),
            "REPAIR_ELIGIBLE": selector["repair_eligible"].astype(np.int8).tolist(),
            "REPAIR_SCORE": selector["repair_score"].tolist(),
            "SELECTOR_SCORE": selector["objective"].tolist(),
        },
    )
    parity_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_PIPELINE_PARITY_RECEIPT.json"
    try:
        pipeline_parity = pipeline_ledger.verify_pipeline_parity(
            phase2=phase2_seal, handoff=handoff_seal, selector=selector_seal, receipt_path=parity_path
        )
    except pipeline_ledger.LedgerIntegrityError as exc:
        raise EngineError(str(exc)) from exc

    selected, reason_codes = select_board(phase2_rows, order, selector, strict, cfg)

    board_rows: list[dict[str, Any]] = []
    for rank, (idx, reason) in enumerate(zip(selected, reason_codes), start=1):
        i = int(idx); row = phase2_rows[i]
        rec: dict[str, Any] = {
            "BOARD_RANK": rank, "LINEUP_ID": _lineup_id(row, slate), "SELECTOR_REASON": reason,
            "SALARY": int(phase2_salary[i]), "SALARY_LEFT": int(SALARY_CAP - phase2_salary[i]),
            "MC_TOP_0_1_RATE": float(metrics["top01_rate"][i]), "MC_WIN_RATE": float(metrics["win_rate"][i]),
            "P95": float(metrics["p95"][i]), "P99": float(metrics["p99"][i]), "CVAR99": float(metrics["cvar99"][i]),
            "WIN_PATH": float(selector["win_path"][i]), "SWEEP_CEILING": float(selector["sweep_ceiling"][i]),
            "SERVE_CEILING": float(selector["serve_ceiling"][i]), "SELECTOR_SCORE": float(selector["objective"][i]),
            "REPAIR_ELIGIBLE": int(selector["repair_eligible"][i]), "REPAIR_SCORE": float(selector["repair_score"][i]),
            "MISSING_PRIOR_COUNT": int(struct["missing_prior_count"][i]),
            "DOG_COUNT": int(struct["dog_count"][i]), "PREMIUM_COUNT": int(struct["premium_count"][i]),
            "LOW_SALARY_COUNT": int(struct["low_salary_count"][i]), "SAME_MATCH_PAIR_COUNT": int(struct["same_match_pair_count"][i]),
        }
        for slot, p in enumerate(row, start=1):
            rec[f"P{slot}"] = slate.player_names[int(p)]; rec[f"P{slot}_ID"] = slate.player_ids[int(p)]
        board_rows.append(rec)
    board_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_FINAL_BOARD.csv"
    pd.DataFrame(board_rows).to_csv(board_path, index=False)

    phase2_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_PHASE2_MANIFEST.csv"
    family = _family_codes(struct)
    pd.DataFrame({
        "LINEUP_ID": [_lineup_id(r, slate) for r in phase2_rows],
        "SALARY": phase2_salary, "SALARY_LEFT": struct["salary_left"], "DOG_COUNT": struct["dog_count"],
        "PREMIUM_COUNT": struct["premium_count"], "LOW_SALARY_COUNT": struct["low_salary_count"],
        "ATP_COUNT": struct["atp_count"], "WTA_COUNT": struct["wta_count"], "SAME_MATCH_PAIR_COUNT": struct["same_match_pair_count"],
        "FAMILY_SIGNATURE": family, "HANDOFF_SURVIVOR": np.ones(len(phase2_rows), dtype=np.int8),
        "SELECTOR_REVIEWED": np.ones(len(phase2_rows), dtype=np.int8),
        "STRICT_ELIGIBLE": strict.astype(np.int8), "REPAIR_ELIGIBLE": selector["repair_eligible"].astype(np.int8),
        "REPAIR_SCORE": selector["repair_score"], "MISSING_PRIOR_COUNT": struct["missing_prior_count"],
        "TOP_0_1_RATE": metrics["top01_rate"], "WIN_RATE": metrics["win_rate"],
        "P95": metrics["p95"], "P99": metrics["p99"], "CVAR99": metrics["cvar99"],
        "SELECTOR_SCORE": selector["objective"], "PLAYER_IDS": ["|".join(slate.player_ids[int(p)] for p in r) for r in phase2_rows],
    }).to_csv(phase2_path, index=False)

    ledger_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_SELECTOR_LEDGER.csv"
    pd.DataFrame({
        "LINEUP_ID": [_lineup_id(r, slate) for r in phase2_rows], "FULL_ORDER_RANK": rank_pos,
        "STRICT_ELIGIBLE": strict.astype(np.int8), "REPAIR_ELIGIBLE": selector["repair_eligible"].astype(np.int8),
        "REPAIR_SCORE": selector["repair_score"], "TOP_0_1_PCTL": selector["TOP_0_1_RATE"], "WIN_PCTL": selector["WIN_RATE"],
        "P99_PCTL": selector["P99"], "CVAR99_PCTL": selector["CVAR99"], "P95_PCTL": selector["P95"],
        "WIN_PATH_PCTL": selector["WIN_PATH"], "SWEEP_PCTL": selector["SWEEP_CEILING"], "SERVE_PCTL": selector["SERVE_CEILING"],
        "UNIQUENESS_PCTL": selector["UNIQUENESS"], "LOW_DUP_PCTL": selector["LOW_DUP"], "SELECTOR_SCORE": selector["objective"],
        "MEAN_DIAGNOSTIC_ONLY": metrics["mean"],
    }).to_csv(ledger_path, index=False)

    receipt = {
        "GLOBAL_STATE_VERSION": ACTIVE_STATE_VERSION,
        "ENGINE_ID": ENGINE_ID, "ENGINE_VERSION": ENGINE_VERSION, "ENGINE_SOURCE_STATUS": "STANDALONE_FULL_REBUILD",
        "PLATFORM": PLATFORM, "SPORT": SPORT, "MODE": MODE, "EXECUTION_ID": str(execution_id),
        "CALIBRATION_SHA256": CALIBRATION_SHA256, "DOCTRINE_SHA256": DOCTRINE_SHA256,
        "GLOBAL_HANDOFF_PATCH": HANDOFF["PATCH_ID"], "GLOBAL_HANDOFF_PATCH_SHA256": HANDOFF_SHA256,
        "MANDATORY_PREBUILD_ROSTER_PATCH_ID": MANDATORY_PREBUILD_ROSTER_PATCH_ID,
        "PREDICTIVE_LAYER_PATCH_ID": slate.strategy.receipt.get("PREDICTIVE_LAYER_PATCH_ID"),
        "PREDICTION_HASH": slate.strategy.receipt.get("PREDICTION_HASH"),
        "STRATEGY_PATCH_ID": slate.strategy.receipt.get("PATCH_ID"), "STRATEGY_FEATURE_HASH": slate.strategy.receipt.get("FEATURE_HASH"),
        "POOL_SHA256": slate.pool_sha256, "MATCHUP_SOURCE": slate.matchup_source,
        "ROSTER_SIZE": cfg.roster_size, "ACTIVE_POOL": len(slate.player_names), "OUT_PURGE": slate.out_purge,
        "FINAL_SELECTOR_AVAILABILITY_RECHECK": final_availability_recheck,
        "MATCHES_RECONCILED": len(slate.pair_indices), "MISSING_WEAK_PRIORS_IMPUTED": int(slate.missing_weak_prior.sum()),
        "MISSING_PRIOR_IMPUTATION_PATCH_ID": ROTOWIRE_NEUTRAL_NOT_ZERO_PATCH_ID,
        "MISSING_PRIOR_IMPUTATION_DOCTRINE_SHA256": ROTOWIRE_DOCTRINE_SHA256,
        "MISSING_PRIOR_IMPUTATION_HOLDOUT_STATUS": ROTOWIRE_DOCTRINE["HOLDOUT_VALIDATION"]["PARSER_STATUS"],
        "MISSING_PRIOR_IMPUTATION_HOLDOUT_POOL_SHA256": ROTOWIRE_DOCTRINE["HOLDOUT_VALIDATION"].get("RAW_HOLDOUT_POOL_SHA256"),
        "MISSING_PRIOR_HISTORICAL_VALIDATION_ID": ROTOWIRE_DOCTRINE["HOLDOUT_VALIDATION"].get("VALIDATION_ID"),
        "MISSING_PRIOR_HISTORICAL_ZERO_MARKERS": ROTOWIRE_DOCTRINE["HOLDOUT_VALIDATION"].get("HISTORICAL_ZERO_MARKERS"),
        "MISSING_PRIOR_GLOBAL_PROMOTION_STATUS": ROTOWIRE_DOCTRINE["GLOBAL_PROMOTION_STATUS"],
        "MISSING_PRIOR_SIBLING_PATCH_ID": MISSING_PRIOR_SIBLING_PATCH_ID,
        "EVENT_NATIVE_PROBABILITY_PATCH_ID": EVENT_NATIVE_PROBABILITY_PATCH_ID,
        "EVENT_NATIVE_PROBABILITY_DOCTRINE_SHA256": EVENT_NATIVE_DOCTRINE_SHA256,
        "EVENT_NATIVE_PRIORS_RECOVERED": int(slate.event_recovered_prior.sum()),
        "SALARY_NEUTRAL_PRIOR_FALLBACKS": int(np.sum(slate.missing_weak_prior & ~slate.event_recovered_prior)),
        "PRIOR_SOURCE_COUNTS": {str(k): int(v) for k, v in zip(*np.unique(slate.prior_source, return_counts=True))},
        "MISSING_PRIOR_SELECTOR_PATCH_ID": MISSING_PRIOR_SELECTOR_PATCH_ID,
        "HARD_SALARY_FLOOR": None, "SAME_MATCH_COOCCURRENCE": "ALLOWED_ACTIVE_CONTRACT",
        "CAP_LEGAL_SCANNED": legal_count, "PHASE1_MC_TRIALS": cfg.phase1_trials, "PHASE1_CALIBRATION_HASH": phase1.metric_hash,
        **p2_receipt,
        "PHASE3_CANDIDATE_LINEUPS": len(phase2_rows), "POST_PHASE2_MUTATION_COUNT": 0,
        "PHASE2_PHASE3_PARITY": "PASS", "FAKE_FIELD_LINEUPS": len(fake_idx), "BASE_SIM_TRIALS": cfg.base_sim_trials,
        "BUBBLE_EXTRA_TRIALS_TOTAL": bubble_extra, "BUBBLE_LINEUPS_REVIEWED": bubble_reviewed,
        "BUBBLE_LINEUPS_UNRESOLVED": bubble_unresolved, "BUBBLE_HASH": bubble_hash,
        "HANDOFF_SURVIVORS": len(phase2_rows), "SELECTOR_REVIEWED_LINEUPS": len(phase2_rows), "HANDOFF_SELECTOR_PARITY": "PASS",
        "PIPELINE_LEDGER_CONTRACT_ID": pipeline_ledger.CONTRACT_ID,
        "PIPELINE_PARITY": pipeline_parity["PIPELINE_PARITY"],
        "PIPELINE_IDENTITY_PARITY": pipeline_parity["IDENTITY_PARITY"],
        "PHASE2_IDENTITY_LEDGER_SHA256": phase2_seal.file_sha256,
        "HANDOFF_SNAPSHOT_SHA256": handoff_seal.file_sha256,
        "SELECTOR_REVIEW_LEDGER_SHA256": selector_seal.file_sha256,
        "PIPELINE_IDENTITY_SHA256": phase2_seal.identity_sha256,
        "PIPELINE_PARITY_RECEIPT_SHA256": pipeline_parity["RECEIPT_SHA256"],
        "NO_POSTLOCK_LEDGER_RECONSTRUCTION": True,
        "SELECTOR_MEAN_WEIGHT": 0.0, "PLAYER_NAMES_USED_BY_SELECTOR": False, "POSTLOCK_RESULTS_USED_IN_FORWARD_ENGINE": False,
        "STRICT_ELIGIBLE_LINEUPS": int(strict.sum()),
        "MISSING_PRIOR_REPAIR_ELIGIBLE_LINEUPS": int(selector["repair_eligible"].sum()),
        "MISSING_PRIOR_REPAIR_SELECTED": int(sum(r == DOCTRINE["SELECTOR"]["MISSING_PRIOR_UPSET_SENTINEL"]["REASON_CODE"] for r in reason_codes)),
        "FINAL_BOARD_SIZE": len(board_rows), "FILLERS_USED": False, "RANK_ALL_USED": False,
        "BOARD_SHA256": sha256_file(board_path), "PHASE2_MANIFEST_SHA256": sha256_file(phase2_path), "SELECTOR_LEDGER_SHA256": sha256_file(ledger_path),
        "RUN_STATE": "BOARD_READY", "BOARD_IDENTITY_RECONCILIATION": BOARD_IDENTITY_RECONCILIATION,
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED" if len(board_rows) else "VALID_EMPTY_STRICT_BOARD",
    }
    receipt_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_FINAL_RECEIPT.json"
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    # Board-first production rendering.
    print(json.dumps({"RUN_STATE": "BOARD_READY", "BOARD_IDENTITY_RECONCILIATION": BOARD_IDENTITY_RECONCILIATION, "EXECUTION_STATE": receipt["EXECUTION_STATE"], "FINAL_BOARD_SIZE": len(board_rows), "FINAL_BOARD": board_rows}, indent=2), flush=True)
    return {
        "receipt": receipt,
        "board_path": str(board_path),
        "phase2_manifest_path": str(phase2_path),
        "phase2_identity_ledger_path": str(phase2_identity_path),
        "handoff_snapshot_path": str(handoff_path),
        "selector_ledger_path": str(ledger_path),
        "selector_review_ledger_path": str(selector_review_path),
        "pipeline_parity_receipt_path": str(parity_path),
        "receipt_path": str(receipt_path),
    }


def _args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--pool", required=True, type=Path)
    p.add_argument("--field-size", required=True, type=int)
    p.add_argument("--execution-id", required=True)
    p.add_argument("--out-dir", required=True, type=Path)
    p.add_argument("--matchups", type=Path)
    p.add_argument("--availability-receipt", type=Path)
    p.add_argument("--roster-size", default="auto")
    p.add_argument("--seed", type=int)
    p.add_argument("--phase1-trials", type=int)
    p.add_argument("--base-sim-trials", type=int)
    p.add_argument("--board-size", type=int)
    return p.parse_args()


def main() -> int:
    a = _args()
    result = run_engine(pool_path=a.pool, field_size=a.field_size, execution_id=a.execution_id, out_dir=a.out_dir,
                        matchup_path=a.matchups, availability_receipt=a.availability_receipt, roster_size=a.roster_size,
                        seed=a.seed, phase1_trials=a.phase1_trials, base_sim_trials=a.base_sim_trials, board_size=a.board_size)
    print(json.dumps(result["receipt"], indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
