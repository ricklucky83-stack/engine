from __future__ import annotations
import argparse, csv, itertools, json, math, hashlib
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix

ENGINE_ID="APEX_TENNIS_CLASSIC_BARE_MIN_RUNTIME_v1"
PROFILE="BARE_MIN_SIMPLE"
SALARY_CAP=50000
SALARY_MIN=0  # compatibility sentinel; Tennis Classic has no fixed minimum-spend legality gate
ROSTER_SIZE=6
FIXED_SALARY_FLOOR=False

def num(v:Any,d:float=0.0)->float:
    try:
        if v is None:return d
        x=str(v).replace(",","").replace("%","").strip()
        if not x or x.lower() in {"nan","none","-"}:return d
        return float(x)
    except:return d

def z(a):
    a=np.asarray(a,dtype=np.float64); sd=float(a.std())
    return np.zeros_like(a) if sd<1e-9 else (a-float(a.mean()))/sd

def canon(x:str)->str:
    return " ".join(str(x).strip().lower().replace(".","").split())

def salary_legal(total:int|float)->bool:
    """DraftKings Tennis Classic legality: positive spend at or below the $50k cap; no fixed minimum."""
    return 0 < float(total) <= SALARY_CAP

def load_pool(path:Path):
    with path.open("r",encoding="utf-8-sig",newline="") as f:
        r=csv.DictReader(f); rows=[dict(x) for x in r]; hdr=set(r.fieldnames or [])
    need={"PLAYER","SAL","FPTS"}
    miss=sorted(need-hdr)
    if miss: raise RuntimeError("RUN_INVALID:MISSING_REQUIRED_COLUMNS:"+",".join(miss))
    out=[]; seen=set()
    for raw in rows:
        name=str(raw.get("PLAYER","")).strip()
        if not name or name in seen: continue
        sal=int(round(num(raw.get("SAL"),0)))
        if sal<=0: continue
        seen.add(name)
        w=num(raw.get("W"),0); l=num(raw.get("L"),0)
        h2w=num(raw.get("H2H W"),0); h2l=num(raw.get("H2H L"),0)
        wp=(w+h2w+1.0)/(w+l+h2w+h2l+2.0)
        out.append({
            "idx":len(out),"name":name,"salary":sal,"fpts":num(raw.get("FPTS"),0),
            "value":num(raw.get("VAL"),0),"ace":num(raw.get("ACE"),0),
            "dblf":num(raw.get("DBLF"),0),"win_prob":float(np.clip(wp,.08,.92)),
            "opp":str(raw.get("Opponent","")).strip()
        })
    if len(out)<ROSTER_SIZE: raise RuntimeError("RUN_INVALID:NO_LEGAL_ROSTER_POOL")
    return out

def build_candidates(players,target:int):
    n=len(players)
    sal=np.array([p["salary"] for p in players],dtype=np.float64)
    fpts=np.array([p["fpts"] for p in players],dtype=np.float64)
    win=np.array([p["win_prob"] for p in players],dtype=np.float64)
    ace=np.array([p["ace"] for p in players],dtype=np.float64)
    dblf=np.array([p["dblf"] for p in players],dtype=np.float64)
    val=np.array([p["value"] for p in players],dtype=np.float64)
    ceiling=fpts+5.0*z(ace)-2.0*z(dblf)+8.0*z(win)
    scenarios=[
        z(fpts)+.25*z(win),
        z(ceiling)+.20*z(win),
        .60*z(fpts)+.75*z(win),
        .75*z(fpts)+.55*z(ace)-.20*z(dblf),
        .65*z(fpts)+.45*z(val)+.20*z(win),
    ]
    base_rows=[
        (list(range(n)),[1.0]*n,ROSTER_SIZE,ROSTER_SIZE),
        (list(range(n)),sal.tolist(),SALARY_MIN,SALARY_CAP),
    ]
    no_goods=[]; cands=[]
    for k in range(target):
        rows=list(base_rows)
        for prev in no_goods:
            ids=sorted(prev); rows.append((ids,[1.0]*len(ids),-np.inf,ROSTER_SIZE-1))
        data=[]; indices=[]; indptr=[0]; lb=[]; ub=[]
        for ids,vals,lo,hi in rows:
            indices.extend(ids); data.extend(vals); indptr.append(len(indices)); lb.append(lo); ub.append(hi)
        A=csr_matrix((np.asarray(data),np.asarray(indices),np.asarray(indptr)),shape=(len(rows),n))
        w=scenarios[k%len(scenarios)].copy()
        w += np.array([((i*131+k*17)%997)*1e-7 for i in range(n)])
        res=milp(c=-w,integrality=np.ones(n,dtype=np.int8),bounds=Bounds(np.zeros(n),np.ones(n)),
                 constraints=LinearConstraint(A,np.asarray(lb),np.asarray(ub)),
                 options={"presolve":True,"mip_rel_gap":0.0,"time_limit":1.0})
        if not res.success or res.x is None: break
        ids=tuple(sorted(map(int,np.flatnonzero(res.x>.5))))
        if len(ids)!=ROSTER_SIZE: break
        no_goods.append(set(ids))
        cands.append(ids)
    if len(cands)<5: raise RuntimeError("RUN_FAIL:BARE_MIN_CANDIDATE_SHORT")
    return list(dict.fromkeys(cands))

def simulate(players,trials:int,seed:int):
    n=len(players); rng=np.random.default_rng(seed)
    mean=np.array([p["fpts"] for p in players],dtype=np.float32)
    wp=np.array([p["win_prob"] for p in players],dtype=np.float32)
    ace=np.array([p["ace"] for p in players],dtype=np.float32)
    sigma=np.maximum(7.0, .38*np.abs(mean)+2.5+2.0*np.maximum(ace,0)).astype(np.float32)
    normal=rng.standard_normal((n,trials),dtype=np.float32)
    heavy=(rng.chisquare(4.0,(n,trials)).astype(np.float32)-4.0)/np.float32(math.sqrt(8.0))
    outcomes=mean[:,None]+sigma[:,None]*(np.float32(.84)*normal+np.float32(.16)*heavy)
    # Simple match physics: reciprocal opponent pairs receive an anti-correlated shared shock.
    names={canon(p["name"]):i for i,p in enumerate(players)}
    used=set()
    for i,p in enumerate(players):
        j=names.get(canon(p["opp"]))
        if j is None or j==i or (j,i) in used: continue
        used.add((i,j))
        shock=rng.standard_normal(trials).astype(np.float32)
        amp=np.float32(4.0+2.0*abs(float(wp[i]-wp[j])))
        outcomes[i]+=amp*shock
        outcomes[j]-=amp*shock
    outcomes=np.maximum(outcomes,0.0)
    return outcomes

def score_rows(rows,outcomes):
    arr=np.asarray(rows,dtype=np.int16)
    scores=outcomes[arr].sum(axis=1)
    p95=np.quantile(scores,.95,axis=1); p99=np.quantile(scores,.99,axis=1)
    q=p99[:,None]
    cvar=np.array([float(scores[i][scores[i]>=q[i,0]].mean()) for i in range(len(arr))])
    winners=np.argmax(scores,axis=0)
    win=np.bincount(winners,minlength=len(arr)).astype(np.float64)/scores.shape[1]
    metric=.48*z(p99)+.30*z(cvar)+.62*z(win)
    return scores,p95,p99,cvar,win,metric

def clusters(rows,win,metric,top_k=5):
    order=np.argsort(-metric,kind="stable")[:min(40,len(rows))]
    agg={}
    for ridx in order:
        r=tuple(rows[int(ridx)])
        for core in itertools.combinations(r,4):
            a=agg.setdefault(core,{"members":set(),"mass":0.0,"best":-1e99})
            a["members"].add(int(ridx)); a["mass"]+=float(win[int(ridx)]); a["best"]=max(a["best"],float(metric[int(ridx)]))
    ranked=sorted(agg.items(),key=lambda kv:(kv[1]["mass"],len(kv[1]["members"]),kv[1]["best"]),reverse=True)
    chosen=[]
    for core,a in ranked:
        if any(len(set(core)&set(c))>=3 for c,_ in chosen): continue
        chosen.append((core,a))
        if len(chosen)>=top_k: break
    return chosen

def closure_for_clusters(players,base_rows,cluster_defs,max_each=192):
    out=set()
    n=len(players)
    for core,a in cluster_defs:
        core=set(core)
        seeds=[base_rows[i] for i in sorted(a["members"])]
        local=0
        for seed in seeds:
            seed=set(seed)
            for rem in list(seed):
                for add in range(n):
                    if add in seed: continue
                    nr=tuple(sorted((seed-{rem})|{add}))
                    sal=sum(players[i]["salary"] for i in nr)
                    if salary_legal(sal):
                        out.add(nr); local+=1
                        if local>=max_each: break
                if local>=max_each: break
            if local>=max_each: break
    return list(out)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--pool",required=True); ap.add_argument("--field-size",required=True,type=int)
    ap.add_argument("--execution-id",required=True); ap.add_argument("--out-dir",required=True)
    ap.add_argument("--sim-trials",type=int,default=8192); ap.add_argument("--candidate-target",type=int,default=96)
    ap.add_argument("--board-size",type=int,default=5)
    a=ap.parse_args()
    if a.sim_trials<=0: raise RuntimeError("ENGINE_INTEGRITY_HALT:MC_ITERATIONS_ZERO")
    out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
    players=load_pool(Path(a.pool))
    candidates=build_candidates(players,a.candidate_target)
    outcomes=simulate(players,a.sim_trials,seed=max(1,a.field_size)*1000003+260901)
    _,p95,p99,cvar,win,metric=score_rows(candidates,outcomes)
    cls=clusters(candidates,win,metric,5)
    closure=closure_for_clusters(players,candidates,cls)
    all_rows=list(dict.fromkeys(candidates+closure))
    _,ap95,ap99,acvar,awin,ametric=score_rows(all_rows,outcomes)
    order=np.argsort(-ametric,kind="stable")
    board=[]; exposure=Counter()
    for idx in order:
        row=all_rows[int(idx)]
        if any(exposure[p]>=max(1,a.board_size-1) for p in row): continue
        rec={"BOARD_RANK":len(board)+1,"SALARY":sum(players[p]["salary"] for p in row),
             "MC_WIN_RATE":round(float(awin[idx]),8),"P95":round(float(ap95[idx]),4),
             "P99":round(float(ap99[idx]),4),"CVAR99":round(float(acvar[idx]),4)}
        for j,p in enumerate(row,1): rec[f"P{j}"]=players[p]["name"]
        board.append(rec); exposure.update(row)
        if len(board)>=a.board_size: break
    if len(board)<a.board_size:
        for idx in order:
            row=all_rows[int(idx)]
            if any(set(row)==set(b.get("_ids",())) for b in board): continue
            rec={"BOARD_RANK":len(board)+1,"SALARY":sum(players[p]["salary"] for p in row),
                 "MC_WIN_RATE":round(float(awin[idx]),8),"P95":round(float(ap95[idx]),4),
                 "P99":round(float(ap99[idx]),4),"CVAR99":round(float(acvar[idx]),4)}
            for j,p in enumerate(row,1): rec[f"P{j}"]=players[p]["name"]
            board.append(rec)
            if len(board)>=a.board_size: break

    cluster_rows=[]
    for rank,(core,meta) in enumerate(cls,1):
        cluster_rows.append({
            "CLUSTER_RANK":rank,
            "CORE":" | ".join(players[p]["name"] for p in core),
            "CHAMPIONSHIP_MASS":round(float(meta["mass"]),8),
            "LOCAL_DENSITY":len(meta["members"]),
            "BEST_CLUSTER_SCORE":round(float(meta["best"]),6),
        })
    with (out/f"execution_{a.execution_id}_bare_min_board.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(board[0].keys())); w.writeheader(); w.writerows(board)
    with (out/f"execution_{a.execution_id}_bare_min_clusters.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(cluster_rows[0].keys())); w.writeheader(); w.writerows(cluster_rows)
    closure_path=out/f"execution_{a.execution_id}_bare_min_closure.csv"
    with closure_path.open("w",newline="",encoding="utf-8") as f:
        fields=["SALARY"]+[f"P{i}" for i in range(1,7)]
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for r in closure:
            zrow={"SALARY":sum(players[p]["salary"] for p in r)}
            for j,p in enumerate(r,1): zrow[f"P{j}"]=players[p]["name"]
            w.writerow(zrow)
    receipt={
        "EXECUTION_STATE":"TOOL_PROVEN_EXECUTED","ENGINE_ID":ENGINE_ID,"ENGINE_PROFILE":PROFILE,
        "FIELD_SIZE":a.field_size,"ACTIVE_POOL":len(players),"MC_TRIALS":a.sim_trials,
        "BASE_CANDIDATES":len(candidates),"TOP_CLUSTERS":len(cluster_rows),"LOCAL_CLOSURE":len(closure),
        "SELECTOR_REVIEWED_LINEUPS":len(all_rows),"FINAL_BOARD_SIZE":len(board),
        "TOP_CLUSTER_SURFACE":cluster_rows,"FINAL_BOARD":board,
        "REGULAR_ENGINE_MUTATED":False,
        "SALARY_LEGALITY":"CAP_ONLY_LE_50000",
        "FIXED_SALARY_FLOOR":None,
        "SALARY_MIN_HARD_GATE":False
    }
    print(json.dumps(receipt,separators=(",",":")))
if __name__=="__main__": main()
