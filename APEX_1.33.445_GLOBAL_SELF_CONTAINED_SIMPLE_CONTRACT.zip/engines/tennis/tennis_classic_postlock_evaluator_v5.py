from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import pandas as pd

EVALUATOR_ID = "TENNIS_CLASSIC_POSTLOCK_EVALUATOR_v5"
VERSION = "5.0.0"


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def classify_lineage(*, born: bool, handoff: bool, reviewed: bool, on_board: bool) -> str:
    if not born:
        return "GENERATOR_CALIBRATION_FAILURE"
    if not handoff:
        return "HANDOFF_RECALL_FAILURE"
    if not reviewed:
        return "SELECTOR_REVIEW_COVERAGE_FAILURE"
    if not on_board:
        return "SELECTOR_FAILURE"
    return "MODEL_OR_VARIANCE_FAILURE"


def _id_set(path: Path, col: str = "LINEUP_ID") -> set[str]:
    if not path.exists():
        raise FileNotFoundError(path)
    df = pd.read_csv(path, usecols=[col])
    return set(df[col].astype(str))


def evaluate(*, winner_lineup_id: str, phase2_manifest: Path, selector_ledger: Path,
             final_board: Path, contest_rank: int | None = None, output: Path | None = None) -> dict[str, Any]:
    p2 = pd.read_csv(phase2_manifest)
    ledger = pd.read_csv(selector_ledger)
    board = pd.read_csv(final_board)
    lineup_id = str(winner_lineup_id)

    born = lineup_id in set(p2["LINEUP_ID"].astype(str))
    if born:
        p2row = p2.loc[p2["LINEUP_ID"].astype(str).eq(lineup_id)].iloc[0]
        handoff = bool(int(p2row.get("HANDOFF_SURVIVOR", 0)))
        reviewed_flag = bool(int(p2row.get("SELECTOR_REVIEWED", 0)))
    else:
        handoff = False
        reviewed_flag = False
    ledger_ids = set(ledger["LINEUP_ID"].astype(str))
    reviewed = reviewed_flag and lineup_id in ledger_ids
    on_board = lineup_id in set(board.get("LINEUP_ID", pd.Series(dtype=str)).astype(str))
    failure_class = classify_lineage(born=born, handoff=handoff, reviewed=reviewed, on_board=on_board)

    receipt = {
        "EVALUATOR_ID": EVALUATOR_ID,
        "VERSION": VERSION,
        "WINNER_LINEUP_ID": lineup_id,
        "CONTEST_RANK": int(contest_rank) if contest_rank is not None else None,
        "WINNER_BORN_PHASE2": born,
        "WINNER_HANDOFF_SURVIVOR": handoff,
        "WINNER_SELECTOR_REVIEWED": reviewed,
        "WINNER_ON_FINAL_BOARD": on_board,
        "FAILURE_CLASS": failure_class,
        "FORWARD_ENGINE_MUTATED": False,
        "PHASE2_MANIFEST_SHA256": sha256_file(phase2_manifest),
        "SELECTOR_LEDGER_SHA256": sha256_file(selector_ledger),
        "FINAL_BOARD_SHA256": sha256_file(final_board),
        "EXECUTION_STATE": "POSTLOCK_LINEAGE_CLASSIFIED",
    }
    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return receipt


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--winner-lineup-id", required=True)
    ap.add_argument("--phase2-manifest", type=Path, required=True)
    ap.add_argument("--selector-ledger", type=Path, required=True)
    ap.add_argument("--final-board", type=Path, required=True)
    ap.add_argument("--contest-rank", type=int)
    ap.add_argument("--output", type=Path)
    a = ap.parse_args()
    print(json.dumps(evaluate(winner_lineup_id=a.winner_lineup_id, phase2_manifest=a.phase2_manifest,
                              selector_ledger=a.selector_ledger, final_board=a.final_board,
                              contest_rank=a.contest_rank, output=a.output), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
