from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

EVALUATOR_ID = "TENNIS_CLASSIC_POSTLOCK_EVALUATOR_v2"
FORENSIC_MODULE_PATH = Path(__file__).with_name("tennis_classic_forensic_reconstruction_v1.py")
_spec = importlib.util.spec_from_file_location("tennis_forensic_v1", FORENSIC_MODULE_PATH)
if _spec is None or _spec.loader is None:
    raise RuntimeError("FORENSIC_MODULE_IMPORT_SPEC_FAIL")
_forensic = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = _forensic
_spec.loader.exec_module(_forensic)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def player_id(name: str, salary: int) -> str:
    return hashlib.sha256(f"{name}|{int(salary)}".encode()).hexdigest()[:16]


def _exact_perfect_from_sources(
    *,
    pool: pd.DataFrame,
    actual_top_path: Path | None,
    player_truth_path: Path | None,
    forensic_out_dir: Path,
    expected_legal_count: int | None,
    audit_path: Path | None,
) -> tuple[pd.DataFrame, dict[str, object]]:
    if (actual_top_path is None) == (player_truth_path is None):
        raise RuntimeError("EXACTLY_ONE_OF_ACTUAL_TOP_OR_PLAYER_TRUTH_REQUIRED")
    if player_truth_path is not None:
        forensic_receipt = _forensic.reconstruct_exact_perfect(
            player_truth_path=player_truth_path,
            out_dir=forensic_out_dir,
            expected_legal_count=expected_legal_count,
            audit_path=audit_path,
        )
        perfect = pd.DataFrame(forensic_receipt["PERFECT_LINEUPS"])
        player_columns = [f"player_{i}" for i in range(1, 7)]
        rows = []
        pool_salary = dict(zip(pool["PLAYER"].astype(str), pool["SAL"].astype(int)))
        for _, lineup in perfect.iterrows():
            for name in [str(lineup[c]) for c in player_columns]:
                if name not in pool_salary:
                    raise RuntimeError(f"FORENSIC_PLAYER_NOT_IN_POOL={name}")
                rows.append({"PLAYER": name, "SAL": pool_salary[name]})
            break
        exact = pd.DataFrame(rows).merge(
            pd.read_csv(player_truth_path).rename(columns={"player": "PLAYER", "actual_fpts": "ACTUAL_FPTS"})[["PLAYER", "ACTUAL_FPTS"]],
            on="PLAYER",
            how="left",
            validate="one_to_one",
        )
        return exact, forensic_receipt

    actual = pd.read_csv(actual_top_path)
    merged = actual.merge(pool[["PLAYER", "SAL"]], on="PLAYER", how="left", validate="one_to_one")
    if merged["SAL"].isna().any():
        raise RuntimeError("POSTLOCK_PLAYER_NOT_IN_POOL")
    return merged[["PLAYER", "SAL", "ACTUAL_FPTS"]], {
        "MODULE_ID": "DIRECT_PLAYER_LEVEL_CONTEST_SIDE_TABLE",
        "PLAYER_TRUTH_SHA256": sha256_file(actual_top_path),
        "FULLY_LEGAL_LINEUPS": None,
        "AUDIT_CROSSCHECK_COUNT": 0,
    }


def evaluate(
    *,
    pool_path: Path,
    phase2_manifest_path: Path,
    board_path: Path,
    out_path: Path,
    actual_top_path: Path | None = None,
    player_truth_path: Path | None = None,
    expected_legal_count: int | None = None,
    audit_path: Path | None = None,
) -> dict[str, object]:
    pool = pd.read_csv(pool_path)
    forensic_out = out_path.parent / f"{out_path.stem}_forensic"
    exact, forensic_receipt = _exact_perfect_from_sources(
        pool=pool,
        actual_top_path=actual_top_path,
        player_truth_path=player_truth_path,
        forensic_out_dir=forensic_out,
        expected_legal_count=expected_legal_count,
        audit_path=audit_path,
    )
    perfect_names = tuple(exact.sort_values("ACTUAL_FPTS", ascending=False)["PLAYER"].astype(str))
    perfect_ids = frozenset(player_id(r.PLAYER, int(r.SAL)) for _, r in exact.iterrows())
    salary = int(exact["SAL"].sum())
    actual_score = float(exact["ACTUAL_FPTS"].sum())

    manifest = pd.read_csv(phase2_manifest_path)
    sets = manifest["PLAYER_IDS"].astype(str).map(lambda s: frozenset(s.split("|")))
    matches = manifest[sets == perfect_ids]
    born = len(matches) == 1
    if len(matches) > 1:
        raise RuntimeError(f"PERFECT_LINEUP_MANIFEST_CARDINALITY={len(matches)}")
    row = matches.iloc[0] if born else None

    board = pd.read_csv(board_path)
    board_sets = [frozenset(str(b[f"P{i}_ID"]) for i in range(1, 7)) for _, b in board.iterrows()]
    on_board = perfect_ids in board_sets
    handoff = bool(int(row["HANDOFF_SURVIVOR"])) if born else False
    selector_reviewed = bool(handoff and pd.notna(row["SELECTOR_SCORE"])) if born else False
    if not born:
        failure = "GENERATOR_CALIBRATION_FAILURE"
    elif not handoff:
        failure = "HANDOFF_RECALL_FAILURE"
    elif not selector_reviewed:
        failure = "HANDOFF_SELECTOR_PARITY_FAILURE"
    elif not on_board:
        failure = "SELECTOR_FAMILY_CLOSURE_FAILURE"
    else:
        failure = "MODEL_OR_VARIANCE_FAILURE"

    result = {
        "EVALUATOR": EVALUATOR_ID,
        "ACTUAL_RESULTS_USED_BY_FORWARD_ENGINE": False,
        "POSTLOCK_ONLY": True,
        "AUTONOMOUS_SELF_HEAL_REQUIRED": failure != "MODEL_OR_VARIANCE_FAILURE",
        "SELF_HEAL_TERMINAL_SUCCESS_ALLOWED": failure == "MODEL_OR_VARIANCE_FAILURE",
        "POOL_SHA256": sha256_file(pool_path),
        "PHASE2_MANIFEST_SHA256": sha256_file(phase2_manifest_path),
        "BOARD_SHA256": sha256_file(board_path),
        "FORENSIC_SOURCE": forensic_receipt,
        "PERFECT_LINEUP_PLAYERS": perfect_names,
        "PERFECT_LINEUP_SALARY": salary,
        "PERFECT_LINEUP_SALARY_LEFT": 50000 - salary,
        "PERFECT_LINEUP_ACTUAL_FPTS": actual_score,
        "PERFECT_LINEUP_PHASE2_BORN": born,
        "PERFECT_LINEUP_HANDOFF_SURVIVOR": handoff,
        "PERFECT_LINEUP_SELECTOR_REVIEWED": selector_reviewed,
        "PERFECT_LINEUP_FINAL_BOARD": on_board,
        "PERFECT_LINEUP_PHASE2_INDEX": int(row["LINEUP_INDEX"]) if born else None,
        "PERFECT_LINEUP_FAMILY_SIGNATURE": str(row["FAMILY_SIGNATURE"]) if born and "FAMILY_SIGNATURE" in row.index else None,
        "PERFECT_LINEUP_TOP_0_1_RATE": None if not born or pd.isna(row["TOP_0_1_RATE"]) else float(row["TOP_0_1_RATE"]),
        "PERFECT_LINEUP_WIN_RATE": None if not born or pd.isna(row["WIN_RATE"]) else float(row["WIN_RATE"]),
        "PERFECT_LINEUP_SELECTOR_SCORE": None if not born or pd.isna(row["SELECTOR_SCORE"]) else float(row["SELECTOR_SCORE"]),
        "FAILURE_CLASS": failure,
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pool", required=True)
    parser.add_argument("--phase2-manifest", required=True)
    parser.add_argument("--board", required=True)
    parser.add_argument("--out", required=True)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--actual-top")
    source.add_argument("--player-truth")
    parser.add_argument("--expected-legal-count", type=int)
    parser.add_argument("--audit")
    args = parser.parse_args()
    result = evaluate(
        pool_path=Path(args.pool),
        phase2_manifest_path=Path(args.phase2_manifest),
        board_path=Path(args.board),
        out_path=Path(args.out),
        actual_top_path=Path(args.actual_top) if args.actual_top else None,
        player_truth_path=Path(args.player_truth) if args.player_truth else None,
        expected_legal_count=args.expected_legal_count,
        audit_path=Path(args.audit) if args.audit else None,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
