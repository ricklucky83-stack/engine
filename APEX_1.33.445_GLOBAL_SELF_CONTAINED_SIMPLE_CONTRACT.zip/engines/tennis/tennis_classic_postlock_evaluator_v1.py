from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Sequence

import pandas as pd


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def player_id(name: str, salary: int) -> str:
    return hashlib.sha256(f"{name}|{int(salary)}".encode()).hexdigest()[:16]


def evaluate(
    *,
    pool_path: Path,
    phase2_manifest_path: Path,
    board_path: Path,
    actual_top_path: Path,
    out_path: Path,
) -> dict[str, object]:
    pool = pd.read_csv(pool_path)
    actual = pd.read_csv(actual_top_path)
    merged = actual.merge(pool[['PLAYER', 'SAL']], on='PLAYER', how='left', validate='one_to_one')
    if merged['SAL'].isna().any():
        raise RuntimeError('POSTLOCK_PLAYER_NOT_IN_POOL')
    perfect_names = tuple(merged.sort_values('ACTUAL_FPTS', ascending=False)['PLAYER'].astype(str))
    perfect_ids = frozenset(player_id(r.PLAYER, int(r.SAL)) for _, r in merged.iterrows())
    salary = int(merged['SAL'].sum())
    actual_score = float(merged['ACTUAL_FPTS'].sum())

    manifest = pd.read_csv(phase2_manifest_path)
    sets = manifest['PLAYER_IDS'].astype(str).map(lambda s: frozenset(s.split('|')))
    matches = manifest[sets == perfect_ids]
    if len(matches) != 1:
        raise RuntimeError(f'PERFECT_LINEUP_MANIFEST_CARDINALITY={len(matches)}')
    row = matches.iloc[0]

    board = pd.read_csv(board_path)
    board_sets = []
    for _, b in board.iterrows():
        ids = [str(b[f'P{i}_ID']) for i in range(1, 7)]
        board_sets.append(frozenset(ids))
    on_board = perfect_ids in board_sets

    born = True
    handoff = bool(int(row['HANDOFF_SURVIVOR']))
    selector_reviewed = handoff and pd.notna(row['SELECTOR_SCORE'])
    if not born:
        failure = 'GENERATOR_CALIBRATION_FAILURE'
    elif not handoff:
        failure = 'HANDOFF_RECALL_FAILURE'
    elif not on_board:
        failure = 'SELECTOR_FAILURE'
    else:
        failure = 'MODEL_OR_VARIANCE_FAILURE'

    result = {
        'EVALUATOR': 'TENNIS_CLASSIC_POSTLOCK_EVALUATOR_v1',
        'ACTUAL_RESULTS_USED_BY_FORWARD_ENGINE': False,
        'POSTLOCK_ONLY': True,
        'POOL_SHA256': sha256_file(pool_path),
        'PHASE2_MANIFEST_SHA256': sha256_file(phase2_manifest_path),
        'BOARD_SHA256': sha256_file(board_path),
        'ACTUAL_TOP_SOURCE_SHA256': sha256_file(actual_top_path),
        'PERFECT_LINEUP_PLAYERS': perfect_names,
        'PERFECT_LINEUP_SALARY': salary,
        'PERFECT_LINEUP_SALARY_LEFT': 50000 - salary,
        'PERFECT_LINEUP_ACTUAL_FPTS': actual_score,
        'PERFECT_LINEUP_PHASE2_BORN': born,
        'PERFECT_LINEUP_HANDOFF_SURVIVOR': handoff,
        'PERFECT_LINEUP_SELECTOR_REVIEWED': selector_reviewed,
        'PERFECT_LINEUP_FINAL_BOARD': on_board,
        'PERFECT_LINEUP_PHASE2_INDEX': int(row['LINEUP_INDEX']),
        'PERFECT_LINEUP_TOP_0_1_RATE': None if pd.isna(row['TOP_0_1_RATE']) else float(row['TOP_0_1_RATE']),
        'PERFECT_LINEUP_WIN_RATE': None if pd.isna(row['WIN_RATE']) else float(row['WIN_RATE']),
        'PERFECT_LINEUP_SELECTOR_SCORE': None if pd.isna(row['SELECTOR_SCORE']) else float(row['SELECTOR_SCORE']),
        'FAILURE_CLASS': failure,
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    return result


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument('--pool', required=True)
    p.add_argument('--phase2-manifest', required=True)
    p.add_argument('--board', required=True)
    p.add_argument('--actual-top', required=True)
    p.add_argument('--out', required=True)
    a = p.parse_args()
    result = evaluate(
        pool_path=Path(a.pool),
        phase2_manifest_path=Path(a.phase2_manifest),
        board_path=Path(a.board),
        actual_top_path=Path(a.actual_top),
        out_path=Path(a.out),
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
