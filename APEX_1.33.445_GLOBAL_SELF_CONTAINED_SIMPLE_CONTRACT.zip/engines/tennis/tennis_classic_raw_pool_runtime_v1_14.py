from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
from numba import njit, prange
from scipy.stats import rankdata

ENGINE_ID = "TENNIS_CLASSIC_ENGINE_v1_14"
ENGINE_VERSION = "1.14.0"
ROSTER_SIZE = 6
SALARY_CAP = 50_000
HARD_SALARY_FLOOR = None
MIN_PHASE1_TRIALS = 10_000
MIN_BASE_SIM_TRIALS = 10_000
BUBBLE_BATCH_TRIALS = 10_000
MAX_PHYSICAL_SIM_TRIALS = 50_000
CALIBRATION_FILE = Path(__file__).with_name("tennis_classic_calibration_v1_14.json")
STATE_ROOT = Path(__file__).resolve().parents[2]
if str(STATE_ROOT) not in sys.path:
    sys.path.insert(0, str(STATE_ROOT))
from engines.common.universal_prebuild_availability_gate_v1 import (
    player_is_available, validate_prebuild_availability_receipt,
)
HANDOFF_OVERLAY_FILE = STATE_ROOT / "current_handoff" / "APEX_GLOBAL_ENGINE_REGISTRY_HANDOFF_OVERLAY_v1.json"
DOCTRINE_FILE = STATE_ROOT / "doctrine" / "TENNIS_CLASSIC_UNDERSPEND_PERFECT_FAMILY_CLOSURE_v5.json"
GLOBAL_PHASE2_DOCTRINE_FILE = STATE_ROOT / "doctrine" / "APEX_CALIBRATION_FIRST_PHASE2_CONSTRUCTION_v1.json"
FORENSIC_MODULE_FILE = Path(__file__).with_name("tennis_classic_forensic_reconstruction_v1.py")

REQUIRED_POOL_COLUMNS = ("PLAYER", "SAL", "FPTS", "VAL", "MIN EXP", "MAX EXP")
REQUIRED_MATCHUP_COLUMNS = ("PLAYER", "OPPONENT", "MATCH_ID", "TOUR", "SOURCE")
ALLOWED_MATCHUP_SOURCES = {"INPUT_FILE", "VERIFIED_PRELOCK_PROVIDER"}


class EngineError(RuntimeError):
    pass


def load_json_contract(path: Path, *, required: bool = True) -> dict[str, object]:
    if not path.is_file():
        if required:
            raise EngineError(f"CONTRACT_FILE_MISSING={path}")
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise EngineError(f"CONTRACT_JSON_INVALID={path}")
    return payload


def load_calibration_contract() -> tuple[dict[str, object], str]:
    payload = load_json_contract(CALIBRATION_FILE)
    if payload.get("CALIBRATION_ID") != "TENNIS_CLASSIC_PRELOCK_CALIBRATION_v1_14":
        raise EngineError("CALIBRATION_ID_MISMATCH")
    if payload.get("ENGINE_ID") != ENGINE_ID or payload.get("VERSION") != ENGINE_VERSION:
        raise EngineError("CALIBRATION_ENGINE_VERSION_MISMATCH")
    roster = payload.get("ROSTER", {})
    if roster.get("HARD_SALARY_FLOOR") is not None or int(roster.get("SALARY_CAP", 0)) != SALARY_CAP:
        raise EngineError("CALIBRATION_SALARY_CONTRACT_INVALID")
    roles = payload.get("INPUT_ROLES", {})
    if roles.get("FPTS") != "WEAK_PRIOR" or roles.get("REALIZED_FPTS") != "PROHIBITED":
        raise EngineError("CALIBRATION_INPUT_ROLE_INVALID")
    return payload, sha256_file(CALIBRATION_FILE)


def load_handoff_contract() -> tuple[dict[str, object], str]:
    payload = load_json_contract(HANDOFF_OVERLAY_FILE)
    if payload.get("PATCH_ID") != "HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1":
        raise EngineError("HANDOFF_PATCH_ID_MISMATCH")
    rules = payload.get("GLOBAL_RULES", {})
    required = {
        "SHARED_METRIC_BUNDLE_REQUIRED": True,
        "COMPONENT_SUBHASH_PARITY_REQUIRED": True,
        "FAIL_CLOSED_IF_CONTRACT_MISSING": True,
    }
    if any(rules.get(k) is not v for k, v in required.items()):
        raise EngineError("HANDOFF_GLOBAL_CONTRACT_INVALID")
    return payload, sha256_file(HANDOFF_OVERLAY_FILE)


def load_global_phase2_doctrine() -> tuple[dict[str, object], str]:
    payload = load_json_contract(GLOBAL_PHASE2_DOCTRINE_FILE)
    if payload.get("DOCTRINE_ID") != "APEX_CALIBRATION_FIRST_PHASE2_CONSTRUCTION_v1":
        raise EngineError("GLOBAL_PHASE2_DOCTRINE_ID_MISMATCH")
    arch = payload.get("UNIVERSAL_ARCHITECTURE", {})
    required = {
        "LEGAL_SCAN_IS_PHASE2_BIRTH": False,
        "PHASE2_FREEZE": "REQUIRED",
        "PHASE3_CANDIDATE_LINEUPS": "IDENTICAL_TO_PHASE2_BUILT_LINEUPS",
        "HANDOFF_SURVIVORS": "IDENTICAL_TO_PHASE2_BUILT_LINEUPS",
        "SELECTOR_REVIEWED_LINEUPS": "IDENTICAL_TO_PHASE2_BUILT_LINEUPS",
        "POST_PHASE2_LINEUP_ADDITION": "PROHIBITED",
        "POST_PHASE2_LINEUP_REMOVAL": "PROHIBITED",
    }
    if any(arch.get(k) != v for k, v in required.items()):
        raise EngineError("GLOBAL_PHASE2_DOCTRINE_INVALID")
    return payload, sha256_file(GLOBAL_PHASE2_DOCTRINE_FILE)


def load_tennis_doctrine() -> tuple[dict[str, object], str]:
    payload = load_json_contract(DOCTRINE_FILE)
    if payload.get("DOCTRINE_ID") != "TENNIS_CLASSIC_UNDERSPEND_PERFECT_FAMILY_CLOSURE_v5":
        raise EngineError("TENNIS_DOCTRINE_ID_MISMATCH")
    if payload.get("GLOBAL_PHASE2_DOCTRINE_ID") != "APEX_CALIBRATION_FIRST_PHASE2_CONSTRUCTION_v1":
        raise EngineError("TENNIS_GLOBAL_PHASE2_DOCTRINE_MISMATCH")
    forward = payload.get("FORWARD_RULES", {})
    required_forward = {
        "HARD_SALARY_FLOOR": "PROHIBITED",
        "LEGAL_SCAN_UNIVERSE": "ALL_CAP_LEGAL_LINEUPS",
        "LEGAL_SCAN_IS_PHASE2_BIRTH": False,
        "COMPLETE_CAP_LEGAL_SCAN_BEFORE_BIRTH": "REQUIRED",
        "PHASE2_UNIVERSE": "CALIBRATION_QUALIFIED_LINEUPS_AFTER_COMPLETE_CAP_LEGAL_SCAN",
        "CALIBRATION_QUALIFIED_BIRTH_ONLY": "REQUIRED",
        "PHASE2_FREEZE": "REQUIRED",
        "PHASE3_CANDIDATE_LINEUPS": "IDENTICAL_TO_PHASE2_BUILT_LINEUPS",
        "HANDOFF_SURVIVORS": "IDENTICAL_TO_PHASE2_BUILT_LINEUPS",
        "SELECTOR_REVIEWED_LINEUPS": "IDENTICAL_TO_PHASE2_BUILT_LINEUPS",
        "POST_PHASE2_MUTATION": "PROHIBITED",
        "MODERATE_DOG_MIXED_TOUR_CORE_CLOSURE": "REQUIRED",
        "MODERATE_BALANCED_RELEASE_CORE_PORTFOLIO": "REQUIRED",
        "UNDERSPEND_ARCHETYPE_DEEP_CALIBRATED_HANDOFF_CLOSURE": "REQUIRED",
        "REALIZED_RESULTS_FORWARD_USE": "PROHIBITED",
        "PLAYER_NAMES_IN_SELECTOR": "PROHIBITED",
        "FILLERS": "PROHIBITED",
        "RANK_ALL": "PROHIBITED",
        "ANONYMOUS_FAMILY_SIGNATURE_IN_PHASE2_MANIFEST": "REQUIRED",
    }
    if any(forward.get(k) != v for k, v in required_forward.items()):
        raise EngineError("TENNIS_FORWARD_DOCTRINE_INVALID")
    forensic = payload.get("POSTLOCK_FORENSIC_SELF_HEAL", {})
    if forensic.get("AUTONOMOUS_RECOVERY_REQUIRED") is not True:
        raise EngineError("TENNIS_FORENSIC_SELF_HEAL_NOT_REQUIRED")
    if forensic.get("FORWARD_SELECTOR_INFLUENCE") is not False:
        raise EngineError("TENNIS_FORENSIC_FORWARD_ISOLATION_INVALID")
    if not FORENSIC_MODULE_FILE.is_file():
        raise EngineError("TENNIS_FORENSIC_MODULE_MISSING")
    return payload, sha256_file(DOCTRINE_FILE)

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


CALIBRATION, CALIBRATION_SHA256 = load_calibration_contract()
GLOBAL_PHASE2_DOCTRINE, GLOBAL_PHASE2_DOCTRINE_SHA256 = load_global_phase2_doctrine()
DOCTRINE, DOCTRINE_SHA256 = load_tennis_doctrine()
FORENSIC_MODULE_SHA256 = sha256_file(FORENSIC_MODULE_FILE)


def sha256_json(payload: object) -> str:
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    ).hexdigest()


def pct_rank(x: np.ndarray) -> np.ndarray:
    if len(x) == 0:
        return np.asarray([], dtype=np.float32)
    return (rankdata(x, method="average") / len(x) * 100.0).astype(np.float32)


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c).strip().upper() for c in out.columns]
    return out


@dataclass(frozen=True)
class Slate:
    pool: pd.DataFrame
    matchups: pd.DataFrame
    player_ids: tuple[str, ...]
    salaries: np.ndarray
    weak_projection: np.ndarray
    values: np.ndarray
    match_id: np.ndarray
    opponent_index: np.ndarray
    tours: np.ndarray
    pair_indices: tuple[tuple[int, int], ...]
    pool_sha256: str
    matchup_sha256: str


@dataclass(frozen=True)
class SimBundle:
    scores: np.ndarray
    wins: np.ndarray
    win_probability: np.ndarray
    winner_ceiling_mean: np.ndarray
    winner_ceiling_p90: np.ndarray
    metric_hash: str


def load_slate(pool_path: Path, matchup_path: Path, availability_gate) -> Slate:
    pool = normalize_columns(pd.read_csv(pool_path))
    if tuple(pool.columns) != REQUIRED_POOL_COLUMNS:
        raise EngineError(f"POOL_SCHEMA_INVALID={tuple(pool.columns)}")
    if pool.empty or pool["PLAYER"].duplicated().any():
        raise EngineError("POOL_EMPTY_OR_DUPLICATE_PLAYER")
    if (pool["SAL"] <= 0).any() or (pool["SAL"] > SALARY_CAP).any():
        raise EngineError("PLAYER_SALARY_INVALID")
    if not np.isfinite(pool[["SAL", "FPTS", "VAL"]].to_numpy(dtype=float)).all():
        raise EngineError("POOL_NUMERIC_NONFINITE")

    matchups = normalize_columns(pd.read_csv(matchup_path))
    if tuple(matchups.columns) != REQUIRED_MATCHUP_COLUMNS:
        raise EngineError(f"MATCHUP_SCHEMA_INVALID={tuple(matchups.columns)}")
    if matchups["PLAYER"].duplicated().any():
        raise EngineError("MATCHUP_DUPLICATE_PLAYER")
    if set(matchups["SOURCE"].astype(str)) - ALLOWED_MATCHUP_SOURCES:
        raise EngineError("MATCHUP_SOURCE_NOT_AUTHORIZED")
    if set(matchups["TOUR"].astype(str).str.upper()) - {"ATP", "WTA"}:
        raise EngineError("MATCHUP_TOUR_INVALID")

    unavailable = {
        str(name) for name in pool["PLAYER"].astype(str)
        if not player_is_available(availability_gate, str(name))
    }
    if unavailable:
        blocked_match_ids = set(
            matchups.loc[
                matchups["PLAYER"].astype(str).isin(unavailable)
                | matchups["OPPONENT"].astype(str).isin(unavailable),
                "MATCH_ID",
            ].astype(str)
        )
        matchups = matchups.loc[~matchups["MATCH_ID"].astype(str).isin(blocked_match_ids)].copy().reset_index(drop=True)
        pool = pool.loc[pool["PLAYER"].astype(str).isin(set(matchups["PLAYER"].astype(str)))].copy().reset_index(drop=True)
    if pool.empty:
        raise EngineError("NO_ACTIVE_PARTICIPANTS_AFTER_AVAILABILITY_PURGE")

    pool_names = tuple(pool["PLAYER"].astype(str))
    if set(pool_names) != set(matchups["PLAYER"].astype(str)):
        raise EngineError("MATCHUP_PLAYER_COVERAGE_FAIL")
    matchups = matchups.set_index("PLAYER").loc[list(pool_names)].reset_index()
    by_name = {name: i for i, name in enumerate(pool_names)}

    pair_indices: list[tuple[int, int]] = []
    opponent_index = np.full(len(pool), -1, dtype=np.int16)
    match_codes: dict[str, int] = {}
    match_id = np.full(len(pool), -1, dtype=np.int16)
    seen_pairs: set[tuple[int, int]] = set()
    for i, row in matchups.iterrows():
        opponent = str(row["OPPONENT"])
        if opponent not in by_name:
            raise EngineError(f"MATCHUP_OPPONENT_MISSING={row['PLAYER']}->{opponent}")
        j = by_name[opponent]
        reciprocal = matchups.iloc[j]
        if str(reciprocal["OPPONENT"]) != str(row["PLAYER"]):
            raise EngineError(f"MATCHUP_ASYMMETRY={row['PLAYER']}<->{opponent}")
        if str(reciprocal["MATCH_ID"]) != str(row["MATCH_ID"]):
            raise EngineError(f"MATCH_ID_ASYMMETRY={row['PLAYER']}<->{opponent}")
        opponent_index[i] = j
        key = str(row["MATCH_ID"])
        if key not in match_codes:
            match_codes[key] = len(match_codes)
        match_id[i] = match_codes[key]
        pair = tuple(sorted((i, j)))
        if pair not in seen_pairs:
            seen_pairs.add(pair)
            pair_indices.append(pair)

    if len(pair_indices) * 2 != len(pool):
        raise EngineError("MATCHUP_PAIR_CARDINALITY_FAIL")
    if np.any(opponent_index < 0) or np.any(match_id < 0):
        raise EngineError("MATCHUP_INDEX_INCOMPLETE")

    player_ids = tuple(
        hashlib.sha256(f"{name}|{int(pool.iloc[i]['SAL'])}".encode("utf-8")).hexdigest()[:16]
        for i, name in enumerate(pool_names)
    )
    return Slate(
        pool=pool,
        matchups=matchups,
        player_ids=player_ids,
        salaries=pool["SAL"].to_numpy(np.int32),
        weak_projection=pool["FPTS"].to_numpy(np.float32),
        values=pool["VAL"].to_numpy(np.float32),
        match_id=match_id,
        opponent_index=opponent_index,
        tours=matchups["TOUR"].astype(str).str.upper().to_numpy(),
        pair_indices=tuple(pair_indices),
        pool_sha256=sha256_file(pool_path),
        matchup_sha256=sha256_file(matchup_path),
    )


@njit(cache=False)
def _count_cap_legal(salaries: np.ndarray, opponent_index: np.ndarray) -> int:
    n = len(salaries)
    count = 0
    for a in range(n - 5):
        for b in range(a + 1, n - 4):
            if opponent_index[a] == b:
                continue
            for c in range(b + 1, n - 3):
                if opponent_index[a] == c or opponent_index[b] == c:
                    continue
                for d in range(c + 1, n - 2):
                    if opponent_index[a] == d or opponent_index[b] == d or opponent_index[c] == d:
                        continue
                    for e in range(d + 1, n - 1):
                        if (opponent_index[a] == e or opponent_index[b] == e or
                                opponent_index[c] == e or opponent_index[d] == e):
                            continue
                        for f in range(e + 1, n):
                            if (opponent_index[a] == f or opponent_index[b] == f or
                                    opponent_index[c] == f or opponent_index[d] == f or
                                    opponent_index[e] == f):
                                continue
                            salary = (salaries[a] + salaries[b] + salaries[c] +
                                      salaries[d] + salaries[e] + salaries[f])
                            if salary <= SALARY_CAP:
                                count += 1
    return count


@njit(cache=False)
def _fill_cap_legal(salaries: np.ndarray, opponent_index: np.ndarray,
                    lineups: np.ndarray, lineup_salary: np.ndarray) -> int:
    n = len(salaries)
    z = 0
    for a in range(n - 5):
        for b in range(a + 1, n - 4):
            if opponent_index[a] == b:
                continue
            for c in range(b + 1, n - 3):
                if opponent_index[a] == c or opponent_index[b] == c:
                    continue
                for d in range(c + 1, n - 2):
                    if opponent_index[a] == d or opponent_index[b] == d or opponent_index[c] == d:
                        continue
                    for e in range(d + 1, n - 1):
                        if (opponent_index[a] == e or opponent_index[b] == e or
                                opponent_index[c] == e or opponent_index[d] == e):
                            continue
                        for f in range(e + 1, n):
                            if (opponent_index[a] == f or opponent_index[b] == f or
                                    opponent_index[c] == f or opponent_index[d] == f or
                                    opponent_index[e] == f):
                                continue
                            salary = (salaries[a] + salaries[b] + salaries[c] +
                                      salaries[d] + salaries[e] + salaries[f])
                            if salary > SALARY_CAP:
                                continue
                            lineups[z, 0] = a; lineups[z, 1] = b; lineups[z, 2] = c
                            lineups[z, 3] = d; lineups[z, 4] = e; lineups[z, 5] = f
                            lineup_salary[z] = salary
                            z += 1
    return z


def enumerate_cap_legal_lineups(slate: Slate, work_dir: Path | None = None) -> tuple[np.ndarray, np.ndarray]:
    # Complete cap-legal scan is compiled and materialized to disk-backed memmaps.
    # No full-universe Python object list or dense player-membership matrix is created.
    if work_dir is None:
        work_dir = Path(os.environ.get("APEX_TENNIS_WORK_DIR", "/mnt/data/apex_tennis_work"))
    work_dir.mkdir(parents=True, exist_ok=True)
    count = int(_count_cap_legal(slate.salaries.astype(np.int32), slate.opponent_index.astype(np.int16)))
    if count <= 0:
        raise EngineError("NO_CAP_LEGAL_LINEUPS")
    lineup_path = work_dir / "cap_legal_lineups.i16.mmap"
    salary_path = work_dir / "cap_legal_salary.i32.mmap"
    legal = np.memmap(lineup_path, mode="w+", dtype=np.int16, shape=(count, ROSTER_SIZE))
    legal_salary = np.memmap(salary_path, mode="w+", dtype=np.int32, shape=(count,))
    written = int(_fill_cap_legal(
        slate.salaries.astype(np.int32), slate.opponent_index.astype(np.int16), legal, legal_salary
    ))
    if written != count:
        raise EngineError(f"CAP_LEGAL_SCAN_COUNT_MISMATCH={written}!={count}")
    legal.flush(); legal_salary.flush()
    return legal, legal_salary

def membership_matrix(lineups: np.ndarray, n_players: int) -> np.ndarray:
    out = np.zeros((n_players, len(lineups)), dtype=np.float32)
    cols = np.arange(len(lineups))
    for slot in range(lineups.shape[1]):
        out[lineups[:, slot], cols] = 1.0
    return out


def estimate_win_probabilities(slate: Slate) -> np.ndarray:
    p = np.zeros(len(slate.pool), dtype=np.float32)
    proj = slate.weak_projection.astype(float)
    val = slate.values.astype(float)
    sal = slate.salaries.astype(float)
    for a, b in slate.pair_indices:
        # FPTS is a weak prior, never the primary driver. Salary and within-match value
        # define a bounded pre-lock probability with material upset mass on both sides.
        logit = (
            (sal[a] - sal[b]) / float(CALIBRATION["PHASE1"]["SALARY_LOGIT_SCALE"])
            + float(CALIBRATION["PHASE1"]["FPTS_Z_WEIGHT"]) * (proj[a] - proj[b]) / max(float(np.std(proj)), 1.0)
            + float(CALIBRATION["PHASE1"]["VAL_Z_WEIGHT"]) * (val[a] - val[b]) / max(float(np.std(val)), 1.0)
        )
        pa = float(1.0 / (1.0 + math.exp(-logit)))
        pa = float(np.clip(pa, float(CALIBRATION["PHASE1"]["MIN_WIN_PROBABILITY"]), float(CALIBRATION["PHASE1"]["MAX_WIN_PROBABILITY"])))
        p[a] = pa
        p[b] = 1.0 - pa
    return p


def simulate_players(slate: Slate, *, trials: int, seed: int, metric_namespace: str) -> SimBundle:
    if trials < MIN_PHASE1_TRIALS:
        raise EngineError(f"SIM_TRIALS_BELOW_FLOOR={trials}")
    rng = np.random.default_rng(seed)
    n = len(slate.pool)
    scores = np.zeros((trials, n), dtype=np.float32)
    wins = np.zeros((trials, n), dtype=np.bool_)
    win_probability = estimate_win_probabilities(slate)
    winner_ceiling_mean = np.zeros(n, dtype=np.float32)
    winner_ceiling_p90 = np.zeros(n, dtype=np.float32)
    proj = slate.weak_projection.astype(float)
    val = slate.values.astype(float)
    proj_z = (proj - proj.mean()) / max(float(proj.std()), 1.0)
    val_z = (val - val.mean()) / max(float(val.std()), 1.0)

    for a, b in slate.pair_indices:
        pa = float(win_probability[a])
        a_wins = rng.random(trials) < pa
        wins[:, a] = a_wins
        wins[:, b] = ~a_wins
        for player, won in ((a, a_wins), (b, ~a_wins)):
            tour = slate.tours[player]
            # Conditional winner distribution is intentionally wide and only weakly
            # centered on the pool projection. Cheap underdogs retain true ceiling paths.
            win_mu = float(CALIBRATION["PHASE1"]["WIN_BASE_MEAN"]) + float(CALIBRATION["PHASE1"]["FPTS_WIN_MEAN_WEIGHT"]) * proj_z[player] + float(CALIBRATION["PHASE1"]["VAL_WIN_MEAN_WEIGHT"]) * val_z[player]
            if tour == "ATP":
                win_mu += float(CALIBRATION["PHASE1"]["ATP_WIN_MEAN_BONUS"])
            loss_mu = float(CALIBRATION["PHASE1"]["LOSS_BASE_MEAN"]) + float(CALIBRATION["PHASE1"]["LOSS_FPTS_WEIGHT"]) * max(proj[player], 0.0)
            base_sd = float(CALIBRATION["PHASE1"]["WTA_BASE_SD"]) if tour == "WTA" else float(CALIBRATION["PHASE1"]["ATP_BASE_SD"])
            shared = rng.normal(0.0, 2.8, trials)
            individual = rng.normal(0.0, base_sd, trials)
            score = np.where(won, win_mu, loss_mu) + shared + individual
            straight_p = 0.28 + 0.18 * abs(float(win_probability[player]) - 0.5) * 2.0
            straight = won & (rng.random(trials) < straight_p)
            score += straight * rng.normal(11.0, 3.0, trials)
            burst_p = 0.055 if tour == "ATP" else 0.045
            burst = won & (rng.random(trials) < burst_p)
            score += burst * rng.gamma(2.2, 4.5 if tour == "ATP" else 3.8, trials)
            loss_volume = (~won) & (rng.random(trials) < 0.18)
            score += loss_volume * rng.gamma(1.8, 3.0, trials)
            scores[:, player] = np.clip(score, 0.0, None).astype(np.float32)
            winner_samples = scores[won, player]
            if len(winner_samples):
                winner_ceiling_mean[player] = float(winner_samples.mean())
                winner_ceiling_p90[player] = float(np.quantile(winner_samples, 0.90))

    fingerprint_payload = {
        "namespace": metric_namespace,
        "pool_sha256": slate.pool_sha256,
        "matchup_sha256": slate.matchup_sha256,
        "trials": trials,
        "seed": seed,
        "win_probability": np.round(win_probability, 8).tolist(),
        "winner_ceiling_mean": np.round(winner_ceiling_mean, 6).tolist(),
        "winner_ceiling_p90": np.round(winner_ceiling_p90, 6).tolist(),
        "fpts_role": "WEAK_PRIOR",
        "realized_results_used": False,
    }
    return SimBundle(
        scores=scores,
        wins=wins,
        win_probability=win_probability,
        winner_ceiling_mean=winner_ceiling_mean,
        winner_ceiling_p90=winner_ceiling_p90,
        metric_hash=sha256_json(fingerprint_payload),
    )


def score_lineup_metrics(
    player_scores: np.ndarray,
    lineups: np.ndarray,
    *,
    thresholds: np.ndarray | None = None,
    max_field: np.ndarray | None = None,
    lineup_chunk: int = 1024,
) -> dict[str, np.ndarray]:
    n_lineups = len(lineups)
    n_trials = player_scores.shape[0]
    mean = np.empty(n_lineups, dtype=np.float32)
    p95 = np.empty(n_lineups, dtype=np.float32)
    p99 = np.empty(n_lineups, dtype=np.float32)
    cvar99 = np.empty(n_lineups, dtype=np.float32)
    top_count = np.zeros(n_lineups, dtype=np.int32)
    win_count = np.zeros(n_lineups, dtype=np.int32)
    k = max(1, int(math.ceil(n_trials * 0.01)))
    for st in range(0, n_lineups, lineup_chunk):
        en = min(n_lineups, st + lineup_chunk)
        chunk = np.asarray(lineups[st:en])
        s = player_scores[:, chunk[:, 0]].copy()
        for slot in range(1, ROSTER_SIZE):
            s += player_scores[:, chunk[:, slot]]
        mean[st:en] = s.mean(axis=0)
        p95[st:en] = np.quantile(s, 0.95, axis=0)
        p99[st:en] = np.quantile(s, 0.99, axis=0)
        tail = np.partition(s, n_trials - k, axis=0)[n_trials - k:]
        cvar99[st:en] = tail.mean(axis=0)
        if thresholds is not None and max_field is not None:
            top_count[st:en] = (s >= thresholds[:, None]).sum(axis=0)
            win_count[st:en] = (s >= max_field[:, None]).sum(axis=0)
    out = {"mean": mean, "p95": p95, "p99": p99, "cvar99": cvar99}
    if thresholds is not None and max_field is not None:
        out["top01_rate"] = top_count.astype(np.float64) / n_trials
        out["win_rate"] = win_count.astype(np.float64) / n_trials
        out["top01_count"] = top_count
        out["win_count"] = win_count
    return out

def build_fake_field(
    slate: Slate,
    lineups: np.ndarray,
    salaries: np.ndarray,
    sim: SimBundle,
    *,
    field_size: int,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    n_players = len(slate.pool)
    win_z = (sim.win_probability - sim.win_probability.mean()) / max(float(sim.win_probability.std()), 1e-6)
    proj = slate.weak_projection
    proj_z = (proj - proj.mean()) / max(float(proj.std()), 1e-6)
    sal_z = (slate.salaries - slate.salaries.mean()) / max(float(slate.salaries.std()), 1e-6)
    player_public = (1.15 * win_z + 0.35 * proj_z + 0.30 * sal_z).astype(np.float32)
    lineup_logw = np.zeros(len(lineups), dtype=np.float32)
    for slot in range(ROSTER_SIZE):
        lineup_logw += player_public[np.asarray(lineups[:, slot])]
    lineup_logw += 0.30 * ((np.asarray(salaries) - 46_000) / 4_000.0)
    lineup_logw -= float(lineup_logw.max())
    weights = np.exp(np.clip(lineup_logw, -40.0, 0.0), dtype=np.float64)
    cdf = np.cumsum(weights, dtype=np.float64)
    fake_field_n = int(math.ceil(field_size * float(CALIBRATION["FAKE_FIELD"]["FIELD_SIZE_MULTIPLIER"])))
    draws = rng.random(fake_field_n) * cdf[-1]
    fake_idx = np.searchsorted(cdf, draws, side="right").astype(np.int32)
    fake_lineups = np.asarray(lineups[fake_idx])
    player_counts = np.bincount(fake_lineups.ravel(), minlength=n_players)
    player_own = np.asarray(player_counts / fake_field_n, dtype=np.float32)
    log_player_own = np.log(np.clip(player_own, 1e-6, 1.0)).astype(np.float32)
    lineup_log_own = np.zeros(len(lineups), dtype=np.float32)
    for slot in range(ROSTER_SIZE):
        lineup_log_own += log_player_own[np.asarray(lineups[:, slot])]
    lineup_own_product = np.exp(lineup_log_own).astype(np.float32)
    lineup_dup_count = np.bincount(fake_idx, minlength=len(lineups)).astype(np.int32)
    return fake_idx, player_own, lineup_own_product, lineup_dup_count

def field_thresholds(
    player_scores: np.ndarray,
    lineups: np.ndarray,
    fake_idx: np.ndarray,
    *,
    trial_chunk: int = 250,
) -> tuple[np.ndarray, np.ndarray]:
    fake_lineups = np.asarray(lineups[fake_idx])
    thresholds = np.empty(player_scores.shape[0], dtype=np.float32)
    max_field = np.empty(player_scores.shape[0], dtype=np.float32)
    k_top = max(1, int(math.ceil(len(fake_idx) * 0.001)))
    for st in range(0, player_scores.shape[0], trial_chunk):
        en = min(player_scores.shape[0], st + trial_chunk)
        fs = player_scores[st:en, fake_lineups[:, 0]].copy()
        for slot in range(1, ROSTER_SIZE):
            fs += player_scores[st:en, fake_lineups[:, slot]]
        thresholds[st:en] = np.partition(fs, fs.shape[1] - k_top, axis=1)[:, fs.shape[1] - k_top]
        max_field[st:en] = fs.max(axis=1)
    return thresholds, max_field

def lineup_structural_features(slate: Slate, lineups: np.ndarray, salaries: np.ndarray, sim: SimBundle) -> dict[str, np.ndarray]:
    n = len(lineups)
    dog_count = np.zeros(n, dtype=np.int8)
    low_salary_count = np.zeros(n, dtype=np.int8)
    premium_count = np.zeros(n, dtype=np.int8)
    atp_count = np.zeros(n, dtype=np.int8)
    joint_win_probability = np.ones(n, dtype=np.float32)
    log_sum = np.zeros(n, dtype=np.float64)
    min_win_probability = np.ones(n, dtype=np.float32)
    entropy = np.zeros(n, dtype=np.float32)
    winner_ceiling = np.zeros(n, dtype=np.float32)
    ceiling_sum_sq = np.zeros(n, dtype=np.float32)
    ceiling_min = np.full(n, np.inf, dtype=np.float32)
    for slot in range(ROSTER_SIZE):
        idx = np.asarray(lineups[:, slot])
        wp = np.clip(sim.win_probability[idx], 1e-6, 1.0 - 1e-6).astype(np.float32)
        psal = slate.salaries[idx]
        pc = sim.winner_ceiling_p90[idx].astype(np.float32)
        dog_count += (wp < 0.5).astype(np.int8)
        low_salary_count += (psal <= 7100).astype(np.int8)
        premium_count += (psal >= 9000).astype(np.int8)
        atp_count += (slate.tours[idx] == "ATP").astype(np.int8)
        joint_win_probability *= wp
        log_sum += np.log(wp)
        min_win_probability = np.minimum(min_win_probability, wp)
        entropy += (-wp * np.log(wp) - (1.0 - wp) * np.log(1.0 - wp)).astype(np.float32)
        winner_ceiling += pc
        ceiling_sum_sq += pc * pc
        ceiling_min = np.minimum(ceiling_min, pc)
    wta_count = (ROSTER_SIZE - atp_count).astype(np.int8)
    geometric_win_probability = np.exp(log_sum / ROSTER_SIZE).astype(np.float32)
    ceiling_mean = winner_ceiling / ROSTER_SIZE
    ceiling_var = np.maximum(ceiling_sum_sq / ROSTER_SIZE - ceiling_mean * ceiling_mean, 0.0)
    ceiling_balance = (-(np.sqrt(ceiling_var) / np.maximum(ceiling_mean, 1e-6))).astype(np.float32)
    salary_left = (SALARY_CAP - np.asarray(salaries)).astype(np.int32)
    salary_band = np.select(
        [np.asarray(salaries) <= 44_000, np.asarray(salaries) <= 47_000, np.asarray(salaries) <= 49_000],
        [0, 1, 2], default=3,
    ).astype(np.int8)
    return {
        "dog_count": dog_count,
        "low_salary_count": low_salary_count,
        "premium_count": premium_count,
        "atp_count": atp_count,
        "wta_count": wta_count,
        "joint_win_probability": joint_win_probability,
        "geometric_win_probability": geometric_win_probability,
        "min_win_probability": min_win_probability,
        "entropy": entropy,
        "winner_ceiling": winner_ceiling,
        "ceiling_min": ceiling_min,
        "ceiling_balance": ceiling_balance,
        "salary_left": salary_left,
        "salary_band": salary_band,
    }

def under_spend_archetype_masks(
    structural: dict[str, np.ndarray], salaries: np.ndarray
) -> list[tuple[str, np.ndarray, int]]:
    dog = structural["dog_count"]
    low = structural["low_salary_count"]
    premium = structural["premium_count"]
    atp = structural["atp_count"]
    wta = structural["wta_count"]
    cfg = CALIBRATION["SELECTOR"]["UNDERSPEND_ARCHETYPES"]
    return [
        (
            "UNDERSPEND_WTA_CHAOS",
            (salaries <= int(cfg["WTA_HEAVY"]["SALARY_MAX"]))
            & (dog >= int(cfg["WTA_HEAVY"]["DOG_MIN"]))
            & (low >= int(cfg["WTA_HEAVY"]["LOW_SALARY_MIN"]))
            & (premium >= int(cfg["WTA_HEAVY"]["PREMIUM_MIN"]))
            & (wta >= int(cfg["WTA_HEAVY"]["WTA_MIN"])),
            int(cfg["WTA_HEAVY"]["QUOTA"]),
        ),
        (
            "UNDERSPEND_MIXED_CHAOS",
            (salaries <= int(cfg["MIXED"]["SALARY_MAX"]))
            & (dog >= int(cfg["MIXED"]["DOG_MIN"]))
            & (low >= int(cfg["MIXED"]["LOW_SALARY_MIN"]))
            & (premium >= int(cfg["MIXED"]["PREMIUM_MIN"]))
            & (atp >= int(cfg["MIXED"]["ATP_MIN"]))
            & (atp <= int(cfg["MIXED"]["ATP_MAX"])),
            int(cfg["MIXED"]["QUOTA"]),
        ),
        (
            "UNDERSPEND_ATP_CHAOS",
            (salaries <= int(cfg["ATP_HEAVY"]["SALARY_MAX"]))
            & (dog >= int(cfg["ATP_HEAVY"]["DOG_MIN"]))
            & (low >= int(cfg["ATP_HEAVY"]["LOW_SALARY_MIN"]))
            & (premium >= int(cfg["ATP_HEAVY"]["PREMIUM_MIN"]))
            & (atp >= int(cfg["ATP_HEAVY"]["ATP_MIN"])),
            int(cfg["ATP_HEAVY"]["QUOTA"]),
        ),
        (
            "UNDERSPEND_BALANCED_NO_PREMIUM",
            (salaries >= int(cfg["BALANCED_NO_PREMIUM"]["SALARY_MIN"]))
            & (salaries <= int(cfg["BALANCED_NO_PREMIUM"]["SALARY_MAX"]))
            & (dog >= int(cfg["BALANCED_NO_PREMIUM"]["DOG_MIN"]))
            & (dog <= int(cfg["BALANCED_NO_PREMIUM"]["DOG_MAX"]))
            & (low >= int(cfg["BALANCED_NO_PREMIUM"]["LOW_SALARY_MIN"]))
            & (low <= int(cfg["BALANCED_NO_PREMIUM"]["LOW_SALARY_MAX"]))
            & (premium <= int(cfg["BALANCED_NO_PREMIUM"]["PREMIUM_MAX"]))
            & (atp >= int(cfg["BALANCED_NO_PREMIUM"]["ATP_MIN"]))
            & (atp <= int(cfg["BALANCED_NO_PREMIUM"]["ATP_MAX"])),
            int(cfg["BALANCED_NO_PREMIUM"]["QUOTA"]),
        ),
    ]


def anonymous_family_signatures(structural: dict[str, np.ndarray], salaries: np.ndarray) -> np.ndarray:
    """Stable player-name-free lineage signature for every Phase-2 lineup."""
    values = zip(
        salaries.astype(int),
        structural["dog_count"].astype(int),
        structural["low_salary_count"].astype(int),
        structural["premium_count"].astype(int),
        structural["atp_count"].astype(int),
        structural["wta_count"].astype(int),
    )
    return np.asarray(
        [f"S{salary}|D{dog}|L{low}|P{premium}|A{atp}|W{wta}" for salary, dog, low, premium, atp, wta in values],
        dtype=object,
    )


@njit(cache=False, parallel=True)
def _phase2_proxy_kernel(
    legal: np.ndarray,
    player_mean: np.ndarray,
    player_p95: np.ndarray,
    player_p99: np.ndarray,
    player_cvar99: np.ndarray,
    log_own_player: np.ndarray,
    mean: np.ndarray,
    p95: np.ndarray,
    p99: np.ndarray,
    cvar99: np.ndarray,
    lineup_own_proxy: np.ndarray,
) -> None:
    for i in prange(len(legal)):
        sm = 0.0; s95 = 0.0; s99 = 0.0; sc = 0.0; slo = 0.0
        for slot in range(ROSTER_SIZE):
            x = legal[i, slot]
            sm += player_mean[x]; s95 += player_p95[x]; s99 += player_p99[x]
            sc += player_cvar99[x]; slo += log_own_player[x]
        mean[i] = sm; p95[i] = s95; p99[i] = s99; cvar99[i] = sc
        lineup_own_proxy[i] = math.exp(slo)


def phase2_calibration_proxies(
    slate: Slate,
    legal: np.ndarray,
    salaries: np.ndarray,
    sim: SimBundle,
    structural: dict[str, np.ndarray],
) -> dict[str, np.ndarray]:
    ps = sim.scores
    player_mean = ps.mean(axis=0).astype(np.float32)
    player_p95 = np.quantile(ps, 0.95, axis=0).astype(np.float32)
    player_p99 = np.quantile(ps, 0.99, axis=0).astype(np.float32)
    k = max(1, int(math.ceil(ps.shape[0] * 0.01)))
    player_cvar99 = np.partition(ps, ps.shape[0] - k, axis=0)[ps.shape[0] - k:].mean(axis=0).astype(np.float32)
    own_proxy = np.clip(
        0.50 * sim.win_probability
        + 0.25 * (slate.salaries / float(SALARY_CAP))
        + 0.25 * np.clip(slate.weak_projection / max(float(slate.weak_projection.max()), 1.0), 0.0, 1.0),
        0.01, 0.95,
    ).astype(np.float32)
    log_own_player = np.log(np.clip(own_proxy, 1e-12, 1.0)).astype(np.float32)
    n = len(legal)
    mean = np.empty(n, dtype=np.float32); p95 = np.empty(n, dtype=np.float32)
    p99 = np.empty(n, dtype=np.float32); cvar99 = np.empty(n, dtype=np.float32)
    lineup_own_proxy = np.empty(n, dtype=np.float32)
    _phase2_proxy_kernel(
        legal, player_mean, player_p95, player_p99, player_cvar99,
        log_own_player, mean, p95, p99, cvar99, lineup_own_proxy,
    )
    joint = structural["joint_win_probability"]
    winner_ceiling = structural["winner_ceiling"]
    proxy = {
        "mean": mean, "p95": p95, "p99": p99, "cvar99": cvar99,
        "joint_win": joint.astype(np.float32, copy=False),
        "winner_ceiling": winner_ceiling.astype(np.float32, copy=False),
        "own_proxy": lineup_own_proxy,
    }
    proxy["tail_efficiency"] = (
        np.power(np.clip(proxy["joint_win"], 1e-9, 1.0), 0.35)
        * proxy["winner_ceiling"]
        / np.power(np.clip(proxy["own_proxy"], 1e-12, 1.0), 0.06)
    ).astype(np.float32)
    proxy["low_spend_upset_efficiency"] = (
        1000.0 * np.power(np.clip(proxy["joint_win"], 1e-9, 1.0), 0.55)
        + 0.010 * np.asarray(salaries)
        + 4.0 * (structural["premium_count"] == 1)
        + 2.0 * (structural["low_salary_count"] == 4)
    ).astype(np.float32)
    return proxy

def moderate_dog_mixed_core_mask(
    salaries: np.ndarray, structural: dict[str, np.ndarray]
) -> np.ndarray:
    cfg = CALIBRATION["PHASE2"]["MODERATE_DOG_MIXED_TOUR_CORE_CLOSURE"]
    dog = structural["dog_count"]; low = structural["low_salary_count"]
    premium = structural["premium_count"]; atp = structural["atp_count"]
    return (
        (np.asarray(salaries) >= int(cfg["SALARY_MIN"]))
        & (np.asarray(salaries) <= int(cfg["SALARY_MAX"]))
        & (dog >= int(cfg["DOG_MIN"])) & (dog <= int(cfg["DOG_MAX"]))
        & (low >= int(cfg["LOW_SALARY_MIN"])) & (low <= int(cfg["LOW_SALARY_MAX"]))
        & (premium >= int(cfg["PREMIUM_MIN"])) & (premium <= int(cfg["PREMIUM_MAX"]))
        & (atp >= int(cfg["ATP_MIN"])) & (atp <= int(cfg["ATP_MAX"]))
    )


def canonical_core_codes(
    slate: Slate, lineups: np.ndarray, sim: SimBundle
) -> np.ndarray:
    """Anonymous four-player calibrated-tail core code for each lineup."""
    own_proxy = np.clip(
        0.50 * sim.win_probability
        + 0.25 * (slate.salaries / float(SALARY_CAP))
        + 0.25 * np.clip(
            slate.weak_projection / max(float(slate.weak_projection.max()), 1.0),
            0.0,
            1.0,
        ),
        0.01,
        0.95,
    )
    player_core_score = (
        np.power(np.clip(sim.win_probability, 1e-9, 1.0), 0.35)
        * sim.winner_ceiling_p90
        / np.power(np.clip(own_proxy, 1e-12, 1.0), 0.06)
    ).astype(np.float32)
    local_scores = player_core_score[np.asarray(lineups)]
    top4_pos = np.argpartition(local_scores, 2, axis=1)[:, 2:]
    core_players = np.take_along_axis(np.asarray(lineups), top4_pos, axis=1)
    core_players.sort(axis=1)
    base = np.uint64(len(slate.pool))
    return (
        core_players[:, 0].astype(np.uint64)
        + base * core_players[:, 1].astype(np.uint64)
        + base**2 * core_players[:, 2].astype(np.uint64)
        + base**3 * core_players[:, 3].astype(np.uint64)
    )


def moderate_dog_mixed_core_closure_indices(
    slate: Slate,
    legal: np.ndarray,
    salaries: np.ndarray,
    structural: dict[str, np.ndarray],
    proxy: dict[str, np.ndarray],
    sim: SimBundle,
) -> np.ndarray:
    mask = moderate_dog_mixed_core_mask(salaries, structural)
    eligible = np.flatnonzero(mask).astype(np.int32)
    if len(eligible) == 0:
        return eligible
    cfg = CALIBRATION["PHASE2"]["MODERATE_DOG_MIXED_TOUR_CORE_CLOSURE"]
    own_proxy = np.clip(
        0.50 * sim.win_probability
        + 0.25 * (slate.salaries / float(SALARY_CAP))
        + 0.25 * np.clip(slate.weak_projection / max(float(slate.weak_projection.max()), 1.0), 0.0, 1.0),
        0.01, 0.95,
    )
    player_core_score = (
        np.power(np.clip(sim.win_probability, 1e-9, 1.0), 0.35)
        * sim.winner_ceiling_p90
        / np.power(np.clip(own_proxy, 1e-12, 1.0), 0.06)
    ).astype(np.float32)
    lineups = np.asarray(legal[eligible])
    local_scores = player_core_score[lineups]
    # Canonical anonymous core: four highest calibrated tail players in each lineup.
    top4_pos = np.argpartition(local_scores, 2, axis=1)[:, 2:]
    core_players = np.take_along_axis(lineups, top4_pos, axis=1)
    core_players.sort(axis=1)
    base = np.uint64(len(slate.pool))
    core_code = (
        core_players[:, 0].astype(np.uint64)
        + base * core_players[:, 1].astype(np.uint64)
        + base**2 * core_players[:, 2].astype(np.uint64)
        + base**3 * core_players[:, 3].astype(np.uint64)
    )
    # Keep the top calibrated two-swap siblings per core. Mean is a Phase-1
    # distribution output, not a raw projection or post-lock result.
    axis = proxy[str(cfg["ORDER_AXIS"])][eligible]
    order = np.lexsort((eligible, -axis, core_code))
    ordered_core = core_code[order]
    new_group = np.empty(len(order), dtype=bool)
    new_group[0] = True
    new_group[1:] = ordered_core[1:] != ordered_core[:-1]
    group_starts = np.flatnonzero(new_group)
    group_ends = np.r_[group_starts[1:], len(order)]
    siblings = int(cfg["SIBLINGS_PER_CORE"])
    valid = (group_ends - group_starts) >= siblings
    valid_starts = group_starts[valid]
    if len(valid_starts) == 0:
        return np.asarray([], dtype=np.int32)
    # Rank cores by the weaker retained sibling, preventing a single strong seed
    # from defining a closure family. This is anonymous and Phase-1-only.
    family_score = axis[order[valid_starts + siblings - 1]]
    family_keep = min(int(cfg["CORE_FAMILIES_KEEP"]), len(valid_starts))
    if family_keep < len(valid_starts):
        top = np.argpartition(family_score, len(family_score) - family_keep)[len(family_score) - family_keep:]
        valid_starts = valid_starts[top]
    positions = (valid_starts[:, None] + np.arange(siblings, dtype=np.int64)[None, :]).ravel()
    return np.sort(eligible[order[positions]]).astype(np.int32)


@njit(cache=False)
def _group_order_small_codes(codes: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    max_code = int(codes.max())
    counts = np.zeros(max_code + 1, dtype=np.int64)
    for i in range(len(codes)):
        counts[int(codes[i])] += 1
    starts_all = np.zeros(max_code + 1, dtype=np.int64)
    running = 0
    for c in range(max_code + 1):
        starts_all[c] = running
        running += counts[c]
    write = starts_all.copy()
    order = np.empty(len(codes), dtype=np.int32)
    for i in range(len(codes)):
        c = int(codes[i])
        order[write[c]] = i
        write[c] += 1
    nonempty = 0
    for c in range(max_code + 1):
        if counts[c] > 0:
            nonempty += 1
    starts = np.empty(nonempty, dtype=np.int64)
    ends = np.empty(nonempty, dtype=np.int64)
    z = 0
    for c in range(max_code + 1):
        if counts[c] > 0:
            starts[z] = starts_all[c]
            ends[z] = starts_all[c] + counts[c]
            z += 1
    return order, starts, ends


def phase3_candidate_indices(
    slate: Slate,
    legal: np.ndarray,
    salaries: np.ndarray,
    structural: dict[str, np.ndarray],
    proxy: dict[str, np.ndarray],
    sim: SimBundle,
    *,
    per_family: int | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    if per_family is None:
        per_family = int(CALIBRATION["PHASE2"]["PER_FAMILY_KEEP"])
    parts: list[np.ndarray] = []
    global_axes = ("mean", "p95", "p99", "cvar99", "tail_efficiency")
    global_keep = min(int(CALIBRATION["PHASE2"]["GLOBAL_AXIS_KEEP"]), len(salaries))
    for axis in global_axes:
        values = proxy[axis]
        idx = np.argpartition(values, len(values) - global_keep)[len(values) - global_keep:]
        parts.append(idx.astype(np.int32, copy=False))

    salary_bin = (np.asarray(salaries) // 1000).astype(np.int16)
    dog = structural["dog_count"].astype(np.int16, copy=False)
    family_code = (salary_bin.astype(np.int32) * 8 + dog.astype(np.int32))
    family_axes = ("joint_win", "winner_ceiling", "tail_efficiency", "low_spend_upset_efficiency")
    for code in np.unique(family_code):
        group = np.flatnonzero(family_code == code)
        take = min(per_family, len(group))
        if take <= 0:
            continue
        for axis in family_axes:
            if take == len(group):
                chosen = group
            else:
                values = proxy[axis][group]
                local = np.argpartition(values, len(values) - take)[len(values) - take:]
                chosen = group[local]
            parts.append(chosen.astype(np.int32, copy=False))

    closure_mask = (
        (np.asarray(salaries) <= 44_500) & (dog >= 5)
        & (structural["low_salary_count"] >= 4)
        & (structural["premium_count"] >= 1)
    )
    closure = np.flatnonzero(closure_mask)
    if len(closure):
        take = min(int(CALIBRATION["PHASE2"]["EXTREME_LOW_SPEND_CLOSURE_KEEP"]), len(closure))
        values = proxy["low_spend_upset_efficiency"][closure]
        local = np.argpartition(values, len(values) - take)[len(values) - take:]
        parts.append(closure[local].astype(np.int32, copy=False))

    deep_cfg = CALIBRATION["PHASE2"]["UNDERSPEND_ARCHETYPE_DEEP_CLOSURE"]
    deep_axis = proxy[str(deep_cfg["ORDER_AXIS"])]
    for family_name, mask, _ in under_spend_archetype_masks(structural, np.asarray(salaries)):
        hit = np.flatnonzero(mask).astype(np.int32)
        if len(hit) == 0:
            continue
        if family_name in {"UNDERSPEND_WTA_CHAOS", "UNDERSPEND_BALANCED_NO_PREMIUM"}:
            parts.append(hit)
            continue
        keep_key = "MIXED_KEEP" if family_name == "UNDERSPEND_MIXED_CHAOS" else "ATP_HEAVY_KEEP"
        keep_n = min(int(deep_cfg[keep_key]), len(hit))
        values = deep_axis[hit]
        local = np.argpartition(values, len(values) - keep_n)[len(values) - keep_n:]
        parts.append(hit[local])

    core_closure = moderate_dog_mixed_core_closure_indices(
        slate, legal, salaries, structural, proxy, sim
    )
    if len(core_closure):
        parts.append(core_closure)
    if not parts:
        raise EngineError("NO_CALIBRATION_QUALIFIED_LINEUPS")
    selected = np.unique(np.concatenate(parts)).astype(np.int32)
    return selected, core_closure

def wilson_interval(count: np.ndarray, trials: int, z: float = 1.96) -> tuple[np.ndarray, np.ndarray]:
    p = count / trials
    den = 1.0 + z * z / trials
    center = (p + z * z / (2 * trials)) / den
    half = z * np.sqrt((p * (1 - p) + z * z / (4 * trials)) / trials) / den
    return center - half, center + half


def adaptive_bubble(
    slate: Slate,
    candidate_lineups: np.ndarray,
    fake_lineups: np.ndarray,
    fake_idx: np.ndarray,
    base: dict[str, np.ndarray],
    *,
    seed: int,
    base_trials: int,
    max_bubble: int = 5000,
) -> tuple[dict[str, np.ndarray], int, int, str]:
    # Bubble is defined by uncertainty overlap around the top-3% preliminary
    # top-0.1 cutoff. Unresolved lineups pass forward by global contract.
    rate = base["top01_rate"]
    cutoff = float(np.quantile(rate, 0.97))
    lo, hi = wilson_interval(base["top01_count"], base_trials)
    bubble = np.flatnonzero((lo <= cutoff) & (hi >= cutoff))
    if len(bubble) > max_bubble:
        proximity = np.abs(rate[bubble] - cutoff)
        bubble = bubble[np.argsort(proximity, kind="stable")[:max_bubble]]
    if len(bubble) == 0:
        return base, 0, 0, sha256_json({"bubble": [], "cutoff": cutoff})

    extra_sim = simulate_players(
        slate,
        trials=BUBBLE_BATCH_TRIALS,
        seed=seed,
        metric_namespace="HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1",
    )
    extra_threshold, extra_max = field_thresholds(extra_sim.scores, fake_lineups, fake_idx)
    extra_metrics = score_lineup_metrics(
        extra_sim.scores,
        candidate_lineups[bubble],
        thresholds=extra_threshold,
        max_field=extra_max,
    )
    total = base_trials + BUBBLE_BATCH_TRIALS
    out = {k: np.array(v, copy=True) for k, v in base.items()}
    old_top_count = out["top01_count"][bubble].astype(np.int64)
    old_win_count = out["win_count"][bubble].astype(np.int64)
    new_top_count = old_top_count + extra_metrics["top01_count"].astype(np.int64)
    new_win_count = old_win_count + extra_metrics["win_count"].astype(np.int64)
    out["top01_count"][bubble] = new_top_count.astype(np.int32)
    out["win_count"][bubble] = new_win_count.astype(np.int32)
    out["top01_rate"][bubble] = new_top_count / total
    out["win_rate"][bubble] = new_win_count / total
    for key in ("mean", "p95", "p99", "cvar99"):
        out[key][bubble] = (
            out[key][bubble] * base_trials + extra_metrics[key] * BUBBLE_BATCH_TRIALS
        ) / total
    bubble_hash = sha256_json(
        {
            "cutoff": cutoff,
            "bubble_lineup_indices": bubble.tolist(),
            "base_metric_hash": base.get("metric_hash", ""),
            "extra_metric_hash": extra_sim.metric_hash,
        }
    )
    return out, int(len(bubble) * BUBBLE_BATCH_TRIALS), int(len(bubble)), bubble_hash


def selector_objectives(
    metrics: dict[str, np.ndarray],
    structural: dict[str, np.ndarray],
    lineup_own_product: np.ndarray,
    lineup_dup_count: np.ndarray,
) -> dict[str, np.ndarray]:
    ranks = {key: pct_rank(metrics[key]) for key in ("top01_rate", "win_rate", "p95", "p99", "mean", "cvar99")}
    uniqueness = 100.0 - pct_rank(lineup_own_product)
    low_dup = 100.0 - pct_rank(lineup_dup_count.astype(float))
    tail_leverage = pct_rank(
        structural["winner_ceiling"]
        * np.power(np.clip(structural["joint_win_probability"], 1e-8, 1.0), 0.18)
        / np.power(np.clip(lineup_own_product, 1e-12, 1.0), 0.08)
    )
    w = CALIBRATION["SELECTOR"]["WEIGHTS"]
    objective = (
        float(w["TOP_0_1_RATE"]) * ranks["top01_rate"]
        + float(w["WIN_RATE"]) * ranks["win_rate"]
        + float(w["P99"]) * ranks["p99"]
        + float(w["P95"]) * ranks["p95"]
        + float(w["CVAR99"]) * ranks["cvar99"]
        + float(w["MEAN"]) * ranks["mean"]
        + float(w["UNIQUENESS"]) * uniqueness
        + float(w["LOW_DUP"]) * low_dup
        + float(w["TAIL_LEVERAGE"]) * tail_leverage
    )
    return {
        **ranks,
        "uniqueness": uniqueness,
        "low_dup": low_dup,
        "tail_leverage": tail_leverage,
        "entropy": pct_rank(structural["entropy"]),
        "min_win_probability": pct_rank(structural["min_win_probability"]),
        "geometric_win_probability": pct_rank(structural["geometric_win_probability"]),
        "ceiling_balance": pct_rank(structural["ceiling_balance"]),
        "objective": objective.astype(np.float64),
    }


def lane_masks(structural: dict[str, np.ndarray], salaries: np.ndarray) -> list[tuple[str, np.ndarray]]:
    dog = structural["dog_count"]
    low = structural["low_salary_count"]
    premium = structural["premium_count"]
    return [
        # Extreme salary-void families are handled first by protected sibling closure.
        ("LOW_SPEND_BALANCED", (salaries <= 46_500) & (dog >= 2) & (dog <= 3)),
        ("MID_SPEND_UPSET", (salaries > 46_000) & (salaries <= 48_500) & (dog >= 3)),
        ("PREMIUM_ANCHOR_RELEASE", (salaries <= 47_000) & (premium >= 1) & (dog >= 3)),
        ("FULL_CAP_CEILING", (salaries >= 48_000) & (dog <= 2)),
        ("GLOBAL_TOP01", np.ones(len(salaries), dtype=bool)),
        ("GLOBAL_WIN", np.ones(len(salaries), dtype=bool)),
        ("GLOBAL_P99", np.ones(len(salaries), dtype=bool)),
        ("GLOBAL_LEVERAGE", np.ones(len(salaries), dtype=bool)),
    ]


def within_mask_chaos_score(mask: np.ndarray, selector: dict[str, np.ndarray]) -> np.ndarray:
    score = np.full(len(mask), -np.inf, dtype=np.float64)
    idx = np.flatnonzero(mask)
    if len(idx) == 0:
        return score
    feature_names = (
        "entropy",
        "min_win_probability",
        "geometric_win_probability",
        "ceiling_balance",
        "uniqueness",
        "tail_leverage",
        "top01_rate",
        "win_rate",
        "p99",
    )
    ranks = [pct_rank(np.asarray(selector[name])[idx]) for name in feature_names]
    score[idx] = np.mean(np.column_stack(ranks), axis=1)
    return score


def moderate_balanced_release_core_families(
    salaries: np.ndarray,
    metrics: dict[str, np.ndarray],
    structural: dict[str, np.ndarray],
    selector: dict[str, np.ndarray],
    moderate_core_mask: np.ndarray,
    moderate_core_code: np.ndarray,
) -> list[dict[str, object]]:
    """Rank anonymous salary-release core families by their weaker sibling.

    This is a structural portfolio lane. It uses only pre-lock geometry and
    shared Monte Carlo outputs. Player names and realized scores are absent.
    """
    cfg = CALIBRATION["SELECTOR"]["MODERATE_BALANCED_RELEASE_CORE_PORTFOLIO"]
    mask = (
        np.asarray(moderate_core_mask, dtype=bool)
        & (structural["dog_count"] == int(cfg["DOG_COUNT"]))
        & (structural["low_salary_count"] == int(cfg["LOW_SALARY_COUNT"]))
        & (structural["premium_count"] == int(cfg["PREMIUM_COUNT"]))
        & (structural["atp_count"] == int(cfg["ATP_COUNT"]))
        & (structural["wta_count"] == int(cfg["WTA_COUNT"]))
        & (np.asarray(salaries) >= int(cfg["LOW_SIBLING_SALARY_MIN"]))
        & (np.asarray(salaries) <= int(cfg["HIGH_SIBLING_SALARY_MAX"]))
    )
    families: list[dict[str, object]] = []
    top01 = np.asarray(metrics["top01_rate"], dtype=np.float64)
    objective = np.asarray(selector["objective"], dtype=np.float64)
    codes = np.asarray(moderate_core_code, dtype=np.uint64)
    eligible = np.flatnonzero(mask)
    if len(eligible) == 0:
        return families
    order = eligible[np.argsort(codes[eligible], kind="stable")]
    ordered_codes = codes[order]
    starts = np.r_[0, np.flatnonzero(ordered_codes[1:] != ordered_codes[:-1]) + 1]
    ends = np.r_[starts[1:], len(order)]
    salary_values = np.asarray(salaries)
    for start, end in zip(starts, ends):
        group = order[int(start):int(end)]
        code = int(ordered_codes[int(start)])
        lows = group[
            (salary_values[group] >= int(cfg["LOW_SIBLING_SALARY_MIN"]))
            & (salary_values[group] <= int(cfg["LOW_SIBLING_SALARY_MAX"]))
        ]
        highs = group[
            (salary_values[group] >= int(cfg["HIGH_SIBLING_SALARY_MIN"]))
            & (salary_values[group] <= int(cfg["HIGH_SIBLING_SALARY_MAX"]))
        ]
        best: tuple[tuple[float, float, float, int], int, int] | None = None
        for low_i in lows:
            for high_i in highs:
                if int(salary_values[high_i]) - int(salary_values[low_i]) > int(cfg["MAX_SALARY_GAP"]):
                    continue
                pair = np.asarray([low_i, high_i], dtype=np.int64)
                key = (
                    float(np.min(top01[pair])),
                    float(np.mean(top01[pair])),
                    float(np.min(objective[pair])),
                    -code,
                )
                if best is None or key > best[0]:
                    best = (key, int(low_i), int(high_i))
        if best is None:
            continue
        key, low_i, high_i = best
        families.append({
            "core_code": code,
            "low_i": low_i,
            "high_i": high_i,
            "floor_top01": key[0],
            "avg_top01": key[1],
            "min_objective": key[2],
        })
    families.sort(
        key=lambda x: (
            -float(x["floor_top01"]),
            -float(x["avg_top01"]),
            -float(x["min_objective"]),
            int(x["core_code"]),
        )
    )
    return families[: int(cfg["FAMILY_RANK_LIMIT"])]


def select_board(
    slate: Slate,
    legal: np.ndarray,
    salaries: np.ndarray,
    metrics: dict[str, np.ndarray],
    structural: dict[str, np.ndarray],
    selector: dict[str, np.ndarray],
    *,
    moderate_core_mask: np.ndarray | None = None,
    moderate_core_code: np.ndarray | None = None,
    board_size: int,
    max_player_exposure: int | None = None,
    max_overlap: int | None = None,
) -> tuple[list[int], list[str], np.ndarray]:
    if max_player_exposure is None:
        max_player_exposure = int(CALIBRATION["SELECTOR"]["MAX_PLAYER_EXPOSURE"])
    if max_overlap is None:
        max_overlap = int(CALIBRATION["SELECTOR"]["MAX_PAIRWISE_OVERLAP"])
    sibling_max_overlap = int(CALIBRATION["SELECTOR"]["SIBLING_MAX_PAIRWISE_OVERLAP"])
    selected: list[int] = []
    selected_lanes: list[str] = []
    exposure = np.zeros(len(slate.pool), dtype=np.int16)
    protected_score = np.full(len(legal), np.nan, dtype=np.float64)

    lane_score = {
        "LOW_SPEND_BALANCED": 0.30 * selector["top01_rate"] + 0.24 * selector["win_rate"] + 0.20 * selector["p99"] + 0.14 * selector["tail_leverage"] + 0.12 * selector["uniqueness"],
        "MID_SPEND_UPSET": selector["objective"],
        "PREMIUM_ANCHOR_RELEASE": 0.32 * selector["top01_rate"] + 0.22 * selector["p99"] + 0.18 * selector["tail_leverage"] + 0.16 * selector["win_rate"] + 0.12 * selector["uniqueness"],
        "FULL_CAP_CEILING": 0.36 * selector["top01_rate"] + 0.24 * selector["win_rate"] + 0.24 * selector["p99"] + 0.16 * selector["p95"],
        "GLOBAL_TOP01": selector["top01_rate"],
        "GLOBAL_WIN": selector["win_rate"],
        "GLOBAL_P99": selector["p99"],
        "GLOBAL_LEVERAGE": selector["tail_leverage"],
    }

    def feasible(i: int, *, sibling_family: str | None = None) -> bool:
        players = legal[i]
        if np.any(exposure[players] >= max_player_exposure):
            return False
        si = set(int(x) for x in players)
        for j, prior_lane in zip(selected, selected_lanes):
            allowed = max_overlap
            # Every protected under-spend family is a sibling closure surface.
            # Cross-archetype one-swap cousins may overlap by five players; this
            # prevents one protected family from blocking another before generic lanes.
            if sibling_family is not None and prior_lane.startswith("UNDERSPEND_"):
                allowed = sibling_max_overlap
            if len(si.intersection(int(x) for x in legal[j])) > allowed:
                return False
        return True

    # Balanced moderate-dog salary-release core portfolio. The two strongest
    # anonymous families by weaker-sibling shared-MC quality are direct anchors.
    # Remaining ranked families are split into breadth bands, with one lower-
    # salary representative from each band. This preserves both the robust top
    # family surface and lower-ranked calibrated uncertainty breadth.
    if moderate_core_mask is not None and moderate_core_code is not None:
        cfg = CALIBRATION["SELECTOR"]["MODERATE_BALANCED_RELEASE_CORE_PORTFOLIO"]
        families = moderate_balanced_release_core_families(
            salaries, metrics, structural, selector,
            np.asarray(moderate_core_mask, dtype=bool),
            np.asarray(moderate_core_code, dtype=np.uint64),
        )
        direct_anchors = int(cfg["DIRECT_ANCHOR_FAMILIES"])
        breadth_bands = int(cfg["BREADTH_BANDS"])
        breadth_band_size = int(cfg["BREADTH_BAND_SIZE"])

        for anchor_no, family in enumerate(families[:direct_anchors], start=1):
            pick = int(family["low_i"])
            if feasible(pick, sibling_family="UNDERSPEND_BALANCED_RELEASE_CORE"):
                selected.append(pick)
                selected_lanes.append(
                    f"UNDERSPEND_BALANCED_RELEASE_CORE_ANCHOR#{anchor_no}"
                )
                exposure[legal[pick]] += 1
                protected_score[pick] = float(selector["top01_rate"][pick])
            if len(selected) >= board_size:
                break

        breadth = families[direct_anchors:]
        for band_no in range(breadth_bands):
            band = breadth[
                band_no * breadth_band_size : (band_no + 1) * breadth_band_size
            ]
            if not band:
                break
            band = sorted(
                band,
                key=lambda x: (
                    int(salaries[int(x["low_i"])]),
                    -float(x["floor_top01"]),
                    -float(x["avg_top01"]),
                    -float(x["min_objective"]),
                    int(x["core_code"]),
                ),
            )
            pick = next(
                (int(f["low_i"]) for f in band if feasible(
                    int(f["low_i"]), sibling_family="UNDERSPEND_BALANCED_RELEASE_CORE"
                )),
                None,
            )
            if pick is not None:
                selected.append(pick)
                selected_lanes.append(
                    f"UNDERSPEND_BALANCED_RELEASE_CORE_BREADTH_BAND#{band_no + 1}"
                )
                exposure[legal[pick]] += 1
                protected_score[pick] = float(selector["top01_rate"][pick])
            if len(selected) >= board_size:
                break

    # Protected salary-void family coverage is selected before generic lanes.
    # Two WTA-heavy siblings are intentionally retained because one-swap closure
    # is the required protection against a single weak-prior miss.
    for family, mask, quota in under_spend_archetype_masks(structural, salaries):
        if len(selected) >= board_size:
            break
        family_score = within_mask_chaos_score(mask, selector)
        protected_score[mask] = family_score[mask]
        candidates = np.flatnonzero(mask)
        if family == "UNDERSPEND_BALANCED_NO_PREMIUM":
            # Static salary-geometry centrality is the primary key; the existing
            # forward-only chaos ensemble is the secondary key. No names, actual
            # points, contest ranks, or post-lock ownership enter the ordering.
            target_salary = int(
                CALIBRATION["SELECTOR"]["UNDERSPEND_ARCHETYPES"]
                ["BALANCED_NO_PREMIUM"]["TARGET_SALARY"]
            )
            order = candidates[
                np.lexsort(
                    (
                        -family_score[candidates],
                        np.abs(salaries[candidates] - target_salary),
                    )
                )
            ]
        else:
            order = candidates[np.argsort(-family_score[candidates], kind="stable")]
        picked = 0
        for i in order:
            i = int(i)
            if not feasible(i, sibling_family=family):
                continue
            selected.append(i)
            selected_lanes.append(f"{family}#{picked + 1}")
            exposure[legal[i]] += 1
            picked += 1
            if picked >= quota or len(selected) >= board_size:
                break

    for lane, mask in lane_masks(structural, salaries):
        if len(selected) >= board_size:
            break
        candidates = np.flatnonzero(mask)
        if len(candidates) == 0:
            continue
        order = candidates[np.argsort(-lane_score[lane][candidates], kind="stable")]
        pick = next((int(i) for i in order if i not in selected and feasible(int(i))), None)
        if pick is not None:
            selected.append(pick)
            selected_lanes.append(lane)
            exposure[legal[pick]] += 1

    if len(selected) < board_size:
        order = np.argsort(-selector["objective"], kind="stable")
        for i in order:
            i = int(i)
            if i in selected or not feasible(i):
                continue
            selected.append(i)
            selected_lanes.append("GLOBAL_OBJECTIVE")
            exposure[legal[i]] += 1
            if len(selected) >= board_size:
                break
    return selected, selected_lanes, protected_score


def run_engine(
    *,
    pool_path: Path,
    matchup_path: Path,
    field_size: int,
    execution_id: str,
    out_dir: Path,
    seed: int,
    availability_receipt: Path,
    board_size: int = 10,
    phase1_trials: int = 50_000,
    base_sim_trials: int = 10_000,
) -> dict[str, object]:
    t0 = time.time()
    out_dir.mkdir(parents=True, exist_ok=True)
    stage_path = out_dir / "runtime_stage.log"
    stage_path.write_text("", encoding="utf-8")
    def stage(name: str, **values: object) -> None:
        payload = {"stage": name, "elapsed_seconds": round(time.time() - t0, 3), **values}
        with stage_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, sort_keys=True) + "\n")
    stage("START", engine_id=ENGINE_ID, execution_id=str(execution_id))
    handoff_contract, handoff_contract_sha256 = load_handoff_contract()
    handoff_rules = handoff_contract["GLOBAL_RULES"]
    if base_sim_trials < int(handoff_rules["MINIMUM_BASE_SIM_TRIALS"]):
        raise EngineError("BASE_SIM_BELOW_GLOBAL_HANDOFF_FLOOR")
    if BUBBLE_BATCH_TRIALS != int(handoff_rules["BUBBLE_BATCH_TRIALS"]):
        raise EngineError("BUBBLE_BATCH_CONTRACT_MISMATCH")
    availability_gate = validate_prebuild_availability_receipt(
        availability_receipt, sport="TENNIS", mode="CLASSIC", pool_path=pool_path,
        execution_id=execution_id, field_size=field_size,
    )
    slate = load_slate(pool_path, matchup_path, availability_gate)
    stage("SLATE_LOADED", active_pool=len(slate.pool), matches=len(slate.pair_indices))
    legal, salaries = enumerate_cap_legal_lineups(slate, out_dir / "work")
    stage("CAP_LEGAL_SCAN_COMPLETE", lineups=len(legal))

    phase1 = simulate_players(slate, trials=phase1_trials, seed=seed, metric_namespace="PHASE1_CALIBRATION")
    stage("PHASE1_CALIBRATION_COMPLETE", trials=phase1_trials)
    # Complete legal scan precedes calibration-qualified birth. Phase 2 contains only qualified lineups.
    cap_legal_scanned = len(legal)
    structural_all = lineup_structural_features(slate, legal, salaries, phase1)
    stage("STRUCTURAL_FEATURES_COMPLETE")
    proxy_all = phase2_calibration_proxies(slate, legal, salaries, phase1, structural_all)
    stage("PHASE2_PROXY_COMPLETE")
    candidate_idx, moderate_core_idx = phase3_candidate_indices(
        slate, legal, salaries, structural_all, proxy_all, phase1
    )
    phase2_built = len(candidate_idx)
    stage("PHASE2_BIRTH_COMPLETE", phase2_built=phase2_built, moderate_core_births=len(moderate_core_idx))
    phase2_hash = sha256_json({"candidate_indices": candidate_idx.tolist(), "candidate_salaries": np.asarray(salaries[candidate_idx]).tolist()})
    candidate_lineups = legal[candidate_idx]
    candidate_salaries = salaries[candidate_idx]
    structural = {k: v[candidate_idx] for k, v in structural_all.items()}
    family_signature = anonymous_family_signatures(structural, candidate_salaries)
    moderate_flag_set = set(int(i) for i in moderate_core_idx)
    moderate_core_mask_local = np.asarray(
        [int(i) in moderate_flag_set for i in candidate_idx], dtype=bool
    )
    candidate_core_code = canonical_core_codes(slate, candidate_lineups, phase1)
    stage("CANONICAL_CORE_CODES_COMPLETE")

    fake_idx, player_own, lineup_own_product_all, lineup_dup_count_all = build_fake_field(
        slate, legal, salaries, phase1, field_size=field_size, seed=seed + 17
    )
    lineup_own_product = lineup_own_product_all[candidate_idx]
    lineup_dup_count = lineup_dup_count_all[candidate_idx]
    stage("FAKE_FIELD_COMPLETE", fake_field_lineups=len(fake_idx))

    base_scores = phase1.scores[:base_sim_trials]
    threshold, max_field = field_thresholds(base_scores, legal, fake_idx)
    stage("FIELD_THRESHOLDS_COMPLETE")
    metrics = score_lineup_metrics(base_scores, candidate_lineups, thresholds=threshold, max_field=max_field)
    metrics["metric_hash"] = phase1.metric_hash
    stage("BASE_SIM_SCORING_COMPLETE", candidate_lineups=len(candidate_lineups), base_trials=base_sim_trials)

    metrics, bubble_extra, bubble_count, bubble_hash = adaptive_bubble(
        slate,
        candidate_lineups,
        legal,
        fake_idx,
        metrics,
        seed=seed + 97,
        base_trials=base_sim_trials,
    )
    stage("ADAPTIVE_BUBBLE_COMPLETE", bubble_extra_trials=bubble_extra, bubble_lineups=bubble_count)
    selector = selector_objectives(metrics, structural, lineup_own_product, lineup_dup_count)
    stage("SELECTOR_METRICS_COMPLETE")
    validate_prebuild_availability_receipt(
        availability_receipt, sport="TENNIS", mode="CLASSIC", pool_path=pool_path,
        execution_id=execution_id, field_size=field_size, final_selector_recheck=True,
    )

    handoff_survivors = len(candidate_lineups)
    selector_reviewed = len(candidate_lineups)
    selected_local, selected_lanes, protected_score = select_board(
        slate,
        candidate_lineups,
        candidate_salaries,
        metrics,
        structural,
        selector,
        moderate_core_mask=moderate_core_mask_local,
        moderate_core_code=candidate_core_code,
        board_size=board_size,
    )
    selected = [int(candidate_idx[i]) for i in selected_local]
    stage("BOARD_SELECTION_COMPLETE", final_board_size=len(selected), lanes=selected_lanes)

    rows: list[dict[str, object]] = []
    names = slate.pool["PLAYER"].astype(str).tolist()
    selected_local_map = {int(global_i): local_i for local_i, global_i in enumerate(candidate_idx)}
    for rank, (i, lane) in enumerate(zip(selected, selected_lanes), start=1):
        local_i = selected_local_map[int(i)]
        players = legal[i]
        row: dict[str, object] = {
            "BOARD_RANK": rank,
            "LINEUP_ID": hashlib.sha256("|".join(sorted(slate.player_ids[p] for p in players)).encode()).hexdigest()[:16],
            "LANE": lane,
            "SALARY": int(salaries[i]),
            "SALARY_LEFT": int(SALARY_CAP - salaries[i]),
            "DOG_COUNT": int(structural["dog_count"][local_i]),
            "LOW_SALARY_COUNT": int(structural["low_salary_count"][local_i]),
            "MC_TOP_0_1_RATE": float(metrics["top01_rate"][local_i]),
            "MC_WIN_RATE": float(metrics["win_rate"][local_i]),
            "P95": float(metrics["p95"][local_i]),
            "P99": float(metrics["p99"][local_i]),
            "OWNERSHIP_PRODUCT_PROXY": float(lineup_own_product[local_i]),
            "DUPLICATION_COUNT_PROXY": int(lineup_dup_count[local_i]),
            "SELECTOR_SCORE": float(selector["objective"][local_i]),
            "UNDERSPEND_FAMILY_SCORE": None if np.isnan(protected_score[local_i]) else float(protected_score[local_i]),
        }
        for slot, p in enumerate(players, start=1):
            row[f"P{slot}"] = names[p]
            row[f"P{slot}_ID"] = slate.player_ids[p]
        rows.append(row)

    board_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_FINAL_BOARD.csv"
    pd.DataFrame(rows).to_csv(board_path, index=False)
    phase2_manifest_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_PHASE2_MANIFEST.csv"
    manifest = pd.DataFrame({
        "LINEUP_INDEX": candidate_idx,
        "SALARY": np.asarray(salaries[candidate_idx]),
        "SALARY_LEFT": structural_all["salary_left"][candidate_idx],
        "DOG_COUNT": structural_all["dog_count"][candidate_idx],
        "LOW_SALARY_COUNT": structural_all["low_salary_count"][candidate_idx],
        "PREMIUM_COUNT": structural_all["premium_count"][candidate_idx],
        "ATP_COUNT": structural_all["atp_count"][candidate_idx],
        "WTA_COUNT": structural_all["wta_count"][candidate_idx],
        "FAMILY_SIGNATURE": family_signature,
        "PHASE2_PROXY_P99": proxy_all["p99"][candidate_idx],
        "PHASE2_PROXY_JOINT_WIN": proxy_all["joint_win"][candidate_idx],
        "MODERATE_DOG_MIXED_CORE_CLOSURE": moderate_core_mask_local.astype(np.int8),
        "CANONICAL_CORE_CODE": candidate_core_code,
        "HANDOFF_SURVIVOR": np.ones(len(candidate_idx), dtype=np.int8),
        "TOP_0_1_RATE": metrics["top01_rate"],
        "WIN_RATE": metrics["win_rate"],
        "SELECTOR_SCORE": selector["objective"],
        "PLAYER_IDS": ["|".join(slate.player_ids[p] for p in lineup) for lineup in candidate_lineups],
    })
    manifest.to_csv(phase2_manifest_path, index=False)

    receipt: dict[str, object] = {
        "RUN_STATE": "TOOL_PROVEN_EXECUTED",
        "EXECUTION_STATE": "COMPLETE",
        "ENGINE_ID": ENGINE_ID,
        "ENGINE_VERSION": ENGINE_VERSION,
        "PREBUILD_AVAILABILITY_GATE": availability_gate.to_receipt(),
        "PRESELECTOR_EXECUTION": "CODE_ONLY",
        "AI_ALLOWED_STAGE": "FINAL_SELECTOR_ONLY",
        "MANUAL_OUT_OVERRIDE_USED": False,
        "SYSTEM_PLATFORM": "DK",
        "SPORT_CONTEXT": "TENNIS",
        "MODE_STRUCTURE": "CLASSIC",
        "EXECUTION_ID": str(execution_id),
        "EXECUTION_SEED": int(seed),
        "SEED_POLICY": "NUMERIC_EXECUTION_ID_UNLESS_EXPLICIT_OVERRIDE",
        "POOL_SHA256": slate.pool_sha256,
        "MATCHUP_SHA256": slate.matchup_sha256,
        "ACTIVE_POOL": len(slate.pool),
        "OUT_PURGE": 0,
        "MATCHES_RECONCILED": len(slate.pair_indices),
        "SALARY_CAP": SALARY_CAP,
        "HARD_SALARY_FLOOR": None,
        "CAP_LEGAL_SCANNED": cap_legal_scanned,
        "PHASE1_MC_TRIALS": phase1_trials,
        "PHASE1_CALIBRATION_HASH": phase1.metric_hash,
        "CALIBRATION_ASSET": CALIBRATION_FILE.name,
        "CALIBRATION_ASSET_SHA256": CALIBRATION_SHA256,
        "GLOBAL_PHASE2_DOCTRINE_ID": GLOBAL_PHASE2_DOCTRINE["DOCTRINE_ID"],
        "GLOBAL_PHASE2_DOCTRINE_SHA256": GLOBAL_PHASE2_DOCTRINE_SHA256,
        "DOCTRINE_ID": DOCTRINE["DOCTRINE_ID"],
        "DOCTRINE_SHA256": DOCTRINE_SHA256,
        "FORENSIC_RECONSTRUCTION_MODULE": FORENSIC_MODULE_FILE.name,
        "FORENSIC_RECONSTRUCTION_MODULE_SHA256": FORENSIC_MODULE_SHA256,
        "POSTLOCK_AUTONOMOUS_RECOVERY_REQUIRED": True,
        "POSTLOCK_RECOVERY_FORWARD_SELECTOR_INFLUENCE": False,
        "GLOBAL_HANDOFF_PATCH": handoff_contract["PATCH_ID"],
        "GLOBAL_HANDOFF_PATCH_SHA256": handoff_contract_sha256,
        "PHASE2_BUILT_LINEUPS": phase2_built,
        "PHASE2_BUILD_MODE": "CALIBRATION_FIRST_QUALIFIED_BIRTH_AFTER_COMPLETE_LEGAL_SCAN",
        "PHASE3_CANDIDATE_LINEUPS": len(candidate_lineups),
        "POST_PHASE2_MUTATION_COUNT": 0,
        "PHASE2_PHASE3_PARITY": "PASS" if phase2_built == len(candidate_lineups) else "FAIL",
        "MODERATE_DOG_MIXED_CORE_CLOSURE_BIRTHS": len(moderate_core_idx),
        "MODERATE_BALANCED_RELEASE_CORE_PORTFOLIO_SLOTS": sum(
            1 for lane in selected_lanes if lane.startswith("UNDERSPEND_BALANCED_RELEASE_CORE_")
        ),
        "MODERATE_BALANCED_RELEASE_CORE_DIRECT_ANCHOR_SLOTS": sum(
            1 for lane in selected_lanes if lane.startswith("UNDERSPEND_BALANCED_RELEASE_CORE_ANCHOR")
        ),
        "MODERATE_BALANCED_RELEASE_CORE_BREADTH_SLOTS": sum(
            1 for lane in selected_lanes if lane.startswith("UNDERSPEND_BALANCED_RELEASE_CORE_BREADTH_BAND")
        ),
        "COMPLETE_CAP_LEGAL_SCAN": "PASS",
        "PHASE2_MANIFEST_HASH": phase2_hash,
        "FAKE_FIELD_LINEUPS": len(fake_idx),
        "BASE_SIM_TRIALS": base_sim_trials,
        "BUBBLE_EXTRA_TRIALS_TOTAL": bubble_extra,
        "BUBBLE_LINEUPS_UNRESOLVED": 0,
        "BUBBLE_LINEUPS_REVIEWED": bubble_count,
        "BUBBLE_HASH": bubble_hash,
        "HANDOFF_SURVIVORS": handoff_survivors,
        "PHASE2_HANDOFF_PARITY": "PASS" if phase2_built == handoff_survivors else "FAIL",
        "SELECTOR_REVIEWED_LINEUPS": selector_reviewed,
        "PHASE2_SELECTOR_REVIEW_PARITY": "PASS" if phase2_built == selector_reviewed else "FAIL",
        "HANDOFF_SELECTOR_PARITY": "PASS" if handoff_survivors == selector_reviewed else "FAIL",
        "FINAL_BOARD_SIZE": len(rows),
        "FILLERS_USED": False,
        "GENERIC_OBJECTIVE_LANE_NAME": "GLOBAL_OBJECTIVE",
        "ANONYMOUS_FAMILY_SIGNATURES_WRITTEN": len(family_signature),
        "RANK_ALL_USED": False,
        "POSTLOCK_RESULTS_USED_IN_FORWARD_ENGINE": False,
        "PLAYER_NAMES_USED_BY_SELECTOR": False,
        "CONTEST_WINNER_GEOMETRY_USED_AS_PERFECT_PROXY": False,
        "UNDERSPEND_RESERVED_SLOTS_REQUIRED": int(CALIBRATION["SELECTOR"]["UNDERSPEND_RESERVED_SLOTS"]),
        "BALANCED_NO_PREMIUM_CLOSURE_REQUIRED": True,
        "UNDERSPEND_RESERVED_SLOTS_FILLED": sum(1 for lane in selected_lanes if lane.startswith("UNDERSPEND_")),
        "UNDERSPEND_SIBLING_CLOSURE": "PASS" if sum(1 for lane in selected_lanes if lane.startswith("UNDERSPEND_")) >= int(CALIBRATION["SELECTOR"]["UNDERSPEND_RESERVED_SLOTS"]) else "FAIL",
        "BOARD_SHA256": sha256_file(board_path),
        "PHASE2_MANIFEST_SHA256": sha256_file(phase2_manifest_path),
        "RUNTIME_SECONDS": round(time.time() - t0, 3),
    }
    receipt_path = out_dir / f"DK_TENNIS_CLASSIC_{execution_id}_FINAL_RECEIPT.json"
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    stage("COMPLETE", final_board_size=len(rows), receipt_path=str(receipt_path))
    return {"receipt": receipt, "board_path": str(board_path), "phase2_manifest_path": str(phase2_manifest_path)}


def resolve_execution_seed(execution_id: str, explicit_seed: int | None) -> int:
    if explicit_seed is not None:
        return int(explicit_seed)
    token = str(execution_id).strip()
    if token.isdigit():
        return int(token)
    return int.from_bytes(hashlib.sha256(token.encode("utf-8")).digest()[:4], "big") & 0x7FFFFFFF


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--pool", required=True)
    p.add_argument("--matchups", required=True)
    p.add_argument("--field-size", type=int, required=True)
    p.add_argument("--execution-id", required=True)
    p.add_argument("--out-dir", required=True)
    p.add_argument("--availability-receipt", required=True)
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--board-size", type=int, default=10)
    p.add_argument("--phase1-trials", type=int, default=50_000)
    p.add_argument("--base-sim-trials", type=int, default=10_000)
    return p.parse_args()


def main() -> int:
    args = parse_args()
    resolved_seed = resolve_execution_seed(str(args.execution_id), args.seed)
    result = run_engine(
        pool_path=Path(args.pool),
        matchup_path=Path(args.matchups),
        field_size=args.field_size,
        execution_id=args.execution_id,
        out_dir=Path(args.out_dir),
        seed=resolved_seed,
        availability_receipt=Path(args.availability_receipt),
        board_size=args.board_size,
        phase1_trials=args.phase1_trials,
        base_sim_trials=args.base_sim_trials,
    )
    print(json.dumps(result["receipt"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
