from __future__ import annotations
import argparse, json, time
from pathlib import Path
import numpy as np
import pandas as pd
from engines.tennis import tennis_classic_raw_pool_runtime_v2 as core
from engines.common import apex_pipeline_identity_ledger_v1 as pipeline_ledger

PATCH_ID='TENNIS_CLASSIC_SEALED_PHASE2_EXECUTION_WINDOW_RESUME_v1'

def _rows_from_ledger(path: Path, slate: core.Slate, roster_size: int):
    df=pd.read_csv(path,dtype=str,keep_default_na=False)
    if len(df)==0 or 'LINEUP_ID' not in df: raise core.EngineError('RUN_INVALID:TENNIS_PHASE2_RESUME_LEDGER_EMPTY')
    mp={str(pid):i for i,pid in enumerate(slate.player_ids)}
    cols=[f'P{i}_ID' for i in range(1,roster_size+1)]
    if any(c not in df for c in cols): raise core.EngineError('RUN_INVALID:TENNIS_PHASE2_RESUME_LEDGER_SCHEMA')
    rows=np.empty((len(df),roster_size),dtype=np.int16)
    for j,c in enumerate(cols):
        try: rows[:,j]=np.asarray([mp[x] for x in df[c].tolist()],dtype=np.int16)
        except KeyError as exc: raise core.EngineError(f'RUN_INVALID:TENNIS_PHASE2_RESUME_PLAYER_ID_MISMATCH:{exc}') from exc
    salary=df['SALARY'].astype(np.int32).to_numpy() if 'SALARY' in df else slate.salaries[rows].sum(axis=1).astype(np.int32)
    # Verify canonical IDs from current slate against sealed parent identities.
    calc=[pipeline_ledger.canonical_lineup_id(core._lineup_player_ids(r,slate), ['UTIL']*roster_size) for r in rows]
    if calc != df['LINEUP_ID'].tolist(): raise core.EngineError('IDENTITY_HASH_MISMATCH:PHASE2_RESUME_CURRENT_SLATE')
    return rows,salary

def run(*, pool:Path, field_size:int, execution_id:str, out_dir:Path, phase2_ledger:Path, matchups:Path|None, availability_receipt:Path|None, base_sim_trials:int=10000, board_size:int|None=None):
    out_dir.mkdir(parents=True,exist_ok=True)
    t0=time.time()
    slate=core.load_slate(pool,matchup_path=matchups,availability_receipt=availability_receipt,execution_id=execution_id,field_size=field_size)
    cfg=core.RuntimeConfig(execution_id=str(execution_id),field_size=int(field_size),seed=core.resolve_seed(str(execution_id),None),roster_size=core.resolve_roster_size(len(slate.player_names),'auto'),phase1_trials=int(core.CALIBRATION['PHASE1']['DEFAULT_TRIALS']),base_sim_trials=int(base_sim_trials),board_size=int(board_size or core.CALIBRATION['SELECTOR']['BOARD_SIZE']))
    phase2_seal=pipeline_ledger.require_original_sealed_ledger(phase2_ledger,missing_code='RUN_INVALID:TENNIS_PHASE2_RESUME_LEDGER_MISSING')
    phase2_rows,phase2_salary=_rows_from_ledger(phase2_ledger,slate,cfg.roster_size)
    if phase2_seal.rows != len(phase2_rows): raise core.EngineError('IDENTITY_HASH_MISMATCH:PHASE2_RESUME_ROW_COUNT')
    phase1=core.simulate_phase1(slate,trials=cfg.phase1_trials,seed=cfg.seed)
    struct=core.structural_features(slate,phase1,phase2_rows,phase2_salary)
    fake_idx,player_own,lineup_own,dup=core.build_fake_field(slate,phase1,phase2_rows,phase2_salary,field_size=cfg.field_size,seed=cfg.seed+31)
    fake_rows=phase2_rows[fake_idx]; base_scores=phase1.player_scores[:cfg.base_sim_trials]
    threshold,max_field=core.field_thresholds(base_scores,fake_rows,quantile=float(core.CALIBRATION['FAKE_FIELD']['TOP_0_1_QUANTILE']))
    metrics=core.score_lineups(base_scores,phase2_rows,threshold=threshold,max_field=max_field)
    metrics,bubble_extra,bubble_reviewed,bubble_unresolved,bubble_hash=core.adaptive_bubble(phase1,phase2_rows,fake_rows,metrics,base_trials=cfg.base_sim_trials,config=cfg)
    handoff_path=out_dir/f'DK_TENNIS_CLASSIC_{execution_id}_HANDOFF_SNAPSHOT.csv'
    handoff_seal=pipeline_ledger.reseal_stage_from_parent_ledger(parent_path=phase2_ledger,stage='HANDOFF',path=handoff_path,extra_columns={'SALARY':phase2_salary.tolist(),'TOP_0_1_RATE':metrics['top01_rate'].tolist(),'WIN_RATE':metrics['win_rate'].tolist(),'P95':metrics['p95'].tolist(),'P99':metrics['p99'].tolist(),'CVAR99':metrics['cvar99'].tolist()})
    final_availability='TEST_MODE_BYPASS'
    if availability_receipt:
        core.require_prebuild_roster_check(availability_receipt,sport=core.SPORT,mode=core.MODE,pool_path=pool,execution_id=execution_id,field_size=field_size,final_selector_recheck=True); final_availability='PASS'
    order,selector,strict=core.selector_full_order(slate,phase1,phase2_rows,phase2_salary,struct,metrics,lineup_own,dup,field_size=int(field_size))
    rank_pos=np.empty(len(order),dtype=np.int32); rank_pos[order]=np.arange(1,len(order)+1)
    selector_path=out_dir/f'DK_TENNIS_CLASSIC_{execution_id}_SELECTOR_REVIEW_LEDGER.csv'
    selector_seal=pipeline_ledger.reseal_stage_from_parent_ledger(parent_path=phase2_ledger,stage='SELECTOR_REVIEW',path=selector_path,extra_columns={'FULL_ORDER_RANK':rank_pos.tolist(),'STRICT_ELIGIBLE':strict.astype(np.int8).tolist(),'REPAIR_ELIGIBLE':selector['repair_eligible'].astype(np.int8).tolist(),'REPAIR_SCORE':selector['repair_score'].tolist(),'SELECTOR_SCORE':selector['objective'].tolist()})
    parity_path=out_dir/f'DK_TENNIS_CLASSIC_{execution_id}_PIPELINE_PARITY_RECEIPT.json'
    parity=pipeline_ledger.verify_pipeline_parity(phase2=phase2_seal,handoff=handoff_seal,selector=selector_seal,receipt_path=parity_path)
    selected,reasons=core.select_board(phase2_rows,order,selector,strict,cfg)
    board=[]
    for rank,(idx,reason) in enumerate(zip(selected,reasons),1):
        i=int(idx); row=phase2_rows[i]
        rec={'BOARD_RANK':rank,'LINEUP_ID':core._lineup_id(row,slate),'SELECTOR_REASON':reason,'SALARY':int(phase2_salary[i]),'SALARY_LEFT':int(core.SALARY_CAP-phase2_salary[i]),'MC_TOP_0_1_RATE':float(metrics['top01_rate'][i]),'MC_WIN_RATE':float(metrics['win_rate'][i]),'P95':float(metrics['p95'][i]),'P99':float(metrics['p99'][i]),'CVAR99':float(metrics['cvar99'][i]),'SELECTOR_SCORE':float(selector['objective'][i])}
        for slot,p in enumerate(row,1): rec[f'P{slot}']=slate.player_names[int(p)]; rec[f'P{slot}_ID']=slate.player_ids[int(p)]
        board.append(rec)
    board_path=out_dir/f'DK_TENNIS_CLASSIC_{execution_id}_FINAL_BOARD.csv'; pd.DataFrame(board).to_csv(board_path,index=False)
    receipt={'GLOBAL_STATE_VERSION':core.ACTIVE_STATE_VERSION,'PATCH_ID':PATCH_ID,'ENGINE_ID':core.ENGINE_ID,'PLATFORM':core.PLATFORM,'SPORT':core.SPORT,'MODE':core.MODE,'EXECUTION_ID':str(execution_id),'POOL_SHA256':slate.pool_sha256,'ACTIVE_POOL':len(slate.player_names),'OUT_PURGE':slate.out_purge,'PHASE2_RESUME':'PASS_SEALED_IDENTITY_LEDGER','PHASE2_BUILT_LINEUPS':len(phase2_rows),'CAP_LEGAL_SCANNED':int(core._count_legal_6(slate.salaries,cfg.salary_cap) if cfg.roster_size==6 else core._count_legal_3(slate.salaries,cfg.salary_cap)),'PHASE1_MC_TRIALS':cfg.phase1_trials,'BASE_SIM_TRIALS':cfg.base_sim_trials,'FAKE_FIELD_LINEUPS':len(fake_idx),'BUBBLE_EXTRA_TRIALS_TOTAL':bubble_extra,'BUBBLE_LINEUPS_REVIEWED':bubble_reviewed,'BUBBLE_LINEUPS_UNRESOLVED':bubble_unresolved,'HANDOFF_SURVIVORS':len(phase2_rows),'SELECTOR_REVIEWED_LINEUPS':len(phase2_rows),'STRICT_ELIGIBLE_LINEUPS':int(strict.sum()),'FINAL_SELECTOR_AVAILABILITY_RECHECK':final_availability,'PIPELINE_IDENTITY_PARITY':parity['IDENTITY_PARITY'],'FINAL_BOARD_SIZE':len(board),'FILLERS_USED':False,'RANK_ALL_USED':False,'BOARD_SHA256':core.sha256_file(board_path),'PHASE2_IDENTITY_LEDGER_SHA256':phase2_seal.file_sha256,'HANDOFF_SNAPSHOT_SHA256':handoff_seal.file_sha256,'SELECTOR_REVIEW_LEDGER_SHA256':selector_seal.file_sha256,'EXACT_TAIL_KERNEL_RUNTIME_SHA256':core.EXACT_TAIL_KERNEL_RUNTIME_SHA256,'ELAPSED_SECONDS':round(time.time()-t0,3),'RUN_STATE':'BOARD_READY','EXECUTION_STATE':'TOOL_PROVEN_EXECUTED' if board else 'VALID_EMPTY_STRICT_BOARD'}
    receipt_path=out_dir/f'DK_TENNIS_CLASSIC_{execution_id}_FINAL_RECEIPT.json'; receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'RUN_STATE':'BOARD_READY','EXECUTION_STATE':receipt['EXECUTION_STATE'],'FINAL_BOARD_SIZE':len(board),'FINAL_BOARD':board,'RECEIPT':receipt},indent=2),flush=True)
    return receipt

def main():
    p=argparse.ArgumentParser(); p.add_argument('--pool',type=Path,required=True); p.add_argument('--field-size',type=int,required=True); p.add_argument('--execution-id',required=True); p.add_argument('--out-dir',type=Path,required=True); p.add_argument('--phase2-ledger',type=Path,required=True); p.add_argument('--matchups',type=Path); p.add_argument('--availability-receipt',type=Path); p.add_argument('--base-sim-trials',type=int,default=10000); p.add_argument('--board-size',type=int)
    a=p.parse_args(); run(pool=a.pool,field_size=a.field_size,execution_id=a.execution_id,out_dir=a.out_dir,phase2_ledger=a.phase2_ledger,matchups=a.matchups,availability_receipt=a.availability_receipt,base_sim_trials=a.base_sim_trials,board_size=a.board_size)
if __name__=='__main__': main()
