from __future__ import annotations
import argparse, hashlib, json, re, zipfile, tempfile
from pathlib import Path
import numpy as np
import pandas as pd
from numba import njit

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for c in iter(lambda:f.read(1<<20),b""): h.update(c)
    return h.hexdigest()

def parse_lineup(value: object) -> list[str]:
    return [x.strip() for x in re.split(r"\s+P\s+", re.sub(r"^P\s+", "", str(value))) if x.strip()]

def load_contest(path: Path) -> pd.DataFrame:
    if path.suffix.lower() != ".zip": return pd.read_csv(path)
    with zipfile.ZipFile(path) as zf:
        names=[n for n in zf.namelist() if n.lower().endswith(".csv")]
        if len(names)!=1: raise RuntimeError(f"CONTEST_ZIP_CSV_COUNT={len(names)}")
        with zf.open(names[0]) as f: return pd.read_csv(f)

@njit(cache=False)
def perfect_scan(sal, pts):
    n=len(sal); best=-1e100; bs=0; bi=np.zeros(6,np.int16); count=0
    for a in range(n-5):
      for b in range(a+1,n-4):
       for c in range(b+1,n-3):
        for d in range(c+1,n-2):
         for e in range(d+1,n-1):
          s5=sal[a]+sal[b]+sal[c]+sal[d]+sal[e]
          for f in range(e+1,n):
           ss=s5+sal[f]
           if ss>50000: continue
           count+=1; sc=pts[a]+pts[b]+pts[c]+pts[d]+pts[e]+pts[f]
           if sc>best: best=sc; bs=ss; bi[:]=np.array([a,b,c,d,e,f],np.int16)
    return count,best,bs,bi

def find_lineage(path: Path, target: set[str]):
    for chunk in pd.read_csv(path,chunksize=50000):
        mask=chunk.PLAYER_IDS.fillna("").map(lambda x:set(str(x).split("|"))==target)
        if mask.any(): return chunk[mask].iloc[0].to_dict()
    return None

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--pool",required=True,type=Path); ap.add_argument("--contest",required=True,type=Path)
    ap.add_argument("--original-board",required=True,type=Path); ap.add_argument("--original-manifest",required=True,type=Path)
    ap.add_argument("--repaired-board",required=True,type=Path); ap.add_argument("--repaired-manifest",required=True,type=Path)
    ap.add_argument("--out-dir",required=True,type=Path); ap.add_argument("--execution-id",required=True)
    args=ap.parse_args(); args.out_dir.mkdir(parents=True,exist_ok=True)
    pool=pd.read_csv(args.pool); cont=load_contest(args.contest)
    truth=cont[["Player","FPTS"]].dropna(subset=["Player"]).drop_duplicates("Player").copy(); truth["FPTS"]=pd.to_numeric(truth.FPTS,errors="coerce")
    actual_key=dict(zip(truth.Player.astype(str).str.casefold(),truth.FPTS.astype(float)))
    names=pool.PLAYER.astype(str).tolist(); name_by_key={n.casefold():n for n in names}
    missing=set(name_by_key)-set(actual_key)
    if missing: raise RuntimeError(f"CONTEST_PLAYER_TRUTH_MISSING={sorted(missing)}")
    actual={n:float(actual_key[n.casefold()]) for n in names}
    sal=pool.SAL.to_numpy(np.int32); pts=np.array([actual[n] for n in names],np.float64)
    count,best,bs,bi=perfect_scan(sal,pts); perfect_names=[names[int(i)] for i in bi]; perfect_set=set(perfect_names)
    field=cont.dropna(subset=["Lineup"]).copy(); field["PARSED"]=field.Lineup.map(lambda s:[name_by_key.get(x.casefold(),x) for x in parse_lineup(s)])
    winner=field.sort_values(["Points","Rank"],ascending=[False,True]).iloc[0]; winner_names=winner.PARSED; winner_set=set(winner_names)
    field_points=pd.to_numeric(cont.Points,errors="coerce").fillna(0).to_numpy(float)
    virtual_rank=lambda score:int(1+np.sum(field_points>score+1e-7))
    def eval_board(path,label):
      b=pd.read_csv(path); rows=[]
      for _,r in b.iterrows():
       ns=[str(r[f"P{i}"]) for i in range(1,7)]; score=float(sum(actual[n] for n in ns)); rank=virtual_rank(score)
       rows.append({"SOURCE":label,"BOARD_RANK":int(r.BOARD_RANK),"LANE":str(r.LANE),"SALARY":int(r.SALARY),"ACTUAL_FPTS":round(score,5),"VIRTUAL_CONTEST_RANK":rank,"IS_EXACT_PERFECT":set(ns)==perfect_set,"IS_CONTEST_WINNER":set(ns)==winner_set,"PLAYERS":" | ".join(ns)})
      return pd.DataFrame(rows)
    orig=eval_board(args.original_board,"ORIGINAL_PRODUCTION"); new=eval_board(args.repaired_board,"REPAIRED_BLIND_REPLAY")
    pd.concat([orig,new],ignore_index=True).to_csv(args.out_dir/f"DK_TENNIS_CLASSIC_{args.execution_id}_POSTLOCK_BOARD_RANKS.csv",index=False)
    ids={n:hashlib.sha256(f"{n}|{int(pool.loc[pool.PLAYER==n,'SAL'].iloc[0])}".encode()).hexdigest()[:16] for n in names}
    op=find_lineage(args.original_manifest,{ids[n] for n in perfect_names}); ow=find_lineage(args.original_manifest,{ids[n] for n in winner_names})
    npf=find_lineage(args.repaired_manifest,{ids[n] for n in perfect_names}); nw=find_lineage(args.repaired_manifest,{ids[n] for n in winner_names})
    receipt={
      "EVALUATOR":"TENNIS_CLASSIC_POSTLOCK_EVALUATOR_v4","POSTLOCK_ONLY":True,"ACTUAL_RESULTS_USED_BY_FORWARD_ENGINE":False,
      "CONTEST_FILE_SHA256":sha256_file(args.contest),"POOL_SHA256":sha256_file(args.pool),"CONTEST_ROWS":int(len(cont)),"POPULATED_FIELD_LINEUPS":int(len(field)),
      "CAP_LEGAL_SCANNED":int(count),"OPPONENT_COLLISION_PROHIBITED":False,"EXACT_PERFECT_PLAYERS":perfect_names,"EXACT_PERFECT_SALARY":int(bs),
      "EXACT_PERFECT_ACTUAL_FPTS":round(float(best),5),"EXACT_PERFECT_VIRTUAL_RANK":virtual_rank(float(best)),"CONTEST_WINNER_PLAYERS":winner_names,
      "CONTEST_WINNER_ACTUAL_FPTS":round(float(winner.Points),5),"CONTEST_WINNER_RECORDED_RANK":int(winner.Rank),
      "ORIGINAL_PERFECT_PHASE2_BORN":op is not None,"ORIGINAL_WINNER_PHASE2_BORN":ow is not None,"ORIGINAL_BEST_BOARD_CONTEST_RANK":int(orig.VIRTUAL_CONTEST_RANK.min()),
      "REPAIRED_PERFECT_PHASE2_BORN":npf is not None,"REPAIRED_PERFECT_HANDOFF":npf is not None and int(npf.get("HANDOFF_SURVIVOR",0))==1,
      "REPAIRED_PERFECT_SELECTOR_REVIEW":npf is not None,"REPAIRED_PERFECT_FINAL_BOARD":bool(new.IS_EXACT_PERFECT.any()),
      "REPAIRED_PERFECT_BOARD_RANK":int(new.loc[new.IS_EXACT_PERFECT,"BOARD_RANK"].iloc[0]) if new.IS_EXACT_PERFECT.any() else None,
      "REPAIRED_WINNER_PHASE2_BORN":nw is not None,"REPAIRED_WINNER_HANDOFF":nw is not None and int(nw.get("HANDOFF_SURVIVOR",0))==1,
      "REPAIRED_WINNER_SELECTOR_REVIEW":nw is not None,"REPAIRED_WINNER_FINAL_BOARD":bool(new.IS_CONTEST_WINNER.any()),
      "REPAIRED_BEST_BOARD_CONTEST_RANK":int(new.VIRTUAL_CONTEST_RANK.min()),
      "INITIAL_FAILURE_CLASS":"GENERATOR_CALIBRATION_FAILURE" if op is None else ("SELECTOR_FAILURE" if not orig.IS_EXACT_PERFECT.any() else "MODEL_OR_VARIANCE_FAILURE"),
      "REPAIRED_EXECUTION_STATE":"PERFECT_CAPTURE_PASS" if new.IS_EXACT_PERFECT.any() else "FAIL",
      "ORIGINAL_BOARD_SHA256":sha256_file(args.original_board),"REPAIRED_BOARD_SHA256":sha256_file(args.repaired_board),"REPAIRED_MANIFEST_SHA256":sha256_file(args.repaired_manifest),
      "PERFECT_LINEAGE":npf,"WINNER_LINEAGE":nw,
    }
    out=args.out_dir/f"DK_TENNIS_CLASSIC_{args.execution_id}_POSTLOCK_AUDIT.json"
    out.write_text(json.dumps(receipt,indent=2,default=lambda x:x.item() if hasattr(x,"item") else str(x))+"\n")
    print(json.dumps({k:v for k,v in receipt.items() if k not in ("PERFECT_LINEAGE","WINNER_LINEAGE")},indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())
