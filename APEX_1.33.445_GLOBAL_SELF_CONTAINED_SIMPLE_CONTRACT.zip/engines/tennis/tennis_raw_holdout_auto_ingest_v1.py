#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, shutil, zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import pandas as pd

PATCH_ID='TENNIS_CLASSIC_RAW_HOLDOUT_AUTO_INGEST_v1'
POOL_REQUIRED={'PLAYER','SAL','FPTS'}
CONTEST_REQUIRED={'Rank','Points','Lineup','Player','Roster Position','FPTS'}

def sha256(path: Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def norm(x: object)->str:
    s=re.sub(r'[^a-z0-9]+',' ',str(x).lower()).strip()
    return re.sub(r'\s+',' ',s)

def _read_contest(path: Path)->pd.DataFrame:
    if path.suffix.lower()=='.zip':
        with zipfile.ZipFile(path) as z:
            ms=[n for n in z.namelist() if n.lower().endswith('.csv')]
            if not ms: raise ValueError('NO_CSV_MEMBER')
            with z.open(ms[0]) as f: return pd.read_csv(f)
    return pd.read_csv(path)

def is_tennis_pool(path: Path)->tuple[bool,str]:
    try:
        d=pd.read_csv(path,nrows=200); cols=set(map(str,d.columns))
        if not POOL_REQUIRED.issubset(cols): return False,'MISSING_TENNIS_POOL_COLUMNS'
        if 'POS' in cols and d['POS'].astype(str).str.contains('CPT',case=False,regex=True).any(): return False,'SHOWDOWN_POSITION_PRESENT'
        if not any(c in cols for c in ('Opponent','OPP','OPPONENT')): return False,'MISSING_OPPONENT_COLUMN'
        sal=pd.to_numeric(d['SAL'],errors='coerce')
        if sal.notna().sum()<6: return False,'INSUFFICIENT_SALARY_ROWS'
        return True,'PASS'
    except Exception as e: return False,f'READ_ERROR:{type(e).__name__}:{e}'

def is_tennis_contest(path: Path)->tuple[bool,str]:
    try:
        d=_read_contest(path); cols=set(map(str,d.columns))
        if not CONTEST_REQUIRED.issubset(cols): return False,'MISSING_CONTEST_COLUMNS'
        lineups=d['Lineup'].dropna().astype(str)
        if not len(lineups): return False,'NO_LINEUPS'
        sample=lineups.head(200)
        p6=float(sample.str.count(r'(?<!\S)P\s+').ge(6).mean())
        if p6<0.80: return False,f'NOT_TENNIS_UTIL6:{p6:.3f}'
        return True,'PASS'
    except Exception as e: return False,f'READ_ERROR:{type(e).__name__}:{e}'

def pool_players(path: Path)->set[str]:
    d=pd.read_csv(path,usecols=lambda c:str(c)=='PLAYER')
    return {norm(x) for x in d['PLAYER'].dropna() if norm(x)}

def contest_players(path: Path)->set[str]:
    d=_read_contest(path)
    return {norm(x) for x in d['Player'].dropna() if norm(x)}

def infer_field_size(path: Path)->int|None:
    d=_read_contest(path)
    if 'EntryId' in d:
        x=d['EntryId'].dropna().astype(str).str.strip(); x=x[x.ne('')]
        if len(x): return int(x.nunique())
    if 'EntryName' in d:
        x=d['EntryName'].dropna().astype(str).str.strip(); x=x[x.ne('')]
        if len(x): return int(len(x))
    r=pd.to_numeric(d['Rank'],errors='coerce')
    return int(r.max()) if r.notna().any() else None

def field_band(n:int)->str:
    return 'SMALL' if n<1000 else ('MEDIUM' if n<3000 else 'LARGE')

def pair_hash(pool_sha:str,contest_sha:str)->str:
    return hashlib.sha256(f'{pool_sha}|{contest_sha}|DK|TENNIS|CLASSIC|UTIL6'.encode()).hexdigest()

def slate_hash(pool_sha:str,players:set[str])->str:
    return hashlib.sha256((pool_sha+'|'+'|'.join(sorted(players))+'|DK|TENNIS|CLASSIC|UTIL6').encode()).hexdigest()

def discover(root:Path,vault:Path|None=None)->tuple[list[Path],list[Path]]:
    pools=[]; contests=[]; vr=vault.resolve() if vault and vault.exists() else None
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.name.startswith('.'): continue
        if vr:
            try: p.resolve().relative_to(vr); continue
            except ValueError: pass
        if p.suffix.lower()=='.csv':
            ok,_=is_tennis_pool(p)
            if ok: pools.append(p); continue
        if p.suffix.lower() in {'.zip','.csv'}:
            ok,_=is_tennis_contest(p)
            if ok: contests.append(p)
    return pools,contests

def match_score(pool:set[str],contest:set[str])->tuple[float,float,float]:
    if not pool or len(contest)<6:return 0.0,0.0,0.0
    inter=len(pool&contest); cov=inter/len(contest); jac=inter/len(pool|contest)
    return .80*cov+.20*jac,cov,jac

def copy_immutable(src:Path,dst:Path,digest:str)->str:
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():
        if sha256(dst)!=digest: raise RuntimeError(f'IMMUTABLE_HASH_CONFLICT:{dst}')
        return 'IDEMPOTENT_PRESENT'
    shutil.copy2(src,dst)
    if sha256(dst)!=digest:
        dst.unlink(missing_ok=True); raise RuntimeError(f'COPY_HASH_MISMATCH:{src}')
    return 'COPIED'

def ingest(root:Path,vault:Path,receipt:Path,target_pair_sha256:str|None=None)->dict[str,Any]:
    pools,contests=discover(root,vault)
    psets={p:pool_players(p) for p in pools}; csets={c:contest_players(c) for c in contests}
    matches=[]; ambiguous=[]; rejected=[]
    for contest in contests:
        cand=[]
        for pool in pools:
            s,cov,j=match_score(psets[pool],csets[contest]); cand.append((s,cov,j,pool))
        cand.sort(key=lambda x:(-x[0],str(x[3])))
        if not cand or cand[0][1]<0.90 or cand[0][0]<0.75:
            rejected.append({'CONTEST_FILE':str(contest),'REASON':'NO_CONFIDENT_POOL_MATCH'}); continue
        if len(cand)>1 and cand[0][0]-cand[1][0]<=0.015:
            ambiguous.append({'CONTEST_FILE':str(contest),'TOP_POOL':str(cand[0][3]),'SECOND_POOL':str(cand[1][3]),'REASON':'AMBIGUOUS_TOP_MATCH'}); continue
        score,cov,jac,pool=cand[0]
        field=infer_field_size(contest)
        if not field:
            rejected.append({'CONTEST_FILE':str(contest),'POOL_FILE':str(pool),'REASON':'FIELD_SIZE_UNRESOLVED'}); continue
        ps=sha256(pool); cs=sha256(contest); ph=pair_hash(ps,cs); sh=slate_hash(ps,psets[pool])
        target=bool(target_pair_sha256 and ph==target_pair_sha256)
        d=vault/sh/cs[:16]
        pt=d/'pool'/pool.name; ct=d/'contest'/contest.name
        pc=copy_immutable(pool,pt,ps); cc=copy_immutable(contest,ct,cs)
        m={'PATCH_ID':PATCH_ID,'STATUS':'BYTE_COMPLETE_RAW_PAIR_INGESTED','INGESTED_AT_UTC':datetime.now(timezone.utc).isoformat(),
           'MODE':'DK_TENNIS_CLASSIC','ROSTER_SCHEMA':'UTIL6','FIELD_SIZE':int(field),'FIELD_BAND':field_band(int(field)),
           'SLATE_SHA256':sh,'PAIR_SHA256':ph,'POOL_FILE':str(pt.relative_to(vault)),'CONTEST_FILE':str(ct.relative_to(vault)),
           'POOL_SHA256':ps,'CONTEST_SHA256':cs,'MATCH_METHOD':'PLAYER_UNIVERSE_FINGERPRINT','MATCH_SCORE':score,
           'CONTEST_PLAYER_COVERAGE':cov,'PLAYER_JACCARD':jac,'POOL_PLAYER_COUNT':len(psets[pool]),'CONTEST_PLAYER_COUNT':len(csets[contest]),
           'TARGET_FAILURE_SLATE':target,'COUNTABLE_BLIND_HOLDOUT':not target,'PRODUCTION_MUTATED':False}
        (d/'pair_manifest.json').write_text(json.dumps(m,indent=2)+'\n')
        matches.append({**m,'POOL_COPY':pc,'CONTEST_COPY':cc,'MANIFEST':str(d/'pair_manifest.json')})
    blind={m['SLATE_SHA256'] for m in matches if m['COUNTABLE_BLIND_HOLDOUT']}
    result={'EXECUTION_STATE':'TOOL_PROVEN_EXECUTED','PATCH_ID':PATCH_ID,'ROOT_SCANNED':str(root),'VAULT':str(vault),
            'POOLS_DISCOVERED':len(pools),'CONTESTS_DISCOVERED':len(contests),'PAIRS_INGESTED_OR_PRESENT':len(matches),
            'COUNTABLE_BLIND_HOLDOUT_SLATES':len(blind),'REQUIRED_BLIND_HOLDOUT_SLATES':2,
            'BLIND_HOLDOUT_READY':len(blind)>=2,'AMBIGUOUS_MATCHES':ambiguous,'REJECTED_MATCHES':rejected,
            'FAIL_CLOSED':bool(ambiguous),'PRODUCTION_MUTATED':False,'MATCHES':matches}
    receipt.parent.mkdir(parents=True,exist_ok=True); receipt.write_text(json.dumps(result,indent=2)+'\n')
    return result

def main()->int:
    a=argparse.ArgumentParser(); a.add_argument('--root',required=True); a.add_argument('--vault',required=True); a.add_argument('--receipt',required=True); a.add_argument('--target-pair-sha256')
    x=a.parse_args(); r=ingest(Path(x.root),Path(x.vault),Path(x.receipt),x.target_pair_sha256)
    print(json.dumps({k:r[k] for k in ('POOLS_DISCOVERED','CONTESTS_DISCOVERED','PAIRS_INGESTED_OR_PRESENT','COUNTABLE_BLIND_HOLDOUT_SLATES','BLIND_HOLDOUT_READY','FAIL_CLOSED')},indent=2))
    return 2 if r['FAIL_CLOSED'] else 0
if __name__=='__main__': raise SystemExit(main())
