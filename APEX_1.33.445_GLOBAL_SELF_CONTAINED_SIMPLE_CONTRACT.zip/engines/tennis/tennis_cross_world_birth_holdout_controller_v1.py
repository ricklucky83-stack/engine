#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from typing import Any
PATCH_ID='TENNIS_CLASSIC_CROSS_WORLD_BIRTH_BLIND_HOLDOUT_CONTROLLER_v1'

def scan(vault:Path,target_pair_sha256:str|None=None)->list[dict[str,Any]]:
    rows=[]
    for p in sorted(vault.rglob('pair_manifest.json')):
        d=json.loads(p.read_text())
        if d.get('MODE')!='DK_TENNIS_CLASSIC': continue
        if target_pair_sha256 and d.get('PAIR_SHA256')==target_pair_sha256: d['TARGET_FAILURE_SLATE']=True; d['COUNTABLE_BLIND_HOLDOUT']=False
        d['MANIFEST_PATH']=str(p); rows.append(d)
    return rows

def build(vault:Path,out:Path,target_pair_sha256:str|None=None)->dict[str,Any]:
    rows=scan(vault,target_pair_sha256)
    by_slate={}
    for r in rows:
        if not r.get('COUNTABLE_BLIND_HOLDOUT',not r.get('TARGET_FAILURE_SLATE',False)): continue
        s=r.get('SLATE_SHA256')
        if s and s not in by_slate: by_slate[s]=r
    folds=[by_slate[k] for k in sorted(by_slate)]
    bands=sorted({r.get('FIELD_BAND') for r in folds if r.get('FIELD_BAND')})
    ready=len(folds)>=2
    receipt={'PATCH_ID':PATCH_ID,'MODE':'SHADOW_RESEARCH_ONLY','REQUIRED_DISTINCT_BYTE_COMPLETE_BLIND_CONTROLS':2,
             'FOUND_DISTINCT_BYTE_COMPLETE_BLIND_CONTROLS':len(folds),'PAIR_DEFICIT':max(0,2-len(folds)),
             'FIELD_BANDS':bands,'BLIND_HOLDOUT_READY':ready,'NON_REGRESSION_CERTIFIED':False,'PROMOTION_REVIEW_ELIGIBLE':False,
             'PRODUCTION_MUTATED':False,'PRODUCTION_PROMOTION_ALLOWED':False,
             'NEXT_ACTION':'RUN_GENERATOR_BASELINE_VS_PATCHED_REPLAY' if ready else 'WAIT_FOR_BYTE_COMPLETE_RAW_PAIR_ARRIVAL',
             'FOLDS':folds}
    out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(receipt,indent=2)+'\n'); return receipt

def main()->int:
    p=argparse.ArgumentParser(); p.add_argument('--vault',required=True); p.add_argument('--out',required=True); p.add_argument('--target-pair-sha256'); a=p.parse_args()
    r=build(Path(a.vault),Path(a.out),a.target_pair_sha256); print(json.dumps({k:r[k] for k in ('FOUND_DISTINCT_BYTE_COMPLETE_BLIND_CONTROLS','PAIR_DEFICIT','BLIND_HOLDOUT_READY','NEXT_ACTION')},indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
