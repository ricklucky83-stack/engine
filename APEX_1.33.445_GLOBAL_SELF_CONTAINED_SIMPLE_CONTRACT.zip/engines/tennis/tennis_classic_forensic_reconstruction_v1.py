from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

MODULE_ID = "TENNIS_CLASSIC_FORENSIC_FOOTPRINT_RECOVERY_v1"
MODULE_VERSION = "1.0.0"
DOCTRINE_ID = "TENNIS_CLASSIC_UNDERSPEND_PERFECT_FAMILY_CLOSURE_v3"
ROSTER_SIZE = 6
SALARY_CAP = 50_000


class ForensicError(RuntimeError):
    pass


class NonIdentifiableError(ForensicError):
    def __init__(self, certificate: dict[str, object]):
        super().__init__(f"NONIDENTIFIABLE={json.dumps(certificate, sort_keys=True)}")
        self.certificate = certificate


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def normalize_name(value: object) -> str:
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.casefold().replace("’", "'")
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def canonicalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c).strip().casefold() for c in out.columns]
    return out


def _resolve_column(columns: Sequence[str], candidates: Sequence[str], label: str) -> str:
    lookup = {str(c).casefold(): str(c) for c in columns}
    for candidate in candidates:
        if candidate.casefold() in lookup:
            return lookup[candidate.casefold()]
    raise ForensicError(f"MISSING_COLUMN={label};AVAILABLE={list(columns)}")


@dataclass(frozen=True)
class EquationSolution:
    players: tuple[str, ...]
    values: np.ndarray
    rank: int
    equations: int
    unknowns: int
    max_abs_residual: float
    granularity: float | None

    def as_mapping(self) -> dict[str, float]:
        return {player: float(value) for player, value in zip(self.players, self.values)}


def solve_additive_lineup_system(
    ledger: pd.DataFrame,
    *,
    player_columns: Sequence[str],
    total_column: str,
    players: Sequence[str] | None = None,
    granularity: float | None = None,
    min_value: float | None = None,
    max_value: float | None = None,
    residual_tolerance: float = 1e-8,
) -> EquationSolution:
    """Solve player values from lineup-sum footprints.

    This is used for salary recovery and may also be used for actual-FPTS recovery
    only when the lineup-total system has full column rank. Underdetermined systems
    fail closed with a machine-readable nonidentifiability certificate.
    """
    data = ledger.copy()
    missing = [c for c in [*player_columns, total_column] if c not in data.columns]
    if missing:
        raise ForensicError(f"LINEUP_SYSTEM_COLUMNS_MISSING={missing}")
    if players is None:
        players = sorted({str(x) for c in player_columns for x in data[c].dropna().astype(str)})
    player_tuple = tuple(str(x) for x in players)
    index = {normalize_name(p): i for i, p in enumerate(player_tuple)}
    if len(index) != len(player_tuple):
        raise ForensicError("DUPLICATE_CANONICAL_PLAYER_IN_SYSTEM")

    matrix = np.zeros((len(data), len(player_tuple)), dtype=np.float64)
    for row_i, row in data.iterrows():
        seen: set[int] = set()
        for column in player_columns:
            key = normalize_name(row[column])
            if key not in index:
                raise ForensicError(f"UNKNOWN_PLAYER_IN_SYSTEM={row[column]}")
            player_i = index[key]
            if player_i in seen:
                raise ForensicError(f"DUPLICATE_PLAYER_IN_LINEUP_ROW={row_i}")
            seen.add(player_i)
            matrix[int(row_i), player_i] = 1.0
    totals = pd.to_numeric(data[total_column], errors="raise").to_numpy(np.float64)
    rank = int(np.linalg.matrix_rank(matrix))
    unknowns = int(matrix.shape[1])
    if rank < unknowns:
        certificate = {
            "CERTIFICATE_ID": "TENNIS_LINEUP_SYSTEM_NONIDENTIFIABILITY_v1",
            "STATUS": "PROVEN_UNDERDETERMINED",
            "EQUATIONS": int(matrix.shape[0]),
            "UNKNOWNS": unknowns,
            "RANK": rank,
            "NULLITY": unknowns - rank,
            "TOTAL_COLUMN": total_column,
            "PLAYERS": list(player_tuple),
        }
        raise NonIdentifiableError(certificate)

    values, _, _, _ = np.linalg.lstsq(matrix, totals, rcond=None)
    if granularity is not None:
        values = np.rint(values / float(granularity)) * float(granularity)
    residual = matrix @ values - totals
    max_abs_residual = float(np.max(np.abs(residual))) if len(residual) else 0.0
    if max_abs_residual > residual_tolerance:
        raise ForensicError(f"LINEUP_SYSTEM_RESIDUAL_FAIL={max_abs_residual}")
    if min_value is not None and np.any(values < float(min_value)):
        raise ForensicError("LINEUP_SYSTEM_VALUE_BELOW_MINIMUM")
    if max_value is not None and np.any(values > float(max_value)):
        raise ForensicError("LINEUP_SYSTEM_VALUE_ABOVE_MAXIMUM")
    return EquationSolution(
        players=player_tuple,
        values=values,
        rank=rank,
        equations=int(matrix.shape[0]),
        unknowns=unknowns,
        max_abs_residual=max_abs_residual,
        granularity=granularity,
    )


def load_player_truth(path: Path) -> pd.DataFrame:
    truth = canonicalize_columns(pd.read_csv(path))
    required = {"player", "salary", "actual_fpts", "opponent", "match_id"}
    missing = required - set(truth.columns)
    if missing:
        raise ForensicError(f"PLAYER_TRUTH_COLUMNS_MISSING={sorted(missing)}")
    truth = truth.copy()
    truth["player"] = truth["player"].astype(str)
    truth["opponent"] = truth["opponent"].astype(str)
    truth["match_id"] = truth["match_id"].astype(str)
    truth["salary"] = pd.to_numeric(truth["salary"], errors="raise").astype(int)
    truth["actual_fpts"] = pd.to_numeric(truth["actual_fpts"], errors="raise").astype(float)
    truth["_canon"] = truth["player"].map(normalize_name)
    truth["_opp_canon"] = truth["opponent"].map(normalize_name)
    if truth["_canon"].duplicated().any():
        raise ForensicError("PLAYER_TRUTH_DUPLICATE_PLAYER")
    if not np.isfinite(truth[["salary", "actual_fpts"]].to_numpy(float)).all():
        raise ForensicError("PLAYER_TRUTH_NONFINITE")
    if (truth["salary"] <= 0).any() or (truth["salary"] > SALARY_CAP).any():
        raise ForensicError("PLAYER_TRUTH_SALARY_INVALID")
    by_name = truth.set_index("_canon")
    for _, row in truth.iterrows():
        if row["_opp_canon"] not in by_name.index:
            raise ForensicError(f"PLAYER_TRUTH_OPPONENT_MISSING={row['player']}->{row['opponent']}")
        reciprocal = by_name.loc[row["_opp_canon"]]
        if reciprocal["_opp_canon"] != row["_canon"]:
            raise ForensicError(f"PLAYER_TRUTH_OPPONENT_ASYMMETRY={row['player']}<->{row['opponent']}")
        if str(reciprocal["match_id"]) != str(row["match_id"]):
            raise ForensicError(f"PLAYER_TRUTH_MATCH_ID_ASYMMETRY={row['player']}<->{row['opponent']}")
    counts = truth.groupby("match_id").size()
    if not (counts == 2).all():
        raise ForensicError("PLAYER_TRUTH_MATCH_CARDINALITY_FAIL")
    return truth.reset_index(drop=True)


def enumerate_exact_legal_universe(
    truth: pd.DataFrame,
    *,
    roster_size: int = ROSTER_SIZE,
    salary_cap: int = SALARY_CAP,
) -> pd.DataFrame:
    if roster_size <= 0:
        raise ForensicError("ROSTER_SIZE_INVALID")
    rows: list[dict[str, object]] = []
    for combo in itertools.combinations(range(len(truth)), roster_size):
        subset = truth.iloc[list(combo)]
        if subset["match_id"].duplicated().any():
            continue
        salary = int(subset["salary"].sum())
        if salary > salary_cap:
            continue
        score = float(subset["actual_fpts"].sum())
        names = sorted(subset["player"].astype(str).tolist())
        rows.append({
            "lineup_key": "|".join(names),
            "salary": salary,
            "salary_left": salary_cap - salary,
            "actual_fpts": round(score, 8),
            **{f"player_{i + 1}": name for i, name in enumerate(names)},
        })
    if not rows:
        raise ForensicError("NO_CAP_LEGAL_LINEUPS")
    legal = pd.DataFrame(rows).sort_values(
        ["actual_fpts", "salary", "lineup_key"],
        ascending=[False, True, True],
        kind="stable",
    ).reset_index(drop=True)
    legal["actual_rank"] = legal["actual_fpts"].rank(method="min", ascending=False).astype(int)
    columns = [
        "actual_rank", "actual_fpts", "salary", "salary_left",
        *[f"player_{i + 1}" for i in range(roster_size)], "lineup_key",
    ]
    return legal[columns]


def validate_preserved_audit_rows(legal: pd.DataFrame, audit: pd.DataFrame) -> list[dict[str, object]]:
    data = canonicalize_columns(audit)
    player_columns = [f"player_{i}" for i in range(1, ROSTER_SIZE + 1)]
    required = {"slot", "expected_salary", "expected_actual", "expected_legal_rank", *player_columns}
    missing = required - set(data.columns)
    if missing:
        raise ForensicError(f"AUDIT_COLUMNS_MISSING={sorted(missing)}")
    by_key = legal.set_index("lineup_key")
    checks: list[dict[str, object]] = []
    for _, row in data.iterrows():
        key = "|".join(sorted(str(row[c]) for c in player_columns))
        if key not in by_key.index:
            raise ForensicError(f"AUDIT_LINEUP_NOT_LEGAL={row['slot']}")
        hit = by_key.loc[key]
        check = {
            "slot": str(row["slot"]),
            "salary_match": int(hit["salary"]) == int(row["expected_salary"]),
            "actual_points_match": math.isclose(float(hit["actual_fpts"]), float(row["expected_actual"]), abs_tol=1e-8),
            "actual_legal_rank_match": int(hit["actual_rank"]) == int(row["expected_legal_rank"]),
            "computed_salary": int(hit["salary"]),
            "computed_actual": float(hit["actual_fpts"]),
            "computed_legal_rank": int(hit["actual_rank"]),
        }
        checks.append(check)
    if not all(c["salary_match"] and c["actual_points_match"] and c["actual_legal_rank_match"] for c in checks):
        raise ForensicError(f"PRESERVED_AUDIT_VALIDATION_FAIL={checks}")
    return checks


def reconstruct_exact_perfect(
    *,
    player_truth_path: Path,
    out_dir: Path | None = None,
    expected_legal_count: int | None = None,
    audit_path: Path | None = None,
) -> dict[str, object]:
    truth = load_player_truth(player_truth_path)
    legal = enumerate_exact_legal_universe(truth)
    if expected_legal_count is not None and len(legal) != int(expected_legal_count):
        raise ForensicError(f"LEGAL_UNIVERSE_COUNT_MISMATCH={len(legal)}!={expected_legal_count}")
    top_score = float(legal.iloc[0]["actual_fpts"])
    perfect = legal.loc[np.isclose(legal["actual_fpts"], top_score, atol=1e-8)].copy()
    audit_checks: list[dict[str, object]] = []
    if audit_path is not None:
        audit_checks = validate_preserved_audit_rows(legal, pd.read_csv(audit_path))
    receipt: dict[str, object] = {
        "RUN_STATE": "TOOL_PROVEN_EXECUTED",
        "EXECUTION_STATE": "EXACT_PERFECT_RECONSTRUCTION_COMPLETE",
        "MODULE_ID": MODULE_ID,
        "MODULE_VERSION": MODULE_VERSION,
        "DOCTRINE_ID": DOCTRINE_ID,
        "POSTLOCK_ONLY": True,
        "FORWARD_SELECTOR_INFLUENCE": False,
        "PLAYER_TRUTH_SHA256": sha256_file(player_truth_path),
        "PLAYER_COUNT": int(len(truth)),
        "MATCH_COUNT": int(truth["match_id"].nunique()),
        "FULLY_LEGAL_LINEUPS": int(len(legal)),
        "MINIMUM_SALARY_GATE": None,
        "PERFECT_TIE_COUNT": int(len(perfect)),
        "PERFECT_ACTUAL_FPTS": top_score,
        "PERFECT_SALARY_MIN": int(perfect["salary"].min()),
        "PERFECT_SALARY_MAX": int(perfect["salary"].max()),
        "PERFECT_LINEUPS": perfect.to_dict(orient="records"),
        "AUDIT_CROSSCHECKS": audit_checks,
        "AUDIT_CROSSCHECK_COUNT": int(len(audit_checks)),
        "NONIDENTIFIABILITY_CERTIFICATE": None,
    }
    if out_dir is not None:
        out_dir.mkdir(parents=True, exist_ok=True)
        legal_path = out_dir / "tennis_exact_legal_universe.csv"
        perfect_path = out_dir / "tennis_exact_perfect_lineups.csv"
        receipt_path = out_dir / "tennis_exact_reconstruction_receipt.json"
        legal.to_csv(legal_path, index=False)
        perfect.to_csv(perfect_path, index=False)
        receipt.update({
            "LEGAL_UNIVERSE_PATH": str(legal_path),
            "LEGAL_UNIVERSE_SHA256": sha256_file(legal_path),
            "PERFECT_LINEUPS_PATH": str(perfect_path),
            "PERFECT_LINEUPS_SHA256": sha256_file(perfect_path),
        })
        receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        receipt["RECEIPT_PATH"] = str(receipt_path)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--player-truth", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--expected-legal-count", type=int)
    parser.add_argument("--audit")
    args = parser.parse_args()
    receipt = reconstruct_exact_perfect(
        player_truth_path=Path(args.player_truth),
        out_dir=Path(args.out_dir),
        expected_legal_count=args.expected_legal_count,
        audit_path=Path(args.audit) if args.audit else None,
    )
    print(json.dumps(receipt, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
