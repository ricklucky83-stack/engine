---
name: apex-pga-classic-engine
description: Execute DraftKings PGA Classic six-golfer lineup validation, four-round cut-survival calibration, deterministic calibration-qualified lineup construction, independent tournament Monte Carlo, anonymous exact hybrid selection, exposure review, and fixed final-board rendering. Use automatically for PGA Classic contests.
---

# APEX PGA Classic Engine

Run only the bundled code. Bind `MODE=PGA_CLASSIC`, `SCORING_HORIZON=FOUR_ROUNDS`, `COMPLETED_RUN_SOLVER=CODE_AI_HYBRID`, and `FASTEST_CODING_METHODS_ONLY=TRUE`.

Require a public field size and authoritative current tournament eligibility before Phase 1. Historical `CUT%`, `CUTS`, and `WD` counts are performance inputs only and never live status authority. When the pool lacks a live status field, source the official tournament field, tee sheet, or leaderboard; freeze `PLAYER,STATUS,SOURCE_URL,RETRIEVED_AT_UTC,EVENT` as an eligibility CSV and pass it with `--eligibility-file`. Purge `MC`, `CUT`, `MDF`, `WD`, `DQ`, `DNS`, inactive, and unlisted golfers before Monte Carlo.

Use the locked order:

1. Phase 0 validates the player pool and status authority.
2. Phase 1 runs correlated four-round player Monte Carlo before lineup birth and freezes cut-survival, finishing, tail, value, and leverage fingerprints.
3. Phase 2 builds a deterministic Phase 1-guided player frontier, scans its complete six-golfer combination matrix, applies DraftKings legality, and retains only multi-surface calibration-qualified lineups.
4. Phase 3 independently simulates every frozen Phase 2 lineup.
5. Phase 3.95 exposes every frozen Phase 2 lineup as anonymous IDs and Monte Carlo outputs only. Phase 2, Phase 3, handoff, and selector-review membership must be identical; compression is prohibited. The exact lexicographic MILP then selects the earned board.

Run the global PGA strategy adapter after authoritative eligibility reconciliation and before Phase 1. Preserve its result-blind salary-unlock paths in calibration/frontier construction without changing final-selector weights. Rank by `ALL_SIX_SURVIVE_RATE`, `FIRST_PLACE_RATE`, `TOP_0_1_PERCENT_RATE`, `TOP_1_PERCENT_RATE`, `TOURNAMENT_P999`, `TOURNAMENT_CVAR99`, then deterministic lineup ID. File projection and mean score have zero final-selector weight. Scenario or structural lanes may protect Phase 2 recall but never earn final-board entitlement. Require positive first-place or top-0.1% equity; fillers are prohibited.

Render one lineup per row as `BOARD_RANK,LINEUP_ID,G1,G2,G3,G4,G5,G6,SALARY`. In chat, render separate vertical lineup blocks.

## Commands

```bash
python scripts/run.py health
python scripts/run.py validate --input /mnt/data/<pool>.csv --eligibility-file /mnt/data/<eligibility>.csv
python scripts/run.py execute --input /mnt/data/<pool>.csv --eligibility-file /mnt/data/<eligibility>.csv --field-size <contest_rows> --output-dir /mnt/data/pga_classic_<execution_id> --seed <execution_id> --simulations 50000
```

## Player Spike Probability Model v1

`PGA_CLASSIC_PLAYER_SPIKE_PROBABILITY_MODEL_v1` computes result-blind pre-lock player tail signals from available golf inputs (birdie/bogey rates when present, ball-striking/stat columns, cut/top-finish history, projection, and Phase 1 Monte Carlo tail behavior). It emits `PLAYER_SPIKE_SCORE`, `PLAYER_SPIKE_RATE`, P95/P99, slate Top-5%/Top-1% rates, tail volatility, and a deterministic 48-player shadow spike frontier. The shadow frontier is diagnostic/research-only and MUST NOT enter Phase 2, handoff, selector, or board construction until independent raw PGA Classic holdout nonregression is proven. Same-slate contest outcomes are post-lock diagnostics only and may never enter spike scoring or frontier construction.
