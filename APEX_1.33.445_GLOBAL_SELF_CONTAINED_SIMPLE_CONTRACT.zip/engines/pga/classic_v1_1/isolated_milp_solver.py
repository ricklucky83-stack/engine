#!/usr/bin/env python3
from __future__ import annotations
import pickle
import sys
from pathlib import Path
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

def main() -> int:
    if len(sys.argv) != 3:
        return 64
    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    with input_path.open('rb') as handle:
        payload = pickle.load(handle)
    result = milp(
        c=np.asarray(payload['c'], dtype=np.float64),
        integrality=np.asarray(payload['integrality'], dtype=np.int8),
        bounds=Bounds(np.asarray(payload['bounds_lb'], dtype=np.float64), np.asarray(payload['bounds_ub'], dtype=np.float64)),
        constraints=LinearConstraint(payload['A'], np.asarray(payload['constraint_lb'], dtype=np.float64), np.asarray(payload['constraint_ub'], dtype=np.float64)),
        options=dict(payload.get('options') or {}),
    )
    record = {
        'success': bool(result.success),
        'status': int(result.status),
        'message': str(result.message),
        'x': None if result.x is None else np.asarray(result.x, dtype=np.float64),
        'fun': None if result.fun is None else float(result.fun),
    }
    with output_path.open('wb') as handle:
        pickle.dump(record, handle, protocol=pickle.HIGHEST_PROTOCOL)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
