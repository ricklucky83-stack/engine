#!/usr/bin/env python3
"""Exact constrained final-board optimizer shared by every hybrid DFS route."""
from __future__ import annotations

import math
import os
import pickle
import subprocess
import sys
import tempfile
from itertools import combinations
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix, vstack


OPTIMIZER_POLICY = "SCIPY_HIGHS_MILP_LEXICOGRAPHIC_v1_0"
# Six decimal places preserve the Monte Carlo rate lattice while keeping the
# sequential equality rows numerically well-conditioned for HiGHS.
METRIC_TICK_SCALE = 1_000_000
PGA_MILP_PROCESS_ISOLATION = "FRESH_SUBPROCESS_PER_EXACT_MILP_v1"


def _solve_milp_isolated(*, c, integrality, bounds, constraints, options):
    """Run one SciPy/HiGHS MILP in a fresh interpreter to prevent solver-state pollution."""
    worker = Path(__file__).with_name("isolated_milp_solver.py")
    if not worker.is_file():
        raise SystemExit("RUN_INVALID: PGA_ISOLATED_MILP_WORKER_MISSING")
    payload = {
        "c": c,
        "integrality": integrality,
        "bounds_lb": bounds.lb,
        "bounds_ub": bounds.ub,
        "A": constraints.A,
        "constraint_lb": constraints.lb,
        "constraint_ub": constraints.ub,
        "options": dict(options or {}),
    }
    with tempfile.TemporaryDirectory(prefix="apex_pga_milp_") as tmpdir:
        input_path = Path(tmpdir) / "input.pkl"
        output_path = Path(tmpdir) / "output.pkl"
        with input_path.open("wb") as handle:
            pickle.dump(payload, handle, protocol=pickle.HIGHEST_PROTOCOL)
        env = os.environ.copy()
        proc = subprocess.run(
            [sys.executable, str(worker), str(input_path), str(output_path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
            check=False,
        )
        if proc.returncode != 0 or not output_path.is_file():
            detail = (proc.stderr or proc.stdout or "UNKNOWN").strip().replace("\n", " | ")
            raise SystemExit("RUN_INVALID: PGA_ISOLATED_MILP_PROCESS_FAILED:" + detail[:1000])
        with output_path.open("rb") as handle:
            result = pickle.load(handle)
    class _Result:
        pass
    out = _Result()
    for key, value in result.items():
        setattr(out, key, value)
    return out


def _finite_number(row: dict[str, Any], field: str) -> float:
    try:
        value = float(row[field])
    except (KeyError, TypeError, ValueError):
        raise SystemExit(
            f"RUN_INVALID: AI_HANDOFF_SELECTION_METRIC_INVALID:{field}"
        ) from None
    if not math.isfinite(value):
        raise SystemExit(
            f"RUN_INVALID: AI_HANDOFF_SELECTION_METRIC_NONFINITE:{field}"
        )
    return value


def locked_order(
    rows: Sequence[dict[str, Any]],
    *,
    id_field: str,
    objectives: Sequence[tuple[str, str]],
) -> list[str]:
    """Return the deterministic individual-lineup order shown to the selector."""
    for _, direction in objectives:
        if direction not in {"MAX", "MIN"}:
            raise ValueError(f"unsupported objective direction: {direction}")
    ordered = sorted(
        rows,
        key=lambda row: tuple(
            (
                -_finite_number(row, field)
                if direction == "MAX"
                else _finite_number(row, field)
            )
            for field, direction in objectives
        )
        + (str(row[id_field]),),
    )
    return [str(row[id_field]) for row in ordered]




def _gcd_normalized_ticks(rows, field):
    ticks = np.asarray([int(round(_finite_number(row, field) * METRIC_TICK_SCALE)) for row in rows], dtype=np.int64)
    ticks -= ticks.min()
    unique = np.unique(ticks)
    if len(unique) > 1:
        step = int(np.gcd.reduce(np.diff(unique)))
        if step > 1:
            ticks //= step
    return ticks

def _exact_clique_matrix(rows, *, id_field, slots, target_rows, max_pairwise_overlap, player_max_lineups, player_min_lineups, eligible_mask, fixed_objectives=None):
    active = np.flatnonzero(np.asarray(eligible_mask, dtype=bool))
    if len(active) < target_rows:
        raise SystemExit("RUN_INVALID: AI_SELECTOR_INSUFFICIENT_ELIGIBLE_ROWS")
    local_rows = [rows[int(i)] for i in active]
    rosters = [tuple(str(row[slot]) for slot in slots) for row in local_rows]
    row_index=[]; column_index=[]; values=[]; lower=[]; upper=[]; ci=0
    for j in range(len(active)):
        row_index.append(ci); column_index.append(j); values.append(1.0)
    lower.append(float(target_rows)); upper.append(float(target_rows)); ci += 1
    for player_id in sorted(player_max_lineups):
        minimum=int((player_min_lineups or {}).get(player_id,0)); maximum=int(player_max_lineups[player_id])
        if minimum < 0 or maximum < minimum or maximum > target_rows:
            raise SystemExit("RUN_INVALID: AI_SELECTOR_PLAYER_CAP_INVALID")
        for j, roster in enumerate(rosters):
            if player_id in roster:
                row_index.append(ci); column_index.append(j); values.append(1.0)
        lower.append(float(minimum)); upper.append(float(maximum)); ci += 1
    shared_size=max_pairwise_overlap+1
    clique_count=0
    if shared_size <= len(slots):
        buckets={}
        for j, roster in enumerate(rosters):
            for shared in combinations(sorted(roster), shared_size):
                buckets.setdefault(shared, []).append(j)
        for bucket in buckets.values():
            if len(bucket) <= 1: continue
            for j in bucket:
                row_index.append(ci); column_index.append(j); values.append(1.0)
            lower.append(-np.inf); upper.append(1.0); ci += 1; clique_count += 1
    matrix=coo_matrix((values,(row_index,column_index)),shape=(ci,len(active)),dtype=np.float64).tocsr()
    lower=np.asarray(lower,dtype=np.float64); upper=np.asarray(upper,dtype=np.float64)
    for ticks,optimum in fixed_objectives or []:
        vector=np.asarray(ticks,dtype=np.float64)[active]
        matrix=vstack((matrix,coo_matrix(vector.reshape(1,-1)).tocsr()),format="csr")
        lower=np.append(lower,float(optimum)); upper=np.append(upper,float(optimum))
    return active,matrix,lower,upper,clique_count

def _solve_exact_clique_lexicographic(rows, *, id_field, slots, objectives, target_rows, max_pairwise_overlap, player_max_lineups, player_min_lineups, eligibility, full_order):
    metric_vectors=[(field,direction,_gcd_normalized_ticks(rows,field)) for field,direction in objectives]
    fixed=[]; objective_ticks={}; milp_calls=0; uniqueness_checks=0; final_global=None; clique_count=0
    eligible_mask=np.asarray(eligibility,dtype=bool)
    # Solve high-priority MC objectives on the full eligible set until safe reduction is material.
    active,matrix,lower,upper,clique_count=_exact_clique_matrix(rows,id_field=id_field,slots=slots,target_rows=target_rows,max_pairwise_overlap=max_pairwise_overlap,player_max_lineups=player_max_lineups,player_min_lineups=player_min_lineups,eligible_mask=eligible_mask,fixed_objectives=fixed)
    for objective_index,(field,direction,ticks) in enumerate(metric_vectors):
        local=ticks[active].astype(np.float64)
        c=-local if direction=="MAX" else local
        milp_calls += 1
        result=_solve_milp_isolated(c=c,integrality=np.ones(len(active),dtype=np.int8),bounds=Bounds(np.zeros(len(active)),np.ones(len(active))),constraints=LinearConstraint(matrix,lower,upper),options={"disp":False,"presolve":True,"mip_rel_gap":0.0})
        if not result.success or result.x is None:
            raise SystemExit("RUN_INVALID: AI_DIVERSITY_MILP_NO_OPTIMAL_SOLUTION:"+field+":"+result.message)
        solution=(result.x>0.5).astype(np.int8)
        optimum=int(np.dot(ticks[active],solution)); objective_ticks[field]=optimum; fixed.append((ticks,optimum)); final_global=active[np.flatnonzero(solution)]
        vector=coo_matrix(ticks[active].astype(np.float64).reshape(1,-1)).tocsr()
        matrix=vstack((matrix,vector),format="csr"); lower=np.append(lower,float(optimum)); upper=np.append(upper,float(optimum))
        # Once at least three higher-priority metrics are fixed, safely remove rows whose nonnegative contribution alone exceeds any fixed optimum.
        if objective_index == 2:
            reduced=eligible_mask.copy()
            # Exact cardinality strengthens the safe upper bound for every fixed
            # nonnegative objective: one selected row can contribute at most the
            # fixed total minus the minimum unavoidable contribution of the other
            # target_rows - 1 selections. This is an exact reduction, not a heuristic.
            for prior_ticks, prior_opt in fixed:
                eligible_min = int(np.min(prior_ticks[eligible_mask]))
                per_row_max = int(prior_opt) - (int(target_rows) - 1) * eligible_min
                reduced &= prior_ticks <= per_row_max
            if int(reduced.sum()) < int(eligible_mask.sum()):
                active,matrix,lower,upper,clique_count=_exact_clique_matrix(rows,id_field=id_field,slots=slots,target_rows=target_rows,max_pairwise_overlap=max_pairwise_overlap,player_max_lineups=player_max_lineups,player_min_lineups=player_min_lineups,eligible_mask=reduced,fixed_objectives=fixed)
        # A unique portfolio under the objectives fixed so far is automatically exact for every lower-priority objective.
        if objective_index >= 4 and final_global is not None:
            local_selected=np.isin(active,final_global).astype(np.float64)
            alt_matrix=vstack((matrix,coo_matrix(local_selected.reshape(1,-1)).tocsr()),format="csr")
            alt_lower=np.append(lower,-np.inf); alt_upper=np.append(upper,float(target_rows-1))
            uniqueness_checks += 1; milp_calls += 1
            alternate=_solve_milp_isolated(c=np.zeros(len(active),dtype=np.float64),integrality=np.ones(len(active),dtype=np.int8),bounds=Bounds(np.zeros(len(active)),np.ones(len(active))),constraints=LinearConstraint(alt_matrix,alt_lower,alt_upper),options={"disp":False,"presolve":True,"mip_rel_gap":0.0})
            if alternate.status == 2 and alternate.x is None:
                break
    if final_global is None or len(final_global) != target_rows:
        raise SystemExit("RUN_INVALID: AI_DIVERSITY_MILP_TARGET_MISMATCH")
    selected_set={str(rows[int(i)][id_field]) for i in final_global}
    selected=[lineup_id for lineup_id in full_order if lineup_id in selected_set]
    proof={"selector_optimizer":OPTIMIZER_POLICY,"optimization_status":"OPTIMAL","milp_solver_used":True,"greedy_selector_used":False,"hard_exposure_caps_inside_optimizer":True,"post_freeze_pool_expansion":False,"metric_tick_scale":METRIC_TICK_SCALE,"objective_tick_totals":objective_ticks,"candidate_rows":len(rows),"eligible_rows":int(np.asarray(eligibility,dtype=bool).sum()),"player_cap_constraints":len(player_max_lineups),"pairwise_conflict_constraints":0,"overlap_clique_constraints":clique_count,"seeded_overlap_clique_constraints":0,"conflict_generation_exact":True,"conflict_generation_rounds":0,"milp_calls":milp_calls,"exact_full_overlap_cliques":True,"safe_objective_bound_reduction":True,"lexicographic_uniqueness_checks":uniqueness_checks,"milp_process_isolation":PGA_MILP_PROCESS_ISOLATION}
    return full_order,selected,proof

def optimize_portfolio(
    rows: Sequence[dict[str, Any]],
    *,
    id_field: str,
    slots: Sequence[str],
    objectives: Sequence[tuple[str, str]],
    target_rows: int,
    max_pairwise_overlap: int,
    player_max_lineups: dict[str, int],
    player_min_lineups: dict[str, int] | None = None,
    eligible: Sequence[bool] | None = None,
    roster_validator: Callable[[tuple[str, ...]], bool] | None = None,
) -> tuple[list[str], list[str], dict[str, Any]]:
    """Solve the final portfolio as an exact multi-pass lexicographic MILP."""
    if not rows or target_rows < 1 or target_rows > len(rows):
        raise SystemExit("RUN_INVALID: AI_DIVERSITY_MILP_DIMENSION_INVALID")
    if not slots or max_pairwise_overlap < 0:
        raise SystemExit("RUN_INVALID: AI_DIVERSITY_MILP_DIMENSION_INVALID")
    if len({str(row[id_field]) for row in rows}) != len(rows):
        raise SystemExit("RUN_INVALID: AI_HANDOFF_DUPLICATE_LINEUP_ID")

    full_order = locked_order(
        rows,
        id_field=id_field,
        objectives=objectives,
    )
    order_position = {
        lineup_id: position for position, lineup_id in enumerate(full_order)
    }
    if len(slots) == 6 and target_rows <= 10 and max_pairwise_overlap == 3:
        if eligible is None:
            eligibility_fast=np.ones(len(rows),dtype=np.float64)
        else:
            if len(eligible) != len(rows):
                raise SystemExit("RUN_INVALID: AI_SELECTOR_ELIGIBILITY_LENGTH_MISMATCH")
            eligibility_fast=np.asarray(eligible,dtype=np.float64)
        return _solve_exact_clique_lexicographic(rows,id_field=id_field,slots=slots,objectives=objectives,target_rows=target_rows,max_pairwise_overlap=max_pairwise_overlap,player_max_lineups=player_max_lineups,player_min_lineups=player_min_lineups or {},eligibility=eligibility_fast,full_order=full_order)
    player_min_lineups = player_min_lineups or {}
    rosters = [
        tuple(str(row[slot]) for slot in slots)
        for row in rows
    ]
    for roster in rosters:
        if (
            len(set(roster)) != len(slots)
            or any(player_id not in player_max_lineups for player_id in roster)
            or (roster_validator is not None and not roster_validator(roster))
        ):
            raise SystemExit("RUN_INVALID: AI_HANDOFF_ANON_ROSTER_INVALID")

    if eligible is None:
        eligibility = np.ones(len(rows), dtype=np.float64)
    else:
        if len(eligible) != len(rows):
            raise SystemExit("RUN_INVALID: AI_SELECTOR_ELIGIBILITY_LENGTH_MISMATCH")
        eligibility = np.asarray(eligible, dtype=np.float64)
    if int(eligibility.sum()) < target_rows:
        raise SystemExit("RUN_INVALID: AI_SELECTOR_INSUFFICIENT_ELIGIBLE_ROWS")

    player_lineups: dict[str, list[int]] = {
        player_id: [] for player_id in player_max_lineups
    }
    for lineup_index, roster in enumerate(rosters):
        for player_id in roster:
            player_lineups[player_id].append(lineup_index)

    roster_sets = [set(roster) for roster in rosters]
    id_to_index = {str(row[id_field]): index for index, row in enumerate(rows)}
    shared_size = max_pairwise_overlap + 1
    seeded_overlap_cliques: list[list[int]] = []
    if shared_size <= len(slots):
        seed_count = min(len(rows), max(256, target_rows * 64), 1024)
        shared_buckets: dict[tuple[str, ...], list[int]] = {}
        for lineup_id in full_order[:seed_count]:
            lineup_index = id_to_index[lineup_id]
            for shared in combinations(sorted(rosters[lineup_index]), shared_size):
                shared_buckets.setdefault(shared, []).append(lineup_index)
        seeded_overlap_cliques = [
            bucket for bucket in shared_buckets.values() if len(bucket) > 1
        ]

    row_index: list[int] = []
    column_index: list[int] = []
    values: list[float] = []
    lower: list[float] = []
    upper: list[float] = []
    constraint_index = 0

    for lineup_index in range(len(rows)):
        row_index.append(constraint_index)
        column_index.append(lineup_index)
        values.append(1.0)
    lower.append(float(target_rows))
    upper.append(float(target_rows))
    constraint_index += 1

    player_constraint_count = 0
    for player_id in sorted(player_max_lineups):
        minimum = int(player_min_lineups.get(player_id, 0))
        maximum = int(player_max_lineups[player_id])
        if minimum < 0 or maximum < minimum or maximum > target_rows:
            raise SystemExit("RUN_INVALID: AI_SELECTOR_PLAYER_CAP_INVALID")
        for lineup_index in player_lineups[player_id]:
            row_index.append(constraint_index)
            column_index.append(lineup_index)
            values.append(1.0)
        lower.append(float(minimum))
        upper.append(float(maximum))
        constraint_index += 1
        player_constraint_count += 1

    for bucket in seeded_overlap_cliques:
        for lineup_index in bucket:
            row_index.append(constraint_index)
            column_index.append(lineup_index)
            values.append(1.0)
        lower.append(-np.inf)
        upper.append(1.0)
        constraint_index += 1

    constraints = coo_matrix(
        (values, (row_index, column_index)),
        shape=(constraint_index, len(rows)),
        dtype=np.float64,
    ).tocsr()
    lower_bounds = np.asarray(lower, dtype=np.float64)
    upper_bounds = np.asarray(upper, dtype=np.float64)
    metric_vectors: list[tuple[str, str, np.ndarray]] = []
    for field, direction in objectives:
        ticks = np.asarray(
            [
                int(round(_finite_number(row, field) * METRIC_TICK_SCALE))
                for row in rows
            ],
            dtype=np.int64,
        )
        ticks -= ticks.min()
        metric_vectors.append((field, direction, ticks))
    metric_vectors.append(
        (
            "LINEUP_ID_TIEBREAK",
            "MIN",
            np.asarray(
                [order_position[str(row[id_field])] for row in rows],
                dtype=np.int64,
            ),
        )
    )

    objective_ticks: dict[str, int] = {}
    solution: np.ndarray | None = None
    conflict_pairs: set[tuple[int, int]] = set()
    conflict_generation_rounds = 0
    milp_calls = 0
    bounds = Bounds(
        np.zeros(len(rows), dtype=np.float64),
        eligibility,
    )
    for field, direction, ticks in metric_vectors:
        objective = ticks.astype(np.float64)
        if direction == "MAX":
            objective = -objective
        while True:
            milp_calls += 1
            result = milp(
                c=objective,
                integrality=np.ones(len(rows), dtype=np.int8),
                bounds=bounds,
                constraints=LinearConstraint(
                    constraints,
                    lower_bounds,
                    upper_bounds,
                ),
                options={
                    "disp": False,
                    "presolve": True,
                    "mip_rel_gap": 0.0,
                },
            )
            if not result.success or result.x is None:
                raise SystemExit(
                    "RUN_INVALID: AI_DIVERSITY_MILP_NO_OPTIMAL_SOLUTION:"
                    f"{field}:{result.message}"
                )
            solution = (result.x > 0.5).astype(np.int8)
            selected_indices = [int(index) for index in np.flatnonzero(solution)]
            violations: list[tuple[int, int]] = []
            for left_position, left in enumerate(selected_indices):
                for right in selected_indices[left_position + 1:]:
                    if len(roster_sets[left] & roster_sets[right]) > max_pairwise_overlap:
                        pair = (left, right) if left < right else (right, left)
                        if pair in conflict_pairs:
                            raise SystemExit("RUN_INVALID: AI_DIVERSITY_MILP_CONFLICT_CUT_BREACH")
                        violations.append(pair)
            if not violations:
                break
            conflict_generation_rounds += 1
            conflict_pairs.update(violations)
            local_rows: list[int] = []
            local_columns: list[int] = []
            for row_number, (left, right) in enumerate(violations):
                local_rows.extend((row_number, row_number))
                local_columns.extend((left, right))
            conflict_matrix = coo_matrix(
                (
                    np.ones(len(local_rows), dtype=np.float64),
                    (local_rows, local_columns),
                ),
                shape=(len(violations), len(rows)),
            ).tocsr()
            constraints = vstack((constraints, conflict_matrix), format="csr")
            lower_bounds = np.append(lower_bounds, np.full(len(violations), -np.inf))
            upper_bounds = np.append(upper_bounds, np.ones(len(violations)))
        optimum = int(np.dot(ticks, solution))
        objective_ticks[field] = optimum
        objective_row = coo_matrix(
            ticks.astype(np.float64).reshape(1, -1)
        ).tocsr()
        constraints = vstack((constraints, objective_row), format="csr")
        lower_bounds = np.append(lower_bounds, float(optimum))
        upper_bounds = np.append(upper_bounds, float(optimum))

    if solution is None or int(solution.sum()) != target_rows:
        raise SystemExit("RUN_INVALID: AI_DIVERSITY_MILP_TARGET_MISMATCH")
    selected_set = {
        str(rows[index][id_field])
        for index in np.flatnonzero(solution)
    }
    selected = [
        lineup_id for lineup_id in full_order
        if lineup_id in selected_set
    ]
    proof = {
        "selector_optimizer": OPTIMIZER_POLICY,
        "optimization_status": "OPTIMAL",
        "milp_solver_used": True,
        "greedy_selector_used": False,
        "hard_exposure_caps_inside_optimizer": True,
        "post_freeze_pool_expansion": False,
        "metric_tick_scale": METRIC_TICK_SCALE,
        "objective_tick_totals": objective_ticks,
        "candidate_rows": len(rows),
        "eligible_rows": int(eligibility.sum()),
        "player_cap_constraints": player_constraint_count,
        "pairwise_conflict_constraints": len(conflict_pairs),
        "overlap_clique_constraints": len(seeded_overlap_cliques),
        "seeded_overlap_clique_constraints": len(seeded_overlap_cliques),
        "conflict_generation_exact": True,
        "conflict_generation_rounds": conflict_generation_rounds,
        "milp_calls": milp_calls,
    }
    return full_order, selected, proof


def validate_optimizer_proof(
    proof: Any,
    *,
    candidate_rows: int,
) -> None:
    if (
        not isinstance(proof, dict)
        or proof.get("selector_optimizer") != OPTIMIZER_POLICY
        or proof.get("optimization_status") != "OPTIMAL"
        or proof.get("milp_solver_used") is not True
        or proof.get("greedy_selector_used") is not False
        or proof.get("hard_exposure_caps_inside_optimizer") is not True
        or proof.get("post_freeze_pool_expansion") is not False
        or int(proof.get("candidate_rows", -1)) != candidate_rows
    ):
        raise SystemExit("RUN_INVALID: AI_SELECTOR_OPTIMIZER_PROOF_INVALID")


def validate_selected_constraints(
    rows: Iterable[dict[str, Any]],
    *,
    selected_ids: Sequence[str],
    id_field: str,
    slots: Sequence[str],
    target_rows: int,
    max_pairwise_overlap: int,
    player_max_lineups: dict[str, int],
    player_min_lineups: dict[str, int] | None = None,
    roster_validator: Callable[[tuple[str, ...]], bool] | None = None,
) -> dict[str, int]:
    """Validate hard portfolio constraints without re-selecting or re-ranking."""
    by_id = {str(row[id_field]): row for row in rows}
    if (
        len(selected_ids) != target_rows
        or len(set(selected_ids)) != target_rows
        or any(lineup_id not in by_id for lineup_id in selected_ids)
    ):
        raise SystemExit("RUN_INVALID: AI_SELECTION_MEMBERSHIP_OR_COUNT_INVALID")
    rosters: list[set[str]] = []
    exposure = {player_id: 0 for player_id in player_max_lineups}
    for lineup_id in selected_ids:
        roster_tuple = tuple(
            str(by_id[lineup_id][slot]) for slot in slots
        )
        if (
            len(set(roster_tuple)) != len(slots)
            or any(
                player_id not in player_max_lineups
                for player_id in roster_tuple
            )
            or (
                roster_validator is not None
                and not roster_validator(roster_tuple)
            )
        ):
            raise SystemExit("RUN_INVALID: AI_SELECTION_ANON_ROSTER_INVALID")
        roster = set(roster_tuple)
        if any(
            len(roster & prior) > max_pairwise_overlap
            for prior in rosters
        ):
            raise SystemExit("RUN_INVALID: AI_SELECTION_OVERLAP_CAP_BREACH")
        rosters.append(roster)
        for player_id in roster:
            exposure[player_id] += 1
            if exposure[player_id] > int(player_max_lineups[player_id]):
                raise SystemExit(
                    "RUN_INVALID: AI_SELECTION_EXPOSURE_CAP_BREACH"
                )
    for player_id, minimum in (player_min_lineups or {}).items():
        if exposure.get(player_id, 0) < int(minimum):
            raise SystemExit("RUN_INVALID: AI_SELECTION_EXPOSURE_MIN_BREACH")
    return exposure
