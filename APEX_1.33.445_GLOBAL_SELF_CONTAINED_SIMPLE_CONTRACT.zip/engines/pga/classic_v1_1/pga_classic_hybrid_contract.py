#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import math
import re
import sys
from pathlib import Path
from typing import Any, Sequence

for _parent in Path(__file__).resolve().parents:
    if (_parent / "global_portfolio_optimizer.py").is_file():
        sys.path.insert(0, str(_parent))
        break
from global_portfolio_optimizer import (
    OPTIMIZER_POLICY,
    locked_order,
    optimize_portfolio,
    validate_optimizer_proof,
    validate_selected_constraints,
)


SELECTION_METRICS = (
    "ALL_SIX_SURVIVE_RATE",
    "FIRST_PLACE_RATE",
    "TOP_0_1_PERCENT_RATE",
    "TOP_1_PERCENT_RATE",
    "TOURNAMENT_P999",
    "TOURNAMENT_CVAR99",
)
OBJECTIVES = tuple((field, "MAX") for field in SELECTION_METRICS)
PUZZLE_ID = "GLOBAL_ANON_MC_FIELD_SIZE_CONSTRAINT_PACKING_v1_0"
ROUTE = "PGA_CLASSIC_BUNDLED_ENGINE"
SELECTOR = "PGA_CLASSIC_ANON_MC_PUZZLE_SELECTOR_v1_0"
SLOTS = ("G1", "G2", "G3", "G4", "G5", "G6")


def sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _write_csv(path: Path, rows: Sequence[dict[str, Any]], fields: Sequence[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _read_csv(path: Path) -> tuple[list[dict[str, str]], list[str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        return list(reader), list(reader.fieldnames or [])


def hybrid_health() -> dict[str, Any]:
    return {
        "HYBRID_CONTRACT_COMPILER_READY": True,
        "HYBRID_CONTRACT_PREFLIGHT_STAGE": "PRE_PHASE1_MC",
        "COMPLETED_RUN_SOLVER": "CODE_AI_HYBRID",
        "AI_SELECTOR": True,
        "AI_HANDOFF_PLAYER_IDENTITIES": "ANONYMIZED_PLAYER_IDS",
        "AI_HANDOFF_PLAYER_NAMES_PRESENT": False,
        "AI_HANDOFF_RAW_PROJECTIONS_PRESENT": False,
        "AI_HANDOFF_RAW_SALARY_PRESENT": False,
        "AI_HANDOFF_RAW_OWNERSHIP_PRESENT": False,
        "AI_HANDOFF_FEATURE_SCOPE": "MONTE_CARLO_OUTPUTS_PLUS_ANON_IDS_AND_HARD_CONSTRAINTS",
        "AI_ROLE": "STRICT_DATA_PROCESSOR",
        "DIVERSITY_PUZZLE_ID": PUZZLE_ID,
        "FINAL_PORTFOLIO_OPTIMIZER": OPTIMIZER_POLICY,
        "GREEDY_FINAL_SELECTOR": False,
        "HARD_EXPOSURE_CAPS_INSIDE_OPTIMIZER": True,
        "LINEUP_BUILD_METHOD": "CALIBRATION_INFORMED",
        "PHASE2_BUILDER_CONSUMED_CALIBRATION": True,
    }


def write_contract(
    *,
    out: Path,
    golfers: Sequence[Any],
    lineups: Any,
    metrics: Sequence[dict[str, Any]],
    target_rows: int,
    public_field_size: int,
) -> dict[str, Any]:
    if public_field_size < 2:
        raise RuntimeError("RUN_BLOCKED: PUBLIC_FIELD_SIZE_NOT_PROVEN")
    if not 1 <= target_rows <= 10 or len(metrics) < target_rows:
        raise RuntimeError("RUN_INVALID: PGA_CLASSIC_HYBRID_CONTRACT_DIMENSION_INVALID")

    player_ids = [f"G{index + 1:04d}" for index in range(len(golfers))]
    identity_rows = [
        {"PLAYER_ID": player_ids[index], "PLAYER": golfer.name}
        for index, golfer in enumerate(golfers)
    ]
    _write_csv(out / "player_identity_map.csv", identity_rows, ("PLAYER_ID", "PLAYER"))

    handoff_rows: list[dict[str, Any]] = []
    lookup_rows: list[dict[str, Any]] = []
    for metric in metrics:
        lineup = lineups[int(metric["_INDEX"])]
        lineup_id = str(metric["LINEUP_ID"])
        handoff_rows.append({
            "LINEUP_ID": lineup_id,
            **{slot: player_ids[int(lineup[index])] for index, slot in enumerate(SLOTS)},
            "CODE_ELIGIBLE": int(
                float(metric["FIRST_PLACE_RATE"]) > 0
                or float(metric["TOP_0_1_PERCENT_RATE"]) > 0
            ),
            **{field: metric[field] for field in SELECTION_METRICS},
        })
        lookup_rows.append({"LINEUP_ID": lineup_id, "SALARY": int(metric["SALARY"])})
    _write_csv(
        out / "phase3_95_ai_handoff.csv",
        handoff_rows,
        ("LINEUP_ID", *SLOTS, "CODE_ELIGIBLE", *SELECTION_METRICS),
    )
    _write_csv(out / "sealed_lineup_lookup.csv", lookup_rows, ("LINEUP_ID", "SALARY"))

    roster_size = len(SLOTS)
    required_difference = min(
        roster_size,
        max(1, math.ceil(math.log2(public_field_size) / roster_size)),
    )
    max_overlap = roster_size - required_difference
    global_max = max(1, math.ceil(target_rows * max_overlap / roster_size))
    player_max = {
        player_ids[index]: min(
            global_max,
            max(1, math.floor(float(golfer.max_exposure) * target_rows + 1e-12)),
        )
        for index, golfer in enumerate(golfers)
    }
    player_min = {
        player_ids[index]: min(
            player_max[player_ids[index]],
            max(0, math.ceil(float(golfer.min_exposure) * target_rows - 1e-12)),
        )
        for index, golfer in enumerate(golfers)
    }
    puzzle = {
        "DIVERSITY_PUZZLE_ID": PUZZLE_ID,
        "ROUTE": ROUTE,
        "ROSTER_SIZE": roster_size,
        "FIELD_SIZE": public_field_size,
        "TARGET_ROWS": target_rows,
        "REQUIRED_PAIRWISE_DIFFERENCE": required_difference,
        "MAX_PAIRWISE_OVERLAP": max_overlap,
        "GLOBAL_MAX_PLAYER_LINEUPS": global_max,
        "PLAYER_MIN_LINEUPS": player_min,
        "PLAYER_MAX_LINEUPS": player_max,
        "SEALED_EXPOSURE_BOUNDS": True,
        "MANUAL_OR_PREFERENCE_DIVERSITY": False,
        "SELECTION_SCOPE": "FROZEN_ANONYMOUS_MC_HANDOFF",
        "SELECTION_POLICY": SELECTOR,
        "OBJECTIVE": list(SELECTION_METRICS),
        "PLAYER_IDENTITY_MAP_SHA256": sha256(out / "player_identity_map.csv"),
        "SEALED_LINEUP_LOOKUP_SHA256": sha256(out / "sealed_lineup_lookup.csv"),
    }
    puzzle_path = out / "phase3_95_ai_puzzle.json"
    puzzle_path.write_text(json.dumps(puzzle, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return {
        **hybrid_health(),
        "FIELD_SIZE": public_field_size,
        "AI_HANDOFF_ROWS": len(handoff_rows),
        "AI_HANDOFF_SHA256": sha256(out / "phase3_95_ai_handoff.csv"),
        "AI_PUZZLE_SHA256": sha256(puzzle_path),
        "PLAYER_IDENTITY_MAP_SHA256": sha256(out / "player_identity_map.csv"),
        "SEALED_LINEUP_LOOKUP_SHA256": sha256(out / "sealed_lineup_lookup.csv"),
        "HYBRID_CONTRACT_ARTIFACT_BUILD": "PASS",
    }


def _load_puzzle(path: Path) -> dict[str, Any]:
    puzzle = json.loads(path.read_text(encoding="utf-8"))
    if (
        puzzle.get("DIVERSITY_PUZZLE_ID") != PUZZLE_ID
        or puzzle.get("ROUTE") != ROUTE
        or puzzle.get("SELECTION_POLICY") != SELECTOR
        or puzzle.get("OBJECTIVE") != list(SELECTION_METRICS)
        or int(puzzle.get("ROSTER_SIZE", 0)) != len(SLOTS)
        or puzzle.get("MANUAL_OR_PREFERENCE_DIVERSITY") is not False
        or puzzle.get("SEALED_EXPOSURE_BOUNDS") is not True
    ):
        raise SystemExit("RUN_INVALID: PGA_CLASSIC_AI_PUZZLE_CONTRACT_BREACH")
    return puzzle


def _load_handoff(path: Path) -> list[dict[str, str]]:
    rows, fields = _read_csv(path)
    expected = {"LINEUP_ID", *SLOTS, "CODE_ELIGIBLE", *SELECTION_METRICS}
    if not rows or set(fields) != expected:
        raise SystemExit("RUN_INVALID: PGA_CLASSIC_AI_HANDOFF_SCHEMA_BREACH")
    if any(
        not re.fullmatch(r"G[0-9]+", row[slot])
        for row in rows
        for slot in SLOTS
    ) or any(row["CODE_ELIGIBLE"] not in {"0", "1"} for row in rows):
        raise SystemExit("RUN_INVALID: PGA_CLASSIC_AI_HANDOFF_ANON_OR_ELIGIBILITY_BREACH")
    return rows


def build_selection_packet(
    *,
    handoff: Path,
    puzzle_path: Path,
    identity_map_sha256: str,
    output: Path,
) -> dict[str, Any]:
    if not re.fullmatch(r"[0-9a-f]{64}", identity_map_sha256):
        raise SystemExit("RUN_INVALID: PLAYER_IDENTITY_MAP_SHA256_INVALID")
    puzzle = _load_puzzle(puzzle_path)
    if puzzle["PLAYER_IDENTITY_MAP_SHA256"] != identity_map_sha256:
        raise SystemExit("RUN_INVALID: PLAYER_IDENTITY_MAP_SHA256_MISMATCH")
    rows = _load_handoff(handoff)
    full_order, selected, optimizer_proof = optimize_portfolio(
        rows,
        id_field="LINEUP_ID",
        slots=SLOTS,
        objectives=OBJECTIVES,
        target_rows=int(puzzle["TARGET_ROWS"]),
        max_pairwise_overlap=int(puzzle["MAX_PAIRWISE_OVERLAP"]),
        player_max_lineups={str(k): int(v) for k, v in puzzle["PLAYER_MAX_LINEUPS"].items()},
        player_min_lineups={str(k): int(v) for k, v in puzzle["PLAYER_MIN_LINEUPS"].items()},
        eligible=[row["CODE_ELIGIBLE"] == "1" for row in rows],
    )
    payload = {
        "handoff_sha256": sha256(handoff),
        "ai_puzzle_sha256": sha256(puzzle_path),
        "player_identity_map_sha256": identity_map_sha256,
        "ai_review_coverage": "100_PERCENT",
        "selection_policy": SELECTOR,
        "selection_metrics": list(SELECTION_METRICS),
        "ai_full_ordered_lineup_ids": full_order,
        "selected_lineup_ids": selected,
        "optimizer_proof": optimizer_proof,
    }
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return {
        "AI_SELECTION_PACKET": "PASS",
        "AI_FULL_ORDER_ROWS": len(full_order),
        "AI_SELECTED_ROWS": len(selected),
        "SELECTOR_OPTIMIZER": OPTIMIZER_POLICY,
        "OPTIMIZATION_STATUS": "OPTIMAL",
        "GREEDY_SELECTOR_USED": False,
        "SELECTION_SHA256": sha256(output),
    }


def finalize_selection(
    *,
    handoff: Path,
    selection_path: Path,
    puzzle_path: Path,
    identity_map_path: Path,
    output: Path,
) -> dict[str, Any]:
    selection = json.loads(selection_path.read_text(encoding="utf-8"))
    puzzle = _load_puzzle(puzzle_path)
    rows = _load_handoff(handoff)
    expected_order = locked_order(rows, id_field="LINEUP_ID", objectives=OBJECTIVES)
    full_order = selection.get("ai_full_ordered_lineup_ids")
    selected = selection.get("selected_lineup_ids")
    if (
        selection.get("handoff_sha256") != sha256(handoff)
        or selection.get("ai_puzzle_sha256") != sha256(puzzle_path)
        or selection.get("player_identity_map_sha256") != sha256(identity_map_path)
        or selection.get("selection_policy") != SELECTOR
        or selection.get("selection_metrics") != list(SELECTION_METRICS)
        or selection.get("ai_review_coverage") != "100_PERCENT"
        or full_order != expected_order
        or not isinstance(selected, list)
        or selected != [lineup_id for lineup_id in full_order if lineup_id in set(selected)]
    ):
        raise SystemExit("RUN_INVALID: PGA_CLASSIC_AI_HANDOFF_PROOF_OR_ORDER_MISMATCH")
    validate_optimizer_proof(selection.get("optimizer_proof"), candidate_rows=len(rows))
    exposure = validate_selected_constraints(
        rows,
        selected_ids=selected,
        id_field="LINEUP_ID",
        slots=SLOTS,
        target_rows=int(puzzle["TARGET_ROWS"]),
        max_pairwise_overlap=int(puzzle["MAX_PAIRWISE_OVERLAP"]),
        player_max_lineups={str(k): int(v) for k, v in puzzle["PLAYER_MAX_LINEUPS"].items()},
        player_min_lineups={str(k): int(v) for k, v in puzzle["PLAYER_MIN_LINEUPS"].items()},
    )
    map_rows, map_fields = _read_csv(identity_map_path)
    if set(map_fields) != {"PLAYER_ID", "PLAYER"}:
        raise SystemExit("RUN_INVALID: PLAYER_IDENTITY_MAP_SCHEMA_INVALID")
    identity = {row["PLAYER_ID"]: row["PLAYER"] for row in map_rows}
    lookup_path = handoff.with_name("sealed_lineup_lookup.csv")
    lookup_rows, lookup_fields = _read_csv(lookup_path)
    if (
        set(lookup_fields) != {"LINEUP_ID", "SALARY"}
        or sha256(lookup_path) != puzzle["SEALED_LINEUP_LOOKUP_SHA256"]
    ):
        raise SystemExit("RUN_INVALID: SEALED_LINEUP_LOOKUP_INVALID")
    salary = {row["LINEUP_ID"]: row["SALARY"] for row in lookup_rows}
    by_id = {row["LINEUP_ID"]: row for row in rows}
    rendered = [
        {
            "BOARD_RANK": rank,
            "LINEUP_ID": lineup_id,
            **{slot: identity[by_id[lineup_id][slot]] for slot in SLOTS},
            "SALARY": int(float(salary[lineup_id])),
        }
        for rank, lineup_id in enumerate(selected, 1)
    ]
    _write_csv(output, rendered, ("BOARD_RANK", "LINEUP_ID", *SLOTS, "SALARY"))
    proof = {
        "AI_SELECTION": "PASS",
        "AI_SELECTOR_STATUS": "ACTIVE",
        "AI_AUTHORITY_AFTER_HANDOFF": "100_PERCENT",
        "CODE_AFTER_HANDOFF": "LOOKUP_LEGALITY_HASH_ONLY",
        "SELECTOR_OPTIMIZER": OPTIMIZER_POLICY,
        "OPTIMIZATION_STATUS": "OPTIMAL",
        "MILP_SOLVER_USED": True,
        "GREEDY_SELECTOR_USED": False,
        "HARD_EXPOSURE_CAPS_INSIDE_OPTIMIZER": True,
        "POST_FREEZE_POOL_EXPANSION": False,
        "FINAL_BOARD_ROWS": len(rendered),
        "EARNED_FINAL_BOARD_ROWS": int(puzzle["TARGET_ROWS"]),
        "FINAL_BOARD_RETENTION_COUNT_MATCH": True,
        "FINAL_BOARD_FILLERS_ALLOWED": False,
        "FINAL_BOARD_FILLER_ROWS": 0,
        "FINAL_RENDER_FORMAT": "FIXED_ROSTER_COLUMNS",
        "FINAL_RENDER_SCHEMA": list(SLOTS),
        "JUMBLED_COLUMNS": False,
        "MAX_FINAL_PLAYER_EXPOSURE": max(exposure.values()),
        "FINAL_MATRIX_SHA256": sha256(output),
    }
    receipt_path = handoff.with_name("execution_receipt.json")
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    receipt.update(proof)
    receipt["PHASE_3_95_PROOF"] = "TOOL_PROVEN_CODE_AI_HYBRID"
    receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return proof
