#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from pga_classic_hybrid_contract import finalize_selection


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--handoff", required=True)
    parser.add_argument("--selection", required=True)
    parser.add_argument("--puzzle", required=True)
    parser.add_argument("--identity-map", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    proof = finalize_selection(
        handoff=Path(args.handoff),
        selection_path=Path(args.selection),
        puzzle_path=Path(args.puzzle),
        identity_map_path=Path(args.identity_map),
        output=Path(args.output),
    )
    print(json.dumps(proof, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
