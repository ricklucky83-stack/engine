#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from pga_classic_hybrid_contract import build_selection_packet


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--handoff", required=True)
    parser.add_argument("--puzzle", required=True)
    parser.add_argument("--identity-map-sha256", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    proof = build_selection_packet(
        handoff=Path(args.handoff),
        puzzle_path=Path(args.puzzle),
        identity_map_sha256=args.identity_map_sha256,
        output=Path(args.output),
    )
    print(json.dumps(proof, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
