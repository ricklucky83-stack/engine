#!/usr/bin/env python3
"""Shared bounded-memory NumPy kernels for bundled APEX engines."""

from __future__ import annotations

import hashlib
import itertools
import math
from pathlib import Path
from typing import Iterable, Iterator

import numpy as np


PERFORMANCE_PATCH = "APEX_GLOBAL_FAST_PATH_CORE_v1_0"


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def iter_combination_blocks(
    pool: Iterable[int],
    choose: int,
    *,
    block_rows: int = 262_144,
    dtype: np.dtype | type = np.int32,
) -> Iterator[np.ndarray]:
    """Yield exhaustive combinations in compact matrices without a Python row list."""

    values = tuple(int(value) for value in pool)
    if choose <= 0 or choose > len(values) or block_rows <= 0:
        return
    source = itertools.combinations(values, choose)
    while True:
        block = list(itertools.islice(source, block_rows))
        if not block:
            return
        yield np.asarray(block, dtype=dtype)


def combination_matrix(
    pool: Iterable[int],
    choose: int,
    *,
    max_rows: int = 2_000_000,
    dtype: np.dtype | type = np.int32,
) -> np.ndarray:
    values = tuple(int(value) for value in pool)
    rows = math.comb(len(values), choose) if 0 <= choose <= len(values) else 0
    if rows <= 0:
        return np.empty((0, max(choose, 0)), dtype=dtype)
    if rows > max_rows:
        raise MemoryError(f"combination rows {rows} exceed bounded maximum {max_rows}")
    iterator = itertools.chain.from_iterable(itertools.combinations(values, choose))
    flat = np.fromiter(iterator, dtype=dtype, count=rows * choose)
    return flat.reshape(rows, choose)


def showdown_matrix(
    pool: Iterable[int],
    *,
    roster_size: int = 6,
    max_base_rows: int = 2_000_000,
    dtype: np.dtype | type = np.int32,
) -> np.ndarray:
    """Expand each unordered roster into every deterministic Captain assignment."""

    base = combination_matrix(pool, roster_size, max_rows=max_base_rows, dtype=dtype)
    if not len(base):
        return np.empty((0, roster_size), dtype=dtype)
    rows = len(base)
    expanded = np.empty((rows * roster_size, roster_size), dtype=dtype)
    for captain_slot in range(roster_size):
        start = captain_slot * rows
        stop = start + rows
        expanded[start:stop, 0] = base[:, captain_slot]
        util_slots = [slot for slot in range(roster_size) if slot != captain_slot]
        expanded[start:stop, 1:] = base[:, util_slots]
    return expanded


def unique_player_mask(matrix: np.ndarray) -> np.ndarray:
    if matrix.ndim != 2:
        raise ValueError("matrix must be two-dimensional")
    if matrix.shape[1] <= 1:
        return np.ones(matrix.shape[0], dtype=bool)
    ordered = np.sort(matrix, axis=1)
    return np.all(np.diff(ordered, axis=1) > 0, axis=1)


def stable_unique_rows(matrix: np.ndarray) -> np.ndarray:
    if not len(matrix):
        return matrix
    _, indices = np.unique(matrix, axis=0, return_index=True)
    return matrix[np.sort(indices)]


def team_count_mask(team_codes: np.ndarray, lineups: np.ndarray, maximum: int) -> np.ndarray:
    selected = team_codes[lineups]
    valid = np.ones(len(lineups), dtype=bool)
    for code in np.unique(team_codes):
        valid &= np.sum(selected == code, axis=1) <= maximum
    return valid


def both_teams_mask(team_codes: np.ndarray, lineups: np.ndarray) -> np.ndarray:
    selected = team_codes[lineups]
    return np.min(selected, axis=1) != np.max(selected, axis=1)


def score_lineup_block(
    worlds: np.ndarray,
    lineups: np.ndarray,
    *,
    multipliers: np.ndarray | None = None,
) -> np.ndarray:
    """Fused gather-and-sum into a single simulation-by-lineup buffer."""

    if worlds.ndim != 2 or lineups.ndim != 2 or lineups.shape[1] == 0:
        raise ValueError("invalid world or lineup matrix")
    weights = np.ones(lineups.shape[1], dtype=np.float32) if multipliers is None else np.asarray(multipliers, dtype=np.float32)
    if weights.shape != (lineups.shape[1],):
        raise ValueError("multiplier shape mismatch")
    output = np.multiply(worlds[:, lineups[:, 0]], weights[0], dtype=np.float32)
    for slot in range(1, lineups.shape[1]):
        if weights[slot] == 1.0:
            np.add(output, worlds[:, lineups[:, slot]], out=output)
        else:
            output += worlds[:, lineups[:, slot]] * weights[slot]
    return output
