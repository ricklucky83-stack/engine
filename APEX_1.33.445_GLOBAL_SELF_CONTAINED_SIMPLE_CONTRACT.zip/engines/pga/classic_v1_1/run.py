#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from engine import ENGINE_ID, ENGINE_VERSION, PGA_PLAYER_SPIKE_MODEL_PATCH_ID, EngineError, execute, load_pool
from pga_classic_hybrid_contract import hybrid_health
from engines.common.universal_prebuild_availability_gate_v1 import validate_prebuild_availability_receipt


ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "config" / "default.json"


def health() -> dict[str, object]:
    return {
        "SKILL_NAME": "APEX PGA Classic Engine",
        "SKILL_ID": "apex-pga-classic-engine",
        "ENGINE_ID": ENGINE_ID,
        "ENGINE_VERSION": ENGINE_VERSION,
        "MODE": "PGA_CLASSIC",
        "ROUTE": "PGA_CLASSIC_BUNDLED_ENGINE",
        "HEALTH_TEST": "PASS",
        "MONTE_CARLO": "ACTIVE",
        "MC_PASSES": 2,
        "SCORING_HORIZON": "FOUR_ROUNDS",
        "OUTCOME_LAYER": "PGA_FOUR_ROUND_SURVIVAL_FIRST_v1_0",
        "ALL_SIX_SURVIVE_RATE_PRIMARY": True,
        "CUT_SURVIVAL_RANKING_WEIGHT": "PRIMARY",
        "MEAN_SELECTION_WEIGHT": 0,
        "FILE_PROJECTION_SELECTION_WEIGHT": 0,
        "CURRENT_ELIGIBILITY_REQUIRED": True,
        "HISTORICAL_CUT_FIELDS_AS_LIVE_STATUS": False,
        "PHASE1_CALIBRATION_CREATED_BEFORE_LINEUP_BIRTH": True,
        "LINEUP_BUILD_METHOD": "CALIBRATION_INFORMED",
        "PHASE2_BUILDER_CONSUMED_CALIBRATION": True,
        "RANDOM_OR_FIRST_N_BUILD": False,
        "PHASE3_EVALUATES_EVERY_FROZEN_ROW": True,
        "PHASE2_HANDOFF_SELECTOR_SET_EQUAL_REQUIRED": True,
        "HANDOFF_COMPRESSION_ALLOWED": False,
        "GLOBAL_SPORTS_STRATEGY_SOURCE_WIRED": True,
        "PREDICTIVE_MARKET_LAYER_SOURCE_WIRED": True,
        "PREDICTION_HASH_FREEZE_REQUIRED": True,
        "PREDICTIVE_POSTLOCK_INPUT_PROHIBITED": True,
        "PREDICTIVE_RAW_AGGREGATE_PROJECTION_TO_PHASE1_PROHIBITED": True,
        "PGA_PLAYER_SPIKE_MODEL_SOURCE_WIRED": True,
        "PGA_PLAYER_SPIKE_MODEL_PATCH_ID": PGA_PLAYER_SPIKE_MODEL_PATCH_ID,
        "PGA_PLAYER_SPIKE_POSTLOCK_INPUT_PROHIBITED": True,
        "PGA_PLAYER_SPIKE_PHASE2_ADMISSION": False,
        "PGA_PLAYER_SPIKE_FRONTIER_ROLE": "SHADOW_RESEARCH_NONSELECTING",
        "SPORT_STRATEGY_LOAD_ORDER": "AFTER_AVAILABILITY_RECONCILIATION_AND_PREDICTION_FREEZE_BEFORE_PHASE1_CALIBRATION",
        "FASTEST_CODING_METHODS_ONLY": True,
        "PYTHON_PER_LINEUP_SCORING": False,
        "DENSE_PLAYER_LINEUP_MATRIX": False,
        "BOUNDED_MEMORY": True,
        "FINAL_BOARD_FILLERS_ALLOWED": False,
        "FINAL_RENDER_FORMAT": "FIXED_ROSTER_COLUMNS",
        "JUMBLED_COLUMNS": False,
        **hybrid_health(),
    }


def complete_hybrid(output_dir: str | Path) -> dict[str, object]:
    root = Path(output_dir)
    scripts = Path(__file__).resolve().parent
    receipt_path = root / "execution_receipt.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    selector_gate = validate_prebuild_availability_receipt(
        root / "prebuild_availability_receipt.json",
        sport="PGA",
        mode="CLASSIC",
        pool_path=receipt["INPUT_PATH"],
        execution_id=receipt["SEED"],
        field_size=receipt["PUBLIC_FIELD_SIZE"],
        final_selector_recheck=True,
    )
    receipt["FINAL_SELECTOR_AVAILABILITY"] = selector_gate.to_receipt()
    receipt["FINAL_SELECTOR_AVAILABILITY_RECHECK"] = "PASS"
    receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    commands = (
        [
            sys.executable,
            str(scripts / "build_ai_selection.py"),
            "--handoff", str(root / "phase3_95_ai_handoff.csv"),
            "--puzzle", str(root / "phase3_95_ai_puzzle.json"),
            "--identity-map-sha256", str(receipt["PLAYER_IDENTITY_MAP_SHA256"]),
            "--output", str(root / "ai_selection.json"),
        ],
        [
            sys.executable,
            str(scripts / "finalize_hybrid.py"),
            "--handoff", str(root / "phase3_95_ai_handoff.csv"),
            "--selection", str(root / "ai_selection.json"),
            "--puzzle", str(root / "phase3_95_ai_puzzle.json"),
            "--identity-map", str(root / "player_identity_map.csv"),
            "--output", str(root / "final_execution_matrix.csv"),
        ],
    )
    for command in commands:
        result = subprocess.run(command, check=False, capture_output=True, text=True)
        if result.returncode:
            raise EngineError(
                (result.stderr or result.stdout).strip()
                or "RUN_INVALID: PGA_CLASSIC_HYBRID_SELECTOR_STAGE_FAILED"
            )
    return json.loads(receipt_path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("health")
    validate = sub.add_parser("validate")
    validate.add_argument("--input", required=True)
    validate.add_argument("--eligibility-file", required=True)
    validate.add_argument("--config", default=str(DEFAULT_CONFIG))
    run = sub.add_parser("execute")
    run.add_argument("--input", required=True)
    run.add_argument("--eligibility-file", required=True)
    run.add_argument("--output-dir", required=True)
    run.add_argument("--config", default=str(DEFAULT_CONFIG))
    run.add_argument("--seed", required=True, type=int)
    run.add_argument("--simulations", required=True, type=int)
    run.add_argument("--field-size", required=True, type=int)
    args = parser.parse_args()
    try:
        if args.command == "health":
            receipt = health()
        elif args.command == "validate":
            golfers, meta = load_pool(args.input, args.eligibility_file)
            receipt = {
                "STATUS": "VALID",
                "MODE": "PGA_CLASSIC",
                **meta,
                "ACTIVE_GOLFERS": [golfer.name for golfer in golfers],
            }
        else:
            execute(
                args.input,
                args.output_dir,
                args.config,
                args.seed,
                args.simulations,
                args.eligibility_file,
                args.field_size,
            )
            receipt = complete_hybrid(args.output_dir)
        print(json.dumps(receipt, sort_keys=True))
        return 0
    except (EngineError, OSError, KeyError, json.JSONDecodeError, RuntimeError, MemoryError) as exc:
        print(str(exc))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
