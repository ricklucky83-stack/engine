from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
import unicodedata
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Sequence

import numpy as np

for _parent in Path(__file__).resolve().parents:
    if (_parent / "performance_core.py").is_file():
        sys.path.insert(0, str(_parent))
        break
sys.path.insert(0, str(Path(__file__).resolve().parent))
from performance_core import combination_matrix
from pga_classic_hybrid_contract import SELECTION_METRICS, write_contract

STATE_ROOT = Path(__file__).resolve().parents[3]
if str(STATE_ROOT) not in sys.path:
    sys.path.insert(0, str(STATE_ROOT))
try:
    from engines.common.apex_global_sports_strategy_layer_v1 import (
        PREDICTIVE_LAYER_PATCH_ID,
        build_strategy_features,
    )
    from engines.common.build_prebuild_availability_receipt_v1 import build_receipt as build_availability_receipt
    from engines.common.universal_prebuild_availability_gate_v1 import validate_prebuild_availability_receipt
except (ImportError, ModuleNotFoundError) as exc:
    raise RuntimeError("RUN_INVALID: PGA_CLASSIC_GLOBAL_GATE_SOURCE_UNAVAILABLE") from exc


PLAYER_LEVEL_MC_TOURNAMENT = "ACTIVE"
LINEUP_BIRTH_FROM_SURVIVORS_ONLY = True
GENERALIZED_BINOMIAL_OUTCOME_STAT_LAYER = "PGA_FOUR_ROUND_SURVIVAL_FIRST_v1_0"
ENGINE_ID = "APEX_PGA_CLASSIC_BUNDLED_ENGINE_v1_1"
ENGINE_VERSION = "1.1.5"
PGA_PLAYER_SPIKE_MODEL_PATCH_ID = "PGA_CLASSIC_PLAYER_SPIKE_PROBABILITY_MODEL_v1"
PGA_PROXY_STRATEGY_HANDOFF_PATCH_ID = "PGA_CLASSIC_PROXY_PROJECTION_STRATEGY_HANDOFF_FIX_v1"


class EngineError(RuntimeError):
    pass


@dataclass(frozen=True)
class Golfer:
    uid: str
    name: str
    salary: int
    projection: float
    ceiling: float
    ownership: float | None
    min_exposure: float
    max_exposure: float
    wave: str
    cut_probability: float
    top10_rate: float
    top3_rate: float
    projection_source: str = "FILE"
    strategy_opportunity_score: float = 0.0
    strategy_role_credibility: float = 1.0
    strategy_salary_unlock: bool = False
    strategy_stale_role_suppressed: bool = False
    strategy_direct_opportunity_absorber: bool = False
    strategic_leverage: float = 0.0
    prelock_spike_prior_score: float = 0.5
    spike_input_coverage: float = 0.0


def _number(value: Any, default: float | None = None) -> float:
    text = "" if value is None else str(value).strip().replace(",", "")
    if not text:
        if default is None:
            raise EngineError("RUN_BLOCKED: REQUIRED_NUMERIC_INPUT_MISSING")
        return default
    percent = text.endswith("%")
    if percent:
        text = text[:-1]
    try:
        result = float(text)
    except ValueError as exc:
        raise EngineError("RUN_BLOCKED: INVALID_NUMERIC_INPUT") from exc
    return result / 100.0 if percent else result


def _column(fields: set[str], *names: str) -> str | None:
    lookup = {field.upper(): field for field in fields}
    return next((lookup[name.upper()] for name in names if name.upper() in lookup), None)


def sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _array_sha256(value: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def _lineup_id_set_sha256(rows: Sequence[dict[str, Any]]) -> str:
    payload = "\n".join(sorted(str(row["LINEUP_ID"]) for row in rows)).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _normalized_name(value: Any) -> str:
    text = unicodedata.normalize("NFKD", str(value)).encode("ascii", "ignore").decode("ascii").upper()
    return " ".join("".join(ch if ch.isalnum() else " " for ch in text.replace("(A)", "")).split())


def _write_csv(path: Path, rows: Sequence[dict[str, Any]], fields: Sequence[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _load_eligibility_snapshot(path: str | Path) -> tuple[dict[str, dict[str, str]], dict[str, Any]]:
    source = Path(path)
    with source.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        fields = set(reader.fieldnames or [])
    player_col = _column(fields, "PLAYER", "NAME")
    status_col = _column(fields, "STATUS", "PLAYER STATUS", "PLAYER_STATUS")
    active_col = _column(fields, "ACTIVE", "IS_ACTIVE")
    source_col = _column(fields, "SOURCE_URL", "SOURCE")
    retrieved_col = _column(fields, "RETRIEVED_AT_UTC", "RETRIEVED_AT")
    event_col = _column(fields, "EVENT", "TOURNAMENT")
    if not rows or not player_col or not (status_col or active_col) or not source_col or not retrieved_col or not event_col:
        raise EngineError("RUN_BLOCKED: PGA_ELIGIBILITY_SNAPSHOT_CONTRACT_BREACH")
    mapping: dict[str, dict[str, str]] = {}
    for row in rows:
        key = _normalized_name(row.get(player_col, ""))
        required = (source_col, retrieved_col, event_col)
        if not key or key in mapping or not all(str(row.get(column, "")).strip() for column in required):
            raise EngineError("RUN_BLOCKED: PGA_ELIGIBILITY_SNAPSHOT_CONTRACT_BREACH")
        mapping[key] = {
            "STATUS": str(row.get(status_col, "") if status_col else "").strip(),
            "ACTIVE": str(row.get(active_col, "") if active_col else "").strip(),
        }
    return mapping, {
        "ELIGIBILITY_SNAPSHOT_SHA256": sha256(source),
        "ELIGIBILITY_SOURCE_URL": str(rows[0][source_col]).strip(),
        "ELIGIBILITY_RETRIEVED_AT_UTC": str(rows[0][retrieved_col]).strip(),
        "ELIGIBILITY_EVENT": str(rows[0][event_col]).strip(),
        "ELIGIBILITY_ROWS": len(rows),
    }


def _build_prebuild_gate(
    *,
    pool_path: str | Path,
    eligibility_path: str | Path,
    out: Path,
    execution_id: int,
    field_size: int,
) -> dict[str, Any]:
    with Path(pool_path).open(newline="", encoding="utf-8-sig") as handle:
        pool_reader = csv.DictReader(handle)
        pool_rows = list(pool_reader)
        pool_fields = set(pool_reader.fieldnames or [])
    player_col = _column(pool_fields, "PLAYER", "NAME")
    if not player_col:
        raise EngineError("RUN_BLOCKED: REQUIRED_COLUMNS_PLAYER_SALARY_FPTS_MISSING")
    with Path(eligibility_path).open(newline="", encoding="utf-8-sig") as handle:
        eligibility_reader = csv.DictReader(handle)
        eligibility_rows = list(eligibility_reader)
        eligibility_fields = set(eligibility_reader.fieldnames or [])
    eligibility_player_col = _column(eligibility_fields, "PLAYER", "NAME")
    status_col = _column(eligibility_fields, "STATUS", "PLAYER STATUS", "PLAYER_STATUS")
    active_col = _column(eligibility_fields, "ACTIVE", "IS_ACTIVE")
    source_col = _column(eligibility_fields, "SOURCE_URL", "SOURCE")
    retrieved_col = _column(eligibility_fields, "RETRIEVED_AT_UTC", "RETRIEVED_AT")
    if not eligibility_rows or not eligibility_player_col or not (status_col or active_col) or not source_col or not retrieved_col:
        raise EngineError("RUN_BLOCKED: PGA_ELIGIBILITY_SNAPSHOT_CONTRACT_BREACH")
    by_name = {
        _normalized_name(row[eligibility_player_col]): row
        for row in eligibility_rows
        if str(row.get(eligibility_player_col, "")).strip()
    }
    participant_status: list[dict[str, Any]] = []
    out_players: list[dict[str, str]] = []
    unknown_count = 0
    source_records: dict[tuple[str, str], dict[str, str]] = {}
    for pool_row in pool_rows:
        player = str(pool_row.get(player_col, "")).strip()
        eligibility_row = by_name.get(_normalized_name(player))
        if eligibility_row is None:
            unknown_count += 1
            continue
        source_ref = str(eligibility_row.get(source_col, "")).strip()
        checked_at = str(eligibility_row.get(retrieved_col, "")).strip()
        raw_status = str(eligibility_row.get(status_col, "") if status_col else "").strip()
        raw_active = str(eligibility_row.get(active_col, "") if active_col else "").strip()
        inactive_reason, _ = _inactive_reason(raw_status, raw_active)
        status = "OUT" if inactive_reason else "ACTIVE"
        participant_status.append({
            "PLAYER": player,
            "STATUS": status,
            "SOURCE_REF": source_ref,
            "CHECKED_AT_UTC": checked_at,
            "SOURCE_STATUS": raw_status or raw_active,
        })
        if status == "OUT":
            out_players.append({"PLAYER": player, "STATUS": "OUT"})
        source_records[(source_ref, checked_at)] = {
            "SOURCE_ID": source_ref,
            "STATUS": "VERIFIED",
            "CHECKED_AT_UTC": checked_at,
        }
    snapshot = {
        "SPORT": "PGA",
        "MODE": "CLASSIC",
        "EXECUTION_ID": str(execution_id),
        "FIELD_SIZE": int(field_size),
        "SOURCE_RECORDS": list(source_records.values()),
        "PARTICIPANT_STATUS": participant_status,
        "OUT_PLAYERS": out_players,
        "UNKNOWN_COUNT": unknown_count,
    }
    snapshot_path = out / "prebuild_availability_source_snapshot.json"
    receipt_path = out / "prebuild_availability_receipt.json"
    snapshot_path.write_text(json.dumps(snapshot, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    build_availability_receipt(
        pool_path=Path(pool_path),
        snapshot_path=snapshot_path,
        output_path=receipt_path,
    )
    gate = validate_prebuild_availability_receipt(
        receipt_path,
        sport="PGA",
        mode="CLASSIC",
        pool_path=pool_path,
        execution_id=execution_id,
        field_size=field_size,
    )
    return {
        **gate.to_receipt(),
        "SOURCE_SNAPSHOT_SHA256": sha256(snapshot_path),
        "SOURCE_SNAPSHOT_PATH": str(snapshot_path.resolve()),
    }


def _inactive_reason(status: str, active: str) -> tuple[str | None, str]:
    status_value = status.strip().upper().replace("_", " ")
    active_value = active.strip().upper()
    inactive_tokens = {
        "CUT", "MC", "MISSED CUT", "MDF", "WD", "W/D", "WITHDRAWN",
        "DQ", "DISQUALIFIED", "DNS", "DID NOT START", "INACTIVE", "OUT",
    }
    if status_value in inactive_tokens or status_value.startswith(
        ("MISSED CUT", "CUT ", "MDF", "WD", "W/D", "WITHDRAWN", "DQ", "DNS")
    ):
        return "MISSED_CUT_OR_INACTIVE_STATUS", status_value
    if active_value in {"NO", "FALSE", "0", "N", "INACTIVE", "OUT"}:
        return "ACTIVE_FLAG_FALSE", active_value
    return None, status_value or active_value


def _golf_projection_proxy(row: dict[str, Any], salary: int) -> float:
    projection = 64.0 + (salary - 6000.0) / 105.0
    for column, baseline, weight in (
        ("GIR", 65.0, .18),
        ("SCRAMB", 60.0, .10),
        ("AVG/RND", 71.0, -.85),
        ("PUTS/RND", 29.0, -.35),
    ):
        value = _number(row.get(column), 0.0)
        if value > 0:
            projection += weight * (value - baseline)
    return float(np.clip(projection, 35.0, 125.0))


def _rate_from_count(value: float, attempts: float, fallback: float) -> float:
    if 0 <= value <= 1:
        return float(value)
    if attempts > 0:
        return float(np.clip((value + 1.0) / (attempts + 3.0), .001, .95))
    return fallback



def _percentile_scores(values: Sequence[float], *, higher_is_better: bool) -> np.ndarray:
    array = np.asarray(values, dtype=np.float64)
    finite = np.isfinite(array)
    scores = np.full(len(array), 0.5, dtype=np.float64)
    count = int(finite.sum())
    if count <= 1:
        return scores
    observed = array[finite]
    order = np.argsort(observed, kind="stable")
    sorted_values = observed[order]
    ranks = np.empty(count, dtype=np.float64)
    start = 0
    while start < count:
        end = start + 1
        while end < count and sorted_values[end] == sorted_values[start]:
            end += 1
        average_rank = (start + end - 1) / 2.0
        ranks[order[start:end]] = average_rank
        start = end
    scores[finite] = ranks / float(count - 1)
    if not higher_is_better:
        scores = 1.0 - scores
    return scores


def _prelock_spike_priors(
    golfers: Sequence[Golfer],
    source_rows: Sequence[dict[str, Any]],
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    if len(golfers) != len(source_rows):
        raise EngineError("RUN_INVALID: PGA_SPIKE_SOURCE_ROW_PARITY_BREACH")
    count = len(golfers)
    weighted = np.zeros(count, dtype=np.float64)
    available_weight = np.zeros(count, dtype=np.float64)
    feature_receipt: list[dict[str, Any]] = []

    def add_array(name: str, values: Sequence[float], higher: bool, weight: float) -> None:
        array = np.asarray(values, dtype=np.float64)
        finite = np.isfinite(array)
        if not np.any(finite):
            feature_receipt.append({"FEATURE": name, "AVAILABLE_ROWS": 0, "WEIGHT": weight})
            return
        scores = _percentile_scores(array, higher_is_better=higher)
        weighted[finite] += weight * scores[finite]
        available_weight[finite] += weight
        feature_receipt.append({"FEATURE": name, "AVAILABLE_ROWS": int(finite.sum()), "WEIGHT": weight})

    raw_specs = (
        ("BIRDIE%", True, .14),
        ("BOGEY%", False, .06),
        ("STRIKE", False, .10),
        ("BOUNCE", True, .06),
        ("DIST", True, .07),
        ("GIR", True, .10),
        ("PUTS/RND", False, .07),
        ("SCRAMB", True, .04),
        ("AVG/RND", False, .08),
        ("ACC", True, .02),
        ("SAND", True, .02),
    )
    for column, higher, weight in raw_specs:
        values = []
        for row in source_rows:
            text = str(row.get(column, "")).strip().replace("%", "")
            try:
                values.append(float(text) if text else float("nan"))
            except ValueError:
                values.append(float("nan"))
        add_array(column, values, higher, weight)

    add_array("TOP10_RATE", [golfer.top10_rate for golfer in golfers], True, .10)
    add_array("TOP3_RATE", [golfer.top3_rate for golfer in golfers], True, .05)
    add_array("PROJECTION", [golfer.projection for golfer in golfers], True, .05)
    add_array("CUT_PROBABILITY", [golfer.cut_probability for golfer in golfers], True, .04)

    score = np.divide(
        weighted,
        available_weight,
        out=np.full(count, .5, dtype=np.float64),
        where=available_weight > 0,
    )
    coverage = np.clip(available_weight, 0.0, 1.0)
    payload = "\n".join(
        f"{golfers[index].uid}|{score[index]:.12f}|{coverage[index]:.12f}"
        for index in range(count)
    ).encode("utf-8")
    return score, coverage, {
        "PATCH_ID": PGA_PLAYER_SPIKE_MODEL_PATCH_ID,
        "FEATURES": feature_receipt,
        "PLAYER_ROWS": count,
        "SCORE_SHA256": hashlib.sha256(payload).hexdigest(),
        "POSTLOCK_RESULTS_USED": False,
        "PLAYER_NAME_CONSTANTS_USED": False,
    }


def _rank_percentile_from_rows(player_rows: Sequence[dict[str, Any]], field: str) -> np.ndarray:
    return _percentile_scores([float(row[field]) for row in player_rows], higher_is_better=True)


def compile_player_spike_frontier(
    player_rows: Sequence[dict[str, Any]],
    golfers: Sequence[Golfer],
    limit: int,
) -> np.ndarray:
    if limit < 6:
        raise EngineError("RUN_INVALID: PGA_CLASSIC_SPIKE_FRONTIER_LT_6")
    limit = min(limit, len(golfers))
    quota_plan = (
        ("PLAYER_SPIKE_SCORE", 12),
        ("SLATE_TOP_5_PERCENT_RATE", 10),
        ("PLAYER_P99", 8),
        ("PLAYER_P999", 6),
        ("FIELD_WIN_RATE", 5),
        ("CUT_SURVIVAL_RATE", 3),
        ("TAIL_SALARY_EFFICIENCY", 2),
        ("STRATEGIC_LEVERAGE", 1),
        ("OWNERSHIP_LEVERAGE", 1),
    )
    if limit != 48:
        scale = limit / 48.0
        scaled = []
        remaining = limit
        for position, (field, quota) in enumerate(quota_plan):
            if position == len(quota_plan) - 1:
                take = max(0, remaining)
            else:
                take = max(1, int(round(quota * scale)))
                take = min(take, remaining)
            scaled.append((field, take))
            remaining -= take
        quota_plan = tuple(scaled)

    orders = {
        field: sorted(
            player_rows,
            key=lambda row: (-float(row[field]), int(row["SALARY"]), int(row["PLAYER_INDEX"])),
        )
        for field, _ in quota_plan
    }
    positions = {field: 0 for field, _ in quota_plan}
    remaining = {field: int(quota) for field, quota in quota_plan}
    chosen: list[int] = []
    seen: set[int] = set()
    while len(chosen) < limit and any(value > 0 for value in remaining.values()):
        progressed = False
        for field, _ in quota_plan:
            if remaining[field] <= 0:
                continue
            order = orders[field]
            while positions[field] < len(order):
                row = order[positions[field]]
                positions[field] += 1
                index = int(row["PLAYER_INDEX"])
                if index in seen:
                    continue
                seen.add(index)
                chosen.append(index)
                remaining[field] -= 1
                progressed = True
                break
            if len(chosen) >= limit:
                break
        if not progressed:
            break
    if len(chosen) < limit:
        rank_maps = {
            field: {int(row["PLAYER_INDEX"]): rank for rank, row in enumerate(order)}
            for field, order in orders.items()
        }
        fallback = sorted(
            range(len(golfers)),
            key=lambda index: (
                min(rank_maps[field][index] for field, _ in quota_plan),
                sum(rank_maps[field][index] for field, _ in quota_plan),
                index,
            ),
        )
        for index in fallback:
            if index in seen:
                continue
            seen.add(index)
            chosen.append(index)
            if len(chosen) >= limit:
                break
    if len(chosen) != limit:
        raise EngineError("RUN_INVALID: PGA_CLASSIC_SPIKE_FRONTIER_TARGET_MISMATCH")
    return np.asarray(sorted(chosen), dtype=np.int32)

def load_pool(
    path: str | Path,
    eligibility_path: str | Path | None = None,
) -> tuple[list[Golfer], dict[str, Any]]:
    source = Path(path)
    with source.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        fields = set(reader.fieldnames or [])
    player_col = _column(fields, "PLAYER", "NAME")
    salary_col = _column(fields, "SAL", "SALARY")
    projection_col = _column(fields, "FPTS", "PROJ", "PROJECTION")
    if not rows or not player_col or not salary_col or not projection_col:
        raise EngineError("RUN_BLOCKED: REQUIRED_COLUMNS_PLAYER_SALARY_FPTS_MISSING")
    if not eligibility_path:
        raise EngineError("RUN_BLOCKED: PGA_CUT_STATUS_AUTHORITY_MISSING")
    eligibility, eligibility_meta = _load_eligibility_snapshot(eligibility_path)
    ownership_col = _column(fields, "RST%", "OWN%", "OWNERSHIP")
    ceiling_col = _column(fields, "CEILING", "MAX FPTS", "MAX_FPTS")
    min_col = _column(fields, "MIN EXP", "MIN_EXP")
    max_col = _column(fields, "MAX EXP", "MAX_EXP")
    cut_col = _column(fields, "CUT%", "CUT PROB", "CUT_PROB")
    cuts_col = _column(fields, "CUTS")
    top10_col = _column(fields, "TOP 10", "TOP10")
    top3_col = _column(fields, "TOP 3", "TOP3")
    tee_col = _column(fields, "TEE TIME", "TEE_TIME", "WAVE")

    golfers: list[Golfer] = []
    purge_rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    proxy_rows = 0
    observed_cut_probabilities: list[float] = []
    if cut_col:
        for source_row in rows:
            observed = _number(source_row.get(cut_col), 0.0)
            if observed > 1:
                observed /= 100.0
            if 0 < observed <= 1:
                observed_cut_probabilities.append(observed)
    cut_probability_imputation = (
        float(np.median(observed_cut_probabilities))
        if observed_cut_probabilities
        else .65
    )
    cut_probability_imputed_rows = 0
    strategy_rows: list[dict[str, Any]] = []
    spike_source_rows: list[dict[str, Any]] = []
    for index, row in enumerate(rows):
        name = str(row.get(player_col, "")).strip()
        if not name:
            continue
        if name in seen:
            raise EngineError(f"RUN_BLOCKED: DUPLICATE_PLAYER={name}")
        seen.add(name)
        eligibility_row = eligibility.get(_normalized_name(name))
        if eligibility_row is None:
            purge_rows.append({"PLAYER": name, "REASON": "NOT_IN_CURRENT_ELIGIBILITY_SNAPSHOT", "SOURCE_STATUS": "NOT_LISTED"})
            continue
        inactive_reason, source_status = _inactive_reason(
            eligibility_row["STATUS"], eligibility_row["ACTIVE"]
        )
        if inactive_reason:
            purge_rows.append({"PLAYER": name, "REASON": inactive_reason, "SOURCE_STATUS": source_status})
            continue
        salary = int(_number(row.get(salary_col)))
        supplied_projection = _number(row.get(projection_col), 0.0)
        if supplied_projection > 0:
            projection = supplied_projection
            projection_source = "FILE"
        else:
            projection = _golf_projection_proxy(row, salary)
            projection_source = "GOLF_EARLY_INFO_PROXY"
            proxy_rows += 1
        ceiling = (
            _number(row.get(ceiling_col), projection + max(18.0, projection * .30))
            if ceiling_col else projection + max(18.0, projection * .30)
        )
        ownership = _number(row.get(ownership_col)) if ownership_col and str(row.get(ownership_col, "")).strip() else None
        if ownership is not None and ownership > 1:
            ownership /= 100.0
        min_exposure = _number(row.get(min_col), 0.0) if min_col else 0.0
        max_exposure = _number(row.get(max_col), 1.0) if max_col else 1.0
        if min_exposure > 1:
            min_exposure /= 100.0
        if max_exposure > 1:
            max_exposure /= 100.0
        cut_probability = _number(row.get(cut_col), .65) if cut_col else .65
        if cut_probability > 1:
            cut_probability /= 100.0
        if cut_probability <= 0:
            cut_probability = cut_probability_imputation
            cut_probability_imputed_rows += 1
        cut_probability = float(np.clip(cut_probability, .05, .99))
        cuts = _number(row.get(cuts_col), 0.0) if cuts_col else 0.0
        top10 = _rate_from_count(_number(row.get(top10_col), 0.0), cuts, .08) if top10_col else .08
        top3 = _rate_from_count(_number(row.get(top3_col), 0.0), cuts, .02) if top3_col else .02
        tee = str(row.get(tee_col, "") if tee_col else "").strip().upper()
        wave = "PM" if "PM" in tee else "AM" if "AM" in tee else "NEUTRAL"
        if (
            salary <= 0
            or not math.isfinite(projection)
            or ceiling < projection
            or not 0 < cut_probability < 1
            or not 0 <= min_exposure <= max_exposure <= 1
        ):
            raise EngineError(f"RUN_BLOCKED: INVALID_PLAYER_INPUT={name}")
        golfers.append(Golfer(
            uid=str(row.get("UID") or row.get("ID") or f"G{index:04d}").strip(),
            name=name,
            salary=salary,
            projection=projection,
            ceiling=ceiling,
            ownership=ownership,
            min_exposure=min_exposure,
            max_exposure=max_exposure,
            wave=wave,
            cut_probability=cut_probability,
            top10_rate=top10,
            top3_rate=top3,
            projection_source=projection_source,
        ))
        strategy_row = dict(row)
        strategy_row["PLAYER"] = name
        strategy_row["SAL"] = salary
        # Preserve ordinary provider rows exactly. A full-slate projection outage
        # is reconciled after ingestion so the strategy layer can consume the same
        # deterministic pre-lock proxy already selected by this PGA engine.
        strategy_rows.append(strategy_row)
        spike_source_rows.append(dict(row))
    if len(golfers) < 6:
        raise EngineError("RUN_BLOCKED: ACTIVE_GOLFERS_LT_6")
    proxy_strategy_handoff_rows = 0
    if proxy_rows == len(golfers):
        for strategy_row, golfer in zip(strategy_rows, golfers):
            strategy_row["FPTS"] = golfer.projection
        proxy_strategy_handoff_rows = len(golfers)
    strategy = build_strategy_features(strategy_rows, sport="PGA", mode="CLASSIC")
    golfers = [
        replace(
            golfer,
            strategy_opportunity_score=float(strategy.opportunity_score[index]),
            strategy_role_credibility=float(strategy.role_credibility[index]),
            strategy_salary_unlock=bool(strategy.salary_unlock[index]),
            strategy_stale_role_suppressed=bool(strategy.stale_role_suppressed[index]),
            strategy_direct_opportunity_absorber=bool(strategy.direct_opportunity_absorber[index]),
            strategic_leverage=float(strategy.strategic_leverage[index]),
        )
        for index, golfer in enumerate(golfers)
    ]
    spike_score, spike_coverage, spike_receipt = _prelock_spike_priors(golfers, spike_source_rows)
    golfers = [
        replace(
            golfer,
            prelock_spike_prior_score=float(spike_score[index]),
            spike_input_coverage=float(spike_coverage[index]),
        )
        for index, golfer in enumerate(golfers)
    ]
    return golfers, {
        "SOURCE_ROWS": len(rows),
        "ACTIVE_ROWS": len(golfers),
        **eligibility_meta,
        "ELIGIBILITY_FALLBACK": "OFFICIAL_CURRENT_SNAPSHOT",
        "CUT_STATUS_AUTHORITY_AVAILABLE": True,
        "HISTORICAL_CUT_FIELDS_USED_AS_LIVE_STATUS": False,
        "INACTIVE_GOLFERS_PURGED": len(purge_rows),
        "MISSED_CUT_PURGED": sum(row["REASON"] == "MISSED_CUT_OR_INACTIVE_STATUS" for row in purge_rows),
        "STATUS_MC_ROWS_PURGED": sum(row["SOURCE_STATUS"] == "MC" for row in purge_rows),
        "MISSED_CUT_SURVIVORS": 0,
        "PGA_STATUS_MC_MEANING": "MISSED_CUT",
        "MC_PROOF_BLOCKS_MEANING": "MONTE_CARLO",
        "PROJECTION_FALLBACK_ROWS": proxy_rows,
        "CUT_PROBABILITY_IMPUTED_ROWS": cut_probability_imputed_rows,
        "CUT_PROBABILITY_IMPUTATION": cut_probability_imputation,
        "CUT_PURGE_MANIFEST": purge_rows,
        "OWNERSHIP_AVAILABLE": all(golfer.ownership is not None for golfer in golfers),
        "GLOBAL_SPORTS_STRATEGIST_PATCH_ID": strategy.receipt["PATCH_ID"],
        "PREDICTIVE_LAYER_PATCH_ID": strategy.receipt["PREDICTIVE_LAYER_PATCH_ID"],
        "PREDICTIVE_LAYER_STATUS": strategy.receipt["PREDICTIVE_LAYER_STATUS"],
        "PREDICTION_HASH": strategy.receipt["PREDICTION_HASH"],
        "RAW_MARKET_INPUT_HASH": strategy.receipt["RAW_MARKET_INPUT_HASH"],
        "PLAYER_MARKET_ROWS": strategy.receipt["PLAYER_MARKET_ROWS"],
        "GAME_MARKET_ROWS": strategy.receipt["GAME_MARKET_ROWS"],
        "MORE_DECISIONS": strategy.receipt["MORE_DECISIONS"],
        "LESS_DECISIONS": strategy.receipt["LESS_DECISIONS"],
        "PASS_DECISIONS": strategy.receipt["PASS_DECISIONS"],
        "STALE_LINE_SIGNALS": strategy.receipt["STALE_LINE_SIGNALS"],
        "PREDICTION_FROZEN": strategy.receipt["PREDICTION_FROZEN"],
        "STRATEGY_CONSUMED_PREDICTION_HASH": strategy.receipt["STRATEGY_CONSUMED_PREDICTION_HASH"],
        "PREDICTIVE_LAYER_SOURCE_WIRED": PREDICTIVE_LAYER_PATCH_ID == strategy.receipt["PREDICTIVE_LAYER_PATCH_ID"],
        "PREDICTIVE_LAYER_POSTLOCK_RESULTS_USED": False,
        "PREDICTIVE_RAW_AGGREGATE_PROJECTION_TO_PHASE1": False,
        "SPORT_STRATEGY_MECHANIC": strategy.receipt["MECHANIC"],
        "STRATEGY_CONTRACT_HASH": strategy.receipt["CONTRACT_HASH"],
        "SPORT_STRATEGY_ADAPTER_STATUS": strategy.receipt["STATUS"],
        "SPORT_STRATEGY_LOAD_ORDER": strategy.receipt["LOAD_ORDER"],
        "DIRECT_OPPORTUNITY_ABSORBERS": int(strategy.direct_opportunity_absorber.sum()),
        "SALARY_UNLOCK_PLAYERS": int(strategy.salary_unlock.sum()),
        "STALE_ROLE_SUPPRESSED_PLAYERS": int(strategy.stale_role_suppressed.sum()),
        "SPORT_STRATEGY_PLAYER_NAME_CONSTANTS_USED": False,
        "SPORT_STRATEGY_POSTLOCK_RESULTS_USED": False,
        "PGA_PLAYER_SPIKE_MODEL_PATCH_ID": spike_receipt["PATCH_ID"],
        "PGA_PLAYER_SPIKE_SCORE_SHA256": spike_receipt["SCORE_SHA256"],
        "PGA_PLAYER_SPIKE_FEATURES": spike_receipt["FEATURES"],
        "PGA_PLAYER_SPIKE_POSTLOCK_RESULTS_USED": spike_receipt["POSTLOCK_RESULTS_USED"],
        "PGA_PLAYER_SPIKE_PLAYER_NAME_CONSTANTS_USED": spike_receipt["PLAYER_NAME_CONSTANTS_USED"],
        "PGA_PROXY_STRATEGY_HANDOFF_PATCH_ID": PGA_PROXY_STRATEGY_HANDOFF_PATCH_ID,
        "PGA_PROXY_STRATEGY_HANDOFF_ROWS": proxy_strategy_handoff_rows,
        "PGA_PROXY_STRATEGY_HANDOFF_POLICY": "FULL_ACTIVE_POOL_PROJECTION_OUTAGE_ONLY",
    }


def simulate_players(
    golfers: Sequence[Golfer],
    simulations: int,
    seed: int,
    return_outcomes: bool = False,
) -> np.ndarray | tuple[np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(int(seed))
    count = len(golfers)
    shared_course = rng.standard_t(7, size=simulations).astype(np.float32)
    shared_scoring = rng.standard_t(6, size=simulations).astype(np.float32)
    waves = sorted({golfer.wave for golfer in golfers})
    wave_worlds = {
        wave: rng.normal(size=simulations).astype(np.float32)
        for wave in waves
    }
    cut_shocks = rng.normal(size=(simulations, count)).astype(np.float32)
    scoring_shocks = rng.standard_t(5, size=(simulations, count)).astype(np.float32)
    scores = np.empty((simulations, count), dtype=np.float32)
    survival = np.empty((simulations, count), dtype=bool)
    for index, golfer in enumerate(golfers):
        probability = float(np.clip(golfer.cut_probability, .02, .995))
        logit = math.log(probability / (1.0 - probability))
        cut_latent = (
            logit
            + .32 * shared_course
            + .18 * wave_worlds[golfer.wave]
            + .92 * cut_shocks[:, index]
        )
        made_cut = cut_latent > 0
        survival[:, index] = made_cut
        upside = max(golfer.ceiling - golfer.projection, 15.0)
        finish_boost = 10.0 * golfer.top10_rate + 14.0 * golfer.top3_rate
        values = (
            golfer.projection
            + finish_boost
            + (upside / 2.2) * (
                .38 * shared_scoring
                + .16 * wave_worlds[golfer.wave]
                + .88 * scoring_shocks[:, index]
            )
        )
        missed_cut_points = .43 * values - 8.0 + 2.0 * shared_course
        scores[:, index] = np.maximum(-5.0, np.where(made_cut, values, missed_cut_points))
    surviving_scores = np.where(survival, scores, -np.inf)
    winner_index = np.argmax(surviving_scores, axis=1)
    no_survivor = ~np.any(survival, axis=1)
    if np.any(no_survivor):
        winner_index[no_survivor] = np.argmax(scores[no_survivor], axis=1)
    field_win = np.zeros_like(survival)
    field_win[np.arange(simulations), winner_index] = True
    return (scores, survival, field_win) if return_outcomes else scores


def player_tournament(
    worlds: np.ndarray,
    golfers: Sequence[Golfer],
    survival: np.ndarray,
    field_win: np.ndarray,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    player_count = len(golfers)
    top5_count = max(1, math.ceil(player_count * .05))
    top1_count = max(1, math.ceil(player_count * .01))
    top5_threshold = np.partition(worlds, player_count - top5_count, axis=1)[:, player_count - top5_count]
    top1_threshold = np.partition(worlds, player_count - top1_count, axis=1)[:, player_count - top1_count]
    for index, golfer in enumerate(golfers):
        made_cut = survival[:, index]
        values = worlds[:, index]
        conditional = values[made_cut]
        p50 = float(np.quantile(values, .50))
        p95 = float(np.quantile(values, .95))
        p99 = float(np.quantile(values, .99))
        rows.append({
            "PLAYER_INDEX": index,
            "PLAYER": golfer.name,
            "SALARY": golfer.salary,
            "CUT_SURVIVAL_RATE": float(np.mean(made_cut)),
            "FIELD_WIN_RATE": float(np.mean(field_win[:, index])),
            "PLAYER_P50": p50,
            "PLAYER_P95": p95,
            "PLAYER_P99": p99,
            "PLAYER_P999": float(np.quantile(values, .999)),
            "SLATE_TOP_5_PERCENT_RATE": float(np.mean(values >= top5_threshold)),
            "SLATE_TOP_1_PERCENT_RATE": float(np.mean(values >= top1_threshold)),
            "TAIL_VOLATILITY": p99 - p50,
            "TAIL_UPSIDE_DELTA": p99 - golfer.projection,
            "PRELOCK_SPIKE_PRIOR_SCORE": golfer.prelock_spike_prior_score,
            "SPIKE_INPUT_COVERAGE": golfer.spike_input_coverage,
            "CONDITIONAL_MADE_CUT_P999": float(np.quantile(conditional, .999)) if len(conditional) else float("-inf"),
            "TAIL_SALARY_EFFICIENCY": float(np.quantile(values, .999) / max(golfer.salary / 1000.0, 1.0)),
            "OWNERSHIP_LEVERAGE": 0.0 if golfer.ownership is None else -math.log(max(golfer.ownership, 1e-9)),
            "STRATEGY_OPPORTUNITY_SCORE": golfer.strategy_opportunity_score,
            "STRATEGY_ROLE_CREDIBILITY": golfer.strategy_role_credibility,
            "STRATEGY_SALARY_UNLOCK": int(golfer.strategy_salary_unlock),
            "STRATEGY_STALE_ROLE_SUPPRESSED": int(golfer.strategy_stale_role_suppressed),
            "STRATEGIC_LEVERAGE": golfer.strategic_leverage,
        })
    spike_prior_rank = _rank_percentile_from_rows(rows, "PRELOCK_SPIKE_PRIOR_SCORE")
    top5_rank = _rank_percentile_from_rows(rows, "SLATE_TOP_5_PERCENT_RATE")
    top1_rank = _rank_percentile_from_rows(rows, "SLATE_TOP_1_PERCENT_RATE")
    p99_rank = _rank_percentile_from_rows(rows, "PLAYER_P99")
    volatility_rank = _rank_percentile_from_rows(rows, "TAIL_VOLATILITY")
    for index, row in enumerate(rows):
        row["PLAYER_SPIKE_SCORE"] = float(
            .30 * spike_prior_rank[index]
            + .25 * top5_rank[index]
            + .15 * top1_rank[index]
            + .20 * p99_rank[index]
            + .10 * volatility_rank[index]
        )
        row["PLAYER_SPIKE_RATE"] = float(row["SLATE_TOP_5_PERCENT_RATE"])
    return rows


def compile_player_frontier(
    player_rows: Sequence[dict[str, Any]],
    golfers: Sequence[Golfer],
    limit: int,
) -> np.ndarray:
    if limit < 6:
        raise EngineError("RUN_INVALID: PGA_CLASSIC_FRONTIER_LT_6")
    limit = min(limit, len(golfers))
    lane_fields = (
        "CUT_SURVIVAL_RATE",
        "FIELD_WIN_RATE",
        "PLAYER_P999",
        "CONDITIONAL_MADE_CUT_P999",
        "TAIL_SALARY_EFFICIENCY",
        "OWNERSHIP_LEVERAGE",
        "STRATEGIC_LEVERAGE",
    )
    lane_width = max(3, math.ceil(limit / len(lane_fields)))
    salary_unlock = {
        int(row["PLAYER_INDEX"])
        for row in player_rows
        if int(row.get("STRATEGY_SALARY_UNLOCK", 0)) == 1
    }
    if len(salary_unlock) > limit:
        raise EngineError("RUN_INVALID: PGA_CLASSIC_STRATEGY_FRONTIER_LIMIT_BREACH")
    chosen: set[int] = set(salary_unlock)
    for field in lane_fields:
        ordered = sorted(
            player_rows,
            key=lambda row: (-float(row[field]), int(row["SALARY"]), int(row["PLAYER_INDEX"])),
        )
        chosen.update(int(row["PLAYER_INDEX"]) for row in ordered[:lane_width])
    salary_bands = ((0, 6999), (7000, 7999), (8000, 8999), (9000, 9999), (10000, 100000))
    for low, high in salary_bands:
        band = [row for row in player_rows if low <= int(row["SALARY"]) <= high]
        band.sort(key=lambda row: (-float(row["TAIL_SALARY_EFFICIENCY"]), int(row["PLAYER_INDEX"])))
        chosen.update(int(row["PLAYER_INDEX"]) for row in band[:2])
    composite = sorted(
        player_rows,
        key=lambda row: (
            -float(row["CUT_SURVIVAL_RATE"]),
            -float(row["FIELD_WIN_RATE"]),
            -float(row["PLAYER_P999"]),
            -float(row["TAIL_SALARY_EFFICIENCY"]),
            int(row["PLAYER_INDEX"]),
        ),
    )
    for row in composite:
        if len(chosen) >= limit:
            break
        chosen.add(int(row["PLAYER_INDEX"]))
    if len(chosen) > limit:
        rank = {int(row["PLAYER_INDEX"]): position for position, row in enumerate(composite)}
        retained = sorted(salary_unlock)
        retained.extend(
            index
            for index in sorted(chosen - salary_unlock, key=lambda index: rank[index])
            if len(retained) < limit
        )
        chosen = set(retained)
    return np.asarray(sorted(chosen), dtype=np.int32)


def build_calibration_qualified_lineups(
    golfers: Sequence[Golfer],
    frontier: np.ndarray,
    player_rows: Sequence[dict[str, Any]],
    cfg: dict[str, Any],
) -> tuple[np.ndarray, dict[str, Any]]:
    search_space = math.comb(len(frontier), 6)
    dtype = np.uint16 if len(golfers) < 65536 else np.uint32
    candidates = combination_matrix(frontier, 6, max_rows=search_space, dtype=dtype)
    salaries = np.asarray([golfer.salary for golfer in golfers], dtype=np.int32)
    totals = salaries[candidates].sum(axis=1)
    legal_mask = (totals >= int(cfg["salary_floor"])) & (totals <= int(cfg["salary_cap"]))
    legal = np.ascontiguousarray(candidates[legal_mask])
    if not len(legal):
        raise EngineError("RUN_BLOCKED: NO_LEGAL_PGA_CLASSIC_LINEUPS")
    by_index = {int(row["PLAYER_INDEX"]): row for row in player_rows}
    survival = np.asarray([by_index[i]["CUT_SURVIVAL_RATE"] for i in range(len(golfers))], dtype=np.float64)
    field_win = np.asarray([by_index[i]["FIELD_WIN_RATE"] for i in range(len(golfers))], dtype=np.float64)
    p999 = np.asarray([by_index[i]["PLAYER_P999"] for i in range(len(golfers))], dtype=np.float64)
    efficiency = np.asarray([by_index[i]["TAIL_SALARY_EFFICIENCY"] for i in range(len(golfers))], dtype=np.float64)
    leverage = np.asarray([by_index[i]["OWNERSHIP_LEVERAGE"] for i in range(len(golfers))], dtype=np.float64)
    strategic_leverage = np.asarray([by_index[i]["STRATEGIC_LEVERAGE"] for i in range(len(golfers))], dtype=np.float64)
    salary_unlock = np.asarray([by_index[i]["STRATEGY_SALARY_UNLOCK"] for i in range(len(golfers))], dtype=np.float64)
    surfaces = {
        "ALL_SIX_SURVIVAL_LOG": np.log(np.clip(survival[legal], 1e-9, 1.0)).sum(axis=1),
        "FIELD_WIN_MASS": field_win[legal].sum(axis=1),
        "TAIL_P999_SUM": p999[legal].sum(axis=1),
        "TAIL_VALUE_SUM": efficiency[legal].sum(axis=1),
        "LEVERAGE_SUM": leverage[legal].sum(axis=1),
        "STRATEGIC_LEVERAGE_SUM": strategic_leverage[legal].sum(axis=1),
        "SALARY_UNLOCK_COUNT": salary_unlock[legal].sum(axis=1),
    }
    target = min(len(legal), max(3000, int(cfg["phase2_qualified_target"])))
    base_index = np.arange(len(legal), dtype=np.int32)
    quota = max(1, math.ceil(target / len(surfaces)))
    selected: set[int] = set()
    rank_rows: list[np.ndarray] = []
    for values in surfaces.values():
        order = np.lexsort((base_index, -np.asarray(values, dtype=np.float64)))
        selected.update(int(index) for index in order[:quota])
        ranks = np.empty(len(legal), dtype=np.int32)
        ranks[order] = np.arange(len(legal), dtype=np.int32)
        rank_rows.append(ranks)
    rank_matrix = np.vstack(rank_rows)
    calibration_score = rank_matrix.min(axis=0).astype(np.float64) + 0.05 * rank_matrix.mean(axis=0)
    selected_index = np.asarray(sorted(selected), dtype=np.int32)
    if len(selected_index) > target:
        keep = np.lexsort((selected_index, calibration_score[selected_index]))[:target]
        selected_index = selected_index[keep]
    elif len(selected_index) < target:
        selected_mask = np.zeros(len(legal), dtype=bool)
        selected_mask[selected_index] = True
        remaining = base_index[~selected_mask]
        fill = np.lexsort((remaining, calibration_score[remaining]))[: target - len(selected_index)]
        selected_index = np.concatenate((selected_index, remaining[fill]))
    qualified = np.ascontiguousarray(legal[selected_index])
    if len(qualified) != target:
        raise EngineError("RUN_INVALID: PGA_CLASSIC_CALIBRATION_QUALIFIED_TARGET_MISMATCH")
    return qualified, {
        "SEARCH_SPACE_SCOPE": "PHASE1_CALIBRATION_FINGERPRINT_GUIDED_PLAYER_FRONTIER",
        "EXPECTED_SEARCH_SPACE": search_space,
        "SCANNED_COMBINATIONS": len(candidates),
        "LEGAL_LINEUPS_FOUND": len(legal),
        "CALIBRATION_REJECTED_LINEUPS": len(legal) - len(qualified),
        "CALIBRATION_QUALIFIED_LINEUPS": len(qualified),
        "PHASE2_QUALIFICATION_QUANTILE": None,
        "PHASE2_QUALIFICATION_METHOD": "DETERMINISTIC_SURFACE_QUOTA_UNION_WITH_CALIBRATION_RANK_CLOSURE_v1",
        "PHASE2_SURFACE_QUOTA": quota,
        "PHASE2_QUALIFICATION_SURFACES": list(surfaces),
        "SCAN_COMPLETE": True,
        "RANDOM_OR_FIRST_N_BUILD": False,
        "NONQUALIFIED_LEGAL_ROWS_STORED": False,
        "FULL_LEGAL_UNIVERSE_MATERIALIZED": False,
    }


def lineup_metrics(
    worlds: np.ndarray,
    survival: np.ndarray,
    lineups: np.ndarray,
    golfers: Sequence[Golfer],
) -> list[dict[str, Any]]:
    simulations = worlds.shape[0]
    count = lineups.shape[0]
    wins = np.zeros(count, dtype=np.int64)
    top01 = np.zeros(count, dtype=np.int64)
    top1 = np.zeros(count, dtype=np.int64)
    all_six = np.zeros(count, dtype=np.int64)
    tail_count = max(1, math.ceil(simulations * .01))
    tails = np.full((tail_count, count), -np.inf, dtype=np.float32)
    top01_count = max(1, math.ceil(count * .001))
    top1_count = max(1, math.ceil(count * .01))
    batch_size = max(32, min(256, int(12_000_000 / max(count, 1))))
    for start in range(0, simulations, batch_size):
        stop = min(simulations, start + batch_size)
        scores = worlds[start:stop, lineups[:, 0]].copy()
        survived = survival[start:stop, lineups[:, 0]].copy()
        for slot in range(1, 6):
            np.add(scores, worlds[start:stop, lineups[:, slot]], out=scores)
            np.logical_and(survived, survival[start:stop, lineups[:, slot]], out=survived)
        all_six += survived.sum(axis=0)
        wins += np.bincount(np.argmax(scores, axis=1), minlength=count)
        cutoff01 = np.partition(scores, count - top01_count, axis=1)[:, count - top01_count]
        cutoff1 = np.partition(scores, count - top1_count, axis=1)[:, count - top1_count]
        top01 += np.sum(scores >= cutoff01[:, None], axis=0)
        top1 += np.sum(scores >= cutoff1[:, None], axis=0)
        merged = np.concatenate((tails, scores), axis=0)
        tails = np.partition(merged, merged.shape[0] - tail_count, axis=0)[-tail_count:]
    salaries = np.asarray([golfer.salary for golfer in golfers], dtype=np.int32)
    rows: list[dict[str, Any]] = []
    for index, lineup in enumerate(lineups):
        values = np.sort(tails[:, index])
        p999_index = max(0, len(values) - max(1, math.ceil(simulations * .001)))
        ownership = (
            None
            if any(golfers[int(player)].ownership is None for player in lineup)
            else math.prod(max(golfers[int(player)].ownership or 0.0, .001) for player in lineup)
        )
        rows.append({
            "LINEUP_ID": f"L{index + 1:08d}",
            "_INDEX": index,
            "SALARY": int(salaries[lineup].sum()),
            "ALL_SIX_SURVIVE_RATE": float(all_six[index] / simulations),
            "FIRST_PLACE_RATE": float(wins[index] / simulations),
            "TOP_0_1_PERCENT_RATE": float(top01[index] / simulations),
            "TOP_1_PERCENT_RATE": float(top1[index] / simulations),
            "TOURNAMENT_P999": float(values[p999_index]),
            "TOURNAMENT_CVAR99": float(values.mean()),
            "OWNERSHIP_PRODUCT": ownership,
        })
    rows.sort(key=lambda row: tuple(-float(row[field]) for field in SELECTION_METRICS) + (str(row["LINEUP_ID"]),))
    return rows


def select_handoff_metrics(
    metrics: Sequence[dict[str, Any]],
    lineups: np.ndarray,
    golfers: Sequence[Golfer],
    limit: int,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Freeze the exact Phase 2/3 identity set for anonymous selector review."""
    if not metrics or int(limit) != len(metrics) or len(lineups) != len(metrics):
        raise EngineError("RUN_INVALID: PGA_CLASSIC_HANDOFF_COMPRESSION_PROHIBITED")
    handoff = list(metrics)
    return handoff, {
        "HANDOFF_SOURCE_ROWS": len(metrics),
        "HANDOFF_ROWS": len(handoff),
        "HANDOFF_COMPILER": "EXACT_PHASE2_PHASE3_IDENTITY_SET_v1_0",
        "HANDOFF_COMPRESSION_USED": False,
        "HANDOFF_MULTI_SURFACE_RECALL": True,
        "HANDOFF_STRUCTURAL_RESERVE": True,
        "HANDOFF_PLAYER_PATH_RESERVE": True,
        "ZERO_VIABLE_PATH_RECALL_COUNT": 0,
    }


def _lineup_rows(
    lineups: np.ndarray,
    golfers: Sequence[Golfer],
) -> list[dict[str, Any]]:
    return [
        {
            "LINEUP_ID": f"L{index + 1:08d}",
            **{f"G{slot + 1}": golfers[int(player)].name for slot, player in enumerate(lineup)},
            "SALARY": sum(golfers[int(player)].salary for player in lineup),
        }
        for index, lineup in enumerate(lineups)
    ]


def execute(
    input_path: str,
    output_dir: str,
    config_path: str,
    seed: int,
    simulations: int,
    eligibility_path: str | Path | None,
    field_size: int,
) -> dict[str, Any]:
    cfg = json.loads(Path(config_path).read_text(encoding="utf-8"))
    if simulations < int(cfg["minimum_simulations"]):
        raise EngineError("RUN_BLOCKED: MONTE_CARLO_MINIMUM_BREACH")
    if field_size < 2:
        raise EngineError("RUN_BLOCKED: PUBLIC_FIELD_SIZE_NOT_PROVEN")
    if not eligibility_path:
        raise EngineError("RUN_BLOCKED: PGA_CUT_STATUS_AUTHORITY_MISSING")
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    prebuild_gate = _build_prebuild_gate(
        pool_path=input_path,
        eligibility_path=eligibility_path,
        out=out,
        execution_id=int(seed),
        field_size=field_size,
    )
    golfers, meta = load_pool(input_path, eligibility_path)
    _write_csv(out / "phase1_cut_purge.csv", meta["CUT_PURGE_MANIFEST"], ("PLAYER", "REASON", "SOURCE_STATUS"))
    meta["CUT_PURGE_SHA256"] = sha256(out / "phase1_cut_purge.csv")
    phase1_seed = int(seed)
    phase3_seed = phase1_seed ^ 0x9E3779B9
    phase1_worlds, phase1_survival, phase1_wins = simulate_players(
        golfers, simulations, phase1_seed, True
    )
    tournament = player_tournament(phase1_worlds, golfers, phase1_survival, phase1_wins)
    _write_csv(
        out / "phase1_calibration_fingerprint.csv",
        tournament,
        (
            "PLAYER_INDEX", "PLAYER", "SALARY", "CUT_SURVIVAL_RATE",
            "FIELD_WIN_RATE", "PLAYER_P50", "PLAYER_P95", "PLAYER_P99", "PLAYER_P999",
            "SLATE_TOP_5_PERCENT_RATE", "SLATE_TOP_1_PERCENT_RATE",
            "TAIL_VOLATILITY", "TAIL_UPSIDE_DELTA",
            "PRELOCK_SPIKE_PRIOR_SCORE", "SPIKE_INPUT_COVERAGE",
            "PLAYER_SPIKE_SCORE", "PLAYER_SPIKE_RATE",
            "CONDITIONAL_MADE_CUT_P999", "TAIL_SALARY_EFFICIENCY",
            "OWNERSHIP_LEVERAGE", "STRATEGY_OPPORTUNITY_SCORE",
            "STRATEGY_ROLE_CREDIBILITY", "STRATEGY_SALARY_UNLOCK",
            "STRATEGY_STALE_ROLE_SUPPRESSED", "STRATEGIC_LEVERAGE",
        ),
    )
    calibration_sha = sha256(out / "phase1_calibration_fingerprint.csv")
    frontier = compile_player_frontier(
        tournament, golfers, int(cfg["phase1_frontier_players"])
    )
    spike_frontier = compile_player_spike_frontier(
        tournament, golfers, int(cfg.get("phase1_spike_frontier_players", cfg["phase1_frontier_players"]))
    )
    spike_rows = []
    tournament_by_index = {int(row["PLAYER_INDEX"]): row for row in tournament}
    for rank, index in enumerate(spike_frontier, 1):
        row = tournament_by_index[int(index)]
        spike_rows.append({
            "SPIKE_FRONTIER_RANK": rank,
            "PLAYER_INDEX": int(index),
            "PLAYER": golfers[int(index)].name,
            "SALARY": golfers[int(index)].salary,
            "PLAYER_SPIKE_SCORE": row["PLAYER_SPIKE_SCORE"],
            "PLAYER_SPIKE_RATE": row["PLAYER_SPIKE_RATE"],
            "PRELOCK_SPIKE_PRIOR_SCORE": row["PRELOCK_SPIKE_PRIOR_SCORE"],
            "SLATE_TOP_5_PERCENT_RATE": row["SLATE_TOP_5_PERCENT_RATE"],
            "SLATE_TOP_1_PERCENT_RATE": row["SLATE_TOP_1_PERCENT_RATE"],
            "PLAYER_P95": row["PLAYER_P95"],
            "PLAYER_P99": row["PLAYER_P99"],
            "TAIL_VOLATILITY": row["TAIL_VOLATILITY"],
        })
    _write_csv(
        out / "phase1_player_spike_frontier.csv",
        spike_rows,
        (
            "SPIKE_FRONTIER_RANK", "PLAYER_INDEX", "PLAYER", "SALARY",
            "PLAYER_SPIKE_SCORE", "PLAYER_SPIKE_RATE", "PRELOCK_SPIKE_PRIOR_SCORE",
            "SLATE_TOP_5_PERCENT_RATE", "SLATE_TOP_1_PERCENT_RATE",
            "PLAYER_P95", "PLAYER_P99", "TAIL_VOLATILITY",
        ),
    )
    lineups, phase2_receipt = build_calibration_qualified_lineups(
        golfers, frontier, tournament, cfg
    )
    phase2_rows = _lineup_rows(lineups, golfers)
    _write_csv(
        out / "phase2_calibration_qualified_matrix.csv",
        phase2_rows,
        ("LINEUP_ID", "G1", "G2", "G3", "G4", "G5", "G6", "SALARY"),
    )
    phase2_sha = sha256(out / "phase2_calibration_qualified_matrix.csv")
    phase3_worlds, phase3_survival, _ = simulate_players(
        golfers, simulations, phase3_seed, True
    )
    metrics = lineup_metrics(phase3_worlds, phase3_survival, lineups, golfers)
    metric_rows = [{key: value for key, value in row.items() if key != "_INDEX"} for row in metrics]
    _write_csv(
        out / "phase3_mc_candidate_metrics.csv",
        metric_rows,
        (
            "LINEUP_ID", "SALARY", "ALL_SIX_SURVIVE_RATE",
            "FIRST_PLACE_RATE", "TOP_0_1_PERCENT_RATE",
            "TOP_1_PERCENT_RATE", "TOURNAMENT_P999",
            "TOURNAMENT_CVAR99", "OWNERSHIP_PRODUCT",
        ),
    )
    positive_equity = [
        row for row in metrics
        if float(row["FIRST_PLACE_RATE"]) > 0
        or float(row["TOP_0_1_PERCENT_RATE"]) > 0
    ]
    if not positive_equity:
        raise EngineError("RUN_INVALID: PGA_CLASSIC_POSITIVE_TARGET_EQUITY_ROWS_ZERO")
    handoff_limit = len(metrics)
    handoff_metrics, handoff_receipt = select_handoff_metrics(
        metrics,
        lineups,
        golfers,
        handoff_limit,
    )
    phase2_ids = {row["LINEUP_ID"] for row in phase2_rows}
    phase3_ids = {row["LINEUP_ID"] for row in metrics}
    handoff_ids = {row["LINEUP_ID"] for row in handoff_metrics}
    if not (phase2_ids == phase3_ids == handoff_ids):
        raise EngineError("RUN_INVALID: PGA_CLASSIC_PHASE2_HANDOFF_SELECTOR_SET_MISMATCH")
    handoff_positive_equity = [
        row for row in handoff_metrics
        if float(row["FIRST_PLACE_RATE"]) > 0
        or float(row["TOP_0_1_PERCENT_RATE"]) > 0
    ]
    earned_rows = min(int(cfg["final_board_size"]), len(handoff_positive_equity))
    baseline = []
    by_id = {row["LINEUP_ID"]: row for row in phase2_rows}
    for rank, metric in enumerate(handoff_positive_equity[:earned_rows], 1):
        baseline.append({
            "BOARD_RANK": rank,
            **by_id[metric["LINEUP_ID"]],
            **{field: metric[field] for field in SELECTION_METRICS},
        })
    _write_csv(
        out / "code_pre_handoff_baseline.csv",
        baseline,
        ("BOARD_RANK", "LINEUP_ID", "G1", "G2", "G3", "G4", "G5", "G6", "SALARY", *SELECTION_METRICS),
    )
    contract = write_contract(
        out=out,
        golfers=golfers,
        lineups=lineups,
        metrics=handoff_metrics,
        target_rows=earned_rows,
        public_field_size=field_size,
    )
    stress_tests = {
        "HYPER_CHALK_MELTDOWN": "PASS" if "OWNERSHIP_PRODUCT" not in SELECTION_METRICS else "FAIL",
        "FLAT_PRICING_VOID": "PASS" if phase2_receipt["SCAN_COMPLETE"] else "FAIL",
        "POISON_PILL": "PASS" if len(frontier) >= 12 else "FAIL",
        "MAX_SALARY_COMPRESSION": "PASS" if all(int(row["SALARY"]) <= int(cfg["salary_cap"]) for row in phase2_rows) else "FAIL",
    }
    if any(value != "PASS" for value in stress_tests.values()):
        raise EngineError("RUN_INVALID: PGA_CLASSIC_STRESS_TEST_FAILURE")
    receipt: dict[str, Any] = {
        "PLUGIN_EXECUTION": "TOOL_PROVEN",
        "ENGINE_ID": ENGINE_ID,
        "ENGINE_VERSION": ENGINE_VERSION,
        "SKILL_ID": "apex-pga-classic-engine",
        "ROUTE": "PGA_CLASSIC_BUNDLED_ENGINE",
        "MODE": "PGA_CLASSIC",
        "SCORING_HORIZON": "FOUR_ROUNDS",
        "OUTCOME_LAYER": GENERALIZED_BINOMIAL_OUTCOME_STAT_LAYER,
        "INPUT_SHA256": sha256(input_path),
        "INPUT_PATH": str(Path(input_path).resolve()),
        "ELIGIBILITY_PATH": str(Path(eligibility_path).resolve()),
        "PREBUILD_AVAILABILITY": prebuild_gate,
        "PREBUILD_AVAILABILITY_GATE": "PASS_CODE_GENERATED_POOL_HASH_BOUND",
        **meta,
        **phase2_receipt,
        **contract,
        **handoff_receipt,
        "PUBLIC_FIELD_SIZE": field_size,
        "ACTIVE_POOL_SIZE": len(golfers),
        "PHASE1_FRONTIER_PLAYERS": len(frontier),
        "PHASE1_FRONTIER_PLAYER_INDICES": [int(index) for index in frontier],
        "PGA_PLAYER_SPIKE_MODEL_ACTIVE": True,
        "PGA_PLAYER_SPIKE_PHASE2_ADMISSION": False,
        "PGA_PLAYER_SPIKE_FRONTIER_ROLE": "SHADOW_RESEARCH_NONSELECTING",
        "PGA_PLAYER_SPIKE_MODEL_PATCH_ID": PGA_PLAYER_SPIKE_MODEL_PATCH_ID,
        "PHASE1_SPIKE_FRONTIER_PLAYERS": len(spike_frontier),
        "PHASE1_SPIKE_FRONTIER_PLAYER_INDICES": [int(index) for index in spike_frontier],
        "PHASE1_SPIKE_FRONTIER_SHA256": sha256(out / "phase1_player_spike_frontier.csv"),
        "PHASE1_BASELINE_SPIKE_UNION_PLAYERS": len(set(map(int, frontier)) | set(map(int, spike_frontier))),
        "PHASE1_SPIKE_POSTLOCK_RESULTS_USED": False,
        "PHASE1_CALIBRATION_SHA256": calibration_sha,
        "PHASE1_CALIBRATION_CREATED_BEFORE_LINEUP_BIRTH": True,
        "PHASE2_BUILDER_CONSUMED_CALIBRATION": True,
        "PHASE2_CALIBRATION_SHA256_CONSUMED": calibration_sha,
        "PHASE2_BUILT_LINEUPS": len(lineups),
        "PHASE2_CANDIDATE_MATRIX_SHA256": phase2_sha,
        "PHASE2_FROZEN_MEMBERSHIP_SHA256": phase2_sha,
        "PHASE2_LINEUP_ID_SET_SHA256": _lineup_id_set_sha256(phase2_rows),
        "PHASE3_EVALUATED_ROWS": len(metrics),
        "PHASE3_LINEUP_ID_SET_SHA256": _lineup_id_set_sha256(metrics),
        "SELECTOR_REVIEWED_LINEUPS": len(handoff_metrics),
        "HANDOFF_LINEUP_ID_SET_SHA256": _lineup_id_set_sha256(handoff_metrics),
        "SELECTOR_REVIEW_LINEUP_ID_SET_SHA256": _lineup_id_set_sha256(handoff_metrics),
        "PHASE2_HANDOFF_SELECTOR_SET_EQUAL": (
            len(lineups) == len(metrics) == len(handoff_metrics)
            and {row["LINEUP_ID"] for row in metrics}
            == {row["LINEUP_ID"] for row in handoff_metrics}
        ),
        "HANDOFF_COMPRESSION_USED": False,
        "PHASE2_PHASE3_ROW_PARITY": len(lineups) == len(metrics),
        "CALIBRATION_QUALIFIED_ROWS": len(lineups),
        "MONTE_CARLO_ITERATIONS": simulations,
        "MC_PASSES": 2,
        "PHASE1_MC_ITERATIONS": simulations,
        "PHASE3_MC_ITERATIONS": simulations,
        "PHASE1_MC_SEED": phase1_seed,
        "PHASE3_MC_SEED": phase3_seed,
        "PHASE1_MC_RECEIPT_SHA256": _array_sha256(phase1_worlds),
        "PHASE3_MC_RECEIPT_SHA256": _array_sha256(phase3_worlds),
        "PHASE1_MC_BEFORE_LINEUP_BIRTH": True,
        "PHASE2_FROZEN_BEFORE_PHASE3_MC": True,
        "PHASE3_MC_INDEPENDENT_FROM_PHASE1": True,
        "POST_FREEZE_POOL_EXPANSION": False,
        "COMPLETED_RUN_SOLVER": "CODE_AI_HYBRID",
        "HYBRID_SELECTOR": "PGA_CLASSIC_ANON_MC_PUZZLE_SELECTOR_v1_0",
        "AI_REVIEW_COVERAGE": "100_PERCENT",
        "AI_AUTHORITY_AFTER_HANDOFF": "100_PERCENT",
        "CODE_AFTER_HANDOFF": "LOOKUP_LEGALITY_HASH_ONLY",
        "FINAL_BOARD_ROWS": 0,
        "CODE_PRE_HANDOFF_BASELINE_ROWS": earned_rows,
        "EARNED_FINAL_BOARD_ROWS": earned_rows,
        "FINAL_BOARD_FILLERS_ALLOWED": False,
        "FINAL_BOARD_FILLER_ROWS": 0,
        "MEAN_SELECTION_WEIGHT": 0,
        "FILE_PROJECTION_SELECTION_WEIGHT": 0,
        "OWNERSHIP_DECISION_POSITION": "DIAGNOSTIC_ONLY_AFTER_MC_HIERARCHY",
        "FASTEST_CODING_METHODS_ONLY": True,
        "PYTHON_PER_LINEUP_SCORING": False,
        "DENSE_PLAYER_LINEUP_MATRIX": False,
        "BOUNDED_MEMORY": True,
        "FINAL_RENDER_FORMAT": "FIXED_ROSTER_COLUMNS",
        "JUMBLED_COLUMNS": False,
        "STRESS_TESTS": stress_tests,
        "STRESS_TEST_STATUS": "PASS",
        "PHASE_3_PROOF": "TOOL_PROVEN",
        "PHASE_3_95_PROOF": "AWAITING_AI_HANDOFF_SELECTION",
        "SEED": int(seed),
    }
    receipt["MC_PROOF_BLOCKS"] = {
        "PHASE1_PRE_BUILD": {
            "STATUS": "TOOL_PROVEN",
            "ITERATIONS": simulations,
            "SEED": phase1_seed,
            "SHA256": receipt["PHASE1_MC_RECEIPT_SHA256"],
            "EXECUTED_BEFORE_LINEUP_BIRTH": True,
            "CONSUMED_BY_PHASE2_BUILDER": True,
            "CALIBRATION_SHA256": calibration_sha,
        },
        "PHASE3_POST_FREEZE": {
            "STATUS": "TOOL_PROVEN",
            "ITERATIONS": simulations,
            "SEED": phase3_seed,
            "SHA256": receipt["PHASE3_MC_RECEIPT_SHA256"],
            "EXECUTED_AFTER_PHASE2_FREEZE": True,
            "INDEPENDENT_FROM_PHASE1": True,
            "FROZEN_MATRIX_SHA256": phase2_sha,
        },
    }
    (out / "execution_receipt.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return receipt
