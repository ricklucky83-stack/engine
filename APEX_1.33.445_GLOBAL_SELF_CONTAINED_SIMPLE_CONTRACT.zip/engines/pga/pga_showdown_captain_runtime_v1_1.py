from __future__ import annotations
import argparse, hashlib, importlib.util as _predictive_importlib_util, itertools, json, math, re, sys, time
from collections import Counter
from pathlib import Path

_STATE_ROOT_FOR_IMPORTS = Path(__file__).resolve().parents[2]
if str(_STATE_ROOT_FOR_IMPORTS) not in sys.path:
    sys.path.insert(0, str(_STATE_ROOT_FOR_IMPORTS))
import numpy as np
import pandas as pd
from engines.common.mandatory_prebuild_roster_gate_v1 import gate_receipt, require_prebuild_roster_check

ENGINE_ID='APEX_PGA_SHOWDOWN_CAPTAIN_RUNTIME_v1_1'
ENGINE_VERSION='1.1.0'
ROSTER_SIZE=6; SALARY_MIN=40000; SALARY_MAX=50000; CAPTAIN_MULTIPLIER=1.5
PLAYER_TRIALS=50000; BASE_TRIALS=10000; MAX_TRIALS=50000
STATE_ROOT=Path(__file__).resolve().parents[2]
DOCTRINE=STATE_ROOT/'doctrine/PGA_SHOWDOWN_CAPTAIN_MODE_RUNTIME_v1.json'
CALIBRATION=Path(__file__).with_name('pga_showdown_captain_calibration_v1_1.json')
HANDOFF=STATE_ROOT/'current_handoff/APEX_GLOBAL_ENGINE_REGISTRY_HANDOFF_OVERLAY_v1.json'
_PREDICTIVE_PATH=STATE_ROOT/'engines/common/apex_global_predictive_market_layer_v1.py'
_predictive_spec=_predictive_importlib_util.spec_from_file_location('apex_global_predictive_market_layer_v1',_PREDICTIVE_PATH)
if _predictive_spec is None or _predictive_spec.loader is None: raise RuntimeError('RUN_INVALID:GLOBAL_PREDICTIVE_MARKET_LAYER_UNAVAILABLE')
global_predictive=_predictive_importlib_util.module_from_spec(_predictive_spec); _predictive_spec.loader.exec_module(global_predictive)
REQ=('PLAYER','SAL','FPTS','RST%','Tee Time','STRIKE','BOUNCE','ACC','DIST','GIR','PUTS/RND','SAND','SCRAMB','AVG/RND')

class EngineError(RuntimeError): pass

def sha256(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def stable_hash(x)->str: return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def num(s): return pd.to_numeric(s.astype(str).str.replace('$','',regex=False).str.replace(',','',regex=False).str.replace('%','',regex=False).str.strip(),errors='coerce')
def pr(x, higher=True):
 x=np.asarray(x,float); x=np.where(np.isfinite(x),x,np.nanmedian(x)); order=np.argsort(x if higher else -x,kind='mergesort'); out=np.empty(len(x)); out[order]=np.linspace(0,1,len(x)); return out

def parse_time(v):
 m=re.match(r'(\d{1,2}):(\d{2})\s*([AP]M)',str(v).strip(),re.I)
 if not m:return np.nan
 h,mi,ap=int(m.group(1)),int(m.group(2)),m.group(3).upper(); h=(h%12)+(12 if ap=='PM' else 0); return h*60+mi

def load_contracts():
 d=json.loads(DOCTRINE.read_text()); c=json.loads(CALIBRATION.read_text()); h=json.loads(HANDOFF.read_text())
 if d.get('DOCTRINE_ID')!='PGA_SHOWDOWN_CAPTAIN_MODE_RUNTIME_v1': raise EngineError('PGA_CAPTAIN_DOCTRINE_ID_MISMATCH')
 if d.get('ROSTER',{}).get('CAPTAIN') is not True: raise EngineError('PGA_CAPTAIN_ROLE_MISSING')
 if float(d.get('ROSTER',{}).get('CAPTAIN_FPTS_MULTIPLIER',0))!=CAPTAIN_MULTIPLIER: raise EngineError('PGA_CAPTAIN_FPTS_MULTIPLIER_MISMATCH')
 if float(d.get('ROSTER',{}).get('CAPTAIN_SALARY_MULTIPLIER',0))!=CAPTAIN_MULTIPLIER: raise EngineError('PGA_CAPTAIN_SALARY_MULTIPLIER_MISMATCH')
 if c.get('ENGINE_ID')!=ENGINE_ID or c.get('VERSION')!=ENGINE_VERSION: raise EngineError('PGA_CAPTAIN_CALIBRATION_ID_MISMATCH')
 if h.get('PATCH_ID')!='HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1': raise EngineError('HANDOFF_PATCH_MISSING')
 g=h.get('GLOBAL_RULES',{})
 if g.get('MINIMUM_BASE_SIM_TRIALS')!=BASE_TRIALS or g.get('MAX_PHYSICAL_SIM_TRIALS')!=MAX_TRIALS: raise EngineError('HANDOFF_TRIAL_CONTRACT_MISMATCH')
 return d,c,h

def load_pool(path:Path, verified_out_names=()):
 df=pd.read_csv(path); missing=[c for c in REQ if c not in df.columns]
 if missing: raise EngineError('MISSING_REQUIRED_COLUMNS:'+','.join(missing))
 df=df.copy(); df['PLAYER']=df.PLAYER.astype(str).str.strip(); df['SALARY']=num(df.SAL).fillna(0).astype(int); df['FPTS0']=num(df.FPTS).fillna(0.)
 own=num(df['RST%']).fillna(0.); own=np.where(own>1,own/100,own); df['OWN']=np.clip(own,.001,.75)
 local_status_candidate=df.get('STATUS',pd.Series('',index=df.index)).astype(str).str.strip().str.upper().isin({'OUT','WD','W/D','WITHDRAWN'})
 explicit=df['PLAYER'].isin(set(map(str,verified_out_names)))
 df['LOCAL_STATUS_UNCERTAIN']=local_status_candidate & (~explicit); df['OUT']=explicit; df=df[(~df.OUT)&df.SALARY.between(1,SALARY_MAX)].reset_index(drop=True)
 if len(df)<ROSTER_SIZE: raise EngineError('ACTIVE_POOL_TOO_SMALL')
 predictive_features=global_predictive.build_predictive_features(df,sport='PGA',mode='SHOWDOWN_FLAT_6')
 predictive_evidence=predictive_features.player_market_available|predictive_features.game_market_available
 predictive_weight=np.where(predictive_evidence,.05+.10*predictive_features.confidence.astype(float),0.0)
 predictive_upside=predictive_features.dfs_upside_score.astype(float)
 for c in ['STRIKE','BOUNCE','ACC','DIST','GIR','PUTS/RND','SAND','SCRAMB','AVG/RND']: df[c+'0']=num(df[c])
 tee=df['Tee Time'].map(parse_time).astype(float); tee=tee.fillna(tee.median()); df['TEE_MIN']=tee
 q1,q2=np.quantile(tee,[1/3,2/3]); df['WAVE']=np.where(tee<=q1,0,np.where(tee<=q2,1,2)).astype(np.int8)
 fpts=pr(df.FPTS0,True); strike=pr(df.STRIKE0,False); bounce=pr(df.BOUNCE0,True); acc=pr(df.ACC0,True); dist=pr(df.DIST0,True); gir=pr(df.GIR0,True); putt=pr(df['PUTS/RND0'],False); sand=pr(df.SAND0,True); scr=pr(df.SCRAMB0,True); avg=pr(df['AVG/RND0'],False)
 tee_edge=np.full(len(df),.5); weather=np.full(len(df),.5)
 skill=.32*fpts+.13*strike+.10*bounce+.055*acc+.005*dist+.11*gir+.08*putt+.02*sand+.08*scr+.08*avg+.02*tee_edge
 skill=(1-predictive_weight)*skill+predictive_weight*predictive_upside
 ceiling=.34*fpts+.15*bounce+.16*gir+.12*strike+.08*putt+.07*scr+.04*dist+.04*(1-df.OWN.to_numpy())
 ceiling=(1-predictive_weight)*ceiling+predictive_weight*predictive_upside
 birdie=.35*fpts+.25*bounce+.20*gir+.10*dist+.10*putt
 streak=.45*birdie+.25*ceiling+.15*strike+.15*(1-df.OWN.to_numpy())
 bogey=.35*avg+.25*scr+.20*putt+.10*gir+.10*acc
 volatility=np.clip(7.0+5.0*(1-bogey)+3.0*streak+2.0*(1-df.OWN.to_numpy()),6,18)
 mean=df.FPTS0.to_numpy()*(.82+.28*skill)
 df['SKILL']=skill; df['ROUND_CEILING']=ceiling; df['BIRDIE_RATE']=birdie; df['STREAK_PATH']=streak; df['BOGEY_AVOID']=bogey; df['TEE_EDGE']=tee_edge; df['WEATHER_EDGE']=weather; df['VOL']=volatility; df['MEAN']=mean; df['PREDICTIVE_UPSIDE']=predictive_upside
 return df, {'ACTIVE_POOL':len(df),'OUT_PURGE':int(explicit.sum()),'WEATHER_EDGE':'NEUTRAL_NO_INPUT','CLASSIC_METRICS_USED':False,'PREDICTIVE_RECEIPT':predictive_features.receipt}

def enumerate_legal(df):
 sal=df.SALARY.to_numpy(dtype=np.int64); out=[]; attempts=0
 for comb in itertools.combinations(range(len(df)),ROSTER_SIZE):
  base=int(sal[list(comb)].sum())
  for cpt in comb:
   attempts+=1; total=base+int(round((CAPTAIN_MULTIPLIER-1.0)*sal[cpt]))
   if SALARY_MIN<=total<=SALARY_MAX:
    flex=tuple(i for i in comb if i!=cpt); out.append((cpt,*flex))
 if not out: raise EngineError('NO_LEGAL_CAPTAIN_ROSTER_UNIVERSE')
 return np.asarray(out,dtype=np.int16),attempts

def lineup_salary(rows,df):
 sal=df.SALARY.to_numpy(dtype=np.float64); return (CAPTAIN_MULTIPLIER*sal[rows[:,0]]+sal[rows[:,1:]].sum(1)).astype(np.int64)

def select_phase2(legal,ps,df,target=25000):
 if len(legal)<=target: return legal
 p95,p99=np.quantile(ps,[.95,.99],axis=0); mean=ps.mean(0); ceil=df.ROUND_CEILING.to_numpy(); own=np.maximum(df.OWN.to_numpy(),.001)
 def role_sum(v): return CAPTAIN_MULTIPLIER*v[legal[:,0]]+v[legal[:,1:]].sum(1)
 lanes=[role_sum(p99),role_sum(p95),role_sum(mean)+8.0*role_sum(ceil),role_sum(p99)-2.5*np.log(np.prod(own[legal],axis=1))]
 reserve=max(1,target//8); chosen=set()
 for v in lanes:
  ix=np.argpartition(v,-reserve)[-reserve:]; chosen.update(map(int,ix))
 if len(chosen)<target:
  z=[]
  for v in lanes:
   sd=float(np.std(v)) or 1.0; z.append((v-float(np.mean(v)))/sd)
  comp=np.maximum.reduce(z)
  need=target-len(chosen); mask=np.ones(len(legal),dtype=bool)
  if chosen: mask[np.fromiter(chosen,dtype=np.int64)]=False
  avail=np.flatnonzero(mask); add=avail[np.argpartition(comp[avail],-need)[-need:]]; chosen.update(map(int,add))
 ix=np.asarray(sorted(chosen),dtype=np.int64)
 if len(ix)>target:
  # Deterministic cross-lane best-rank trim if reserve overlap is unusually low.
  rank=np.full(len(legal),len(legal),dtype=np.int32)
  for v in lanes:
   o=np.argsort(-v,kind='mergesort'); rr=np.empty(len(legal),dtype=np.int32); rr[o]=np.arange(len(legal),dtype=np.int32); rank=np.minimum(rank,rr)
  ix=ix[np.argsort(rank[ix],kind='mergesort')[:target]]
 return legal[np.sort(ix)]

def player_scores(df,rng,trials):
 n=len(df); common=rng.normal(size=(trials,1)).astype(np.float32); wave=rng.normal(size=(trials,3)).astype(np.float32); indiv=rng.normal(size=(trials,n)).astype(np.float32)
 tail=rng.gamma(2.0,1.0,size=(trials,n)).astype(np.float32); trig=rng.random((trials,n)) < np.clip(.035+.13*df.STREAK_PATH.to_numpy()+.05*(1-df.OWN.to_numpy()),.03,.22)
 mean=df.MEAN.to_numpy(np.float32); vol=df.VOL.to_numpy(np.float32); waves=df.WAVE.to_numpy()
 score=mean+2.2*common+1.3*wave[:,waves]+indiv*vol+trig*tail*(2.2+3.5*df.ROUND_CEILING.to_numpy())
 return np.maximum(score,-5).astype(np.float32)

def lineup_scores(ps,a):
 s=CAPTAIN_MULTIPLIER*ps[:,a[:,0]].astype(np.float32,copy=False)
 for j in range(1,ROSTER_SIZE): s+=ps[:,a[:,j]]
 return s

def field_thresholds(ps,field,contest_size,topn):
 t=ps.shape[0]; rank=max(1,int(math.ceil(len(field)*topn/max(contest_size,1)))); top=np.full((t,rank),-np.inf,np.float32)
 for start in range(0,len(field),400):
  s=lineup_scores(ps,field[start:start+400]); z=np.concatenate([top,s],axis=1); top=np.partition(z,-rank,axis=1)[:,-rank:]
 return top.max(1),top.min(1),rank

def score_rows(ps,rows,win_thr,top_thr,chunk=600):
 out=np.empty((len(rows),5),dtype=np.float64); n=ps.shape[0]
 for start in range(0,len(rows),chunk):
  a=rows[start:start+chunk]; s=lineup_scores(ps,a)
  q=np.quantile(s,[.95,.99],axis=0); out[start:start+len(a),0]=s.mean(0); out[start:start+len(a),1]=q[0]; out[start:start+len(a),2]=q[1]; out[start:start+len(a),3]=(s>=win_thr[:,None]).mean(0); out[start:start+len(a),4]=(s>=top_thr[:,None]).mean(0)
 return out

def wilson(p,n,z=1.96):
 den=1+z*z/n; c=(p+z*z/(2*n))/den; h=z*np.sqrt((p*(1-p)+z*z/(4*n))/n)/den; return np.maximum(0,c-h),np.minimum(1,c+h)

def field_weights(rows,df):
 own=np.maximum(df.OWN.to_numpy(),.001); ceil=np.maximum(df.ROUND_CEILING.to_numpy(),.02)
 roster=np.prod(own[rows],axis=1); cpt=(own[rows[:,0]]**.35)*(ceil[rows[:,0]]**1.25)
 w=np.maximum(roster*cpt,1e-30); return w/w.sum()

def sample_field(rng,legal,df,target):
 p=field_weights(legal,df); idx=rng.choice(len(legal),size=target,replace=True,p=p); return legal[idx],target

def run(pool,field_size,execution_id,out_dir,seed=2378,board_size=10,availability_receipt=None):
 t0=time.time(); doctrine,cal,handoff=load_contracts(); roster_gate=require_prebuild_roster_check(availability_receipt,sport='PGA',mode='SHOWDOWN_CAPTAIN',pool_path=pool,execution_id=execution_id,field_size=field_size); df,poolrec=load_pool(Path(pool),roster_gate.out_players); rng=np.random.default_rng(seed)
 legal,attempts=enumerate_legal(df); ps=player_scores(df,rng,PLAYER_TRIALS); rows=select_phase2(legal,ps,df,25000); salary=lineup_salary(rows,df); phase2_hash=stable_hash(rows.tolist())
 own=df.OWN.to_numpy(); fake_target=max(field_size,int(math.ceil(field_size*3.4))); field,field_attempts=sample_field(rng,legal,df,fake_target); dup=Counter(map(tuple,field.tolist()))
 topn=max(1,math.ceil(field_size*.001)); base_ps=ps[:BASE_TRIALS]; wthr,tthr,field_rank=field_thresholds(base_ps,field,field_size,topn); base=score_rows(base_ps,rows,wthr,tthr)
 ownprod=np.prod(np.maximum(own[rows],.001),axis=1); dups=np.asarray([dup.get(tuple(x),0) for x in rows]); order=np.lexsort((salary,ownprod,dups,-base[:,1],-base[:,2],-base[:,3],-base[:,4]))
 cutoff_pos=min(max(board_size*5,50),len(rows)-1); cut=order[cutoff_pos]; lo,hi=wilson(base[:,4],BASE_TRIALS); clo,chi=lo[cut],hi[cut]; front=order[:min(1200,len(order))]; bubble=front[(hi[front]>=clo)&(lo[front]<=chi)]
 if len(bubble)<128:bubble=order[:min(128,len(order))]
 bubble=bubble[:512]; extra_trials=MAX_TRIALS-BASE_TRIALS; unresolved=0; final=base.copy()
 if len(bubble):
  eps=ps[BASE_TRIALS:]; ew,et,_=field_thresholds(eps,field,field_size,topn); ext=score_rows(eps,rows[bubble],ew,et); full=lineup_scores(ps,rows[bubble]); q=np.quantile(full,[.95,.99],axis=0)
  final[bubble,0]=(base[bubble,0]*BASE_TRIALS+ext[:,0]*extra_trials)/MAX_TRIALS; final[bubble,1]=q[0]; final[bubble,2]=q[1]; final[bubble,3]=(base[bubble,3]*BASE_TRIALS+ext[:,3]*extra_trials)/MAX_TRIALS; final[bubble,4]=(base[bubble,4]*BASE_TRIALS+ext[:,4]*extra_trials)/MAX_TRIALS
  flo,fhi=wilson(final[bubble,4],MAX_TRIALS); unresolved=int(((flo<=chi)&(fhi>=clo)).sum())
 order=np.lexsort((salary,ownprod,dups,-final[:,1],-final[:,2],-final[:,3],-final[:,4]))
 board=[]; exp=Counter(); cpt_exp=Counter()
 for idx in order:
  r=rows[idx]; st=set(map(int,r)); cpt=int(r[0])
  if exp[cpt]>=7 or cpt_exp[cpt]>=3 or any(exp[x]>=7 for x in st): continue
  if any(len(st&set(b['_idx']))>4 for b in board): continue
  for x in st: exp[x]+=1
  cpt_exp[cpt]+=1
  board.append({'LINEUP_RANK':len(board)+1,'CPT':df.PLAYER.iloc[cpt], 'FLEX':df.PLAYER.iloc[r[1:]].tolist(), 'SALARY':int(salary[idx]),'SALARY_LEFT':int(SALARY_MAX-salary[idx]),'MC_TOP_0_1_RATE':float(final[idx,4]),'MC_WIN_RATE':float(final[idx,3]),'MC_P95':float(final[idx,1]),'MC_P99':float(final[idx,2]),'MC_MEAN':float(final[idx,0]),'OWNERSHIP_PRODUCT':float(ownprod[idx]),'FAKE_FIELD_DUP_COUNT':int(dups[idx]),'_idx':r.tolist()})
  if len(board)>=board_size: break
 if len(board)<board_size: raise EngineError(f'FINAL_BOARD_SHORTFALL:{len(board)}:{board_size}')
 for b in board:b.pop('_idx')
 out_dir=Path(out_dir); out_dir.mkdir(parents=True,exist_ok=True)
 manifest=pd.DataFrame({'PHASE2_ROW':np.arange(len(rows)),'CPT':df.PLAYER.iloc[rows[:,0]].to_numpy(),'FLEX1':df.PLAYER.iloc[rows[:,1]].to_numpy(),'FLEX2':df.PLAYER.iloc[rows[:,2]].to_numpy(),'FLEX3':df.PLAYER.iloc[rows[:,3]].to_numpy(),'FLEX4':df.PLAYER.iloc[rows[:,4]].to_numpy(),'FLEX5':df.PLAYER.iloc[rows[:,5]].to_numpy(),'SALARY':salary,'MC_TOP_0_1_RATE':final[:,4],'MC_WIN_RATE':final[:,3],'P95':final[:,1],'P99':final[:,2],'OWNERSHIP_PRODUCT':ownprod,'DUP_COUNT':dups})
 mpath=out_dir/f'{execution_id}_phase2_manifest.csv'; manifest.to_csv(mpath,index=False)
 bpath=out_dir/f'{execution_id}_final_board.csv'; pd.DataFrame([{**{'CPT':b['CPT']},**{f'FLEX{i+1}':p for i,p in enumerate(b['FLEX'])},**{k:v for k,v in b.items() if k not in {'CPT','FLEX'}}} for b in board]).to_csv(bpath,index=False)
 metric_bundle={'PLAYER_ORDER':df.PLAYER.tolist(),'MEAN':df.MEAN.round(8).tolist(),'VOL':df.VOL.round(8).tolist(),'OWN':df.OWN.round(8).tolist(),'ROUND_CEILING':df.ROUND_CEILING.round(8).tolist(),'WAVE':df.WAVE.tolist(),'CAPTAIN_MULTIPLIER':CAPTAIN_MULTIPLIER}; metric_hash=stable_hash(metric_bundle); predrec=poolrec['PREDICTIVE_RECEIPT']
 state_version=json.loads((STATE_ROOT/'bundle_manifest.json').read_text()).get('STATE_VERSION','UNKNOWN')
 receipt={'RUN_STATE':'TOOL_PROVEN_EXECUTED','PREBUILD_ROSTER_CHECK':gate_receipt(roster_gate),'ENGINE_ID':ENGINE_ID,'ENGINE_VERSION':ENGINE_VERSION,'EXECUTION_ID':execution_id,'PLATFORM':'DK','SPORT':'PGA','MODE':'SHOWDOWN_CAPTAIN','FIELD_SIZE':field_size,'GLOBAL_STATE_VERSION':state_version,'PREDICTIVE_LAYER_PATCH_ID':predrec['PATCH_ID'],'PREDICTIVE_LAYER_STATUS':predrec['STATUS'],'PREDICTION_HASH':predrec['PREDICTION_HASH'],'STRATEGY_CONSUMED_PREDICTION_HASH':predrec['PREDICTION_HASH'],'DOCTRINE_HASH':sha256(DOCTRINE),'CALIBRATION_HASH':sha256(CALIBRATION),'HANDOFF_HASH':sha256(HANDOFF),'METRIC_BUNDLE_HASH_PHASE2':metric_hash,'METRIC_BUNDLE_HASH_PHASE3':metric_hash,'METRIC_PARITY':'PASS','ACTIVE_POOL':poolrec['ACTIVE_POOL'],'OUT_PURGE':poolrec['OUT_PURGE'],'CLASSIC_METRICS_USED':False,'WEATHER_EDGE':poolrec['WEATHER_EDGE'],'CAPTAIN':True,'CAPTAIN_FPTS_MULTIPLIER':CAPTAIN_MULTIPLIER,'CAPTAIN_SALARY_MULTIPLIER':CAPTAIN_MULTIPLIER,'LEGAL_GENERATION_ATTEMPTS':attempts,'LEGAL_ROSTER_UNIVERSE':len(legal),'PHASE2_BUILT_LINEUPS':len(rows),'PHASE2_HASH':phase2_hash,'BASE_SIM_TRIALS':BASE_TRIALS,'BUBBLE_LINEUPS':len(bubble),'BUBBLE_EXTRA_TRIALS_TOTAL':int(len(bubble)*extra_trials),'BUBBLE_LINEUPS_UNRESOLVED':unresolved,'HANDOFF_SURVIVORS':len(rows),'SELECTOR_REVIEWED_LINEUPS':len(rows),'FAKE_FIELD_ENTRIES':len(field),'FAKE_FIELD_GENERATION_ATTEMPTS':field_attempts,'TOP_0_1_FIELD_THRESHOLD_ORDER':field_rank,'FINAL_BOARD_SIZE':len(board),'FINAL_BOARD':board,'PHASE2_MANIFEST':str(mpath),'FINAL_BOARD_CSV':str(bpath),'RUNTIME_SECONDS':round(time.time()-t0,3),'EXECUTION_STATE':'TOOL_PROVEN_EXECUTED'}
 rpath=out_dir/f'{execution_id}_final_receipt.json'; rpath.write_text(json.dumps(receipt,indent=2)+'\n'); receipt['FINAL_RECEIPT']=str(rpath); return receipt

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--input-csv',required=True); ap.add_argument('--field-size',required=True,type=int); ap.add_argument('--execution-id',required=True); ap.add_argument('--availability-receipt',required=True); ap.add_argument('--output-dir',required=True); ap.add_argument('--seed',type=int,default=2378); ap.add_argument('--board-size',type=int,default=10); a=ap.parse_args()
 try: print(json.dumps(run(a.input_csv,a.field_size,a.execution_id,a.output_dir,a.seed,a.board_size,a.availability_receipt),indent=2))
 except Exception as e: print(json.dumps({'RUN_STATE':'RUN_INVALID','ENGINE_ID':ENGINE_ID,'FINAL_BOARD_SIZE':0,'FAILURE_CODE':f'{type(e).__name__}:{e}'},indent=2)); raise SystemExit(1)
if __name__=='__main__':main()
