#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

PATCH_ID = "APEX_HISTORICAL_CERTIFICATION_PROTOCOL_v1"
RUNNER_ID = "APEX_HISTORICAL_CERTIFICATION_RUNNER_v1"
POSTLOCK_ENV_KEYS = {
    "APEX_CONTEST_FILE",
    "APEX_POSTSEAL_WINNER_JSON",
    "APEX_ACTUAL_RESULTS",
    "APEX_FINAL_OWNERSHIP",
}
GEN_SUFFIXES = {"jr", "sr", "ii", "iii", "iv"}
DEFAULT_IDENTITY_ALIASES = {
    "kike hernandez": "enrique hernandez",
    "kik hernandez": "enrique hernandez",
}


class CertificationError(RuntimeError):
    pass


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def normalize_name(value: object) -> str:
    text = re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()
    return re.sub(r"\s+", " ", text)


def identity_name(value: object, aliases: dict[str, str] | None = None) -> str:
    tokens = normalize_name(value).split()
    while tokens and tokens[-1] in GEN_SUFFIXES:
        tokens.pop()
    ident = " ".join(tokens)
    mapping = dict(DEFAULT_IDENTITY_ALIASES)
    if aliases:
        mapping.update({normalize_name(k): normalize_name(v) for k, v in aliases.items()})
    return mapping.get(ident, ident)


def parse_showdown_lineup(value: object) -> tuple[str, list[str]]:
    text = re.sub(r"\s+", " ", str(value)).strip()
    parts = re.split(r"\s+(?=(?:CPT|UTIL)\s)", text)
    cpt = ""
    utils: list[str] = []
    for part in parts:
        if part.startswith("CPT "):
            cpt = part[4:].strip()
        elif part.startswith("UTIL "):
            utils.append(part[5:].strip())
    if not cpt or len(utils) != 5:
        raise CertificationError(f"SHOWDOWN_LINEUP_PARSE_FAILURE:{value}")
    return cpt, utils


def showdown_key(cpt: object, utils: Iterable[object], aliases: dict[str, str] | None = None) -> str:
    c = identity_name(cpt, aliases)
    u = sorted(identity_name(x, aliases) for x in utils)
    return f"CPT:{c}|UTIL:{'|'.join(u)}"


def contest_frame(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".zip":
        import zipfile
        with zipfile.ZipFile(path) as z:
            members = sorted(x for x in z.namelist() if x.lower().endswith(".csv"))
            if not members:
                raise CertificationError("CONTEST_ZIP_NO_CSV")
            with z.open(members[0]) as f:
                return pd.read_csv(f)
    return pd.read_csv(path)


def _contest_base_points(frame: pd.DataFrame, aliases: dict[str, str] | None = None) -> dict[str, float]:
    required = {"Player", "Roster Position", "FPTS"}
    if not required.issubset(frame.columns):
        return {}
    values: dict[str, list[float]] = {}
    for _, row in frame.dropna(subset=["Player", "FPTS"]).iterrows():
        try:
            val = float(row["FPTS"])
        except Exception:
            continue
        if str(row.get("Roster Position", "")).strip().upper() == "CPT":
            val /= 1.5
        key = identity_name(row["Player"], aliases)
        values.setdefault(key, []).append(val)
    return {k: float(np.median(v)) for k, v in values.items() if v}


def score_showdown_board(
    board_path: Path,
    contest_path: Path,
    contest_size: int | None = None,
    aliases: dict[str, str] | None = None,
) -> dict:
    board = pd.read_csv(board_path)
    contest = contest_frame(contest_path)
    required_board = {"CPT", "UTIL1", "UTIL2", "UTIL3", "UTIL4", "UTIL5"}
    if not required_board.issubset(board.columns):
        raise CertificationError(f"BOARD_COLUMNS_MISSING:{sorted(required_board - set(board.columns))}")
    if not {"Rank", "Lineup"}.issubset(contest.columns):
        raise CertificationError("CONTEST_COLUMNS_MISSING:Rank,Lineup")
    n = int(contest_size or len(contest))
    if n <= 0:
        raise CertificationError("CONTEST_SIZE_INVALID")

    exact_rank: dict[str, int] = {}
    numeric_rank = pd.to_numeric(contest["Rank"], errors="coerce")
    for idx, row in contest.loc[numeric_rank.notna()].iterrows():
        try:
            cpt, utils = parse_showdown_lineup(row["Lineup"])
        except CertificationError:
            continue
        key = showdown_key(cpt, utils, aliases)
        rank = int(numeric_rank.loc[idx])
        exact_rank[key] = min(rank, exact_rank.get(key, rank))

    point_map = _contest_base_points(contest, aliases)
    contest_points = pd.to_numeric(contest.get("Points", pd.Series(dtype=float)), errors="coerce").dropna().to_numpy(float)
    rows = []
    for board_rank, (_, row) in enumerate(board.iterrows(), start=1):
        utils = [row[f"UTIL{i}"] for i in range(1, 6)]
        key = showdown_key(row["CPT"], utils, aliases)
        erank = exact_rank.get(key)
        names = [row["CPT"], *utils]
        ids = [identity_name(x, aliases) for x in names]
        missing = [names[i] for i, ident in enumerate(ids) if ident not in point_map]
        actual_points = None
        virtual_rank = None
        if not missing and len(contest_points):
            actual_points = 1.5 * point_map[ids[0]] + sum(point_map[x] for x in ids[1:])
            virtual_rank = 1 + int(np.sum(contest_points > actual_points + 1e-9))
        actual_rank = erank if erank is not None else virtual_rank
        rows.append({
            "BOARD_RANK": int(row.get("RANK", board_rank)),
            "EXACT_FIELD_MATCH_RANK": erank,
            "VIRTUAL_IF_PLAYED_RANK": virtual_rank,
            "ACTUAL_RANK_FOR_SCORING": actual_rank,
            "ACTUAL_POINTS": actual_points,
            "MISSING_LABEL_PLAYERS": [str(x) for x in missing],
            "LINEUP_KEY": key,
        })

    ranks = [int(r["ACTUAL_RANK_FOR_SCORING"]) for r in rows if r["ACTUAL_RANK_FOR_SCORING"] is not None]
    if not ranks:
        raise CertificationError("NO_BOARD_LINEUP_COULD_BE_SCORED")
    denom = len(rows)
    thresholds = {
        "TOP_10_PERCENT_RATE": math.ceil(n * 0.10),
        "TOP_1_PERCENT_RATE": math.ceil(n * 0.01),
        "TOP_0_1_PERCENT_RATE": math.ceil(n * 0.001),
    }
    metrics = {
        "CONTEST_SIZE": n,
        "BOARD_SIZE": denom,
        "SCORED_BOARD_LINES": len(ranks),
        "BEST_BOARD_ACTUAL_RANK": int(min(ranks)),
        "MEDIAN_BOARD_RANK": float(np.median(ranks)),
        "TOP_10_PERCENT_RATE": sum(x <= thresholds["TOP_10_PERCENT_RATE"] for x in ranks) / denom,
        "TOP_1_PERCENT_RATE": sum(x <= thresholds["TOP_1_PERCENT_RATE"] for x in ranks) / denom,
        "TOP_0_1_PERCENT_RATE": sum(x <= thresholds["TOP_0_1_PERCENT_RATE"] for x in ranks) / denom,
        "EXACT_FIELD_MATCH_RATE": sum(r["EXACT_FIELD_MATCH_RANK"] is not None for r in rows) / denom,
    }
    return {"RUNNER_ID": RUNNER_ID, "PATCH_ID": PATCH_ID, "METRICS": metrics, "BOARD_ROWS": rows}


def score_postlock_rank_file(path: Path, contest_size: int, rank_column: str = "CONTEST_RANK") -> dict:
    frame = pd.read_csv(path)
    if rank_column not in frame.columns:
        raise CertificationError(f"POSTLOCK_RANK_COLUMN_MISSING:{rank_column}")
    ranks = pd.to_numeric(frame[rank_column], errors="coerce").dropna().astype(int).tolist()
    if not ranks:
        raise CertificationError("POSTLOCK_RANKS_EMPTY")
    denom = len(frame)
    return {
        "CONTEST_SIZE": int(contest_size),
        "BOARD_SIZE": int(denom),
        "SCORED_BOARD_LINES": len(ranks),
        "BEST_BOARD_ACTUAL_RANK": int(min(ranks)),
        "MEDIAN_BOARD_RANK": float(np.median(ranks)),
        "TOP_10_PERCENT_RATE": sum(x <= math.ceil(contest_size * 0.10) for x in ranks) / denom,
        "TOP_1_PERCENT_RATE": sum(x <= math.ceil(contest_size * 0.01) for x in ranks) / denom,
        "TOP_0_1_PERCENT_RATE": sum(x <= math.ceil(contest_size * 0.001) for x in ranks) / denom,
    }


def rolling_origin_splits(slate_ids: list[str], min_train: int) -> list[dict]:
    if min_train < 1 or len(slate_ids) <= min_train:
        return []
    return [
        {"TRAIN": slate_ids[:i], "TEST": slate_ids[i]}
        for i in range(min_train, len(slate_ids))
    ]


def validate_replay_spec(spec: dict) -> None:
    prelock = {str(Path(x).resolve()) for x in spec.get("prelock_files", [])}
    label = spec.get("label_file")
    if not prelock:
        raise CertificationError("PRELOCK_FILES_REQUIRED")
    if label and str(Path(label).resolve()) in prelock:
        raise CertificationError("LEAKAGE_LABEL_FILE_PRESENT_IN_PRELOCK_SET")
    for key in POSTLOCK_ENV_KEYS:
        if key in spec.get("engine_env", {}) and spec["engine_env"].get(key):
            raise CertificationError(f"LEAKAGE_POSTLOCK_ENV_SET:{key}")
    if spec.get("split") == "LOCKED_HISTORICAL_HOLDOUT" and spec.get("labels_used_for_candidate_tuning"):
        raise CertificationError("HOLDOUT_CONTAMINATED_BY_TUNING")


def classify_evidence(spec: dict) -> str:
    if spec.get("split") == "LOCKED_HISTORICAL_HOLDOUT" and not spec.get("labels_used_for_candidate_tuning") and spec.get("prelock_frozen"):
        return "LOCKED_CURRENT_HOLDOUT"
    if spec.get("blind_proven") and spec.get("prelock_frozen"):
        return "LEGACY_BLIND_HOLDOUT"
    if spec.get("labels_revealed"):
        return "DEVELOPMENT_AFTER_REVEAL"
    if spec.get("prelock_frozen"):
        return "FROZEN_PRELOCK_SCORE"
    return "UNQUALIFIED_EVIDENCE"


def run_time_frozen_replay(spec: dict) -> dict:
    validate_replay_spec(spec)
    if not spec.get("engine_command"):
        raise CertificationError("ENGINE_COMMAND_REQUIRED")
    label_file = Path(spec["label_file"]).resolve() if spec.get("label_file") else None
    with tempfile.TemporaryDirectory(prefix="apex_hist_replay_") as td:
        run_dir = Path(td)
        copied = []
        for src_s in spec["prelock_files"]:
            src = Path(src_s).resolve()
            if not src.exists():
                raise CertificationError(f"PRELOCK_FILE_MISSING:{src}")
            dst = run_dir / src.name
            shutil.copy2(src, dst)
            copied.append(dst)
        env = os.environ.copy()
        for key in POSTLOCK_ENV_KEYS:
            env.pop(key, None)
        env.update({str(k): str(v) for k, v in spec.get("engine_env", {}).items()})
        env["APEX_EXECUTION_MODE"] = "PRODUCTION"
        mapping = {str(Path(x).resolve()): str(y) for x, y in zip(spec["prelock_files"], copied)}
        for key, value in list(env.items()):
            if value in mapping:
                env[key] = mapping[value]
        cmd = [str(x) for x in spec["engine_command"]]
        proc = subprocess.run(cmd, cwd=spec.get("engine_cwd"), env=env, text=True, capture_output=True)
        if proc.returncode != 0:
            raise CertificationError(f"ENGINE_REPLAY_FAILED:{proc.returncode}:{proc.stderr[-4000:]}")
        outputs = []
        for out_s in spec.get("freeze_outputs", []):
            p = Path(out_s)
            if not p.is_absolute():
                p = run_dir / p
            if not p.exists():
                raise CertificationError(f"FREEZE_OUTPUT_MISSING:{p}")
            outputs.append({"path": str(p), "sha256": sha256(p), "bytes": p.stat().st_size})
        freeze_receipt = {
            "PATCH_ID": PATCH_ID,
            "FREEZE_COMPLETE": True,
            "POSTLOCK_ENV_KEYS_PRESENT": [k for k in POSTLOCK_ENV_KEYS if env.get(k)],
            "OUTPUTS": outputs,
            "STDOUT_SHA256": hashlib.sha256(proc.stdout.encode()).hexdigest(),
        }
        # Label is intentionally touched only after the immutable output hashes exist.
        result = {"FREEZE_RECEIPT": freeze_receipt, "EVIDENCE_CLASS": classify_evidence(spec)}
        if label_file:
            if not label_file.exists():
                raise CertificationError(f"LABEL_FILE_MISSING:{label_file}")
            result["LABEL_SHA256"] = sha256(label_file)
        return result


def _cli() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("score-showdown")
    s.add_argument("--board", required=True)
    s.add_argument("--contest", required=True)
    s.add_argument("--contest-size", type=int)
    s.add_argument("--out")
    p = sub.add_parser("score-postlock-ranks")
    p.add_argument("--postlock", required=True)
    p.add_argument("--contest-size", required=True, type=int)
    p.add_argument("--out")
    v = sub.add_parser("validate-spec")
    v.add_argument("--spec", required=True)
    w = sub.add_parser("walk-forward")
    w.add_argument("--slates", required=True, help="comma-separated ordered slate ids")
    w.add_argument("--min-train", required=True, type=int)
    args = ap.parse_args()
    if args.cmd == "score-showdown":
        obj = score_showdown_board(Path(args.board), Path(args.contest), args.contest_size)
    elif args.cmd == "score-postlock-ranks":
        obj = score_postlock_rank_file(Path(args.postlock), args.contest_size)
    elif args.cmd == "validate-spec":
        spec = json.loads(Path(args.spec).read_text())
        validate_replay_spec(spec)
        obj = {"STATUS": "PASS", "EVIDENCE_CLASS": classify_evidence(spec)}
    else:
        obj = {"SPLITS": rolling_origin_splits([x for x in args.slates.split(",") if x], args.min_train)}
    text = json.dumps(obj, indent=2, sort_keys=True) + "\n"
    if getattr(args, "out", None):
        Path(args.out).write_text(text)
    print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
