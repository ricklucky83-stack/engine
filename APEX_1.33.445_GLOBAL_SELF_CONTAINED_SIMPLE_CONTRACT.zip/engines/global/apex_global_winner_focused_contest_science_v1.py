#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import re
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable, Sequence

import pandas as pd

EVALUATOR_ID = "APEX_GLOBAL_WINNER_FOCUSED_CONTEST_SCIENCE_v1"
COHORTS = (("WINNER", None), ("TOP_0_1_PERCENT", 0.001), ("TOP_1_PERCENT", 0.01), ("TOP_5_PERCENT", 0.05), ("WHOLE_FIELD", 1.0))
SLOT_TOKEN_RE = re.compile(
    r"(?<!\S)(CPT|UTIL|FLEX|DST|DEF|QB|RB|WR|TE|PG|SG|SF|PF|1B|2B|3B|SS|OF|P|C|G|F|K|D)(?=\s)",
    flags=re.I,
)
SLOT_COLUMN_RE = re.compile(
    r"^(CPT|UTIL\d*|FLEX\d*|P\d*|C|1B|2B|3B|SS|OF\d*|PG|SG|SF|PF|G\d*|F\d*|QB|RB\d*|WR\d*|TE|DST|DEF|K|D)$",
    flags=re.I,
)
META_SUFFIX_RE = re.compile(r"_(TEAM|SALARY|ID|FPTS|OWN|OWNERSHIP)$", flags=re.I)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def normalize_name(value: object) -> str:
    text = re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()
    return re.sub(r"\s+", " ", text)


MLB_GENERATIONAL_SUFFIXES = frozenset({"jr", "sr", "ii", "iii", "iv"})
MLB_POSTLOCK_IDENTITY_ALIASES = {"kike hernandez": "enrique hernandez", "kik hernandez": "enrique hernandez"}

def identity_name(value: object) -> str:
    """Postlock cross-provider identity only; visible names are preserved elsewhere."""
    text = normalize_name(value)
    tokens = text.split()
    while tokens and tokens[-1] in MLB_GENERATIONAL_SUFFIXES:
        tokens.pop()
    ident = " ".join(tokens)
    return MLB_POSTLOCK_IDENTITY_ALIASES.get(ident, ident)

def identity_roster(roster: Sequence[tuple[str, str]], sport: str, source: str) -> list[tuple[str, str]]:
    if str(sport).upper() != "MLB":
        return list(roster)
    out=[]; aliases: dict[str, set[str]] = defaultdict(set)
    for slot, name in roster:
        raw=normalize_name(name); ident=identity_name(name)
        if not ident:
            continue
        aliases[ident].add(raw); out.append((slot, ident))
    collisions={k: sorted(v) for k,v in aliases.items() if len(v)>1}
    if collisions:
        detail=json.dumps(collisions,sort_keys=True,separators=(",",":"))
        raise RuntimeError(f"POSTLOCK_IDENTITY_CANONICALIZATION_COLLISION:{source}:{detail}")
    return out

def canonicalize_pool_identity(pool: dict[str, dict], sport: str) -> dict[str, dict]:
    if str(sport).upper() != "MLB":
        return pool
    out: dict[str, dict] = {}; aliases: dict[str, set[str]] = defaultdict(set)
    for raw, info in pool.items():
        ident=identity_name(raw)
        if not ident:
            continue
        aliases[ident].add(normalize_name(raw))
        if ident not in out:
            out[ident]=info
    collisions={k: sorted(v) for k,v in aliases.items() if len(v)>1}
    if collisions:
        detail=json.dumps(collisions,sort_keys=True,separators=(",",":"))
        raise RuntimeError(f"POSTLOCK_IDENTITY_CANONICALIZATION_COLLISION:POOL:{detail}")
    return out


def normalize_slot(value: object) -> str:
    slot = str(value).upper().strip()
    return re.sub(r"\d+$", "", slot)


def read_table(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as z:
            members = sorted(n for n in z.namelist() if n.lower().endswith(".csv"))
            if not members:
                raise ValueError("NO_CSV_MEMBER")
            with z.open(members[0]) as f:
                return pd.read_csv(f)
    return pd.read_csv(path)


def parse_lineup(value: object) -> list[tuple[str, str]]:
    text = re.sub(r"\s+", " ", str(value)).strip()
    if not text or text.lower() == "nan":
        return []
    markers = list(SLOT_TOKEN_RE.finditer(text))
    if not markers or markers[0].start() != 0:
        return []
    parsed: list[tuple[str, str]] = []
    for i, marker in enumerate(markers):
        start = marker.end() + 1
        end = markers[i + 1].start() if i + 1 < len(markers) else len(text)
        name = normalize_name(text[start:end])
        if not name:
            return []
        parsed.append((normalize_slot(marker.group(1)), name))
    names = [name for _, name in parsed]
    return parsed if len(names) == len(set(names)) else []


def cell_name(value: object) -> str:
    if pd.isna(value):
        return ""
    raw = str(value).strip()
    if not raw:
        return ""
    parts = [x.strip() for x in raw.split("|")]
    if len(parts) >= 3 and (parts[-1].isdigit() or len(parts[0]) <= 4):
        raw = parts[1]
    return normalize_name(raw)


def infer_slot_columns(frame: pd.DataFrame) -> list[str]:
    if 'CPT' in frame.columns and 'UTILS' in frame.columns:
        return ['CPT','UTILS']
    cols: list[str] = []
    for col in frame.columns:
        name = str(col)
        if META_SUFFIX_RE.search(name):
            continue
        if SLOT_COLUMN_RE.fullmatch(name):
            cols.append(name)
    if cols:
        return cols
    for candidate in ("PLAYERS", "LINEUP", "UTILS"):
        if candidate in frame.columns:
            return [candidate]
    raise ValueError("NO_ROSTER_COLUMNS_IDENTIFIED")


def row_roster(row: pd.Series, slot_columns: Sequence[str]) -> list[tuple[str, str]]:
    if len(slot_columns) == 2 and list(slot_columns) == ['CPT','UTILS']:
        cpt=cell_name(row['CPT'])
        chunks=[normalize_name(x) for x in str(row['UTILS']).split('|') if str(x).strip()]
        roster=([('CPT',cpt)] if cpt else []) + [('UTIL',x) for x in chunks if x]
        names=[name for _,name in roster]
        return roster if len(names)==6 and len(names)==len(set(names)) else []
    if len(slot_columns) == 1 and slot_columns[0] in {"PLAYERS", "LINEUP", "UTILS"}:
        value = row[slot_columns[0]]
        parsed = parse_lineup(value)
        if parsed:
            return parsed
        raw = str(value)
        if slot_columns[0] == "UTILS":
            chunks = [x.strip() for x in raw.split("|") if x.strip()]
            return [("UTIL", normalize_name(x)) for x in chunks]
        return []
    out: list[tuple[str, str]] = []
    for col in slot_columns:
        name = cell_name(row[col])
        if name:
            out.append((normalize_slot(col), name))
    return out


def player_set_key(roster: Sequence[tuple[str, str]]) -> str:
    return "|".join(sorted(name for _, name in roster))


def role_key(roster: Sequence[tuple[str, str]]) -> str:
    return "|".join(sorted(f"{slot}:{name}" for slot, name in roster))


def uses_role_identity(mode: str, rosters: Iterable[Sequence[tuple[str, str]]]) -> bool:
    norm = mode.upper().replace("-", "_").replace(" ", "_")
    if any(x in norm for x in ("SHOWDOWN", "CAPTAIN", "CPT", "SD")):
        return True
    return any(any(slot == "CPT" for slot, _ in roster) for roster in rosters)


def load_pool(path: Path | None) -> tuple[dict[str, dict], list[str]]:
    if path is None:
        return {}, []
    frame = pd.read_csv(path)
    name_col = next((c for c in ("PLAYER", "Name", "NAME", "Player") if c in frame.columns), None)
    if not name_col:
        raise ValueError("POOL_PLAYER_COLUMN_MISSING")
    team_col = next((c for c in ("TEAM", "Team", "TEAM_ABBREVIATION") if c in frame.columns), None)
    pos_col = next((c for c in ("POS", "Position", "POSITION") if c in frame.columns), None)
    sal_col = next((c for c in ("SAL", "Salary", "SALARY") if c in frame.columns), None)
    own_col = next((c for c in ("RST%", "OWN%", "OWNERSHIP", "Projected Ownership") if c in frame.columns), None)
    grouped: dict[str, list[dict]] = defaultdict(list)
    for _, row in frame.iterrows():
        key = normalize_name(row[name_col])
        if not key:
            continue
        grouped[key].append({
            "display": str(row[name_col]),
            "team": None if team_col is None or pd.isna(row[team_col]) else str(row[team_col]).upper().strip(),
            "position": None if pos_col is None or pd.isna(row[pos_col]) else str(row[pos_col]),
            "salary": None if sal_col is None or pd.isna(row[sal_col]) else float(row[sal_col]),
            "projected_ownership": None if own_col is None or pd.isna(row[own_col]) else float(row[own_col]),
        })
    ambiguous = sorted(k for k, vals in grouped.items() if len({(x["team"], x["position"], x["salary"]) for x in vals}) > 1)
    mapping = {k: vals[0] for k, vals in grouped.items()}
    return mapping, ambiguous


def team_structure(roster: Sequence[tuple[str, str]], pool: dict[str, dict], sport: str, mode: str) -> tuple[str, str]:
    teams: list[str] = []
    for slot, name in roster:
        if sport.upper() == "MLB" and mode.upper() == "CLASSIC" and slot == "P":
            continue
        team = pool.get(name, {}).get("team")
        if team:
            teams.append(team)
    counts = Counter(teams)
    ordered = sorted(counts.items(), key=lambda x: (-x[1], x[0]))
    pattern = "-".join(str(count) for _, count in ordered)
    signature = "-".join(f"{team}{count}" for team, count in ordered)
    return pattern, signature


def contest_entries(contest: Path, pool: dict[str, dict], sport: str, mode: str) -> pd.DataFrame:
    frame = read_table(contest)
    required = {"Rank", "Lineup"}
    if not required.issubset(frame.columns):
        raise ValueError("CONTEST_MISSING_RANK_OR_LINEUP")
    rows = []
    for idx, row in frame.iterrows():
        roster = parse_lineup(row["Lineup"])
        if not roster:
            continue
        rank_match = re.search(r"(\d+)", str(row["Rank"]))
        if not rank_match:
            continue
        rank = int(rank_match.group(1))
        points = None
        if "Points" in frame.columns and not pd.isna(row.get("Points")):
            try:
                points = float(row["Points"])
            except Exception:
                points = None
        ident_roster = identity_roster(roster, sport, f"CONTEST_ROW_{idx}")
        pattern, signature = team_structure(ident_roster, pool, sport, mode)
        rows.append({
            "ROW_INDEX": int(idx),
            "RANK": rank,
            "POINTS": points,
            "ENTRY_ID": None if "EntryId" not in frame.columns else str(row.get("EntryId")),
            "ENTRY_NAME": None if "EntryName" not in frame.columns else str(row.get("EntryName")),
            "ROSTER": roster,
            "PLAYER_SET": frozenset(name for _, name in ident_roster),
            "PLAYER_SET_KEY": player_set_key(ident_roster),
            "ROLE_KEY": role_key(ident_roster),
            "PATTERN": pattern,
            "STACK_SIGNATURE": signature,
        })
    if not rows:
        raise RuntimeError("NO_VALID_CONTEST_LINEUPS")
    return pd.DataFrame(rows).sort_values(["RANK", "ROW_INDEX"]).reset_index(drop=True)


def artifact_lineups(path: Path | None, artifact_type: str, sport: str = "") -> pd.DataFrame:
    if path is None:
        return pd.DataFrame()
    frame = pd.read_csv(path)
    slot_columns = infer_slot_columns(frame)
    rows = []
    for idx, row in frame.iterrows():
        roster = row_roster(row, slot_columns)
        if not roster:
            continue
        ident_roster = identity_roster(roster, sport, f"{artifact_type}_ROW_{idx}")
        rows.append({
            "ROW_INDEX": int(idx),
            "LINEUP_ID": str(row.get("LINEUP_ID", row.get("LINEUP_INDEX", idx))),
            "ROSTER": roster,
            "PLAYER_SET": frozenset(name for _, name in ident_roster),
            "PLAYER_SET_KEY": player_set_key(ident_roster),
            "ROLE_KEY": role_key(ident_roster),
            "PATTERN": str(row.get("PATTERN", row.get("STRUCTURE_FAMILY", ""))),
            "STACK_SIGNATURE": str(row.get("STACK_SIGNATURE", "")),
            "ARTIFACT_TYPE": artifact_type,
            **{str(c): row[c] for c in frame.columns if str(c) not in slot_columns},
        })
    return pd.DataFrame(rows)


def cohort_frame(entries: pd.DataFrame, label: str, fraction: float | None) -> pd.DataFrame:
    if label == "WINNER":
        return entries.loc[entries["RANK"].eq(entries["RANK"].min())].copy()
    count = max(1, math.ceil(len(entries) * float(fraction)))
    return entries.head(count).copy()


def identity_column(role_sensitive: bool) -> str:
    return "ROLE_KEY" if role_sensitive else "PLAYER_SET_KEY"


def component_support(winner_set: frozenset[str], groups: dict[str, pd.DataFrame], phase2: pd.DataFrame) -> pd.DataFrame:
    phase_index: dict[str, set[int]] = defaultdict(set)
    for i, players in enumerate(phase2.get("PLAYER_SET", pd.Series(dtype=object))):
        for player in players:
            phase_index[player].add(i)
    rows = []
    for size in (1, 2, 3):
        for combo in itertools.combinations(sorted(winner_set), size):
            combo_set = set(combo)
            result = {"COMPONENT_SIZE": size, "COMPONENT": " + ".join(combo)}
            for label, group in groups.items():
                support = int(sum(combo_set.issubset(players) for players in group["PLAYER_SET"]))
                result[f"{label}_COUNT"] = support
                result[f"{label}_RATE"] = support / len(group) if len(group) else 0.0
            if phase2.empty:
                phase_support = 0
            else:
                sets = [phase_index[p] for p in combo]
                phase_support = len(set.intersection(*sets)) if sets and all(sets) else 0
            result["PHASE2_COUNT"] = phase_support
            result["PHASE2_RATE"] = phase_support / len(phase2) if len(phase2) else 0.0
            rows.append(result)
    return pd.DataFrame(rows)


def nearest_rows(target_sets: Sequence[frozenset[str]], artifact: pd.DataFrame, top_n: int = 50) -> pd.DataFrame:
    if artifact.empty:
        return pd.DataFrame()
    records = []
    for _, row in artifact.iterrows():
        players = row["PLAYER_SET"]
        overlaps = [len(players & target) for target in target_sets]
        best = max(overlaps) if overlaps else 0
        target = target_sets[overlaps.index(best)] if overlaps else frozenset()
        rec = {
            "LINEUP_ID": row["LINEUP_ID"],
            "OVERLAP": best,
            "ROSTER_SIZE": len(players),
            "SWAPS_TO_WINNER": max(len(players), len(target)) - best,
            "MISSING_FROM_LINEUP": "|".join(sorted(target - players)),
            "EXTRA_IN_LINEUP": "|".join(sorted(players - target)),
            "PATTERN": row.get("PATTERN", ""),
            "STACK_SIGNATURE": row.get("STACK_SIGNATURE", ""),
        }
        for metric in ("MC_WIN_RATE", "MC_TOP_0_1_RATE", "MC_TOP_1_RATE", "P95", "P99", "SALARY", "BOARD_RANK", "BIRTH_SOURCE", "CLOSURE_TRANSITION"):
            if metric in row.index:
                rec[metric] = row[metric]
        records.append(rec)
    return pd.DataFrame(records).sort_values(["OVERLAP", "LINEUP_ID"], ascending=[False, True]).head(top_n).reset_index(drop=True)


def pattern_comparison(entries: pd.DataFrame, phase2: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for label, fraction in COHORTS:
        group = cohort_frame(entries, label, fraction)
        counts = group["PATTERN"].replace("", "UNKNOWN").value_counts()
        for pattern, count in counts.items():
            rows.append({"SOURCE": label, "PATTERN": pattern, "COUNT": int(count), "TOTAL": len(group), "SHARE": float(count / len(group))})
    if not phase2.empty:
        counts = phase2["PATTERN"].fillna("").replace("", "UNKNOWN").value_counts()
        for pattern, count in counts.items():
            rows.append({"SOURCE": "PHASE2", "PATTERN": pattern, "COUNT": int(count), "TOTAL": len(phase2), "SHARE": float(count / len(phase2))})
    return pd.DataFrame(rows)


def player_frequencies(entries: pd.DataFrame, phase2: pd.DataFrame, pool: dict[str, dict]) -> pd.DataFrame:
    all_players = set().union(*entries["PLAYER_SET"].tolist())
    if not phase2.empty:
        all_players |= set().union(*phase2["PLAYER_SET"].tolist())
    rows = []
    groups = {label: cohort_frame(entries, label, fraction) for label, fraction in COHORTS}
    for player in sorted(all_players):
        info = pool.get(player, {})
        row = {
            "PLAYER": info.get("display", player),
            "NORMALIZED_PLAYER": player,
            "TEAM": info.get("team"),
            "POSITION": info.get("position"),
            "SALARY": info.get("salary"),
            "PROJECTED_OWNERSHIP": info.get("projected_ownership"),
        }
        for label, group in groups.items():
            count = int(sum(player in s for s in group["PLAYER_SET"]))
            row[f"{label}_COUNT"] = count
            row[f"{label}_RATE"] = count / len(group) if len(group) else 0.0
        phase_count = int(sum(player in s for s in phase2.get("PLAYER_SET", pd.Series(dtype=object)))) if not phase2.empty else 0
        row["PHASE2_COUNT"] = phase_count
        row["PHASE2_RATE"] = phase_count / len(phase2) if len(phase2) else 0.0
        rows.append(row)
    return pd.DataFrame(rows)




def pass_flag(value: object) -> bool:
    if value is True:
        return True
    if isinstance(value, str):
        return value.strip().upper() in {"PASS", "TRUE", "YES", "1", "PASS_TRUE", "PASS_EQUAL"}
    return False

def failure_class(winner_born: bool, selector_reached: bool, board_selected: bool) -> str:
    if not winner_born:
        return "GENERATOR_FAMILY_ALLOCATION_OR_RECALL_FAILURE"
    if not selector_reached:
        return "HANDOFF_RECALL_FAILURE"
    if not board_selected:
        return "SELECTOR_FAILURE"
    return "MODEL_OR_VARIANCE_FAILURE"


def evaluate(
    contest: Path,
    output_dir: Path,
    sport: str,
    mode: str,
    phase2_manifest: Path | None = None,
    board: Path | None = None,
    receipt: Path | None = None,
    player_pool: Path | None = None,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    pool, ambiguous = load_pool(player_pool)
    pool = canonicalize_pool_identity(pool, sport)
    entries = contest_entries(contest, pool, sport, mode)
    phase2 = artifact_lineups(phase2_manifest, "PHASE2", sport)
    board_df = artifact_lineups(board, "BOARD", sport)
    role_sensitive = uses_role_identity(mode, entries["ROSTER"].tolist())
    id_col = identity_column(role_sensitive)
    winner = cohort_frame(entries, "WINNER", None)
    winner_keys = set(winner[id_col])
    phase2_keys = set(phase2.get(id_col, pd.Series(dtype=str)))
    board_keys = set(board_df.get(id_col, pd.Series(dtype=str)))
    winner_born = bool(winner_keys & phase2_keys)
    board_selected = bool(winner_keys & board_keys)
    receipt_data = json.loads(receipt.read_text()) if receipt and receipt.exists() else {}
    nested_phase2 = receipt_data.get('PHASE2') if isinstance(receipt_data.get('PHASE2'), dict) else {}
    nested_handoff = receipt_data.get('HANDOFF') if isinstance(receipt_data.get('HANDOFF'), dict) else {}
    nested_selector = receipt_data.get('SELECTOR') if isinstance(receipt_data.get('SELECTOR'), dict) else {}
    nested_stress = receipt_data.get('STRESS') if isinstance(receipt_data.get('STRESS'), dict) else {}
    parity = bool(
        pass_flag(receipt_data.get("PHASE2_HANDOFF_SELECTOR_PARITY"))
        or pass_flag(nested_stress.get("PHASE2_HANDOFF_SELECTOR_PARITY"))
        or (
            receipt_data.get("PHASE2_BUILT_LINEUPS") is not None
            and receipt_data.get("HANDOFF_SURVIVORS") == receipt_data.get("PHASE2_BUILT_LINEUPS")
            and receipt_data.get("SELECTOR_REVIEWED_LINEUPS") == receipt_data.get("PHASE2_BUILT_LINEUPS")
        )
        or (
            nested_phase2.get('PHASE2_BUILT_LINEUPS') is not None
            and nested_handoff.get('SURVIVORS') == nested_phase2.get('PHASE2_BUILT_LINEUPS')
            and nested_selector.get('REVIEWED_LINEUPS') == nested_phase2.get('PHASE2_BUILT_LINEUPS')
        )
    )
    selector_reached = bool(winner_born and parity)

    cohort_rows = []
    for label, fraction in COHORTS:
        group = cohort_frame(entries, label, fraction)
        keys = set(group[id_col])
        phase_hits = group[id_col].isin(phase2_keys)
        board_hits = group[id_col].isin(board_keys)
        cohort_rows.append({
            "COHORT": label,
            "LINEUPS": len(group),
            "EXACT_PHASE2_BIRTHS": int(phase_hits.sum()),
            "EXACT_PHASE2_RECALL": float(phase_hits.mean()),
            "EXACT_BOARD_CAPTURES": int(board_hits.sum()),
            "EXACT_BOARD_CAPTURE_RATE": float(board_hits.mean()),
            "MIN_RANK": int(group["RANK"].min()),
            "MAX_RANK": int(group["RANK"].max()),
        })
    cohort_df = pd.DataFrame(cohort_rows)

    groups = {label: cohort_frame(entries, label, fraction) for label, fraction in COHORTS}
    winner_sets = winner["PLAYER_SET"].tolist()
    nearest_phase2 = nearest_rows(winner_sets, phase2, 100)
    nearest_board = nearest_rows(winner_sets, board_df, max(10, len(board_df)))
    components = component_support(winner_sets[0], groups, phase2)
    patterns = pattern_comparison(entries, phase2)
    players = player_frequencies(entries, phase2, pool)

    cohort_df.to_csv(output_dir / "cohort_recall.csv", index=False)
    nearest_phase2.to_csv(output_dir / "winner_nearest_phase2.csv", index=False)
    nearest_board.to_csv(output_dir / "winner_vs_board.csv", index=False)
    components.to_csv(output_dir / "winner_component_support.csv", index=False)
    patterns.to_csv(output_dir / "pattern_comparison.csv", index=False)
    players.to_csv(output_dir / "player_frequency_science.csv", index=False)

    winner_records = []
    for _, row in winner.iterrows():
        winner_records.append({
            "rank": int(row["RANK"]),
            "points": row["POINTS"],
            "entry_id": row["ENTRY_ID"],
            "entry_name": row["ENTRY_NAME"],
            "player_set_key": row["PLAYER_SET_KEY"],
            "role_key": row["ROLE_KEY"],
            "pattern": row["PATTERN"],
            "stack_signature": row["STACK_SIGNATURE"],
            "roster": [{"slot": slot, "player": pool.get(identity_name(name) if sport.upper()=="MLB" else name, {}).get("display", name), "normalized_player": name, **pool.get(identity_name(name) if sport.upper()=="MLB" else name, {})} for slot, name in row["ROSTER"]],
        })

    result = {
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "EVALUATOR_ID": EVALUATOR_ID,
        "POSTLOCK_ONLY": True,
        "ACTUAL_RESULTS_USED_BY_SELECTOR": False,
        "PRODUCTION_MUTATED": False,
        "WINNER_ONLY_OPTIMIZATION": False,
        "WHOLE_CONTEST_INGESTION": True,
        "WINNER_FOCUSED_REVIEW": True,
        "COHORT_REVIEW": [x[0] for x in COHORTS],
        "SPORT": sport.upper(),
        "MODE": mode.upper(),
        "ROLE_SENSITIVE_IDENTITY": role_sensitive,
        "CONTEST_SHA256": sha256(contest),
        "PHASE2_MANIFEST_SHA256": sha256(phase2_manifest) if phase2_manifest else None,
        "BOARD_SHA256": sha256(board) if board else None,
        "RECEIPT_SHA256": sha256(receipt) if receipt else None,
        "PLAYER_POOL_SHA256": sha256(player_pool) if player_pool else None,
        "VALID_CONTEST_LINEUPS": len(entries),
        "WINNER_TIES": len(winner),
        "WINNERS": winner_records,
        "WINNER_EXACT_PHASE2_BIRTH": winner_born,
        "WINNER_REACHED_HANDOFF_AND_SELECTOR": selector_reached,
        "WINNER_SELECTED_TO_BOARD": board_selected,
        "WINNER_NEAREST_PHASE2_OVERLAP": None if nearest_phase2.empty else int(nearest_phase2.iloc[0]["OVERLAP"]),
        "WINNER_NEAREST_PHASE2_SWAPS": None if nearest_phase2.empty else int(nearest_phase2.iloc[0]["SWAPS_TO_WINNER"]),
        "WINNER_NEAREST_BOARD_OVERLAP": None if nearest_board.empty else int(nearest_board.iloc[0]["OVERLAP"]),
        "WINNER_NEAREST_BOARD_SWAPS": None if nearest_board.empty else int(nearest_board.iloc[0]["SWAPS_TO_WINNER"]),
        "FAILURE_CLASS": failure_class(winner_born, selector_reached, board_selected),
        "PHASE2_LINEUPS_REVIEWED": len(phase2),
        "BOARD_LINEUPS_REVIEWED": len(board_df),
        "POOL_IDENTITY_AMBIGUITIES": ambiguous,
        "COHORT_RECEIPTS": cohort_rows,
        "PROMOTION_GOVERNANCE": {
            "SAME_SLATE_WINNER_INSERTION_PROHIBITED": True,
            "SINGLE_WINNER_PATCH_PROMOTION_PROHIBITED": True,
            "COHORT_SUPPORT_REQUIRED": True,
            "MINIMUM_BYTE_COMPLETE_BLIND_CONTROLS": 2,
            "DETERMINISTIC_REPLAY_REQUIRED": True,
            "PRODUCTION_SELECTOR_ISOLATION_REQUIRED": True,
        },
        "OUTPUTS": {
            "COHORT_RECALL": "cohort_recall.csv",
            "WINNER_NEAREST_PHASE2": "winner_nearest_phase2.csv",
            "WINNER_VS_BOARD": "winner_vs_board.csv",
            "WINNER_COMPONENT_SUPPORT": "winner_component_support.csv",
            "PATTERN_COMPARISON": "pattern_comparison.csv",
            "PLAYER_FREQUENCY_SCIENCE": "player_frequency_science.csv",
        },
    }
    (output_dir / "winner_focused_science_receipt.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contest", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--sport", required=True)
    parser.add_argument("--mode", required=True)
    parser.add_argument("--phase2-manifest")
    parser.add_argument("--board")
    parser.add_argument("--receipt")
    parser.add_argument("--player-pool")
    args = parser.parse_args()
    result = evaluate(
        contest=Path(args.contest),
        output_dir=Path(args.output_dir),
        sport=args.sport,
        mode=args.mode,
        phase2_manifest=Path(args.phase2_manifest) if args.phase2_manifest else None,
        board=Path(args.board) if args.board else None,
        receipt=Path(args.receipt) if args.receipt else None,
        player_pool=Path(args.player_pool) if args.player_pool else None,
    )
    print(json.dumps({k: result[k] for k in (
        "EXECUTION_STATE", "VALID_CONTEST_LINEUPS", "WINNER_EXACT_PHASE2_BIRTH",
        "WINNER_REACHED_HANDOFF_AND_SELECTOR", "WINNER_SELECTED_TO_BOARD",
        "WINNER_NEAREST_PHASE2_OVERLAP", "FAILURE_CLASS",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
