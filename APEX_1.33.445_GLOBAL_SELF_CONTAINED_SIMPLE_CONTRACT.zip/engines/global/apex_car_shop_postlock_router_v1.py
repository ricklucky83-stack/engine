#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from importlib import import_module
winner_science_module = import_module("engines.global.apex_global_winner_focused_contest_science_v1")
winner_science_evaluate = winner_science_module.evaluate
mlb_classic_compatibility = import_module("engines.mlb.mlb_classic_postlock_contest_matcher_v1").pool_contest_compatibility

ROOT = Path(__file__).resolve().parents[2]
ROUTER_ID = "APEX_GLOBAL_CAR_SHOP_POSTLOCK_AUTOLOAD_v1"
DOCTRINE_PATH = ROOT / "doctrine" / "CAR_SHOP_REPAIR_v1.json"
POSTLOCK_DOCTRINE_PATH = ROOT / "doctrine" / "APEX_GLOBAL_POSTLOCK_LOSS_CAUSAL_RESEARCH_AND_REPAIR_v1.json"
REGISTRY_PATH = ROOT / "engine_registry.json"
STATE_CONTRACT_PATH = ROOT / "state_contract.json"
CHANGE_LEDGER_PATH = ROOT / "change_ledger.json"


def _json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _platform_norm(value: str) -> str:
    token = value.upper().replace(" ", "").replace("_", "")
    return "DRAFTKINGS" if token in {"DK", "DRAFTKINGS"} else value.upper()


def _resolve_engine(registry: dict[str, Any], platform: str, sport: str, mode: str) -> dict[str, Any]:
    p, s, m = _platform_norm(platform), sport.upper(), mode.upper()
    matches = []
    for engine in registry.get("ENGINES", []):
        modes = {str(x).upper() for x in engine.get("MODES", [])}
        if str(engine.get("PLATFORM", "")).upper() == p and str(engine.get("SPORT", "")).upper() == s and m in modes:
            matches.append(engine)
    if len(matches) != 1:
        raise RuntimeError(f"CAR_SHOP_ENGINE_RESOLUTION_FAILED:{p}:{s}:{m}:MATCHES={len(matches)}")
    return matches[0]


def _rule_snapshot(engine: dict[str, Any]) -> dict[str, Any]:
    keep = (
        "STANDARD_ROSTER_SIZE", "SMALL_SLATE_ROSTER_SIZE", "SALARY_CAP", "HARD_SALARY_FLOOR",
        "MAX_SAME_TEAM", "MIN_GAMES", "MANDATORY_PREBUILD_ROSTER_CHECK", "PREBUILD_AVAILABILITY_GATE_REQUIRED",
        "FINAL_SELECTOR_AVAILABILITY_RECHECK_REQUIRED", "PHASE2_BIRTH_METHOD", "PHASE2_PHASE3_HANDOFF_SELECTOR_PARITY_REQUIRED",
        "POST_PHASE2_MUTATION_ALLOWED", "SELECTOR_REVIEW_POLICY", "SELECTOR_TARGET", "SELECTOR_MEAN_WEIGHT",
        "FILLERS_ALLOWED", "POSTLOCK_RESULTS_USED_IN_FORWARD_ENGINE", "RUNTIME_TELEMETRY_PROHIBITED",
    )
    return {k: engine[k] for k in keep if k in engine}


def _history(ledger: dict[str, Any], sport: str, limit: int = 32) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    raw = ledger.get("CHANGES") or ledger.get("ENTRIES") or ledger.get("CHANGE_LEDGER") or []
    if not isinstance(raw, list):
        raw = []
    sport_u = sport.upper()
    relevant = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        blob = json.dumps(item, sort_keys=True).upper()
        if "GLOBAL" in blob or sport_u in blob or "CAR_SHOP" in blob:
            relevant.append(item)
    relevant = relevant[-limit:]
    rejected, validated = [], []
    for item in relevant:
        blob = json.dumps(item, sort_keys=True).upper()
        if any(x in blob for x in ("REJECT", "REGRESS", "BLOCKED", "FAILED_HOLDOUT", "PROMOTION_BLOCK")):
            rejected.append(item)
        else:
            validated.append(item)
    return validated[-16:], rejected[-16:]


def _postlock_compatibility_gate(contest: Path, player_pool: Path | None, sport: str, mode: str) -> dict[str, Any]:
    """Fail closed before causal classification when a registered slate-compatibility adapter rejects the contest."""
    sport_u, mode_u = sport.upper(), mode.upper()
    if sport_u == "MLB" and mode_u == "CLASSIC":
        if player_pool is None or not player_pool.exists():
            return {
                "GATE_ID": "APEX_GLOBAL_CAR_SHOP_ACTIVE_POOL_COMPATIBILITY_PRECLASSIFICATION_GATE_v1",
                "ADAPTER": "MLB_CLASSIC_POSTLOCK_CONTEST_MATCHER_v1",
                "STATUS": "UNRESOLVED_ACTIVE_POOL_REQUIRED",
                "POOL_CONTEST_COMPATIBILITY_PASS": False,
                "CAUSAL_CLASSIFICATION_ALLOWED": False,
                "MATCH_REJECT_REASONS": ["ACTIVE_PLAYER_POOL_REQUIRED_FOR_MLB_CLASSIC_POSTLOCK_COMPATIBILITY"],
            }
        compat = mlb_classic_compatibility(player_pool, contest)
        passed = bool(compat.get("POOL_CONTEST_COMPATIBILITY_PASS"))
        return {
            "GATE_ID": "APEX_GLOBAL_CAR_SHOP_ACTIVE_POOL_COMPATIBILITY_PRECLASSIFICATION_GATE_v1",
            "ADAPTER": "MLB_CLASSIC_POSTLOCK_CONTEST_MATCHER_v1",
            **compat,
            "STATUS": "PASS" if passed else "REJECTED_POOL_CONTEST_MISMATCH",
            "CAUSAL_CLASSIFICATION_ALLOWED": passed,
        }
    return {
        "GATE_ID": "APEX_GLOBAL_CAR_SHOP_ACTIVE_POOL_COMPATIBILITY_PRECLASSIFICATION_GATE_v1",
        "ADAPTER": "NOT_APPLICABLE",
        "STATUS": "NOT_APPLICABLE",
        "POOL_CONTEST_COMPATIBILITY_PASS": True,
        "CAUSAL_CLASSIFICATION_ALLOWED": True,
        "MATCH_REJECT_REASONS": [],
    }



def _mlb_classic_active_pool_compatible_view(contest: Path, player_pool: Path, output_dir: Path) -> tuple[Path | None, dict[str, Any]]:
    """Build a postlock-only causal contest view from lineups the source active pool could legally produce."""
    pool, ambiguous = winner_science_module.load_pool(player_pool)
    pool = winner_science_module.canonicalize_pool_identity(pool, "MLB")
    pool_names = set(pool)
    frame = winner_science_module.read_table(contest)
    if not {"Rank", "Lineup"}.issubset(frame.columns):
        return None, {
            "CAUSAL_TARGET_STATUS": "UNRESOLVED_CONTEST_SCHEMA",
            "CAUSAL_CLASSIFICATION_ALLOWED": False,
            "MATCH_REJECT_REASONS": ["CONTEST_MISSING_RANK_OR_LINEUP"],
        }

    expected_slots = {"P": 2, "C": 1, "1B": 1, "2B": 1, "3B": 1, "SS": 1, "OF": 3}
    compatible_indices: list[int] = []
    compatible_rows: list[dict[str, Any]] = []
    rejection_counts: dict[str, int] = {}

    def reject(reason: str) -> None:
        rejection_counts[reason] = rejection_counts.get(reason, 0) + 1

    for idx, row in frame.iterrows():
        roster = winner_science_module.parse_lineup(row.get("Lineup"))
        if not roster:
            reject("UNPARSEABLE_LINEUP")
            continue
        ident_roster = winner_science_module.identity_roster(roster, "MLB", f"CAR_SHOP_CAUSAL_ROW_{idx}")
        names = [name for _, name in ident_roster]
        if len(ident_roster) != 10 or len(set(names)) != 10:
            reject("ROSTER_SIZE_OR_DUPLICATE")
            continue
        from collections import Counter
        if Counter(slot for slot, _ in ident_roster) != Counter(expected_slots):
            reject("SLOT_COUNTS")
            continue
        if not set(names).issubset(pool_names):
            reject("PLAYER_OUTSIDE_ACTIVE_POOL")
            continue
        salary = 0.0
        position_ok = True
        hitter_teams: list[str] = []
        for slot, name in ident_roster:
            info = pool.get(name, {})
            salary += float(info.get("salary") or 0.0)
            positions = {x.strip().upper() for x in str(info.get("position") or "").split("/") if x.strip()}
            if slot.upper() not in positions:
                position_ok = False
                break
            if slot.upper() != "P" and info.get("team"):
                hitter_teams.append(str(info["team"]).upper())
        if not position_ok:
            reject("POSITION_INELIGIBLE")
            continue
        if not 48_000 <= salary <= 50_000:
            reject("SOURCE_SALARY_BOUNDS")
            continue
        hitter_counts = Counter(hitter_teams)
        if hitter_counts and max(hitter_counts.values()) > 5:
            reject("MAX_FIVE_HITTERS_ONE_TEAM")
            continue
        rank_match = __import__("re").search(r"(\d+)", str(row.get("Rank")))
        if not rank_match:
            reject("RANK_UNRESOLVED")
            continue
        try:
            points = float(row.get("Points")) if row.get("Points") is not None else None
        except Exception:
            points = None
        compatible_indices.append(int(idx))
        compatible_rows.append({
            "ROW_INDEX": int(idx),
            "RANK": int(rank_match.group(1)),
            "POINTS": points,
            "ENTRY_ID": None if "EntryId" not in frame.columns else str(row.get("EntryId")),
            "ENTRY_NAME": None if "EntryName" not in frame.columns else str(row.get("EntryName")),
            "SALARY": int(round(salary)),
            "PLAYER_SET_KEY": winner_science_module.player_set_key(ident_roster),
            "ROSTER": ident_roster,
        })

    if not compatible_rows:
        return None, {
            "CAUSAL_TARGET_STATUS": "UNRESOLVED_NO_ACTIVE_POOL_COMPATIBLE_CONTEST_ENTRY",
            "CAUSAL_CLASSIFICATION_ALLOWED": False,
            "ACTIVE_POOL_COMPATIBLE_CONTEST_LINEUPS": 0,
            "REJECTION_COUNTS": rejection_counts,
            "AMBIGUOUS_POOL_IDENTITIES": ambiguous,
            "MATCH_REJECT_REASONS": ["NO_ACTIVE_POOL_COMPATIBLE_CONTEST_ENTRY"],
        }

    compatible_rows.sort(key=lambda x: (x["RANK"], x["ROW_INDEX"]))
    target = compatible_rows[0]
    causal_path = output_dir / "active_pool_compatible_contest.csv"
    frame.loc[compatible_indices].to_csv(causal_path, index=False)
    full_rank = __import__("pandas").to_numeric(frame["Rank"].astype(str).str.extract(r"(\d+)", expand=False), errors="coerce")
    reference_rank = int(full_rank.min()) if full_rank.notna().any() else None
    target_is_reference_winner = bool(reference_rank is not None and target["RANK"] == reference_rank)
    return causal_path, {
        "CAUSAL_TARGET_STATUS": "PASS_ACTIVE_POOL_COMPATIBLE_TARGET_RESOLVED",
        "CAUSAL_CLASSIFICATION_ALLOWED": True,
        "CAUSAL_TARGET_SOURCE": "REFERENCE_WINNER" if target_is_reference_winner else "BEST_ACTIVE_POOL_COMPATIBLE_CONTEST_ENTRY",
        "REFERENCE_WINNER_COMPATIBLE": target_is_reference_winner,
        "REFERENCE_WINNER_RANK": reference_rank,
        "ACTIVE_POOL_COMPATIBLE_CONTEST_LINEUPS": len(compatible_rows),
        "CAUSAL_TARGET_RANK": target["RANK"],
        "CAUSAL_TARGET_POINTS": target["POINTS"],
        "CAUSAL_TARGET_ENTRY_ID": target["ENTRY_ID"],
        "CAUSAL_TARGET_ENTRY_NAME": target["ENTRY_NAME"],
        "CAUSAL_TARGET_SALARY": target["SALARY"],
        "CAUSAL_TARGET_PLAYER_SET_KEY": target["PLAYER_SET_KEY"],
        "CAUSAL_TARGET_POOL_COVERAGE": 1.0,
        "DERIVED_CONTEST_VIEW": str(causal_path),
        "REJECTION_COUNTS": rejection_counts,
        "AMBIGUOUS_POOL_IDENTITIES": ambiguous,
        "MATCH_REJECT_REASONS": [],
    }



def _resolve_active_pool_snapshot(player_pool: Path | None, receipt: Path | None, active_pool: Path | None, sport: str) -> tuple[Path | None, dict[str, Any]]:
    """Resolve the exact post-prebuild active pool for CAR SHOP causal classification."""
    if active_pool is not None and active_pool.exists():
        return active_pool, {"ACTIVE_POOL_SOURCE": "EXPLICIT_ACTIVE_POOL", "ACTIVE_POOL_PATH": str(active_pool)}
    if receipt is not None and receipt.exists():
        try:
            rec = _json(receipt)
        except Exception:
            rec = {}
        snap = rec.get("ACTIVE_POOL_SNAPSHOT_FILE")
        if snap:
            cand = Path(str(snap))
            if not cand.is_absolute():
                cand = receipt.parent / cand
            if cand.exists():
                return cand, {"ACTIVE_POOL_SOURCE": "RECEIPT_SNAPSHOT", "ACTIVE_POOL_PATH": str(cand)}
        out_purge = int(rec.get("OUT_PURGE") or 0)
        if sport.upper() == "TENNIS" and out_purge > 0:
            return None, {
                "ACTIVE_POOL_SOURCE": "UNRESOLVED",
                "ACTIVE_POOL_PATH": None,
                "ACTIVE_POOL_RESOLUTION_ERROR": "TENNIS_POSTLOCK_ACTIVE_POOL_SNAPSHOT_REQUIRED_WHEN_OUT_PURGE_GT_0",
            }
    if player_pool is not None and player_pool.exists():
        return player_pool, {"ACTIVE_POOL_SOURCE": "RAW_PLAYER_POOL_NO_RECORDED_PURGE", "ACTIVE_POOL_PATH": str(player_pool)}
    return None, {"ACTIVE_POOL_SOURCE": "UNRESOLVED", "ACTIVE_POOL_PATH": None}


def _tennis_classic_active_pool_compatible_view(contest: Path, active_pool: Path, output_dir: Path) -> tuple[Path | None, dict[str, Any]]:
    """Resolve the best contest lineup that the exact prelock Tennis active pool could legally produce."""
    pool, ambiguous = winner_science_module.load_pool(active_pool)
    pool = winner_science_module.canonicalize_pool_identity(pool, "TENNIS")
    pool_names = set(pool)
    frame = winner_science_module.read_table(contest)
    if not {"Rank", "Lineup"}.issubset(frame.columns):
        return None, {
            "CAUSAL_TARGET_STATUS": "UNRESOLVED_CONTEST_SCHEMA",
            "CAUSAL_CLASSIFICATION_ALLOWED": False,
            "MATCH_REJECT_REASONS": ["CONTEST_MISSING_RANK_OR_LINEUP"],
        }
    compatible_indices: list[int] = []
    compatible_rows: list[dict[str, Any]] = []
    rejection_counts: dict[str, int] = {}
    def reject(reason: str) -> None:
        rejection_counts[reason] = rejection_counts.get(reason, 0) + 1
    for idx, row in frame.iterrows():
        roster = winner_science_module.parse_lineup(row.get("Lineup"))
        if not roster:
            reject("UNPARSEABLE_LINEUP")
            continue
        ident_roster = winner_science_module.identity_roster(roster, "TENNIS", f"CAR_SHOP_TENNIS_CAUSAL_ROW_{idx}")
        names = [name for _, name in ident_roster]
        if len(ident_roster) != 6 or len(set(names)) != 6:
            reject("ROSTER_SIZE_OR_DUPLICATE")
            continue
        if not set(names).issubset(pool_names):
            reject("PLAYER_OUTSIDE_ACTIVE_POOL")
            continue
        salary = sum(float(pool.get(name, {}).get("salary") or 0.0) for name in names)
        if salary > 50_000:
            reject("SALARY_CAP")
            continue
        rank_match = __import__("re").search(r"(\d+)", str(row.get("Rank")))
        if not rank_match:
            reject("RANK_UNRESOLVED")
            continue
        try:
            points = float(row.get("Points")) if row.get("Points") is not None else None
        except Exception:
            points = None
        compatible_indices.append(int(idx))
        compatible_rows.append({
            "ROW_INDEX": int(idx),
            "RANK": int(rank_match.group(1)),
            "POINTS": points,
            "ENTRY_ID": None if "EntryId" not in frame.columns else str(row.get("EntryId")),
            "ENTRY_NAME": None if "EntryName" not in frame.columns else str(row.get("EntryName")),
            "SALARY": int(round(salary)),
            "PLAYER_SET_KEY": winner_science_module.player_set_key(ident_roster),
        })
    if not compatible_rows:
        return None, {
            "CAUSAL_TARGET_STATUS": "UNRESOLVED_NO_ACTIVE_POOL_COMPATIBLE_CONTEST_ENTRY",
            "CAUSAL_CLASSIFICATION_ALLOWED": False,
            "ACTIVE_POOL_COMPATIBLE_CONTEST_LINEUPS": 0,
            "REJECTION_COUNTS": rejection_counts,
            "AMBIGUOUS_POOL_IDENTITIES": ambiguous,
            "MATCH_REJECT_REASONS": ["NO_ACTIVE_POOL_COMPATIBLE_CONTEST_ENTRY"],
        }
    compatible_rows.sort(key=lambda x: (x["RANK"], x["ROW_INDEX"]))
    target = compatible_rows[0]
    causal_path = output_dir / "active_pool_compatible_contest.csv"
    frame.loc[compatible_indices].to_csv(causal_path, index=False)
    full_rank = __import__("pandas").to_numeric(frame["Rank"].astype(str).str.extract(r"(\d+)", expand=False), errors="coerce")
    reference_rank = int(full_rank.min()) if full_rank.notna().any() else None
    target_is_reference_winner = bool(reference_rank is not None and target["RANK"] == reference_rank)
    return causal_path, {
        "CAUSAL_TARGET_STATUS": "PASS_ACTIVE_POOL_COMPATIBLE_TARGET_RESOLVED",
        "CAUSAL_CLASSIFICATION_ALLOWED": True,
        "CAUSAL_TARGET_SOURCE": "REFERENCE_WINNER" if target_is_reference_winner else "BEST_ACTIVE_POOL_COMPATIBLE_CONTEST_ENTRY",
        "REFERENCE_WINNER_COMPATIBLE": target_is_reference_winner,
        "REFERENCE_WINNER_RANK": reference_rank,
        "ACTIVE_POOL_COMPATIBLE_CONTEST_LINEUPS": len(compatible_rows),
        "CAUSAL_TARGET_RANK": target["RANK"],
        "CAUSAL_TARGET_POINTS": target["POINTS"],
        "CAUSAL_TARGET_ENTRY_ID": target["ENTRY_ID"],
        "CAUSAL_TARGET_ENTRY_NAME": target["ENTRY_NAME"],
        "CAUSAL_TARGET_SALARY": target["SALARY"],
        "CAUSAL_TARGET_PLAYER_SET_KEY": target["PLAYER_SET_KEY"],
        "CAUSAL_TARGET_POOL_COVERAGE": 1.0,
        "DERIVED_CONTEST_VIEW": str(causal_path),
        "REJECTION_COUNTS": rejection_counts,
        "AMBIGUOUS_POOL_IDENTITIES": ambiguous,
        "MATCH_REJECT_REASONS": [],
    }

def _resolve_postlock_causal_view(contest: Path, player_pool: Path | None, sport: str, mode: str, output_dir: Path, receipt: Path | None = None, active_pool: Path | None = None) -> tuple[Path, dict[str, Any]]:
    resolved_pool, pool_meta = _resolve_active_pool_snapshot(player_pool, receipt, active_pool, sport)
    sport_u, mode_u = sport.upper(), mode.upper()
    if sport_u == "TENNIS" and mode_u == "CLASSIC":
        if resolved_pool is None or not resolved_pool.exists():
            return contest, {
                "GATE_ID": "APEX_GLOBAL_CAR_SHOP_ACTIVE_POOL_COMPATIBILITY_PRECLASSIFICATION_GATE_v1",
                "ADAPTER": "TENNIS_CLASSIC_ACTIVE_POOL_COMPATIBILITY_v1",
                "STATUS": "UNRESOLVED_ACTIVE_POOL_REQUIRED",
                "POOL_CONTEST_COMPATIBILITY_PASS": False,
                "REFERENCE_CONTEST_COMPATIBILITY_PASS": False,
                "CAUSAL_CLASSIFICATION_ALLOWED": False,
                "MATCH_REJECT_REASONS": [pool_meta.get("ACTIVE_POOL_RESOLUTION_ERROR") or "ACTIVE_PLAYER_POOL_REQUIRED_FOR_TENNIS_CLASSIC_POSTLOCK_COMPATIBILITY"],
                **pool_meta,
            }
        causal_path, derived = _tennis_classic_active_pool_compatible_view(contest, resolved_pool, output_dir)
        merged = {
            "GATE_ID": "APEX_GLOBAL_CAR_SHOP_ACTIVE_POOL_COMPATIBILITY_PRECLASSIFICATION_GATE_v1",
            "ADAPTER": "TENNIS_CLASSIC_ACTIVE_POOL_COMPATIBILITY_v1",
            "POOL_CONTEST_COMPATIBILITY_PASS": bool(derived.get("REFERENCE_WINNER_COMPATIBLE")),
            "REFERENCE_CONTEST_COMPATIBILITY_PASS": bool(derived.get("REFERENCE_WINNER_COMPATIBLE")),
            **pool_meta, **derived,
        }
        if causal_path is not None and derived.get("CAUSAL_CLASSIFICATION_ALLOWED"):
            merged["STATUS"] = "PASS" if derived.get("REFERENCE_WINNER_COMPATIBLE") else "PASS_DERIVED_ACTIVE_POOL_COMPATIBLE_CAUSAL_TARGET"
            merged["CAUSAL_TARGET_CONTEST"] = str(causal_path)
            return causal_path, merged
        merged["STATUS"] = derived.get("CAUSAL_TARGET_STATUS", "UNRESOLVED_CAUSAL_TARGET")
        return contest, merged

    reference = _postlock_compatibility_gate(contest, resolved_pool, sport, mode)
    reference.update(pool_meta)
    reference["REFERENCE_CONTEST_COMPATIBILITY_PASS"] = bool(reference.get("POOL_CONTEST_COMPATIBILITY_PASS"))
    if reference.get("CAUSAL_CLASSIFICATION_ALLOWED", True):
        reference.update({
            "CAUSAL_TARGET_STATUS": "PASS_REFERENCE_WINNER_COMPATIBLE",
            "CAUSAL_TARGET_SOURCE": "REFERENCE_WINNER",
            "REFERENCE_WINNER_COMPATIBLE": True,
            "CAUSAL_TARGET_CONTEST": str(contest),
        })
        return contest, reference
    if sport_u == "MLB" and mode_u == "CLASSIC" and resolved_pool is not None and resolved_pool.exists():
        causal_path, derived = _mlb_classic_active_pool_compatible_view(contest, resolved_pool, output_dir)
        merged = {**reference, **derived}
        merged["REFERENCE_GATE_STATUS"] = reference.get("STATUS")
        merged["REFERENCE_MATCH_REJECT_REASONS"] = reference.get("MATCH_REJECT_REASONS", [])
        if causal_path is not None and derived.get("CAUSAL_CLASSIFICATION_ALLOWED"):
            merged["STATUS"] = "PASS_DERIVED_ACTIVE_POOL_COMPATIBLE_CAUSAL_TARGET"
            merged["CAUSAL_TARGET_CONTEST"] = str(causal_path)
            return causal_path, merged
        merged["STATUS"] = derived.get("CAUSAL_TARGET_STATUS", "UNRESOLVED_CAUSAL_TARGET")
        return contest, merged
    return contest, reference

def _car_shop_failure_class(science: dict[str, Any], receipt: Path | None, compatibility: dict[str, Any] | None = None) -> str:
    compatibility = compatibility or {"CAUSAL_CLASSIFICATION_ALLOWED": True, "STATUS": "NOT_APPLICABLE"}
    if not compatibility.get("CAUSAL_CLASSIFICATION_ALLOWED", True):
        if compatibility.get("STATUS") == "UNRESOLVED_ACTIVE_POOL_REQUIRED":
            return "UNRESOLVED_ACTIVE_POOL_REQUIRED_FOR_CAUSAL_CLASSIFICATION"
        if compatibility.get("CAUSAL_TARGET_STATUS") == "UNRESOLVED_NO_ACTIVE_POOL_COMPATIBLE_CONTEST_ENTRY":
            return "UNRESOLVED_NO_ACTIVE_POOL_COMPATIBLE_CAUSAL_TARGET"
        return "POOL_CONTEST_SLATE_MISMATCH_CAUSAL_CLASSIFICATION_BLOCKED"
    # Missing Phase 2 telemetry is not evidence that the winner failed birth.
    if (not science.get("WINNER_EXACT_PHASE2_BIRTH")) and int(science.get("PHASE2_LINEUPS_REVIEWED") or 0) == 0 and not science.get("PHASE2_MANIFEST_SHA256"):
        return "UNRESOLVED_PHASE2_BIRTH_REQUIRES_EXECUTION_PARITY_ARTIFACT"
    # Do not convert missing handoff/selector telemetry into a false handoff failure.
    if science.get("WINNER_SELECTED_TO_BOARD"):
        return "MODEL_OR_VARIANCE_FAILURE"
    if not science.get("WINNER_EXACT_PHASE2_BIRTH"):
        return "GENERATOR_FAMILY_ALLOCATION_OR_RECALL_FAILURE"
    if receipt is None or not receipt.exists():
        return "UNRESOLVED_HANDOFF_VS_SELECTOR_REQUIRES_EXECUTION_PARITY_RECEIPT"
    return str(science.get("FAILURE_CLASS"))


def _failure_evidence(science: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "VALID_CONTEST_LINEUPS", "WINNER_TIES", "WINNERS", "WINNER_EXACT_PHASE2_BIRTH",
        "WINNER_REACHED_HANDOFF_AND_SELECTOR", "WINNER_SELECTED_TO_BOARD", "WINNER_NEAREST_PHASE2_OVERLAP",
        "WINNER_NEAREST_PHASE2_SWAPS", "WINNER_NEAREST_BOARD_OVERLAP", "WINNER_NEAREST_BOARD_SWAPS",
        "FAILURE_CLASS", "PHASE2_LINEUPS_REVIEWED", "BOARD_LINEUPS_REVIEWED", "COHORT_RECEIPTS",
    )
    return {k: science.get(k) for k in keys}


def evaluate(
    contest: Path,
    output_dir: Path,
    sport: str,
    mode: str,
    phase2_manifest: Path | None = None,
    board: Path | None = None,
    receipt: Path | None = None,
    player_pool: Path | None = None,
    active_pool: Path | None = None,
    platform: str = "DK",
    field_size: int | None = None,
    execution_id: str | None = None,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    doctrine = _json(DOCTRINE_PATH)
    postlock_doctrine = _json(POSTLOCK_DOCTRINE_PATH)
    registry = _json(REGISTRY_PATH)
    state_contract = _json(STATE_CONTRACT_PATH)
    ledger = _json(CHANGE_LEDGER_PATH)

    if doctrine.get("DOCTRINE_ID") != "CAR_SHOP_REPAIR_v1" or doctrine.get("STATUS") != "LOCKED_HARD_GATE":
        raise RuntimeError("CAR_SHOP_DOCTRINE_NOT_LOCKED")
    if not registry.get("GLOBAL_RULES", {}).get("CAR_SHOP_REPAIR_PROTOCOL_REQUIRED_FOR_ADVISOR_DIAGNOSTICS"):
        raise RuntimeError("CAR_SHOP_REGISTRY_GATE_MISSING")

    engine = _resolve_engine(registry, platform, sport, mode)
    causal_contest, compatibility = _resolve_postlock_causal_view(contest, player_pool, sport, mode, output_dir, receipt=receipt, active_pool=active_pool)
    science = winner_science_evaluate(
        contest=causal_contest,
        output_dir=output_dir,
        sport=sport,
        mode=mode,
        phase2_manifest=phase2_manifest,
        board=board,
        receipt=receipt,
        player_pool=active_pool if active_pool is not None else player_pool,
    )
    validated, rejected = _history(ledger, sport)
    global_patch_ids = [x.get("PATCH_ID") for x in registry.get("GLOBAL_PATCHES", []) if isinstance(x, dict) and x.get("PATCH_ID")]
    active_patches = list(dict.fromkeys([*(engine.get("ACTIVE_PATCHES") or []), *global_patch_ids]))
    active_doctrines = list(dict.fromkeys([*(engine.get("ACTIVE_DOCTRINES") or []), "CAR_SHOP_REPAIR_v1", "APEX_GLOBAL_POSTLOCK_LOSS_CAUSAL_RESEARCH_AND_REPAIR_v1"]))

    car_shop_failure = _car_shop_failure_class(science, receipt, compatibility)

    packet = {
        "CAR_SHOP_CONTEXT_PACKET_STATUS": "PASS",
        "ROUTER_ID": ROUTER_ID,
        "CAR_SHOP_DOCTRINE_ID": doctrine["DOCTRINE_ID"],
        "CAR_SHOP_DOCTRINE_STATUS": doctrine["STATUS"],
        "POSTLOCK_CAUSAL_DOCTRINE_ID": postlock_doctrine.get("DOCTRINE_ID"),
        "ACTIVE_GLOBAL_STATE_VERSION_AND_HASH_STATUS": {
            "STATE_VERSION": registry.get("STATE_VERSION") or registry.get("REGISTRY_STATE_VERSION"),
            "REGISTRY_STATE_VERSION": registry.get("REGISTRY_STATE_VERSION"),
            "BUNDLE_HASH_STATUS": "BOOTSTRAP_VERIFICATION_REQUIRED_AND_PRESERVED",
        },
        "PLATFORM_SPORT_MODE_FIELD_SIZE_AND_EXECUTION_ID": {
            "PLATFORM": _platform_norm(platform),
            "SPORT": sport.upper(),
            "MODE": mode.upper(),
            "FIELD_SIZE_REQUESTED": field_size,
            "FIELD_SIZE_CONTEST_VALID": science.get("VALID_CONTEST_LINEUPS"),
            "EXECUTION_ID": execution_id,
        },
        "EXACT_ENGINE_SOURCE_AND_ACTIVE_PATCHES": {
            "ENGINE_ID": engine.get("ENGINE_ID"),
            "ENTRYPOINT": engine.get("ENTRYPOINT"),
            "AUTHORITY_STATUS": engine.get("AUTHORITY_STATUS"),
            "EXPECTED_SHA256": engine.get("EXPECTED_SHA256", {}),
            "ACTIVE_PATCHES": active_patches,
            "ACTIVE_DOCTRINES": active_doctrines,
        },
        "ROSTER_AND_LEGALITY_RULES": _rule_snapshot(engine),
        "PHASE1_CALIBRATION_MECHANICS": {
            "GLOBAL_PHASE2_ARCHITECTURE": engine.get("GLOBAL_PHASE2_ARCHITECTURE"),
            "CALIBRATION_ASSET": engine.get("CALIBRATION_ASSET"),
            "CALIBRATION_HASH_OR_ENTRYPOINT_BINDINGS": {k: v for k, v in engine.get("EXPECTED_SHA256", {}).items() if "calibration" in k.lower() or "phase1" in k.lower()},
        },
        "PHASE2_BIRTH_AND_FAMILY_CLOSURE_MECHANICS": {
            "PHASE2_BIRTH_METHOD": engine.get("PHASE2_BIRTH_METHOD"),
            "GLOBAL_PHASE2_ARCHITECTURE": engine.get("GLOBAL_PHASE2_ARCHITECTURE"),
            "ACTIVE_CLOSURE_PATCHES": [x for x in active_patches if any(t in x for t in ("CLOSURE", "RECALL", "SIBLING", "PHASE2"))],
        },
        "PHASE2_TO_HANDOFF_TO_SELECTOR_IDENTITY_POLICY": {
            "PARITY_REQUIRED": engine.get("PHASE2_PHASE3_HANDOFF_SELECTOR_PARITY_REQUIRED"),
            "POST_PHASE2_MUTATION_ALLOWED": engine.get("POST_PHASE2_MUTATION_ALLOWED"),
            "SELECTOR_REVIEW_POLICY": engine.get("SELECTOR_REVIEW_POLICY"),
        },
        "MONTE_CARLO_AND_PUBLIC_FIELD_MODEL_MECHANICS": {
            "SELECTOR_TARGET": engine.get("SELECTOR_TARGET"),
            "SELECTOR_MEAN_WEIGHT": engine.get("SELECTOR_MEAN_WEIGHT"),
            "ACTIVE_SIM_PATCHES": [x for x in active_patches if any(t in x for t in ("SIM", "MONTE", "FIELD", "TAIL", "TOP_0_1"))],
        },
        "FINAL_SELECTOR_AND_PORTFOLIO_ORDERING_MECHANICS": {
            "SELECTOR_TARGET": engine.get("SELECTOR_TARGET"),
            "SELECTOR_REVIEW_POLICY": engine.get("SELECTOR_REVIEW_POLICY"),
            "FILLERS_ALLOWED": engine.get("FILLERS_ALLOWED"),
            "ACTIVE_SELECTOR_PATCHES": [x for x in active_patches if any(t in x for t in ("SELECTOR", "RANKER", "PORTFOLIO", "TROPHY"))],
        },
        "VALIDATED_WORKING_FINDINGS": validated,
        "VALIDATED_REPAIRS_ALREADY_RETAINED": [x for x in active_patches if x not in {"HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1"}],
        "REJECTED_OR_REGRESSIVE_EXPERIMENTS": rejected,
        "POSTLOCK_SLATE_COMPATIBILITY_GATE": compatibility,
        "CURRENT_POSTLOCK_OR_FORWARD_FAILURE_EVIDENCE": _failure_evidence(science),
        "WINNER_TOP0_1_TOP1_TOP5_AND_WHOLE_FIELD_TRACE_WHEN_AVAILABLE": science.get("COHORT_RECEIPTS"),
        "CURRENT_FAILURE_CLASSIFICATION": car_shop_failure,
        "RAW_WINNER_SCIENCE_FAILURE_CLASSIFICATION": science.get("FAILURE_CLASS"),
        "ADVISOR_CAUSAL_DIAGNOSIS": "BLOCKED_UNTIL_CONTEXT_PACKET_CONSUMED",
        "APEX_COUNTER_EVIDENCE": "REQUIRED_AFTER_ADVISOR_PROPOSAL",
        "REVISED_ADVISOR_RECOMMENDATION": "PENDING",
        "BOUNDED_TEST_RESULT": "PENDING",
        "REPAIR_DECISION": "PENDING",
        "GLOBAL_PROMOTION_STATUS": ("NO_CHANGE_FROM_POSTLOCK_EVIDENCE_ALONE" if compatibility.get("CAUSAL_CLASSIFICATION_ALLOWED", True) else "BLOCKED_NO_VALID_CAUSAL_TARGET"),
        "GOVERNANCE": {
            "POSTLOCK_RESULTS_AS_FORWARD_SELECTOR_INPUT": doctrine.get("REPAIR_GOVERNANCE", {}).get("POSTLOCK_RESULTS_AS_FORWARD_SELECTOR_INPUT"),
            "SAME_SLATE_WINNER_MEMORIZATION": doctrine.get("REPAIR_GOVERNANCE", {}).get("SAME_SLATE_WINNER_MEMORIZATION"),
            "SINGLE_SLATE_PROMOTION": doctrine.get("REPAIR_GOVERNANCE", {}).get("SINGLE_SLATE_PROMOTION"),
            "FAILURE_POLICY_WITHOUT_PACKET": state_contract.get("FAILURE_POLICY", {}).get("ADVISOR_REPAIR_WITHOUT_CAR_SHOP_CONTEXT_PACKET"),
        },
    }
    packet_path = output_dir / "car_shop_context_packet.json"
    packet_path.write_text(json.dumps(packet, indent=2) + "\n", encoding="utf-8")
    receipt_out = {
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "POSTLOCK_ROUTER": ROUTER_ID,
        "CAR_SHOP_CONTEXT_PACKET_STATUS": "PASS",
        "CONTEXT_PACKET": str(packet_path),
        "WINNER_SCIENCE_RECEIPT": str(output_dir / "winner_focused_science_receipt.json"),
        "CURRENT_FAILURE_CLASSIFICATION": car_shop_failure,
        "RAW_WINNER_SCIENCE_FAILURE_CLASSIFICATION": science.get("FAILURE_CLASS"),
        "POSTLOCK_SLATE_COMPATIBILITY_STATUS": compatibility.get("STATUS"),
        "CAUSAL_CLASSIFICATION_ALLOWED": bool(compatibility.get("CAUSAL_CLASSIFICATION_ALLOWED", True)),
        "ADVISOR_REPAIR_ALLOWED": bool(compatibility.get("CAUSAL_CLASSIFICATION_ALLOWED", True)),
        "ADVISOR_ONE_WAY_DIAGNOSIS_ALLOWED": False,
    }
    (output_dir / "car_shop_postlock_router_receipt.json").write_text(json.dumps(receipt_out, indent=2) + "\n", encoding="utf-8")
    return {"SCIENCE": science, "CONTEXT_PACKET": packet, "ROUTER_RECEIPT": receipt_out}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contest", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--sport", required=True)
    parser.add_argument("--mode", required=True)
    parser.add_argument("--phase2-manifest")
    parser.add_argument("--board")
    parser.add_argument("--receipt")
    parser.add_argument("--player-pool")
    parser.add_argument("--active-pool")
    parser.add_argument("--platform", default="DK")
    parser.add_argument("--field-size", type=int)
    parser.add_argument("--execution-id")
    args = parser.parse_args()
    result = evaluate(
        contest=Path(args.contest), output_dir=Path(args.output_dir), sport=args.sport, mode=args.mode,
        phase2_manifest=Path(args.phase2_manifest) if args.phase2_manifest else None,
        board=Path(args.board) if args.board else None,
        receipt=Path(args.receipt) if args.receipt else None,
        player_pool=Path(args.player_pool) if args.player_pool else None,
        active_pool=Path(args.active_pool) if args.active_pool else None,
        platform=args.platform, field_size=args.field_size, execution_id=args.execution_id,
    )
    print(json.dumps(result["ROUTER_RECEIPT"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
