from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

PATCH_ID = "APEX_FOOTBALL_MULTI_PATH_RED_ZONE_INTELLIGENCE_v1_2"
SIDECAR_SCHEMA_VERSION = "APEX_FOOTBALL_RED_ZONE_SIDECAR_v1"

_NUMERIC_ALIASES = {
    "pass_yards": ["O/U PSYD", "PASS_YDS_PROP", "Pass Yds", "L8 Pass Yds"],
    "rush_yards": ["O/U RUYD", "RUSH_YDS_PROP", "Rush Yds", "L8 Rush Yds"],
    "rec_yards": ["O/U REYD", "REC_YDS_PROP", "Rec Yds", "L8 Rec Yds"],
    "receptions": ["O/U REC", "RECEPTIONS_PROP", "REC", "L8 REC"],
    "targets": ["TAR", "L8 TAR"],
    "rush_attempts": ["Rush Att", "L8 Rush Att"],
    "rz_targets": ["RZ Targets", "Red Zone Targets", "RZ_TGT"],
    "rz_rush": ["RZ Rush Att", "Red Zone Rush Attempts", "RZ_RUSH_ATT"],
    "inside10_targets": ["Inside10 Targets", "I10 Targets", "RZ10_TGT"],
    "inside10_rush": ["Inside10 Rush Att", "I10 Rush Att", "RZ10_RUSH_ATT"],
    "inside5_rush": ["Inside5 Rush Att", "I5 Rush Att", "RZ5_RUSH_ATT"],
    "endzone_targets": ["End Zone Targets", "Endzone Targets", "EZ Targets", "EZ_TGT"],
    "rz_target_share": ["RZ Target Share", "Red Zone Target Share", "RZ_TGT_SHARE"],
    "rz_rush_share": ["RZ Rush Share", "Red Zone Rush Share", "RZ_RUSH_SHARE"],
    "goal_line_share": ["Goal Line Share", "GL Share", "GOAL_LINE_SHARE"],
    "qb_rz_pass_att": ["RZ Pass Att", "Red Zone Pass Attempts", "RZ_PASS_ATT"],
    "qb_rz_rush": ["RZ QB Rush Att", "Designed RZ Rush", "RZ_DESIGNED_RUSH"],
    "td_prob_1": ["1+ TD", "TD_PROB_1"],
}

_RZ_CANONICAL = [
    "RZ Targets", "RZ Rush Att", "Inside10 Targets", "Inside10 Rush Att",
    "Inside5 Rush Att", "End Zone Targets", "RZ Target Share", "RZ Rush Share",
    "Goal Line Share", "RZ Pass Att", "RZ QB Rush Att",
]


def _series(df: pd.DataFrame, aliases: list[str]) -> np.ndarray:
    for col in aliases:
        if col in df.columns:
            return pd.to_numeric(df[col], errors="coerce").fillna(0.0).to_numpy(np.float64)
    return np.zeros(len(df), dtype=np.float64)


def _positive_rank01(v: np.ndarray, threshold: float = 0.0) -> np.ndarray:
    """Percentile only among genuinely positive signals; zero stays exact zero."""
    v = np.asarray(v, dtype=np.float64)
    out = np.zeros(len(v), dtype=np.float64)
    idx = np.flatnonzero(np.isfinite(v) & (v > float(threshold)))
    if not len(idx):
        return out
    vals = v[idx]
    order = np.argsort(vals, kind="stable")
    sorted_vals = vals[order]
    ranks = np.zeros(len(idx), dtype=np.float64)
    i = 0
    n = len(idx)
    while i < n:
        j = i + 1
        while j < n and sorted_vals[j] == sorted_vals[i]:
            j += 1
        ranks[order[i:j]] = ((i + j - 1) / 2.0 + 0.5) / n
        i = j
    out[idx] = ranks
    return out


def _norm_positive(v: np.ndarray) -> np.ndarray:
    v = np.maximum(np.asarray(v, dtype=np.float64), 0.0)
    mx = float(np.max(v)) if len(v) else 0.0
    return np.zeros_like(v) if mx <= 0.0 else np.clip(v / mx, 0.0, 1.0)


def _normalize_name(x: Any) -> str:
    return " ".join(str(x).replace(".", "").replace("’", "'").split()).strip().lower()


def _resolve_red_zone_sidecar(pool_path: str | Path | None = None, explicit_path: str | Path | None = None) -> Path | None:
    candidates: list[Path] = []
    if explicit_path:
        candidates.append(Path(explicit_path))
    env = os.environ.get("APEX_FOOTBALL_RED_ZONE_CSV", "").strip()
    if env:
        candidates.append(Path(env))
    if pool_path:
        pool = Path(pool_path)
        candidates.extend([
            pool.with_name(pool.stem + ".redzone.csv"),
            pool.with_name(pool.stem + "_redzone.csv"),
            pool.parent / "football_red_zone_stats.csv",
            pool.parent / "red_zone_stats.csv",
        ])
    for c in candidates:
        if c.exists() and c.is_file():
            return c
    return None


def merge_red_zone_evidence(
    df: pd.DataFrame,
    *,
    pool_path: str | Path | None = None,
    explicit_path: str | Path | None = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Merge optional chronology-valid prelock red-zone data by player identity.

    Existing embedded/prelock-role values win when positive. Sidecar only fills a
    missing/zero player-field value; postlock result columns are never consulted.
    """
    out = df.copy()
    embedded = [c for c in _RZ_CANONICAL if c in out.columns]
    sidecar = _resolve_red_zone_sidecar(pool_path, explicit_path)
    receipt: dict[str, Any] = {
        "PATCH_ID": PATCH_ID,
        "SIDECAR_SCHEMA_VERSION": SIDECAR_SCHEMA_VERSION,
        "RED_ZONE_DATA_STATUS": "EMBEDDED" if embedded else "UNAVAILABLE",
        "RED_ZONE_SIDECAR_PATH": str(sidecar) if sidecar else "",
        "RED_ZONE_MATCHED_PLAYERS": 0,
        "RED_ZONE_ACTIVE_FIELDS": sorted(embedded),
        "POSTLOCK_RESULTS_USED": False,
    }
    if sidecar is None:
        return out, receipt

    rz = pd.read_csv(sidecar)
    name_col = next((c for c in ("PLAYER", "Name", "Player", "name", "player") if c in rz.columns), None)
    main_name = "PLAYER" if "PLAYER" in out.columns else ("Name" if "Name" in out.columns else None)
    if name_col is None:
        raise RuntimeError("RUN_INVALID:RED_ZONE_SIDECAR_MISSING_PLAYER_IDENTITY")
    if main_name is None:
        raise RuntimeError("RUN_INVALID:RED_ZONE_MAIN_FRAME_MISSING_PLAYER_IDENTITY")
    rz = rz.copy()
    rz["_RZ_KEY"] = rz[name_col].map(_normalize_name)
    if rz["_RZ_KEY"].duplicated().any():
        raise RuntimeError("RUN_INVALID:RED_ZONE_SIDECAR_DUPLICATE_PLAYER")
    out["_RZ_KEY"] = out[main_name].map(_normalize_name)

    aliases = {
        "RZ Targets": ["RZ Targets", "rz_targets", "red_zone_targets", "RZ_TGT"],
        "RZ Rush Att": ["RZ Rush Att", "rz_rush_att", "rz_rush_attempts", "red_zone_rush_attempts", "RZ_RUSH_ATT"],
        "Inside10 Targets": ["Inside10 Targets", "inside10_targets", "i10_targets", "RZ10_TGT"],
        "Inside10 Rush Att": ["Inside10 Rush Att", "inside10_rush_att", "inside10_rush_attempts", "i10_rush_att", "RZ10_RUSH_ATT"],
        "Inside5 Rush Att": ["Inside5 Rush Att", "inside5_rush_att", "inside5_rush_attempts", "i5_rush_att", "RZ5_RUSH_ATT", "goal_line_carries"],
        "End Zone Targets": ["End Zone Targets", "end_zone_targets", "endzone_targets", "EZ_TGT"],
        "RZ Target Share": ["RZ Target Share", "rz_target_share", "RZ_TGT_SHARE"],
        "RZ Rush Share": ["RZ Rush Share", "rz_rush_share", "RZ_RUSH_SHARE"],
        "Goal Line Share": ["Goal Line Share", "goal_line_share", "GOAL_LINE_SHARE"],
        "RZ Pass Att": ["RZ Pass Att", "rz_pass_att", "rz_pass_attempts", "red_zone_pass_attempts", "RZ_PASS_ATT"],
        "RZ QB Rush Att": ["RZ QB Rush Att", "rz_qb_rush_att", "qb_rz_rush_attempts", "designed_rz_rush", "RZ_DESIGNED_RUSH"],
    }
    incoming = rz[["_RZ_KEY"]].copy()
    active_fields: list[str] = []
    for canonical, names in aliases.items():
        src = next((c for c in names if c in rz.columns), None)
        if src is not None:
            incoming[canonical + "__RZ"] = pd.to_numeric(rz[src], errors="coerce")
            active_fields.append(canonical)
    if not active_fields:
        raise RuntimeError("RUN_INVALID:RED_ZONE_SIDECAR_NO_SUPPORTED_FIELDS")

    merged = out.merge(incoming, on="_RZ_KEY", how="left")
    matched = np.zeros(len(merged), dtype=bool)
    for canonical in active_fields:
        inc = pd.to_numeric(merged[canonical + "__RZ"], errors="coerce")
        matched |= inc.notna().to_numpy()
        if canonical in merged.columns:
            base = pd.to_numeric(merged[canonical], errors="coerce")
            # Positive embedded/nflverse values are authoritative. Sidecar fills gaps.
            merged[canonical] = base.where(base.fillna(0.0) > 0.0, inc).fillna(0.0)
        else:
            merged[canonical] = inc.fillna(0.0)
        merged.drop(columns=[canonical + "__RZ"], inplace=True)
    merged.drop(columns=["_RZ_KEY"], inplace=True)
    receipt.update({
        "RED_ZONE_DATA_STATUS": "SIDECAR_MERGED",
        "RED_ZONE_MATCHED_PLAYERS": int(matched.sum()),
        "RED_ZONE_ACTIVE_FIELDS": sorted(set(embedded) | set(active_fields)),
    })
    return merged, receipt


def detect_linestar_live_contamination(df: pd.DataFrame) -> dict[str, Any]:
    if "Scored" not in df.columns:
        return {"detected": False, "reason": "NO_LINESTAR_SCORED_COLUMN"}
    scored = pd.to_numeric(df["Scored"], errors="coerce").fillna(0.0).to_numpy(np.float64)
    n_nonzero = int(np.count_nonzero(np.abs(scored) > 1e-9))
    return {
        "detected": bool(n_nonzero > 0),
        "reason": "NONZERO_SCORED_FIELD" if n_nonzero > 0 else "PRELOCK_ZERO_SCORED",
        "nonzero_scored_rows": n_nonzero,
    }


def source_authority_receipt(rotowire_present: bool, linestar_present: bool, linestar_frame: pd.DataFrame | None = None) -> dict[str, Any]:
    contamination = {"detected": False, "reason": "LINESTAR_NOT_PRESENT"}
    if linestar_present and linestar_frame is not None:
        contamination = detect_linestar_live_contamination(linestar_frame)
    return {
        "PATCH_ID": PATCH_ID,
        "ROTOWIRE_ROLE_PROP_AUTHORITY": "PRIMARY_WHEN_AVAILABLE" if rotowire_present else "UNAVAILABLE",
        "LINESTAR_CONSENSUS_LEVERAGE": "EXCLUDED_LIVE_CONTAMINATION" if contamination["detected"] else ("SECONDARY_PRELOCK_ONLY" if linestar_present else "UNAVAILABLE"),
        "LINESTAR_LIVE_CONTAMINATION": bool(contamination["detected"]),
        "LINESTAR_CONTAMINATION_REASON": contamination["reason"],
    }


def derive_player_features(df: pd.DataFrame, pos_col: str = "POS_BASE") -> pd.DataFrame:
    out = df.copy()
    pos = out.get(pos_col, out.get("POS", pd.Series(["UNK"] * len(out)))).astype(str).str.upper().to_numpy(object)

    pass_y = _series(out, _NUMERIC_ALIASES["pass_yards"])
    rush_y = _series(out, _NUMERIC_ALIASES["rush_yards"])
    rec_y = _series(out, _NUMERIC_ALIASES["rec_yards"])
    rec = _series(out, _NUMERIC_ALIASES["receptions"])
    tar = _series(out, _NUMERIC_ALIASES["targets"])
    rush_att = _series(out, _NUMERIC_ALIASES["rush_attempts"])

    # Provider workload fields are valid prelock opportunity evidence. CFB uses
    # projected attempts/targets directly; NFL role snapshots use normalized shares.
    proj_pa = _series(out, ["Proj PA"])
    proj_ra = _series(out, ["Proj RA"])
    proj_tar = _series(out, ["Proj TAR"])
    touches = _series(out, ["TOUCHES"])
    rush_att = np.maximum(rush_att, proj_ra)
    tar = np.maximum(tar, proj_tar)

    pass_sig = np.where(pos == "QB", np.maximum(pass_y, 6.0 * proj_pa), 0.0)
    rush_sig = np.where(np.isin(pos, ["QB", "RB", "WR", "TE"]), rush_y + 1.8 * rush_att, 0.0)
    rec_sig = np.where(np.isin(pos, ["RB", "WR", "TE"]), rec_y + 2.25 * rec + 1.15 * tar, 0.0)

    snap = _series(out, ["SNAPS"]) / 100.0
    routes = _series(out, ["ROUTES"]) / 100.0
    targets_role = _series(out, ["TARGETS"]) / 20.0
    carries_role = _series(out, ["CARRIES"]) / 25.0
    nfl_role_present = bool(np.any((snap + routes + targets_role + carries_role) > 0.0))
    if nfl_role_present:
        pass_cap = np.where(pos == "QB", np.clip(snap, 0.0, 1.0), 0.0)
        rush_cap = np.clip(0.55 * snap + 0.45 * carries_role, 0.0, 1.0)
        rec_cap = np.clip(0.40 * snap + 0.35 * routes + 0.25 * targets_role, 0.0, 1.0)
    else:
        # CFB/provider fallback: normalize within the slate; role columns are already
        # projected prelock volumes and should make the shared feature operational.
        pass_cap = np.where(pos == "QB", _norm_positive(proj_pa), 0.0)
        rush_cap = np.clip(0.70 * _norm_positive(proj_ra) + 0.30 * _norm_positive(touches), 0.0, 1.0)
        rec_cap = np.clip(0.78 * _norm_positive(proj_tar) + 0.22 * _norm_positive(touches), 0.0, 1.0)
        # If no explicit role surface exists but a prop/history channel exists, do
        # not erase it. The signal itself provides bounded viability evidence.
        pass_cap = np.where((pass_cap <= 0) & (pass_sig > 0), 0.35, pass_cap)
        rush_cap = np.where((rush_cap <= 0) & (rush_sig > 0), 0.25, rush_cap)
        rec_cap = np.where((rec_cap <= 0) & (rec_sig > 0), 0.25, rec_cap)

    pass_adj = pass_sig * pass_cap
    rush_adj = rush_sig * rush_cap
    rec_adj = rec_sig * rec_cap
    pass_viable = (pass_adj > 0.0) & (pass_cap >= 0.08)
    rush_viable = (rush_adj > 0.0) & (rush_cap >= 0.08)
    rec_viable = (rec_adj > 0.0) & (rec_cap >= 0.08)

    pass_rank = _positive_rank01(np.where(pass_viable, pass_adj, 0.0))
    rush_rank = _positive_rank01(np.where(rush_viable, rush_adj, 0.0))
    rec_rank = _positive_rank01(np.where(rec_viable, rec_adj, 0.0))
    channel_present = pass_viable.astype(float) + rush_viable.astype(float) + rec_viable.astype(float)
    strength_sum = pass_rank + rush_rank + rec_rank
    channel_strength = np.divide(strength_sum, np.maximum(channel_present, 1.0), out=np.zeros(len(out), dtype=float), where=channel_present > 0)
    breadth_bonus = np.clip(channel_present - 1.0, 0.0, 2.0) / 2.0
    multi = np.where(channel_present > 0, np.clip(0.72 * channel_strength + 0.28 * breadth_bonus, 0.0, 1.0), 0.0)

    rz_targets = _series(out, _NUMERIC_ALIASES["rz_targets"])
    rz_rush = _series(out, _NUMERIC_ALIASES["rz_rush"])
    i10_t = _series(out, _NUMERIC_ALIASES["inside10_targets"])
    i10_r = _series(out, _NUMERIC_ALIASES["inside10_rush"])
    i5_r = _series(out, _NUMERIC_ALIASES["inside5_rush"])
    ez_t = _series(out, _NUMERIC_ALIASES["endzone_targets"])
    rz_t_share = _series(out, _NUMERIC_ALIASES["rz_target_share"])
    rz_r_share = _series(out, _NUMERIC_ALIASES["rz_rush_share"])
    gl_share = _series(out, _NUMERIC_ALIASES["goal_line_share"])
    qb_rz_pa = _series(out, _NUMERIC_ALIASES["qb_rz_pass_att"])
    qb_rz_r = _series(out, _NUMERIC_ALIASES["qb_rz_rush"])
    td_prob = _series(out, _NUMERIC_ALIASES["td_prob_1"])
    exact_rz_present = any(c in out.columns for c in _RZ_CANONICAL)
    if exact_rz_present:
        rz_raw = (
            0.16 * _positive_rank01(rz_targets)
            + 0.16 * _positive_rank01(rz_rush)
            + 0.13 * _positive_rank01(i10_t)
            + 0.13 * _positive_rank01(i10_r)
            + 0.13 * _positive_rank01(i5_r)
            + 0.10 * _positive_rank01(ez_t)
            + 0.06 * _positive_rank01(rz_t_share)
            + 0.06 * _positive_rank01(rz_r_share)
            + 0.03 * _positive_rank01(gl_share)
            + 0.02 * _positive_rank01(qb_rz_pa)
            + 0.02 * _positive_rank01(qb_rz_r)
        )
        redzone = np.clip(0.92 * rz_raw + 0.08 * _positive_rank01(td_prob), 0.0, 1.0)
        # Historical RZ data is damped by current role instead of being a name-only prior.
        rz_cap = np.where(pos == "QB", np.maximum(pass_cap, rush_cap), np.where(pos == "RB", np.maximum(rush_cap, rec_cap), rec_cap))
        redzone *= np.clip(0.35 + 0.65 * rz_cap, 0.0, 1.0)
    else:
        redzone = np.zeros(len(out), dtype=np.float64)

    rz_rush_path = exact_rz_present & ((rz_rush > 0) | (i10_r > 0) | (i5_r > 0) | (qb_rz_r > 0))
    rz_rec_path = exact_rz_present & ((rz_targets > 0) | (i10_t > 0) | (ez_t > 0))
    rz_pass_path = exact_rz_present & (qb_rz_pa > 0)
    red_zone_path_count = rz_rush_path.astype(float) + rz_rec_path.astype(float) + rz_pass_path.astype(float)

    out["MULTI_PATH_CEILING"] = multi
    out["PTS_PATH_COUNT"] = channel_present
    out["RED_ZONE_OPPORTUNITY"] = redzone
    out["RED_ZONE_PATH_COUNT"] = red_zone_path_count
    out["FOOTBALL_MULTI_PATH_PATCH_ID"] = PATCH_ID
    return out


def soft_adjust_mean_sigma(mu: np.ndarray, sigma: np.ndarray, df: pd.DataFrame, sport: str) -> tuple[np.ndarray, np.ndarray]:
    multi_src = df["MULTI_PATH_CEILING"] if "MULTI_PATH_CEILING" in df.columns else pd.Series(np.zeros(len(df)), index=df.index)
    rz_src = df["RED_ZONE_OPPORTUNITY"] if "RED_ZONE_OPPORTUNITY" in df.columns else pd.Series(np.zeros(len(df)), index=df.index)
    multi = pd.to_numeric(multi_src, errors="coerce").fillna(0.0).to_numpy(np.float64)
    rz = pd.to_numeric(rz_src, errors="coerce").fillna(0.0).to_numpy(np.float64)
    cfb_mult = 1.15 if str(sport).upper() == "CFB" else 1.0
    mean_boost = cfb_mult * (0.022 * multi + 0.014 * rz)
    tail_boost = cfb_mult * (0.070 * multi + 0.065 * rz)
    mu2 = np.asarray(mu, dtype=np.float64) * (1.0 + mean_boost)
    sigma2 = np.asarray(sigma, dtype=np.float64) * (1.0 + tail_boost)
    return mu2.astype(np.float32), sigma2.astype(np.float32)
