from __future__ import annotations
import json, os, re
from pathlib import Path
from typing import Iterable

PATCH_ID='APEX_GLOBAL_EXTERNAL_DATA_RECOVERY_ORCHESTRATION_v2'
RECOVERY_RETURN_CODE=76
MAX_RECOVERY_ATTEMPTS=2

_PATTERNS=(
    re.compile(r'RUN_RECOVERABLE:EXTERNAL_DATA_GAP:(?P<variable>[^:\n]+):ENTITIES=(?P<entities>[^:\n]*):DETAIL=(?P<detail>[^\n]+)'),
    re.compile(r'RUN_RECOVERABLE:PREGAME_DATA_GAP:(?P<variable>[^:\n]+):TEAMS=(?P<entities>[^:\n]*):DETAIL=(?P<detail>[^\n]+)'),
)

_INJECTION_CONTRACTS={
    'T_RUNS': {
        'ENV':'APEX_TEAM_RUN_TOTALS_JSON',
        'SCHEMA':'JSON_OBJECT_TEAM_TO_IMPLIED_RUNS',
        'RECOVERY_POLICY':'SEARCH_CURRENT_PUBLIC_MARKET_SOURCES_VERIFY_RECONCILE_INJECT_RERUN',
        'MIN_SOURCES':2,
        'BOUNDS':[1.0,9.0],
    },
}

def _norm_variable(value:str)->str:
    return str(value or '').strip().upper().replace(' ','_').replace('-','_')

def detect(stderr_lines: Iterable[str], terminal_obj: dict|None=None) -> dict|None:
    if isinstance(terminal_obj,dict) and str(terminal_obj.get('RUN_STATE','')).upper() in {'RUN_RECOVERABLE','EXTERNAL_DATA_RECOVERY_REQUIRED'}:
        variable=_norm_variable(terminal_obj.get('VARIABLE') or terminal_obj.get('MISSING_VARIABLE'))
        entities=terminal_obj.get('ENTITIES') or terminal_obj.get('TEAMS') or []
        if isinstance(entities,str): entities=[x.strip() for x in entities.split(',') if x.strip()]
        return {'VARIABLE':variable,'ENTITIES':sorted(set(map(str,entities))),'DETAIL':str(terminal_obj.get('DETAIL') or terminal_obj.get('FAILURE_CODE') or 'PUBLIC_RECOVERY_REQUIRED')}
    text='\n'.join(map(str,stderr_lines or ()))
    for pat in _PATTERNS:
        matches=list(pat.finditer(text))
        if not matches: continue
        m=matches[-1]
        variable=_norm_variable(m.group('variable'))
        entities=sorted({x.strip().upper() for x in m.group('entities').split(',') if x.strip()})
        return {'VARIABLE':variable,'ENTITIES':entities,'DETAIL':m.group('detail').strip()}
    return None

def build_request(*, recovery:dict, sport:str, mode:str, execution_id:str, output_dir:Path, env:dict, child_return_code:int) -> dict:
    variable=_norm_variable(recovery.get('VARIABLE'))
    attempts=int(str(env.get('APEX_EXTERNAL_RECOVERY_ATTEMPT','0') or '0'))
    if attempts>=MAX_RECOVERY_ATTEMPTS:
        return {
            'RUN_STATE':'RUN_INVALID','EXECUTION_STATE':'FAILED','PATCH_ID':PATCH_ID,
            'FAILURE_CODE':f'RUN_INVALID:UNRECOVERABLE_EXTERNAL_DATA_GAP:{variable}:MAX_ATTEMPTS_{attempts}',
            'VARIABLE':variable,'ENTITIES':recovery.get('ENTITIES',[]),'DETAIL':recovery.get('DETAIL'),
            'RECOVERY_ATTEMPTS':attempts,'CHILD_RETURN_CODE':int(child_return_code),
        }
    contract=dict(_INJECTION_CONTRACTS.get(variable) or {
        'ENV':'APEX_RECOVERED_EXTERNAL_DATA_JSON','SCHEMA':'VARIABLE_SPECIFIC_JSON','MIN_SOURCES':2,
        'RECOVERY_POLICY':'SEARCH_CURRENT_TRUSTWORTHY_PUBLIC_SOURCES_VERIFY_RECONCILE_INJECT_RERUN',
    })
    request={
        'RUN_STATE':'EXTERNAL_DATA_RECOVERY_REQUIRED','EXECUTION_STATE':'RESUMABLE','PATCH_ID':PATCH_ID,
        'SPORT':str(sport).upper(),'MODE':str(mode).upper(),'EXECUTION_ID':str(execution_id),
        'VARIABLE':variable,'ENTITIES':list(recovery.get('ENTITIES') or []),'DETAIL':str(recovery.get('DETAIL') or ''),
        'RECOVERY_ACTION':'SEARCH_VALIDATE_INJECT_RERUN_SAME_PINNED_STATE_SLATE',
        'INJECTION_CONTRACT':contract,'NEXT_RECOVERY_ATTEMPT':attempts+1,
        'STATE_VERSION':str(env.get('APEX_GLOBAL_STATE_VERSION') or env.get('APEX_STATE_VERSION') or ''),
        'ORIGINAL_PLAYER_POOL':str(env.get('APEX_ORIGINAL_PLAYER_POOL') or env.get('APEX_PLAYER_POOL') or ''),
        'RUNTIME_PLAYER_POOL':str(env.get('APEX_PLAYER_POOL') or ''),
        'FIELD_SIZE':str(env.get('APEX_FIELD_SIZE') or ''),'CHILD_RETURN_CODE':int(child_return_code),
        'NO_ENGINE_PATCH_REQUIRED':True,'SPORT_MODEL_MUTATION_ALLOWED':False,
    }
    output_dir.mkdir(parents=True,exist_ok=True)
    path=output_dir/f'APEX_{str(sport).upper()}_{str(mode).upper()}_{execution_id}_EXTERNAL_DATA_RECOVERY_REQUEST.json'
    path.write_text(json.dumps(request,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    request['RECOVERY_REQUEST_PATH']=str(path)
    return request
