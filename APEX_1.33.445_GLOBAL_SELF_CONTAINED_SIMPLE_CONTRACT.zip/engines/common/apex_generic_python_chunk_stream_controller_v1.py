#!/usr/bin/env python3
from __future__ import annotations

import ast
import contextlib
import importlib
import importlib.util
import inspect
import hashlib
import io
import json
import os
import pickle
import sys
import time
from pathlib import Path
from typing import Any

PATCH_ID = "APEX_GENERIC_PYTHON_NATIVE_STATEMENT_CHUNK_STREAM_v1"
CONTINUE_CODE = 75
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


class _ReturnSignal(BaseException):
    def __init__(self, value: Any = None):
        self.value = value


class _ReturnTransformer(ast.NodeTransformer):
    def visit_Return(self, node: ast.Return):
        value = node.value if node.value is not None else ast.Constant(None)
        repl = ast.Raise(
            exc=ast.Call(func=ast.Name(id="__APEX_RETURN_SIGNAL__", ctx=ast.Load()), args=[value], keywords=[]),
            cause=None,
        )
        return ast.copy_location(repl, node)


def _atomic_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True, default=str)
        f.write("\n"); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def _atomic_pickle(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("wb") as f:
        pickle.dump(obj, f, protocol=5); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def _load_registry_entry(sport: str, mode: str) -> dict[str, Any]:
    registry = json.loads((ROOT / "engine_registry.json").read_text(encoding="utf-8"))
    su, mu = sport.upper(), mode.upper()
    for entry in registry.get("ENGINES", []):
        if str(entry.get("SPORT", "")).upper() != su:
            continue
        if mu in {str(x).upper() for x in entry.get("MODES", [])}:
            return entry
    raise RuntimeError(f"RUN_INVALID:GENERIC_CHUNK_REGISTRY_ENTRY_MISSING:{su}:{mu}")


def _module_name(path: Path) -> str:
    try:
        rel = path.resolve().relative_to(ROOT.resolve()).with_suffix("")
        parts = list(rel.parts)
        if all(p.isidentifier() for p in parts):
            return ".".join(parts)
    except Exception:
        pass
    return f"apex_chunk_target_{abs(hash(str(path.resolve())))}"


def _import_source(path: Path):
    name = _module_name(path)
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"RUN_INVALID:GENERIC_CHUNK_IMPORT_SPEC_FAILED:{path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    parent = str(path.parent)
    if parent not in sys.path:
        sys.path.insert(0, parent)
    spec.loader.exec_module(mod)
    return mod


def _simple_cli(argv: list[str]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    i = 0
    if argv and not argv[0].startswith("-"):
        out["command"] = argv[0]; i = 1
    while i < len(argv):
        tok = argv[i]
        if not tok.startswith("--"):
            i += 1; continue
        key = tok[2:].replace("-", "_")
        if i + 1 >= len(argv) or argv[i + 1].startswith("--"):
            out[key] = True; i += 1; continue
        val = argv[i + 1]
        # Preserve repeated --out values.
        if key == "out":
            out.setdefault(key, []).append(val)
        else:
            out[key] = val
        i += 2
    for key in ("field_size", "seed", "simulations", "board_size", "candidate_target", "mc_sims"):
        if key in out and out[key] not in (None, ""):
            try: out[key] = int(out[key])
            except Exception: pass
    return out


def _parse_namespace(parser_mod: Any, argv: list[str], use_env_only: bool) -> Any:
    parse_argv = [] if use_env_only else list(argv)
    for name in ("_args", "_parse_args", "parse_args"):
        fn = getattr(parser_mod, name, None)
        if callable(fn):
            old = sys.argv[:]
            try:
                sys.argv = [str(Path(parser_mod.__file__).resolve())] + parse_argv
                return fn()
            finally:
                sys.argv = old
    from types import SimpleNamespace
    vals=_simple_cli(parse_argv)
    if 'config' not in vals and hasattr(parser_mod,'DEFAULT_CONFIG'):
        vals['config']=str(getattr(parser_mod,'DEFAULT_CONFIG'))
    return SimpleNamespace(**vals)


def _coerce_like_default(value: Any, default: Any) -> Any:
    if value is None:
        return value
    if default is inspect._empty:
        return value
    try:
        if isinstance(default, bool) and not isinstance(value, bool):
            return str(value).strip().lower() in {"1", "true", "yes", "on"}
        if isinstance(default, int) and not isinstance(value, int): return int(value)
        if isinstance(default, float) and not isinstance(value, float): return float(value)
        if isinstance(default, Path) and not isinstance(value, Path): return Path(value)
    except Exception:
        return value
    return value


_ALIAS = {
    "pool": ("pool", "player_pool", "input_csv", "input"),
    "pool_path": ("pool", "player_pool", "input_csv", "input"),
    "input_path": ("input", "input_path", "player_pool", "pool"),
    "field_size": ("field_size",),
    "role_evidence": ("role_evidence",),
    "market_evidence": ("market_evidence",),
    "availability_receipt": ("availability_receipt",),
    "final_availability_receipt": ("final_availability_receipt",),
    "execution_id": ("execution_id",),
    "board_path": ("board", "board_path"),
    "output_board": ("board", "output_board"),
    "receipt_path": ("receipt", "receipt_path"),
    "output_receipt": ("receipt", "output_receipt"),
    "out_names": ("out", "out_names"),
    "ledger_path": ("ledger", "ledger_path"),
    "output_ledger": ("ledger", "output_ledger"),
    "identity_path": ("identity_map", "identity_path"),
    "output_identity_map": ("identity_map", "output_identity_map"),
    "out_evidence_path": ("out_evidence_json", "out_evidence_path"),
    "out_dir": ("output_dir", "out_dir"),
    "output_dir": ("output_dir", "out_dir"),
    "seed": ("seed",),
    "candidate_target": ("candidate_target",),
    "board_size": ("board_size",),
    "config_path": ("config", "config_path"),
    "eligibility_path": ("eligibility_file", "eligibility_path"),
    "simulations": ("simulations",),
    "nflverse_cache_dir": ("nflverse_cache_dir",),
    "nflverse_as_of": ("nflverse_as_of",),
    "nflverse_seasons": ("nflverse_seasons",),
    "nflverse_refresh": ("nflverse_refresh",),
}


def _bind_function(fn: Any, ns_obj: Any, arg_map: dict[str, Any], pass_namespace: bool) -> dict[str, Any]:
    sig = inspect.signature(fn)
    vals = vars(ns_obj) if hasattr(ns_obj, "__dict__") else dict(ns_obj)
    if pass_namespace:
        params = list(sig.parameters.values())
        if len(params) != 1:
            raise RuntimeError("RUN_INVALID:GENERIC_CHUNK_NAMESPACE_TARGET_ARITY")
        return {params[0].name: ns_obj}
    bound: dict[str, Any] = {}
    for name, p in sig.parameters.items():
        if p.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            continue
        source = arg_map.get(name)
        candidates = []
        if source is not None:
            candidates = [source] if isinstance(source, str) else list(source)
        else:
            candidates = list(_ALIAS.get(name, (name,)))
        found = False
        for cand in candidates:
            if cand in vals:
                bound[name] = _coerce_like_default(vals[cand], p.default)
                found = True; break
        if not found:
            if p.default is not inspect._empty:
                bound[name] = p.default
            else:
                raise RuntimeError(f"RUN_INVALID:GENERIC_CHUNK_ARGUMENT_MISSING:{name}:{candidates}")
    return bound


def _future_names(run_node: ast.FunctionDef, after_index: int) -> set[str]:
    names: set[str] = set()
    for stmt in run_node.body[after_index + 1:]:
        for node in ast.walk(stmt):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                names.add(node.id)
    return names


def _serializable_state(ns: dict[str, Any], baseline: set[str], future: set[str], params: set[str]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    keep = set(future) | set(params)
    # Persist data globals as well; functions/classes/modules are excluded. This captures
    # runtime receipts/caches without making them execution authority.
    for k, v in ns.items():
        if k.startswith("__"):
            continue
        if k not in keep and k in baseline:
            # Small/serializable baseline data is safe to persist, but skip constants unless
            # the helper changed them into runtime data.
            if k.isupper():
                continue
        if inspect.ismodule(v) or inspect.isroutine(v) or inspect.isclass(v) or isinstance(v, io.IOBase):
            continue
        try:
            pickle.dumps(v, protocol=5)
        except Exception:
            continue
        out[k] = v
    return out


def _sha256_path(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _try_proven_legacy_controller_identity_migration(*, state: dict[str, Any], state_path: Path, identity: dict[str, Any],
                                                     target_path: Path, fn_name: str, sport: str, mode: str) -> bool:
    if str(os.environ.get("APEX_LEGACY_RESUME_MIGRATION_ALLOWED", "0")).strip() != "1":
        return False
    old_ident = dict(state.get("IDENTITY") or {})
    expected_pool_sha = str(os.environ.get("APEX_LEGACY_RESUME_EXPECTED_POOL_SHA256") or "")
    expected_checkpoint = str(os.environ.get("APEX_LEGACY_RESUME_EXPECTED_CHECKPOINT") or "")
    expected_old_state = str(os.environ.get("APEX_LEGACY_RESUME_EXPECTED_CONTROLLER_STATE_VERSION") or "")
    original_pool_raw = os.environ.get("APEX_ORIGINAL_PLAYER_POOL") or os.environ.get("APEX_PROVIDER_PLAYER_POOL")
    if not original_pool_raw or not Path(str(original_pool_raw)).exists():
        return False
    current_original_pool_sha = _sha256_path(Path(str(original_pool_raw)))
    old_pool_meta = old_ident.get("POOL_FILE_META")
    same_coords = (
        str(old_ident.get("PATCH_ID") or "") == PATCH_ID and
        str(old_ident.get("SPORT") or "") == sport and
        str(old_ident.get("MODE") or "") == mode and
        str(old_ident.get("TARGET_SOURCE") or "") == str(target_path.relative_to(ROOT)) and
        str(old_ident.get("TARGET_FUNCTION") or "") == fn_name
    )
    if expected_old_state and str(old_ident.get("STATE_VERSION") or "") != expected_old_state:
        return False
    legacy_mtime_shape = isinstance(old_pool_meta, list) and len(old_pool_meta) == 3 and isinstance(old_pool_meta[2], int)
    checkpoint = str(state.get("CHECKPOINT") or "")
    proof_ok = (
        same_coords and legacy_mtime_shape and expected_pool_sha and current_original_pool_sha == expected_pool_sha and
        expected_checkpoint and checkpoint == expected_checkpoint and Path(checkpoint).exists()
    )
    if not proof_ok:
        return False
    state["LEGACY_IDENTITY_MIGRATION"] = {
        "STATUS": "PROVEN_ONE_TIME_MIGRATION",
        "PRIOR_IDENTITY": old_ident,
        "ORIGINAL_POOL_SHA256": current_original_pool_sha,
        "CHECKPOINT": checkpoint,
    }
    state["IDENTITY"] = identity
    _atomic_json(state_path, state)
    return True


def _board_rows_from_path(path: Path) -> list[dict[str, Any]]:
    if not path.exists(): return []
    if path.suffix.lower() == ".csv":
        import pandas as pd
        return pd.read_csv(path).to_dict("records")
    if path.suffix.lower() == ".json":
        obj = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(obj, list): return [dict(x) for x in obj if isinstance(x, dict)]
        if isinstance(obj, dict):
            for key in ("FINAL_BOARD", "final_board", "board"):
                if isinstance(obj.get(key), list): return [dict(x) for x in obj[key] if isinstance(x, dict)]
    return []


def _final_rows(ns: dict[str, Any], parsed: Any, entry: dict[str, Any]) -> tuple[list[dict[str, Any]], str | None]:
    import pandas as pd
    # Explicit registry template first.
    template = entry.get("CHUNK_STREAM_FINAL_BOARD_PATH_TEMPLATE")
    vals = vars(parsed) if hasattr(parsed, "__dict__") else {}
    if template:
        fmt = {**{k: str(v) for k, v in vals.items()}, **{k: str(v) for k, v in os.environ.items()}}
        try:
            p = Path(str(template).format(**fmt)).resolve()
            rows = _board_rows_from_path(p)
            if rows: return rows, str(p)
        except Exception:
            pass
    for key in ("board_df", "board_ready", "preview", "board"):
        v = ns.get(key)
        if isinstance(v, pd.DataFrame) and len(v):
            for attr in ("board", "output_board", "board_path"):
                raw = vals.get(attr)
                if raw:
                    q = Path(str(raw)).resolve()
                    if q.exists() and q.is_file(): return v.to_dict("records"), str(q)
            return v.to_dict("records"), None
        if isinstance(v, list) and v and all(isinstance(x, dict) for x in v):
            for attr in ("board", "output_board", "board_path"):
                raw = vals.get(attr)
                if raw:
                    q = Path(str(raw)).resolve()
                    if q.exists() and q.is_file(): return [dict(x) for x in v], str(q)
            return [dict(x) for x in v], None
    for attr in ("board", "output_board", "board_path"):
        raw = vals.get(attr)
        if raw:
            p = Path(str(raw)).resolve(); rows = _board_rows_from_path(p)
            if rows: return rows, str(p)
    rec = ns.get("receipt") or ns.get("result") or ns.get("proof")
    if isinstance(rec, dict):
        for key in ("FINAL_BOARD", "final_board", "board"):
            if isinstance(rec.get(key), list):
                rows = [dict(x) for x in rec[key] if isinstance(x, dict)]
                if rows: return rows, None
    raise RuntimeError("RUN_INVALID:GENERIC_CHUNK_FINAL_BOARD_SOURCE_MISSING")


def _terminal_payload(rows: list[dict[str, Any]], src: str | None, parsed: Any, *, patch_id: str, sport: str, mode: str, execution_id: str, completed_chunks: int) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    vals = vars(parsed) if hasattr(parsed, "__dict__") else {}
    for attr in ("receipt", "receipt_path", "output_receipt"):
        raw = vals.get(attr)
        if not raw:
            continue
        rp = Path(str(raw)).resolve()
        if not rp.exists() or not rp.is_file():
            continue
        try:
            obj = json.loads(rp.read_text(encoding="utf-8"))
            if isinstance(obj, dict):
                payload.update(obj)
                break
        except Exception:
            pass
    payload.update({
        "RUN_STATE": payload.get("RUN_STATE", "BOARD_READY"),
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "CONTROLLER_PATCH_ID": patch_id,
        "SPORT": sport, "MODE": mode, "EXECUTION_ID": execution_id,
        "FINAL_BOARD_SIZE": len(rows), "FINAL_BOARD": rows,
        "SOURCE_BOARD_FILE": src,
        "CHUNK_STREAM_COMPLETED_CHUNKS": int(completed_chunks),
    })
    return payload


def main() -> int:
    sport = str(os.environ.get("APEX_SPORT") or "").upper()
    mode = str(os.environ.get("APEX_MODE") or os.environ.get("APEX_SPORT_MODE") or "").upper()
    execution_id = str(os.environ.get("APEX_EXECUTION_ID") or "UNSET")
    if not sport or not mode:
        raise RuntimeError("RUN_INVALID:GENERIC_CHUNK_SPORT_MODE_MISSING")
    entry = _load_registry_entry(sport, mode)
    if str((entry.get("CHUNK_STREAM_MODE_STATUS") or {}).get(mode, "")).upper() != "CERTIFIED":
        raise RuntimeError(f"RUN_INVALID:CHUNK_STREAM_ADAPTER_REQUIRED:{sport}:{mode}")
    target_rel = entry.get("CHUNK_STREAM_TARGET_SOURCE") or entry.get("ENTRYPOINT")
    parser_rel = entry.get("CHUNK_STREAM_ARG_PARSER_SOURCE") or entry.get("ENTRYPOINT")
    fn_name = str(entry.get("CHUNK_STREAM_TARGET_FUNCTION") or "")
    target_path = (ROOT / str(target_rel)).resolve(); parser_path = (ROOT / str(parser_rel)).resolve()
    if not target_path.exists() or not parser_path.exists():
        raise RuntimeError(f"RUN_INVALID:GENERIC_CHUNK_TARGET_MISSING:{target_path}:{parser_path}")
    target_mod = _import_source(target_path)
    parser_mod = target_mod if parser_path == target_path else _import_source(parser_path)
    if not fn_name:
        fn_name = next((x for x in ("run", "run_engine", "build", "execute") if callable(getattr(target_mod, x, None))), "")
    fn = getattr(target_mod, fn_name, None)
    if not callable(fn):
        raise RuntimeError(f"RUN_INVALID:GENERIC_CHUNK_TARGET_FUNCTION_MISSING:{fn_name}")
    parsed = _parse_namespace(parser_mod, sys.argv[1:], bool(entry.get("CHUNK_STREAM_USE_ENV_ARGS")))
    arg_map = entry.get("CHUNK_STREAM_ARG_MAP") or {}
    params = _bind_function(fn, parsed, arg_map, bool(entry.get("CHUNK_STREAM_PASS_NAMESPACE")))

    tree = ast.parse(target_path.read_text(encoding="utf-8"))
    funcs = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == fn_name]
    if len(funcs) != 1:
        raise RuntimeError(f"RUN_INVALID:GENERIC_CHUNK_TARGET_FUNCTION_AST_NOT_UNIQUE:{fn_name}:{len(funcs)}")
    run_node = funcs[0]
    statements = list(run_node.body)
    if not statements:
        raise RuntimeError("RUN_INVALID:GENERIC_CHUNK_EMPTY_TARGET_BODY")

    base_root = Path(os.environ.get("APEX_RESUMABLE_RUN_ROOT") or os.environ.get("APEX_OUTPUT_DIR") or "/mnt/data")
    state_root = base_root / f"generic_chunk_{sport.lower()}_{mode.lower()}"
    state_root.mkdir(parents=True, exist_ok=True)
    state_path = state_root / "controller_state.json"
    pool_raw = os.environ.get("APEX_PLAYER_POOL") or getattr(parsed, "pool", None) or getattr(parsed, "player_pool", None) or getattr(parsed, "input", None) or getattr(parsed, "input_csv", None)
    pool_meta = None
    if pool_raw and Path(str(pool_raw)).exists():
        _pool_p = Path(str(pool_raw))
        _pool_h = hashlib.sha256(_pool_p.read_bytes()).hexdigest()
        pool_meta = [_pool_p.name, _pool_h]
    identity = {
        "PATCH_ID": PATCH_ID, "SPORT": sport, "MODE": mode, "EXECUTION_ID": execution_id,
        "STATE_VERSION": str(os.environ.get("APEX_GLOBAL_STATE_VERSION") or os.environ.get("APEX_RESUMABLE_STATE_VERSION") or "UNSPECIFIED"),
        "TARGET_SOURCE": str(target_path.relative_to(ROOT)), "TARGET_FUNCTION": fn_name, "POOL_FILE_META": pool_meta,
    }
    state: dict[str, Any] = {}
    if state_path.exists():
        try: state = json.loads(state_path.read_text(encoding="utf-8"))
        except Exception: state = {}
    if state and state.get("IDENTITY") != identity:
        migrated = _try_proven_legacy_controller_identity_migration(
            state=state, state_path=state_path, identity=identity, target_path=target_path, fn_name=fn_name,
            sport=sport, mode=mode,
        )
        if not migrated:
            stale = state_root.with_name(state_root.name + f".stale.{time.time_ns()}")
            os.replace(state_root, stale); state_root.mkdir(parents=True, exist_ok=True); state = {}
    if not state:
        state = {"PATCH_ID": PATCH_ID, "IDENTITY": identity, "STAGE_INDEX": 0, "COMPLETED_CHUNKS": 0, "EXECUTION_STATE": "RUNNING"}
        _atomic_json(state_path, state)
    idx = int(state.get("STAGE_INDEX", 0))
    if idx >= len(statements):
        # Rehydrate latest checkpoint only to discover final board sources if needed.
        ns = target_mod.__dict__
        ck = state.get("CHECKPOINT")
        if ck and Path(str(ck)).exists():
            with Path(str(ck)).open("rb") as f:
                ns.update(pickle.load(f))
        rows, src = _final_rows(ns, parsed, entry)
        print(json.dumps(_terminal_payload(rows, src, parsed, patch_id=PATCH_ID, sport=sport, mode=mode, execution_id=execution_id, completed_chunks=int(state.get("COMPLETED_CHUNKS",0))), default=str), flush=True)
        return 0

    ns = target_mod.__dict__
    baseline = set(ns)
    ns.update(params)
    ns["__APEX_RETURN_SIGNAL__"] = _ReturnSignal
    ck_in = state.get("CHECKPOINT")
    if ck_in and Path(str(ck_in)).exists():
        with Path(str(ck_in)).open("rb") as f:
            restored = pickle.load(f)
        ns.update(restored)
        # Current CLI/environment remains authority for function parameters.
        ns.update(params)
    stmt = statements[idx]
    transformed = _ReturnTransformer().visit(ast.fix_missing_locations(ast.Module(body=[stmt], type_ignores=[])))
    ast.fix_missing_locations(transformed)
    returned = False
    captured_return = None
    muted = io.StringIO()
    try:
        with contextlib.redirect_stdout(muted):
            exec(compile(transformed, str(target_path), "exec"), ns, ns)
    except _ReturnSignal as ret:
        returned = True; captured_return = ret.value
    except BaseException as exc:
        if getattr(exc, "APEX_CHUNK_STREAM_YIELD", False):
            progress = dict(getattr(exc, "apex_chunk_stream_progress", {}) or {})
            intra_checkpoint = str(getattr(exc, "apex_chunk_stream_checkpoint", "") or "")
            native_patch = str(getattr(exc, "apex_chunk_stream_patch_id", "") or PATCH_ID)
            state["COMPLETED_CHUNKS"] = int(state.get("COMPLETED_CHUNKS", 0)) + 1
            state["EXECUTION_STATE"] = "RESUMABLE"
            state["INTRA_STATEMENT_PATCH_ID"] = native_patch
            state["INTRA_STATEMENT_PROGRESS"] = progress
            state["INTRA_STATEMENT_CHECKPOINT"] = intra_checkpoint
            _atomic_json(state_path, state)
            print(json.dumps({
                "RUN_STATE":"CHECKPOINTED_CONTINUE", "EXECUTION_STATE":"RESUMABLE",
                "PATCH_ID":native_patch, "CONTROLLER_PATCH_ID":PATCH_ID,
                "SPORT":sport, "MODE":mode, "EXECUTION_ID":execution_id,
                "COMPLETED_STAGE":f"STATEMENT_{idx:04d}_INTRA_CHUNK",
                "NEXT_STAGE":f"STATEMENT_{idx:04d}", "STAGE_INDEX":idx,
                "CHECKPOINT":str(state.get("CHECKPOINT") or ""),
                "CONTROLLER_STATE":str(state_path),
                "INTRA_STATEMENT_CHECKPOINT":intra_checkpoint,
                "INTRA_STATEMENT_PROGRESS":progress,
                "CHUNK_STREAM_COMPLETED_CHUNKS":int(state["COMPLETED_CHUNKS"]),
            }, default=str), flush=True)
            return CONTINUE_CODE
        raise
    # Intermediate raw runtime output is diagnostic-only; never leak a premature BOARD_READY.
    if muted.getvalue().strip():
        (state_root / f"chunk_{idx:04d}_stdout.log").write_text(muted.getvalue(), encoding="utf-8")

    state["COMPLETED_CHUNKS"] = int(state.get("COMPLETED_CHUNKS", 0)) + 1
    if returned or idx + 1 >= len(statements):
        if returned:
            ns["__APEX_RETURN_VALUE__"] = captured_return
        state["STAGE_INDEX"] = len(statements); state["EXECUTION_STATE"] = "COMPLETED"
        future = set()
        ck_out = state_root / f"checkpoint_{idx:04d}.pkl"
        data = _serializable_state(ns, baseline, future, set(params))
        _atomic_pickle(ck_out, data); state["CHECKPOINT"] = str(ck_out); _atomic_json(state_path, state)
        rows, src = _final_rows(ns, parsed, entry)
        print(json.dumps(_terminal_payload(rows, src, parsed, patch_id=PATCH_ID, sport=sport, mode=mode, execution_id=execution_id, completed_chunks=int(state["COMPLETED_CHUNKS"])), default=str), flush=True)
        return 0

    future = _future_names(run_node, idx)
    ck_out = state_root / f"checkpoint_{idx:04d}.pkl"
    data = _serializable_state(ns, baseline, future, set(params))
    _atomic_pickle(ck_out, data)
    # Only newest checkpoint is needed; each completed chunk has a state receipt.
    old = state.get("CHECKPOINT")
    state["CHECKPOINT"] = str(ck_out); state["STAGE_INDEX"] = idx + 1; state["EXECUTION_STATE"] = "RESUMABLE"
    chunk_receipt = state_root / f"chunk_{idx:04d}.json"
    _atomic_json(chunk_receipt, {"PATCH_ID":PATCH_ID,"SPORT":sport,"MODE":mode,"EXECUTION_ID":execution_id,"CHUNK_INDEX":idx,"SOURCE_LINES":[int(stmt.lineno),int(stmt.end_lineno)],"CHECKPOINT":str(ck_out),"STATUS":"COMMITTED"})
    _atomic_json(state_path, state)
    if old and Path(str(old)).exists() and str(old) != str(ck_out):
        try: Path(str(old)).unlink()
        except OSError: pass
    print(json.dumps({"RUN_STATE":"CHECKPOINTED_CONTINUE","EXECUTION_STATE":"RESUMABLE","PATCH_ID":PATCH_ID,"SPORT":sport,"MODE":mode,"EXECUTION_ID":execution_id,"COMPLETED_STAGE":f"STATEMENT_{idx:04d}","NEXT_STAGE":f"STATEMENT_{idx+1:04d}","STAGE_INDEX":idx+1,"CHECKPOINT":str(ck_out),"CHUNK_STREAM_COMPLETED_CHUNKS":int(state["COMPLETED_CHUNKS"])}, default=str), flush=True)
    return CONTINUE_CODE


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except BaseException as exc:
        print(json.dumps({"RUN_STATE":"RUN_INVALID","EXECUTION_STATE":"FAILED","PATCH_ID":PATCH_ID,"FAILURE_CODE":f"{type(exc).__name__}:{exc}","FINAL_BOARD_SIZE":0}), flush=True)
        raise SystemExit(2)
