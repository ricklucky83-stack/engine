from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

PATCH_ID = "APEX_GLOBAL_FINAL_BOARD_FIRST_STATS_SECOND_SOURCE_PROVENANCE_HARD_GATE_v1"

# These artifacts are review/evidence surfaces. They are never user-visible board authority.
FORBIDDEN_BOARD_SOURCE_TOKENS = (
    "AI_TERMINAL_CANDIDATE",
    "TERMINAL_CANDIDATE",
    "PREVALIDATION",
    "SELECTOR_LEDGER",
    "TERMINAL_SELECTOR_LEDGER",
    "PHASE2_MANIFEST",
    "HANDOFF",
    "CANDIDATE_SURFACE",
    "REVIEW_SURFACE",
)

CANONICAL_BOARD_TOKENS = (
    "FINAL_BOARD",
    "PRODUCTION_BOARD_READY",
)

class BoardOutputGuardError(RuntimeError):
    pass


def classify_artifact(path: str | Path) -> str:
    name = Path(path).name.upper()
    if any(tok in name for tok in FORBIDDEN_BOARD_SOURCE_TOKENS):
        return "FORBIDDEN_NONBOARD_ARTIFACT"
    if any(tok in name for tok in CANONICAL_BOARD_TOKENS):
        return "CANONICAL_FINAL_BOARD_ARTIFACT"
    return "UNKNOWN_ARTIFACT"


def assert_presentable_board_source(path: str | Path) -> Path:
    p = Path(path)
    kind = classify_artifact(p)
    if kind != "CANONICAL_FINAL_BOARD_ARTIFACT":
        raise BoardOutputGuardError(f"USER_VISIBLE_BOARD_SOURCE_REJECTED:{kind}:{p.name}")
    return p


def select_canonical_final_board(paths: Iterable[str | Path]) -> Path:
    candidates = []
    rejected = []
    for raw in paths:
        p = Path(raw)
        kind = classify_artifact(p)
        if kind == "CANONICAL_FINAL_BOARD_ARTIFACT":
            candidates.append(p)
        elif kind == "FORBIDDEN_NONBOARD_ARTIFACT":
            rejected.append(p)
    if not candidates:
        suffix = ",".join(p.name for p in rejected[:8])
        raise BoardOutputGuardError(f"CANONICAL_FINAL_BOARD_ARTIFACT_MISSING:REJECTED={suffix}")
    # Prefer the sealed machine production artifact over a native final-board CSV.
    candidates.sort(key=lambda p: ("PRODUCTION_BOARD_READY" not in p.name.upper(), "FINAL_BOARD" not in p.name.upper(), p.name))
    return assert_presentable_board_source(candidates[0])


def output_sequence(*, include_metrics: bool = True) -> list[str]:
    seq = ["FINAL_BOARD"]
    if include_metrics:
        seq.append("RUN_METRICS_STATS")
    return seq


def command_requests_metrics(text: str) -> bool:
    t = str(text or "")
    return bool(re.search(r"\b(?:SHOW\s+)?RUN\s+METRICS(?:\s+AND\s+STATS)?\b|\bMETRICS\s+AND\s+STATS\b", t, re.I))


def presentation_contract(command_text: str = "") -> dict:
    metrics = command_requests_metrics(command_text)
    return {
        "PATCH_ID": PATCH_ID,
        "USER_VISIBLE_BOARD_SOURCE": "SEALED_MACHINE_FINAL_BOARD_ARTIFACT_ONLY",
        "NONBOARD_ARTIFACTS_AS_BOARD_SOURCE": "HARD_REJECT",
        "FINAL_BOARD_RENDER_ORDER": 1,
        "RUN_METRICS_STATS_RENDER_ORDER": 2 if metrics else None,
        "FINAL_BOARD_REQUIRED_BEFORE_METRICS": bool(metrics),
        "OUTPUT_SEQUENCE": output_sequence(include_metrics=metrics),
    }
