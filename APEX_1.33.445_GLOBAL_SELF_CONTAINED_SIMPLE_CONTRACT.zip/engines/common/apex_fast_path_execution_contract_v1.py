from __future__ import annotations
import hashlib, json
from pathlib import Path
from typing import Iterable, Mapping, Sequence

PATCH_ID = "APEX_GLOBAL_FAST_PATH_METHOD_ONLY_AND_STATE_PARITY_v1"
MAX_NON_EXECUTION_ACTIONS_BEFORE_LAUNCH = 2
REQUIRED_METRIC_KEYS = (
    "ACTIVE_POOL", "OUT_PURGE", "PHASE2_BUILT_LINEUPS", "BASE_SIM_TRIALS",
    "BUBBLE_EXTRA_TRIALS_TOTAL", "HANDOFF_SURVIVORS",
    "SELECTOR_REVIEWED_LINEUPS", "FINAL_BOARD_SIZE", "EXECUTION_STATE",
)


FAST_PATH_SEMANTICS = "CHUNK_AND_STREAM_ONLY"
FAST_PATH_INTEGRITY_BYPASS_ALLOWED = False
FAST_PATH_METHOD_PRIORITY = ("NUMBA_COMPILED", "VECTORIZED", "SPARSE", "BRANCH_AND_BOUND", "CHUNKED_STREAMING")

def fast_path_semantics_receipt() -> dict:
    return {
        "PATCH_ID": PATCH_ID,
        "FAST_PATH_SEMANTICS": FAST_PATH_SEMANTICS,
        "FAST_PATH_INTEGRITY_BYPASS_ALLOWED": FAST_PATH_INTEGRITY_BYPASS_ALLOWED,
        "METHOD_PRIORITY": list(FAST_PATH_METHOD_PRIORITY),
        "IDENTITY_HASH_STATE_GATES_ALWAYS_ON": True,
        "NO_AUDITS_DIAGNOSTICS_MEANS_VERBOSE_DIAGNOSTIC_SUPPRESSION_ONLY": True,
    }

class FastPathContractError(RuntimeError):
    pass

CALIBRATION_BIRTH_HARD_GATE_ID = "APEX_GLOBAL_FAST_PATH_CALIBRATION_QUALIFIED_BIRTH_HARD_GATE_v1"
CALIBRATION_FIRST_PHASE2_DOCTRINE_ID = "APEX_CALIBRATION_FIRST_PHASE2_CONSTRUCTION_v2"

def require_global_calibration_birth_policy(registry: Mapping[str, object], *, sport: str, mode: str, fast_path_required: bool, engine_entry: Mapping[str, object] | None = None) -> dict:
    """Fail closed if the canonical registry does not enforce calibration-qualified birth globally."""
    if not bool(fast_path_required):
        return {"PATCH_ID": CALIBRATION_BIRTH_HARD_GATE_ID, "APPLIES": False}
    active = str(registry.get("ACTIVE_GLOBAL_FAST_PATH_CALIBRATION_QUALIFIED_BIRTH_HARD_GATE") or "")
    policy = registry.get("GLOBAL_FAST_PATH_CALIBRATION_QUALIFIED_BIRTH_POLICY") or {}
    if active != CALIBRATION_BIRTH_HARD_GATE_ID:
        raise FastPathContractError(f"GLOBAL_CALIBRATION_BIRTH_GATE_MISSING:{sport}:{mode}:{active or 'UNSET'}")
    required = {
        "PHASE1_BEFORE_BIRTH": True,
        "UNQUALIFIED_CANDIDATE_BIRTH_ALLOWED": False,
        "FULL_LEGAL_UNIVERSE_ENUMERATION_ALLOWED": False,
        "PRE_PHASE2_RAW_LATTICE_MATERIALIZATION_ALLOWED": False,
        "CHUNK_STREAM_REQUIRED": True,
        "FAIL_CLOSED": True,
        "ROUTE_CERTIFICATION_REQUIRED": True,
    }
    bad=[f"{k}={policy.get(k)!r}" for k,v in required.items() if policy.get(k) is not v]
    if bad:
        raise FastPathContractError("GLOBAL_CALIBRATION_BIRTH_POLICY_DRIFT:"+"|".join(bad))
    entry = dict(engine_entry or {})
    if not entry:
        sport_u=str(sport).upper(); mode_u=str(mode).upper()
        matches=[]
        for rec in registry.get("ENGINES", []) or []:
            if not isinstance(rec, Mapping):
                continue
            modes=[str(x).upper() for x in (rec.get("MODES") or [])]
            if str(rec.get("SPORT") or "").upper()==sport_u and mode_u in modes:
                matches.append(dict(rec))
        if len(matches)==1:
            entry=matches[0]
        else:
            raise FastPathContractError(f"GLOBAL_CALIBRATION_BIRTH_ROUTE_CERTIFICATION_MISSING:{sport}:{mode}:ENGINE_ENTRY_REQUIRED")
    if entry.get("CALIBRATION_QUALIFIED_BIRTH_CERTIFIED") is not True:
        raise FastPathContractError(f"GLOBAL_CALIBRATION_BIRTH_ROUTE_NOT_CERTIFIED:{sport}:{mode}:{entry.get('ENGINE_ID','UNKNOWN')}")
    if entry.get("UNQUALIFIED_CANDIDATE_BIRTH_ALLOWED") is not False:
        raise FastPathContractError(f"GLOBAL_CALIBRATION_BIRTH_ROUTE_POLICY_DRIFT:{sport}:{mode}:UNQUALIFIED_CANDIDATE_BIRTH_ALLOWED")
    if entry.get("FULL_LEGAL_UNIVERSE_ENUMERATION_ALLOWED") is not False:
        raise FastPathContractError(f"GLOBAL_CALIBRATION_BIRTH_ROUTE_POLICY_DRIFT:{sport}:{mode}:FULL_LEGAL_UNIVERSE_ENUMERATION_ALLOWED")
    return {
        "PATCH_ID": CALIBRATION_BIRTH_HARD_GATE_ID,
        "APPLIES": True,
        "SPORT": str(sport).upper(),
        "MODE": str(mode).upper(),
        "PHASE1_BEFORE_BIRTH": True,
        "UNQUALIFIED_CANDIDATE_BIRTH_ALLOWED": False,
        "FULL_LEGAL_UNIVERSE_ENUMERATION_ALLOWED": False,
        "PRE_PHASE2_RAW_LATTICE_MATERIALIZATION_ALLOWED": False,
        "CHUNK_STREAM_REQUIRED": True,
        "FAIL_CLOSED": True,
        "ROUTE_CERTIFIED": True,
        "ENGINE_ID": str(entry.get("ENGINE_ID") or ""),
    }

RUN_UNTIL_BOARD_PATCH_ID = "APEX_GLOBAL_RUN_UNTIL_BOARD_OR_TRUE_RUN_INVALID_v1"
BOARD_READY_IMMEDIATE_RENDER_PATCH_ID = "APEX_GLOBAL_FAST_PATH_BOARD_READY_IMMEDIATE_RENDER_v1"

def board_ready_terminal_gate(*, legal_board_ready: bool, requested_entry_count: int,
                              final_board_size: int, selector_complete: bool,
                              fast_path: bool = True) -> dict:
    """Hard terminal fence: a complete legal FAST PATH board ends upstream work immediately."""
    ready = bool(legal_board_ready) and bool(selector_complete) and int(final_board_size) >= int(requested_entry_count) > 0
    return {
        "PATCH_ID": BOARD_READY_IMMEDIATE_RENDER_PATCH_ID,
        "BOARD_READY_TERMINAL": ready,
        "STOP_RESEARCH": bool(ready and fast_path),
        "STOP_DIAGNOSTICS": bool(ready and fast_path),
        "STOP_PATCH_INVESTIGATION": bool(ready and fast_path),
        "RENDER_BOARD_IMMEDIATELY": bool(ready),
        "RENDER_VERTICAL": bool(ready),
        "FILE_LINK_SECONDARY_ONLY": bool(ready),
        "NEXT_ACTION": "RENDER_BOARD_THEN_EXECUTION_COMPLETE" if ready else "CONTINUE_EXECUTION",
    }
TRUE_RUN_INVALID_FAILURE_PREFIXES = (
    "PLAYER_POOL_MISSING", "PLAYER_POOL_INVALID", "INVALID_PLAYER_POOL",
    "ENGINE_SOURCE_MISSING", "ENGINE_SOURCE_UNAVAILABLE", "PRODUCTION_COMMAND_MISSING",
    "BUNDLE_HASH_MISMATCH", "ENCODED_BUNDLE_HASH_MISMATCH", "INTERNAL_BUNDLE_MANIFEST_HASH_MISMATCH",
    "MANIFEST_HASH_MISMATCH", "NO_LEGAL_UNIVERSE", "LEGAL_UNIVERSE_EMPTY",
    "SIMULATION_CAPABILITY_UNAVAILABLE", "VALID_SIMULATION_CAPABILITY_UNAVAILABLE",
    "REQUIRED_DEPENDENCY_MISSING", "EXECUTABLE_ENGINE_UNAVAILABLE",
)

def terminal_disposition(*, run_state: str = "", failure_code: str = "", child_return_code=None) -> dict:
    """Classify only proven impossibility as terminal.

    Nonzero process exits, missing board artifacts, throttles, time-window exits,
    transient connector/runtime errors, and recoverable data gaps are retry signals.
    """
    state = str(run_state or "").strip().upper()
    failure = str(failure_code or "").strip().upper()
    true_invalid = state == "RUN_INVALID" and any(failure.startswith(x) for x in TRUE_RUN_INVALID_FAILURE_PREFIXES)
    return {
        "PATCH_ID": RUN_UNTIL_BOARD_PATCH_ID,
        "DISPOSITION": "TRUE_RUN_INVALID" if true_invalid else "RECOVERABLE_RETRY",
        "RUN_STATE": state,
        "FAILURE_CODE": failure,
        "CHILD_RETURN_CODE": child_return_code,
        "NONZERO_RETURN_CODE_IS_TERMINAL_BY_ITSELF": False,
        "MISSING_BOARD_IS_TERMINAL_BY_ITSELF": False,
    }

def _norm(text: str) -> str:
    return " ".join(str(text or "").upper().replace("_", " ").replace("-", " ").split())

def is_fast_path(command_text: str) -> bool:
    t = _norm(command_text)
    return "FAST PATH" in t or "FASTPATH" in t

def show_run_metrics_requested(command_text: str) -> bool:
    t = _norm(command_text)
    return "SHOW RUN METRICS" in t or "SHOW METRICS AND STATS" in t

class FastPathLaunchGate:
    def __init__(self, non_execution_actions: int = 0, process_launched: bool = False, process_id: int | None = None):
        self.non_execution_actions = int(non_execution_actions)
        self.process_launched = bool(process_launched)
        self.process_id = process_id

    def record_non_execution_action(self, label: str) -> dict:
        if self.process_launched:
            return self.receipt()
        self.non_execution_actions += 1
        if self.non_execution_actions > MAX_NON_EXECUTION_ACTIONS_BEFORE_LAUNCH:
            raise FastPathContractError(
                f"FAST_PATH_STALL_FAILURE:NON_EXECUTION_ACTION_BUDGET_EXCEEDED:"
                f"{self.non_execution_actions}:{label}"
            )
        return self.receipt()

    def mark_process_launched(self, pid: int | None = None) -> dict:
        self.process_launched = True
        self.process_id = None if pid is None else int(pid)
        return self.receipt()

    def receipt(self) -> dict:
        return {
            "PATCH_ID": PATCH_ID,
            "MAX_NON_EXECUTION_ACTIONS_BEFORE_LAUNCH": MAX_NON_EXECUTION_ACTIONS_BEFORE_LAUNCH,
            "NON_EXECUTION_ACTIONS": int(self.non_execution_actions),
            "PROCESS_LAUNCHED": bool(self.process_launched),
            "PROCESS_ID": self.process_id,
        }

def validate_execution_state_claim(claim: str, evidence: Mapping[str, object]) -> dict:
    c = str(claim or "").upper()
    e = dict(evidence or {})
    live = bool(e.get("PROCESS_LAUNCHED")) and bool(e.get("PROCESS_ACTIVE"))
    exited = e.get("ENGINE_RETURN_CODE") is not None and bool(e.get("ENGINE_EXIT_RECEIPT"))
    tool = bool(e.get("ACTUAL_TOOL_PROCESS"))
    if c in {"RUNNING", "ACTIVE", "CONTINUING"} and not live:
        raise FastPathContractError(f"FALSE_RUNNING_STATUS_BLOCKED:{c}")
    if c in {"EXECUTED", "EXECUTION_COMPLETE"} and not exited:
        raise FastPathContractError(f"FALSE_EXECUTED_STATUS_BLOCKED:{c}")
    if c == "TOOL_PROVEN_EXECUTED" and not (exited and tool):
        raise FastPathContractError("FALSE_TOOL_PROVEN_EXECUTED_BLOCKED")
    return {"PATCH_ID": PATCH_ID, "EXECUTION_STATE_CLAIM": c, "CLAIM_VALIDATED": True}

def require_metrics_receipt(receipt: Mapping[str, object]) -> dict:
    missing = [k for k in REQUIRED_METRIC_KEYS if k not in receipt]
    if missing:
        raise FastPathContractError("RUN_METRICS_MISSING:" + ",".join(missing))
    return {"PATCH_ID": PATCH_ID, "RUN_METRICS_PARITY": "PASS", "FIELDS": list(REQUIRED_METRIC_KEYS)}

def terminal_board_parity(*, board_lineup_ids: Sequence[str], final_board_size: int,
                          selected_lineup_ids: Sequence[str], board_run_artifact_id: str,
                          ledger_run_artifact_id: str) -> dict:
    board = [str(x) for x in board_lineup_ids]
    selected = [str(x) for x in selected_lineup_ids]
    if int(final_board_size) != len(board):
        raise FastPathContractError(f"FINAL_BOARD_SIZE_MISMATCH:{final_board_size}:{len(board)}")
    if len(selected) != int(final_board_size):
        raise FastPathContractError(f"TERMINAL_SELECTOR_SELECTED_COUNT_MISMATCH:{len(selected)}:{final_board_size}")
    if board != selected:
        raise FastPathContractError("TERMINAL_SELECTOR_BOARD_LINEUP_ID_MISMATCH")
    if not board_run_artifact_id or board_run_artifact_id != ledger_run_artifact_id:
        raise FastPathContractError("SAME_RUN_ARTIFACT_ID_MISMATCH")
    return {
        "PATCH_ID": PATCH_ID,
        "TERMINAL_ARTIFACT_RECONCILIATION": "PASS",
        "FINAL_BOARD_SIZE": int(final_board_size),
        "SELECTED_LEDGER_ROWS": len(selected),
        "RUN_ARTIFACT_ID": str(board_run_artifact_id),
    }

def deterministic_run_artifact_id(*parts: object) -> str:
    payload = json.dumps([str(x) for x in parts], separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()

def assert_current_pool_authority(*, current_message_pool: str | Path, selected_pool: str | Path) -> dict:
    a = Path(current_message_pool).resolve()
    b = Path(selected_pool).resolve()
    if a != b:
        raise FastPathContractError(f"CURRENT_MESSAGE_POOL_AUTHORITY_VIOLATION:{a}:{b}")
    return {"PATCH_ID": PATCH_ID, "CURRENT_MESSAGE_POOL_AUTHORITY": "PASS", "POOL": str(a)}

def interruption_receipt(*, process_launched: bool, process_active: bool, engine_return_code=None) -> dict:
    if process_active and not process_launched:
        raise FastPathContractError("INTERRUPTION_STATE_INCONSISTENT")
    return {
        "PATCH_ID": PATCH_ID,
        "INTERRUPTION_PRIORITY": "PREEMPT_NONESSENTIAL_WORK",
        "PROCESS_LAUNCHED": bool(process_launched),
        "PROCESS_ACTIVE": bool(process_active),
        "ENGINE_RETURN_CODE": engine_return_code,
        "ASSUMED_PROGRESS_ALLOWED": False,
    }
