from __future__ import annotations
import hashlib, json, os, uuid

PATCH_ID = "APEX_GLOBAL_MACHINE_PROVEN_EXECUTION_REPORTING_GUARD_v1"
REPORTABLE_PHASE_PREFIXES = ("PHASE1_","PHASE2_","PHASE3_","MC_","SIM_","SELECTOR_","BOARD_")
REPORTABLE_RUN_STATES = {"RUNNING","ENGINE_INTERNAL_AUTO_CONTINUE","BOARD_READY","TOOL_PROVEN_EXECUTED","FINAL_BOARD_PRESENTED_PENDING_POSTBOARD_VALIDATION"}

class ExecutionReportingGuardError(RuntimeError):
    pass

def new_run_provenance(execution_id: str) -> dict:
    return {
        "PATCH_ID": PATCH_ID,
        "MACHINE_EVENT_SOURCE": "ENGINE_SUBPROCESS",
        "MACHINE_EVENT_RUN_NONCE": uuid.uuid4().hex,
        "MACHINE_EVENT_PID": os.getpid(),
        "EXECUTION_ID": str(execution_id),
    }

def _hash_payload(payload: dict) -> str:
    body={k:v for k,v in payload.items() if k != "MACHINE_EVENT_RECEIPT_SHA256"}
    return hashlib.sha256(json.dumps(body,sort_keys=True,separators=(",",":"),default=str).encode()).hexdigest()

def stamp(payload: dict, provenance: dict) -> dict:
    out=dict(payload or {})
    out.update({
        "EXECUTION_REPORTING_GUARD": PATCH_ID,
        "MACHINE_EVENT_PROVENANCE": "PASS",
        "MACHINE_EVENT_SOURCE": provenance["MACHINE_EVENT_SOURCE"],
        "MACHINE_EVENT_RUN_NONCE": provenance["MACHINE_EVENT_RUN_NONCE"],
        "MACHINE_EVENT_PID": int(provenance["MACHINE_EVENT_PID"]),
    })
    out["MACHINE_EVENT_RECEIPT_SHA256"]=_hash_payload(out)
    return out

def validate(payload: dict, *, require_reportable: bool=True) -> dict:
    p=dict(payload or {})
    run_state=str(p.get("RUN_STATE","")).upper()
    phase=str(p.get("CURRENT_PHASE","")).upper()
    is_reportable=(run_state in REPORTABLE_RUN_STATES) or phase.startswith(REPORTABLE_PHASE_PREFIXES)
    if require_reportable and not is_reportable:
        return {"PATCH_ID":PATCH_ID,"STATUS":"NOT_REPORTABLE"}
    if p.get("MACHINE_EVENT_PROVENANCE") != "PASS" or p.get("MACHINE_EVENT_SOURCE") != "ENGINE_SUBPROCESS":
        raise ExecutionReportingGuardError("UNPROVEN_EXECUTION_STATUS_BLOCKED")
    if not str(p.get("MACHINE_EVENT_RUN_NONCE","")).strip():
        raise ExecutionReportingGuardError("MACHINE_RUN_NONCE_MISSING")
    try:
        if int(p.get("MACHINE_EVENT_PID",0)) <= 0:
            raise ValueError
    except Exception:
        raise ExecutionReportingGuardError("MACHINE_EVENT_PID_INVALID")
    got=str(p.get("MACHINE_EVENT_RECEIPT_SHA256","")).strip()
    expected=_hash_payload(p)
    if not got or got != expected:
        raise ExecutionReportingGuardError("MACHINE_EVENT_RECEIPT_HASH_MISMATCH")
    return {"PATCH_ID":PATCH_ID,"STATUS":"PASS","MACHINE_EVENT_RECEIPT_SHA256":got}

def reject_chat_synthesized_status(payload: dict) -> dict:
    p=dict(payload or {})
    phase=str(p.get("CURRENT_PHASE","")).upper()
    run_state=str(p.get("RUN_STATE","")).upper()
    if phase.startswith(REPORTABLE_PHASE_PREFIXES) or run_state in REPORTABLE_RUN_STATES:
        return validate(p)
    return {"PATCH_ID":PATCH_ID,"STATUS":"NOT_REPORTABLE"}
