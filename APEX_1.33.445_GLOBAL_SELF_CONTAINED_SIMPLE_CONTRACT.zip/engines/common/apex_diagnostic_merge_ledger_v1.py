from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence

PATCH_ID = "APEX_GLOBAL_DIAGNOSTIC_IMMUTABLE_QUEUE_AND_FAST_PROMOTION_v1"
TERMINAL_STATUSES = {"ACTIVE", "MERGED", "SUPERSEDED", "REJECTED"}
VALIDATED_STATUSES = {"VALIDATED", "QUEUED", "MERGE_READY"}

class DiagnosticLedgerError(RuntimeError):
    pass


def _canonical_json(obj: Mapping) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def build_patch_id(*, sport: str, mode: str, slate_id: str, base_state_version: str,
                   changed_components: Sequence[str], patch_payload: Mapping) -> str:
    payload = {
        "SPORT": str(sport).upper(),
        "MODE": str(mode).upper(),
        "SLATE_ID": str(slate_id),
        "BASE_STATE_VERSION": str(base_state_version),
        "CHANGED_COMPONENTS": sorted(set(map(str, changed_components))),
        "PATCH_PAYLOAD": patch_payload,
    }
    digest = sha256_bytes(_canonical_json(payload))[:20]
    return f"DIAG_{payload['SPORT']}_{payload['MODE']}_{payload['SLATE_ID']}_{digest}"


def build_receipt(*, patch_id: str, base_state_version: str, sport: str, mode: str,
                  slate_id: str, changed_components: Sequence[str], patch_hash: str,
                  status: str = "VALIDATED", dependencies: Sequence[str] = (),
                  conflict_keys: Sequence[str] = (), supersedes: Sequence[str] = ()) -> dict:
    status = str(status).upper()
    receipt = {
        "SCHEMA": PATCH_ID,
        "PATCH_ID": str(patch_id),
        "BASE_STATE_VERSION": str(base_state_version),
        "SPORT": str(sport).upper(),
        "MODE": str(mode).upper(),
        "SLATE_ID": str(slate_id),
        "CHANGED_COMPONENTS": sorted(set(map(str, changed_components))),
        "PATCH_HASH": str(patch_hash),
        "DEPENDENCIES": sorted(set(map(str, dependencies))),
        "CONFLICT_KEYS": sorted(set(map(str, conflict_keys))),
        "SUPERSEDES": sorted(set(map(str, supersedes))),
        "STATUS": status,
    }
    receipt["RECEIPT_SHA256"] = sha256_bytes(_canonical_json(receipt))
    return receipt


def persist_immutable_receipt(queue_dir: str | Path, receipt: Mapping) -> Path:
    root = Path(queue_dir)
    root.mkdir(parents=True, exist_ok=True)
    patch_id = str(receipt.get("PATCH_ID") or "")
    receipt_hash = str(receipt.get("RECEIPT_SHA256") or "")
    if not patch_id or not receipt_hash:
        raise DiagnosticLedgerError("INVALID_DIAGNOSTIC_RECEIPT")
    path = root / f"{patch_id}.{receipt_hash[:16]}.json"
    data = json.dumps(dict(receipt), sort_keys=True, indent=2).encode("utf-8") + bytes((10,))
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    try:
        fd = os.open(path, flags, 0o644)
    except FileExistsError:
        if path.read_bytes() != data:
            raise DiagnosticLedgerError(f"IMMUTABLE_RECEIPT_COLLISION:{path.name}")
        return path
    with os.fdopen(fd, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    return path


def load_receipts(queue_dir: str | Path) -> list[dict]:
    root = Path(queue_dir)
    if not root.exists():
        return []
    out = []
    for p in sorted(root.glob("*.json")):
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))
        except Exception as exc:
            raise DiagnosticLedgerError(f"INVALID_QUEUE_RECEIPT:{p.name}:{exc}") from exc
        expected = obj.get("RECEIPT_SHA256")
        check = dict(obj); check.pop("RECEIPT_SHA256", None)
        got = sha256_bytes(_canonical_json(check))
        if expected != got:
            raise DiagnosticLedgerError(f"QUEUE_RECEIPT_HASH_MISMATCH:{p.name}")
        out.append(obj)
    return out


def queue_snapshot(receipts: Iterable[Mapping]) -> dict:
    rows = sorted((str(r.get("PATCH_ID")), str(r.get("RECEIPT_SHA256")), str(r.get("STATUS"))) for r in receipts)
    digest = sha256_bytes(_canonical_json({"ROWS": rows}))
    return {"QUEUE_COUNT": len(rows), "QUEUE_SNAPSHOT_SHA256": digest, "ROWS": rows}


def latest_status_by_patch(receipts: Iterable[Mapping]) -> dict[str, str]:
    # Immutable events may coexist. Status precedence is explicit and deterministic.
    precedence = {"VALIDATED": 10, "QUEUED": 20, "MERGE_READY": 30, "ACTIVE": 40,
                  "MERGED": 40, "SUPERSEDED": 40, "REJECTED": 40}
    latest: dict[str, tuple[int, str]] = {}
    for r in receipts:
        pid = str(r.get("PATCH_ID"))
        status = str(r.get("STATUS") or "").upper()
        score = precedence.get(status, 0)
        if score >= latest.get(pid, (-1, ""))[0]:
            latest[pid] = (score, status)
    return {k: v[1] for k, v in latest.items()}


def build_promotion_set(receipts: Iterable[Mapping], active_patch_ids: Iterable[str]) -> dict:
    rows = list(receipts)
    active = set(map(str, active_patch_ids))
    latest = latest_status_by_patch(rows)
    by_id: dict[str, list[Mapping]] = {}
    for r in rows:
        by_id.setdefault(str(r.get("PATCH_ID")), []).append(r)
    promotion = []
    accounted = set(active)
    terminal = set()
    for pid, status in latest.items():
        if pid in active:
            accounted.add(pid)
            continue
        if status in {"SUPERSEDED", "REJECTED"}:
            terminal.add(pid); accounted.add(pid); continue
        if status in VALIDATED_STATUSES:
            # Use the newest deterministic receipt by hash ordering; receipts are immutable.
            candidate = sorted(by_id[pid], key=lambda r: str(r.get("RECEIPT_SHA256")))[-1]
            promotion.append(candidate); accounted.add(pid)
    unaccounted = sorted(pid for pid in latest if pid not in accounted)
    if unaccounted:
        raise DiagnosticLedgerError("UNACCOUNTED_VALIDATED_PATCHES:" + ",".join(unaccounted))
    return {
        "PROMOTION_PATCH_IDS": sorted(str(r["PATCH_ID"]) for r in promotion),
        "PROMOTION_SET": promotion,
        "ALREADY_ACTIVE": sorted(active.intersection(latest)),
        "TERMINAL_ACCOUNTED": sorted(terminal),
        "UNACCOUNTED": [],
    }


def detect_patch_conflicts(promotion_set: Sequence[Mapping]) -> dict:
    owners: dict[str, list[str]] = {}
    for r in promotion_set:
        pid = str(r.get("PATCH_ID"))
        keys = set(map(str, r.get("CONFLICT_KEYS") or ())) | set(map(str, r.get("CHANGED_COMPONENTS") or ()))
        for key in keys:
            owners.setdefault(key, []).append(pid)
    conflicts = {k: sorted(v) for k, v in owners.items() if len(set(v)) > 1}
    return {"CONFLICT_COUNT": len(conflicts), "CONFLICTS": conflicts,
            "MERGE_STATE": "AUTO_MERGE_SAFE" if not conflicts else "EXPLICIT_RECONCILIATION_REQUIRED"}


def assert_queue_unchanged(before: Mapping, after: Mapping) -> None:
    if str(before.get("QUEUE_SNAPSHOT_SHA256")) != str(after.get("QUEUE_SNAPSHOT_SHA256")):
        raise DiagnosticLedgerError(
            f"DIAGNOSTIC_QUEUE_DRIFT_REBASE_REQUIRED:{before.get('QUEUE_SNAPSHOT_SHA256')}:{after.get('QUEUE_SNAPSHOT_SHA256')}"
        )
