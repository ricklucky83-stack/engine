from __future__ import annotations

"""Global contest-order intelligence framework.

Shared contract, sport x mode adapters.  This module never creates, deletes,
legalizes, simulates, or selects lineups.  It only attaches prelock ordering
signals and returns a deterministic order over an already-frozen surface.

The framework is global; learned coefficients are NOT shared across sports.
Sport/mode adapters may contribute certified structural lanes or native scores.
All comparisons are within one slate.
"""

from dataclasses import dataclass
from typing import Any, Mapping, Sequence
import math
import numpy as np

from engines.common.apex_global_mc_signal_doctrine_v1 import PATCH_ID as MC_SIGNAL_PATCH_ID
from engines.common.apex_global_championship_head_policy_v1 import PATCH_ID as CHAMPIONSHIP_HEAD_PATCH_ID

PATCH_ID = "APEX_GLOBAL_CONTEST_ORDER_INTELLIGENCE_v3"
ARCHITECTURE = "GLOBAL_SHARED_FRAMEWORK_PLUS_SPORT_MODE_ADAPTERS"
MEMBERSHIP_MUTATION_ALLOWED = False
UNIVERSAL_CROSS_SPORT_MODEL_ALLOWED = False
POSTLOCK_FIELDS = frozenset({
    "CONTEST_RANK","ACTUAL_RANK","FINAL_CONTEST_RANK","ACTUAL_FPTS",
    "REALIZED_FPTS","POSTLOCK_SCORE","REALIZED_SCORE","ACTUAL_SCORE",
    "WINNING_LINEUP","TARGET_ACTUAL_SCORE",
})

# Shared statistical channels.  We aggregate percentiles/ranks, not raw values,
# so sport-specific units do not leak into the common layer.
COMMON_WEIGHTS = {
    # Rank-1 remains the most important single seat, but production ordering is
    # explicitly a full ordinal problem: 1,2,3,4,... as close to realized
    # contest order as prelock information allows.
    "MOST_PROBABLE_BEST": 0.24,
    "EXTREME_TAIL": 0.16,
    "ORDINAL_POSTERIOR": 0.24,
    "SPORT_NATIVE": 0.18,
    "CROSS_WORLD": 0.08,
    "STABILITY": 0.06,
    "LOW_DUPLICATION": 0.04,
    "TOP_NEIGHBORHOOD": 0.16,
}

ORDERING_OBJECTIVE = "PREDICT_REALIZED_CONTEST_ORDER_1_2_3_4_ETC_WITH_ELITE_TOP_NEIGHBORHOOD_COHERENCE"
ORDERING_EVALUATION = {
    "PRIMARY": "TOP_WEIGHTED_FULL_ORDINAL_SEQUENCE_ACCURACY",
    "SECONDARY": ["WINNER_ORDER_RANK", "TOP5_REALIZED_RANK_VECTOR", "TOP5_MEDIAN_REALIZED_RANK",
                  "WINNER_REMOVED_HEAD_MEDIAN_5", "WINNER_REMOVED_HEAD_FRAGILE",
                  "TOP5_MAX_REALIZED_RANK", "TOP5_MEAN_LOG_REALIZED_RANK", "TOP5_NEIGHBORHOOD_COHERENCE",
                  "NDCG_AT_5", "NDCG_AT_10", "NDCG_AT_25", "NDCG_AT_100",
                  "SPEARMAN_FULL_BOARD", "KENDALL_FULL_BOARD", "PAIRWISE_ORDER_ACCURACY"],
    "TOP_NEIGHBORHOOD_RULE": "IF_RANK1_IS_ELITE_RANKS_2_TO_5_MUST_MINIMIZE_EXPECTED_REALIZED_RANK_DISTANCE_SUBJECT_TO_PRELOCK_EVIDENCE",
    "TIE_POLICY": "REALIZED_SCORE_TIES_SHARE_CONTEST_RANK; PREDICTIVE_ORDER_USES_STABLE_TIEBREAK_ONLY",
}

class GlobalOrderIntelligenceError(RuntimeError):
    pass


def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")


def _arr(x: Any, n: int, default: float = float("nan")) -> np.ndarray:
    if x is None:
        return np.full(n, default, dtype=np.float64)
    a = np.asarray(x, dtype=np.float64)
    if a.ndim == 0:
        a = np.full(n, float(a), dtype=np.float64)
    if len(a) != n:
        raise GlobalOrderIntelligenceError(f"GLOBAL_ORDER_LENGTH_MISMATCH:{len(a)}:{n}")
    return a


def _pct(a: np.ndarray, *, higher: bool = True) -> np.ndarray:
    a = np.asarray(a, dtype=np.float64)
    n = len(a)
    out = np.full(n, np.nan, dtype=np.float64)
    good = np.flatnonzero(np.isfinite(a))
    if len(good) == 0:
        return out
    vals = a[good]
    order = np.argsort(vals, kind="mergesort")
    ranks = np.empty(len(good), dtype=np.float64)
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and vals[order[j]] == vals[order[i]]:
            j += 1
        avg = ((i + j - 1) / 2.0 + 0.5) / max(1, len(order))
        ranks[order[i:j]] = avg
        i = j
    out[good] = ranks if higher else (1.0 - ranks)
    return out


def _blend(parts: Sequence[tuple[np.ndarray, float]], n: int) -> np.ndarray:
    num = np.zeros(n, dtype=np.float64)
    den = np.zeros(n, dtype=np.float64)
    for a, w in parts:
        good = np.isfinite(a)
        num[good] += a[good] * float(w)
        den[good] += float(w)
    return np.divide(num, den, out=np.full(n, 0.5, dtype=np.float64), where=den > 0)


def validate_prelock_mapping(mapping: Mapping[str, Any]) -> None:
    bad = sorted(k for k in mapping if str(k).upper() in POSTLOCK_FIELDS)
    if bad:
        raise GlobalOrderIntelligenceError("GLOBAL_ORDER_POSTLOCK_LEAKAGE:" + ",".join(bad))


@dataclass(frozen=True)
class OrderResult:
    order: np.ndarray
    order_rank: np.ndarray
    order_score: np.ndarray
    order_confidence: np.ndarray
    rank_uncertainty_width: np.ndarray
    most_probable_best_score: np.ndarray
    extreme_tail_score: np.ndarray
    ordinal_posterior_score: np.ndarray
    sport_native_pctl: np.ndarray
    adapter_priority_tier: np.ndarray
    adapter_priority_rank: np.ndarray
    receipt: dict[str, Any]



def apply_exact_role_head_order(
    base_order: Any,
    exact_role_head_score: Any,
    *,
    family_context_score: Any = None,
    head_rerank_size: int = 15,
) -> tuple[np.ndarray,int]:
    """Apply bounded exact-role common-world head order to a frozen membership.

    Family/context evidence is an exact-score tie-break only. The returned array
    is a permutation of the input membership and therefore cannot add/remove rows.
    """
    order=np.asarray(base_order,dtype=np.int32).reshape(-1)
    n=len(order)
    if n==0:
        return order,0
    if sorted(order.tolist()) != list(range(n)):
        raise GlobalOrderIntelligenceError("GLOBAL_ORDER_BASE_ORDER_NOT_PERMUTATION")
    ex=_arr(exact_role_head_score,n)
    famctx=_arr(family_context_score,n) if family_context_score is not None else np.full(n,np.nan)
    finite=np.flatnonzero(np.isfinite(ex))
    if len(finite)==0:
        return order.copy(),0
    head_size=min(max(1,int(head_rerank_size)),len(finite),n)
    idx=np.arange(n,dtype=np.int64)
    base_pos=np.empty(n,dtype=np.int32); base_pos[order]=np.arange(n,dtype=np.int32)
    fam_tie=np.nan_to_num(_pct(famctx),nan=-1.0)
    exact_order=np.lexsort((idx,base_pos,-fam_tie,-np.nan_to_num(ex,nan=-1.0))).astype(np.int32)
    head=[int(i) for i in exact_order if math.isfinite(float(ex[i]))][:head_size]
    hset=set(head)
    rest=[int(i) for i in order if int(i) not in hset]
    return np.asarray(head+rest,dtype=np.int32),head_size

def rank_surface(
    metrics: Mapping[str, Any], *, sport: str, mode: str,
    sport_native_score: Any = None,
    world_breadth: Any = None,
    rank_stability: Any = None,
    projected_duplication: Any = None,
    expected_rank: Any = None,
    median_rank: Any = None,
    rank_p90: Any = None,
    pairwise_strength: Any = None,
    adapter_priority_tier: Any = None,
    adapter_priority_score: Any = None,
    top_neighborhood_support: Any = None,
    adapter_id: str | None = None,
    adapter_live_authority: bool = False,
    exact_role_head_score: Any = None,
    family_context_score: Any = None,
    exact_role_head_live_authority: bool = False,
    head_rerank_size: int = 15,
) -> OrderResult:
    """Rank a frozen candidate surface using shared statistical machinery.

    Certified adapter lanes may occupy early order positions, but cannot add/remove
    candidates.  All remaining rows are ordered by a common uncertainty-aware
    percentile ensemble.  The same coefficient vector is intentionally NOT learned
    across sports; only the common statistical aggregation is shared.
    """
    validate_prelock_mapping(metrics)
    # determine n from first array-like metric
    n = None
    for v in metrics.values():
        try:
            if np.asarray(v).ndim > 0:
                n = len(np.asarray(v)); break
        except Exception:
            pass
    if n is None or n <= 0:
        raise GlobalOrderIntelligenceError("GLOBAL_ORDER_EMPTY_SURFACE")

    top01 = _arr(metrics.get("top01_lcb", metrics.get("MC_TOP_0_1_LCB", metrics.get("top01_rate", metrics.get("MC_TOP_0_1_RATE")))), n)
    win = _arr(metrics.get("win_lcb", metrics.get("MC_WIN_LCB", metrics.get("win_rate", metrics.get("MC_WIN_RATE")))), n)
    p99 = _arr(metrics.get("p99", metrics.get("MC_P99")), n)
    p95 = _arr(metrics.get("p95", metrics.get("MC_P95")), n)
    # Prefer explicit uncertainty width.  Otherwise use Wilson gap when supplied.
    if metrics.get("rank_uncertainty_width") is not None:
        width = _arr(metrics.get("rank_uncertainty_width"), n)
    elif metrics.get("top01_ucb") is not None and metrics.get("top01_lcb") is not None:
        width = np.maximum(0.0, _arr(metrics.get("top01_ucb"),n) - _arr(metrics.get("top01_lcb"),n))
    else:
        width = np.full(n, np.nan, dtype=np.float64)

    top01p = _pct(top01); winp = _pct(win); p99p = _pct(p99); p95p = _pct(p95)
    mpb = _blend(((top01p,0.65),(winp,0.35)), n)
    tail = _blend(((p99p,0.70),(p95p,0.30)), n)

    # Full-ordinal posterior channels. These are intentionally optional so every
    # sport can enter production under the same contract before it has a learned
    # ordinal adapter. Lower expected/median/P90 rank is better; higher pairwise
    # strength is better.
    er = _arr(expected_rank,n) if expected_rank is not None else np.full(n,np.nan)
    mr = _arr(median_rank,n) if median_rank is not None else np.full(n,np.nan)
    r90 = _arr(rank_p90,n) if rank_p90 is not None else np.full(n,np.nan)
    ps = _arr(pairwise_strength,n) if pairwise_strength is not None else np.full(n,np.nan)
    ordinal = _blend(((_pct(er,higher=False),0.35),(_pct(mr,higher=False),0.25),
                      (_pct(r90,higher=False),0.20),(_pct(ps,higher=True),0.20)),n)
    ordinal_has_evidence = bool(np.any(np.isfinite(er)) or np.any(np.isfinite(mr)) or np.any(np.isfinite(r90)) or np.any(np.isfinite(ps)))
    if not ordinal_has_evidence:
        ordinal[:] = np.nan

    native = _arr(sport_native_score,n) if sport_native_score is not None else np.full(n,np.nan)
    nativep = _pct(native)
    world = _arr(world_breadth,n) if world_breadth is not None else np.full(n,np.nan)
    worldp = _pct(world)
    stability = _arr(rank_stability,n) if rank_stability is not None else np.full(n,np.nan)
    stabilityp = _pct(stability)
    if np.all(~np.isfinite(stabilityp)) and np.any(np.isfinite(width)):
        stabilityp = _pct(width, higher=False)
    dup = _arr(projected_duplication,n) if projected_duplication is not None else np.full(n,np.nan)
    lowdupp = _pct(dup,higher=False)
    topnbr = _arr(top_neighborhood_support,n) if top_neighborhood_support is not None else np.full(n,np.nan)
    topnbrp = _pct(topnbr)

    base = _blend((
        (mpb,COMMON_WEIGHTS["MOST_PROBABLE_BEST"]),
        (tail,COMMON_WEIGHTS["EXTREME_TAIL"]),
        (ordinal,COMMON_WEIGHTS["ORDINAL_POSTERIOR"]),
        (nativep,COMMON_WEIGHTS["SPORT_NATIVE"]),
        (worldp,COMMON_WEIGHTS["CROSS_WORLD"]),
        (stabilityp,COMMON_WEIGHTS["STABILITY"]),
        (lowdupp,COMMON_WEIGHTS["LOW_DUPLICATION"]),
        (topnbrp,COMMON_WEIGHTS["TOP_NEIGHBORHOOD"]),
    ),n)

    # Rank-confidence penalty is intentionally small: uncertainty widens the rank
    # band rather than erasing a strong independent signal.
    channel_stack=np.vstack([mpb,tail,ordinal,nativep,worldp,stabilityp,topnbrp])
    spread=np.nanmax(channel_stack,axis=0)-np.nanmin(channel_stack,axis=0)
    spread=np.nan_to_num(spread,nan=0.0,posinf=1.0,neginf=0.0)
    confidence=np.clip(1.0-spread,0.0,1.0)
    score=np.clip(base - 0.05*spread,0.0,1.0)

    tier = _arr(adapter_priority_tier,n,0.0) if adapter_priority_tier is not None else np.zeros(n)
    apr = _arr(adapter_priority_score,n) if adapter_priority_score is not None else native.copy()
    apr_p=_pct(apr)
    # Certified lanes interleave by tier only when the sport adapter explicitly has
    # live order authority.  Otherwise all adapter evidence remains shadow features.
    live_tier=tier if adapter_live_authority else np.zeros(n)
    idx=np.arange(n,dtype=np.int64)
    # lexsort last key is primary: live tier desc, adapter score desc for tier rows,
    # global score desc, then deterministic index.
    live_adapter_sort=np.where(live_tier>0.0,np.nan_to_num(apr_p,nan=-1.0),-1.0)
    order=np.lexsort((idx,-score,-live_adapter_sort,-live_tier)).astype(np.int32)

    # Global conditional-family ordinal-head contract. Family/core evidence may
    # discover or shrink a neighborhood but may not own terminal rank. Only an
    # explicit sport/mode exact-role common-world score can activate this head.
    head_active=False
    head_size=0
    if exact_role_head_live_authority:
        if exact_role_head_score is None:
            raise GlobalOrderIntelligenceError("GLOBAL_ORDER_EXACT_ROLE_HEAD_SCORE_REQUIRED")
        ex=_arr(exact_role_head_score,n)
        famctx=_arr(family_context_score,n) if family_context_score is not None else np.full(n,np.nan)
        if np.any(np.isfinite(ex)):
            order,head_size=apply_exact_role_head_order(
                order,ex,family_context_score=famctx,head_rerank_size=head_rerank_size
            )
            head_active=bool(head_size>0)
    rank=np.empty(n,dtype=np.int32); rank[order]=np.arange(1,n+1,dtype=np.int32)

    receipt={
        "PATCH_ID":PATCH_ID,
        "ARCHITECTURE":ARCHITECTURE,
        "SPORT":_norm(sport),"MODE":_norm(mode),
        "MEMBERSHIP_MUTATION_ALLOWED":False,
        "UNIVERSAL_CROSS_SPORT_MODEL_ALLOWED":False,
        "SHARED_STATISTICAL_AGGREGATION":True,
        "SPORT_MODE_ADAPTER_REQUIRED":True,
        "ADAPTER_ID":str(adapter_id or f"{_norm(sport)}__{_norm(mode)}__DEFAULT_SHADOW"),
        "ADAPTER_LIVE_ORDER_AUTHORITY":bool(adapter_live_authority),
        "CANDIDATE_COUNT":int(n),
        "POSTLOCK_INPUT_USED":False,
        "ORDERING_OBJECTIVE":ORDERING_OBJECTIVE,
        "ORDERING_EVALUATION":dict(ORDERING_EVALUATION),
        "COMMON_WEIGHTS":dict(COMMON_WEIGHTS),
        "ORDINAL_POSTERIOR_CHANNEL_ACTIVE":ordinal_has_evidence,
        "RANK_UNCERTAINTY_OUTPUT":True,
        "MOST_PROBABLE_BEST_CHANNEL":True,
        "CROSS_WORLD_CONSENSUS_CHANNEL":True,
        "TOP_NEIGHBORHOOD_CHANNEL_ACTIVE":bool(np.any(np.isfinite(topnbr))),
        "TOP_NEIGHBORHOOD_RULE":ORDERING_EVALUATION["TOP_NEIGHBORHOOD_RULE"],
        "FAMILY_CONTEXT_TERMINAL_AUTHORITY":False,
        "EXACT_ROLE_COMMON_WORLD_HEAD_CHANNEL_ACTIVE":bool(head_active),
        "EXACT_ROLE_COMMON_WORLD_HEAD_LIVE_AUTHORITY":bool(exact_role_head_live_authority and head_active),
        "HEAD_RERANK_SIZE":int(head_size),
        "UNSUPPORTED_HEAD_ADAPTER_BEHAVIOR":"NO_OP",
        "PORTFOLIO_DIVERSIFICATION_ROLE":"DOWNSTREAM_SEAT_6_PLUS_ONLY",
        "MC_SIGNAL_POLICY_ID":MC_SIGNAL_PATCH_ID,
        "MC_METRICS_ROLE":"SIGNAL_NOT_TRUTH",
        "RAW_MC_LITERAL_AUTHORITY":False,
        "CHAMPIONSHIP_HEAD_POLICY_ID":CHAMPIONSHIP_HEAD_PATCH_ID,
        "TOP5_IS_CHAMPIONSHIP_NEIGHBORHOOD":True,
        "WINNER_CAPTURE_ALONE_SUFFICIENT":False,
        "DIVERSIFICATION_ALLOWED_INSIDE_TOP5":False,
        "DIVERSIFICATION_START_SEAT":6,
    }
    return OrderResult(order,rank,score,confidence,spread,mpb,tail,ordinal,nativep,tier.astype(np.int32),apr_p,receipt)


def attach_order_fields(rows: Sequence[Mapping[str,Any]], result: OrderResult) -> list[dict[str,Any]]:
    if len(rows) != len(result.order_rank):
        raise GlobalOrderIntelligenceError("GLOBAL_ORDER_ATTACH_LENGTH_MISMATCH")
    out=[]
    for i,row in enumerate(rows):
        r=dict(row)
        r["GLOBAL_ORDER_SCORE"]=float(result.order_score[i])
        r["GLOBAL_ORDER_RANK"]=int(result.order_rank[i])
        r["GLOBAL_ORDER_CONFIDENCE"]=float(result.order_confidence[i])
        r["GLOBAL_ORDER_UNCERTAINTY_WIDTH"]=float(result.rank_uncertainty_width[i])
        r["GLOBAL_MOST_PROBABLE_BEST_SCORE"]=float(result.most_probable_best_score[i])
        r["GLOBAL_EXTREME_TAIL_SCORE"]=float(result.extreme_tail_score[i])
        r["GLOBAL_ORDINAL_POSTERIOR_SCORE"]=float(result.ordinal_posterior_score[i]) if math.isfinite(float(result.ordinal_posterior_score[i])) else ""
        r["GLOBAL_SPORT_NATIVE_PCTL"]=float(result.sport_native_pctl[i]) if math.isfinite(float(result.sport_native_pctl[i])) else ""
        r["GLOBAL_ADAPTER_PRIORITY_TIER"]=int(result.adapter_priority_tier[i])
        out.append(r)
    return out


def derive_root_neighborhood_support(
    lineups: Any, root_indices: Any, *, role_sensitive_prefix: int = 0, max_depth: int = 2
) -> np.ndarray:
    """Return prelock structural proximity to certified adapter roots.

    This is a shared framework primitive, not a sport-specific coefficient model.
    A sport adapter decides which roots are certified.  The global layer only
    measures local lineup distance after membership is frozen.  Exact roots score
    1.0; one-mutation neighbors score 0.85; two-mutation neighbors score 0.65.
    Role-sensitive prefix slots (for example CPT) must match for full support.
    """
    x=np.asarray(lineups)
    if x.ndim != 2 or len(x)==0:
        return np.empty(0,dtype=np.float64)
    roots=np.asarray(root_indices,dtype=np.int64).reshape(-1)
    roots=roots[(roots>=0)&(roots<len(x))]
    out=np.zeros(len(x),dtype=np.float64)
    if len(roots)==0:
        return out
    rp=max(0,min(int(role_sensitive_prefix),x.shape[1]))
    root_rows=x[roots]
    for i,row in enumerate(x):
        best=0.0
        row_set=set(map(int,row.tolist()))
        for rr in root_rows:
            if rp and not np.array_equal(row[:rp],rr[:rp]):
                continue
            shared=len(row_set.intersection(set(map(int,rr.tolist()))))
            depth=max(0,x.shape[1]-shared)
            if depth==0: val=1.0
            elif depth==1: val=0.85
            elif depth<=max_depth: val=0.65
            else: val=0.0
            if val>best: best=val
        out[i]=best
    return out

def grade_ordinal_sequence(predicted_order: Any, realized_ranks: Any, *, top_k: int = 5) -> dict[str,Any]:
    """Diagnostic-only ordinal grading. Never call from live selection with truth.

    Lower realized ranks are better.  This explicitly detects the isolated-winner
    failure mode where predicted #1 is excellent but #2-#5 are far down-table.
    """
    order=np.asarray(predicted_order,dtype=np.int64).reshape(-1)
    truth=np.asarray(realized_ranks,dtype=np.float64).reshape(-1)
    if len(order)==0 or len(truth)==0 or np.any(order<0) or np.any(order>=len(truth)):
        raise GlobalOrderIntelligenceError("GLOBAL_ORDER_GRADE_INVALID_INPUT")
    k=min(max(1,int(top_k)),len(order))
    v=truth[order[:k]]
    good=np.isfinite(v)&(v>0)
    vg=v[good]
    if len(vg)==0:
        med=mx=mean_log=float("nan")
        coherence=0.0
    else:
        med=float(np.median(vg)); mx=float(np.max(vg)); mean_log=float(np.mean(np.log1p(vg)))
        # 1.0 is ideal.  The score decays smoothly as the predicted elite block
        # drifts away from the top of the realized leaderboard.
        coherence=float(np.mean(1.0/np.log2(vg+1.0)))
    finite_truth=np.flatnonzero(np.isfinite(truth)&(truth>0))
    winner_idx=int(finite_truth[np.argmin(truth[finite_truth])]) if len(finite_truth) else -1
    without=[int(i) for i in order if int(i)!=winner_idx][:k]
    wr=truth[np.asarray(without,dtype=np.int64)] if without else np.empty(0,dtype=np.float64)
    wrg=wr[np.isfinite(wr)&(wr>0)]
    wrmed=float(np.median(wrg)) if len(wrg) else float("nan")
    return {
        "TOP_K":k,
        "REALIZED_RANK_VECTOR":[float(x) if math.isfinite(float(x)) else None for x in v],
        "MEDIAN_REALIZED_RANK":med,
        "MAX_REALIZED_RANK":mx,
        "MEAN_LOG_REALIZED_RANK":mean_log,
        "TOP_NEIGHBORHOOD_COHERENCE":coherence,
        "ISOLATED_WINNER_FAILURE":bool(len(vg)>=2 and np.min(vg)<=5 and np.median(vg)>100),
        "WINNER_REMOVED_REALIZED_RANK_VECTOR":[float(x) if math.isfinite(float(x)) else None for x in wr],
        "WINNER_REMOVED_HEAD_MEDIAN_5":wrmed,
        "WINNER_REMOVED_HEAD_FRAGILE":bool(math.isfinite(wrmed) and wrmed>100.0),
    }

def contract() -> dict[str,Any]:
    return {
        "PATCH_ID":PATCH_ID,
        "ARCHITECTURE":ARCHITECTURE,
        "SCOPE":"ALL_SUPPORTED_SPORTS_AND_MODES",
        "ORDERING_OBJECTIVE":ORDERING_OBJECTIVE,
        "ORDERING_EVALUATION":dict(ORDERING_EVALUATION),
        "MEMBERSHIP_MUTATION_ALLOWED":False,
        "UNIVERSAL_CROSS_SPORT_MODEL_ALLOWED":False,
        "SPORT_MODE_ADAPTER_REQUIRED":True,
        "ORDER_OUTPUTS":["GLOBAL_ORDER_SCORE","GLOBAL_ORDER_RANK","GLOBAL_ORDER_CONFIDENCE","GLOBAL_ORDER_UNCERTAINTY_WIDTH","GLOBAL_ORDINAL_POSTERIOR_SCORE"],
        "DIAGNOSTIC_OUTPUTS":["WINNER_GLOBAL_ORDER_RANK","TOP5_REALIZED_RANK_VECTOR","TOP5_MEDIAN_REALIZED_RANK","WINNER_REMOVED_HEAD_MEDIAN_5","WINNER_REMOVED_HEAD_FRAGILE","TOP5_MAX_REALIZED_RANK","TOP5_MEAN_LOG_REALIZED_RANK","TOP5_NEIGHBORHOOD_COHERENCE","TOP5_TOP01_CAPTURE","NDCG_AT_5","NDCG_AT_10","NDCG_AT_25","NDCG_AT_100","SPEARMAN_FULL_BOARD","KENDALL_FULL_BOARD","PAIRWISE_ORDER_ACCURACY","RANK_STABILITY"],
        "PORTFOLIO_DIVERSIFICATION_ROLE":"DOWNSTREAM_ONLY_AFTER_LINEUP_ORDER_INTELLIGENCE",
        "HISTORICAL_OUTCOMES_FORWARD_INPUT":False,
        "FAMILY_CONTEXT_TERMINAL_AUTHORITY":False,
        "EXACT_ROLE_COMMON_WORLD_HEAD_AUTHORITY":"SPORT_MODE_ADAPTER_GATED",
        "WINNER_REMOVED_HEAD_ROBUSTNESS_REQUIRED":True,
    }
