from __future__ import annotations
import numpy as np

PATCH_ID = "APEX_GLOBAL_EXPLICIT_TT_CORRELATED_MC_PAYLOAD_v1"

def _num(v, default=0.0):
    try:
        x=float(v)
        return x if np.isfinite(x) else float(default)
    except Exception:
        return float(default)

def first_numeric(row, aliases, default):
    for k in aliases:
        try:
            if k in row.index:
                v=_num(row.get(k), np.nan)
                if np.isfinite(v): return float(v)
        except Exception:
            pass
    return float(default)

def environment_from_pool(pool):
    park=first_numeric(pool.iloc[0], ("Park Factor","PARK_FACTOR","ParkFactor","PF"), 1.0)
    if park > 3.0: park /= 100.0
    weather=first_numeric(pool.iloc[0], ("Weather Run Modifier","WEATHER_RUN_MODIFIER","WeatherFactor","WEATHER_FACTOR"), 1.0)
    if weather > 3.0: weather /= 100.0
    pace=first_numeric(pool.iloc[0], ("Pace Modifier","PACE_MODIFIER","Projected Pace Modifier"), 1.0)
    if pace > 3.0: pace /= 100.0
    return {
        "projected_pace_modifier": float(np.clip(pace,.75,1.30)),
        "weather_run_modifier": float(np.clip(weather,.70,1.30)),
        "stadium_park_factor": float(np.clip(park,.70,1.35)),
    }

def correlation_matrix(players):
    n=len(players)
    C=np.eye(n,dtype=float)
    explicit={}
    for i,a in enumerate(players):
        for j in range(i+1,n):
            b=players[j]; rho=0.0
            if a["team"]==b["team"]:
                if (not a["is_sp"] and not a["is_rp"] and not b["is_sp"] and not b["is_rp"]):
                    gap=abs(int(a.get("order",9))-int(b.get("order",9)))
                    rho=0.18 if gap==1 else (0.12 if gap==2 else 0.08)
                elif a["is_sp"] or b["is_sp"]:
                    rho=0.10
                else:
                    rho=0.06
            else:
                # Opposing hitters share game environment mildly; hitters vs SP are negative.
                hitter_a=not a["is_sp"] and not a["is_rp"]
                hitter_b=not b["is_sp"] and not b["is_rp"]
                if (a["is_sp"] and hitter_b) or (b["is_sp"] and hitter_a):
                    rho=-0.18
                elif hitter_a and hitter_b:
                    rho=0.05
                else:
                    rho=-0.03
            C[i,j]=C[j,i]=rho
            if abs(rho)>=0.10:
                explicit[f"{a['name']}|{b['name']}"]=float(rho)
    # nearest PSD correlation matrix
    vals, vecs=np.linalg.eigh(C)
    vals=np.clip(vals,1e-6,None)
    C=(vecs*vals)@vecs.T
    d=np.sqrt(np.diag(C)); C=C/(d[:,None]*d[None,:])
    np.fill_diagonal(C,1.0)
    return C, explicit

def team_total_paths(players, trials, rng, env):
    teams=sorted({p["team"] for p in players})
    game_lat=rng.standard_normal(trials)
    out={}; receipt={}
    for t in teams:
        ps=[p for p in players if p["team"]==t]
        market=float(np.median([p.get("team_runs",4.0) for p in ps]))
        target=max(.25, market*env["stadium_park_factor"]*env["weather_run_modifier"]*env["projected_pace_modifier"])
        team_lat=rng.standard_normal(trials)
        shape=4.5
        lam=rng.gamma(shape, target/shape, trials)
        mult=np.exp(.10*game_lat+.16*team_lat-.5*(.10**2+.16**2))
        lam=np.clip(lam*mult,.02,20.0)
        runs=rng.poisson(lam).astype(np.float32)
        out[t]=runs
        mean=float(runs.mean())
        receipt[t]={
            "MARKET_IMPLIED_TT":market,
            "ENVIRONMENT_ADJUSTED_TT":target,
            "SIM_TT_MEAN":mean,
            "SIM_TT_DRIFT":mean-target,
            "SIM_TT_DRIFT_PCT":(mean-target)/target if target else 0.0,
        }
    return out, receipt
