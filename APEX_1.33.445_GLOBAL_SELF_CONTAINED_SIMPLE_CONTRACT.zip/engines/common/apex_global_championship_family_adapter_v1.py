from __future__ import annotations

"""Pre-lock sport-native family/authority adapter for the global Core-5 layer.

This module translates already-produced sport selector metadata into a small shared
contract.  It never reads contest outcomes and contains no player/team identities.
"""
from dataclasses import dataclass
from typing import Any
import math

PATCH_ID = "APEX_GLOBAL_CHAMPIONSHIP_FAMILY_ADAPTER_v1"


def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace("-", "_").replace(" ", "_")


def _num(x: Any, default: float = float("nan")) -> float:
    try:
        y = float(x)
        return y if math.isfinite(y) else default
    except Exception:
        return default


def _truthy(x: Any) -> bool:
    if isinstance(x, bool): return x
    return _norm(x) in {"1", "TRUE", "YES", "Y", "PASS", "PROTECTED"}


@dataclass(frozen=True)
class FamilyDescriptor:
    family_id: str | None = None
    scenario_id: str | None = None
    protected: bool = False
    protection_priority: int = 0
    protection_family_cap: int = 1
    reason: str = "NONE"


def describe(row: dict[str, Any], *, sport: str, mode: str) -> FamilyDescriptor:
    s, m = _norm(sport), _norm(mode)

    # Preferred standardized engine-owned contract.
    explicit_family = row.get("GLOBAL_CORE_FAMILY_ID") or row.get("CHAMPIONSHIP_FAMILY_ID")
    explicit_scenario = row.get("GLOBAL_CORE_SCENARIO_ID") or row.get("CHAMPIONSHIP_SCENARIO_ID")
    explicit_protected = row.get("GLOBAL_CORE_PROTECTED")
    if explicit_protected is not None and _truthy(explicit_protected):
        return FamilyDescriptor(
            family_id=str(explicit_family or "EXPLICIT_PROTECTED"),
            scenario_id=str(explicit_scenario or explicit_family or "EXPLICIT_PROTECTED"),
            protected=True,
            protection_priority=int(_num(row.get("GLOBAL_CORE_PRIORITY"), 100)),
            protection_family_cap=max(1, min(3, int(_num(row.get("GLOBAL_CORE_FAMILY_CAP"), 1)))),
            reason="ENGINE_EXPLICIT_CHAMPIONSHIP_AUTHORITY",
        )

    # Generic sport selector sentinels are pre-lock structural authorities.
    lane = _norm(row.get("SELECTION_LANE") or row.get("SELECTOR_REASON") or row.get("REASON") or "")
    scenario_rank = _num(row.get("SCENARIO_RANK"))
    if "SENTINEL" in lane and (not math.isfinite(scenario_rank) or scenario_rank <= 1.0):
        return FamilyDescriptor(
            family_id=lane or "SENTINEL",
            scenario_id=lane or "SENTINEL",
            protected=True,
            protection_priority=90,
            protection_family_cap=1,
            reason="SPORT_NATIVE_SENTINEL",
        )

    # MLB Showdown's active dual-RP scenario doctrine deliberately keeps a bunch
    # of highly correlated low-median tail tickets.  Historical compatibility is
    # derived only from pre-lock structural counts, never winner identity/results.
    if s == "MLB" and m in {"SHOWDOWN", "SD", "CAPTAIN", "CPT"}:
        rp = _num(row.get("RP_COUNT"))
        if math.isfinite(rp) and rp >= 2:
            branch = _norm(row.get("BRANCH") or "UNK")
            sp = int(_num(row.get("SP_COUNT"), 0))
            fid = f"MLB_SD_DUAL_RP|{branch}|SP{sp}"
            return FamilyDescriptor(
                family_id=fid,
                scenario_id="MLB_SD_DUAL_RP_EXTREME_TAIL",
                protected=True,
                protection_priority=80,
                protection_family_cap=3,
                reason="MLB_SD_ELITE_DUAL_RP_SCENARIO_COMPAT",
            )

    if explicit_family or explicit_scenario:
        return FamilyDescriptor(
            family_id=str(explicit_family) if explicit_family else None,
            scenario_id=str(explicit_scenario) if explicit_scenario else None,
            reason="ENGINE_EXPLICIT_FAMILY_METADATA",
        )
    return FamilyDescriptor()


def describe_rows(rows: list[dict[str, Any]], *, sport: str, mode: str) -> list[FamilyDescriptor]:
    return [describe(r, sport=sport, mode=mode) for r in rows]
