#!/usr/bin/env python3
"""Offline-only OpenAI advisor for APEX Monte Carlo calibration research.

This module NEVER participates in a live slate and NEVER mutates simulation parameters.
It consumes chronology-valid historical calibration evidence and emits structured,
bounded hypotheses for shadow evaluation. Production promotion remains a deterministic,
cross-control engineering decision.
"""
from __future__ import annotations

import argparse, importlib.util, json, os
from pathlib import Path
from typing import Any, Mapping, Sequence, Callable

PATCH_ID="APEX_OPENAI_MC_CALIBRATION_ADVISOR_v1"

_here=Path(__file__).resolve().parent
_spec=importlib.util.spec_from_file_location("apex_openai_terminal_selector_bridge_v1",_here/"apex_openai_terminal_selector_bridge_v1.py")
if _spec is None or _spec.loader is None: raise RuntimeError("OPENAI_MC_ADVISOR_BRIDGE_MODULE_UNAVAILABLE")
bridge=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(bridge)

class MCCalibrationAdvisorError(RuntimeError): pass

DEFECT_ENUM=[
 "TAIL_COMPRESSION","TAIL_OVERDISPERSION","CPT_ROLE_MISSPECIFICATION","TD_EVENT_TAIL_MISSPECIFICATION",
 "CORRELATION_MISSPECIFICATION","DST_EVENT_MISSPECIFICATION","INPUT_UNCERTAINTY_MISSING",
 "MEMBERSHIP_CENSORING","SELECTOR_CENSORING","INSUFFICIENT_EVIDENCE"
]
PARAMETER_ENUM=[
 "PLAYER_DISTRIBUTION_FAMILY","ROLE_SIGMA","INPUT_UNCERTAINTY","TD_EVENT_PROCESS","DST_EVENT_PROCESS",
 "GAME_SCRIPT_CORRELATION","TEAM_CORRELATION","PASS_RUSH_LATENT_FACTORS","CPT_ROLE_TRANSFORM","NONE"
]
ACTION_ENUM=["INCREASE","DECREASE","REPLACE_DISTRIBUTION","ADD_EVENT_COMPONENT","RECALIBRATE_CORRELATION","NO_CHANGE","COLLECT_MORE_EVIDENCE"]

SCHEMA={
 "type":"object",
 "properties":{
  "status":{"type":"string","enum":["ADVISORY_COMPLETE","INSUFFICIENT_EVIDENCE"]},
  "evidence_grade":{"type":"string","enum":["LOW","MEDIUM","HIGH"]},
  "diagnosed_defects":{"type":"array","items":{"type":"object","properties":{
    "defect":{"type":"string","enum":DEFECT_ENUM},
    "confidence":{"type":"number","minimum":0,"maximum":1},
    "supporting_control_ids":{"type":"array","items":{"type":"string"}},
    "reason":{"type":"string","maxLength":500}
  },"required":["defect","confidence","supporting_control_ids","reason"],"additionalProperties":False}},
  "segment_findings":{"type":"array","items":{"type":"object","properties":{
    "segment":{"type":"string","maxLength":160},
    "direction":{"type":"string","enum":["UNDERDISPERSED","OVERDISPERSED","MISORDERED","WELL_CALIBRATED","UNKNOWN"]},
    "confidence":{"type":"number","minimum":0,"maximum":1},
    "supporting_control_ids":{"type":"array","items":{"type":"string"}}
  },"required":["segment","direction","confidence","supporting_control_ids"],"additionalProperties":False}},
  "recommended_shadow_changes":{"type":"array","items":{"type":"object","properties":{
    "parameter_family":{"type":"string","enum":PARAMETER_ENUM},
    "action":{"type":"string","enum":ACTION_ENUM},
    "max_relative_change":{"type":"number","minimum":0,"maximum":0.5},
    "scope":{"type":"string","maxLength":160},
    "reason":{"type":"string","maxLength":500}
  },"required":["parameter_family","action","max_relative_change","scope","reason"],"additionalProperties":False}},
  "required_validation":{"type":"array","items":{"type":"string","enum":[
    "COMMON_RANDOM_NUMBERS","CHRONOLOGICAL_CROSS_CONTROL","WEIGHTED_BRIER","TAIL_LOG_LOSS","RELIABILITY_CURVES",
    "WINNER_CAPTURE_NON_REGRESSION","TOP01_CAPTURE_NON_REGRESSION","NO_SAME_SLATE_POSTLOCK_FORWARD_INPUT","MEMBERSHIP_PARITY"
  ]}},
  "promotion_decision":{"type":"string","enum":["SHADOW_ONLY","READY_FOR_CODE_SHADOW","INSUFFICIENT_EVIDENCE"]}
 },
 "required":["status","evidence_grade","diagnosed_defects","segment_findings","recommended_shadow_changes","required_validation","promotion_decision"],
 "additionalProperties":False
}

INSTRUCTIONS="""You are the offline APEX Monte Carlo calibration research advisor.
You are NOT a live lineup selector and you have ZERO authority to mutate production parameters.
Use only the historical controls supplied in this request. Postlock truth is valid here only as an offline label for future calibration.
Distinguish membership censoring from MC calibration: do not blame MC for a winner that never reached the evaluated surface.
P95/P99 and raw MC rates are signals, not literal truth. Do not recommend blind universal variance inflation from one slate.
Look for repeated reliability failures across chronological controls and role/tail families. Prefer event-native/heavy-tail or input-uncertainty fixes when evidence supports them over arbitrary scalar boosts.
Any proposed change must be bounded, shadow-only, and require common-random-number cross-control validation before production promotion.
Selector metrics must not be used to tune the MC distribution unless the candidate was born and retained for evaluation.
"""

def _load_dataset(path: Path) -> dict[str,Any]:
    obj=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(obj,dict): raise MCCalibrationAdvisorError('MC_ADVISOR_DATASET_NOT_OBJECT')
    controls=obj.get('controls')
    if not isinstance(controls,list) or len(controls)<2: raise MCCalibrationAdvisorError('MC_ADVISOR_NEEDS_MULTIPLE_CONTROLS')
    ids=[]
    for c in controls:
        if not isinstance(c,dict): raise MCCalibrationAdvisorError('MC_ADVISOR_CONTROL_NOT_OBJECT')
        cid=str(c.get('control_id') or '')
        if not cid: raise MCCalibrationAdvisorError('MC_ADVISOR_CONTROL_ID_MISSING')
        if cid in ids: raise MCCalibrationAdvisorError('MC_ADVISOR_DUPLICATE_CONTROL_ID:'+cid)
        ids.append(cid)
        if c.get('same_slate_forward_truth_used') is True: raise MCCalibrationAdvisorError('MC_ADVISOR_FORWARD_LEAKAGE:'+cid)
    return obj

def run_advisor(*, dataset_path: Path, output_path: Path, model: str, reasoning_effort: str,
                timeout: float, max_retries: int, response_caller: Callable[...,Mapping[str,Any]]|None=None) -> dict[str,Any]:
    bridge._load_local_env(); data=_load_dataset(dataset_path)
    caller=response_caller or bridge.call_responses
    payload=bridge._response_payload(model=model,reasoning_effort=reasoning_effort,instructions=INSTRUCTIONS,
        user_payload={"task":"DIAGNOSE_MULTI_CONTROL_MC_CALIBRATION_AND_PROPOSE_BOUNDED_SHADOW_REPAIRS","dataset":data},
        schema_name="apex_mc_calibration_advisory",schema=SCHEMA)
    resp=caller(payload,timeout=timeout,max_retries=max_retries)
    obj=bridge._parse_structured(resp)
    # Minimal local contract validation. Structured Outputs owns full schema adherence.
    if obj.get('promotion_decision') not in {'SHADOW_ONLY','READY_FOR_CODE_SHADOW','INSUFFICIENT_EVIDENCE'}:
        raise MCCalibrationAdvisorError('MC_ADVISOR_BAD_PROMOTION_DECISION')
    out={"PATCH_ID":PATCH_ID,"MODEL":model,"REASONING_EFFORT":reasoning_effort,
         "PRODUCTION_MUTATION":False,"LIVE_FORWARD_AUTHORITY":False,"ADVISORY":obj,
         "USAGE":dict(resp.get('usage') or {})}
    bridge._atomic_json(output_path,out); return out

def main(argv:Sequence[str]|None=None)->int:
    bridge._load_local_env()
    ap=argparse.ArgumentParser(description=PATCH_ID)
    ap.add_argument('--dataset',required=True); ap.add_argument('--output',required=True)
    ap.add_argument('--model',default=os.environ.get('APEX_OPENAI_CALIBRATION_MODEL',os.environ.get('APEX_OPENAI_SELECTOR_MODEL',bridge.DEFAULT_MODEL)))
    ap.add_argument('--reasoning-effort',default=os.environ.get('APEX_OPENAI_CALIBRATION_REASONING_EFFORT','high'),choices=['low','medium','high','xhigh','max'])
    ap.add_argument('--timeout',type=float,default=float(os.environ.get('APEX_OPENAI_TIMEOUT_SECONDS',bridge.DEFAULT_TIMEOUT_SECONDS)))
    ap.add_argument('--max-retries',type=int,default=int(os.environ.get('APEX_OPENAI_MAX_RETRIES',bridge.DEFAULT_MAX_RETRIES)))
    a=ap.parse_args(argv)
    try:
        out=run_advisor(dataset_path=Path(a.dataset),output_path=Path(a.output),model=a.model,reasoning_effort=a.reasoning_effort,timeout=a.timeout,max_retries=a.max_retries)
    except Exception as exc:
        print(json.dumps({'PATCH_ID':PATCH_ID,'STATUS':'FAIL','ERROR':f'{type(exc).__name__}:{exc}'},separators=(',',':'))); return 2
    print(json.dumps({'PATCH_ID':PATCH_ID,'STATUS':'PASS','OUTPUT':str(Path(a.output)),'PRODUCTION_MUTATION':False,'PROMOTION_DECISION':out['ADVISORY']['promotion_decision']},indent=2)); return 0

if __name__=='__main__': raise SystemExit(main())
