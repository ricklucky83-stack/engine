from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Iterable, Mapping, Sequence

PATCH_ID = "APEX_GLOBAL_DIAGNOSTIC_NO_LOST_REPAIR_AND_INCREMENTAL_PROMOTION_v2"
TERMINAL_STATUSES = {"ACTIVE", "MERGED", "SUPERSEDED", "REJECTED"}
VALIDATED_STATUSES = {"VALIDATED", "QUEUED", "MERGE_READY"}
STATUS_PRECEDENCE = {
    "VALIDATED": 10,
    "QUEUED": 20,
    "MERGE_READY": 30,
    "ACTIVE": 40,
    "MERGED": 40,
    "SUPERSEDED": 40,
    "REJECTED": 40,
}


class DiagnosticLedgerError(RuntimeError):
    pass


def _canonical_json(obj: Mapping) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def build_patch_id(*, sport: str, mode: str, slate_id: str, base_state_version: str,
                   changed_components: Sequence[str], patch_payload: Mapping) -> str:
    payload = {
        "SPORT": str(sport).upper(),
        "MODE": str(mode).upper(),
        "SLATE_ID": str(slate_id),
        "BASE_STATE_VERSION": str(base_state_version),
        "CHANGED_COMPONENTS": sorted(set(map(str, changed_components))),
        "PATCH_PAYLOAD": patch_payload,
    }
    digest = sha256_bytes(_canonical_json(payload))[:20]
    return f"DIAG_{payload['SPORT']}_{payload['MODE']}_{payload['SLATE_ID']}_{digest}"


def _validate_terminal_fields(*, status: str, superseded_by: str | None,
                              reason: str | None, promoted_state_version: str | None) -> None:
    if status == "SUPERSEDED" and not superseded_by:
        raise DiagnosticLedgerError("SUPERSEDED_PATCH_REQUIRES_SUCCESSOR_PATCH_ID")
    if status == "REJECTED" and not reason:
        raise DiagnosticLedgerError("REJECTED_PATCH_REQUIRES_REASON")
    if status in {"ACTIVE", "MERGED"} and not promoted_state_version:
        raise DiagnosticLedgerError("MERGED_PATCH_REQUIRES_PROMOTED_STATE_VERSION")


def build_receipt(*, patch_id: str, base_state_version: str, sport: str, mode: str,
                  slate_id: str, changed_components: Sequence[str], patch_hash: str,
                  status: str = "VALIDATED", dependencies: Sequence[str] = (),
                  conflict_keys: Sequence[str] = (), supersedes: Sequence[str] = (),
                  superseded_by: str | None = None, reason: str | None = None,
                  promoted_state_version: str | None = None) -> dict:
    status = str(status).upper()
    if status not in STATUS_PRECEDENCE:
        raise DiagnosticLedgerError(f"INVALID_DIAGNOSTIC_STATUS:{status}")
    _validate_terminal_fields(status=status, superseded_by=superseded_by,
                              reason=reason, promoted_state_version=promoted_state_version)
    receipt = {
        "SCHEMA": PATCH_ID,
        "PATCH_ID": str(patch_id),
        "BASE_STATE_VERSION": str(base_state_version),
        "SPORT": str(sport).upper(),
        "MODE": str(mode).upper(),
        "SLATE_ID": str(slate_id),
        "CHANGED_COMPONENTS": sorted(set(map(str, changed_components))),
        "PATCH_HASH": str(patch_hash),
        "DEPENDENCIES": sorted(set(map(str, dependencies))),
        "CONFLICT_KEYS": sorted(set(map(str, conflict_keys))),
        "SUPERSEDES": sorted(set(map(str, supersedes))),
        "SUPERSEDED_BY": str(superseded_by) if superseded_by else None,
        "REASON": str(reason) if reason else None,
        "PROMOTED_STATE_VERSION": str(promoted_state_version) if promoted_state_version else None,
        "STATUS": status,
    }
    receipt["RECEIPT_SHA256"] = sha256_bytes(_canonical_json(receipt))
    return receipt


def persist_immutable_receipt(queue_dir: str | Path, receipt: Mapping) -> Path:
    root = Path(queue_dir)
    root.mkdir(parents=True, exist_ok=True)
    patch_id = str(receipt.get("PATCH_ID") or "")
    receipt_hash = str(receipt.get("RECEIPT_SHA256") or "")
    if not patch_id or not receipt_hash:
        raise DiagnosticLedgerError("INVALID_DIAGNOSTIC_RECEIPT")
    path = root / f"{patch_id}.{receipt_hash[:16]}.json"
    data = json.dumps(dict(receipt), sort_keys=True, indent=2).encode("utf-8") + b"\n"
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    try:
        fd = os.open(path, flags, 0o644)
    except FileExistsError:
        if path.read_bytes() != data:
            raise DiagnosticLedgerError(f"IMMUTABLE_RECEIPT_COLLISION:{path.name}")
        return path
    with os.fdopen(fd, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    return path


def load_receipts(queue_dir: str | Path) -> list[dict]:
    root = Path(queue_dir)
    if not root.exists():
        return []
    out = []
    for p in sorted(root.glob("*.json")):
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))
        except Exception as exc:
            raise DiagnosticLedgerError(f"INVALID_QUEUE_RECEIPT:{p.name}:{exc}") from exc
        expected = obj.get("RECEIPT_SHA256")
        check = dict(obj); check.pop("RECEIPT_SHA256", None)
        got = sha256_bytes(_canonical_json(check))
        if expected != got:
            raise DiagnosticLedgerError(f"QUEUE_RECEIPT_HASH_MISMATCH:{p.name}")
        out.append(obj)
    return out


def queue_snapshot(receipts: Iterable[Mapping]) -> dict:
    rows = sorted((str(r.get("PATCH_ID")), str(r.get("RECEIPT_SHA256")), str(r.get("STATUS"))) for r in receipts)
    digest = sha256_bytes(_canonical_json({"ROWS": rows}))
    return {"QUEUE_COUNT": len(rows), "QUEUE_SNAPSHOT_SHA256": digest, "ROWS": rows}


def _terminal_resolution(rows: Sequence[Mapping]) -> tuple[str | None, Mapping | None]:
    terminals = [r for r in rows if str(r.get("STATUS") or "").upper() in TERMINAL_STATUSES]
    kinds = sorted({str(r.get("STATUS") or "").upper() for r in terminals})
    if len(kinds) > 1:
        raise DiagnosticLedgerError("DIAGNOSTIC_TERMINAL_STATE_CONFLICT:" + ",".join(kinds))
    if not terminals:
        return None, None
    status = kinds[0]
    chosen = sorted(terminals, key=lambda r: str(r.get("RECEIPT_SHA256")))[-1]
    # v1 queue receipts predate explicit terminal metadata. They remain valid
    # historical evidence and are grandfathered; v2+ receipts must satisfy
    # the stricter successor/reason/promoted-version contract.
    if str(chosen.get("SCHEMA") or "") == PATCH_ID:
        _validate_terminal_fields(
            status=status,
            superseded_by=chosen.get("SUPERSEDED_BY"),
            reason=chosen.get("REASON"),
            promoted_state_version=chosen.get("PROMOTED_STATE_VERSION"),
        )
    return status, chosen


def resolve_patch_state(rows: Sequence[Mapping]) -> tuple[str, Mapping]:
    terminal_status, terminal_receipt = _terminal_resolution(rows)
    if terminal_status and terminal_receipt:
        return terminal_status, terminal_receipt
    candidates = []
    for r in rows:
        status = str(r.get("STATUS") or "").upper()
        if status in VALIDATED_STATUSES:
            candidates.append((STATUS_PRECEDENCE[status], str(r.get("RECEIPT_SHA256")), r))
    if not candidates:
        raise DiagnosticLedgerError("UNRESOLVED_DIAGNOSTIC_PATCH_STATE")
    _, _, chosen = sorted(candidates, key=lambda x: (x[0], x[1]))[-1]
    return str(chosen.get("STATUS")).upper(), chosen


def build_promotion_set(receipts: Iterable[Mapping], active_patch_ids: Iterable[str]) -> dict:
    rows = list(receipts)
    active = set(map(str, active_patch_ids))
    by_id: dict[str, list[Mapping]] = {}
    for r in rows:
        by_id.setdefault(str(r.get("PATCH_ID")), []).append(r)

    promotion: list[Mapping] = []
    already_active: set[str] = set()
    terminal_accounted: set[str] = set()
    state_by_patch: dict[str, str] = {}
    for pid, events in sorted(by_id.items()):
        status, chosen = resolve_patch_state(events)
        state_by_patch[pid] = status
        if pid in active or status in {"ACTIVE", "MERGED"}:
            already_active.add(pid)
        elif status in {"SUPERSEDED", "REJECTED"}:
            terminal_accounted.add(pid)
        elif status in VALIDATED_STATUSES:
            promotion.append(chosen)
        else:
            raise DiagnosticLedgerError(f"UNACCOUNTED_VALIDATED_PATCHES:{pid}:{status}")

    promotion_ids = sorted(str(r["PATCH_ID"]) for r in promotion)
    accounted = already_active | terminal_accounted | set(promotion_ids)
    unaccounted = sorted(set(by_id) - accounted)
    if unaccounted:
        raise DiagnosticLedgerError("UNACCOUNTED_VALIDATED_PATCHES:" + ",".join(unaccounted))
    return {
        "VALIDATED_DIAGNOSTICS_TOTAL": len(by_id),
        "PROMOTION_PATCH_IDS": promotion_ids,
        "PROMOTION_SET": promotion,
        "ALREADY_ACTIVE": sorted(already_active),
        "TERMINAL_ACCOUNTED": sorted(terminal_accounted),
        "PATCH_STATE": state_by_patch,
        "UNACCOUNTED": [],
        "UNACCOUNTED_VALIDATED_PATCHES": 0,
    }


def require_promotion_coverage(plan: Mapping, merged_patch_ids: Iterable[str]) -> dict:
    required = set(map(str, plan.get("PROMOTION_PATCH_IDS") or ()))
    merged = set(map(str, merged_patch_ids or ()))
    missing = sorted(required - merged)
    if missing:
        raise DiagnosticLedgerError("VALIDATED_PATCHES_NOT_IMPLEMENTED:" + ",".join(missing))
    return {
        "PROMOTION_REQUIRED_PATCHES": sorted(required),
        "PROMOTION_IMPLEMENTED_PATCHES": sorted(required & merged),
        "UNIMPLEMENTED_VALIDATED_PATCHES": 0,
    }


def detect_patch_conflicts(promotion_set: Sequence[Mapping]) -> dict:
    owners: dict[str, list[str]] = {}
    for r in promotion_set:
        pid = str(r.get("PATCH_ID"))
        keys = set(map(str, r.get("CONFLICT_KEYS") or ())) | set(map(str, r.get("CHANGED_COMPONENTS") or ()))
        for key in keys:
            owners.setdefault(key, []).append(pid)
    conflicts = {k: sorted(set(v)) for k, v in owners.items() if len(set(v)) > 1}
    return {"CONFLICT_COUNT": len(conflicts), "CONFLICTS": conflicts,
            "MERGE_STATE": "AUTO_MERGE_SAFE" if not conflicts else "EXPLICIT_RECONCILIATION_REQUIRED"}


def assert_queue_unchanged(before: Mapping, after: Mapping) -> None:
    if str(before.get("QUEUE_SNAPSHOT_SHA256")) != str(after.get("QUEUE_SNAPSHOT_SHA256")):
        raise DiagnosticLedgerError(
            f"DIAGNOSTIC_QUEUE_DRIFT_REBASE_REQUIRED:{before.get('QUEUE_SNAPSHOT_SHA256')}:{after.get('QUEUE_SNAPSHOT_SHA256')}"
        )
