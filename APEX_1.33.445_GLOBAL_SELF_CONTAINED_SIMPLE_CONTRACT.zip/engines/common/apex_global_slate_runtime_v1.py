from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo
import re
import os
import pandas as pd

PATCH_ID = "APEX_GLOBAL_SLATE_RUNTIME_SLA_v1"
USER_TIMEZONE = "America/Chicago"
TIME_COLUMN_CANDIDATES = (
    "Time (ET)", "TIME (ET)", "Time (CT)", "TIME (CT)", "Time (MT)", "TIME (MT)",
    "Time (PT)", "TIME (PT)", "Game Start", "GAME START", "Start Time", "START TIME",
    "Game Time", "GAME TIME", "Start", "START", "Date/Time", "DATE/TIME", "Game Info", "GAME INFO",
)
ZONE_HINTS = {
    "ET": "America/New_York",
    "EST": "America/New_York",
    "EDT": "America/New_York",
    "CT": "America/Chicago",
    "CST": "America/Chicago",
    "CDT": "America/Chicago",
    "MT": "America/Denver",
    "MST": "America/Denver",
    "MDT": "America/Denver",
    "PT": "America/Los_Angeles",
    "PST": "America/Los_Angeles",
    "PDT": "America/Los_Angeles",
}

def _field_caps(field_size: int) -> dict[str, int | str]:
    f=max(1,int(field_size))
    if f <= 300:
        return dict(tier="SMALL", player=20_000, phase2=2_500, base=2_000, bubble=128, extra=5_000)
    if f <= 3_000:
        return dict(tier="MEDIUM", player=20_000, phase2=5_000, base=2_000, bubble=192, extra=5_000)
    return dict(tier="LARGE", player=20_000, phase2=8_000, base=2_500, bubble=256, extra=7_500)


def _urgency(minutes_to_lock: float) -> tuple[str, dict[str,float]]:
    if minutes_to_lock >= 60:
        return "NORMAL", dict(player=1.0, phase2=1.0, base=1.0, bubble=1.0, extra=1.0)
    if minutes_to_lock >= 30:
        return "ACCELERATED", dict(player=.75, phase2=.75, base=.75, bubble=.75, extra=.60)
    if minutes_to_lock >= 15:
        return "URGENT", dict(player=.50, phase2=.50, base=.50, bubble=.50, extra=.40)
    if minutes_to_lock >= 5:
        return "CRITICAL", dict(player=.30, phase2=.30, base=.30, bubble=.25, extra=.20)
    return "EMERGENCY", dict(player=.15, phase2=.15, base=.20, bubble=.125, extra=.10)


def budget_for(field_size: int, minutes_to_lock: float) -> dict[str, Any]:
    base=_field_caps(field_size)
    urgency,m=_urgency(minutes_to_lock)
    def cap(name: str, floor: int) -> int:
        return max(floor, int(round(int(base[name]) * m[name])))
    return {
        "field_size": int(field_size),
        "player_trials_max": cap("player", 1_000),
        "phase2_sim_cap": cap("phase2", 400),
        "base_sim_trials_max": cap("base", 250),
        "adaptive_bubble_max": cap("bubble", 16),
        "bubble_extra_trials_max": cap("extra", 500),
        "tier": str(base["tier"]), "urgency": urgency,
    }


def _column_zone(name: str) -> str | None:
    upper=name.upper()
    for token, zone in ZONE_HINTS.items():
        if re.search(rf"(?:\(|\b){re.escape(token)}(?:\)|\b)", upper):
            return zone
    return None


def _extract_datetime_text(value: Any) -> tuple[str, str | None]:
    text=str(value).strip()
    zone=None
    for token,z in ZONE_HINTS.items():
        if re.search(rf"\b{token}\b", text.upper()):
            zone=z
            text=re.sub(rf"\b{token}\b", "", text, flags=re.I).strip()
            break
    # DraftKings-like Game Info: TEAM@TEAM 08/07/2026 07:30PM
    m=re.search(r"(\d{1,2}/\d{1,2}/\d{2,4}\s+\d{1,2}:\d{2}\s*[AP]M)", text, flags=re.I)
    if m: return m.group(1), zone
    m=re.search(r"(\d{4}-\d{2}-\d{2}[ T]\d{1,2}:\d{2}(?::\d{2})?(?:[+-]\d{2}:?\d{2}|Z)?)", text, flags=re.I)
    if m: return m.group(1), zone
    return text, zone


def parse_start_times(frame: pd.DataFrame, default_tz: str = USER_TIMEZONE) -> tuple[pd.DatetimeIndex, str]:
    column=None
    for candidate in TIME_COLUMN_CANDIDATES:
        if candidate in frame.columns:
            column=candidate; break
    if column is None:
        # Conservative semantic fallback: only columns clearly naming time/start/game info.
        for c in frame.columns:
            u=str(c).upper()
            if "TIME" in u or "START" in u or "GAME INFO" in u:
                column=c; break
    if column is None:
        return pd.DatetimeIndex([]), "NO_FILE_TIME_COLUMN"
    col_zone=_column_zone(str(column))
    parsed=[]
    for raw in frame[column].dropna().unique().tolist():
        text,value_zone=_extract_datetime_text(raw)
        try:
            ts=pd.Timestamp(text)
        except Exception:
            continue
        if pd.isna(ts):
            continue
        if ts.tzinfo is None:
            ts=ts.tz_localize(value_zone or col_zone or default_tz, ambiguous="NaT", nonexistent="shift_forward")
        ts=ts.tz_convert(USER_TIMEZONE)
        parsed.append(ts)
    parsed=[x for x in parsed if not pd.isna(x)]
    return pd.DatetimeIndex(sorted(set(parsed))), f"FILE_COLUMN:{column}"


def evaluate_pool(pool_path: str | Path, field_size: int, now: str | datetime | None = None) -> dict[str, Any]:
    frame=pd.read_csv(pool_path, low_memory=False)
    starts,source=parse_start_times(frame)
    if now is None:
        now=os.environ.get("APEX_NOW_ISO")
    if isinstance(now,str):
        now_ts=pd.Timestamp(now)
    elif isinstance(now,datetime):
        now_ts=pd.Timestamp(now)
    else:
        now_ts=pd.Timestamp.now(tz=USER_TIMEZONE)
    if now_ts.tzinfo is None:
        now_ts=now_ts.tz_localize(USER_TIMEZONE)
    else:
        now_ts=now_ts.tz_convert(USER_TIMEZONE)
    if len(starts)==0:
        # No file time means we can still enforce bounded live compute, but cannot certify lock proximity.
        minutes=60.0
        lock=None
        expired=False
        source="NO_FILE_TIME_COLUMN_BOUNDED_FALLBACK"
    else:
        lock=starts.min()
        minutes=float((lock-now_ts).total_seconds()/60.0)
        expired=minutes <= 0.0
    budget=budget_for(field_size, minutes)
    return {
        "PATCH_ID": PATCH_ID,
        "TIME_SOURCE": source,
        "NOW_LOCAL": now_ts.isoformat(),
        "ENTRY_LOCK_LOCAL": None if lock is None else lock.isoformat(),
        "MINUTES_TO_ENTRY_LOCK": round(minutes,3),
        "ENTRY_WINDOW_EXPIRED": bool(expired),
        "RUN_RESULT": "PRODUCTION_FAILURE" if expired else "LIVE_PRODUCTION_ALLOWED",
        "BOARD_DEADLINE_PRIORITY": "ABSOLUTE",
        "DEEP_SIM_BEFORE_BOARD": "PROHIBITED",
        "MASSIVE_BUBBLE_BEFORE_BOARD": "PROHIBITED",
        "RESEARCH_WORK_BEFORE_BOARD": "PROHIBITED",
        "SELF_EXPANDING_COMPUTE": "PROHIBITED",
        "BOARD_WALL": "HARD_STOP_AFTER_RENDER",
        "BUDGET": budget,
    }
