from __future__ import annotations

"""Global APEX championship-head policy.

The first five playable seats are a championship neighborhood, not a diversification
showcase.  Diversification/exposure controls begin only after the championship head
has been protected.  This policy is sport-agnostic; sport/mode adapters still own
feature construction and calibration.

Forward selection may never consume post-lock truth.  The diagnostic helper at the
bottom is explicitly post-lock-only and is not imported by forward selectors.
"""

from typing import Any, Sequence
import math
import statistics

PATCH_ID = "APEX_GLOBAL_CHAMPIONSHIP_HEAD_TOP0050_LARGE_CONTEST_v2"
SCOPE = "ALL_SUPPORTED_SPORTS_AND_MODES"
CHAMPIONSHIP_HEAD_SIZE = 5
DIVERSIFICATION_START_SEAT = 6
TOP5_IS_CHAMPIONSHIP_NEIGHBORHOOD = True
DIVERSIFICATION_ALLOWED_INSIDE_HEAD = False
RAW_MC_LITERAL_AUTHORITY = False

# Global contest-size objective. Large contests target the true championship
# neighborhood at Top-0.0050% first; Top-0.0100% is secondary and Top-0.1000%
# is fallback. Sport/mode adapters may be stricter but may not relax a large
# contest below this standard without an explicit documented exception.
LARGE_CONTEST_MIN_FIELD_SIZE = 5000
PRIMARY_CHAMPIONSHIP_FRACTION = 0.00005
SECONDARY_CHAMPIONSHIP_FRACTION = 0.00010
FALLBACK_CHAMPIONSHIP_FRACTION = 0.00100

PRIMARY_SIGNALS = (
    "CROSS_WORLD_RECURRENCE",
    "PAIRWISE_STRENGTH",
    "WORLD_BREADTH",
    "STABLE_TAIL_PRESENCE",
    "RANK_STABILITY",
)
SECONDARY_SIGNALS = (
    "REL_TOP0050", "REL_TOP0100", "REL_WIN", "REL_TOP01", "REL_TOP1", "REL_P95", "REL_P99",
    "REL_EXPECTED_RANK", "REL_MEDIAN_RANK", "REL_P90_RANK",
)
PENALTIES = (
    "INSTABILITY", "SINGLE_WORLD_CONCENTRATION", "EXTREME_METRIC_DISAGREEMENT",
)
MANDATORY_DIAGNOSTICS = (
    "WINNER_RANK",
    "TOP5_EX_WINNER_MEDIAN",
    "TOP10_EX_WINNER_MEDIAN",
    "TOP0050_IN_TOP5",
    "TOP0100_IN_TOP5",
    "TOP1PCT_IN_TOP5",
    "TOP1PCT_IN_TOP10",
    "PHASE2_TO_BOARD_ELITE_RECALL",
    "ORACLE_GAP",
)



def championship_target_policy(field_size: int) -> dict[str, Any]:
    """Field-scaled global championship target contract.

    Large contests (>= LARGE_CONTEST_MIN_FIELD_SIZE) must use Top-0.0050% as
    the primary championship band. Smaller contests retain sport/mode-native
    calibration, but the rank equivalents are still returned for diagnostics.
    """
    fs=max(1,int(field_size))
    large=fs >= LARGE_CONTEST_MIN_FIELD_SIZE
    return {
        "PATCH_ID": PATCH_ID,
        "FIELD_SIZE": fs,
        "LARGE_CONTEST": bool(large),
        "LARGE_CONTEST_MIN_FIELD_SIZE": LARGE_CONTEST_MIN_FIELD_SIZE,
        "PRIMARY_TARGET": "TOP_0.0050%" if large else "SPORT_MODE_NATIVE",
        "SECONDARY_TARGET": "TOP_0.0100%" if large else "SPORT_MODE_NATIVE",
        "FALLBACK_TARGET": "TOP_0.1000%" if large else "SPORT_MODE_NATIVE",
        "TOP0050_TARGET_RANK": max(1,int(math.ceil(fs*PRIMARY_CHAMPIONSHIP_FRACTION))),
        "TOP0100_TARGET_RANK": max(1,int(math.ceil(fs*SECONDARY_CHAMPIONSHIP_FRACTION))),
        "TOP0100_FALLBACK_RANK": max(1,int(math.ceil(fs*FALLBACK_CHAMPIONSHIP_FRACTION))),
        "RAW_MC_LITERAL_AUTHORITY": False,
    }

def head_size(board_size: int) -> int:
    return min(CHAMPIONSHIP_HEAD_SIZE, max(0, int(board_size)))


def diversification_allowed(one_based_seat: int, board_size: int | None = None) -> bool:
    if one_based_seat <= 0:
        raise ValueError("SEAT_MUST_BE_ONE_BASED_POSITIVE")
    h = CHAMPIONSHIP_HEAD_SIZE if board_size is None else head_size(board_size)
    return int(one_based_seat) > h


def policy_receipt(board_size: int, field_size: int | None = None) -> dict[str, Any]:
    h = head_size(board_size)
    target = championship_target_policy(field_size) if field_size is not None else None
    return {
        "PATCH_ID": PATCH_ID,
        "SCOPE": SCOPE,
        "BOARD_SIZE": int(board_size),
        "CHAMPIONSHIP_HEAD_SIZE": h,
        "DIVERSIFICATION_START_SEAT": h + 1 if int(board_size) > h else None,
        "TOP5_IS_CHAMPIONSHIP_NEIGHBORHOOD": True,
        "DIVERSIFICATION_ALLOWED_INSIDE_HEAD": False,
        "RAW_MC_LITERAL_AUTHORITY": False,
        "PRIMARY_SIGNALS": list(PRIMARY_SIGNALS),
        "SECONDARY_SIGNALS": list(SECONDARY_SIGNALS),
        "PENALTIES": list(PENALTIES),
        "MANDATORY_DIAGNOSTICS": list(MANDATORY_DIAGNOSTICS),
        "LARGE_CONTEST_TARGET_POLICY": target,
    }


def _median_or_none(values: Sequence[float]) -> float | None:
    vals = [float(x) for x in values if x is not None and math.isfinite(float(x))]
    return float(statistics.median(vals)) if vals else None


def postlock_neighborhood_diagnostics(
    realized_ranks: Sequence[float], *, top1pct_cutoff: float | None = None,
    phase2_elite_count: int | None = None, board_elite_count: int | None = None,
    oracle_head_ranks: Sequence[float] | None = None,
) -> dict[str, Any]:
    """Post-lock diagnostic only; never call from forward selection.

    Winner-removal is identity-free: every rank <= 1 is removed from the neighborhood
    calculation.  `ORACLE_GAP` compares winner-removed Top-5 median with the best
    attainable winner-removed Top-5 median from the supplied frozen surface.
    """
    rr = [float(x) for x in realized_ranks if x is not None and math.isfinite(float(x))]
    top5 = rr[:5]
    top10 = rr[:10]
    top5_ex = [x for x in top5 if x > 1.0]
    top10_ex = [x for x in top10 if x > 1.0]
    winner_rank = min(rr) if rr else None
    out: dict[str, Any] = {
        "PATCH_ID": PATCH_ID,
        "POSTLOCK_DIAGNOSTIC_ONLY": True,
        "WINNER_RANK": winner_rank,
        "TOP5_EX_WINNER_MEDIAN": _median_or_none(top5_ex),
        "TOP10_EX_WINNER_MEDIAN": _median_or_none(top10_ex),
    }
    if top1pct_cutoff is not None:
        cut = float(top1pct_cutoff)
        out["TOP1PCT_IN_TOP5"] = sum(x <= cut for x in top5)
        out["TOP1PCT_IN_TOP10"] = sum(x <= cut for x in top10)
    if phase2_elite_count is not None and board_elite_count is not None:
        den = max(0, int(phase2_elite_count)); num = max(0, int(board_elite_count))
        out["PHASE2_TO_BOARD_ELITE_RECALL"] = (num / den) if den else None
    if oracle_head_ranks is not None:
        oracle = [float(x) for x in oracle_head_ranks if x is not None and math.isfinite(float(x))][:5]
        oracle_ex = [x for x in oracle if x > 1.0]
        oracle_med = _median_or_none(oracle_ex)
        out["ORACLE_TOP5_EX_WINNER_MEDIAN"] = oracle_med
        cur = out["TOP5_EX_WINNER_MEDIAN"]
        out["ORACLE_GAP"] = (float(cur) - float(oracle_med)) if cur is not None and oracle_med is not None else None
    return out
