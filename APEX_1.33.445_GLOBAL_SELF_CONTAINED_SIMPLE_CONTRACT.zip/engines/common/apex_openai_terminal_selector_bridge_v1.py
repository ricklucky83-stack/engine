#!/usr/bin/env python3
"""OpenAI Responses API bridge for the existing APEX terminal AI handoff.

This module is deliberately OUTSIDE mechanical lineup generation/simulation authority.
It consumes the already-frozen terminal candidate CSV, reviews 100% of rows in
checkpointed physical chunks, then asks the configured OpenAI model for the final
existing lineup IDs. It never creates or edits a lineup and never writes upstream
metrics.

The bridge prefers the official OpenAI Python SDK when available and otherwise uses
an equivalent stdlib HTTPS request to /v1/responses. No secret is printed or persisted
outside the environment/.env file.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import os
import random
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

PATCH_ID = "APEX_OPENAI_TERMINAL_SELECTOR_BRIDGE_v1"
API_URL = "https://api.openai.com/v1/responses"
DEFAULT_MODEL = "gpt-6-astra"
DEFAULT_REASONING_EFFORT = "high"
DEFAULT_CHUNK_ROWS = 2500
DEFAULT_CHUNK_MAX_CHARS = 700_000
DEFAULT_CHUNK_KEEP = 64
DEFAULT_TIMEOUT_SECONDS = 240
DEFAULT_MAX_RETRIES = 2

class OpenAISelectorBridgeError(RuntimeError):
    pass


def _engine_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _load_local_env() -> None:
    root = _engine_root()
    env_path = root / ".env"
    try:
        from dotenv import load_dotenv  # type: ignore
        load_dotenv(env_path, override=False)
        return
    except Exception:
        pass
    if not env_path.exists():
        return
    for raw in env_path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip(); value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def _load_terminal_ai_module():
    path = Path(__file__).with_name("apex_terminal_ai_hybrid_selector_v6.py")
    spec = importlib.util.spec_from_file_location("apex_terminal_ai_hybrid_selector_v6", path)
    if spec is None or spec.loader is None:
        raise OpenAISelectorBridgeError("OPENAI_BRIDGE_TERMINAL_AI_MODULE_UNAVAILABLE")
    mod = importlib.util.module_from_spec(spec)
    sys.modules.setdefault(spec.name, mod)
    spec.loader.exec_module(mod)
    return mod


terminal_ai = _load_terminal_ai_module()


def _canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")


def _sha(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj)).hexdigest()


def _atomic_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True, ensure_ascii=False)
        f.write("\n"); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")


# Compact live-AI surface. Raw bit-vectors are intentionally omitted; their aggregate
# recurrence/breadth metrics stay available and prevent token blow-up.
SAFE_PREFIXES = (
    "AI_", "MC_", "BASE_MC_", "FAMILY_", "WORLD_", "FAST_PATH_WORLD_",
    "PAIRWISE_", "RANK_", "GLOBAL_CORE_", "CHAMPIONSHIP_", "OWNERSHIP_",
    "EXPECTED_DUP", "P_UNIQUE", "UNIQUE_PROB", "PROB_UNIQUE", "SALARY",
    "CURRENT_SELECTOR_", "SELECTION_", "SCENARIO_", "STACK_", "ROUTE_",
    "RED_ZONE_", "MULTI_PATH_", "ROLE_", "CPT_", "BRANCH", "FIELD_",
)
EXACT_FIELDS = {
    "LINEUP_ID","LINEUP_INDEX","ID","CPT","CAPTAIN","MVP","UTIL","UTILS","PLAYERS",
    "QB","RB1","RB2","WR1","WR2","WR3","TE","FLEX","DST","K",
    "P1","P2","C","1B","2B","3B","SS","OF1","OF2","OF3",
    "G1","G2","G3","G4","G5","G6","F1","F2","F3","F4","F5","F6",
    "WIN_RATE","WIN_PROB","TOP_0_1_RATE","TOP01_RATE","TOP_1_RATE","TOP1_RATE",
    "P99","CVAR99","P95","SELECTOR_SCORE","OBJECTIVE","SCORE","TRIALS",
    "FIELD_SIZE","CONTEST_SIZE","ENTRIES","TEAM_SPLIT","TEAM_SHAPE","GAME_SCRIPT_CLASS",
}
for _i in range(1, 13):
    EXACT_FIELDS.add(f"PLAYER{_i}"); EXACT_FIELDS.add(f"UTIL{_i}")


def _keep_field(name: str) -> bool:
    n = _norm(name)
    if n in terminal_ai.FORBIDDEN_POSTLOCK_FIELDS:
        return False
    if n.endswith("_BITS") or "BITSET" in n or "RAW_WORLD_VECTOR" in n:
        return False
    return n in EXACT_FIELDS or any(n.startswith(p) for p in SAFE_PREFIXES)


def _compact_row(row: Mapping[str, Any]) -> dict[str, Any]:
    lid = terminal_ai._lineup_id(row)
    out: dict[str, Any] = {"LINEUP_ID": lid}
    for k, v in row.items():
        if not _keep_field(str(k)) or v in (None, ""):
            continue
        text = str(v)
        # Keep the prompt bounded if a runtime introduces a verbose diagnostic field.
        if len(text) > 512:
            continue
        out[str(k)] = v
    return out


def _iter_compact_rows(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        rd = csv.DictReader(f)
        fieldnames = list(rd.fieldnames or [])
        forbidden = sorted({_norm(k) for k in fieldnames} & set(terminal_ai.FORBIDDEN_POSTLOCK_FIELDS))
        if forbidden:
            raise OpenAISelectorBridgeError("POSTLOCK_FIELDS_ENTERED_OPENAI_SELECTOR:" + ",".join(forbidden))
        for row in rd:
            yield _compact_row(row)


def _physical_chunks(rows: Iterable[dict[str, Any]], *, max_rows: int, max_chars: int) -> Iterable[list[dict[str, Any]]]:
    if max_rows < 1 or max_chars < 10_000:
        raise OpenAISelectorBridgeError("OPENAI_BRIDGE_INVALID_CHUNK_LIMIT")
    chunk: list[dict[str, Any]] = []; chars = 2
    for row in rows:
        row_chars = len(json.dumps(row, ensure_ascii=False, separators=(",", ":"))) + 1
        if chunk and (len(chunk) >= max_rows or chars + row_chars > max_chars):
            yield chunk
            chunk = []; chars = 2
        chunk.append(row); chars += row_chars
    if chunk:
        yield chunk


def _extract_output_text(obj: Mapping[str, Any]) -> str:
    direct = obj.get("output_text")
    if isinstance(direct, str) and direct.strip():
        return direct
    texts: list[str] = []
    for item in obj.get("output") or []:
        if not isinstance(item, Mapping):
            continue
        for c in item.get("content") or []:
            if isinstance(c, Mapping) and c.get("type") == "output_text" and isinstance(c.get("text"), str):
                texts.append(str(c["text"]))
    if texts:
        return "".join(texts)
    raise OpenAISelectorBridgeError("OPENAI_RESPONSE_OUTPUT_TEXT_MISSING")


def _sdk_request(payload: Mapping[str, Any], *, timeout: float, max_retries: int) -> dict[str, Any]:
    try:
        from openai import OpenAI  # type: ignore
    except Exception as exc:
        raise ImportError from exc
    client = OpenAI(timeout=timeout, max_retries=max_retries)
    kwargs = dict(payload)
    resp = client.responses.create(**kwargs)
    if hasattr(resp, "model_dump"):
        return dict(resp.model_dump())
    if hasattr(resp, "to_dict"):
        return dict(resp.to_dict())
    raise OpenAISelectorBridgeError("OPENAI_SDK_RESPONSE_UNSERIALIZABLE")


def _stdlib_request(payload: Mapping[str, Any], *, timeout: float, max_retries: int) -> dict[str, Any]:
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not key:
        raise OpenAISelectorBridgeError("OPENAI_API_KEY_MISSING")
    body = _canonical(payload)
    retryable = {408, 409, 429, 500, 502, 503, 504}
    last: Exception | None = None
    for attempt in range(max_retries + 1):
        req = urllib.request.Request(
            API_URL,
            data=body,
            method="POST",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:  # nosec B310 - fixed OpenAI endpoint
                raw = r.read()
            obj = json.loads(raw)
            if not isinstance(obj, dict):
                raise OpenAISelectorBridgeError("OPENAI_RESPONSE_NOT_OBJECT")
            return obj
        except urllib.error.HTTPError as exc:
            # Never include response bodies because providers may echo request metadata.
            last = exc
            if exc.code not in retryable or attempt >= max_retries:
                raise OpenAISelectorBridgeError(f"OPENAI_HTTP_ERROR:{exc.code}") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            last = exc
            if attempt >= max_retries:
                raise OpenAISelectorBridgeError(f"OPENAI_NETWORK_ERROR:{type(exc).__name__}") from exc
        time.sleep(min(8.0, (2 ** attempt) + random.random() * 0.25))
    raise OpenAISelectorBridgeError(f"OPENAI_REQUEST_FAILED:{type(last).__name__ if last else 'UNKNOWN'}")


def call_responses(payload: Mapping[str, Any], *, timeout: float, max_retries: int) -> dict[str, Any]:
    try:
        return _sdk_request(payload, timeout=timeout, max_retries=max_retries)
    except ImportError:
        return _stdlib_request(payload, timeout=timeout, max_retries=max_retries)


def _reason_enum() -> list[str]:
    return sorted(str(x) for x in terminal_ai.ALLOWED_REASON_CODES)


def _selection_item_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "lineup_id": {"type": "string", "minLength": 1},
            "reason_codes": {
                "type": "array", "minItems": 1, "maxItems": 6,
                "items": {"type": "string", "enum": _reason_enum()},
            },
        },
        "required": ["lineup_id", "reason_codes"],
        "additionalProperties": False,
    }


def _chunk_schema(keep: int) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "candidate_freeze_sha256": {"type": "string"},
            "advancers": {"type": "array", "minItems": 1, "maxItems": int(keep), "items": _selection_item_schema()},
        },
        "required": ["candidate_freeze_sha256", "advancers"],
        "additionalProperties": False,
    }


def _final_schema(board_size: int) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "candidate_freeze_sha256": {"type": "string"},
            "selections": {
                "type": "array", "minItems": int(board_size), "maxItems": int(board_size),
                "items": _selection_item_schema(),
            },
        },
        "required": ["candidate_freeze_sha256", "selections"],
        "additionalProperties": False,
    }


SYSTEM_INSTRUCTIONS = """You are the APEX terminal Hybrid AI selector. The mechanical DFS engine has already completed legality, candidate birth, calibration, simulation, field modeling, and frozen handoff. You have terminal selection authority only over EXISTING lineup IDs in the supplied frozen surface.

Absolute rules:
- Never invent, edit, reconstruct, or substitute a lineup.
- Never infer or use post-lock outcomes. Use only supplied pre-lock/frozen evidence.
- Raw MC/P95/P99 values are signals, not truth and not automatic ranking authority.
- Objective hierarchy: actual championship/perfect-lineup probability > Top-0.1% probability > Top-1% probability > best contest-rank potential > stability.
- Prefer elite support that recurs across many independent/common worlds and coherent championship families; do not mistake repeated hits in one fragile world/script for broad support.
- Current coded selector scores/ranks are advisory evidence only.
- Ownership/duplication are late leverage/tie-break signals; they may not override materially stronger championship evidence.
- For the Top-5 portfolio, preserve strong shared championship cores when supported. Diversify only when it adds genuine marginal winning-world coverage; generic diversification is not a reason to evict a stronger championship sibling.
- Use only allowed reason codes in the required schema.
"""


def _response_payload(*, model: str, reasoning_effort: str, instructions: str, user_payload: Mapping[str, Any], schema_name: str, schema: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "model": model,
        "instructions": instructions,
        "input": json.dumps(user_payload, ensure_ascii=False, separators=(",", ":")),
        "reasoning": {"effort": reasoning_effort},
        "text": {"format": {"type": "json_schema", "name": schema_name, "strict": True, "schema": dict(schema)}},
        "store": False,
        "truncation": "disabled",
    }


def _parse_structured(resp: Mapping[str, Any]) -> dict[str, Any]:
    status = str(resp.get("status") or "")
    if status and status not in {"completed"}:
        raise OpenAISelectorBridgeError(f"OPENAI_RESPONSE_NOT_COMPLETED:{status}")
    text = _extract_output_text(resp)
    try:
        obj = json.loads(text)
    except Exception as exc:
        raise OpenAISelectorBridgeError("OPENAI_STRUCTURED_OUTPUT_INVALID_JSON") from exc
    if not isinstance(obj, dict):
        raise OpenAISelectorBridgeError("OPENAI_STRUCTURED_OUTPUT_NOT_OBJECT")
    return obj


def _validate_pick_list(obj: Mapping[str, Any], *, key: str, allowed_ids: set[str], freeze: str, exact_count: int | None = None) -> list[dict[str, Any]]:
    if str(obj.get("candidate_freeze_sha256") or "") != str(freeze):
        raise OpenAISelectorBridgeError("OPENAI_DECISION_FREEZE_MISMATCH")
    picks = obj.get(key)
    if not isinstance(picks, list) or not picks:
        raise OpenAISelectorBridgeError(f"OPENAI_DECISION_{key.upper()}_EMPTY")
    if exact_count is not None and len(picks) != int(exact_count):
        raise OpenAISelectorBridgeError(f"OPENAI_DECISION_COUNT_MISMATCH:{len(picks)}:{exact_count}")
    seen: set[str] = set(); out=[]
    for p in picks:
        if not isinstance(p, Mapping):
            raise OpenAISelectorBridgeError("OPENAI_DECISION_PICK_NOT_OBJECT")
        lid = str(p.get("lineup_id") or "")
        if lid not in allowed_ids:
            raise OpenAISelectorBridgeError(f"OPENAI_CREATED_UNSEEN_LINEUP:{lid}")
        if lid in seen:
            raise OpenAISelectorBridgeError(f"OPENAI_DUPLICATE_LINEUP:{lid}")
        reasons = [str(x) for x in (p.get("reason_codes") or [])]
        if not reasons:
            raise OpenAISelectorBridgeError(f"OPENAI_REASON_CODES_MISSING:{lid}")
        bad = sorted(set(reasons) - set(_reason_enum()))
        if bad:
            raise OpenAISelectorBridgeError(f"OPENAI_REASON_CODES_INVALID:{lid}:{','.join(bad)}")
        seen.add(lid); out.append({"lineup_id": lid, "reason_codes": reasons})
    return out


def _load_receipt(path: Path) -> dict[str, Any]:
    obj = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise OpenAISelectorBridgeError("OPENAI_BRIDGE_RECEIPT_NOT_OBJECT")
    return obj


def _canonical_decision_path(output_dir: Path, sport: str, mode: str, execution_id: str) -> Path:
    stem=f"DK_{str(sport).upper()}_{str(mode).upper()}_{execution_id}".replace(" ","_")
    return output_dir / f"{stem}_AI_TERMINAL_DECISION.json"


def run_bridge(*, candidate_file: Path, candidate_receipt: Path, output_dir: Path,
               model: str, screen_model: str, reasoning_effort: str,
               chunk_rows: int, chunk_max_chars: int, chunk_keep: int,
               timeout: float, max_retries: int, board_size: int = 5,
               response_caller: Callable[..., Mapping[str, Any]] | None = None) -> dict[str, Any]:
    _load_local_env()
    if not os.environ.get("OPENAI_API_KEY", "").strip() and response_caller is None:
        raise OpenAISelectorBridgeError("OPENAI_API_KEY_MISSING")
    receipt = _load_receipt(candidate_receipt)
    scan = terminal_ai.scan_candidate_csv(candidate_file)
    freeze = str(scan["CANDIDATE_FREEZE_SHA256"])
    if str(receipt.get("CANDIDATE_FREEZE_SHA256") or "") != freeze:
        raise OpenAISelectorBridgeError("OPENAI_BRIDGE_RECEIPT_FREEZE_MISMATCH")
    candidate_count = int(scan["CANDIDATE_COUNT"])
    if int(receipt.get("CANDIDATE_COUNT", candidate_count) or candidate_count) != candidate_count:
        raise OpenAISelectorBridgeError("OPENAI_BRIDGE_RECEIPT_COUNT_MISMATCH")
    sport = str(receipt.get("SPORT") or "").upper()
    mode = str(receipt.get("MODE") or "").upper()
    execution_id = str(receipt.get("EXECUTION_ID") or "")
    if not sport or not mode or not execution_id:
        raise OpenAISelectorBridgeError("OPENAI_BRIDGE_RECEIPT_IDENTITY_MISSING")
    context = dict(receipt.get("CONTEXT") or {})
    caller = response_caller or call_responses

    checkpoint_root = output_dir / ".apex_openai_selector" / freeze
    checkpoint_root.mkdir(parents=True, exist_ok=True)
    manifest_path = checkpoint_root / "manifest.json"
    manifest = {
        "PATCH_ID": PATCH_ID,
        "CANDIDATE_FREEZE_SHA256": freeze,
        "CANDIDATE_COUNT": candidate_count,
        "SPORT": sport, "MODE": mode, "EXECUTION_ID": execution_id,
        "MODEL": model, "SCREEN_MODEL": screen_model, "REASONING_EFFORT": reasoning_effort,
        "CHUNK_ROWS": int(chunk_rows), "CHUNK_MAX_CHARS": int(chunk_max_chars), "CHUNK_KEEP": int(chunk_keep),
        "BOARD_SIZE": int(board_size), "POSTLOCK_FORWARD_INPUT": False,
        "ENGINE_UPSTREAM_AUTHORITY": True, "OPENAI_TERMINAL_AUTHORITY_ONLY": True,
    }
    if manifest_path.exists():
        existing=json.loads(manifest_path.read_text(encoding="utf-8"))
        stable={k:manifest[k] for k in manifest if k not in {}}
        if any(str(existing.get(k)) != str(v) for k,v in stable.items()):
            raise OpenAISelectorBridgeError("OPENAI_BRIDGE_CHECKPOINT_CONFIG_MISMATCH")
    else:
        _atomic_json(manifest_path, manifest)

    total_reviewed=0; advancers: list[dict[str, Any]]=[]; chunk_count=0
    for chunk_index, rows in enumerate(_physical_chunks(_iter_compact_rows(candidate_file), max_rows=chunk_rows, max_chars=chunk_max_chars), start=1):
        chunk_count += 1
        ids=[str(r["LINEUP_ID"]) for r in rows]; idset=set(ids)
        if len(ids)!=len(idset):
            raise OpenAISelectorBridgeError("OPENAI_BRIDGE_DUPLICATE_ID_INSIDE_CHUNK")
        input_obj={
            "task":"REVIEW_COMPLETE_PHYSICAL_CHUNK_AND_ADVANCE_CHAMPIONSHIP_CANDIDATES",
            "candidate_freeze_sha256":freeze,
            "sport":sport,"mode":mode,"execution_id":execution_id,
            "context":context,
            "chunk_index":chunk_index,
            "chunk_candidate_count":len(rows),
            "advance_at_most":min(int(chunk_keep),len(rows)),
            "candidates":rows,
        }
        input_hash=_sha(input_obj)
        cp=checkpoint_root/f"chunk_{chunk_index:05d}.json"
        obj=None
        if cp.exists():
            saved=json.loads(cp.read_text(encoding="utf-8"))
            if (saved.get("INPUT_SHA256")==input_hash and saved.get("MODEL")==screen_model and
                saved.get("REASONING_EFFORT")==reasoning_effort and int(saved.get("REVIEWED_COUNT",0))==len(rows)):
                obj=saved.get("STRUCTURED_OUTPUT")
        if obj is None:
            payload=_response_payload(
                model=screen_model,reasoning_effort=reasoning_effort,
                instructions=SYSTEM_INSTRUCTIONS + "\nThis is a physical chunk of the frozen surface. Review EVERY supplied candidate before choosing advancers. Advancing a row is an AI judgment, not a code-side prune. Preserve distinct championship families and exact-role siblings when evidence is genuinely unresolved.",
                user_payload=input_obj,schema_name="apex_terminal_chunk_advancers",schema=_chunk_schema(min(int(chunk_keep),len(rows))),
            )
            resp=caller(payload, timeout=timeout, max_retries=max_retries)
            obj=_parse_structured(resp)
            picks=_validate_pick_list(obj,key="advancers",allowed_ids=idset,freeze=freeze)
            saved={
                "PATCH_ID":PATCH_ID,"INPUT_SHA256":input_hash,"MODEL":screen_model,"REASONING_EFFORT":reasoning_effort,
                "REVIEWED_COUNT":len(rows),"REVIEWED_IDS_SHA256":_sha(ids),"STRUCTURED_OUTPUT":obj,
                "USAGE":dict(resp.get("usage") or {}),
            }
            _atomic_json(cp,saved)
        picks=_validate_pick_list(obj,key="advancers",allowed_ids=idset,freeze=freeze)
        advancers.extend(picks); total_reviewed += len(rows)
        print(json.dumps({"OPENAI_CHUNK_COMPLETE":chunk_index,"REVIEWED":len(rows),"CUMULATIVE_REVIEWED":total_reviewed,"ADVANCERS":len(picks)},separators=(",",":")), flush=True)

    if total_reviewed != candidate_count:
        raise OpenAISelectorBridgeError(f"OPENAI_BRIDGE_INCOMPLETE_COVERAGE:{total_reviewed}:{candidate_count}")
    # De-duplicate only identical lineup IDs advanced by the AI; candidate rows belong to one physical chunk,
    # so duplicates here would indicate corrupt checkpoints rather than portfolio pruning.
    ordered_ids=[]; reason_by_id={}
    for p in advancers:
        lid=p["lineup_id"]
        if lid not in reason_by_id:
            ordered_ids.append(lid); reason_by_id[lid]=p["reason_codes"]
    if len(ordered_ids) < board_size:
        raise OpenAISelectorBridgeError(f"OPENAI_BRIDGE_TOO_FEW_FINALISTS:{len(ordered_ids)}:{board_size}")

    finalist_rows = terminal_ai.load_selected_candidate_rows(candidate_file, ordered_ids)
    finalist_compact=[_compact_row(r) for r in finalist_rows]
    final_input={
        "task":"SELECT_FINAL_APEX_TOP5_FROM_AI_REVIEWED_CHAMPIONSHIP_FINALISTS",
        "candidate_freeze_sha256":freeze,"sport":sport,"mode":mode,"execution_id":execution_id,
        "context":context,"source_candidate_count":candidate_count,"physical_chunks_reviewed":chunk_count,
        "all_source_candidates_reviewed":True,"board_size":int(board_size),"finalists":finalist_compact,
    }
    final_hash=_sha(final_input); final_cp=checkpoint_root/"final_merge.json"; final_obj=None; final_resp={}
    if final_cp.exists():
        saved=json.loads(final_cp.read_text(encoding="utf-8"))
        if saved.get("INPUT_SHA256")==final_hash and saved.get("MODEL")==model and saved.get("REASONING_EFFORT")==reasoning_effort:
            final_obj=saved.get("STRUCTURED_OUTPUT")
    finalist_ids=set(ordered_ids)
    if final_obj is None:
        payload=_response_payload(
            model=model,reasoning_effort=reasoning_effort,
            instructions=SYSTEM_INSTRUCTIONS + "\nAll source candidates were already reviewed by the AI in persisted chunks. These finalists are the AI-advanced championship pool. Select the final board now. Do not diversify merely for appearance. For each selected lineup, give evidence-based allowed reason codes.",
            user_payload=final_input,schema_name="apex_terminal_final_decision",schema=_final_schema(board_size),
        )
        final_resp=dict(caller(payload, timeout=timeout, max_retries=max_retries))
        final_obj=_parse_structured(final_resp)
        _validate_pick_list(final_obj,key="selections",allowed_ids=finalist_ids,freeze=freeze,exact_count=board_size)
        _atomic_json(final_cp,{"PATCH_ID":PATCH_ID,"INPUT_SHA256":final_hash,"MODEL":model,"REASONING_EFFORT":reasoning_effort,
                               "STRUCTURED_OUTPUT":final_obj,"USAGE":dict(final_resp.get("usage") or {})})
    selections=_validate_pick_list(final_obj,key="selections",allowed_ids=finalist_ids,freeze=freeze,exact_count=board_size)

    # The engine remains the formal validator/sealer. This file is exactly the existing durable handoff contract.
    decision={
        "patch_id":PATCH_ID,
        "candidate_freeze_sha256":freeze,
        "candidate_count":candidate_count,
        "all_candidates_reviewed":True,
        "reviewed_candidate_count":total_reviewed,
        "physical_chunk_count":chunk_count,
        "selector_model":model,
        "screen_model":screen_model,
        "reasoning_effort":reasoning_effort,
        "postlock_results_used":False,
        "ai_created_lineups":False,
        "selections":selections,
    }
    decision_path=_canonical_decision_path(output_dir,sport,mode,execution_id)
    _atomic_json(decision_path,decision)
    summary={
        "PATCH_ID":PATCH_ID,"STATUS":"PASS","DECISION_PATH":str(decision_path),
        "CANDIDATE_FREEZE_SHA256":freeze,"CANDIDATE_COUNT":candidate_count,
        "REVIEWED_CANDIDATES":total_reviewed,"PHYSICAL_CHUNKS":chunk_count,
        "AI_ADVANCED_FINALISTS":len(ordered_ids),"FINAL_BOARD_SIZE":len(selections),
        "MODEL":model,"SCREEN_MODEL":screen_model,"ENGINE_FORMAL_VALIDATION_REQUIRED":True,
        "NEXT_ACTION":"RERUN_SAME_PRODUCTION_COMMAND_TO_COMMIT_DECISION_VALIDATE_AND_SEAL",
    }
    _atomic_json(checkpoint_root/"bridge_receipt.json",summary)
    return summary


def main(argv: Sequence[str] | None = None) -> int:
    _load_local_env()
    ap=argparse.ArgumentParser(description=PATCH_ID)
    ap.add_argument("--candidate-file",required=True)
    ap.add_argument("--candidate-receipt",required=True)
    ap.add_argument("--output-dir",default="/mnt/data")
    ap.add_argument("--model",default=os.environ.get("APEX_OPENAI_SELECTOR_MODEL",DEFAULT_MODEL))
    ap.add_argument("--screen-model",default=os.environ.get("APEX_OPENAI_SCREEN_MODEL",os.environ.get("APEX_OPENAI_SELECTOR_MODEL",DEFAULT_MODEL)))
    ap.add_argument("--reasoning-effort",default=os.environ.get("APEX_OPENAI_REASONING_EFFORT",DEFAULT_REASONING_EFFORT),choices=["low","medium","high","xhigh","max"])
    ap.add_argument("--chunk-rows",type=int,default=int(os.environ.get("APEX_OPENAI_CHUNK_ROWS",DEFAULT_CHUNK_ROWS)))
    ap.add_argument("--chunk-max-chars",type=int,default=int(os.environ.get("APEX_OPENAI_CHUNK_MAX_CHARS",DEFAULT_CHUNK_MAX_CHARS)))
    ap.add_argument("--chunk-keep",type=int,default=int(os.environ.get("APEX_OPENAI_CHUNK_KEEP",DEFAULT_CHUNK_KEEP)))
    ap.add_argument("--timeout",type=float,default=float(os.environ.get("APEX_OPENAI_TIMEOUT_SECONDS",DEFAULT_TIMEOUT_SECONDS)))
    ap.add_argument("--max-retries",type=int,default=int(os.environ.get("APEX_OPENAI_MAX_RETRIES",DEFAULT_MAX_RETRIES)))
    ap.add_argument("--board-size",type=int,default=5)
    a=ap.parse_args(argv)
    try:
        out=run_bridge(candidate_file=Path(a.candidate_file),candidate_receipt=Path(a.candidate_receipt),output_dir=Path(a.output_dir),
                       model=a.model,screen_model=a.screen_model,reasoning_effort=a.reasoning_effort,
                       chunk_rows=a.chunk_rows,chunk_max_chars=a.chunk_max_chars,chunk_keep=a.chunk_keep,
                       timeout=a.timeout,max_retries=a.max_retries,board_size=a.board_size)
    except Exception as exc:
        print(json.dumps({"PATCH_ID":PATCH_ID,"STATUS":"FAIL","ERROR":f"{type(exc).__name__}:{exc}"},separators=(",",":")))
        return 2
    print(json.dumps(out,indent=2,sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
