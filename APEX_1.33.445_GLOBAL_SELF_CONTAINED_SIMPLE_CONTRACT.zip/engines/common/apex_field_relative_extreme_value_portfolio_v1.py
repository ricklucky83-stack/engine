from __future__ import annotations

"""Production field-relative extreme-value portfolio selector.

Sport runtimes own candidate birth, legality, opportunity simulation and the exact
contest field. This module owns only the final pre-lock portfolio decision.

The selector has two modes:
  * EXACT_COMMON_WORLD: caller supplies packed WIN / Top-0.1 / Top-1 event masks.
    Seats maximize incremental shared-world championship coverage.
  * FIELD_RELATIVE_PROXY: when masks are not exported to the terminal runner, use
    uncertainty-shrunk field-relative tail rates, tail quantiles, duplication risk,
    and lineup overlap to approximate marginal championship mass without inventing
    a projection-only scalar objective.

No post-lock results or realized contest ranks are valid inputs.
"""

from dataclasses import dataclass
from typing import Any, Mapping, Sequence
import math
import re
import numpy as np

PATCH_ID = "APEX_GLOBAL_FIELD_RELATIVE_EXTREME_VALUE_PORTFOLIO_SELECTOR_v1"
PRIMARY_OBJECTIVE = "MAXIMIZE_JOINT_PRELOCK_CHAMPIONSHIP_AND_TOP_0_1_FIELD_RELATIVE_COVERAGE"
EXACT_WORLD_WEIGHT_RATIO = (15, 10, 1)
MAX_DOMINANT_ONE_SWAP_FAMILY = 3
MIN_REQUIRED_METRIC_ROWS = 2

FORBIDDEN_FORWARD_FIELDS = {
    "CONTEST_RANK", "ACTUAL_FPTS", "REALIZED_FPTS", "POSTLOCK_SCORE",
    "WINNING_LINEUP", "TARGET_ACTUAL_SCORE", "FINAL_CONTEST_RANK",
    "REALIZED_SCORE", "ACTUAL_SCORE", "ACTUAL_RANK",
}

WIN_NAMES = ("MC_WIN_RATE", "WIN_RATE", "WIN_PROB", "P_WIN", "WIN")
TOP01_NAMES = ("MC_TOP_0_1_RATE", "TOP_0_1_RATE", "TOP01_RATE", "TOP_0_1", "P_TOP_0_1")
TOP1_NAMES = ("MC_TOP_1_RATE", "TOP_1_RATE", "TOP1_RATE", "TOP_1", "P_TOP_1")
TRIAL_NAMES = ("TRIALS", "MC_TRIALS", "SIM_TRIALS", "N_TRIALS")
P99_NAMES = ("CVAR99", "MC_CVAR99", "P99", "MC_P99")
P95_NAMES = ("P95", "MC_P95")
DUP_NAMES = ("EXPECTED_DUP", "EXPECTED_DUPES", "EXPECTED_DUPLICATES", "DUP_EXPECTED")
UNIQUE_NAMES = ("P_UNIQUE", "UNIQUE_PROB", "PROB_UNIQUE")
OWN_PRODUCT_NAMES = ("OWNERSHIP_PRODUCT", "PRODUCT_OWNERSHIP", "LINEUP_OWN_PRODUCT", "OWN_PRODUCT")
FIELD_SIZE_NAMES = ("FIELD_SIZE", "CONTEST_SIZE", "ENTRIES")


class ExtremeValueSelectorError(RuntimeError):
    pass


@dataclass(frozen=True)
class ExtremeValueSelection:
    source_indices: list[int]
    receipt: dict[str, Any]


def _norm_key(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")


def _num(x: Any, default: float = float("nan")) -> float:
    try:
        if isinstance(x, str):
            x = x.replace("%", "").replace("$", "").replace(",", "").strip()
        y = float(x)
        return y if math.isfinite(y) else default
    except Exception:
        return default


def _metric(row: Mapping[str, Any], names: Sequence[str]) -> float:
    cmap = {_norm_key(k): k for k in row}
    for name in names:
        key = cmap.get(_norm_key(name))
        if key is None:
            continue
        v = _num(row.get(key))
        if math.isfinite(v):
            return v
    return float("nan")


def _prob(row: Mapping[str, Any], names: Sequence[str]) -> float:
    cmap = {_norm_key(k): k for k in row}
    raw = None
    for name in names:
        key = cmap.get(_norm_key(name))
        if key is not None:
            raw = row.get(key)
            break
    if raw is None:
        return float("nan")
    is_pct_string = isinstance(raw, str) and "%" in raw
    v = _num(raw)
    if not math.isfinite(v) or v < 0:
        return float("nan")
    if is_pct_string:
        return min(1.0, v / 100.0)
    if v <= 1.0000001:
        return min(1.0, v)
    if v <= 100.0000001:
        return min(1.0, v / 100.0)
    # Counts must not be silently interpreted as probabilities.
    return float("nan")


def _trials(row: Mapping[str, Any]) -> int:
    v = _metric(row, TRIAL_NAMES)
    if not math.isfinite(v) or v <= 0:
        return 0
    return int(round(v))


def _posterior_mean(p: float, n: int, alpha: float = 0.5, beta: float = 0.5) -> float:
    if not math.isfinite(p):
        return 0.0
    p = min(1.0, max(0.0, p))
    if n <= 0:
        return p
    x = p * n
    return float((x + alpha) / (n + alpha + beta))


def _wilson_lcb(p: float, n: int, z: float = 1.6448536269514722) -> float:
    """One-sided ~95% Wilson lower confidence bound.

    When trial count is absent we deliberately widen uncertainty rather than
    pretending the point estimate is certain.
    """
    if not math.isfinite(p):
        return 0.0
    p = min(1.0, max(0.0, p))
    if n <= 0:
        return 0.5 * p
    denom = 1.0 + (z * z) / n
    center = p + (z * z) / (2.0 * n)
    rad = z * math.sqrt(max(0.0, p * (1.0 - p) / n + (z * z) / (4.0 * n * n)))
    return max(0.0, float((center - rad) / denom))


def _rank01(values: Sequence[float], *, higher_is_better: bool = True, missing: float = 0.0) -> np.ndarray:
    """Stable empirical rank in [0,1]; equal values get equal midrank."""
    a = np.asarray(values, dtype=float)
    valid = np.isfinite(a)
    out = np.full(len(a), float(missing), dtype=float)
    if not np.any(valid):
        return out
    vals = a[valid]
    if len(vals) == 1:
        out[np.flatnonzero(valid)[0]] = 1.0
        return out
    uniq = np.unique(vals)
    if len(uniq) == 1:
        out[valid] = 0.5
        return out
    order = np.argsort(uniq)
    mapping = {}
    for r, uidx in enumerate(order):
        q = r / (len(order) - 1)
        mapping[float(uniq[uidx])] = q if higher_is_better else 1.0 - q
    for i in np.flatnonzero(valid):
        out[i] = mapping[float(a[i])]
    return out


def _overlap_ratio(a: Sequence[str], b: Sequence[str]) -> float:
    sa = {str(x).casefold() for x in a if str(x).strip()}
    sb = {str(x).casefold() for x in b if str(x).strip()}
    denom = max(1, min(len(sa), len(sb)))
    return len(sa & sb) / denom


def _one_swap_family(a: Sequence[str], b: Sequence[str]) -> bool:
    n = min(len(set(a)), len(set(b)))
    if n <= 1:
        return False
    return _overlap_ratio(a, b) >= (n - 1) / n


def _family_components(players: Sequence[Sequence[str]]) -> tuple[list[list[int]], list[int]]:
    n = len(players)
    adj = [[] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            if _one_swap_family(players[i], players[j]):
                adj[i].append(j); adj[j].append(i)
    seen: set[int] = set(); comps: list[list[int]] = []; labels = [-1] * n
    for i in range(n):
        if i in seen:
            continue
        stack = [i]; seen.add(i); comp: list[int] = []
        while stack:
            x = stack.pop(); comp.append(x)
            for y in adj[x]:
                if y not in seen:
                    seen.add(y); stack.append(y)
        comp.sort(); cid = len(comps)
        for x in comp: labels[x] = cid
        comps.append(comp)
    return comps, labels


def validate_prelock_rows(rows: Sequence[Mapping[str, Any]]) -> None:
    if not rows:
        raise ExtremeValueSelectorError("RUN_INVALID:EXTREME_VALUE_SELECTOR_EMPTY_ROWS")
    forbidden = sorted({_norm_key(k) for r in rows for k in r} & FORBIDDEN_FORWARD_FIELDS)
    if forbidden:
        raise ExtremeValueSelectorError(
            "RUN_INVALID:POSTLOCK_FIELDS_ENTERED_FIELD_RELATIVE_SELECTOR:" + ",".join(forbidden)
        )


def has_sufficient_field_relative_metrics(rows: Sequence[Mapping[str, Any]]) -> bool:
    if not rows:
        return False
    count = 0
    for r in rows:
        if any(math.isfinite(_prob(r, names)) for names in (WIN_NAMES, TOP01_NAMES, TOP1_NAMES)):
            count += 1
    return count >= min(MIN_REQUIRED_METRIC_ROWS, len(rows))


def _extract_features(rows: Sequence[Mapping[str, Any]]) -> dict[str, np.ndarray]:
    n = len(rows)
    win = np.array([_prob(r, WIN_NAMES) for r in rows], float)
    top01 = np.array([_prob(r, TOP01_NAMES) for r in rows], float)
    top1 = np.array([_prob(r, TOP1_NAMES) for r in rows], float)
    trials = np.array([_trials(r) for r in rows], int)
    p99 = np.array([_metric(r, P99_NAMES) for r in rows], float)
    p95 = np.array([_metric(r, P95_NAMES) for r in rows], float)
    dup = np.array([_metric(r, DUP_NAMES) for r in rows], float)
    p_unique = np.array([_prob(r, UNIQUE_NAMES) for r in rows], float)
    own_prod = np.array([_metric(r, OWN_PRODUCT_NAMES) for r in rows], float)
    field_size = np.array([_metric(r, FIELD_SIZE_NAMES) for r in rows], float)

    win_post = np.array([_posterior_mean(p, int(t)) for p, t in zip(win, trials)], float)
    top01_post = np.array([_posterior_mean(p, int(t)) for p, t in zip(top01, trials)], float)
    top1_post = np.array([_posterior_mean(p, int(t)) for p, t in zip(top1, trials)], float)
    win_lcb = np.array([_wilson_lcb(p, int(t)) for p, t in zip(win, trials)], float)
    top01_lcb = np.array([_wilson_lcb(p, int(t)) for p, t in zip(top01, trials)], float)
    top1_lcb = np.array([_wilson_lcb(p, int(t)) for p, t in zip(top1, trials)], float)

    # Use direct uniqueness evidence first. If absent, expected duplicates are the
    # best field-density measure. Ownership product is only a last-resort proxy.
    uniqueness = np.full(n, np.nan, float)
    for i in range(n):
        if math.isfinite(p_unique[i]):
            uniqueness[i] = p_unique[i]
        elif math.isfinite(dup[i]) and dup[i] >= 0:
            uniqueness[i] = 1.0 / (1.0 + dup[i])
        elif math.isfinite(own_prod[i]) and own_prod[i] > 0:
            op = own_prod[i]
            if op > 1.0 and op <= 100.0:
                op /= 100.0
            if op > 0:
                fs = field_size[i] if math.isfinite(field_size[i]) and field_size[i] > 0 else 1.0
                uniqueness[i] = 1.0 / (1.0 + fs * op)

    # Cross-lineup empirical ranks avoid mixing sport-specific point scales.
    win_rank = _rank01(win_lcb)
    top01_rank = _rank01(top01_lcb)
    top1_rank = _rank01(top1_lcb)
    tail_primary = np.where(np.isfinite(p99), p99, p95)
    tail_rank = _rank01(tail_primary)
    unique_rank = _rank01(uniqueness, missing=0.5)

    available = {
        "win": int(np.sum(np.isfinite(win))),
        "top01": int(np.sum(np.isfinite(top01))),
        "top1": int(np.sum(np.isfinite(top1))),
        "tail": int(np.sum(np.isfinite(tail_primary))),
        "uniqueness": int(np.sum(np.isfinite(uniqueness))),
        "trials": int(np.sum(trials > 0)),
    }

    # Championship outcomes stay primary. Tail and uniqueness are tie/robustness
    # terms, not substitutes for field-relative simulated finishes.
    robust = (
        0.44 * win_rank
        + 0.31 * top01_rank
        + 0.10 * top1_rank
        + 0.10 * tail_rank
        + 0.05 * unique_rank
    )
    if available["win"] == 0:
        robust = 0.58 * top01_rank + 0.17 * top1_rank + 0.15 * tail_rank + 0.10 * unique_rank
    if available["win"] == 0 and available["top01"] == 0:
        robust = 0.55 * top1_rank + 0.30 * tail_rank + 0.15 * unique_rank

    return {
        "win": win, "top01": top01, "top1": top1, "trials": trials,
        "win_post": win_post, "top01_post": top01_post, "top1_post": top1_post,
        "win_lcb": win_lcb, "top01_lcb": top01_lcb, "top1_lcb": top1_lcb,
        "p99": p99, "p95": p95, "dup": dup, "uniqueness": uniqueness,
        "robust": robust, "available": available,
    }


_POP8 = np.unpackbits(np.arange(256, dtype=np.uint8)[:, None], axis=1).sum(axis=1).astype(np.int16)


def _validate_bits(name: str, bits: np.ndarray, n: int, worlds: int) -> np.ndarray:
    arr = np.asarray(bits)
    expected = (int(worlds) + 7) // 8
    if arr.dtype != np.uint8 or arr.ndim != 2 or arr.shape != (n, expected):
        raise ExtremeValueSelectorError(f"{name}_BITS_SHAPE_OR_DTYPE_INVALID:{arr.dtype}:{arr.shape}:{n}:{expected}")
    return arr


def _gain(bits: np.ndarray, idx: int, covered: np.ndarray) -> int:
    inv = np.bitwise_not(covered)
    return int(_POP8[np.bitwise_and(bits[int(idx)], inv)].sum())


def _union_hits(bits: np.ndarray, positions: Sequence[int]) -> int:
    covered = np.zeros(bits.shape[1], dtype=np.uint8)
    for i in positions:
        covered |= bits[int(i)]
    return int(_POP8[covered].sum())


def select_portfolio_rows(
    rows: Sequence[Mapping[str, Any]],
    *,
    players: Sequence[Sequence[str]],
    board_size: int = 5,
    protected_indices: Sequence[int] | None = None,
    protected_priority: Mapping[int, float] | None = None,
    win_bits: np.ndarray | None = None,
    top01_bits: np.ndarray | None = None,
    top1_bits: np.ndarray | None = None,
    common_worlds: int | None = None,
    dominant_family_max: int = MAX_DOMINANT_ONE_SWAP_FAMILY,
) -> ExtremeValueSelection:
    validate_prelock_rows(rows)
    n = len(rows)
    if len(players) != n:
        raise ExtremeValueSelectorError(f"PLAYER_VECTOR_LENGTH_MISMATCH:{len(players)}:{n}")
    target = min(max(1, int(board_size)), n)
    protected = sorted({int(i) for i in (protected_indices or []) if 0 <= int(i) < n})
    pprio = {int(k): float(v) for k, v in (protected_priority or {}).items()}
    features = _extract_features(rows)
    comps, family_label = _family_components(players)

    exact = all(x is not None for x in (win_bits, top01_bits, top1_bits))
    if any(x is not None for x in (win_bits, top01_bits, top1_bits)) and not exact:
        raise ExtremeValueSelectorError("COMMON_WORLD_BITS_MUST_BE_ALL_OR_NONE")
    if exact:
        if common_worlds is None or int(common_worlds) <= 0:
            raise ExtremeValueSelectorError("COMMON_WORLDS_REQUIRED_WITH_EVENT_BITS")
        worlds = int(common_worlds)
        wb = _validate_bits("WIN", np.asarray(win_bits), n, worlds)
        b01 = _validate_bits("TOP01", np.asarray(top01_bits), n, worlds)
        b1 = _validate_bits("TOP1", np.asarray(top1_bits), n, worlds)
        covered_w = np.zeros(wb.shape[1], dtype=np.uint8)
        covered_01 = np.zeros(b01.shape[1], dtype=np.uint8)
        covered_1 = np.zeros(b1.shape[1], dtype=np.uint8)
    else:
        worlds = 0; wb = b01 = b1 = None
        covered_w = covered_01 = covered_1 = None

    selected: list[int] = []
    marginal_receipt: list[dict[str, Any]] = []

    # Protected sport-native lanes remain first-class. Within the protected set,
    # rank by explicit protection priority then robust field-relative evidence.
    for i in sorted(protected, key=lambda j: (-pprio.get(j, 0.0), -features["robust"][j], j)):
        if len(selected) >= target:
            break
        selected.append(i)
        if exact:
            gw = _gain(wb, i, covered_w); g01 = _gain(b01, i, covered_01); g1 = _gain(b1, i, covered_1)
            covered_w |= wb[i]; covered_01 |= b01[i]; covered_1 |= b1[i]
        else:
            gw = g01 = g1 = None
        marginal_receipt.append({"SOURCE_INDEX": i + 1, "REASON": "SPORT_NATIVE_PROTECTED", "WIN_GAIN": gw, "TOP01_GAIN": g01, "TOP1_GAIN": g1})

    while len(selected) < target:
        pool = [i for i in range(n) if i not in selected]
        if not pool:
            break

        # Hard guard against five copies of one one-swap family. If alternatives
        # exist, no family may occupy more than the configured bounded core share.
        if selected:
            fam_counts = {f: sum(1 for j in selected if family_label[j] == f) for f in set(family_label)}
            constrained = [i for i in pool if fam_counts.get(family_label[i], 0) < int(dominant_family_max)]
            if constrained:
                pool = constrained

        def key(i: int) -> tuple[float, float, float, float, int]:
            max_sim = max((_overlap_ratio(players[i], players[j]) for j in selected), default=0.0)
            if exact:
                gw = _gain(wb, i, covered_w); g01 = _gain(b01, i, covered_01); g1 = _gain(b1, i, covered_1)
                exact_score = 15.0 * gw + 10.0 * g01 + 1.0 * g1
                # Exact marginal shared-world coverage is primary. Robust quality
                # and overlap only resolve equal/nearly-equal coverage.
                return (exact_score, features["robust"][i], 1.0 - max_sim, features["top01_lcb"][i], -i)
            # Proxy mode discounts redundant siblings but does not ban them: a
            # dominant championship family may still use up to three core seats.
            redundancy_discount = 1.0 - 0.62 * (max_sim ** 2)
            proxy = features["robust"][i] * redundancy_discount
            return (proxy, features["robust"][i], 1.0 - max_sim, features["top01_lcb"][i], -i)

        i = max(pool, key=key)
        max_sim = max((_overlap_ratio(players[i], players[j]) for j in selected), default=0.0)
        if exact:
            gw = _gain(wb, i, covered_w); g01 = _gain(b01, i, covered_01); g1 = _gain(b1, i, covered_1)
            covered_w |= wb[i]; covered_01 |= b01[i]; covered_1 |= b1[i]
        else:
            gw = g01 = g1 = None
        selected.append(i)
        marginal_receipt.append({
            "SOURCE_INDEX": i + 1,
            "REASON": "EXACT_COMMON_WORLD_MARGINAL" if exact else "FIELD_RELATIVE_PROXY_MARGINAL",
            "WIN_GAIN": gw, "TOP01_GAIN": g01, "TOP1_GAIN": g1,
            "ROBUST_SCORE": float(features["robust"][i]),
            "WIN_LCB": float(features["win_lcb"][i]),
            "TOP01_LCB": float(features["top01_lcb"][i]),
            "MAX_PLAYER_OVERLAP_RATIO": float(max_sim),
        })

    if len(selected) != target:
        raise ExtremeValueSelectorError(f"FIELD_RELATIVE_SELECTION_INCOMPLETE:{len(selected)}:{target}")

    selected_family_counts: dict[str, int] = {}
    for i in selected:
        k = str(family_label[i]); selected_family_counts[k] = selected_family_counts.get(k, 0) + 1

    receipt: dict[str, Any] = {
        "PATCH_ID": PATCH_ID,
        "PRIMARY_OBJECTIVE": PRIMARY_OBJECTIVE,
        "SELECTOR_MODE": "EXACT_COMMON_WORLD" if exact else "FIELD_RELATIVE_PROXY",
        "SOURCE_ROWS": n,
        "FINAL_BOARD_SIZE": target,
        "SELECTED_SOURCE_INDICES": [i + 1 for i in selected],
        "PROTECTED_SOURCE_INDICES": [i + 1 for i in protected],
        "POSTLOCK_RESULTS_USED": False,
        "PLAYER_NAME_CONSTANTS_USED": False,
        "MEAN_PROJECTION_PRIMARY_OBJECTIVE": False,
        "STATIC_MIQP_SURROGATE_PRIMARY_OBJECTIVE": False,
        "PRODUCT_OWNERSHIP_PRIMARY_OBJECTIVE": False,
        "DUPLICATION_FIELD_DENSITY_USED_WHEN_AVAILABLE": bool(features["available"]["uniqueness"]),
        "UNCERTAINTY_SHRINKAGE": "JEFFREYS_POSTERIOR_PLUS_ONE_SIDED_WILSON_LCB",
        "AVAILABLE_METRICS": dict(features["available"]),
        "DOMINANT_ONE_SWAP_FAMILY_MAX": int(dominant_family_max),
        "SELECTED_FAMILY_COUNTS": selected_family_counts,
        "MARGINAL_SELECTION_LEDGER": marginal_receipt,
        "EXACT_WORLD_WEIGHT_RATIO": list(EXACT_WORLD_WEIGHT_RATIO) if exact else None,
        "COMMON_WORLDS": int(worlds) if exact else None,
    }
    if exact:
        receipt.update({
            "SELECTED_WIN_UNION_HITS": _union_hits(wb, selected),
            "SELECTED_TOP01_UNION_HITS": _union_hits(b01, selected),
            "SELECTED_TOP1_UNION_HITS": _union_hits(b1, selected),
            "SELECTED_WIN_UNION_RATE": _union_hits(wb, selected) / max(1, worlds),
            "SELECTED_TOP01_UNION_RATE": _union_hits(b01, selected) / max(1, worlds),
            "SELECTED_TOP1_UNION_RATE": _union_hits(b1, selected) / max(1, worlds),
        })
    return ExtremeValueSelection(source_indices=selected, receipt=receipt)
