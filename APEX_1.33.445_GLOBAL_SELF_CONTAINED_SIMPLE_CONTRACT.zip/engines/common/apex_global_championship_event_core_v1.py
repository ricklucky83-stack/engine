from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict
import numpy as np

PATCH_ID = 'APEX_GLOBAL_CHAMPIONSHIP_EVENT_CORE_v1'
PRIORITY_CORE_FULL_RUN_QUALIFIED_ZERO_GAIN_PATCH_ID = 'APEX_GLOBAL_CHAMPIONSHIP_CORE_FULL_RUN_PREQUALIFIED_ZERO_SPARSE_GAIN_v1'

@dataclass(frozen=True)
class ChampionshipCoreResult:
    selected_local: np.ndarray
    core_local: np.ndarray
    satellite_local: np.ndarray
    receipt: dict


def _as_bool_matrix(events):
    x=np.asarray(events,dtype=bool)
    if x.ndim!=2 or x.shape[0]<1 or x.shape[1]<1:
        raise ValueError('CHAMPIONSHIP_EVENTS_MUST_BE_NONEMPTY_2D')
    return x


def _stable_argmax(vals, quality, candidate_ids):
    vals=np.asarray(vals,float); quality=np.asarray(quality,float); candidate_ids=np.asarray(candidate_ids)
    # Primary: objective. Secondary: frozen quality. Tertiary: deterministic candidate id.
    order=np.lexsort((candidate_ids, -quality, -vals))
    return int(order[0])


def select_championship_core(
    events,
    quality,
    candidate_ids=None,
    family_labels=None,
    core_size=5,
    max_board_size=10,
    min_satellite_gain_events=1,
    priority_satellite_mask=None,
    priority_core_mask=None,
    priority_core_limit=0,
    priority_core_groups=None,
    priority_core_total_limit=None,
    priority_core_min_gain_events=1,
):
    """Build an immutable Core-5, then add only positive-coverage satellites.

    `events[i,t]` is True when candidate i reaches the frozen trial-t
    championship boundary.  No realized/postlock result may be encoded here.

    The core objective is greedy marginal union coverage of championship trials.
    No blanket family/player correlation penalty is applied.  Correlated siblings
    are retained whenever they cover new championship worlds.
    """
    ev=_as_bool_matrix(events)
    n,T=ev.shape
    q=np.asarray(quality,float)
    if q.shape!=(n,): raise ValueError('QUALITY_SHAPE_MISMATCH')
    if candidate_ids is None: candidate_ids=np.arange(n,dtype=np.int64)
    ids=np.asarray(candidate_ids)
    if ids.shape!=(n,): raise ValueError('CANDIDATE_ID_SHAPE_MISMATCH')
    if len(np.unique(ids))!=n: raise ValueError('CANDIDATE_IDS_MUST_BE_UNIQUE')
    core_size=int(core_size); max_board_size=int(max_board_size)
    if core_size<1 or max_board_size<core_size: raise ValueError('INVALID_CORE_BOARD_SIZE')
    core_size=min(core_size,n); max_board_size=min(max_board_size,n)

    if family_labels is None: family_labels=np.asarray(['UNSPECIFIED']*n,object)
    fam=np.asarray(family_labels,object)
    if fam.shape!=(n,): raise ValueError('FAMILY_LABEL_SHAPE_MISMATCH')

    covered=np.zeros(T,dtype=bool)
    remaining=np.ones(n,dtype=bool)
    core=[]; core_gain=[]; priority_core=[]
    if priority_core_mask is None:
        pcore=np.zeros(n,dtype=bool)
    else:
        pcore=np.asarray(priority_core_mask,dtype=bool)
        if pcore.shape!=(n,): raise ValueError('PRIORITY_CORE_MASK_SHAPE_MISMATCH')
    pcore_limit=max(0,min(int(priority_core_limit),core_size))
    # Sport-specific prelock championship sentinels may claim a bounded number
    # of immutable Core seats. Ordered authority groups allow a proven native
    # structural authority to retain its seats before a newer generic/adjacent
    # authority is considered. The default still requires one new frozen
    # championship world. A sport-native high-confidence parlay may explicitly
    # set the minimum to zero only after full-run prelock qualification; this
    # never fabricates event coverage and identity/postlock truth cannot enter.
    priority_core_min_gain_events=max(0,int(priority_core_min_gain_events))
    group_specs=[]
    if priority_core_groups is not None:
        for spec in priority_core_groups:
            if len(spec)!=3: raise ValueError('PRIORITY_CORE_GROUP_SPEC_INVALID')
            label,mask,limit=spec
            mm=np.asarray(mask,dtype=bool)
            if mm.shape!=(n,): raise ValueError('PRIORITY_CORE_GROUP_MASK_SHAPE_MISMATCH')
            group_specs.append((str(label),mm,max(0,int(limit))))
        total_priority_limit=sum(x[2] for x in group_specs) if priority_core_total_limit is None else int(priority_core_total_limit)
        total_priority_limit=max(0,min(total_priority_limit,core_size))
    else:
        group_specs=[('DEFAULT',pcore,pcore_limit)] if pcore_limit>0 else []
        total_priority_limit=pcore_limit
    priority_group_receipt=[]
    for label,mask,limit in group_specs:
        chosen_group=[]
        for _ in range(limit):
            if len(priority_core)>=total_priority_limit: break
            eligible=np.flatnonzero(remaining & mask)
            if len(eligible)==0: break
            gains=np.count_nonzero(ev[eligible] & ~covered,axis=1)
            best_rel=_stable_argmax(gains,q[eligible],ids[eligible])
            best=int(eligible[best_rel]); gain=int(gains[best_rel])
            if gain<priority_core_min_gain_events: break
            core.append(best); core_gain.append(gain); priority_core.append(best); chosen_group.append(best)
            covered |= ev[best]; remaining[best]=False
        priority_group_receipt.append({'LABEL':label,'LIMIT':int(limit),'SELECTED_IDS':[int(ids[i]) for i in chosen_group]})
    while len(core)<core_size:
        eligible=np.flatnonzero(remaining)
        gains=np.count_nonzero(ev[eligible] & ~covered,axis=1)
        best_rel=_stable_argmax(gains,q[eligible],ids[eligible])
        best=int(eligible[best_rel])
        gain=int(gains[best_rel])
        core.append(best); core_gain.append(gain)
        covered |= ev[best]; remaining[best]=False

    core_covered=covered.copy()
    satellites=[]; satellite_gain=[]; priority_satellites=[]
    if priority_satellite_mask is None:
        priority=np.zeros(n,dtype=bool)
    else:
        priority=np.asarray(priority_satellite_mask,dtype=bool)
        if priority.shape!=(n,): raise ValueError('PRIORITY_SATELLITE_MASK_SHAPE_MISMATCH')
    # Core is immutable.  Uncertainty-frontier sentinels may consume satellite
    # seats only when they add new championship worlds; they never displace core.
    for best in np.flatnonzero(priority & remaining):
        if len(core)+len(satellites)>=max_board_size: break
        gain=int(np.count_nonzero(ev[int(best)] & ~covered))
        if gain<int(min_satellite_gain_events): continue
        satellites.append(int(best)); satellite_gain.append(gain); priority_satellites.append(int(best))
        covered |= ev[int(best)]; remaining[int(best)]=False
    while len(core)+len(satellites)<max_board_size:
        eligible=np.flatnonzero(remaining)
        if len(eligible)==0: break
        gains=np.count_nonzero(ev[eligible] & ~covered,axis=1)
        best_rel=_stable_argmax(gains,q[eligible],ids[eligible])
        best=int(eligible[best_rel]); gain=int(gains[best_rel])
        if gain<int(min_satellite_gain_events): break
        satellites.append(best); satellite_gain.append(gain)
        covered |= ev[best]; remaining[best]=False

    # Family championship mass: union probability of all candidate events in family.
    family_mass={}
    family_split_stability={}
    family_top_event_candidates={}
    groups=defaultdict(list)
    for i,label in enumerate(fam.tolist()): groups[str(label)].append(i)
    h=T//2
    for label,idx in groups.items():
        u=np.any(ev[np.asarray(idx,int)],axis=0)
        family_mass[label]=float(u.mean())
        if h>=1 and T-h>=1:
            a=float(u[:h].mean()); b=float(u[h:].mean())
            family_split_stability[label]={'HALF_A':a,'HALF_B':b,'ABS_DELTA':abs(a-b)}
        else:
            family_split_stability[label]={'HALF_A':None,'HALF_B':None,'ABS_DELTA':None}
        ii=np.asarray(idx,int)
        cnt=np.count_nonzero(ev[ii],axis=1)
        ord_local=np.lexsort((ids[ii],-q[ii],-cnt))[:10]
        family_top_event_candidates[label]=[{'ID':int(ids[ii[j]]),'EVENTS':int(cnt[j]),'QUALITY':float(q[ii[j]])} for j in ord_local]

    selected=np.asarray(core+satellites,dtype=np.int32)
    core_arr=np.asarray(core,dtype=np.int32); sat_arr=np.asarray(satellites,dtype=np.int32)
    receipt={
        'PATCH_ID':PATCH_ID,
        'OBJECTIVE':'P_ANY_BOARD_LINEUP_CROSSES_FROZEN_CHAMPIONSHIP_BOUNDARY',
        'TRIALS':int(T),
        'CANDIDATES_REVIEWED':int(n),
        'CORE_SIZE':int(len(core_arr)),
        'CORE_FROZEN':True,
        'CORE_IDS':[int(ids[i]) for i in core_arr],
        'PRIORITY_CORE_IDS':[int(ids[i]) for i in priority_core],
        'PRIORITY_CORE_LIMIT':int(total_priority_limit),'PRIORITY_CORE_MIN_GAIN_EVENTS':int(priority_core_min_gain_events),'PRIORITY_CORE_ZERO_GAIN_OVERRIDE_PATCH_ID':(PRIORITY_CORE_FULL_RUN_QUALIFIED_ZERO_GAIN_PATCH_ID if priority_core_min_gain_events==0 else None),
        'PRIORITY_CORE_GROUPS':priority_group_receipt,
        'CORE_MARGINAL_GAIN_EVENTS':list(map(int,core_gain)),
        'CORE_UNION_COVERAGE':float(core_covered.mean()),
        'SATELLITE_COUNT':int(len(sat_arr)),
        'PRIORITY_SATELLITE_IDS':[int(ids[i]) for i in priority_satellites],
        'SATELLITE_IDS':[int(ids[i]) for i in sat_arr],
        'SATELLITE_MARGINAL_GAIN_EVENTS':list(map(int,satellite_gain)),
        'FINAL_BOARD_SIZE':int(len(selected)),
        'FINAL_UNION_COVERAGE':float(covered.mean()),
        'SATELLITES_CAN_DISPLACE_CORE':False,
        'BLANKET_CORRELATION_PENALTY':False,
        'HARD_FAMILY_DIVERSIFICATION_QUOTA':False,
        'MIN_SATELLITE_GAIN_EVENTS':int(min_satellite_gain_events),
        'FAMILY_CHAMPIONSHIP_MASS':family_mass,
        'FAMILY_SPLIT_HALF_STABILITY':family_split_stability,
        'FAMILY_TOP_EVENT_CANDIDATES':family_top_event_candidates,
        'POSTLOCK_RESULTS_USED':False,
    }
    return ChampionshipCoreResult(selected,core_arr,sat_arr,receipt)
