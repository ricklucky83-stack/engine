from __future__ import annotations

"""Global APEX doctrine: Monte Carlo metrics are evidence, never literal truth.

This module is intentionally sport-agnostic. It converts every supplied metric to a
within-slate percentile before aggregation. Cross-world recurrence, pairwise strength,
world breadth and stability are primary. Raw MC tail/rank outputs remain secondary
relative evidence. Disagreement is a penalty rather than a hard rejection.
"""

from dataclasses import dataclass
from typing import Any, Mapping
import numpy as np

PATCH_ID = "APEX_GLOBAL_MC_METRICS_SIGNAL_NOT_TRUTH_v1"
MC_METRICS_ROLE = "SIGNAL_NOT_TRUTH"
COMPARISON_SCOPE = "WITHIN_SLATE_ONLY"
POSTLOCK_AUTHORITY = False

PRIMARY_WEIGHTS = {
    "CROSS_WORLD_RECURRENCE": 0.22,
    "PAIRWISE_STRENGTH": 0.18,
    "WORLD_BREADTH": 0.15,
    "RANK_STABILITY": 0.07,
    "STABLE_TAIL_PRESENCE": 0.10,
}
SECONDARY_GROUP_WEIGHT = 0.22
CONTEXT_WEIGHTS = {
    "STRUCTURE_CONTEXT": 0.04,
    "NEIGHBORHOOD_CONTEXT": 0.02,
}
DISAGREEMENT_PENALTY_WEIGHT = 0.08
SECONDARY_INTERNAL_WEIGHTS = {
    "REL_WIN": 0.18,
    "REL_TOP01": 0.22,
    "REL_TOP1_OR_TOP10": 0.10,
    "REL_P95": 0.18,
    "REL_P99": 0.22,
    "REL_EXPECTED_RANK": 0.05,
    "REL_MEDIAN_RANK": 0.03,
    "REL_P90_RANK": 0.02,
}


class MCSignalDoctrineError(RuntimeError):
    pass


def _as_array(x: Any, n: int | None = None) -> np.ndarray:
    if x is None:
        if n is None:
            raise MCSignalDoctrineError("MC_SIGNAL_EMPTY")
        return np.full(n, np.nan, dtype=np.float64)
    a = np.asarray(x, dtype=np.float64)
    if a.ndim == 0:
        if n is None:
            n = 1
        a = np.full(n, float(a), dtype=np.float64)
    if n is not None and len(a) != n:
        raise MCSignalDoctrineError(f"MC_SIGNAL_LENGTH_MISMATCH:{len(a)}:{n}")
    return a


def percentile(a: Any, *, higher: bool = True, n: int | None = None) -> np.ndarray:
    x = _as_array(a, n)
    out = np.full(len(x), np.nan, dtype=np.float64)
    good = np.flatnonzero(np.isfinite(x))
    if len(good) == 0:
        return out
    vals = x[good]
    order = np.argsort(vals, kind="mergesort")
    ranks = np.empty(len(good), dtype=np.float64)
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and vals[order[j]] == vals[order[i]]:
            j += 1
        avg = ((i + j - 1) / 2.0 + 1.0) / len(order)
        ranks[order[i:j]] = avg
        i = j
    out[good] = ranks if higher else (1.0 - ranks + 1.0 / len(order))
    return out


def _blend(parts: list[tuple[np.ndarray, float]], n: int, default: float = 0.5) -> np.ndarray:
    num = np.zeros(n, dtype=np.float64)
    den = np.zeros(n, dtype=np.float64)
    for arr, weight in parts:
        good = np.isfinite(arr)
        num[good] += arr[good] * float(weight)
        den[good] += float(weight)
    return np.divide(num, den, out=np.full(n, default, dtype=np.float64), where=den > 0)


@dataclass(frozen=True)
class DoctrineResult:
    score: np.ndarray
    primary_score: np.ndarray
    secondary_score: np.ndarray
    disagreement: np.ndarray
    channels: dict[str, np.ndarray]
    receipt: dict[str, Any]


def score_surface(
    *,
    cross_world_recurrence: Any,
    pairwise_strength: Any,
    world_breadth: Any,
    rank_stability: Any,
    stable_tail_presence: Any,
    win: Any = None,
    top01: Any = None,
    top1_or_top10: Any = None,
    p95: Any = None,
    p99: Any = None,
    expected_rank: Any = None,
    median_rank: Any = None,
    rank_p90: Any = None,
    structure_context: Any = None,
    neighborhood_context: Any = None,
    stability_higher_is_better: bool = True,
) -> DoctrineResult:
    base = _as_array(cross_world_recurrence)
    n = len(base)
    arr = lambda x: _as_array(x, n)

    channels = {
        "RECURRENCE_PCTL": percentile(base, n=n),
        "PAIRWISE_PCTL": percentile(arr(pairwise_strength), n=n),
        "WORLD_BREADTH_PCTL": percentile(arr(world_breadth), n=n),
        "STABILITY_PCTL": percentile(arr(rank_stability), higher=stability_higher_is_better, n=n),
        "STABLE_TAIL_PCTL": percentile(arr(stable_tail_presence), n=n),
        "WIN_PCTL": percentile(arr(win), n=n),
        "TOP01_PCTL": percentile(arr(top01), n=n),
        "TOP1_OR_TOP10_PCTL": percentile(arr(top1_or_top10), n=n),
        "P95_PCTL": percentile(arr(p95), n=n),
        "P99_PCTL": percentile(arr(p99), n=n),
        "EXPECTED_RANK_PCTL": percentile(arr(expected_rank), higher=False, n=n),
        "MEDIAN_RANK_PCTL": percentile(arr(median_rank), higher=False, n=n),
        "P90_RANK_PCTL": percentile(arr(rank_p90), higher=False, n=n),
        "STRUCTURE_PCTL": percentile(arr(structure_context), n=n),
        "NEIGHBORHOOD_PCTL": percentile(arr(neighborhood_context), n=n),
    }

    primary = np.zeros(n, dtype=np.float64)
    for name, weight in PRIMARY_WEIGHTS.items():
        key = {
            "CROSS_WORLD_RECURRENCE": "RECURRENCE_PCTL",
            "PAIRWISE_STRENGTH": "PAIRWISE_PCTL",
            "WORLD_BREADTH": "WORLD_BREADTH_PCTL",
            "RANK_STABILITY": "STABILITY_PCTL",
            "STABLE_TAIL_PRESENCE": "STABLE_TAIL_PCTL",
        }[name]
        a = channels[key]
        primary += np.nan_to_num(a, nan=0.5) * float(weight)

    secondary_raw = np.zeros(n, dtype=np.float64)
    for name, weight in SECONDARY_INTERNAL_WEIGHTS.items():
        key = {
            "REL_WIN": "WIN_PCTL",
            "REL_TOP01": "TOP01_PCTL",
            "REL_TOP1_OR_TOP10": "TOP1_OR_TOP10_PCTL",
            "REL_P95": "P95_PCTL",
            "REL_P99": "P99_PCTL",
            "REL_EXPECTED_RANK": "EXPECTED_RANK_PCTL",
            "REL_MEDIAN_RANK": "MEDIAN_RANK_PCTL",
            "REL_P90_RANK": "P90_RANK_PCTL",
        }[name]
        secondary_raw += np.nan_to_num(channels[key], nan=0.5) * float(weight)
    secondary = SECONDARY_GROUP_WEIGHT * secondary_raw

    context = (
        CONTEXT_WEIGHTS["STRUCTURE_CONTEXT"] * np.nan_to_num(channels["STRUCTURE_PCTL"], nan=0.5)
        + CONTEXT_WEIGHTS["NEIGHBORHOOD_CONTEXT"] * np.nan_to_num(channels["NEIGHBORHOOD_PCTL"], nan=0.5)
    )

    disagreement_stack = np.vstack([
        channels["RECURRENCE_PCTL"], channels["PAIRWISE_PCTL"], channels["WORLD_BREADTH_PCTL"],
        channels["STABILITY_PCTL"], channels["STABLE_TAIL_PCTL"], channels["WIN_PCTL"],
        channels["TOP01_PCTL"], channels["P99_PCTL"], channels["EXPECTED_RANK_PCTL"],
    ])
    disagreement = np.nanstd(disagreement_stack, axis=0)
    disagreement = np.nan_to_num(disagreement, nan=0.0, posinf=1.0, neginf=1.0)

    score = primary + secondary + context - DISAGREEMENT_PENALTY_WEIGHT * disagreement
    receipt = {
        "PATCH_ID": PATCH_ID,
        "MC_METRICS_ROLE": MC_METRICS_ROLE,
        "RAW_MC_LITERAL_AUTHORITY": False,
        "WITHIN_SLATE_PERCENTILE_NORMALIZATION": True,
        "PRIMARY_WEIGHTS": dict(PRIMARY_WEIGHTS),
        "SECONDARY_GROUP_WEIGHT": SECONDARY_GROUP_WEIGHT,
        "SECONDARY_INTERNAL_WEIGHTS": dict(SECONDARY_INTERNAL_WEIGHTS),
        "CONTEXT_WEIGHTS": dict(CONTEXT_WEIGHTS),
        "DISAGREEMENT_PENALTY_WEIGHT": DISAGREEMENT_PENALTY_WEIGHT,
        "POSTLOCK_AUTHORITY": POSTLOCK_AUTHORITY,
    }
    return DoctrineResult(score=score, primary_score=primary, secondary_score=secondary,
                          disagreement=disagreement, channels=channels, receipt=receipt)
