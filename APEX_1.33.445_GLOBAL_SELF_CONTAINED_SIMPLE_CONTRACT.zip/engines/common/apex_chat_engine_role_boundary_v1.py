from __future__ import annotations

import os
from pathlib import Path
from typing import Sequence

PATCH_ID = 'APEX_GLOBAL_CHAT_TRIGGER_REPORT_ONLY_BOUNDARY_v2'
CHAT_ROLE = 'TRIGGER_REPORT_ONLY'
LIVE_RUN_CONTROL_POLICY = 'ENGINE_OWNS_FULL_PROCESS_LIFECYCLE'
LATENCY_AUTHORITY = 'NONE'
TELEMETRY_AUTHORITY = 'READ_ONLY'

# Chat may trigger the integrated production runner and report its sealed result.
# It has no selector authority and may not operate engine internals directly.
# The production runner resolves the authoritative sport entrypoint from the bundled
# registry; no bootstrap, pointer, or external hash gate supplies execution authority.
FORBIDDEN_NAME_TOKENS = (
    'raw_pool_runtime',
    'checkpoint_runner',
    'chunkshim',
    'fastpath_recovery',
    'recovery_shim',
    'repair_shim',
)
FORBIDDEN_ENV_KEYS = (
    'APEX_CHAT_ALLOW_LIVE_INTERVENTION',
    'APEX_CHAT_ALLOW_LATENCY_RESTART',
    'APEX_CHAT_ALLOW_LIVE_PATCHING',
    'APEX_CHAT_ALLOW_CHECKPOINT_MUTATION',
    'APEX_SPLIT_SOURCE',
    'APEX_SPLIT_START',
    'APEX_SPLIT_END',
    'APEX_SPLIT_CHECKPOINT_IN',
    'APEX_SPLIT_CHECKPOINT_OUT',
    'APEX_PAIR_SLICE_START',
    'APEX_PAIR_SLICE_END',
)

class ChatEngineRoleBoundaryError(RuntimeError):
    pass


def _py_targets(command: Sequence[str]) -> list[Path]:
    out: list[Path] = []
    for part in command:
        s = str(part)
        if s.endswith('.py'):
            out.append(Path(s))
    return out


def enforce_live_production_child(command: Sequence[str], env: dict[str, str]) -> dict:
    """Fail closed if Chat attempts to manually operate engine internals.

    The authoritative sport entrypoint is resolved by the production runner from
    the bundled engine registry and exposed through APEX_AUTHORITATIVE_ENGINE_ENTRYPOINT.
    Chat has no terminal-selector continuation authority.
    """
    if str(env.get('APEX_EXECUTION_MODE', 'PRODUCTION')).upper() != 'PRODUCTION':
        return {'PATCH_ID': PATCH_ID, 'STATUS': 'NOT_APPLICABLE_NON_PRODUCTION'}

    for key in FORBIDDEN_ENV_KEYS:
        if str(env.get(key, '')).strip():
            raise ChatEngineRoleBoundaryError(f'CHAT_ENGINE_INTERNAL_CONTROL_PROHIBITED:{key}')

    targets = _py_targets(command)
    expected = str(env.get('APEX_AUTHORITATIVE_ENGINE_ENTRYPOINT', '')).strip()
    if expected:
        expected_path = Path(expected).resolve()
        if not targets:
            raise ChatEngineRoleBoundaryError('AUTHORITATIVE_ENGINE_ENTRYPOINT_CHILD_MISSING')
        actual = targets[-1].resolve()
        if actual != expected_path:
            raise ChatEngineRoleBoundaryError(
                f'AUTHORITATIVE_ENGINE_ENTRYPOINT_MISMATCH:{actual}:{expected_path}'
            )
    else:
        # Legacy/manual runner calls receive no registry-pinned entrypoint. In
        # production they may not target known engine-internal helper surfaces.
        for target in targets:
            name = target.name.lower()
            if any(token in name for token in FORBIDDEN_NAME_TOKENS):
                raise ChatEngineRoleBoundaryError(f'CHAT_DIRECT_ENGINE_INTERNAL_SCRIPT_PROHIBITED:{target.name}')

    return {
        'PATCH_ID': PATCH_ID,
        'STATUS': 'PASS',
        'CHAT_ROLE': CHAT_ROLE,
        'CHAT_ENGINE_INTERNAL_OPERATION_ALLOWED': False,
        'SELECTOR_BOUNDARY_ALLOWED': False,
        'LIVE_RUN_CONTROL_POLICY': LIVE_RUN_CONTROL_POLICY,
        'LATENCY_AUTHORITY': LATENCY_AUTHORITY,
        'TELEMETRY_AUTHORITY': TELEMETRY_AUTHORITY,
        'CHAT_LATENCY_BASED_RESTART_ALLOWED': False,
        'CHAT_LIVE_PATCHING_ALLOWED': False,
        'CHAT_CHECKPOINT_MUTATION_ALLOWED': False,
        'AUTHORITATIVE_ENGINE_ENTRYPOINT': expected or None,
    }


def production_env(authoritative_entrypoint: str | os.PathLike[str]) -> dict[str, str]:
    return {
        'APEX_CHAT_ENGINE_ROLE_BOUNDARY': PATCH_ID,
        'APEX_CHAT_ROLE': CHAT_ROLE,
        'APEX_AUTHORITATIVE_ENGINE_ENTRYPOINT': str(Path(authoritative_entrypoint).resolve()),
        'APEX_CHAT_INTERNAL_ENGINE_CONTROL': 'PROHIBITED',
        'APEX_CHAT_SELECTOR_BOUNDARY_ONLY': '0',
        'APEX_CHAT_EXECUTION_AUTHORITY': '0',
        'APEX_CHAT_LIVE_INTERVENTION': 'PROHIBITED',
        'APEX_CHAT_LATENCY_BASED_RESTART': 'PROHIBITED',
        'APEX_CHAT_LIVE_PATCHING': 'PROHIBITED',
        'APEX_CHAT_CHECKPOINT_MUTATION': 'PROHIBITED',
        'APEX_ENGINE_CHECKPOINT_AUTHORITY': '1',
        'APEX_ENGINE_PROCESS_LIFECYCLE_AUTHORITY': '1',
    }
