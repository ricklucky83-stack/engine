from __future__ import annotations
import hashlib, json, os, tempfile
from pathlib import Path
from typing import Any

PATCH_ID = "APEX_GLOBAL_FRESH_MANIFEST_SEAL_AND_POINTER_GATE_v1"
MANIFEST_FILE = "bundle_manifest.json"
class BundleSealError(RuntimeError): pass
def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""): digest.update(block)
    return digest.hexdigest()
def _bundle_files(root: Path) -> list[Path]:
    return sorted(path for path in root.rglob("*") if path.is_file() and path.relative_to(root).as_posix() != MANIFEST_FILE)
def build_complete_file_map(root: str | Path) -> dict[str, dict[str, Any]]:
    root_path = Path(root)
    if not root_path.is_dir(): raise BundleSealError(f"BUNDLE_ROOT_MISSING:{root_path}")
    return {path.relative_to(root_path).as_posix(): {"bytes":path.stat().st_size,"sha256":sha256_file(path)} for path in _bundle_files(root_path)}
def assert_complete_manifest(root: str | Path, manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    root_path=Path(root); manifest_path=root_path/MANIFEST_FILE
    if manifest is None:
        if not manifest_path.exists(): raise BundleSealError("BUNDLE_MANIFEST_MISSING")
        manifest=json.loads(manifest_path.read_text(encoding="utf-8"))
    declared=manifest.get("FILES")
    if not isinstance(declared,dict): raise BundleSealError("BUNDLE_MANIFEST_FILES_INVALID")
    actual=build_complete_file_map(root_path); declared_keys=set(map(str,declared)); actual_keys=set(actual)
    missing=sorted(actual_keys-declared_keys); stale=sorted(declared_keys-actual_keys)
    if missing or stale: raise BundleSealError("BUNDLE_MANIFEST_FILESET_MISMATCH:"+f"MISSING={','.join(missing)}:STALE={','.join(stale)}")
    bad=[rel for rel,observed in actual.items() if not isinstance(declared[rel],dict) or declared[rel].get("sha256")!=observed["sha256"] or declared[rel].get("bytes")!=observed["bytes"]]
    if bad: raise BundleSealError("BUNDLE_MANIFEST_CONTENT_MISMATCH:"+",".join(sorted(bad)))
    return {"PATCH_ID":PATCH_ID,"MANIFEST_FRESHLY_REBUILT":True,"MANIFEST_EXACT_FILESET":True,"MANIFEST_ENTRY_COUNT":len(actual),"MANIFEST_SHA256":sha256_file(manifest_path),"INTERNAL_MANIFEST_CHECK":"PASS"}
def _atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True,exist_ok=True); fd,temp_name=tempfile.mkstemp(prefix=path.name+".",suffix=".tmp",dir=str(path.parent))
    try:
        with os.fdopen(fd,"w",encoding="utf-8") as handle:
            json.dump(value,handle,indent=2,sort_keys=True); handle.write("\n"); handle.flush(); os.fsync(handle.fileno())
        os.replace(temp_name,path)
    finally:
        if os.path.exists(temp_name): os.unlink(temp_name)
def rebuild_and_verify_manifest(root: str | Path, metadata: dict[str, Any]) -> dict[str, Any]:
    root_path=Path(root); manifest=dict(metadata); manifest["FILES"]=build_complete_file_map(root_path); manifest["MANIFEST_GENERATION"]={"PATCH_ID":PATCH_ID,"MODE":"FULL_REBUILD_FROM_CURRENT_BUNDLE_BYTES","INHERITED_FILE_ENTRIES_ALLOWED":False}; _atomic_write_json(root_path/MANIFEST_FILE,manifest); return assert_complete_manifest(root_path,manifest)
__all__=["PATCH_ID","BundleSealError","assert_complete_manifest","build_complete_file_map","rebuild_and_verify_manifest","sha256_file"]
