from __future__ import annotations
import re

STOP_RE = re.compile(r"^\s*(STOP|STOP EXECUTION|CANCEL|ABORT)(?:[!?.\s]*)$", re.I)
BOARD_RE = re.compile(r"^\s*(?:SHOW\s+)?BOARD(?:\s*!+)?\s*$", re.I)

# User command authority is immutable at orchestration time. The assistant/orchestrator
# may execute recovery already authorized by committed doctrine, but it may not replace
# the requested run/board action with commentary, a newly invented fallback policy, or
# an unproven asynchronous/running status.
USER_COMMAND_AUTHORITY = True
UNAUTHORIZED_POLICY_MUTATION_ALLOWED = False
UNPROVEN_ACTIVE_STATUS_ALLOWED = False

def evaluate_command(command_text: str, live_production: bool=True) -> dict:
    text=(command_text or "").strip()
    stop=bool(STOP_RE.match(text))
    code_only=bool(re.search(r"\bCODE\s+ONLY\b", text, re.I)) or bool(re.search(r"EXECUTION\s+MODE", text, re.I))
    fast_path=bool(re.search(r"\bFAST\s*PATH\b", text, re.I))
    board_command=bool(BOARD_RE.match(text))
    metrics_request=bool(re.search(r"\b(?:SHOW\s+)?RUN\s+METRICS(?:\s+AND\s+STATS)?\b|\bMETRICS\s+AND\s+STATS\b", text, re.I))
    if stop:
        return {
            "CONTROL":"STOP_PREEMPT",
            "TOOL_CALLS_ALLOWED_AFTER_STOP":False,
            "PROGRESS_MESSAGES_ALLOWED":False,
            "FIRST_USER_VISIBLE_PAYLOAD":"STOPPED_ONLY",
            "CODE_ONLY":code_only,
            "FAST_PATH":fast_path,
            "USER_COMMAND_AUTHORITY":USER_COMMAND_AUTHORITY,
            "UNAUTHORIZED_POLICY_MUTATION_ALLOWED":UNAUTHORIZED_POLICY_MUTATION_ALLOWED,
            "UNPROVEN_ACTIVE_STATUS_ALLOWED":UNPROVEN_ACTIVE_STATUS_ALLOWED,
        }
    silent=bool(live_production and code_only)
    return {
        "CONTROL":"RUN",
        "TOOL_CALLS_ALLOWED_AFTER_STOP":False,
        "PROGRESS_MESSAGES_ALLOWED":not silent,
        "FIRST_USER_VISIBLE_PAYLOAD":"FINAL_BOARD_OR_RUN_INVALID" if silent else "NORMAL",
        "CODE_ONLY":code_only,
        "FAST_PATH":fast_path,
        "REDUNDANT_BOOTSTRAP_FORBIDDEN":True,
        "LIVE_BOOTSTRAP_GATE":False,
        "LIVE_POINTER_GATE":False,
        "LIVE_BUNDLE_HASH_GATE":False,
        "LIVE_MANIFEST_HASH_GATE":False,
        "BOARD_OVER_EVERYTHING":True,
        "RUN_UNTIL_BOARD_OR_TRUE_RUN_INVALID":True,
        "RECOVERABLE_EXIT_MAY_TERMINATE":False,
        "MISSING_BOARD_MAY_TERMINATE":False,
        "ACTIVE_POINTER_IDENTITY_PREEXECUTION_REQUIRED":False,
        "REMOTE_BOOTSTRAP_PREBOARD_DEFAULT":False,
        "LOCAL_COMPATIBLE_RUNTIME_FIRST":True,
        "LOCAL_IDENTICAL_VERIFIED_RUNTIME_REUSE":True,
        "CACHE_AUTHORITY":False,
        "POSTBOARD_STATE_WORK":True,
        "USER_COMMAND_AUTHORITY":USER_COMMAND_AUTHORITY,
        "UNAUTHORIZED_POLICY_MUTATION_ALLOWED":UNAUTHORIZED_POLICY_MUTATION_ALLOWED,
        "UNPROVEN_ACTIVE_STATUS_ALLOWED":UNPROVEN_ACTIVE_STATUS_ALLOWED,
        "BOARD_COMMAND":board_command,
        "BOARD_COMMAND_REQUIRES_IMMEDIATE_BOARD_PAYLOAD":bool(live_production and board_command),
        "METRICS_STATS_REQUEST":metrics_request,
        "FINAL_BOARD_REQUIRED_BEFORE_METRICS":bool(live_production and metrics_request),
        "OUTPUT_SEQUENCE":["FINAL_BOARD","RUN_METRICS_STATS"] if (live_production and metrics_request) else ["FINAL_BOARD"],
        "FINAL_BOARD_RENDER_ORDER":1,
        "RUN_METRICS_STATS_RENDER_ORDER":2 if (live_production and metrics_request) else None,
        "USER_VISIBLE_BOARD_SOURCE":"SEALED_MACHINE_FINAL_BOARD_ARTIFACT_ONLY",
        "NONBOARD_ARTIFACTS_AS_BOARD_SOURCE":"HARD_REJECT",
        "ASSISTANT_COMMENTARY_MAY_REPLACE_EXECUTION_RESULT":False,
        "NEW_FALLBACK_POLICY_MAY_BE_INVENTED_MIDRUN":False,
        "TERMINAL_USER_PAYLOAD_ALLOWLIST":["FINAL_BOARD","RUN_INVALID_TRUE_IMPOSSIBILITY"] if live_production else ["NORMAL"],
        "INTERMEDIATE_FAILURE_STATUS_USER_VISIBLE_TERMINAL":False if live_production else None,
    }
