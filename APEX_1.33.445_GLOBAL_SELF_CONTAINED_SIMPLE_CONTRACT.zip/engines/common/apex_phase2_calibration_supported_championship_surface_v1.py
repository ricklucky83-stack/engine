from __future__ import annotations

"""Global calibration-supported Phase-2 championship surface helpers.

The engine may use frozen Phase-1 calibration to concentrate work, but calibration
must not silently erase a structurally distinct championship species that still has
credible lineup-level support.  This module never uses post-lock outcomes and never
creates lineups; it operates only on already-legal candidate indices supplied by the
sport adapter.
"""

from dataclasses import dataclass
from typing import Mapping, Sequence
import math
import numpy as np

PATCH_ID = "APEX_GLOBAL_PHASE2_CALIBRATION_SUPPORTED_CHAMPIONSHIP_SURFACE_v1"
BASE_DOCTRINE_ID = "APEX_CALIBRATION_FIRST_PHASE2_CONSTRUCTION_v2"


@dataclass(frozen=True)
class SpeciesSpec:
    name: str
    mask: np.ndarray


def _pct_rank(values: np.ndarray) -> np.ndarray:
    x=np.asarray(values,float)
    out=np.zeros(len(x),float)
    finite=np.isfinite(x)
    if not finite.any():
        return out
    vals=x[finite]
    order=np.argsort(vals,kind="mergesort")
    sorted_vals=vals[order]
    ranks=np.empty(len(vals),float)
    if len(vals)==1:
        ranks[0]=1.0
    else:
        i=0
        while i<len(vals):
            j=i+1
            while j<len(vals) and sorted_vals[j]==sorted_vals[i]:
                j+=1
            r=((i+j-1)/2.0)/(len(vals)-1)
            ranks[order[i:j]]=r
            i=j
    out[np.where(finite)[0]]=ranks
    return out


def championship_support_score(metrics: Mapping[str, np.ndarray]) -> np.ndarray:
    """Shared lineup-level support from frozen calibration metrics only."""
    required=("top01","win","p99","p95")
    missing=[k for k in required if k not in metrics]
    if missing:
        raise RuntimeError("RUN_INVALID:PHASE2_CALIBRATION_SUPPORT_METRICS_MISSING:"+",".join(missing))
    n=len(np.asarray(metrics["top01"]))
    if any(len(np.asarray(metrics[k]))!=n for k in required):
        raise RuntimeError("RUN_INVALID:PHASE2_CALIBRATION_SUPPORT_LENGTH_MISMATCH")
    return (
        .35*_pct_rank(np.asarray(metrics["top01"],float))
        +.25*_pct_rank(np.asarray(metrics["win"],float))
        +.25*_pct_rank(np.asarray(metrics["p99"],float))
        +.15*_pct_rank(np.asarray(metrics["p95"],float))
    )


def tail_rescue_union(
    selected: Sequence[int],
    metrics: Mapping[str, np.ndarray],
    *,
    fraction: float=.005,
    min_rows: int=8,
    max_rows_per_metric: int=128,
) -> tuple[np.ndarray, dict]:
    """Union the strongest frozen tail rows on each independent dimension."""
    ids=set(map(int,selected))
    n=len(np.asarray(metrics["top01"]))
    added_by_metric={}
    for key in ("top01","win","p99","p95"):
        arr=np.asarray(metrics[key],float)
        k=min(n,max(int(min_rows),min(int(max_rows_per_metric),int(math.ceil(max(0.0,float(fraction))*n)))))
        if k<=0:
            added_by_metric[key]=0
            continue
        order=np.argsort(-arr,kind="mergesort")[:k]
        before=len(ids); ids.update(map(int,order)); added_by_metric[key]=len(ids)-before
    return np.asarray(sorted(ids),np.int32),{
        "PATCH_ID":PATCH_ID,
        "COMPONENT":"CALIBRATION_TAIL_RESCUE",
        "POSTLOCK_INPUT_USED":False,
        "METRICS":["top01","win","p99","p95"],
        "ADDITIONS_BY_METRIC":added_by_metric,
        "OUTPUT_ROWS":int(len(ids)),
    }


def species_coverage_closure(
    selected: Sequence[int],
    metrics: Mapping[str, np.ndarray],
    species: Sequence[SpeciesSpec],
    *,
    credible_support_floor: float=.70,
    min_rows: int=8,
    max_rows: int=64,
) -> tuple[np.ndarray, dict]:
    """Preserve credible structural species without imposing equal quotas.

    A species is credible when at least one legal row clears the shared lineup-level
    calibration support floor.  The closure then retains a small, evidence-scaled
    calibrated neighborhood for that species.  Species with no credible support are
    not forced into Phase 2.
    """
    support=championship_support_score(metrics)
    ids=set(map(int,selected))
    n=len(support)
    rows=[]
    for spec in species:
        mask=np.asarray(spec.mask,bool)
        if len(mask)!=n:
            raise RuntimeError(f"RUN_INVALID:PHASE2_SPECIES_MASK_LENGTH_MISMATCH:{spec.name}")
        legal=np.flatnonzero(mask).astype(np.int32)
        if not len(legal):
            rows.append({"SPECIES":spec.name,"LEGAL_ROWS":0,"CREDIBLE":False,"MAX_SUPPORT":None,"TARGET_ROWS":0,"BORN_ROWS":0,"ADDED":0})
            continue
        max_support=float(np.max(support[legal]))
        credible=bool(max_support+1e-12>=float(credible_support_floor))
        target=0
        before=sum(int(i) in ids for i in legal)
        if credible:
            target=min(int(max_rows),max(int(min_rows),int(math.ceil(math.sqrt(len(legal))))))
            target=min(target,len(legal))
            if before<target:
                order=legal[np.argsort(-support[legal],kind="mergesort")[:target]]
                ids.update(map(int,order))
        after=sum(int(i) in ids for i in legal)
        if credible and after<=0:
            raise RuntimeError(f"ENGINE_INTEGRITY_HALT:PHASE2_CREDIBLE_SPECIES_COLLAPSE:{spec.name}")
        rows.append({
            "SPECIES":spec.name,
            "LEGAL_ROWS":int(len(legal)),
            "CREDIBLE":credible,
            "MAX_SUPPORT":max_support,
            "TARGET_ROWS":int(target),
            "BORN_ROWS":int(after),
            "ADDED":int(max(0,after-before)),
        })
    credible=[r for r in rows if r["CREDIBLE"]]
    collapsed=[r["SPECIES"] for r in credible if r["BORN_ROWS"]<=0]
    if collapsed:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:PHASE2_CREDIBLE_SPECIES_COLLAPSE:"+",".join(collapsed))
    return np.asarray(sorted(ids),np.int32),{
        "PATCH_ID":PATCH_ID,
        "COMPONENT":"CHAMPIONSHIP_SPECIES_COVERAGE",
        "POSTLOCK_INPUT_USED":False,
        "CREDIBLE_SUPPORT_FLOOR":float(credible_support_floor),
        "NO_CREDIBLE_SPECIES_COLLAPSE":True,
        "CREDIBLE_SPECIES_COUNT":int(len(credible)),
        "SPECIES":rows,
        "OUTPUT_ROWS":int(len(ids)),
    }


def validate_phase2_freeze(
    phase2_ids: Sequence[int],
    *,
    legal_count: int,
    phase3_count: int | None=None,
    handoff_count: int | None=None,
    selector_review_count: int | None=None,
    post_phase2_mutation_count: int=0,
) -> dict:
    p2=len(set(map(int,phase2_ids)))
    if p2<=0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:PHASE2_EMPTY")
    if p2>int(legal_count):
        raise RuntimeError("RUN_INVALID:PHASE2_EXCEEDS_LEGAL_SURFACE")
    if int(post_phase2_mutation_count)!=0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:POST_PHASE2_MUTATION")
    for label,value in (("PHASE3",phase3_count),("HANDOFF",handoff_count),("SELECTOR",selector_review_count)):
        if value is not None and int(value)!=p2:
            raise RuntimeError(f"ENGINE_INTEGRITY_HALT:PHASE2_{label}_PARITY:{p2}:{int(value)}")
    return {
        "PATCH_ID":PATCH_ID,
        "PHASE2_BUILT_LINEUPS":p2,
        "LEGAL_SCAN_LINEUPS":int(legal_count),
        "POST_PHASE2_MUTATION_COUNT":0,
        "PHASE2_FREEZE":"PASS",
    }
