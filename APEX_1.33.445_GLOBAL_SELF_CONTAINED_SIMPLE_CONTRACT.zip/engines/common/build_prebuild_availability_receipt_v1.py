from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

STATE_ROOT = Path(__file__).resolve().parents[2]
if str(STATE_ROOT) not in sys.path:
    sys.path.insert(0, str(STATE_ROOT))

from engines.common.universal_prebuild_availability_gate_v1 import (
    SCHEMA_VERSION, sha256_file, DK_SOURCE_UNIVERSE_HARD_LOCK_PATCH_ID,
    INDIVIDUAL_SPORTS, INDIVIDUAL_HARD_OUT_MIN_VERIFIED_SOURCES,
)

GENERATOR_ID = "APEX_PREBUILD_AVAILABILITY_RECEIPT_BUILDER_v2"


def _pool_player_count(pool_path: Path) -> int:
    import csv
    with pool_path.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fields = reader.fieldnames or []
        player_col = next((x for x in fields if str(x).strip().upper().replace(" ", "_") in {"PLAYER", "NAME", "ATHLETE"}), None)
        if player_col is None:
            return 0
        return sum(1 for row in reader if str(row.get(player_col, "")).strip())


def build_receipt(*, pool_path: Path, snapshot_path: Path, output_path: Path, max_age_minutes: int = 30) -> dict[str, Any]:
    snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
    if not isinstance(snapshot, dict):
        raise RuntimeError("RUN_INVALID:AVAILABILITY_SOURCE_SNAPSHOT_NOT_OBJECT")
    required = ["SPORT", "MODE", "EXECUTION_ID", "FIELD_SIZE", "SOURCE_RECORDS", "UNKNOWN_COUNT"]
    missing = [key for key in required if key not in snapshot]
    if missing:
        raise RuntimeError("RUN_INVALID:AVAILABILITY_SOURCE_SNAPSHOT_MISSING:" + ",".join(missing))
    if str(snapshot.get("SPORT") or "").strip().upper() == "WNBA":
        team_status = snapshot.get("TEAM_STATUS")
        if not isinstance(team_status, list) or not team_status:
            raise RuntimeError("RUN_INVALID:WNBA_TEAM_STATUS_MISSING")
        if snapshot.get("WNBA_FINAL_OUT_LIST_COMPLETE") is not True:
            raise RuntimeError("RUN_INVALID:WNBA_FINAL_OUT_LIST_COMPLETENESS_NOT_CERTIFIED")
        for raw in team_status:
            team = str(raw.get("TEAM") or "").strip().upper() if isinstance(raw, dict) else "UNKNOWN"
            report_status = str(raw.get("INJURY_REPORT_STATUS") or "").strip().upper() if isinstance(raw, dict) else ""
            source_ref = str(raw.get("SOURCE_REF") or "").strip() if isinstance(raw, dict) else ""
            if report_status != "FINAL":
                raise RuntimeError(f"RUN_INVALID:WNBA_INJURY_REPORT_NOT_FINAL:{team}:{report_status or 'MISSING'}")
            if not source_ref:
                raise RuntimeError(f"RUN_INVALID:WNBA_INJURY_REPORT_SOURCE_MISSING:{team}")
    if str(snapshot.get("SPORT") or "").strip().upper() == "MLB":
        team_status = snapshot.get("TEAM_STATUS")
        if not isinstance(team_status, list) or not team_status:
            raise RuntimeError("RUN_INVALID:MLB_TEAM_STATUS_MISSING")
        for raw in team_status:
            team = str(raw.get("TEAM") or "").strip().upper() if isinstance(raw, dict) else "UNKNOWN"
            if not isinstance(raw, dict) or raw.get("INFERENCE_USED") is not False:
                raise RuntimeError(f"RUN_INVALID:MLB_STARTER_POSITIONAL_INFERENCE_PROHIBITED:{team}")
            source_mode = str(raw.get("STARTER_SOURCE_MODE") or "").strip().upper().replace("-", "_").replace(" ", "_")
            if source_mode not in {"OFFICIAL_SOURCE_EXACT", "VERIFIED_PROVIDER_EXACT"}:
                raise RuntimeError(f"RUN_INVALID:MLB_STARTER_SOURCE_NOT_EXACT:{team}:{source_mode or 'MISSING'}")
    receipt = {
        **snapshot,
        "SCHEMA_VERSION": SCHEMA_VERSION,
        "STATUS": "PASS",
        "POOL_SHA256": sha256_file(pool_path),
        "GENERATED_AT_UTC": datetime.now(timezone.utc).isoformat(),
        "MAX_AGE_MINUTES": int(max_age_minutes),
        "CODE_GENERATED": True,
        "GENERATOR_ID": GENERATOR_ID,
        "GENERATOR_SOURCE_SHA256": sha256_file(Path(__file__)),
        "MANUAL_OVERRIDE_USED": False,
        "PRESELECTOR_EXECUTION": "CODE_ONLY",
        "AI_ALLOWED_STAGE": "FINAL_SELECTOR_ONLY",
        "NFL_HARD_OUT_TEMPORAL_PROVENANCE_REQUIRED": str(snapshot.get("SPORT") or "").strip().upper() == "NFL",
        "DK_SOURCE_UNIVERSE_HARD_LOCK_PATCH_ID": DK_SOURCE_UNIVERSE_HARD_LOCK_PATCH_ID,
        "DK_SOURCE_UNIVERSE_ANCHOR_SHA256": sha256_file(pool_path),
        "DK_SOURCE_UNIVERSE_PLAYER_COUNT": _pool_player_count(pool_path),
        "INDIVIDUAL_HARD_OUT_REQUIRES_DUAL_SOURCE_OR_OFFICIAL_OR_HUMAN": str(snapshot.get("SPORT") or "").strip().upper() in INDIVIDUAL_SPORTS,
        "INDIVIDUAL_HARD_OUT_MIN_VERIFIED_SOURCES": INDIVIDUAL_HARD_OUT_MIN_VERIFIED_SOURCES if str(snapshot.get("SPORT") or "").strip().upper() in INDIVIDUAL_SPORTS else None,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return receipt


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pool", required=True)
    parser.add_argument("--source-snapshot", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--max-age-minutes", type=int, default=30)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    receipt = build_receipt(
        pool_path=Path(args.pool),
        snapshot_path=Path(args.source_snapshot),
        output_path=Path(args.output),
        max_age_minutes=args.max_age_minutes,
    )
    print(json.dumps({
        "STATUS": "PASS",
        "GENERATOR_ID": receipt["GENERATOR_ID"],
        "POOL_SHA256": receipt["POOL_SHA256"],
        "OUTPUT": str(Path(args.output).resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
