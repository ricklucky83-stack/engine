from __future__ import annotations
import numpy as np
from numba import njit, prange, set_num_threads, get_num_threads

_MAX_THREADS = 5
try:
    set_num_threads(min(_MAX_THREADS, get_num_threads()))
except Exception:
    pass

@njit(parallel=True, cache=True)
def tennis_exact_metrics(player_scores, rows, threshold, max_field):
    n = rows.shape[0]; trials = player_scores.shape[0]; slots = rows.shape[1]
    mean = np.empty(n, np.float32); p95 = np.empty(n, np.float32); p99 = np.empty(n, np.float32); cvar99 = np.empty(n, np.float32)
    top_count = np.zeros(n, np.int32); win_count = np.zeros(n, np.int32)
    x95 = 0.95 * (trials - 1); i95 = int(np.floor(x95)); j95 = int(np.ceil(x95)); w95 = x95 - i95
    x99 = 0.99 * (trials - 1); i99 = int(np.floor(x99)); j99 = int(np.ceil(x99)); w99 = x99 - i99
    k = max(1, int(np.ceil(trials * 0.01))); kth = trials - k
    has_thr = threshold.shape[0] == trials and max_field.shape[0] == trials
    for i in prange(n):
        a = np.empty(trials, np.float32); s = np.float32(0.0); tc = 0; wc = 0
        for t in range(trials):
            v = np.float32(0.0)
            for q in range(slots):
                v += player_scores[t, rows[i, q]]
            a[t] = v; s += v
            if has_thr:
                if v >= threshold[t]: tc += 1
                if v >= max_field[t]: wc += 1
        mean[i] = s / trials
        part = np.partition(a, (i95, j95, i99, j99, kth))
        p95[i] = part[i95] * (1.0 - w95) + part[j95] * w95
        p99[i] = part[i99] * (1.0 - w99) + part[j99] * w99
        ts = np.float32(0.0)
        for z in range(kth, trials): ts = np.float32(ts + part[z])
        cvar99[i] = ts / k
        top_count[i] = tc; win_count[i] = wc
    return mean, p95, p99, cvar99, top_count, win_count

@njit(parallel=True, cache=True)
def mlb_exact_metrics(score_surface, lines, threshold_top1, threshold_top01, threshold_win):
    n = lines.shape[0]; trials = score_surface.shape[0]; slots = lines.shape[1]
    mean = np.empty(n, np.float64); p95 = np.empty(n, np.float64); p99 = np.empty(n, np.float64); cvar99 = np.empty(n, np.float64)
    top1 = np.zeros(n, np.int64); top01 = np.zeros(n, np.int64); win = np.zeros(n, np.int64)
    bits = np.zeros((n, (trials + 7)//8), np.uint8)
    x95 = 0.95 * (trials - 1); i95 = int(np.floor(x95)); j95 = int(np.ceil(x95)); w95 = x95 - i95
    x99 = 0.99 * (trials - 1); i99 = int(np.floor(x99)); j99 = int(np.ceil(x99)); w99 = x99 - i99
    for i in prange(n):
        a = np.empty(trials, np.float32); s = np.float32(0.0)
        c1 = 0; c01 = 0; cw = 0
        for t in range(trials):
            v = np.float32(0.0)
            for q in range(slots): v += score_surface[t, lines[i,q]]
            a[t] = v; s += v
            if v >= threshold_top1: c1 += 1
            if v >= threshold_top01:
                c01 += 1; bits[i,t>>3] |= np.uint8(1 << (t & 7))
            if v >= threshold_win: cw += 1
        mean[i] = s / trials
        part = np.partition(a, (i95,j95,i99,j99))
        q95 = np.float32(part[i95]*(1.0-w95)+part[j95]*w95); q99 = np.float32(part[i99]*(1.0-w99)+part[j99]*w99)
        p95[i]=q95; p99[i]=q99
        ts=np.float32(0.0); cc=0
        for t in range(trials):
            if a[t] >= q99: ts = np.float32(ts + a[t]); cc += 1
        cvar99[i] = ts / max(cc,1)
        top1[i]=c1; top01[i]=c01; win[i]=cw
    return mean,p95,p99,cvar99,top1,top01,win,bits
