from __future__ import annotations

"""Global DFS entry-limit game theory.

The contest entry limit is a strategic parameter for BOTH sides of the contest.
A 1-max contest is one portfolio seat per entrant; a 3-max contest is three; a
28-max or 150-max contest permits progressively broader coordinated coverage.
The objective is always contest-win probability of the whole allowed portfolio,
not safety, projection, leverage, or independent Top-N lineup ranking.
"""

from dataclasses import asdict, dataclass
from typing import Iterable, Sequence
import math
import numpy as np

PATCH_ID = "APEX_GLOBAL_SYMMETRIC_ENTRY_LIMIT_PORTFOLIO_GAME_THEORY_v1"
OBJECTIVE = "MAXIMIZE_P_ANY_OUR_ENTRY_FINISHES_FIRST_VS_OPPONENT_PORTFOLIOS_UNDER_SAME_ENTRY_LIMIT"


class EntryLimitGameTheoryError(RuntimeError):
    pass


@dataclass(frozen=True)
class EntryLimitProfile:
    field_size: int
    contest_max_entries: int
    our_entry_budget: int
    opponent_entry_budget: int
    regime: str
    objective: str = OBJECTIVE
    symmetric_entry_limit: bool = True
    portfolio_coordination_required: bool = True
    independent_top_n_selection_prohibited: bool = True
    exposure_management_required: bool = False
    single_entry: bool = False


def _positive_int(value, name: str) -> int:
    try:
        iv = int(value)
    except Exception as exc:
        raise EntryLimitGameTheoryError(f"{name}_INVALID:{value}") from exc
    if iv <= 0:
        raise EntryLimitGameTheoryError(f"{name}_MUST_BE_POSITIVE:{iv}")
    return iv


def _regime(max_entries: int) -> str:
    if max_entries == 1:
        return "SINGLE_ENTRY_ONE_SHOT_EACH"
    if max_entries <= 3:
        return "LOW_MAX_COORDINATED_PORTFOLIO"
    if max_entries <= 20:
        return "SMALL_MAX_BRANCH_COVERAGE"
    if max_entries <= 99:
        return "MID_MAX_PORTFOLIO_COVERAGE"
    return "MASS_MULTI_ENTRY_PORTFOLIO_COVERAGE"


def build_entry_limit_profile(*, field_size, max_entries, user_entries=None) -> EntryLimitProfile:
    field = _positive_int(field_size, "FIELD_SIZE")
    max_e = _positive_int(max_entries, "MAX_ENTRIES")
    our = max_e if user_entries in (None, "", 0, "0") else _positive_int(user_entries, "USER_ENTRIES")
    if our > max_e:
        raise EntryLimitGameTheoryError(f"USER_ENTRIES_EXCEED_CONTEST_MAX:{our}>{max_e}")
    if our > field:
        raise EntryLimitGameTheoryError(f"USER_ENTRIES_EXCEED_FIELD_SIZE:{our}>{field}")
    return EntryLimitProfile(
        field_size=field,
        contest_max_entries=max_e,
        our_entry_budget=our,
        opponent_entry_budget=max_e,
        regime=_regime(max_e),
        single_entry=(max_e == 1),
        portfolio_coordination_required=(max_e > 1),
    )


def profile_dict(*, field_size, max_entries, user_entries=None) -> dict:
    return asdict(build_entry_limit_profile(field_size=field_size, max_entries=max_entries, user_entries=user_entries))


def opponent_portfolio_sizes(*, field_size, max_entries, user_entries=0) -> list[int]:
    """Partition opponent entries into symmetric max-entry portfolios.

    This is the default structural assumption when owner-level entry counts are
    unavailable.  The final portfolio may be partial so total entries remain exact.
    """
    field = _positive_int(field_size, "FIELD_SIZE")
    cap = _positive_int(max_entries, "MAX_ENTRIES")
    ours = 0 if user_entries in (None, "", 0, "0") else _positive_int(user_entries, "USER_ENTRIES")
    if ours > field:
        raise EntryLimitGameTheoryError(f"USER_ENTRIES_EXCEED_FIELD_SIZE:{ours}>{field}")
    remaining = field - ours
    if remaining <= 0:
        return []
    q, r = divmod(remaining, cap)
    sizes = [cap] * q
    if r:
        sizes.append(r)
    return sizes


def joint_union_capture(success_matrix: np.ndarray, selected: Sequence[int]) -> float:
    arr = np.asarray(success_matrix, dtype=bool)
    if arr.ndim != 2:
        raise EntryLimitGameTheoryError("SUCCESS_MATRIX_MUST_BE_2D_CANDIDATE_X_WORLD")
    if not selected:
        return 0.0
    idx = np.asarray(selected, dtype=int)
    if np.any(idx < 0) or np.any(idx >= arr.shape[0]):
        raise EntryLimitGameTheoryError("SELECTED_INDEX_OUT_OF_RANGE")
    return float(np.mean(np.any(arr[idx], axis=0)))


def select_joint_portfolio(
    success_matrix: np.ndarray,
    *,
    entry_budget: int,
    lineup_quality: Sequence[float] | None = None,
) -> dict:
    """Select lineups by marginal contest-win-world coverage.

    `success_matrix[i, w]` means lineup i wins/clears the chosen contest-win event
    in world w against the simulated opponent field.  For one entry this is exactly
    one-shot selection.  For multi-entry contests subsequent seats maximize NEW
    winning-world coverage, preventing independent Top-N ranking from masquerading
    as a coordinated portfolio.
    """
    success = np.asarray(success_matrix, dtype=bool)
    if success.ndim != 2 or success.shape[0] == 0 or success.shape[1] == 0:
        raise EntryLimitGameTheoryError("SUCCESS_MATRIX_MUST_BE_NONEMPTY_2D")
    budget = min(_positive_int(entry_budget, "ENTRY_BUDGET"), success.shape[0])
    q = np.zeros(success.shape[0], dtype=float) if lineup_quality is None else np.asarray(lineup_quality, dtype=float)
    if q.shape != (success.shape[0],) or np.any(~np.isfinite(q)):
        raise EntryLimitGameTheoryError("LINEUP_QUALITY_SHAPE_OR_VALUE_INVALID")

    individual = success.mean(axis=1)
    selected: list[int] = []
    covered = np.zeros(success.shape[1], dtype=bool)
    marginal_rates: list[float] = []

    for _ in range(budget):
        remaining = np.array([i for i in range(success.shape[0]) if i not in selected], dtype=int)
        if remaining.size == 0:
            break
        marginal = np.mean(success[remaining] & ~covered, axis=1)
        # Deterministic lexicographic order: marginal union capture, then standalone
        # win rate, then supplied prelock quality, then lower source index.
        order = np.lexsort((remaining, -q[remaining], -individual[remaining], -marginal))
        pick = int(remaining[order[0]])
        selected.append(pick)
        marginal_rates.append(float(np.mean(success[pick] & ~covered)))
        covered |= success[pick]

    return {
        "PATCH_ID": PATCH_ID,
        "OBJECTIVE": OBJECTIVE,
        "ENTRY_BUDGET": budget,
        "SELECTED_INDICES": selected,
        "INDIVIDUAL_SUCCESS_RATES": [float(individual[i]) for i in selected],
        "MARGINAL_NEW_WIN_WORLD_RATES": marginal_rates,
        "PORTFOLIO_UNION_WIN_RATE": float(np.mean(covered)),
        "SINGLE_ENTRY_ONE_SHOT": bool(budget == 1),
        "INDEPENDENT_TOP_N_USED": False,
    }


def success_vs_opponent_best(candidate_scores: np.ndarray, opponent_best_scores: np.ndarray, *, ties_win_fraction: float = 0.0) -> np.ndarray:
    """Build candidate x world success bits against opponent-portfolio best scores."""
    cand = np.asarray(candidate_scores, dtype=float)
    opp = np.asarray(opponent_best_scores, dtype=float)
    if cand.ndim != 2:
        raise EntryLimitGameTheoryError("CANDIDATE_SCORES_MUST_BE_2D_CANDIDATE_X_WORLD")
    if opp.ndim != 1 or opp.shape[0] != cand.shape[1]:
        raise EntryLimitGameTheoryError("OPPONENT_BEST_SCORES_MUST_MATCH_WORLD_AXIS")
    if not (0.0 <= float(ties_win_fraction) <= 1.0):
        raise EntryLimitGameTheoryError("TIES_WIN_FRACTION_OUT_OF_RANGE")
    if ties_win_fraction <= 0.0:
        return cand > opp[None, :]
    # Deterministic fractional tie handling is represented as a threshold only when
    # ties count fully; callers needing split-pot EV should retain the tie mask.
    if ties_win_fraction >= 1.0:
        return cand >= opp[None, :]
    return cand > opp[None, :]
