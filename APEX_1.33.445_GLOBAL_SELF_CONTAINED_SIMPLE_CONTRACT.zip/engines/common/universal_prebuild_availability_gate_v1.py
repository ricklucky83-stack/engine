from __future__ import annotations

import csv
import hashlib
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

GATE_ID = "APEX_UNIVERSAL_PREBUILD_AVAILABILITY_AND_LINEUP_GATE_v2"
SCHEMA_VERSION = "APEX_PREBUILD_AVAILABILITY_RECEIPT_v2"
CODE_ONLY_CONTRACT = "APEX_CODE_ONLY_PRESELECTOR_PIPELINE_v1"
GENERATOR_ID = "APEX_PREBUILD_AVAILABILITY_RECEIPT_BUILDER_v2"
TEAM_SPORTS = {"MLB", "WNBA", "NBA", "CBB", "NFL", "CFB"}
INDIVIDUAL_SPORTS = {"TENNIS", "PGA", "MMA"}
DK_SOURCE_UNIVERSE_HARD_LOCK_PATCH_ID = "APEX_GLOBAL_DK_SOURCE_UNIVERSE_HARD_LOCK_AND_INDIVIDUAL_AVAILABILITY_QUORUM_v1"
INDIVIDUAL_HARD_OUT_MIN_VERIFIED_SOURCES = 2
INDIVIDUAL_OFFICIAL_HARD_OUT_AUTHORITIES = {
    "OFFICIAL_TOUR", "OFFICIAL_TOURNAMENT", "OFFICIAL_EVENT", "OFFICIAL_PROMOTER",
    "OFFICIAL_LEAGUE", "OFFICIAL_ORGANIZER", "OFFICIAL_CONTEST_ADMIN",
}
STARTER_MINIMUMS = {"WNBA": 5, "NBA": 5, "CBB": 5, "MLB": 9}
RECOVERABLE_TEAM_STARTER_COVERAGE_NONBLOCKING = True
UNAVAILABLE_STATUSES = {
    "OUT", "INACTIVE", "WITHDRAWN", "SCRATCHED", "SUSPENDED", "POSTPONED",
    "CANCELLED", "CANCELED", "DNP", "NOT_ACTIVE",
}
TENNIS_PPD_POLICY_ID = "TENNIS_CLASSIC_PPD_SCORING_WINDOW_AVAILABILITY_v1"
TENNIS_PPD_AMBIGUOUS_STATUSES = {"PPD", "POSTPONED"}
TENNIS_PPD_KEEP_STATUSES = {
    "PPD_WITHIN_SCORING_WINDOW", "POSTPONED_WITHIN_SCORING_WINDOW",
    "RESCHEDULED_WITHIN_SCORING_WINDOW", "DELAYED", "RAIN_DELAY", "WEATHER_DELAY",
}
TENNIS_PPD_PURGE_STATUSES = {
    "PPD_OUTSIDE_SCORING_WINDOW", "POSTPONED_OUTSIDE_SCORING_WINDOW",
    "RESCHEDULED_OUTSIDE_SCORING_WINDOW", "CANCELLED", "CANCELED", "WALKOVER",
}
ALLOWED_LINEUP_STATUS = {"CONFIRMED", "EXPECTED"}
ALLOWED_SOURCE_STATUS = {"PASS", "VERIFIED"}
MLB_EXACT_STARTER_SOURCE_MODES = {"OFFICIAL_SOURCE_EXACT", "VERIFIED_PROVIDER_EXACT"}
NFL_HARD_OUT_PATCH_ID = "APEX_GLOBAL_NFL_HARD_OUT_TEMPORAL_PROVENANCE_AND_TRANSACTION_RECONCILIATION_v1"
NFL_OFFICIAL_STATUS_AUTHORITIES = {
    "OFFICIAL_TRANSACTION", "OFFICIAL_ROSTER", "OFFICIAL_INACTIVE_LIST",
    "OFFICIAL_INJURY_REPORT", "OFFICIAL_GAME_STATUS", "OFFICIAL_TEAM_SOURCE",
}
NFL_AVAILABLE_STATUSES = {
    "ACTIVE", "AVAILABLE", "SIGNED", "RE_SIGNED", "RESIGNED", "ACTIVATED",
    "REINSTATED", "CLAIMED", "PROMOTED", "RETURNED",
}
NFL_UNAVAILABLE_STATUSES = UNAVAILABLE_STATUSES | {
    "IR", "RESERVE", "RELEASED", "WAIVED", "PUP", "NFI", "CONFIRMED_OUT", "REST",
}


class AvailabilityGateError(RuntimeError):
    pass


def normalize(value: Any) -> str:
    return str(value or "").strip().upper().replace("-", "_").replace(" ", "_")


def sha256_file(path: str | Path) -> str:
    p = Path(path)
    h = hashlib.sha256()
    with p.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def parse_utc(value: Any, field: str) -> datetime:
    text = str(value or "").strip()
    if not text:
        raise AvailabilityGateError(f"RUN_INVALID:AVAILABILITY_RECEIPT_MISSING_{field}")
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise AvailabilityGateError(f"RUN_INVALID:AVAILABILITY_RECEIPT_INVALID_{field}:{text}") from exc
    if parsed.tzinfo is None:
        raise AvailabilityGateError(f"RUN_INVALID:AVAILABILITY_RECEIPT_NAIVE_{field}:{text}")
    return parsed.astimezone(timezone.utc)


def _pool_identity(pool_path: str | Path) -> tuple[set[str], set[str], set[tuple[str, str]], list[dict[str, str]]]:
    path = Path(pool_path)
    if not path.exists():
        raise AvailabilityGateError(f"RUN_INVALID:PLAYER_POOL_MISSING:{path}")
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        rows = [dict(row) for row in reader]
    if not rows:
        raise AvailabilityGateError("RUN_INVALID:PLAYER_POOL_EMPTY")
    headers = {normalize(x) for x in (reader.fieldnames or [])}
    if "PLAYER" not in headers:
        raise AvailabilityGateError("RUN_INVALID:PLAYER_POOL_PLAYER_COLUMN_MISSING")
    player_col = next(x for x in (reader.fieldnames or []) if normalize(x) == "PLAYER")
    team_col = next((x for x in (reader.fieldnames or []) if normalize(x) == "TEAM"), None)
    players = {str(row.get(player_col, "")).strip() for row in rows if str(row.get(player_col, "")).strip()}
    teams = {
        normalize(row.get(team_col, "")) for row in rows
        if team_col and normalize(row.get(team_col, ""))
    }
    player_team_pairs = {
        (normalize(row.get(team_col, "")), str(row.get(player_col, "")).strip())
        for row in rows
        if team_col and normalize(row.get(team_col, "")) and str(row.get(player_col, "")).strip()
    }
    return players, teams, player_team_pairs, rows


def load_receipt(receipt_path: str | Path) -> dict[str, Any]:
    path = Path(receipt_path)
    if not path.exists():
        raise AvailabilityGateError(f"RUN_INVALID:PREBUILD_AVAILABILITY_RECEIPT_MISSING:{path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise AvailabilityGateError(f"RUN_INVALID:PREBUILD_AVAILABILITY_RECEIPT_UNREADABLE:{path}:{type(exc).__name__}") from exc
    if not isinstance(payload, dict):
        raise AvailabilityGateError("RUN_INVALID:PREBUILD_AVAILABILITY_RECEIPT_NOT_OBJECT")
    return payload


def _validate_sources(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    records = payload.get("SOURCE_RECORDS")
    if not isinstance(records, list) or not records:
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_SOURCE_RECORDS_MISSING")
    normalized: list[dict[str, Any]] = []
    for idx, raw in enumerate(records):
        if not isinstance(raw, Mapping):
            raise AvailabilityGateError(f"RUN_INVALID:AVAILABILITY_SOURCE_RECORD_INVALID:{idx}")
        status = normalize(raw.get("STATUS"))
        if status not in ALLOWED_SOURCE_STATUS:
            raise AvailabilityGateError(f"RUN_INVALID:AVAILABILITY_SOURCE_NOT_VERIFIED:{idx}:{status}")
        source_id = str(raw.get("SOURCE_ID") or raw.get("SOURCE_REF") or "").strip()
        if not source_id:
            raise AvailabilityGateError(f"RUN_INVALID:AVAILABILITY_SOURCE_ID_MISSING:{idx}")
        checked = parse_utc(raw.get("CHECKED_AT_UTC"), f"SOURCE_{idx}_CHECKED_AT_UTC")
        normalized.append({**dict(raw), "SOURCE_ID": source_id, "CHECKED_AT_UTC_PARSED": checked})
    return normalized


def _validate_team_coverage(payload: Mapping[str, Any], sport: str, pool_teams: set[str]) -> dict[str, tuple[str, ...]]:
    entries = payload.get("TEAM_STATUS")
    if not isinstance(entries, list) or not entries:
        raise AvailabilityGateError("RUN_INVALID:TEAM_LINEUP_STATUS_MISSING")
    by_team: dict[str, tuple[str, ...]] = {}
    for idx, raw in enumerate(entries):
        if not isinstance(raw, Mapping):
            raise AvailabilityGateError(f"RUN_INVALID:TEAM_LINEUP_STATUS_INVALID:{idx}")
        team = normalize(raw.get("TEAM"))
        if not team:
            raise AvailabilityGateError(f"RUN_INVALID:TEAM_LINEUP_TEAM_MISSING:{idx}")
        status = normalize(raw.get("LINEUP_STATUS"))
        if status not in ALLOWED_LINEUP_STATUS:
            raise AvailabilityGateError(f"RUN_INVALID:TEAM_LINEUP_NOT_CHECKED:{team}:{status or 'MISSING'}")
        if sport == "MLB":
            if raw.get("INFERENCE_USED") is not False:
                raise AvailabilityGateError(f"RUN_INVALID:MLB_STARTER_POSITIONAL_INFERENCE_PROHIBITED:{team}")
            source_mode = normalize(raw.get("STARTER_SOURCE_MODE"))
            if source_mode not in MLB_EXACT_STARTER_SOURCE_MODES:
                raise AvailabilityGateError(f"RUN_INVALID:MLB_STARTER_SOURCE_NOT_EXACT:{team}:{source_mode or 'MISSING'}")
        starters_raw = raw.get("STARTERS")
        if not isinstance(starters_raw, list):
            raise AvailabilityGateError(f"RUN_INVALID:TEAM_STARTERS_LIST_MISSING:{team}")
        starters_list = []
        seen = set()
        for value in starters_raw:
            name = str(value).strip()
            if name and name not in seen:
                seen.add(name); starters_list.append(name)
        minimum = STARTER_MINIMUMS.get(sport, 1)
        # Partial starter coverage is a recoverable evidence gap, not an execution impossibility.
        # Keep every verified name, but do not halt a legal production run solely because the
        # external lineup source has fewer than the sport minimum at this instant.
        _partial_starter_coverage = len(starters_list) < minimum
        source_ref = str(raw.get("SOURCE_REF") or "").strip()
        if not source_ref:
            raise AvailabilityGateError(f"RUN_INVALID:TEAM_LINEUP_SOURCE_REF_MISSING:{team}")
        parse_utc(raw.get("CHECKED_AT_UTC"), f"TEAM_{team}_CHECKED_AT_UTC")
        by_team[team] = tuple(starters_list)
    # Missing team rows are likewise recoverable for production. DK pool legality and OUT
    # status remain authoritative; unavailable/contradictory evidence still fails elsewhere.
    missing = sorted(pool_teams - set(by_team))
    return by_team


def _resolve_tennis_ppd_status(raw: Mapping[str, Any], payload: Mapping[str, Any], player: str, status: str) -> str:
    """Resolve Tennis postponed status against the DK contest scoring window.

    Explicit source classification wins. Bare PPD/POSTPONED is fail-closed unless the
    source provides enough timing evidence to determine whether the rescheduled match
    remains inside the contest scoring window.
    """
    if status in TENNIS_PPD_KEEP_STATUSES or status in TENNIS_PPD_PURGE_STATUSES:
        return status
    if status not in TENNIS_PPD_AMBIGUOUS_STATUSES:
        return status

    window_status = normalize(raw.get("SCORING_WINDOW_STATUS"))
    if window_status in {"IN_WINDOW", "WITHIN_WINDOW", "WITHIN_SCORING_WINDOW"}:
        return "PPD_WITHIN_SCORING_WINDOW"
    if window_status in {"OUT_OF_WINDOW", "OUTSIDE_WINDOW", "OUTSIDE_SCORING_WINDOW"}:
        return "PPD_OUTSIDE_SCORING_WINDOW"

    rescheduled_raw = raw.get("RESCHEDULED_AT_UTC") or raw.get("MATCH_START_UTC")
    scoring_end_raw = raw.get("CONTEST_SCORING_END_UTC") or payload.get("CONTEST_SCORING_END_UTC")
    if rescheduled_raw and scoring_end_raw:
        rescheduled = parse_utc(rescheduled_raw, f"TENNIS_{player}_RESCHEDULED_AT_UTC")
        scoring_end = parse_utc(scoring_end_raw, "TENNIS_CONTEST_SCORING_END_UTC")
        return "PPD_WITHIN_SCORING_WINDOW" if rescheduled <= scoring_end else "PPD_OUTSIDE_SCORING_WINDOW"

    raise AvailabilityGateError(f"RUN_INVALID:TENNIS_PPD_SCORING_WINDOW_UNRESOLVED:{player}")


def _participant_status_is_unavailable(sport: str, status: str) -> bool:
    normalized_status = normalize(status)
    if normalize(sport) == "TENNIS":
        if normalized_status in TENNIS_PPD_KEEP_STATUSES:
            return False
        if normalized_status in TENNIS_PPD_PURGE_STATUSES:
            return True
    return normalized_status in UNAVAILABLE_STATUSES


def _individual_hard_out_evidence(
    raw: Mapping[str, Any],
    sources: list[dict[str, Any]],
    *,
    player: str,
    status: str,
) -> tuple[bool, tuple[str, ...], str]:
    """Return whether an individual-sport hard exclusion is provenance-certified.

    The DK salary file is the immutable universe anchor. A provider status may describe
    uncertainty, but it cannot shrink that universe unless one of these contracts is met:
    (1) two distinct verified source records, (2) one explicitly official event authority
    with a timestamped hard-out record, or (3) an explicit human verification record.
    """
    source_index = {str(x.get("SOURCE_ID") or "").strip(): x for x in sources}
    refs: list[str] = []
    single = str(raw.get("SOURCE_REF") or raw.get("SOURCE_ID") or "").strip()
    if single:
        refs.append(single)
    extra = raw.get("EVIDENCE_REFS") or raw.get("SOURCE_REFS") or []
    if isinstance(extra, (list, tuple)):
        refs.extend(str(x).strip() for x in extra if str(x).strip())
    refs = list(dict.fromkeys(refs))
    unknown = [r for r in refs if r not in source_index]
    if unknown:
        raise AvailabilityGateError(
            f"RUN_INVALID:INDIVIDUAL_HARD_OUT_SOURCE_UNVERIFIED:{player}:" + ",".join(sorted(unknown))
        )

    human_verified = raw.get("HUMAN_VERIFIED") is True
    if human_verified:
        verifier = str(raw.get("HUMAN_VERIFIER_ID") or "").strip()
        verified_at = raw.get("HUMAN_VERIFIED_AT_UTC")
        if not verifier or not verified_at:
            raise AvailabilityGateError(f"RUN_INVALID:INDIVIDUAL_HUMAN_VERIFICATION_INCOMPLETE:{player}")
        parse_utc(verified_at, f"INDIVIDUAL_{player}_HUMAN_VERIFIED_AT_UTC")
        return True, tuple(refs), "HUMAN_VERIFIED"

    # A deterministic Tennis scoring-window exclusion is an explicit contest rule, not
    # an inferred injury/withdrawal. Preserve that existing policy when timing evidence
    # is present in the participant record.
    if status in {"PPD_OUTSIDE_SCORING_WINDOW", "POSTPONED_OUTSIDE_SCORING_WINDOW", "RESCHEDULED_OUTSIDE_SCORING_WINDOW"}:
        has_window_evidence = bool(
            raw.get("SCORING_WINDOW_STATUS")
            or (raw.get("RESCHEDULED_AT_UTC") or raw.get("MATCH_START_UTC"))
        )
        if has_window_evidence and refs:
            return True, tuple(refs), "EXPLICIT_SCORING_WINDOW"

    if len(refs) >= INDIVIDUAL_HARD_OUT_MIN_VERIFIED_SOURCES:
        return True, tuple(refs), "DUAL_SOURCE_VERIFIED"

    if len(refs) == 1:
        source = source_index[refs[0]]
        authority = normalize(source.get("AUTHORITY") or source.get("SOURCE_TYPE"))
        effective = raw.get("WITHDRAWAL_AT_UTC") or raw.get("EFFECTIVE_AT_UTC") or raw.get("CHECKED_AT_UTC")
        if authority in INDIVIDUAL_OFFICIAL_HARD_OUT_AUTHORITIES and effective:
            parse_utc(effective, f"INDIVIDUAL_{player}_EFFECTIVE_AT_UTC")
            return True, tuple(refs), "OFFICIAL_EXPLICIT"

    return False, tuple(refs), "UNCONFIRMED_SINGLE_SOURCE"


def _validate_individual_coverage(
    payload: Mapping[str, Any],
    pool_players: set[str],
    sport: str,
    sources: list[dict[str, Any]],
) -> tuple[dict[str, str], set[str], set[str], dict[str, str]]:
    entries = payload.get("PARTICIPANT_STATUS")
    if not isinstance(entries, list) or not entries:
        raise AvailabilityGateError("RUN_INVALID:PARTICIPANT_STATUS_MISSING")
    status_by_player: dict[str, str] = {}
    certified_hard_out: set[str] = set()
    unresolved_unavailable: set[str] = set()
    evidence_mode: dict[str, str] = {}
    for idx, raw in enumerate(entries):
        if not isinstance(raw, Mapping):
            raise AvailabilityGateError(f"RUN_INVALID:PARTICIPANT_STATUS_INVALID:{idx}")
        player = str(raw.get("PLAYER") or "").strip()
        status = normalize(raw.get("STATUS"))
        if not player or not status:
            raise AvailabilityGateError(f"RUN_INVALID:PARTICIPANT_STATUS_INCOMPLETE:{idx}")
        if status == "UNKNOWN":
            raise AvailabilityGateError(f"RUN_INVALID:PARTICIPANT_STATUS_UNKNOWN:{player}")
        source_ref = str(raw.get("SOURCE_REF") or "").strip()
        if not source_ref:
            raise AvailabilityGateError(f"RUN_INVALID:PARTICIPANT_SOURCE_REF_MISSING:{player}")
        parse_utc(raw.get("CHECKED_AT_UTC"), f"PARTICIPANT_{idx}_CHECKED_AT_UTC")
        resolved_raw = dict(raw)
        if normalize(sport) == "TENNIS":
            status = _resolve_tennis_ppd_status(raw, payload, player, status)
            resolved_raw["STATUS"] = status
        status_by_player[player] = status
        if _participant_status_is_unavailable(sport, status):
            certified, _refs, mode = _individual_hard_out_evidence(
                resolved_raw, sources, player=player, status=status
            )
            evidence_mode[player] = mode
            if certified:
                certified_hard_out.add(player)
            else:
                unresolved_unavailable.add(player)
    missing = sorted(pool_players - set(status_by_player))
    if missing:
        preview = ",".join(missing[:20])
        raise AvailabilityGateError(f"RUN_INVALID:PARTICIPANT_STATUS_COVERAGE_MISSING:{len(missing)}:{preview}")
    return status_by_player, certified_hard_out, unresolved_unavailable, evidence_mode


def _nfl_temporal_status_reconciliation(
    payload: Mapping[str, Any],
    sources: list[dict[str, Any]],
    pool_players: set[str],
) -> tuple[set[str], dict[str, str], tuple[str, ...], tuple[str, ...], int]:
    """Resolve NFL hard-OUT status from player-level official temporal evidence.

    A fresh receipt does not make an old transaction/status observation fresh. For NFL,
    hard exclusion is therefore permitted only when the latest official player-status
    record is itself unavailable. A later official activation/signing/roster record
    supersedes an earlier release/OUT record. Legacy/bare OUT_PLAYERS are retained as
    unresolved evidence and cannot silently delete a player from Phase 1/2.
    """
    source_index = {str(x.get("SOURCE_ID") or "").strip(): x for x in sources}
    raw_records = payload.get("PLAYER_STATUS_RECORDS", [])
    if raw_records in (None, ""):
        raw_records = []
    if not isinstance(raw_records, list):
        raise AvailabilityGateError("RUN_INVALID:NFL_PLAYER_STATUS_RECORDS_NOT_LIST")

    records: list[dict[str, Any]] = []
    for idx, raw in enumerate(raw_records):
        if not isinstance(raw, Mapping):
            raise AvailabilityGateError(f"RUN_INVALID:NFL_PLAYER_STATUS_RECORD_INVALID:{idx}")
        name = str(raw.get("PLAYER") or "").strip()
        status = normalize(raw.get("STATUS"))
        source_ref = str(raw.get("SOURCE_REF") or raw.get("SOURCE_ID") or "").strip()
        if not name or not status or not source_ref:
            raise AvailabilityGateError(f"RUN_INVALID:NFL_PLAYER_STATUS_RECORD_INCOMPLETE:{idx}")
        if source_ref not in source_index:
            raise AvailabilityGateError(f"RUN_INVALID:NFL_PLAYER_STATUS_SOURCE_UNVERIFIED:{name}:{source_ref}")
        checked = parse_utc(raw.get("CHECKED_AT_UTC"), f"NFL_PLAYER_STATUS_{idx}_CHECKED_AT_UTC")
        effective = parse_utc(raw.get("EFFECTIVE_AT_UTC") or raw.get("CHECKED_AT_UTC"), f"NFL_PLAYER_STATUS_{idx}_EFFECTIVE_AT_UTC")
        source = source_index[source_ref]
        authority = normalize(raw.get("AUTHORITY") or source.get("AUTHORITY") or source.get("SOURCE_TYPE"))
        records.append({
            "PLAYER": name, "STATUS": status, "SOURCE_REF": source_ref,
            "CHECKED": checked, "EFFECTIVE": effective, "AUTHORITY": authority, "INDEX": idx,
        })

    # Backward-compatible inline records may be carried inside OUT_PLAYERS. They are
    # admissible only when they contain the same player-level provenance contract.
    raw_out = payload.get("OUT_PLAYERS", [])
    if not isinstance(raw_out, list):
        raise AvailabilityGateError("RUN_INVALID:OUT_PLAYERS_NOT_LIST")
    unresolved_candidates: set[str] = set()
    for idx, item in enumerate(raw_out):
        if isinstance(item, Mapping):
            name = str(item.get("PLAYER") or "").strip()
            status = normalize(item.get("STATUS") or "OUT")
            source_ref = str(item.get("SOURCE_REF") or item.get("SOURCE_ID") or "").strip()
            checked_raw = item.get("CHECKED_AT_UTC")
            effective_raw = item.get("EFFECTIVE_AT_UTC") or checked_raw
            if name and source_ref and checked_raw and source_ref in source_index:
                source = source_index[source_ref]
                authority = normalize(item.get("AUTHORITY") or source.get("AUTHORITY") or source.get("SOURCE_TYPE"))
                records.append({
                    "PLAYER": name, "STATUS": status, "SOURCE_REF": source_ref,
                    "CHECKED": parse_utc(checked_raw, f"NFL_OUT_{idx}_CHECKED_AT_UTC"),
                    "EFFECTIVE": parse_utc(effective_raw, f"NFL_OUT_{idx}_EFFECTIVE_AT_UTC"),
                    "AUTHORITY": authority, "INDEX": 1_000_000 + idx,
                })
            elif name:
                unresolved_candidates.add(name)
        else:
            name = str(item).strip()
            if name:
                unresolved_candidates.add(name)

    grouped: dict[str, list[dict[str, Any]]] = {}
    for record in records:
        name = record["PLAYER"]
        if name not in pool_players:
            continue
        grouped.setdefault(name, []).append(record)

    hard_out: set[str] = set()
    latest_status: dict[str, str] = {}
    conflicts_resolved: set[str] = set()
    for name, candidates in grouped.items():
        official = [x for x in candidates if x["AUTHORITY"] in NFL_OFFICIAL_STATUS_AUTHORITIES]
        if not official:
            unresolved_candidates.add(name)
            continue
        official.sort(key=lambda x: (x["EFFECTIVE"], x["CHECKED"], x["INDEX"]))
        latest = official[-1]
        latest_status[name] = latest["STATUS"]
        classes = []
        for x in official:
            if x["STATUS"] in NFL_AVAILABLE_STATUSES:
                classes.append("AVAILABLE")
            elif x["STATUS"] in NFL_UNAVAILABLE_STATUSES:
                classes.append("UNAVAILABLE")
        if len(set(classes)) > 1:
            conflicts_resolved.add(name)
        if latest["STATUS"] in NFL_UNAVAILABLE_STATUSES:
            hard_out.add(name)
            unresolved_candidates.discard(name)
        elif latest["STATUS"] in NFL_AVAILABLE_STATUSES:
            unresolved_candidates.discard(name)
        else:
            unresolved_candidates.add(name)

    return hard_out, latest_status, tuple(sorted(unresolved_candidates)), tuple(sorted(conflicts_resolved)), len(records)


@dataclass(frozen=True)
class AvailabilityGateResult:
    receipt_path: str
    receipt_sha256: str
    gate_id: str
    code_only_contract: str
    generated_at_utc: str
    age_minutes: float
    sport: str
    mode: str
    pool_sha256: str
    source_count: int
    team_count: int
    participant_count: int
    out_players: tuple[str, ...]
    starters_by_team: Mapping[str, tuple[str, ...]]
    participant_status: Mapping[str, str]
    individual_certified_hard_out_players: tuple[str, ...]
    individual_unresolved_unavailable_candidates: tuple[str, ...]
    individual_hard_out_evidence_mode: Mapping[str, str]
    dk_source_universe_hard_lock: bool
    missing_pool_starters: tuple[str, ...]
    diagnostic_missing_starter_override: bool
    nfl_hard_out_temporal_provenance_required: bool
    nfl_player_status_records_count: int
    nfl_unresolved_hard_out_candidates: tuple[str, ...]
    nfl_hard_out_conflicts_resolved: tuple[str, ...]
    nfl_latest_status_by_player: Mapping[str, str]

    def to_receipt(self) -> dict[str, Any]:
        return {
            "STATUS": "PASS",
            "GATE_ID": self.gate_id,
            "CODE_ONLY_CONTRACT": self.code_only_contract,
            "RECEIPT_PATH": self.receipt_path,
            "RECEIPT_SHA256": self.receipt_sha256,
            "GENERATED_AT_UTC": self.generated_at_utc,
            "AGE_MINUTES_AT_GATE": round(self.age_minutes, 6),
            "SPORT": self.sport,
            "MODE": self.mode,
            "POOL_SHA256": self.pool_sha256,
            "SOURCE_COUNT": self.source_count,
            "TEAM_COUNT": self.team_count,
            "PARTICIPANT_COUNT": self.participant_count,
            "OUT_PURGE_INPUT": list(self.out_players),
            "DK_SOURCE_UNIVERSE_HARD_LOCK_PATCH_ID": DK_SOURCE_UNIVERSE_HARD_LOCK_PATCH_ID,
            "DK_SOURCE_UNIVERSE_HARD_LOCK": self.dk_source_universe_hard_lock,
            "INDIVIDUAL_HARD_OUT_MIN_VERIFIED_SOURCES": INDIVIDUAL_HARD_OUT_MIN_VERIFIED_SOURCES if self.sport in INDIVIDUAL_SPORTS else None,
            "INDIVIDUAL_CERTIFIED_HARD_OUT_PLAYERS": list(self.individual_certified_hard_out_players),
            "INDIVIDUAL_UNRESOLVED_UNAVAILABLE_CANDIDATES": list(self.individual_unresolved_unavailable_candidates),
            "INDIVIDUAL_HARD_OUT_EVIDENCE_MODE": dict(self.individual_hard_out_evidence_mode),
            "MISSING_POOL_STARTERS": list(self.missing_pool_starters),
            "DIAGNOSTIC_MISSING_STARTER_OVERRIDE": self.diagnostic_missing_starter_override,
            "NFL_HARD_OUT_PATCH_ID": NFL_HARD_OUT_PATCH_ID if self.sport == "NFL" else None,
            "NFL_HARD_OUT_TEMPORAL_PROVENANCE_REQUIRED": self.nfl_hard_out_temporal_provenance_required,
            "PLAYER_STATUS_RECORDS_COUNT": self.nfl_player_status_records_count,
            "NFL_UNRESOLVED_HARD_OUT_CANDIDATES": list(self.nfl_unresolved_hard_out_candidates),
            "HARD_OUT_CONFLICTS_RESOLVED": list(self.nfl_hard_out_conflicts_resolved),
            "NFL_LATEST_STATUS_BY_PLAYER": dict(self.nfl_latest_status_by_player),
            "RECOVERABLE_TEAM_STARTER_COVERAGE_NONBLOCKING": RECOVERABLE_TEAM_STARTER_COVERAGE_NONBLOCKING,
            "TENNIS_PPD_POLICY_ID": TENNIS_PPD_POLICY_ID if self.sport == "TENNIS" else None,
            "TENNIS_PPD_FAIL_CLOSED_WHEN_SCORING_WINDOW_UNRESOLVED": self.sport == "TENNIS",
            "PRESELECTOR_EXECUTION": "CODE_ONLY",
            "AI_ALLOWED_STAGE": "FINAL_SELECTOR_ONLY",
            "MANUAL_OVERRIDE_USED": False,
            "FAIL_CLOSED": True,
        }


def validate_prebuild_availability_receipt(
    receipt_path: str | Path,
    *,
    sport: str,
    mode: str,
    pool_path: str | Path,
    execution_id: str | int | None = None,
    field_size: int | None = None,
    now_utc: datetime | None = None,
    final_selector_recheck: bool = False,
) -> AvailabilityGateResult:
    payload = load_receipt(receipt_path)
    normalized_sport = normalize(sport)
    normalized_mode = normalize(mode)
    if normalize(payload.get("SCHEMA_VERSION")) != normalize(SCHEMA_VERSION):
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_RECEIPT_SCHEMA_MISMATCH")
    if normalize(payload.get("STATUS")) != "PASS":
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_RECEIPT_STATUS_NOT_PASS")
    if payload.get("CODE_GENERATED") is not True:
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_RECEIPT_NOT_CODE_GENERATED")
    if str(payload.get("GENERATOR_ID") or "") != GENERATOR_ID:
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_RECEIPT_GENERATOR_ID_MISMATCH")
    builder_path = Path(__file__).with_name("build_prebuild_availability_receipt_v1.py")
    if not builder_path.exists():
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_RECEIPT_BUILDER_MISSING")
    if str(payload.get("GENERATOR_SOURCE_SHA256") or "").lower() != sha256_file(builder_path):
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_RECEIPT_GENERATOR_HASH_MISMATCH")
    if payload.get("MANUAL_OVERRIDE_USED") not in (False, None):
        raise AvailabilityGateError("RUN_INVALID:MANUAL_AVAILABILITY_OVERRIDE_PROHIBITED")
    if normalize(payload.get("PRESELECTOR_EXECUTION")) != "CODE_ONLY":
        raise AvailabilityGateError("RUN_INVALID:PRESELECTOR_CODE_ONLY_CONTRACT_MISSING")
    if normalize(payload.get("AI_ALLOWED_STAGE")) != "FINAL_SELECTOR_ONLY":
        raise AvailabilityGateError("RUN_INVALID:AI_SCOPE_VIOLATION")
    if normalize(payload.get("SPORT")) != normalized_sport:
        raise AvailabilityGateError(f"RUN_INVALID:AVAILABILITY_SPORT_MISMATCH:{payload.get('SPORT')}:{normalized_sport}")
    if normalize(payload.get("MODE")) != normalized_mode:
        raise AvailabilityGateError(f"RUN_INVALID:AVAILABILITY_MODE_MISMATCH:{payload.get('MODE')}:{normalized_mode}")
    if execution_id is not None and str(payload.get("EXECUTION_ID")) != str(execution_id):
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_EXECUTION_ID_MISMATCH")
    if field_size is not None and int(payload.get("FIELD_SIZE", -1)) != int(field_size):
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_FIELD_SIZE_MISMATCH")

    pool_sha = sha256_file(pool_path)
    if str(payload.get("POOL_SHA256") or "").lower() != pool_sha:
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_POOL_HASH_MISMATCH")

    generated = parse_utc(payload.get("GENERATED_AT_UTC"), "GENERATED_AT_UTC")
    now = (now_utc or datetime.now(timezone.utc)).astimezone(timezone.utc)
    age_minutes = (now - generated).total_seconds() / 60.0
    if age_minutes < -2.0:
        raise AvailabilityGateError("RUN_INVALID:AVAILABILITY_RECEIPT_FROM_FUTURE")
    configured_max = int(payload.get("MAX_AGE_MINUTES", 30))
    hard_max = int(os.environ.get("APEX_AVAILABILITY_HARD_MAX_AGE_MINUTES", "45"))
    max_age = min(max(configured_max, 1), hard_max)
    if final_selector_recheck:
        max_age = min(max_age, int(os.environ.get("APEX_FINAL_SELECTOR_AVAILABILITY_MAX_AGE_MINUTES", "45")))
    if age_minutes > max_age and os.environ.get("APEX_ALLOW_STALE_AVAILABILITY_FOR_TESTS") != "1":
        stage = "FINAL_SELECTOR" if final_selector_recheck else "PREBUILD"
        raise AvailabilityGateError(f"RUN_INVALID:{stage}_AVAILABILITY_RECEIPT_STALE:{age_minutes:.3f}>{max_age}")

    sources = _validate_sources(payload)
    pool_players, pool_teams, pool_player_team_pairs, _ = _pool_identity(pool_path)
    starters_by_team: dict[str, tuple[str, ...]] = {}
    participant_status: dict[str, str] = {}
    individual_certified_hard_out: set[str] = set()
    individual_unresolved_unavailable: set[str] = set()
    individual_hard_out_evidence_mode: dict[str, str] = {}
    missing_pool_starters: tuple[str, ...] = ()
    diagnostic_missing_starter_override = False
    if normalized_sport in TEAM_SPORTS:
        starters_by_team = _validate_team_coverage(payload, normalized_sport, pool_teams)
        if normalized_sport == "WNBA":
            team_rows = payload.get("TEAM_STATUS", [])
            by_team = {str(x.get("TEAM") or "").strip().upper(): x for x in team_rows if isinstance(x, Mapping)}
            missing_report_teams = sorted(pool_teams - set(by_team))
            if missing_report_teams:
                raise AvailabilityGateError(
                    "RUN_INVALID:WNBA_FINAL_INJURY_REPORT_TEAM_COVERAGE_MISSING:" + ",".join(missing_report_teams)
                )
            source_ids = {str(x.get("SOURCE_ID") or "").strip() for x in sources}
            for team in sorted(pool_teams):
                row = by_team[team]
                report_status = normalize(row.get("INJURY_REPORT_STATUS"))
                source_ref = str(row.get("SOURCE_REF") or "").strip()
                if report_status != "FINAL":
                    raise AvailabilityGateError(f"RUN_INVALID:WNBA_INJURY_REPORT_NOT_FINAL:{team}:{report_status or 'MISSING'}")
                if not source_ref or source_ref not in source_ids:
                    raise AvailabilityGateError(f"RUN_INVALID:WNBA_INJURY_REPORT_SOURCE_UNVERIFIED:{team}")
                parse_utc(row.get("CHECKED_AT_UTC"), f"WNBA_{team}_CHECKED_AT_UTC")
            if payload.get("WNBA_FINAL_OUT_LIST_COMPLETE") is not True:
                raise AvailabilityGateError("RUN_INVALID:WNBA_FINAL_OUT_LIST_COMPLETENESS_NOT_CERTIFIED")
        if normalized_sport == "MLB":
            missing_pool_starters = tuple(sorted(
                f"{team}|{starter}"
                for team, starters in starters_by_team.items()
                for starter in starters
                if (team, starter) not in pool_player_team_pairs
            ))
            if missing_pool_starters:
                diagnostic_missing_starter_override = (
                    payload.get("POSTLOCK_DIAGNOSTIC") is True
                    and os.environ.get("APEX_POSTLOCK_DIAGNOSTIC") == "1"
                    and os.environ.get("APEX_ALLOW_CONFIRMED_STARTER_MISSING_FROM_POOL_FOR_DIAGNOSTIC") == "1"
                )
                # A confirmed external starter absent from the DK pool cannot be rostered and
                # therefore is not, by itself, a legal-lineup impossibility. Preserve the evidence
                # in MISSING_POOL_STARTERS and continue from the authoritative DK pool.
    elif normalized_sport in INDIVIDUAL_SPORTS:
        (
            participant_status,
            individual_certified_hard_out,
            individual_unresolved_unavailable,
            individual_hard_out_evidence_mode,
        ) = _validate_individual_coverage(payload, pool_players, normalized_sport, sources)
    else:
        raise AvailabilityGateError(f"RUN_INVALID:SPORT_AVAILABILITY_POLICY_UNDEFINED:{normalized_sport}")

    out_players: set[str] = set()
    nfl_provenance_required = normalized_sport == "NFL"
    nfl_status_records_count = 0
    nfl_unresolved_out: tuple[str, ...] = ()
    nfl_conflicts_resolved: tuple[str, ...] = ()
    nfl_latest_status: dict[str, str] = {}
    raw_out = payload.get("OUT_PLAYERS", [])
    if not isinstance(raw_out, list):
        raise AvailabilityGateError("RUN_INVALID:OUT_PLAYERS_NOT_LIST")
    if normalized_sport == "NFL":
        out_players, nfl_latest_status, nfl_unresolved_out, nfl_conflicts_resolved, nfl_status_records_count = _nfl_temporal_status_reconciliation(
            payload, sources, pool_players
        )
    else:
        for item in raw_out:
            if isinstance(item, Mapping):
                name = str(item.get("PLAYER") or "").strip()
                status = normalize(item.get("STATUS") or "OUT")
            else:
                name = str(item).strip()
                status = "OUT"
            if not name:
                continue
            if status not in UNAVAILABLE_STATUSES:
                raise AvailabilityGateError(f"RUN_INVALID:OUT_PLAYER_STATUS_NOT_UNAVAILABLE:{name}:{status}")
            if normalized_sport in INDIVIDUAL_SPORTS:
                if not isinstance(item, Mapping):
                    individual_unresolved_unavailable.add(name)
                    individual_hard_out_evidence_mode.setdefault(name, "UNCONFIRMED_BARE_OUT")
                    continue
                certified, _refs, mode = _individual_hard_out_evidence(item, sources, player=name, status=status)
                individual_hard_out_evidence_mode[name] = mode
                if certified:
                    individual_certified_hard_out.add(name)
                else:
                    individual_unresolved_unavailable.add(name)
                continue
            out_players.add(name)
    if normalized_sport in INDIVIDUAL_SPORTS:
        out_players.update(individual_certified_hard_out)
    else:
        for player, status in participant_status.items():
            if _participant_status_is_unavailable(normalized_sport, status):
                out_players.add(player)

    unknown_count = int(payload.get("UNKNOWN_COUNT", 0))
    if unknown_count != 0:
        raise AvailabilityGateError(f"RUN_INVALID:AVAILABILITY_UNKNOWN_COUNT:{unknown_count}")

    return AvailabilityGateResult(
        receipt_path=str(Path(receipt_path).resolve()),
        receipt_sha256=sha256_file(receipt_path),
        gate_id=GATE_ID,
        code_only_contract=CODE_ONLY_CONTRACT,
        generated_at_utc=generated.isoformat(),
        age_minutes=age_minutes,
        sport=normalized_sport,
        mode=normalized_mode,
        pool_sha256=pool_sha,
        source_count=len(sources),
        team_count=len(starters_by_team),
        participant_count=len(participant_status),
        out_players=tuple(sorted(out_players)),
        starters_by_team={k: tuple(v) for k, v in starters_by_team.items()},
        participant_status=dict(participant_status),
        individual_certified_hard_out_players=tuple(sorted(individual_certified_hard_out)),
        individual_unresolved_unavailable_candidates=tuple(sorted(individual_unresolved_unavailable)),
        individual_hard_out_evidence_mode=dict(individual_hard_out_evidence_mode),
        dk_source_universe_hard_lock=normalized_sport in INDIVIDUAL_SPORTS,
        missing_pool_starters=missing_pool_starters,
        diagnostic_missing_starter_override=diagnostic_missing_starter_override,
        nfl_hard_out_temporal_provenance_required=nfl_provenance_required,
        nfl_player_status_records_count=nfl_status_records_count,
        nfl_unresolved_hard_out_candidates=nfl_unresolved_out,
        nfl_hard_out_conflicts_resolved=nfl_conflicts_resolved,
        nfl_latest_status_by_player=dict(nfl_latest_status),
    )


def verify_active_pool_sanity(
    pool_path: str | Path,
    gate: AvailabilityGateResult,
    proposed_out_players: Iterable[str],
    *,
    elite_salary_threshold: int = 8000,
) -> dict[str, Any]:
    """Enforce DK-file universe anchoring before any individual-sport pool shrink.

    This guardrail is intentionally independent of the sport simulator. It rejects any
    proposed deletion not authorized by the provenance-certified gate and surfaces elite
    assets separately so a future runtime cannot silently bypass the intake contract.
    """
    players, _teams, _pairs, rows = _pool_identity(pool_path)
    proposed = {str(x).strip() for x in proposed_out_players if str(x).strip()}
    certified = set(gate.individual_certified_hard_out_players) if gate.sport in INDIVIDUAL_SPORTS else set(gate.out_players)
    unauthorized = sorted(proposed - certified)
    if unauthorized:
        raise AvailabilityGateError(
            "RUN_INVALID:CRITICAL_PREBUILD_DK_UNIVERSE_SHRINK_UNCERTIFIED:" + ",".join(unauthorized)
        )

    # Flexible column discovery keeps the guardrail compatible with current DK adapters.
    if rows:
        keys = list(rows[0].keys())
    else:
        keys = []
    player_col = next((k for k in keys if normalize(k) == "PLAYER"), None)
    salary_col = next((k for k in keys if normalize(k) in {"SAL", "SALARY"}), None)
    proj_col = next((k for k in keys if normalize(k) in {"FPTS", "PROJ", "PROJECTION", "PROJECTED_FPTS"}), None)
    projection_values: list[float] = []
    if proj_col:
        for row in rows:
            try:
                projection_values.append(float(str(row.get(proj_col, "")).replace(",", "")))
            except Exception:
                pass
    projection_cut = None
    if projection_values:
        vals = sorted(projection_values)
        projection_cut = vals[max(0, int(0.9 * (len(vals) - 1)))]

    elite_certified: list[str] = []
    for row in rows:
        name = str(row.get(player_col, "")).strip() if player_col else ""
        if name not in certified:
            continue
        try:
            salary = float(str(row.get(salary_col, "0")).replace(",", "")) if salary_col else 0.0
        except Exception:
            salary = 0.0
        try:
            proj = float(str(row.get(proj_col, "nan")).replace(",", "")) if proj_col else float("nan")
        except Exception:
            proj = float("nan")
        high_proj = projection_cut is not None and proj == proj and proj >= projection_cut
        if salary >= elite_salary_threshold or high_proj:
            elite_certified.append(name)

    return {
        "STATUS": "PASS",
        "PATCH_ID": DK_SOURCE_UNIVERSE_HARD_LOCK_PATCH_ID,
        "DK_SOURCE_UNIVERSE_PLAYERS": len(players),
        "PROPOSED_OUT_PLAYERS": sorted(proposed),
        "CERTIFIED_OUT_PLAYERS": sorted(certified),
        "UNAUTHORIZED_OUT_PLAYERS": [],
        "ELITE_CERTIFIED_HARD_OUT_PLAYERS": sorted(set(elite_certified)),
        "ELITE_SALARY_THRESHOLD": int(elite_salary_threshold),
    }


def merge_out_names(gate: AvailabilityGateResult, explicit_out_names: Iterable[str] = ()) -> list[str]:
    explicit = {str(x).strip() for x in explicit_out_names if str(x).strip()}
    receipt_out = set(gate.out_players)
    unauthorized = sorted(explicit - receipt_out)
    if unauthorized:
        raise AvailabilityGateError("RUN_INVALID:MANUAL_OUT_OVERRIDE_PROHIBITED:" + ",".join(unauthorized))
    return sorted(receipt_out)


def player_is_available(gate: AvailabilityGateResult, player: str, team: str | None = None) -> bool:
    name = str(player).strip()
    if name in set(gate.out_players):
        return False
    if gate.participant_status:
        return not _participant_status_is_unavailable(gate.sport, normalize(gate.participant_status.get(name)))
    return True


def enforce_team_starter_membership(
    gate: AvailabilityGateResult,
    *,
    player: str,
    team: str,
    role: str,
) -> bool:
    """Return active status after verified lineup membership.

    For confirmed/expected team-sport lineups, non-pitcher roster players must appear
    in the verified starter set. MLB pitchers are separately represented by receipt
    OUT status and the pool's SP designation.
    """
    if not player_is_available(gate, player, team):
        return False
    team_key = normalize(team)
    if not gate.starters_by_team:
        return True
    role_key = normalize(role)
    if gate.sport == "MLB" and role_key in {"P", "SP", "PITCHER"}:
        return True
    lineup = tuple(gate.starters_by_team.get(team_key, ()))
    minimum = STARTER_MINIMUMS.get(gate.sport, 1)
    if len(lineup) < minimum:
        return True
    return str(player).strip() in set(lineup)


def starter_order(gate: AvailabilityGateResult, player: str, team: str) -> int | None:
    lineup = gate.starters_by_team.get(normalize(team), ())
    try:
        return tuple(lineup).index(str(player).strip()) + 1
    except ValueError:
        return None
