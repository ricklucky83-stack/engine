from __future__ import annotations

"""APEX authority walk-forward persistence + offline calibration utilities.

Purpose
-------
Persist the *complete pre-lock selector-reviewed surface* without changing
candidate ordering or terminal selection, then grade projection/role vs MC
authority offline after contest resolution.

This module is observability/calibration infrastructure.  It is not a live
selector and has no authority to birth, prune, reorder, or reject lineups.
"""

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping, Sequence
import csv
import json
import math
import os
import shutil
import tempfile
import zipfile

PATCH_ID = "APEX_AUTHORITY_WALKFORWARD_PERSISTENCE_v1"
AUTHORITY_GRID = tuple(range(0, 101, 5))
DEFAULT_BOARD_SIZE = 5

# Keep this deliberately broad.  A pre-lock snapshot must never contain any
# realized contest truth.  Normalization strips spaces/hyphens/case.
FORBIDDEN_PRELOCK_FIELDS = frozenset({
    "CONTEST_RANK", "ACTUAL_FPTS", "REALIZED_FPTS", "POSTLOCK_SCORE",
    "REALIZED_SCORE", "ACTUAL_SCORE", "ACTUAL_RANK", "FINAL_CONTEST_RANK",
    "WINNING_LINEUP", "TARGET_ACTUAL_SCORE", "REALIZED_OWNERSHIP",
    "POSTLOCK_OWNERSHIP", "WINNER_LABEL", "IS_WINNER", "IS_PERFECT",
    "IS_TOP01", "IS_TOP_0_1", "IS_TOP1", "IS_TOP_1",
})

TRUTH_FIELDS = (
    "LINEUP_ID", "CONTEST_RANK", "ACTUAL_SCORE", "IS_WINNER", "IS_PERFECT",
    "IS_TOP01", "IS_TOP1",
)

# These are semantic roles, not hard gates.  Existing engines use different
# names, so the receipt records availability rather than refusing the run.
CHANNEL_ALIASES = {
    "DFS_ROLE": (
        "DFS_ROLE_AUTHORITY", "PROJECTION_ROLE_AUTHORITY", "PROJECTION_ROLE_PCTL",
        "DFS_INTELLIGENCE_PCTL", "ROLE_PROJECTION_PCTL", "PROJECTION_PCTL",
        "CURRENT_SELECTOR_SCORE", "STRATEGY_SCORE",
    ),
    "MC": (
        "MC_AUTHORITY", "MC_AUTHORITY_PCTL", "MC_RANK_PCTL", "MC_WIN_RATE",
        "MC_TOP_0_1_RATE", "MC_TOP01_RATE", "MC_TOP_1_RATE", "MC_P99",
        "P99", "WIN_RATE",
    ),
    "MC_SEED_STABILITY": (
        "CROSS_SEED_STABILITY", "RANK_STABILITY", "CALIBRATION_STABILITY",
    ),
}


def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _lineup_id(row: Mapping[str, Any]) -> str:
    cmap = {_norm(k): k for k in row}
    for name in ("LINEUP_ID", "ID", "ANON_ID", "KEY"):
        k = cmap.get(name)
        if k is not None and str(row.get(k, "")).strip():
            return str(row[k]).strip()
    # Stable roster-derived fallback.  Never use post-lock values.
    slots = []
    for name in ("PITCHER1", "PITCHER2", "P", "C", "1B", "2B", "3B", "SS",
                 "OF1", "OF2", "OF3", "CPT", "UTIL1", "UTIL2", "UTIL3", "UTIL4", "UTIL5"):
        k = cmap.get(name)
        if k is not None and str(row.get(k, "")).strip():
            slots.append(f"{name}:{str(row[k]).strip()}")
    if slots:
        return "|".join(slots)
    raise ValueError("AUTHORITY_PERSISTENCE_MISSING_LINEUP_ID")


def _csv_fields(rows: Sequence[Mapping[str, Any]]) -> list[str]:
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for k in row:
            if k not in seen:
                seen.add(k)
                fields.append(str(k))
    return fields


def _sha(path: Path) -> str:
    h = sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _channel_availability(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    cols = {_norm(k) for r in rows for k in r}
    out: dict[str, Any] = {}
    for channel, aliases in CHANNEL_ALIASES.items():
        present = [x for x in aliases if _norm(x) in cols]
        out[channel] = {"PRESENT": present, "AVAILABLE": bool(present)}
    return out


def validate_prelock_rows(rows: Sequence[Mapping[str, Any]]) -> None:
    if not rows:
        raise ValueError("AUTHORITY_PERSISTENCE_EMPTY_SURFACE")
    cols = {_norm(k) for r in rows for k in r}
    forbidden = sorted(cols & FORBIDDEN_PRELOCK_FIELDS)
    if forbidden:
        raise ValueError("AUTHORITY_PERSISTENCE_POSTLOCK_LEAK:" + ",".join(forbidden))
    seen: set[str] = set()
    for row in rows:
        lid = _lineup_id(row)
        if lid in seen:
            raise ValueError(f"AUTHORITY_PERSISTENCE_DUPLICATE_LINEUP_ID:{lid}")
        seen.add(lid)


def persist_prelock_snapshot(
    rows: Sequence[Mapping[str, Any]], *, sport: str, mode: str, execution_id: str,
    output_dir: str | Path, seed_id: str | int | None = None,
    context: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Write an immutable pre-lock replay surface and manifest.

    Candidate identity/order and values are copied exactly.  No score is
    calculated and no candidate is removed.  Existing files for the same
    execution_id are never silently overwritten.
    """
    frozen = [dict(r) for r in rows]
    validate_prelock_rows(frozen)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    stem = f"{str(sport).upper()}_{str(mode).upper()}_{execution_id}_AUTHORITY_PRELOCK"
    csv_path = out / f"{stem}.csv"
    manifest_path = out / f"{stem}_MANIFEST.json"
    if csv_path.exists() or manifest_path.exists():
        raise FileExistsError(f"AUTHORITY_PERSISTENCE_IMMUTABLE_SNAPSHOT_EXISTS:{stem}")

    fields = _csv_fields(frozen)
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(frozen)

    # Hash a canonical semantic representation too, so CSV formatting is not
    # the only identity proof.
    semantic = sorted((dict(r) for r in frozen), key=_lineup_id)
    semantic_sha = sha256(_canonical_json(semantic)).hexdigest()
    manifest = {
        "PATCH_ID": PATCH_ID,
        "STATUS": "PASS",
        "ARTIFACT_ROLE": "IMMUTABLE_PRELOCK_SELECTOR_REPLAY_SURFACE",
        "SPORT": str(sport).upper(),
        "MODE": str(mode).upper(),
        "EXECUTION_ID": str(execution_id),
        "SEED_ID": None if seed_id is None else str(seed_id),
        "CANDIDATE_COUNT": len(frozen),
        "CANDIDATE_ORDER_PRESERVED": True,
        "CANDIDATE_PRUNING": 0,
        "SELECTOR_ORDER_MUTATED": False,
        "PRODUCTION_SELECTION_AUTHORITY": False,
        "POSTLOCK_FIELDS_PRESENT": False,
        "SURFACE_CSV": str(csv_path),
        "SURFACE_CSV_SHA256": _sha(csv_path),
        "SEMANTIC_SURFACE_SHA256": semantic_sha,
        "CHANNEL_AVAILABILITY": _channel_availability(frozen),
        "COLUMN_COUNT": len(fields),
        "COLUMNS": fields,
        "CONTEXT": dict(context or {}),
        "AUTHORITY_GRID_FOR_FUTURE_OFFLINE_REPLAY": list(AUTHORITY_GRID),
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    manifest["MANIFEST_PATH"] = str(manifest_path)
    manifest["MANIFEST_SHA256"] = _sha(manifest_path)
    return manifest



def _header_channel_availability(fields: Sequence[str]) -> dict[str, Any]:
    cols = {_norm(k) for k in fields}
    out: dict[str, Any] = {}
    for channel, aliases in CHANNEL_ALIASES.items():
        present = [x for x in aliases if _norm(x) in cols]
        out[channel] = {"PRESENT": present, "AVAILABLE": bool(present)}
    return out


def persist_prelock_csv_snapshot(
    *, source_csv: str | Path, sport: str, mode: str, execution_id: str,
    output_dir: str | Path, candidate_count: int | None = None,
    semantic_surface_sha256: str | None = None, seed_id: str | int | None = None,
    context: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Persist the already-frozen terminal CSV without rebuilding the row graph.

    The source bytes are copied in streaming mode after a bounded-memory validation
    pass.  This function never ranks, scores, prunes, or mutates candidates.  Exact
    replays of an already-persisted execution are idempotent; divergent bytes for the
    same execution id hard-fail the sidecar while remaining non-authoritative upstream.
    """
    src = Path(source_csv)
    if not src.exists():
        raise FileNotFoundError(f"AUTHORITY_PERSISTENCE_SOURCE_MISSING:{src}")

    with src.open("r", encoding="utf-8-sig", newline="") as f:
        rd = csv.DictReader(f)
        fields = list(rd.fieldnames or [])
        if not fields:
            raise ValueError("AUTHORITY_PERSISTENCE_EMPTY_HEADER")
        forbidden = sorted({_norm(k) for k in fields} & FORBIDDEN_PRELOCK_FIELDS)
        if forbidden:
            raise ValueError("AUTHORITY_PERSISTENCE_POSTLOCK_LEAK:" + ",".join(forbidden))
        seen: set[str] = set()
        observed = 0
        for row in rd:
            lid = _lineup_id(row)
            if lid in seen:
                raise ValueError(f"AUTHORITY_PERSISTENCE_DUPLICATE_LINEUP_ID:{lid}")
            seen.add(lid)
            observed += 1

    if observed <= 0:
        raise ValueError("AUTHORITY_PERSISTENCE_EMPTY_SURFACE")
    if candidate_count is not None and int(candidate_count) != observed:
        raise ValueError(
            f"AUTHORITY_PERSISTENCE_COUNT_MISMATCH:DECLARED={int(candidate_count)}:OBSERVED={observed}"
        )

    source_sha = _sha(src)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    stem = f"{str(sport).upper()}_{str(mode).upper()}_{execution_id}_AUTHORITY_PRELOCK"
    csv_path = out / f"{stem}.csv"
    manifest_path = out / f"{stem}_MANIFEST.json"

    if csv_path.exists() or manifest_path.exists():
        if not (csv_path.exists() and manifest_path.exists()):
            raise FileExistsError(f"AUTHORITY_PERSISTENCE_PARTIAL_SNAPSHOT_EXISTS:{stem}")
        prior = json.loads(manifest_path.read_text(encoding="utf-8"))
        if (
            str(prior.get("SOURCE_SURFACE_SHA256")) == source_sha
            and int(prior.get("CANDIDATE_COUNT", -1)) == observed
            and _sha(csv_path) == source_sha
        ):
            prior = dict(prior)
            prior["STATUS"] = "PASS_ALREADY_PERSISTED"
            prior["MANIFEST_PATH"] = str(manifest_path)
            prior["MANIFEST_SHA256"] = _sha(manifest_path)
            return prior
        raise FileExistsError(f"AUTHORITY_PERSISTENCE_IMMUTABLE_SNAPSHOT_CONFLICT:{stem}")

    fd, tmp_name = tempfile.mkstemp(prefix=f".{csv_path.name}.", suffix=".tmp", dir=str(out))
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        with src.open("rb") as rf, tmp.open("wb") as wf:
            shutil.copyfileobj(rf, wf, length=1 << 20)
            wf.flush(); os.fsync(wf.fileno())
        if _sha(tmp) != source_sha:
            raise ValueError("AUTHORITY_PERSISTENCE_STREAM_COPY_HASH_MISMATCH")
        os.replace(tmp, csv_path)
    finally:
        try: tmp.unlink()
        except FileNotFoundError: pass

    manifest = {
        "PATCH_ID": PATCH_ID,
        "STATUS": "PASS",
        "ARTIFACT_ROLE": "IMMUTABLE_PRELOCK_SELECTOR_REPLAY_SURFACE",
        "PERSISTENCE_METHOD": "STREAM_COPY_OF_ALREADY_FROZEN_TERMINAL_CSV",
        "SPORT": str(sport).upper(),
        "MODE": str(mode).upper(),
        "EXECUTION_ID": str(execution_id),
        "SEED_ID": None if seed_id is None else str(seed_id),
        "CANDIDATE_COUNT": observed,
        "CANDIDATE_ORDER_PRESERVED": True,
        "CANDIDATE_PRUNING": 0,
        "SELECTOR_ORDER_MUTATED": False,
        "PRODUCTION_SELECTION_AUTHORITY": False,
        "POSTLOCK_FIELDS_PRESENT": False,
        "SOURCE_SURFACE_CSV": str(src),
        "SOURCE_SURFACE_SHA256": source_sha,
        "SURFACE_CSV": str(csv_path),
        "SURFACE_CSV_SHA256": _sha(csv_path),
        "SEMANTIC_SURFACE_SHA256": str(semantic_surface_sha256 or ""),
        "CHANNEL_AVAILABILITY": _header_channel_availability(fields),
        "COLUMN_COUNT": len(fields),
        "COLUMNS": fields,
        "CONTEXT": dict(context or {}),
        "AUTHORITY_GRID_FOR_FUTURE_OFFLINE_REPLAY": list(AUTHORITY_GRID),
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    manifest["MANIFEST_PATH"] = str(manifest_path)
    manifest["MANIFEST_SHA256"] = _sha(manifest_path)
    return manifest


def seal_durable_prelock_bundle(
    *, candidate_surface: str | Path, candidate_receipt: str | Path,
    prelock_surface: str | Path, prelock_manifest: str | Path,
    final_board: str | Path, controller_state: str | Path,
    output_zip: str | Path, native_artifacts_zip: str | Path | None = None,
) -> dict[str, Any]:
    """Atomically seal the complete MLB Classic calibration evidence package.

    This is durability-only infrastructure. It copies already-frozen artifacts,
    never changes candidate membership/order, scores, selector output, or board
    membership. Exact replays are idempotent; divergent sources for the same
    output path hard-fail the sidecar export while the live board remains
    independently authoritative upstream.
    """
    paths = {
        "CANDIDATE_SURFACE": Path(candidate_surface),
        "CANDIDATE_RECEIPT": Path(candidate_receipt),
        "PRELOCK_SURFACE": Path(prelock_surface),
        "PRELOCK_MANIFEST": Path(prelock_manifest),
        "FINAL_BOARD": Path(final_board),
        "CONTROLLER_STATE": Path(controller_state),
    }
    if native_artifacts_zip is not None:
        paths["NATIVE_ARTIFACTS_ZIP"] = Path(native_artifacts_zip)
    missing = [f"{k}:{v}" for k, v in paths.items() if not v.exists()]
    if missing:
        raise FileNotFoundError("AUTHORITY_DURABLE_EXPORT_SOURCE_MISSING:" + "|".join(missing))

    manifest = json.loads(paths["PRELOCK_MANIFEST"].read_text(encoding="utf-8"))
    if _sha(paths["PRELOCK_SURFACE"]) != str(manifest.get("SURFACE_CSV_SHA256", "")):
        raise ValueError("AUTHORITY_DURABLE_EXPORT_PRELOCK_HASH_MISMATCH")
    if _sha(paths["CANDIDATE_SURFACE"]) != _sha(paths["PRELOCK_SURFACE"]):
        raise ValueError("AUTHORITY_DURABLE_EXPORT_SOURCE_COPY_MISMATCH")

    source_hashes = {k: _sha(v) for k, v in paths.items()}
    out = Path(output_zip)
    out.parent.mkdir(parents=True, exist_ok=True)
    receipt_path = out.with_suffix(out.suffix + ".receipt.json")

    if out.exists() or receipt_path.exists():
        if not (out.exists() and receipt_path.exists()):
            raise FileExistsError(f"AUTHORITY_DURABLE_EXPORT_PARTIAL_EXISTS:{out}")
        prior = json.loads(receipt_path.read_text(encoding="utf-8"))
        if (
            prior.get("SOURCE_HASHES") == source_hashes
            and str(prior.get("BUNDLE_SHA256", "")) == _sha(out)
            and str(prior.get("STATUS", "")).startswith("PASS")
        ):
            prior = dict(prior)
            prior["STATUS"] = "PASS_ALREADY_EXPORTED"
            prior["RECEIPT_PATH"] = str(receipt_path)
            return prior
        raise FileExistsError(f"AUTHORITY_DURABLE_EXPORT_IMMUTABLE_CONFLICT:{out}")

    fd, tmp_name = tempfile.mkstemp(prefix=f".{out.name}.", suffix=".tmp", dir=str(out.parent))
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
            z.write(paths["CANDIDATE_SURFACE"], arcname=f"terminal_surface/{paths['CANDIDATE_SURFACE'].name}")
            z.write(paths["CANDIDATE_RECEIPT"], arcname=f"terminal_surface/{paths['CANDIDATE_RECEIPT'].name}")
            z.write(paths["PRELOCK_SURFACE"], arcname=f"authority_history/{paths['PRELOCK_SURFACE'].name}")
            z.write(paths["PRELOCK_MANIFEST"], arcname=f"authority_history/{paths['PRELOCK_MANIFEST'].name}")
            z.write(paths["FINAL_BOARD"], arcname=f"final_board/{paths['FINAL_BOARD'].name}")
            z.write(paths["CONTROLLER_STATE"], arcname=f"controller_state/{paths['CONTROLLER_STATE'].name}")
            if "NATIVE_ARTIFACTS_ZIP" in paths:
                z.write(paths["NATIVE_ARTIFACTS_ZIP"], arcname=f"native_execution/{paths['NATIVE_ARTIFACTS_ZIP'].name}")
        with zipfile.ZipFile(tmp, "r") as z:
            bad = z.testzip()
            if bad is not None:
                raise ValueError(f"AUTHORITY_DURABLE_EXPORT_ZIP_CRC_FAILURE:{bad}")
            names = set(z.namelist())
            required = {
                f"terminal_surface/{paths['CANDIDATE_SURFACE'].name}",
                f"terminal_surface/{paths['CANDIDATE_RECEIPT'].name}",
                f"authority_history/{paths['PRELOCK_SURFACE'].name}",
                f"authority_history/{paths['PRELOCK_MANIFEST'].name}",
                f"final_board/{paths['FINAL_BOARD'].name}",
                f"controller_state/{paths['CONTROLLER_STATE'].name}",
            }
            if not required.issubset(names):
                raise ValueError("AUTHORITY_DURABLE_EXPORT_ZIP_MEMBER_MISSING")
        os.replace(tmp, out)
    finally:
        try: tmp.unlink()
        except FileNotFoundError: pass

    receipt = {
        "PATCH_ID": "MLB_CLASSIC_AUTHORITY_DURABLE_EXPORT_v1",
        "STATUS": "PASS",
        "ARTIFACT_ROLE": "DURABLE_COMPLETE_PRELOCK_SELECTOR_CALIBRATION_PACKAGE",
        "CANDIDATE_MEMBERSHIP_MUTATION": False,
        "SELECTOR_ORDER_MUTATION": False,
        "PRODUCTION_SELECTION_AUTHORITY": False,
        "POSTLOCK_TRUTH_INCLUDED": False,
        "SOURCE_HASHES": source_hashes,
        "BUNDLE_PATH": str(out),
        "BUNDLE_SHA256": _sha(out),
        "BUNDLE_BYTES": int(out.stat().st_size),
    }
    fd, rtmp_name = tempfile.mkstemp(prefix=f".{receipt_path.name}.", suffix=".tmp", dir=str(out.parent))
    os.close(fd)
    rtmp = Path(rtmp_name)
    try:
        with rtmp.open("w", encoding="utf-8") as f:
            json.dump(receipt, f, indent=2, sort_keys=True)
            f.write("\n")
            f.flush(); os.fsync(f.fileno())
        os.replace(rtmp, receipt_path)
    finally:
        try: rtmp.unlink()
        except FileNotFoundError: pass
    receipt["RECEIPT_PATH"] = str(receipt_path)
    receipt["RECEIPT_SHA256"] = _sha(receipt_path)
    return receipt


def write_postlock_truth_map(
    truth_rows: Sequence[Mapping[str, Any]], *, prelock_manifest: str | Path,
    output_dir: str | Path,
) -> dict[str, Any]:
    """Persist contest truth separately; never overwrite the pre-lock surface."""
    mpath = Path(prelock_manifest)
    manifest = json.loads(mpath.read_text(encoding="utf-8"))
    prelock_path = Path(manifest["SURFACE_CSV"])
    if _sha(prelock_path) != manifest["SURFACE_CSV_SHA256"]:
        raise ValueError("AUTHORITY_PERSISTENCE_PRELOCK_SURFACE_CHANGED_AFTER_FREEZE")

    # Truth must key back to lineup identity.  Missing non-key fields are fine.
    norm_truth: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in truth_rows:
        r = {_norm(k): v for k, v in row.items()}
        lid = str(r.get("LINEUP_ID", "")).strip()
        if not lid:
            raise ValueError("AUTHORITY_TRUTH_MISSING_LINEUP_ID")
        if lid in seen:
            raise ValueError(f"AUTHORITY_TRUTH_DUPLICATE_LINEUP_ID:{lid}")
        seen.add(lid)
        norm_truth.append({k: r.get(k) for k in TRUTH_FIELDS})

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    stem = prelock_path.stem.replace("_AUTHORITY_PRELOCK", "_AUTHORITY_POSTLOCK_TRUTH")
    truth_path = out / f"{stem}.csv"
    receipt_path = out / f"{stem}_RECEIPT.json"
    if truth_path.exists() or receipt_path.exists():
        raise FileExistsError(f"AUTHORITY_TRUTH_IMMUTABLE_ARTIFACT_EXISTS:{stem}")
    with truth_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(TRUTH_FIELDS))
        w.writeheader(); w.writerows(norm_truth)
    receipt = {
        "PATCH_ID": PATCH_ID,
        "STATUS": "PASS",
        "ARTIFACT_ROLE": "POSTLOCK_TRUTH_MAP_SEPARATE_FROM_PRELOCK_SURFACE",
        "PRELOCK_MANIFEST": str(mpath),
        "PRELOCK_SURFACE_SHA256_REVERIFIED": True,
        "TRUTH_ROW_COUNT": len(norm_truth),
        "TRUTH_CSV": str(truth_path),
        "TRUTH_CSV_SHA256": _sha(truth_path),
        "PRELOCK_OVERWRITTEN": False,
    }
    receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True), encoding="utf-8")
    receipt["RECEIPT_PATH"] = str(receipt_path)
    receipt["RECEIPT_SHA256"] = _sha(receipt_path)
    return receipt


def _as_float(x: Any) -> float:
    try:
        v = float(str(x).replace("%", "").replace(",", "").strip())
        return v if math.isfinite(v) else float("nan")
    except Exception:
        return float("nan")


def _load_csv(path: str | Path) -> list[dict[str, Any]]:
    with Path(path).open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def _rank_percentile(values: Sequence[float], *, higher_is_better: bool = True) -> list[float]:
    """Average-rank percentiles in [0,1], dependency-free."""
    n = len(values)
    finite = [(i, float(v)) for i, v in enumerate(values) if math.isfinite(float(v))]
    if not finite:
        return [float("nan")] * n
    ordered = sorted(finite, key=lambda x: x[1])
    ranks = [float("nan")] * n
    pos = 0
    while pos < len(ordered):
        j = pos + 1
        while j < len(ordered) and ordered[j][1] == ordered[pos][1]:
            j += 1
        avg_rank = (pos + 1 + j) / 2.0
        pct = avg_rank / len(ordered)
        for k in range(pos, j):
            ranks[ordered[k][0]] = pct if higher_is_better else 1.0 - pct + 1.0 / len(ordered)
        pos = j
    return ranks


def _top_ids(order: Sequence[int], rows: Sequence[Mapping[str, Any]], n: int) -> list[str]:
    return [_lineup_id(rows[i]) for i in order[:n]]


def _jaccard(a: Sequence[str], b: Sequence[str]) -> float:
    sa, sb = set(a), set(b)
    return len(sa & sb) / max(1, len(sa | sb))


def grade_authority_curve(
    *, prelock_csv: str | Path, truth_csv: str | Path,
    dfs_role_field: str, mc_field: str,
    output_csv: str | Path, board_size: int = DEFAULT_BOARD_SIZE,
    topn_diagnostics: Sequence[int] = (5, 20, 100),
    higher_dfs_is_better: bool = True, higher_mc_is_better: bool = True,
) -> dict[str, Any]:
    """Grade the complete 21-point authority curve.

    Hierarchy encoded in the offline sort only:
      1) winner/perfect board capture
      2) Top-0.1 recall
      3) winner/perfect rank
      4) best board contest rank
      5) portfolio Top-0.1 coverage
      6) cross-seed stability when supplied in the pre-lock surface
      7) neighboring-weight stability

    The *full curve is always emitted*.  The local optimum is diagnostic only.
    """
    pre = _load_csv(prelock_csv)
    truth = _load_csv(truth_csv)
    if not pre:
        raise ValueError("AUTHORITY_CURVE_EMPTY_PRELOCK")
    by_truth = {str(r.get("LINEUP_ID", "")).strip(): r for r in truth}
    ids = [_lineup_id(r) for r in pre]
    if len(ids) != len(set(ids)):
        raise ValueError("AUTHORITY_CURVE_DUPLICATE_PRELOCK_IDS")

    dfs_raw = [_as_float(r.get(dfs_role_field)) for r in pre]
    mc_raw = [_as_float(r.get(mc_field)) for r in pre]

    def normalize_channel(values: Sequence[float], field_name: str, higher: bool) -> list[float]:
        finite = [float(x) for x in values if math.isfinite(float(x))]
        norm_name = _norm(field_name)
        # Preserve an explicitly pre-normalized within-slate authority/percentile
        # channel. Re-ranking an already-normalized composite can distort the
        # intended 5-point blend when the composite itself has non-uniform gaps.
        looks_normalized = (
            finite
            and min(finite) >= -1e-12
            and max(finite) <= 1.0 + 1e-12
            and ("PCTL" in norm_name or "PERCENTILE" in norm_name or "AUTHORITY" in norm_name)
        )
        if looks_normalized:
            if higher:
                return [float(x) if math.isfinite(float(x)) else float("nan") for x in values]
            return [1.0-float(x) if math.isfinite(float(x)) else float("nan") for x in values]
        return _rank_percentile(values, higher_is_better=higher)

    dfs = normalize_channel(dfs_raw, dfs_role_field, higher_dfs_is_better)
    mc = normalize_channel(mc_raw, mc_field, higher_mc_is_better)
    if not any(math.isfinite(x) for x in dfs) or not any(math.isfinite(x) for x in mc):
        raise ValueError("AUTHORITY_CURVE_CHANNEL_FIELD_UNUSABLE")

    # Optional cross-seed stability is evidence, not required.
    stab_aliases = ["CROSS_SEED_STABILITY", "RANK_STABILITY", "CALIBRATION_STABILITY"]
    stab_field = next((k for k in pre[0] if _norm(k) in stab_aliases), None)

    truth_by_id: dict[str, dict[str, Any]] = {}
    for lid in ids:
        t = {_norm(k): v for k, v in by_truth.get(lid, {}).items()}
        truth_by_id[lid] = t

    def bval(v: Any) -> bool:
        return str(v).strip().lower() in {"1", "true", "yes", "y"}

    winner_ids = {lid for lid, t in truth_by_id.items() if bval(t.get("IS_WINNER"))}
    perfect_ids = {lid for lid, t in truth_by_id.items() if bval(t.get("IS_PERFECT"))}
    top01_ids = {lid for lid, t in truth_by_id.items() if bval(t.get("IS_TOP01")) or bval(t.get("IS_TOP_0_1"))}
    top1_ids = {lid for lid, t in truth_by_id.items() if bval(t.get("IS_TOP1")) or bval(t.get("IS_TOP_1"))}

    curve: list[dict[str, Any]] = []
    top_boards: dict[int, list[str]] = {}
    full_orders: dict[int, list[int]] = {}
    for dfs_pct in AUTHORITY_GRID:
        mc_pct = 100 - dfs_pct
        scores = []
        for i in range(len(pre)):
            d = dfs[i] if math.isfinite(dfs[i]) else 0.0
            m = mc[i] if math.isfinite(mc[i]) else 0.0
            scores.append((dfs_pct / 100.0) * d + (mc_pct / 100.0) * m)
        order = sorted(range(len(pre)), key=lambda i: (-scores[i], ids[i]))
        full_orders[dfs_pct] = order
        rank = {ids[i]: j + 1 for j, i in enumerate(order)}
        board = _top_ids(order, pre, board_size)
        top_boards[dfs_pct] = board

        winner_rank = min((rank[x] for x in winner_ids if x in rank), default=None)
        perfect_rank = min((rank[x] for x in perfect_ids if x in rank), default=None)
        winner_capture = any(x in board for x in winner_ids)
        perfect_capture = any(x in board for x in perfect_ids)
        top01_count = len(set(board) & top01_ids)
        top01_recall = top01_count / max(1, len(top01_ids))
        top1_count = len(set(board) & top1_ids)
        board_contest_ranks = [
            _as_float(truth_by_id[x].get("CONTEST_RANK")) for x in board
            if math.isfinite(_as_float(truth_by_id[x].get("CONTEST_RANK")))
        ]
        best_board_rank = min(board_contest_ranks) if board_contest_ranks else None
        avg_board_rank = sum(board_contest_ranks) / len(board_contest_ranks) if board_contest_ranks else None
        seed_vals = [
            _as_float(pre[i].get(stab_field)) for i in order[:board_size]
        ] if stab_field else []
        seed_vals = [x for x in seed_vals if math.isfinite(x)]
        cross_seed = sum(seed_vals) / len(seed_vals) if seed_vals else None

        row = {
            "DFS_ROLE_AUTHORITY": dfs_pct,
            "MC_AUTHORITY": mc_pct,
            "WINNER_CAPTURE_AT_BOARD": winner_capture,
            "PERFECT_CAPTURE_AT_BOARD": perfect_capture,
            "PRIMARY_CAPTURE_COUNT": int(winner_capture) + int(perfect_capture),
            "TOP01_COUNT_AT_BOARD": top01_count,
            "TOP01_RECALL_AT_BOARD": top01_recall,
            "TOP1_COUNT_AT_BOARD": top1_count,
            "WINNER_RANK": winner_rank,
            "PERFECT_RANK": perfect_rank,
            "BEST_BOARD_CONTEST_RANK": best_board_rank,
            "AVG_BOARD_CONTEST_RANK": avg_board_rank,
            "PORTFOLIO_TOP01_COVERAGE": top01_count,
            "CROSS_SEED_STABILITY": cross_seed,
        }
        for n_top in topn_diagnostics:
            chosen = set(_top_ids(order, pre, min(n_top, len(pre))))
            row[f"TOP01_RECALL_AT_{n_top}"] = len(chosen & top01_ids) / max(1, len(top01_ids))
            row[f"TOP1_RECALL_AT_{n_top}"] = len(chosen & top1_ids) / max(1, len(top1_ids))
        curve.append(row)

    # Neighboring-weight stability is computed from the frozen full curve, not
    # used to tune any lineup-specific value.
    by_weight = {r["DFS_ROLE_AUTHORITY"]: r for r in curve}
    for r in curve:
        w = r["DFS_ROLE_AUTHORITY"]
        js = []
        rank_deltas = []
        for nw in (w - 5, w + 5):
            if nw in top_boards:
                js.append(_jaccard(top_boards[w], top_boards[nw]))
                a, b = r.get("WINNER_RANK"), by_weight[nw].get("WINNER_RANK")
                if a is not None and b is not None:
                    rank_deltas.append(abs(a - b))
        r["NEIGHBOR_TOP5_JACCARD"] = sum(js) / len(js) if js else None
        r["NEIGHBOR_WINNER_RANK_DELTA"] = sum(rank_deltas) / len(rank_deltas) if rank_deltas else None

    # Offline diagnostic hierarchy.  Missing ranks are sent to the bottom.
    def sort_key(r: Mapping[str, Any]) -> tuple:
        wr = r["WINNER_RANK"] if r["WINNER_RANK"] is not None else 10**12
        pr = r["PERFECT_RANK"] if r["PERFECT_RANK"] is not None else 10**12
        br = r["BEST_BOARD_CONTEST_RANK"] if r["BEST_BOARD_CONTEST_RANK"] is not None else 10**12
        ar = r["AVG_BOARD_CONTEST_RANK"] if r["AVG_BOARD_CONTEST_RANK"] is not None else 10**12
        cs = r["CROSS_SEED_STABILITY"] if r["CROSS_SEED_STABILITY"] is not None else -1.0
        nj = r["NEIGHBOR_TOP5_JACCARD"] if r["NEIGHBOR_TOP5_JACCARD"] is not None else -1.0
        return (
            -r["PRIMARY_CAPTURE_COUNT"],
            -r["TOP01_RECALL_AT_BOARD"],
            wr + pr,
            br,
            -r["PORTFOLIO_TOP01_COVERAGE"],
            -cs,
            -nj,
            ar,
        )

    diagnostic_order = sorted(curve, key=sort_key)
    best = diagnostic_order[0]

    out = Path(output_csv)
    out.parent.mkdir(parents=True, exist_ok=True)
    fields = list(curve[0].keys())
    with out.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(curve)

    return {
        "PATCH_ID": PATCH_ID,
        "STATUS": "PASS",
        "EVIDENCE_CLASS": "OFFLINE_HISTORICAL_AUTHORITY_CURVE",
        "AUTHORITY_GRID": list(AUTHORITY_GRID),
        "FULL_CURVE_PRESERVED": True,
        "BOARD_SIZE": int(board_size),
        "TOP01_TRUTH_COUNT": len(top01_ids),
        "WINNER_TRUTH_COUNT": len(winner_ids),
        "PERFECT_TRUTH_COUNT": len(perfect_ids),
        "DIAGNOSTIC_LOCAL_OPTIMUM": {
            "DFS_ROLE_AUTHORITY": best["DFS_ROLE_AUTHORITY"],
            "MC_AUTHORITY": best["MC_AUTHORITY"],
        },
        "LOCAL_OPTIMUM_IS_PRODUCTION_COEFFICIENT": False,
        "PROFILE_FREEZE_REQUIRES_MULTI_SLATE_CHRONOLOGICAL_WALKFORWARD": True,
        "CURVE_CSV": str(out),
        "CURVE_CSV_SHA256": _sha(out),
        "GRADING_HIERARCHY": [
            "WINNER_PERFECT_BOARD_CAPTURE",
            "TOP01_RECALL",
            "WINNER_PERFECT_RANK",
            "BEST_BOARD_CONTEST_RANK",
            "PORTFOLIO_TOP01_COVERAGE",
            "CROSS_SEED_STABILITY",
            "NEIGHBORING_WEIGHT_STABILITY",
        ],
    }
