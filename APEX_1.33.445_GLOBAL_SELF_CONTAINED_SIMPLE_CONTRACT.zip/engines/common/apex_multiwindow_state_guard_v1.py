from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping

GUARD_ID = "APEX_GLOBAL_MULTIWINDOW_ISOLATED_STATE_EDIT_AND_ATOMIC_PROMOTION_v1"
GLOBAL_NAMESPACES = ("engines/common/", "engines/global/", "doctrine/APEX_GLOBAL_", "docs/APEX_GLOBAL_", "engine_registry.json", "bundle_manifest.json")
SPORT_ROOTS = {
    "MLB": "engines/mlb/",
    "CFB": "engines/cfb/",
    "NFL": "engines/nfl/",
    "WNBA": "engines/wnba/",
    "TENNIS": "engines/tennis/",
    "PGA": "engines/pga/",
    "MMA": "engines/mma/",
}

class MultiWindowStateError(RuntimeError):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str | Path) -> str:
    p = Path(path)
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_relpath(path: str | Path) -> str:
    rel = str(path).replace("\\", "/").lstrip("./")
    if rel.startswith("../") or rel == ".." or "/../" in f"/{rel}/":
        raise MultiWindowStateError(f"WORKSPACE_PATH_ESCAPE:{path}")
    return rel


def classify_component_scope(relpath: str) -> str:
    rel = canonical_relpath(relpath)
    for sport, root in SPORT_ROOTS.items():
        if rel.startswith(root):
            return sport
    if any(rel == p or rel.startswith(p) for p in GLOBAL_NAMESPACES):
        return "GLOBAL"
    return "SHARED_OTHER"


def snapshot_component_hashes(root: str | Path, components: Iterable[str]) -> dict[str, str | None]:
    base = Path(root)
    out: dict[str, str | None] = {}
    for raw in sorted(set(components)):
        rel = canonical_relpath(raw)
        p = base / rel
        out[rel] = sha256_file(p) if p.exists() and p.is_file() else None
    return out


def build_workspace_manifest(*, workspace_id: str, base_state_version: str,
                             base_bundle_sha256: str, engine_root: str | Path,
                             components: Iterable[str], declared_scope: str | None = None) -> dict:
    touched = snapshot_component_hashes(engine_root, components)
    scopes = sorted({classify_component_scope(p) for p in touched})
    if declared_scope:
        d = str(declared_scope).upper()
        invalid = [s for s in scopes if s not in {d, "GLOBAL", "SHARED_OTHER"}]
        if invalid:
            raise MultiWindowStateError(f"CROSS_SPORT_SCOPE_VIOLATION:{d}:{','.join(invalid)}")
    payload = {
        "WORKSPACE_ID": str(workspace_id),
        "BASE_STATE_VERSION": str(base_state_version),
        "BASE_BUNDLE_SHA256": str(base_bundle_sha256),
        "DECLARED_SCOPE": str(declared_scope or "MIXED").upper(),
        "COMPONENT_BASE_HASHES": touched,
        "COMPONENT_SCOPES": {p: classify_component_scope(p) for p in touched},
        "LATEST_POINTER_WRITE_ALLOWED": False,
        "ACTIVE_BUNDLE_IN_PLACE_EDIT_ALLOWED": False,
    }
    payload["WORKSPACE_MANIFEST_SHA256"] = sha256_bytes(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    )
    return payload


def detect_component_conflicts(workspace_manifest: Mapping, current_root: str | Path) -> dict:
    base_hashes = dict(workspace_manifest.get("COMPONENT_BASE_HASHES") or {})
    current = snapshot_component_hashes(current_root, base_hashes.keys())
    conflicts = []
    for rel, before in base_hashes.items():
        now = current.get(rel)
        if now != before:
            conflicts.append({"component": rel, "base_sha256": before, "current_sha256": now})
    return {
        "GUARD_ID": GUARD_ID,
        "WORKSPACE_ID": workspace_manifest.get("WORKSPACE_ID"),
        "CONFLICT_COUNT": len(conflicts),
        "CONFLICTS": conflicts,
        "MERGE_STATE": "AUTO_MERGE_SAFE" if not conflicts else "MERGE_CONFLICT",
    }


def require_current_base(workspace_manifest: Mapping, *, current_state_version: str,
                         current_bundle_sha256: str) -> dict:
    state_ok = str(workspace_manifest.get("BASE_STATE_VERSION")) == str(current_state_version)
    bundle_ok = str(workspace_manifest.get("BASE_BUNDLE_SHA256")) == str(current_bundle_sha256)
    if not (state_ok and bundle_ok):
        raise MultiWindowStateError(
            "REBASE_REQUIRED:"
            f"BASE={workspace_manifest.get('BASE_STATE_VERSION')}:{workspace_manifest.get('BASE_BUNDLE_SHA256')}:"
            f"CURRENT={current_state_version}:{current_bundle_sha256}"
        )
    return {"BASE_CONCURRENCY_CHECK": "PASS", "CURRENT_STATE_VERSION": str(current_state_version)}


def validate_patch_scope(workspace_manifest: Mapping, changed_components: Iterable[str]) -> dict:
    declared = str(workspace_manifest.get("DECLARED_SCOPE") or "MIXED").upper()
    changed = [canonical_relpath(p) for p in changed_components]
    scopes = {p: classify_component_scope(p) for p in changed}
    if declared not in {"MIXED", "GLOBAL"}:
        bad = [p for p, s in scopes.items() if s not in {declared, "GLOBAL", "SHARED_OTHER"}]
        if bad:
            raise MultiWindowStateError(f"CROSS_SPORT_SCOPE_VIOLATION:{declared}:{','.join(sorted(bad))}")
    return {"PATCH_SCOPE_CHECK": "PASS", "DECLARED_SCOPE": declared, "COMPONENT_SCOPES": scopes}


def atomic_write(path: str | Path, data: bytes, *, expected_sha256: str | None = None) -> dict:
    target = Path(path)
    if target.exists() and expected_sha256 is not None:
        current = sha256_file(target)
        if current != expected_sha256:
            raise MultiWindowStateError(f"ATOMIC_WRITE_STALE_TARGET:{current}:{expected_sha256}")
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{target.name}.", dir=str(target.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, target)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return {"ATOMIC_WRITE": "PASS", "PATH": str(target), "SHA256": sha256_file(target)}


def build_run_snapshot(*, state_version: str, bundle_sha256: str,
                       component_hashes: Mapping[str, str]) -> dict:
    payload = {
        "STATE_VERSION": str(state_version),
        "BUNDLE_SHA256": str(bundle_sha256),
        "COMPONENT_HASHES": dict(sorted(component_hashes.items())),
        "MIDRUN_STATE_SWITCH_ALLOWED": False,
        "MIDRUN_SOURCE_MUTATION_ALLOWED": False,
    }
    payload["RUN_SNAPSHOT_SHA256"] = sha256_bytes(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    )
    return payload


def assert_run_snapshot(root: str | Path, snapshot: Mapping) -> dict:
    expected = dict(snapshot.get("COMPONENT_HASHES") or {})
    actual = snapshot_component_hashes(root, expected.keys())
    drift = [p for p in expected if actual.get(p) != expected[p]]
    if drift:
        raise MultiWindowStateError("RUN_SNAPSHOT_DRIFT:" + ",".join(sorted(drift)))
    return {"RUN_SNAPSHOT_CHECK": "PASS", "RUN_SNAPSHOT_SHA256": snapshot.get("RUN_SNAPSHOT_SHA256")}


def promotion_gate(*, workspace_manifest: Mapping, current_state_version: str,
                   current_bundle_sha256: str, current_root: str | Path,
                   changed_components: Iterable[str]) -> dict:
    require_current_base(
        workspace_manifest,
        current_state_version=current_state_version,
        current_bundle_sha256=current_bundle_sha256,
    )
    scope = validate_patch_scope(workspace_manifest, changed_components)
    conflicts = detect_component_conflicts(workspace_manifest, current_root)
    if conflicts["CONFLICT_COUNT"]:
        raise MultiWindowStateError("MERGE_CONFLICT:" + ",".join(c["component"] for c in conflicts["CONFLICTS"]))
    return {
        "PROMOTION_GATE": "PASS",
        "MERGE_STATE": "AUTO_MERGE_SAFE",
        "DECLARED_SCOPE": scope["DECLARED_SCOPE"],
        "ACTIVE_POINTER_ROTATION_ALLOWED": True,
        "REQUIRED_ROTATION_MODE": "STABLE_POINTER_IN_PLACE_CAS",
        "ACTIVE_POINTER_DELETE_ALLOWED": False,
        "ACTIVE_POINTER_OBJECT_ID_STABLE": True,
    }
