from __future__ import annotations
import json, os
from pathlib import Path
import numpy as np
from engines.common.apex_continuous_cursor_engine_v1 import AppendOnlyLedger, atomic_write_json, sha256_file, PATCH_ID, PROTOCOL_ID

class StateManager:
    """Durable chunk state. The append-only ledger tail, never RAM metadata, is progress authority."""
    def __init__(self, checkpoint_dir: str | os.PathLike, chunk_size: int = 4096):
        self.dir=Path(checkpoint_dir); self.chunk_size=int(chunk_size); self.dir.mkdir(parents=True,exist_ok=True)
        self.ledger=AppendOnlyLedger(self.dir/'execution_ledger.jsonl')
    @property
    def metadata_path(self)->Path: return self.dir/'execution_metadata.json'
    def get_progress_pointer(self)->dict:
        tail=self.ledger.verify()
        if tail is not None:
            rec=tail.record
            return {"last_processed_chunk":tail.chunk_id,"phase3_complete":bool(rec.get("PHASE3_COMPLETE",False)),"emitted_boards":int(rec.get("EMITTED_BOARDS",0)),"last_commit_hash":tail.commit_hash,"PROGRESS_AUTHORITY":"APPEND_ONLY_LEDGER","PROTOCOL_ID":PROTOCOL_ID}
        if self.metadata_path.exists():
            # Legacy metadata is readable only before first ledger commit; it never overrides ledger state.
            try: return json.loads(self.metadata_path.read_text(encoding='utf-8'))
            except Exception: pass
        return {"last_processed_chunk":-1,"phase3_complete":False,"emitted_boards":0,"PROGRESS_AUTHORITY":"APPEND_ONLY_LEDGER","PROTOCOL_ID":PROTOCOL_ID}
    def save_progress_pointer(self, chunk_idx:int, emitted_count:int, *, phase3_done:bool=False, extra:dict|None=None)->None:
        chunk_idx=int(chunk_idx); extra=dict(extra or {})
        checkpoint=extra.pop("CHECKPOINT_PATH",None)
        output_hash=sha256_file(checkpoint) if checkpoint and Path(checkpoint).exists() else str(extra.pop("OUTPUT_HASH","0"*64))
        tail=self.ledger.append_commit({"PATCH_ID":PATCH_ID,"PROTOCOL_ID":PROTOCOL_ID,"PHASE":str(extra.pop("PHASE","PHASE2")),"CHUNK_ID":chunk_idx,"OUTPUT_HASH":output_hash,"PHASE3_COMPLETE":bool(phase3_done),"EMITTED_BOARDS":int(emitted_count),**extra})
        atomic_write_json(self.metadata_path,{"last_processed_chunk":tail.chunk_id,"phase3_complete":bool(phase3_done),"emitted_boards":int(emitted_count),"last_commit_hash":tail.commit_hash,"PROGRESS_AUTHORITY":"APPEND_ONLY_LEDGER","PROTOCOL_ID":PROTOCOL_ID})
    def cache_intermediate_survivors(self, chunk_idx:int, survivors_matrix:np.ndarray)->Path:
        out=self.dir/f"survivors_chunk_{int(chunk_idx)}.npy"; tmp=out.with_suffix('.npy.tmp')
        with tmp.open('wb') as f:
            np.save(f,survivors_matrix,allow_pickle=False); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,out); return out
    def load_cached_survivors(self, chunk_idx:int)->np.ndarray|None:
        p=self.dir/f"survivors_chunk_{int(chunk_idx)}.npy"
        return np.load(p,allow_pickle=False) if p.exists() else None
