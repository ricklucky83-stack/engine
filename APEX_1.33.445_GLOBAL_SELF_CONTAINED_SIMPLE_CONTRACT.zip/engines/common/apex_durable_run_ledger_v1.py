from __future__ import annotations
import csv, fcntl, hashlib, json, os, time
from pathlib import Path
from typing import Any

PATCH_ID = "APEX_GLOBAL_DURABLE_RUN_LEDGER_AND_TERMINAL_COMMIT_PROTOCOL_v1"
SCHEMA_VERSION = "APEX_DURABLE_RUN_LEDGER_V1"

class DurableRunError(RuntimeError):
    pass

def _canonical(obj: Any) -> bytes:
    return (json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str) + "\n").encode("utf-8")

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def atomic_write(path: Path, data: bytes) -> None:
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+f".tmp.{os.getpid()}")
    with tmp.open("wb") as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)
    try:
        dfd=os.open(str(path.parent), os.O_RDONLY)
        try: os.fsync(dfd)
        finally: os.close(dfd)
    except Exception:
        pass

def artifact_meta(path: Path, *, row_count: int|None=None, schema_version: str|None=None) -> dict:
    path=Path(path)
    if not path.exists() or not path.is_file():
        raise DurableRunError(f"ARTIFACT_MISSING:{path}")
    out={"PATH":str(path.resolve()),"SHA256":sha256_file(path),"BYTES":path.stat().st_size}
    if row_count is not None: out["ROW_COUNT"]=int(row_count)
    if schema_version: out["SCHEMA_VERSION"]=str(schema_version)
    return out

def _ledger_dir(root: Path) -> Path:
    return Path(root)/"durable_run_ledger_v1"

def migrate_legacy_identity_if_proven(*, root: Path, requested_run_identity: str, metadata: dict,
                                      expected_legacy_run_identity: str, expected_original_pool_sha256: str,
                                      current_original_pool_sha256: str, expected_checkpoint: str,
                                      expected_legacy_state_version: str = "") -> dict:
    """One-time migration from the legacy mtime-based identity to content-hash identity.

    Fail closed unless the caller proves the exact legacy identity, original-pool
    content hash, state coordinates, and durable checkpoint path. No checkpoint
    bytes or ledger events are modified.
    """
    d=_ledger_dir(root); manifest=d/"run_manifest.json"
    if not manifest.exists():
        return {"STATUS":"NO_LEGACY_MANIFEST"}
    current=json.loads(manifest.read_text(encoding="utf-8"))
    if str(current.get("RUN_IDENTITY") or "")==str(requested_run_identity):
        return {"STATUS":"ALREADY_STABLE"}
    if not expected_legacy_run_identity or str(current.get("RUN_IDENTITY") or "")!=str(expected_legacy_run_identity):
        raise DurableRunError("LEGACY_MIGRATION_IDENTITY_PROOF_FAILED")
    if not expected_original_pool_sha256 or str(current_original_pool_sha256)!=str(expected_original_pool_sha256):
        raise DurableRunError("LEGACY_MIGRATION_POOL_HASH_PROOF_FAILED")
    # STATE_VERSION is expected to change during a cross-version repair. Verify the
    # legacy version against explicit proof, while keeping contest coordinates immutable.
    if expected_legacy_state_version and str(current.get("STATE_VERSION") or "")!=str(expected_legacy_state_version):
        raise DurableRunError("LEGACY_MIGRATION_STATE_VERSION_PROOF_FAILED")
    for k in ("SPORT","MODE","EXECUTION_ID"):
        if str(current.get(k) or "")!=str(metadata.get(k) or ""):
            raise DurableRunError(f"LEGACY_MIGRATION_COORDINATE_MISMATCH:{k}")
    if str(current.get("POOL_SHA256") or "") or str(current.get("ENGINE_SHA256") or ""):
        raise DurableRunError("LEGACY_MIGRATION_NOT_LEGACY_BLANK_HASH_MANIFEST")
    session_path=Path(root)/".session_state.json"
    if not session_path.exists():
        raise DurableRunError("LEGACY_MIGRATION_SESSION_STATE_MISSING")
    session=json.loads(session_path.read_text(encoding="utf-8"))
    checkpoint=str(session.get("ENGINE_OWNED_CHECKPOINT") or "")
    if not expected_checkpoint or checkpoint!=str(expected_checkpoint) or not Path(checkpoint).exists():
        raise DurableRunError("LEGACY_MIGRATION_CHECKPOINT_PROOF_FAILED")
    requested={"PATCH_ID":PATCH_ID,"SCHEMA_VERSION":SCHEMA_VERSION,"RUN_IDENTITY":str(requested_run_identity),**dict(metadata)}
    requested["LEGACY_IDENTITY_MIGRATION"]={
        "STATUS":"PROVEN_ONE_TIME_MIGRATION",
        "PRIOR_RUN_IDENTITY":str(current.get("RUN_IDENTITY") or ""),
        "ORIGINAL_POOL_SHA256":str(current_original_pool_sha256),
        "CHECKPOINT":checkpoint,
    }
    backup=d/"run_manifest.legacy_mtime_identity.json"
    if not backup.exists():
        atomic_write(backup,_canonical(current))
    atomic_write(manifest,_canonical(requested))
    return {"STATUS":"MIGRATED","BACKUP":str(backup),"CHECKPOINT":checkpoint}

def initialize(*, root: Path, run_identity: str, metadata: dict) -> dict:
    d=_ledger_dir(root); d.mkdir(parents=True,exist_ok=True)
    manifest=d/"run_manifest.json"
    requested={"PATCH_ID":PATCH_ID,"SCHEMA_VERSION":SCHEMA_VERSION,"RUN_IDENTITY":str(run_identity),**dict(metadata)}
    if manifest.exists():
        current=json.loads(manifest.read_text(encoding="utf-8"))
        for k in ("RUN_IDENTITY","STATE_TOKEN","POOL_SHA256","ENGINE_SHA256","SPORT","MODE","EXECUTION_ID"):
            if k in requested and k in current and str(requested[k])!=str(current[k]):
                raise DurableRunError(f"RUN_MANIFEST_IDENTITY_MISMATCH:{k}:{current[k]}:{requested[k]}")
    else:
        atomic_write(manifest,_canonical(requested))
    return {"ROOT":str(d),"MANIFEST":str(manifest),"LEDGER":str(d/'events.jsonl')}

def _load_events_unlocked(path: Path) -> list[dict]:
    if not path.exists(): return []
    events=[]; prev=""
    for lineno,line in enumerate(path.read_text(encoding="utf-8").splitlines(),start=1):
        if not line.strip(): continue
        e=json.loads(line)
        stored=str(e.get("EVENT_SHA256") or "")
        raw=dict(e); raw.pop("EVENT_SHA256",None)
        actual=hashlib.sha256(_canonical(raw)).hexdigest()
        if stored!=actual:
            raise DurableRunError(f"LEDGER_EVENT_HASH_MISMATCH:{lineno}")
        if str(e.get("PREV_EVENT_SHA256") or "")!=prev:
            raise DurableRunError(f"LEDGER_CHAIN_MISMATCH:{lineno}")
        prev=stored; events.append(e)
    return events

def load_events(root: Path) -> list[dict]:
    return _load_events_unlocked(_ledger_dir(root)/"events.jsonl")

def commit_event(*, root: Path, event_type: str, event_key: str, payload: dict) -> dict:
    d=_ledger_dir(root); d.mkdir(parents=True,exist_ok=True)
    ledger=d/"events.jsonl"; lock=d/"events.lock"
    with lock.open("a+") as lf:
        fcntl.flock(lf.fileno(),fcntl.LOCK_EX)
        events=_load_events_unlocked(ledger)
        payload_sha=hashlib.sha256(_canonical(payload)).hexdigest()
        for e in events:
            if str(e.get("EVENT_KEY"))==str(event_key):
                if str(e.get("PAYLOAD_SHA256"))!=payload_sha:
                    raise DurableRunError(f"IDEMPOTENCY_KEY_CONFLICT:{event_key}")
                return e
        raw={
            "SEQ":len(events)+1,
            "EVENT_TYPE":str(event_type),
            "EVENT_KEY":str(event_key),
            "CREATED_AT_NS":time.time_ns(),
            "PREV_EVENT_SHA256":str(events[-1].get("EVENT_SHA256") if events else ""),
            "PAYLOAD_SHA256":payload_sha,
            "PAYLOAD":payload,
        }
        raw["EVENT_SHA256"]=hashlib.sha256(_canonical(raw)).hexdigest()
        with ledger.open("ab") as f:
            f.write(_canonical(raw)); f.flush(); os.fsync(f.fileno())
        return raw

def latest_event(root: Path, event_type: str) -> dict|None:
    for e in reversed(load_events(root)):
        if str(e.get("EVENT_TYPE"))==str(event_type): return e
    return None

def canonical_decision_path(output_dir: Path, sport: str, mode: str, execution_id: str) -> Path:
    stem=f"DK_{str(sport).upper()}_{str(mode).upper()}_{execution_id}".replace(" ","_")
    return Path(output_dir)/f"{stem}_AI_TERMINAL_DECISION.json"

def commit_terminal_surface(*, root: Path, surface_path: Path, receipt_path: Path, freeze_sha256: str, candidate_count: int) -> dict:
    sp=artifact_meta(Path(surface_path),row_count=candidate_count,schema_version="APEX_TERMINAL_CANDIDATE_SURFACE_V1")
    rp=artifact_meta(Path(receipt_path),schema_version="APEX_TERMINAL_CANDIDATE_RECEIPT_V1")
    payload={"CANDIDATE_SURFACE":sp,"CANDIDATE_RECEIPT":rp,"CANDIDATE_FREEZE_SHA256":str(freeze_sha256),"CANDIDATE_COUNT":int(candidate_count)}
    return commit_event(root=root,event_type="TERMINAL_SURFACE_COMMITTED",event_key=f"TERMINAL_SURFACE:{freeze_sha256}",payload=payload)

def _selected_ids_from_decision(decision: dict) -> list[str]:
    out=[]
    for x in decision.get("selections") or []:
        if isinstance(x,dict): lid=x.get("lineup_id") or x.get("LINEUP_ID")
        else: lid=x
        if lid is not None: out.append(str(lid))
    return out

def commit_selector_decision(*, root: Path, decision_path: Path, freeze_sha256: str) -> dict:
    p=Path(decision_path)
    decision=json.loads(p.read_text(encoding="utf-8"))
    if str(decision.get("candidate_freeze_sha256") or "")!=str(freeze_sha256):
        raise DurableRunError("SELECTOR_DECISION_FREEZE_MISMATCH")
    selected=_selected_ids_from_decision(decision)
    if not selected: raise DurableRunError("SELECTOR_DECISION_EMPTY")
    payload={"DECISION":artifact_meta(p,schema_version="APEX_TERMINAL_AI_DECISION_V1"),"CANDIDATE_FREEZE_SHA256":str(freeze_sha256),"SELECTED_IDS":selected}
    return commit_event(root=root,event_type="AI_DECISION_COMMITTED",event_key=f"AI_DECISION:{freeze_sha256}",payload=payload)

def commit_board(*, root: Path, board_path: Path, board_payload_sha256: str, final_board_size: int, selected_ids: list[str]) -> dict:
    payload={"BOARD":artifact_meta(Path(board_path),row_count=final_board_size,schema_version="APEX_CORE5_BOARD_V1"),"BOARD_PAYLOAD_SHA256":str(board_payload_sha256),"FINAL_BOARD_SIZE":int(final_board_size),"SELECTED_IDS":[str(x) for x in selected_ids]}
    return commit_event(root=root,event_type="CORE5_BOARD_COMMITTED",event_key=f"CORE5_BOARD:{board_payload_sha256}",payload=payload)

def validate_committed_artifact(meta: dict) -> Path:
    p=Path(str(meta.get("PATH") or ""))
    if not p.exists(): raise DurableRunError(f"COMMITTED_ARTIFACT_MISSING:{p}")
    if sha256_file(p)!=str(meta.get("SHA256") or ""):
        raise DurableRunError(f"COMMITTED_ARTIFACT_HASH_MISMATCH:{p}")
    if int(p.stat().st_size)!=int(meta.get("BYTES",-1)):
        raise DurableRunError(f"COMMITTED_ARTIFACT_SIZE_MISMATCH:{p}")
    return p

def terminal_recovery(root: Path) -> dict:
    surface=latest_event(root,"TERMINAL_SURFACE_COMMITTED")
    decision=latest_event(root,"AI_DECISION_COMMITTED")
    board=latest_event(root,"CORE5_BOARD_COMMITTED")
    out={"SURFACE":surface,"DECISION":decision,"BOARD":board}
    if surface:
        validate_committed_artifact(surface["PAYLOAD"]["CANDIDATE_SURFACE"])
        validate_committed_artifact(surface["PAYLOAD"]["CANDIDATE_RECEIPT"])
    if decision:
        validate_committed_artifact(decision["PAYLOAD"]["DECISION"])
        if surface and str(decision["PAYLOAD"].get("CANDIDATE_FREEZE_SHA256"))!=str(surface["PAYLOAD"].get("CANDIDATE_FREEZE_SHA256")):
            raise DurableRunError("RECOVERY_SURFACE_DECISION_FREEZE_MISMATCH")
    if board:
        validate_committed_artifact(board["PAYLOAD"]["BOARD"])
    return out

def csv_row_count(path: Path) -> int:
    with Path(path).open("r",encoding="utf-8-sig",newline="") as f:
        return sum(1 for _ in csv.DictReader(f))
