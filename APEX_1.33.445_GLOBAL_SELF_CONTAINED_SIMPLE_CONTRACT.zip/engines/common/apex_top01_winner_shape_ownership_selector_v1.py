from __future__ import annotations

"""Pre-lock winner-shape / ownership-shape evidence for terminal DFS selection.

This module does not simulate outcomes and never reads realized contest results.
It identifies whether a lineup has the structural ownership geometry repeatedly
seen in rank-1/perfect lineups: justified chalk plus at least one credible
ceiling-capable differentiator, or an otherwise fragmented ceiling structure.
Low ownership alone receives no positive credit.
"""

from typing import Any, Mapping, Sequence
import json, math

PATCH_ID = "APEX_GLOBAL_TOP01_WINNER_SHAPE_OWNERSHIP_DIFFERENTIATOR_v1"
MC_ROLE = "DIAGNOSTIC_SUPPORT_TIEBREAK_ONLY"
MC_TERMINAL_AUTHORITY = False
FIELD_CONFORMITY_IS_OBJECTIVE = False
TOP01_REQUIRES_CREDIBLE_STRUCTURAL_SEPARATION = True
POSTLOCK_RESULTS_ALLOWED = False
PLAYER_NAME_CONSTANTS = False

SPORT_MODE_POLICY = {
    ("MLB", "SHOWDOWN"): {
        "low_owned_pct": 15.0,
        "deep_low_owned_pct": 8.0,
        "chalk_pct": 30.0,
        "ceiling_gate": 0.80,
        "elite_ceiling_gate": 0.90,
        "dust_ceiling_max": 0.65,
        "min_diff_score": 0.50,
    },
    ("MLB", "CLASSIC"): {
        "low_owned_pct": 12.0,
        "deep_low_owned_pct": 9.0,
        "chalk_pct": 20.0,
        "ceiling_gate": 0.80,
        "elite_ceiling_gate": 0.90,
        "dust_ceiling_max": 0.65,
        "min_diff_score": 0.50,
    },
}


def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")


def _float(x: Any, default: float = float("nan")) -> float:
    try:
        if isinstance(x, str):
            x = x.replace("%", "").replace(",", "").strip()
        v = float(x)
        return v if math.isfinite(v) else default
    except Exception:
        return default


def _truthy(x: Any) -> bool:
    if isinstance(x, bool):
        return x
    return str(x or "").strip().lower() in {"1", "true", "yes", "y", "on"}


def _pct(values: Sequence[float], *, higher: bool = True) -> list[float]:
    vals = [float(v) if math.isfinite(_float(v)) else float("nan") for v in values]
    uniq = sorted(set(v for v in vals if math.isfinite(v)))
    if not uniq:
        return [float("nan")] * len(vals)
    if len(uniq) == 1:
        return [0.5 if math.isfinite(v) else float("nan") for v in vals]
    rank = {v: i / (len(uniq) - 1) for i, v in enumerate(uniq)}
    return [(rank[v] if higher else 1.0 - rank[v]) if math.isfinite(v) else float("nan") for v in vals]


def _lineup_slots(row: Mapping[str, Any]) -> list[tuple[str, str]]:
    cmap = {_norm(k): k for k in row}
    out: list[tuple[str, str]] = []
    # Showdown / captain formats.
    for role in ("CPT", "CAPTAIN", "MVP"):
        k = cmap.get(role)
        if k is not None and row.get(k) not in (None, ""):
            out.append(("CPT", str(row[k]).strip()))
            break
    util_keys = [k for k in row if _norm(k) == "UTIL" or (_norm(k).startswith("UTIL") and _norm(k)[4:].isdigit())]
    for k in sorted(util_keys, key=lambda x: (_norm(x) != "UTIL", _norm(x))):
        if row.get(k) not in (None, ""):
            out.append((_norm(k), str(row[k]).strip()))
    if out:
        return out
    # Classic formats.
    preferred = ("QB","RB1","RB2","WR1","WR2","WR3","TE","FLEX","DST","P1","P2","C","1B","2B","3B","SS","OF1","OF2","OF3","G1","G2","G3","F1","F2","F3","UTIL")
    for role in preferred:
        k = cmap.get(role)
        if k is not None and row.get(k) not in (None, ""):
            out.append((role, str(row[k]).strip()))
    if out:
        return out
    for i in range(1, 13):
        for key in (f"PLAYER{i}", f"P{i}_ID"):
            k = cmap.get(key)
            if k is not None and row.get(k) not in (None, ""):
                out.append((f"PLAYER{i}", str(row[k]).strip()))
                break
    if out:
        return out
    k = cmap.get("PLAYER_IDS") or cmap.get("PLAYERS")
    if k is not None and row.get(k) not in (None, ""):
        text = str(row[k])
        sep = "|" if "|" in text else ";" if ";" in text else ","
        return [(f"PLAYER{i}", x.strip()) for i, x in enumerate(text.split(sep), 1) if x.strip()]
    return []


def _slot_value(row: Mapping[str, Any], slot: str, suffixes: Sequence[str]) -> Any:
    cmap = {_norm(k): k for k in row}
    for suffix in suffixes:
        for key in (f"{slot}_{suffix}", f"{slot}{suffix}"):
            k = cmap.get(_norm(key))
            if k is not None and row.get(k) not in (None, ""):
                return row.get(k)
    return None


def _parse_vector(row: Mapping[str, Any], names: Sequence[str]) -> list[float]:
    cmap = {_norm(k): k for k in row}
    raw = None
    for name in names:
        k = cmap.get(_norm(name))
        if k is not None and row.get(k) not in (None, ""):
            raw = row.get(k)
            break
    if raw is None:
        return []
    if isinstance(raw, (list, tuple)):
        seq = list(raw)
    else:
        text = str(raw).strip()
        try:
            parsed = json.loads(text)
            seq = list(parsed) if isinstance(parsed, list) else [parsed]
        except Exception:
            sep = "|" if "|" in text else ";" if ";" in text else ","
            seq = [x.strip() for x in text.split(sep)]
    return [_float(x) for x in seq]


def _lineup_player_evidence(row: Mapping[str, Any]) -> list[dict[str, Any]]:
    slots = _lineup_slots(row)
    evidence: list[dict[str, Any]] = []
    # Vector fallbacks are useful for generic full-handoff adapters.
    own_vec = _parse_vector(row, ("PLAYER_OWNERSHIP_PCTS", "PLAYER_ROSTER_OWNERSHIP_PCTS"))
    ownp_vec = _parse_vector(row, ("PLAYER_OWNERSHIP_PCTLS", "PLAYER_OWNERSHIP_PERCENTILES"))
    ceil_vec = _parse_vector(row, ("PLAYER_CEILING_PCTLS", "PLAYER_TAIL_PCTLS"))
    unlock_vec = _parse_vector(row, ("PLAYER_SALARY_UNLOCK_FLAGS", "PLAYER_UNLOCK_FLAGS"))
    lev_vec = _parse_vector(row, ("PLAYER_STRATEGIC_LEVERAGE", "PLAYER_LEVERAGE_SCORES"))
    for i, (slot, player) in enumerate(slots):
        own = _float(_slot_value(row, slot, ("ROSTER_OWNERSHIP_PCT", "OWNERSHIP_PCT", "OWN_PCT")))
        if not math.isfinite(own) and i < len(own_vec): own = own_vec[i]
        ownp = _float(_slot_value(row, slot, ("OWNERSHIP_PCTL", "OWNERSHIP_PERCENTILE")))
        if not math.isfinite(ownp) and i < len(ownp_vec): ownp = ownp_vec[i]
        ceiling = _float(_slot_value(row, slot, ("CEILING_PCTL", "TAIL_PCTL", "P99_PCTL")))
        if not math.isfinite(ceiling) and i < len(ceil_vec): ceiling = ceil_vec[i]
        unlock_raw = _slot_value(row, slot, ("SALARY_UNLOCK_FLAG", "SALARY_UNLOCK", "UNLOCK_FLAG"))
        unlock = _truthy(unlock_raw) if unlock_raw is not None else (bool(unlock_vec[i] >= 0.5) if i < len(unlock_vec) and math.isfinite(unlock_vec[i]) else False)
        lev = _float(_slot_value(row, slot, ("STRATEGIC_LEVERAGE", "LEVERAGE_SCORE")))
        if not math.isfinite(lev) and i < len(lev_vec): lev = lev_vec[i]
        evidence.append({"slot": slot, "player": player, "own": own, "ownp": ownp, "ceiling": ceiling, "unlock": unlock, "leverage": lev})
    return evidence


def enrich_winner_shape(rows: Sequence[Mapping[str, Any]], *, sport: str, mode: str) -> list[dict[str, Any]]:
    out = [dict(r) for r in rows]
    key = (_norm(sport), _norm(mode))
    if key not in SPORT_MODE_POLICY:
        return out
    pol = SPORT_MODE_POLICY[key]
    raw_scores: list[float] = []
    for r in out:
        ev = _lineup_player_evidence(r)
        valid = [x for x in ev if math.isfinite(x["own"]) and math.isfinite(x["ceiling"])]
        diff: list[tuple[float, dict[str, Any]]] = []
        dust = 0
        chalk = 0
        justified_chalk = 0
        elite_ceiling = 0
        unlock_ceiling = 0
        for x in valid:
            own = max(0.0, min(100.0, x["own"]))
            ceil = max(0.0, min(1.0, x["ceiling"]))
            is_low = own <= pol["low_owned_pct"] or (math.isfinite(x["ownp"]) and x["ownp"] <= 0.35)
            is_chalk = own >= pol["chalk_pct"] or (math.isfinite(x["ownp"]) and x["ownp"] >= 0.70)
            if ceil >= pol["elite_ceiling_gate"]:
                elite_ceiling += 1
            if x["unlock"] and ceil >= pol["ceiling_gate"]:
                unlock_ceiling += 1
            if is_low and ceil < pol["dust_ceiling_max"]:
                dust += 1
            if is_chalk:
                chalk += 1
                if ceil >= pol["ceiling_gate"]:
                    justified_chalk += 1
            if is_low and ceil >= pol["ceiling_gate"]:
                own_edge = max(0.0, 1.0 - own / 100.0)
                deep_bonus = 1.12 if own <= pol["deep_low_owned_pct"] else 1.0
                unlock_mult = 1.12 if x["unlock"] else 1.0
                lev = x["leverage"] if math.isfinite(x["leverage"]) else 0.0
                lev_mult = 1.0 + 0.08 * max(0.0, min(2.0, lev))
                score = min(1.0, ceil * (own_edge ** 0.65) * deep_bonus * unlock_mult * lev_mult)
                diff.append((score, x))
        diff.sort(key=lambda z: z[0], reverse=True)
        best_diff = diff[0][0] if diff else 0.0
        best = diff[0][1] if diff else None
        ceiling_vals = [max(0.0, min(1.0, x["ceiling"])) for x in valid]
        ceiling_floor = sorted(ceiling_vals, reverse=True)[min(2, len(ceiling_vals)-1)] if ceiling_vals else 0.0
        salary_release = _float(r.get("SALARY_RELEASE_SCORE"), 0.0)
        leftover = _float(r.get("LEFTOVER"), 0.0)
        salary = _float(r.get("SALARY"), float("nan"))
        # The unlock component rewards *productive* relief only; it is bounded by
        # a qualifying ceiling differentiator or an explicit high-ceiling unlock.
        salary_unlock = min(1.0, max(0.0, salary_release) / 10.0) if salary_release > 0 else 0.0
        if key == ("MLB", "CLASSIC") and math.isfinite(leftover):
            salary_unlock = max(salary_unlock, min(1.0, max(0.0, leftover) / 1800.0) * (1.0 if diff else 0.35))
        if unlock_ceiling:
            salary_unlock = max(salary_unlock, min(1.0, 0.55 + 0.15 * unlock_ceiling))
        correlation = _float(r.get("CORRELATION_SCORE"), float("nan"))
        if not math.isfinite(correlation):
            correlation = _float(r.get("AI_LINEUP_CONDITIONAL_SUPPORT_SUM"), float("nan"))
        correlation_component = 0.5 if not math.isfinite(correlation) else max(0.0, min(1.0, correlation if correlation <= 1.0 else correlation / (abs(correlation) + 1.0)))
        dup = _float(r.get("PROJECTED_EXACT_MATCH_DUPLICATION"), float("nan"))
        low_dup = 0.5 if not math.isfinite(dup) else 1.0 / (1.0 + max(0.0, dup))
        # A credible top-0.1 shape is not "be low-owned". It is the coexistence
        # of ceiling, ownership separation, productive salary geometry and a
        # coherent chalk/core spine when the slate supports one.
        has_diff = bool(diff and best_diff >= pol["min_diff_score"])
        fragmented_ceiling = (elite_ceiling >= 2 and chalk <= max(2, len(valid)//2) and dust == 0)
        credible = has_diff or fragmented_ceiling
        if dust and not has_diff and elite_ceiling == 0:
            shape_bucket = "LOW_OWN_DUST"
        elif has_diff and chalk > 0:
            shape_bucket = "CHALK_SPINE_PLUS_CEILING_DIFFERENTIATOR"
        elif has_diff:
            shape_bucket = "CEILING_DIFFERENTIATOR_NO_CHALK_SPINE"
        elif fragmented_ceiling:
            shape_bucket = "FRAGMENTED_OWNERSHIP_CEILING"
        elif justified_chalk > 0:
            shape_bucket = "JUSTIFIED_CHALK_NO_DIFFERENTIATOR"
        else:
            shape_bucket = "FIELD_CONFORMING_OR_UNRESOLVED"
        ownership_shape = max(0.0, min(1.0,
            0.52 * best_diff + 0.18 * min(1.0, len(diff)/2.0) + 0.12 * min(1.0, justified_chalk/3.0)
            + 0.10 * low_dup + 0.08 * (1.0 if fragmented_ceiling else 0.0) - 0.16 * min(1.0, dust/2.0)
        ))
        winner_shape = max(0.0, min(1.0,
            0.38 * best_diff + 0.20 * ceiling_floor + 0.15 * salary_unlock + 0.10 * min(1.0, justified_chalk/3.0)
            + 0.10 * correlation_component + 0.07 * low_dup - 0.12 * min(1.0, dust/2.0)
        ))
        r["AI_WINNER_SHAPE_PATCH_ID"] = PATCH_ID
        r["AI_MC_ROLE"] = MC_ROLE
        r["AI_MC_TERMINAL_AUTHORITY"] = False
        r["AI_FIELD_CONFORMITY_OBJECTIVE"] = False
        r["AI_LOW_OWNED_CEILING_COUNT"] = len(diff)
        r["AI_LOW_OWNED_DUST_COUNT"] = dust
        r["AI_CHALK_SPINE_COUNT"] = chalk
        r["AI_JUSTIFIED_CHALK_COUNT"] = justified_chalk
        r["AI_ELITE_CEILING_PLAYER_COUNT"] = elite_ceiling
        r["AI_VALUE_TO_CEILING_UNLOCK_COUNT"] = unlock_ceiling
        r["AI_PRIMARY_DIFFERENTIATOR_PLAYER"] = best["player"] if best else ""
        r["AI_PRIMARY_DIFFERENTIATOR_SLOT"] = best["slot"] if best else ""
        r["AI_PRIMARY_DIFFERENTIATOR_OWNERSHIP_PCT"] = round(best["own"], 6) if best else ""
        r["AI_PRIMARY_DIFFERENTIATOR_CEILING_PCTL"] = round(best["ceiling"], 8) if best else ""
        r["AI_PRIMARY_DIFFERENTIATOR_SCORE"] = round(best_diff, 12)
        r["AI_VALUE_TO_CEILING_UNLOCK_SCORE"] = round(salary_unlock, 12)
        r["AI_OWNERSHIP_SHAPE_SCORE"] = round(ownership_shape, 12)
        r["AI_WINNER_SHAPE_SCORE"] = round(winner_shape, 12)
        r["AI_WINNER_SHAPE_BUCKET"] = shape_bucket
        r["AI_CREDIBLE_WINNING_DIFFERENTIATOR"] = bool(has_diff)
        r["AI_CREDIBLE_STRUCTURAL_SEPARATION"] = bool(credible)
        r["AI_ALL_CHALK_NO_DIFFERENTIATOR"] = bool(chalk >= max(2, len(valid)//2) and not credible)
        r["AI_PLAYER_SHAPE_EVIDENCE_COUNT"] = len(valid)
        raw_scores.append(winner_shape)
    pctl = _pct(raw_scores)
    for i, r in enumerate(out):
        r["AI_WINNER_SHAPE_PCTL"] = round(pctl[i], 12) if math.isfinite(pctl[i]) else ""
    return out
