from pathlib import Path
import json
import pandas as pd
from apex_data_governor_v1 import assert_forward_clean, GovernanceError, PreFlightEnvironmentFirewall
from engines.common import apex_entry_limit_game_theory_v1 as entry_limit_game
PATCH_ID = "APEX_GLOBAL_POINT_IN_TIME_PREFLIGHT_FIREWALL_v1"
def run_preflight(player_pool, provenance_file, contest_payload):
    df = pd.read_csv(player_pool, nrows=5); assert_forward_clean(df.columns)
    meta = json.loads(Path(provenance_file).read_text()); env = meta.get("CONTEST_PAYLOAD", {}).get("ENVIRONMENT")
    if env != "FORWARD_PRELOCK": raise GovernanceError("ENGINE_INTEGRITY_HALT:FORWARD_ENVIRONMENT_MISMATCH")
    if int(contest_payload.get("FIELD_SIZE") or 0) <= 0: raise GovernanceError("ENGINE_INTEGRITY_HALT:FIELD_SIZE_REQUIRED")
    max_entries = contest_payload.get("MAX_ENTRIES")
    user_entries = contest_payload.get("USER_ENTRIES")
    entry_profile = None
    if max_entries not in (None, ""):
        try:
            entry_profile = entry_limit_game.profile_dict(
                field_size=int(contest_payload["FIELD_SIZE"]), max_entries=int(max_entries), user_entries=user_entries
            )
        except Exception as exc:
            raise GovernanceError(f"ENGINE_INTEGRITY_HALT:ENTRY_LIMIT_CONTEXT_INVALID:{type(exc).__name__}:{exc}") from exc
        embedded = contest_payload.get("ENTRY_LIMIT_PROFILE")
        if embedded and embedded != entry_profile:
            raise GovernanceError("ENGINE_INTEGRITY_HALT:ENTRY_LIMIT_PROFILE_MISMATCH")
    for name, envelope in meta.get("FEATURE_ENVELOPES", {}).items():
        PreFlightEnvironmentFirewall.verify_integrity(name, env)
        if str(envelope.get("source_class", "")).startswith("POST_LOCK"):
            raise GovernanceError("ENGINE_INTEGRITY_HALT:POSTLOCK_FEATURE_PRESENT_IN_FORWARD_MATRIX:" + name)
    return {"STATUS":"PASS","PATCH_ID":PATCH_ID,"FIELD_SIZE":contest_payload["FIELD_SIZE"],"FORWARD_FEATURE_COUNT":len(meta.get("FEATURE_ENVELOPES",{})),"ENTRY_LIMIT_GAME_THEORY_PATCH_ID":entry_limit_game.PATCH_ID,"ENTRY_LIMIT_PROFILE":entry_profile}
