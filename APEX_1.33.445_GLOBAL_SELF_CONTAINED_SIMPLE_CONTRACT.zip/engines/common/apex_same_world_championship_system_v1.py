from __future__ import annotations

"""Sport-agnostic same-world championship-system metrics.

The unit of truth is a shared Monte Carlo world. This module never creates a
lineup and never uses post-lock outcomes. It evaluates already-legal lineups on
frozen common-world score tapes and asks whether the complete roster is jointly
alive when the lineup reaches a championship boundary.

Pairwise correlation is deliberately not used as a substitute for the full
system event. Player thresholds are player-relative quantiles from the same
pre-lock simulation law, so a low-salary role player is judged against their own
outcome distribution rather than against a superstar's raw score.
"""

from dataclasses import dataclass
from typing import Mapping
import hashlib
import numpy as np

PATCH_ID = "APEX_GLOBAL_SAME_WORLD_CHAMPIONSHIP_SYSTEM_v1"
DOCTRINE_ID = PATCH_ID

# Multi-tier system definitions. No single arbitrary cutoff is allowed to carry
# the entire decision. The selector receives recurrence at all three tiers.
TIER_CONFIG = {
    "LOOSE": {"ACTIVE_Q": 0.20, "SPIKE_Q": 0.70, "MIN_SPIKES_FRAC": 0.50},
    "CORE": {"ACTIVE_Q": 0.30, "SPIKE_Q": 0.75, "MIN_SPIKES_FRAC": 0.60},
    "STRICT": {"ACTIVE_Q": 0.40, "SPIKE_Q": 0.80, "MIN_SPIKES_FRAC": 0.70},
}


@dataclass(frozen=True)
class SameWorldEvaluation:
    metrics: Mapping[str, np.ndarray]
    core_top01_bits: np.ndarray
    core_win_bits: np.ndarray
    strict_top01_bits: np.ndarray
    loose_top01_bits: np.ndarray
    receipt: dict


def _validate_bits(name: str, bits: np.ndarray, n: int, worlds: int) -> np.ndarray:
    x=np.asarray(bits)
    expected=(int(worlds)+7)//8
    if x.dtype != np.uint8 or x.ndim != 2 or x.shape != (n, expected):
        raise ValueError(f"{name}_BITS_INVALID:{x.dtype}:{x.shape}:{n}:{expected}")
    return x


def _set_bits(row: np.ndarray, world_idx: np.ndarray) -> None:
    if len(world_idx)==0:
        return
    byte_idx=(world_idx//8).astype(np.int64, copy=False)
    bit_idx=(world_idx%8).astype(np.uint8, copy=False)
    masks=np.left_shift(np.uint8(1), bit_idx)
    np.bitwise_or.at(row, byte_idx, masks)


def _event_worlds(bits_row: np.ndarray, worlds: int) -> np.ndarray:
    return np.flatnonzero(np.unpackbits(bits_row, bitorder='little')[:worlds]).astype(np.int32)


def _quantile_thresholds(scores: np.ndarray) -> dict[float, np.ndarray]:
    qs=sorted({float(v[k]) for v in TIER_CONFIG.values() for k in ("ACTIVE_Q","SPIKE_Q")})
    vals=np.quantile(np.asarray(scores,dtype=np.float32), qs, axis=0)
    return {q: np.asarray(vals[j],dtype=np.float32) for j,q in enumerate(qs)}


def _system_mask(values: np.ndarray, player_ids: np.ndarray, thresholds: dict[float,np.ndarray], tier: str) -> np.ndarray:
    cfg=TIER_CONFIG[tier]
    aq=float(cfg['ACTIVE_Q']); sq=float(cfg['SPIKE_Q'])
    roster=int(values.shape[1])
    min_spikes=max(1, int(np.ceil(float(cfg['MIN_SPIKES_FRAC'])*roster)))
    active=np.all(values >= thresholds[aq][player_ids][None,:], axis=1)
    spikes=np.sum(values >= thresholds[sq][player_ids][None,:], axis=1)
    return active & (spikes >= min_spikes)


def evaluate_championship_worlds(
    player_scores: np.ndarray,
    lineups: np.ndarray,
    *,
    top01_bits: np.ndarray,
    win_bits: np.ndarray,
) -> SameWorldEvaluation:
    """Evaluate repeated all-wheel success only inside actual Top-0.1 worlds.

    This is intentionally sparse. A lineup that never reaches the frozen Top-0.1
    boundary cannot have positive recurring championship-world mass, so it does
    not incur any slot-by-world evaluation cost.
    """
    scores=np.asarray(player_scores,dtype=np.float32)
    lines=np.asarray(lineups,dtype=np.int32)
    if scores.ndim!=2 or lines.ndim!=2 or lines.shape[1]<1:
        raise ValueError('SAME_WORLD_INPUT_SHAPE_INVALID')
    worlds,n_players=scores.shape
    n=len(lines)
    if np.any(lines<0) or np.any(lines>=n_players):
        raise ValueError('SAME_WORLD_LINEUP_PLAYER_INDEX_INVALID')
    top01=_validate_bits('TOP01',top01_bits,n,worlds)
    win=_validate_bits('WIN',win_bits,n,worlds)
    thresholds=_quantile_thresholds(scores)

    strict_count=np.zeros(n,dtype=np.int32)
    core_count=np.zeros(n,dtype=np.int32)
    loose_count=np.zeros(n,dtype=np.int32)
    core_win_count=np.zeros(n,dtype=np.int32)
    half_min=np.zeros(n,dtype=np.float64)
    conversion=np.zeros(n,dtype=np.float64)
    top01_count=np.zeros(n,dtype=np.int32)

    core_bits=np.zeros_like(top01)
    strict_bits=np.zeros_like(top01)
    loose_bits=np.zeros_like(top01)

    active_rows=np.flatnonzero(np.any(top01!=0,axis=1))
    half=worlds//2
    for i in active_rows.tolist():
        w=_event_worlds(top01[i],worlds)
        if len(w)==0:
            continue
        top01_count[i]=len(w)
        ids=lines[i]
        vals=scores[w[:,None],ids[None,:]]
        loose=_system_mask(vals,ids,thresholds,'LOOSE')
        core=_system_mask(vals,ids,thresholds,'CORE')
        strict=_system_mask(vals,ids,thresholds,'STRICT')
        lw=w[loose]; cw=w[core]; sw=w[strict]
        loose_count[i]=len(lw); core_count[i]=len(cw); strict_count[i]=len(sw)
        _set_bits(loose_bits[i],lw); _set_bits(core_bits[i],cw); _set_bits(strict_bits[i],sw)
        if len(cw):
            a=int(np.count_nonzero(cw < half)) if half>0 else 0
            b=int(len(cw)-a)
            ar=a/max(1,half); br=b/max(1,worlds-half)
            half_min[i]=min(ar,br)
        conversion[i]=len(cw)/max(1,len(w))

    core_win_bits=np.bitwise_and(core_bits,win)
    if len(active_rows):
        core_win_count[active_rows]=np.unpackbits(core_win_bits[active_rows],axis=1,bitorder='little')[:,:worlds].sum(axis=1).astype(np.int32)

    denom=float(max(1,worlds))
    metrics={
        'same_world_strict_mass': strict_count.astype(np.float64)/denom,
        'same_world_core_mass': core_count.astype(np.float64)/denom,
        'same_world_loose_mass': loose_count.astype(np.float64)/denom,
        'same_world_win_mass': core_win_count.astype(np.float64)/denom,
        'same_world_core_half_min': half_min,
        'same_world_top01_conversion': conversion,
        'same_world_strict_events': strict_count.astype(np.float64),
        'same_world_core_events': core_count.astype(np.float64),
        'same_world_loose_events': loose_count.astype(np.float64),
        'same_world_top01_events': top01_count.astype(np.float64),
    }
    receipt={
        'PATCH_ID':PATCH_ID,
        'DOCTRINE_ID':DOCTRINE_ID,
        'WORLD_UNIT':'SHARED_CAUSAL_MONTE_CARLO_TRIAL',
        'COMMON_WORLDS':int(worlds),
        'LINEUPS_REVIEWED':int(n),
        'TOP01_EVENT_LINEUPS_EVALUATED':int(len(active_rows)),
        'TIER_CONFIG':TIER_CONFIG,
        'PRIMARY_EVENT':'RECURRING_FULL_WHEEL_TOP01_COMMON_WORLD_MASS',
        'PAIRWISE_CORRELATION_AS_SYSTEM_PROXY':False,
        'POSTLOCK_RESULTS_USED':False,
        'PLAYER_NAMES_USED':False,
        'FULL_UNIVERSE_PRUNED':False,
        'CORE_EVENT_LINEUPS':int(np.count_nonzero(core_count)),
        'STRICT_EVENT_LINEUPS':int(np.count_nonzero(strict_count)),
        'CORE_EVENT_TOTAL':int(core_count.sum()),
        'STRICT_EVENT_TOTAL':int(strict_count.sum()),
    }
    receipt['METRIC_SCHEMA_SHA256']=hashlib.sha256('|'.join(sorted(metrics)).encode()).hexdigest()
    return SameWorldEvaluation(metrics,core_bits,core_win_bits,strict_bits,loose_bits,receipt)
