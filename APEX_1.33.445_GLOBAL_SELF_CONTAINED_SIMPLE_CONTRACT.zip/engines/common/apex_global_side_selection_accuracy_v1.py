from __future__ import annotations

"""Global prelock side-selection accuracy and spread-calibration ledger.

This module measures whether APEX's prelock side preference agrees with the eventual
winning/covering side.  It is intentionally measurement-first: postlock grades never
flow into the same slate and cannot alter live selection.  Future market authority may
only be adjusted from a frozen, prospective calibration summary that clears the
minimum-sample and reliability gates below.
"""

from collections import defaultdict
import math
from typing import Any, Iterable, Mapping, Sequence

PATCH_ID = "APEX_GLOBAL_SIDE_SELECTION_ACCURACY_AND_SPREAD_CALIBRATION_v1"
DOCTRINE_ID = PATCH_ID
CONTRACT_VERSION = "1.0"
TEAM_SPORTS = {"NFL", "CFB", "CBB", "NBA", "WNBA", "NHL", "MLB"}
MIN_GRADED_GAMES_FOR_FORWARD_AUTHORITY = 20
MIN_BUCKET_GRADED_GAMES_FOR_FORWARD_AUTHORITY = 12
MAX_MARKET_AUTHORITY_MULTIPLIER = 1.20
MIN_MARKET_AUTHORITY_MULTIPLIER = 0.80


def _num(value: Any, default: float = math.nan) -> float:
    try:
        if value is None:
            return default
        if isinstance(value, str):
            value = value.replace("%", "").replace(",", "").strip()
            if value.lower() in {"", "-", "nan", "none", "null"}:
                return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


def spread_bucket(spread: Any) -> str:
    """Bucket by absolute prelock point spread."""
    s = abs(_num(spread))
    if not math.isfinite(s):
        return "SPREAD_UNKNOWN"
    if s <= 3.0:
        return "PICKEM_0_3"
    if s <= 7.0:
        return "SMALL_3P5_7"
    if s <= 14.0:
        return "MEDIUM_7P5_14"
    if s <= 21.0:
        return "LARGE_14P5_21"
    return "EXTREME_21P5_PLUS"


def market_favorite(teams: Sequence[str], spread_team0: Any) -> str | None:
    if len(teams) != 2:
        raise ValueError("exactly two teams required")
    s = _num(spread_team0)
    if not math.isfinite(s) or abs(s) < 1e-12:
        return None
    # Team0 line: negative means team0 is favored.
    return str(teams[0] if s < 0 else teams[1])


def model_favored_team(teams: Sequence[str], win_probabilities: Mapping[str, Any]) -> str | None:
    if len(teams) != 2:
        raise ValueError("exactly two teams required")
    vals = [(str(t), _num(win_probabilities.get(str(t)))) for t in teams]
    vals = [(t, p) for t, p in vals if math.isfinite(p)]
    if len(vals) != 2 or abs(vals[0][1] - vals[1][1]) < 1e-12:
        return None
    return max(vals, key=lambda x: x[1])[0]


def prelock_game_side_receipt(
    *,
    sport: str,
    mode: str,
    teams: Sequence[str],
    spread_team0: Any,
    win_probabilities: Mapping[str, Any],
    selected_team: str | None = None,
    selected_share: float | None = None,
) -> dict[str, Any]:
    """Freeze the prelock side signal before outcomes are known.

    selected_team may represent the lineup/portfolio side that APEX actually
    overweighted.  When omitted, the model-favored side is used as the measurable
    prelock side preference.
    """
    s = str(sport).upper().strip()
    m = str(mode).upper().strip()
    if s not in TEAM_SPORTS:
        raise ValueError(f"unsupported team sport:{s}")
    if len(teams) != 2:
        raise ValueError("exactly two teams required")
    t0, t1 = str(teams[0]), str(teams[1])
    favorite = market_favorite((t0, t1), spread_team0)
    model_side = model_favored_team((t0, t1), win_probabilities)
    chosen = str(selected_team) if selected_team is not None else model_side
    if chosen is not None and chosen not in {t0, t1}:
        raise ValueError(f"selected team outside game:{chosen}")
    share = _num(selected_share)
    return {
        "PATCH_ID": PATCH_ID,
        "CONTRACT_VERSION": CONTRACT_VERSION,
        "SPORT": s,
        "MODE": m,
        "TEAMS": [t0, t1],
        "SPREAD_TEAM0": None if not math.isfinite(_num(spread_team0)) else float(_num(spread_team0)),
        "SPREAD_BUCKET": spread_bucket(spread_team0),
        "MARKET_FAVORITE": favorite,
        "MODEL_FAVORED_TEAM": model_side,
        "SELECTED_SIDE": chosen,
        "SELECTED_SIDE_SHARE": None if not math.isfinite(share) else float(share),
        "MODEL_WIN_PROBABILITIES": {t0: float(_num(win_probabilities.get(t0), 0.5)), t1: float(_num(win_probabilities.get(t1), 0.5))},
        "MARKET_FAVORITE_ALIGNMENT": None if favorite is None or chosen is None else bool(chosen == favorite),
        "PRELOCK_FROZEN": True,
        "POSTLOCK_RESULTS_USED": False,
        "FORWARD_AUTHORITY": "MEASUREMENT_ONLY_UNTIL_CALIBRATION_GATE",
    }


def grade_prelock_game_side(
    receipt: Mapping[str, Any],
    *,
    final_scores: Mapping[str, Any],
    downstream_metrics: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Postlock grade of a frozen prelock side receipt."""
    teams = [str(x) for x in receipt.get("TEAMS", [])]
    if len(teams) != 2:
        raise ValueError("receipt must contain exactly two teams")
    t0, t1 = teams
    s0, s1 = _num(final_scores.get(t0)), _num(final_scores.get(t1))
    if not (math.isfinite(s0) and math.isfinite(s1)):
        raise ValueError("finite final scores required")
    winner = None if abs(s0 - s1) < 1e-12 else (t0 if s0 > s1 else t1)
    spread0 = _num(receipt.get("SPREAD_TEAM0"))
    cover_team = None
    push = False
    if math.isfinite(spread0):
        ats0 = s0 + spread0 - s1
        if abs(ats0) < 1e-12:
            push = True
        else:
            cover_team = t0 if ats0 > 0 else t1
    favorite = receipt.get("MARKET_FAVORITE")
    selected = receipt.get("SELECTED_SIDE")
    downstream = dict(downstream_metrics or {})
    return {
        **dict(receipt),
        "FINAL_SCORES": {t0: float(s0), t1: float(s1)},
        "OUTRIGHT_WINNER": winner,
        "ATS_COVER_TEAM": cover_team,
        "ATS_PUSH": push,
        "MARKET_FAVORITE_WON": None if favorite is None or winner is None else bool(favorite == winner),
        "MARKET_FAVORITE_COVERED": None if favorite is None or cover_team is None else bool(favorite == cover_team),
        "SELECTED_SIDE_WON": None if selected is None or winner is None else bool(selected == winner),
        "SELECTED_SIDE_COVERED": None if selected is None or cover_team is None else bool(selected == cover_team),
        "POSTLOCK_GRADED": True,
        "POSTLOCK_RESULTS_USED_FOR_SAME_SLATE": False,
        "TOP_0_1_HIT": downstream.get("TOP_0_1_HIT"),
        "WINNER_OR_PERFECT_CAPTURE": downstream.get("WINNER_OR_PERFECT_CAPTURE"),
        "TERMINAL_RANK": downstream.get("TERMINAL_RANK"),
        "DOWNSTREAM_METRICS_GRADING_ONLY": True,
    }


def _rate(values: Iterable[Any]) -> tuple[int, float | None]:
    xs = [bool(v) for v in values if v is not None]
    return len(xs), (sum(xs) / len(xs) if xs else None)


def _beta_shrunk(rate: float | None, n: int, prior_mean: float = 0.5, prior_strength: float = 12.0) -> float | None:
    if rate is None or n <= 0:
        return None
    return (rate * n + prior_mean * prior_strength) / (n + prior_strength)


def aggregate_calibration(grades: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """Aggregate historical/prospective postlock grades by sport/mode/spread bucket."""
    rows = [dict(r) for r in grades if bool(r.get("POSTLOCK_GRADED"))]
    groups: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for r in rows:
        groups[(str(r.get("SPORT", "")).upper(), str(r.get("MODE", "")).upper(), str(r.get("SPREAD_BUCKET", "SPREAD_UNKNOWN")))].append(r)

    def summarize(rs: list[dict[str, Any]]) -> dict[str, Any]:
        n_sel_win, sel_win = _rate(r.get("SELECTED_SIDE_WON") for r in rs)
        n_sel_cover, sel_cover = _rate(r.get("SELECTED_SIDE_COVERED") for r in rs)
        n_fav_win, fav_win = _rate(r.get("MARKET_FAVORITE_WON") for r in rs)
        n_fav_cover, fav_cover = _rate(r.get("MARKET_FAVORITE_COVERED") for r in rs)
        align_n, align = _rate(r.get("MARKET_FAVORITE_ALIGNMENT") for r in rs)
        n_top01, top01 = _rate(r.get("TOP_0_1_HIT") for r in rs)
        n_capture, capture = _rate(r.get("WINNER_OR_PERFECT_CAPTURE") for r in rs)
        ranks = [_num(r.get("TERMINAL_RANK")) for r in rs]
        ranks = [x for x in ranks if math.isfinite(x) and x > 0]
        return {
            "N_GRADED": len(rs),
            "N_SELECTED_OUTRIGHT": n_sel_win,
            "SELECTED_SIDE_OUTRIGHT_ACCURACY": sel_win,
            "SELECTED_SIDE_OUTRIGHT_ACCURACY_SHRUNK": _beta_shrunk(sel_win, n_sel_win),
            "N_SELECTED_ATS": n_sel_cover,
            "SELECTED_SIDE_COVER_ACCURACY": sel_cover,
            "SELECTED_SIDE_COVER_ACCURACY_SHRUNK": _beta_shrunk(sel_cover, n_sel_cover),
            "MARKET_FAVORITE_WIN_RATE": fav_win,
            "MARKET_FAVORITE_COVER_RATE": fav_cover,
            "N_MARKET_FAVORITE_WIN": n_fav_win,
            "N_MARKET_FAVORITE_ATS": n_fav_cover,
            "MARKET_FAVORITE_ALIGNMENT_RATE": align,
            "N_ALIGNMENT": align_n,
            "N_TOP_0_1_GRADED": n_top01,
            "TOP_0_1_HIT_RATE": top01,
            "N_WINNER_OR_PERFECT_GRADED": n_capture,
            "WINNER_OR_PERFECT_CAPTURE_RATE": capture,
            "MEDIAN_TERMINAL_RANK": (sorted(ranks)[len(ranks)//2] if ranks else None),
        }

    overall = summarize(rows)
    by_bucket = {}
    for (sport, mode, bucket), rs in sorted(groups.items()):
        b = summarize(rs)
        b["BUCKET_FORWARD_AUTHORITY_ELIGIBLE"] = bool(
            b["N_SELECTED_OUTRIGHT"] >= MIN_BUCKET_GRADED_GAMES_FOR_FORWARD_AUTHORITY
            and b["SELECTED_SIDE_OUTRIGHT_ACCURACY_SHRUNK"] is not None
        )
        by_bucket[f"{sport}|{mode}|{bucket}"] = b
    overall["FORWARD_AUTHORITY_ELIGIBLE"] = bool(
        overall["N_SELECTED_OUTRIGHT"] >= MIN_GRADED_GAMES_FOR_FORWARD_AUTHORITY
        and overall["SELECTED_SIDE_OUTRIGHT_ACCURACY_SHRUNK"] is not None
    )
    return {
        "PATCH_ID": PATCH_ID,
        "CONTRACT_VERSION": CONTRACT_VERSION,
        "STATUS": "CALIBRATED" if rows else "NO_GRADED_GAMES",
        "OVERALL": overall,
        "BY_SPORT_MODE_SPREAD_BUCKET": by_bucket,
        "MIN_GRADED_GAMES_FOR_FORWARD_AUTHORITY": MIN_GRADED_GAMES_FOR_FORWARD_AUTHORITY,
        "MIN_BUCKET_GRADED_GAMES_FOR_FORWARD_AUTHORITY": MIN_BUCKET_GRADED_GAMES_FOR_FORWARD_AUTHORITY,
        "POSTLOCK_RESULTS_USED_FOR_SAME_SLATE": False,
    }


def calibrated_market_authority_multiplier(summary: Mapping[str, Any]) -> float:
    """Bounded future-slate multiplier after the calibration gate clears.

    1.0 means no change.  The function deliberately uses shrunk accuracy and cannot
    produce authority outside [0.80, 1.20].
    """
    overall = dict(summary.get("OVERALL") or {})
    if not bool(overall.get("FORWARD_AUTHORITY_ELIGIBLE")):
        return 1.0
    acc = _num(overall.get("SELECTED_SIDE_OUTRIGHT_ACCURACY_SHRUNK"), 0.5)
    cover = _num(overall.get("SELECTED_SIDE_COVER_ACCURACY_SHRUNK"), 0.5)
    signal = 0.70 * (acc - 0.5) + 0.30 * (cover - 0.5)
    return float(max(MIN_MARKET_AUTHORITY_MULTIPLIER, min(MAX_MARKET_AUTHORITY_MULTIPLIER, 1.0 + signal)))


def contract_receipt(*, sport: str, mode: str) -> dict[str, Any]:
    s = str(sport).upper().strip()
    return {
        "PATCH_ID": PATCH_ID,
        "CONTRACT_VERSION": CONTRACT_VERSION,
        "SPORT": s,
        "MODE": str(mode).upper().strip(),
        "APPLIES": s in TEAM_SPORTS,
        "TRACK_OUTRIGHT_WIN_ACCURACY": s in TEAM_SPORTS,
        "TRACK_ATS_COVER_ACCURACY": s in TEAM_SPORTS,
        "TRACK_MARKET_FAVORITE_ALIGNMENT": s in TEAM_SPORTS,
        "TRACK_BY_SPREAD_BUCKET": s in TEAM_SPORTS,
        "SAME_SLATE_POSTLOCK_LEAKAGE_ALLOWED": False,
        "UNVALIDATED_SPREAD_AUTHORITY_BOOST_ALLOWED": False,
        "FORWARD_AUTHORITY_GATE": MIN_GRADED_GAMES_FOR_FORWARD_AUTHORITY,
    }


__all__ = [
    "PATCH_ID", "DOCTRINE_ID", "TEAM_SPORTS", "spread_bucket", "market_favorite",
    "model_favored_team", "prelock_game_side_receipt", "grade_prelock_game_side",
    "aggregate_calibration", "calibrated_market_authority_multiplier", "contract_receipt",
]
