from __future__ import annotations

"""Terminal-only AI Hybrid selection boundary.

The engine owns candidate birth, legality, calibration, simulation, ownership,
field construction, handoff and metric computation.  AI authority begins only
after the complete calibration-qualified/selector-reviewed candidate matrix is handed off.
No Top-N sieve, cohort reduction, Pareto pruning, or selector pruning is allowed.
The AI may select
existing lineup IDs and attach bounded reason codes.  It cannot create lineups,
change metrics, recompute simulations, or use post-lock outcomes.
"""

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
import csv, json, math

PATCH_ID = "APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v4"
SELECTOR_MODE = "CODE_AI_HYBRID_TERMINAL_ONLY_FULL_HANDOFF_SPORT_MODE_INTELLIGENCE"
TOP5_POLICY_ID = "APEX_GLOBAL_TOP5_HIGH_CONFIDENCE_PARLAY_v1"
BOARD_SIZE = 5

FORBIDDEN_POSTLOCK_FIELDS = frozenset({
    "CONTEST_RANK","ACTUAL_FPTS","REALIZED_FPTS","POSTLOCK_SCORE","REALIZED_SCORE",
    "ACTUAL_SCORE","ACTUAL_RANK","FINAL_CONTEST_RANK","WINNING_LINEUP","TARGET_ACTUAL_SCORE",
})

ALLOWED_REASON_CODES = frozenset({
    # Existing authority vocabulary
    "ELITE_WIN_PATH","ELITE_TOP_0_1_PATH","ELITE_TOP_1_PATH","P99_TAIL","CVAR99_TAIL","P95_TAIL",
    "CORRELATION_PATH","LEVERAGE_PATH","LOW_DUPLICATION_PATH","SALARY_GEOMETRY_PATH",
    "STRUCTURE_DIVERSIFICATION","PORTFOLIO_MARGINAL_VALUE",
    # v2 terminal intelligence vocabulary
    "CHAMPIONSHIP_UNION_COVERAGE","TOP01_UNION_COVERAGE","TOP1_UNION_COVERAGE",
    "UNCERTAINTY_STABILITY","CROSS_SEED_STABILITY","REGIME_COVERAGE","COUNTER_SCRIPT_COVERAGE",
    "FIELD_MODEL_RELIABILITY","CURRENT_SELECTOR_SUPPORT","CURRENT_SELECTOR_DISAGREEMENT",
    "TAIL_ASYMMETRY","PARETO_FRONTIER","DUPLICATION_ADJUSTED_UPSIDE","FAMILY_CHAMPIONSHIP_MASS",
    "SIBLING_RECALL","DOMINANT_FAMILY_EVIDENCE",
    # v4 relationship / conditional-mutation intelligence vocabulary
    "RECIPROCAL_ROLE_SIBLING","RECIPROCAL_CPT_SIBLING","PROBABILITY_EQUIVALENT",
    "ONE_PLAYER_MUTATION","TWO_PLAYER_MUTATION","CONDITIONAL_CORE_FIT",
    "SCRIPT_COMPLETION","CPT_SIDE_SCRIPT_COMPLETION","TAIL_MAGNITUDE_GAIN",
    "LOCAL_CHAMPIONSHIP_DENSITY","SUBFAMILY_CHAMPIONSHIP_MASS",
    "MARKET_TAIL_DISAGREEMENT","DECK_DEPTH_PROTECTED","DOMINANT_FAMILY_SUPPORT",
})

FEATURE_REGISTRY = {
    "PRIMARY_TAIL": ["MC_WIN_RATE","MC_WIN_LCB","MC_TOP_0_1_RATE","MC_TOP_0_1_LCB","MC_TOP_1_RATE","MC_TOP_1_LCB"],
    "TAIL_SHAPE": ["MC_P95","MC_P99","MC_CVAR99","TAIL_ASYMMETRY","MC_MEAN"],
    "UNCERTAINTY": ["MC_TRIALS","RANK_STABILITY","CROSS_SEED_STABILITY","CALIBRATION_STABILITY"],
    "FIELD_RELATIVE": ["PROJECTED_EXACT_MATCH_DUPLICATION","P_UNIQUE","OWNERSHIP_PRODUCT","FIELD_MODEL_RELIABILITY"],
    "FAMILY": ["FAMILY_MC_WIN_RATE","FAMILY_MC_TOP_0_1_RATE","FAMILY_MC_TOP1_RATE","FAMILY_CHAMPIONSHIP_MASS","WINNING_SIBLING_COUNT"],
    "PORTFOLIO": ["COMMON_WORLD_WIN_BITS","COMMON_WORLD_TOP01_BITS","COMMON_WORLD_TOP1_BITS","PAIRWISE_OUTCOME_CORRELATION","LINEUP_OVERLAP"],
    "STRUCTURE": ["BRANCH","ROUTE","CPT_ROLE","SP_COUNT","RP_COUNT","SALARY","SALARY_GEOMETRY","SCENARIO_ID"],
    "CODE_COMPARATOR": ["CURRENT_SELECTOR_SELECTED","CURRENT_SELECTOR_RANK","CURRENT_SELECTOR_SCORE","GLOBAL_CORE_PROTECTED","GLOBAL_CORE_PRIORITY"],
    "MODEL_GOVERNANCE": ["FIELD_MODEL_SOURCE","FIELD_MODEL_RELIABILITY","OWNERSHIP_AUTHORITY","MARKET_MODEL_DIVERGENCE"],
    "RELATIONSHIPS": ["AI_EXACT_PLAYERSET_FAMILY_ID","AI_EXACT_PLAYERSET_SIBLING_COUNT","AI_RECIPROCAL_ROLE_SIBLING_COUNT","AI_D1_NEIGHBOR_COUNT","AI_D1_TOP01_DENSITY","AI_D2_RELATIONSHIP_MODE"],
    "PROBABILITY_EQUIVALENCE": ["AI_TOP01_95_HALF_WIDTH","AI_WIN_95_HALF_WIDTH"],
    "SPORT_MODE_INTELLIGENCE": ["AI_INTELLIGENCE_PROFILE_ID","AI_TEAM_COUNT","AI_DOMINANT_TEAM_COUNT","AI_ROLE_SIDE_COUNT","AI_BATTING_ADJACENCY_PAIRS","AI_MARKET_TAIL_SUPPORT_PCTL","AI_MARKET_TAIL_VS_MC_DISAGREEMENT"],
}

class TerminalAIHybridError(RuntimeError):
    pass


def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")

MODE_ALIASES = {
    "SD": "SHOWDOWN", "SHOWDOWN_CAPT": "SHOWDOWN_CAPTAIN", "SHOWDOWN_CPT": "SHOWDOWN_CAPTAIN",
    "CAPTAIN": "SHOWDOWN_CAPTAIN", "CPT": "SHOWDOWN_CAPTAIN",
    "SHOWDOWN_FLAT6": "SHOWDOWN_FLAT_6", "SHOWDOWN_FLAT_6": "SHOWDOWN_FLAT_6", "FLAT_6": "SHOWDOWN_FLAT_6",
    "SS_HRS": "SS_HRS", "SS_HR": "SS_HRS", "HRS": "SS_HRS", "HR_SPECIAL": "SS_HRS",
}
SPORT_ALIASES = {"GOLF": "PGA", "UFC": "MMA"}

# Exact sport x contest-type intelligence contracts.  These profiles only govern
# terminal evidence interpretation; they never birth, prune, legalize, or simulate lineups.
_PROFILE_ROWS = {
    ("MLB","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=2, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="TEAM_STACK_BATTING_ORDER", market_fields=("TT_LEVERAGE_SCORE","LINEUP_MARKET_TT","STRATEGY_SCORE")),
    ("MLB","CLASSIC"): dict(roster_size=10, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="STACK_GEOMETRY_TEAM_CORE", script_axis="TEAM_STACK_PITCHER_HITTER_COVARIANCE", market_fields=("LINEUP_MARKET_TT","STACK_MARKET_TOTAL","STRATEGY_SCORE")),
    ("MLB","SS_HRS"): dict(roster_size=None, role_sensitive=False, role_slot=None, mutation_depth=1, family_basis="CORRELATED_HR_EVENT_CORE", script_axis="HR_CORRELATION_GAME_ENVIRONMENT", market_fields=("HR_MARKET_SUPPORT","LINEUP_MARKET_TT","STRATEGY_SCORE")),
    ("WNBA","CLASSIC"): dict(roster_size=8, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="GAME_ROLE_MINUTES_CORE", script_axis="MINUTES_USAGE_GAME_CORRELATION", market_fields=("STRATEGY_SCORE","ROLE_CREDIBILITY","MINUTES_STABILITY")),
    ("WNBA","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=2, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="TEAM_ROLE_GAME_SCRIPT", market_fields=("STRATEGY_SCORE","ROLE_CREDIBILITY","MINUTES_STABILITY")),
    ("NFL","CLASSIC"): dict(roster_size=9, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="STACK_BRINGBACK_ROLE_CORE", script_axis="PASS_RUSH_GAME_SCRIPT", market_fields=("STRATEGY_SCORE","ROUTE_TOUCH_SUPPORT","RED_ZONE_SUPPORT")),
    ("NFL","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=2, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="TEAM_GAME_SCRIPT_ROLE_CORRELATION", market_fields=("STRATEGY_SCORE","ROUTE_TOUCH_SUPPORT","RED_ZONE_SUPPORT")),
    ("CFB","CLASSIC"): dict(roster_size=9, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="STACK_PACE_ROLE_CORE", script_axis="PACE_ROLE_GAME_SCRIPT", market_fields=("STRATEGY_SCORE","ROUTE_TOUCH_SUPPORT","PACE_SUPPORT")),
    ("CFB","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=2, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="DRIVE_REGIME_ROLE_CORRELATION", market_fields=("STRATEGY_SCORE","ROLE_CERTAINTY","REGIME_SUPPORT")),
    ("PGA","CLASSIC"): dict(roster_size=6, role_sensitive=False, role_slot=None, mutation_depth=1, family_basis="GOLFER_TAIL_WEATHER_CORE", script_axis="TEE_WEATHER_BIRDIE_VOLATILITY", market_fields=("STRATEGY_SCORE","BIRDIE_SUPPORT","WEATHER_SUPPORT")),
    ("PGA","SHOWDOWN_FLAT_6"): dict(roster_size=6, role_sensitive=False, role_slot=None, mutation_depth=1, family_basis="ROUND_TAIL_WEATHER_CORE", script_axis="ROUND_TEE_WEATHER_BIRDIE_VOLATILITY", market_fields=("STRATEGY_SCORE","BIRDIE_SUPPORT","ROUND_SUPPORT")),
    ("PGA","SHOWDOWN_CAPTAIN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=1, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="ROUND_TEE_WEATHER_BIRDIE_VOLATILITY", market_fields=("STRATEGY_SCORE","BIRDIE_SUPPORT","ROUND_SUPPORT")),
    ("TENNIS","CLASSIC"): dict(roster_size=6, role_sensitive=False, role_slot=None, mutation_depth=1, family_basis="MATCH_SCENARIO_VOLATILITY_CORE", script_axis="MATCH_SURFACE_SERVE_RETURN", market_fields=("STRATEGY_SCORE","MATCH_WIN_SUPPORT","VOLATILITY_SUPPORT")),
    ("TENNIS","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=1, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="MATCH_SCENARIO_SERVE_RETURN", market_fields=("STRATEGY_SCORE","MATCH_WIN_SUPPORT","VOLATILITY_SUPPORT")),
    ("MMA","CLASSIC"): dict(roster_size=6, role_sensitive=False, role_slot=None, mutation_depth=1, family_basis="FIGHT_STYLE_FINISH_CORE", script_axis="FIGHT_STYLE_PACE_FINISH", market_fields=("STRATEGY_SCORE","FINISH_SUPPORT","PACE_SUPPORT")),
    ("MMA","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=1, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="FIGHT_STYLE_PACE_FINISH", market_fields=("STRATEGY_SCORE","FINISH_SUPPORT","PACE_SUPPORT")),
    ("NBA","CLASSIC"): dict(roster_size=8, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="GAME_ROLE_MINUTES_CORE", script_axis="MINUTES_USAGE_GAME_CORRELATION", market_fields=("STRATEGY_SCORE","ROLE_CREDIBILITY","MINUTES_STABILITY")),
    ("NBA","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=2, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="TEAM_ROLE_GAME_SCRIPT", market_fields=("STRATEGY_SCORE","ROLE_CREDIBILITY","MINUTES_STABILITY")),
    ("CBB","CLASSIC"): dict(roster_size=8, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="GAME_ROLE_MINUTES_CORE", script_axis="MINUTES_USAGE_GAME_CORRELATION", market_fields=("STRATEGY_SCORE","ROLE_CREDIBILITY","MINUTES_STABILITY")),
    ("NHL","CLASSIC"): dict(roster_size=9, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="LINE_PP_GOALIE_CORE", script_axis="LINE_POWERPLAY_SHOT_GOALIE", market_fields=("STRATEGY_SCORE","SHOT_SUPPORT","POWER_PLAY_SUPPORT")),
}


def normalize_sport_mode(sport: str, mode: str) -> tuple[str,str]:
    s=SPORT_ALIASES.get(_norm(sport),_norm(sport)); m=MODE_ALIASES.get(_norm(mode),_norm(mode))
    return s,m


def intelligence_profile(sport: str, mode: str) -> dict[str,Any]:
    s,m=normalize_sport_mode(sport,mode)
    key=(s,m)
    if key not in _PROFILE_ROWS:
        raise TerminalAIHybridError(f"RUN_INVALID:AI_INTELLIGENCE_PROFILE_UNDEFINED:{s}:{m}")
    p=dict(_PROFILE_ROWS[key]); p.update({"sport":s,"mode":m,"profile_id":f"{s}_{m}_TERMINAL_INTELLIGENCE_v4"})
    return p


def _canonical_json(obj: object) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _lineup_id(row: Mapping[str, Any]) -> str:
    for k in ("LINEUP_ID","LINEUP_INDEX","ID"):
        v=row.get(k)
        if v not in (None, ""):
            return str(v)
    raise TerminalAIHybridError("RUN_INVALID:AI_CANDIDATE_MISSING_LINEUP_ID")


def _lineup_slots(row: Mapping[str, Any]) -> tuple[tuple[str,str], ...]:
    """Return a role-aware lineup slot map across Showdown and Classic schemas."""
    cmap={_norm(k):k for k in row}
    slots=[]
    # Multiplier roles first.
    for role in ("CPT","CAPTAIN","MVP"):
        k=cmap.get(role)
        if k is not None and row.get(k) not in (None,""):
            slots.append(("CPT",str(row[k]).strip())); break
    util_keys=[k for k in row if (_norm(k)=="UTIL" or (_norm(k).startswith("UTIL") and _norm(k)[4:].isdigit()))]
    for k in sorted(util_keys,key=lambda x:(_norm(x)!="UTIL",_norm(x))):
        if row.get(k) not in (None,""): slots.append((_norm(k),str(row[k]).strip()))
    if row.get(cmap.get("UTILS",""),None) not in (None,""):
        text=str(row[cmap["UTILS"]]); sep="|" if "|" in text else ";" if ";" in text else ","
        for i,x in enumerate((x.strip() for x in text.split(sep) if x.strip()),1): slots.append((f"UTIL{i}",x))
    if slots: return tuple(slots)
    # Common Classic / flat schemas.  Position role is retained for display but
    # duplicate detection for non-multiplier contests is player-set based.
    preferred=("QB","RB1","RB2","WR1","WR2","WR3","TE","FLEX","DST","P1","P2","C","1B","2B","3B","SS","OF1","OF2","OF3","G1","G2","G3","G4","G5","G6","F1","F2","F3","F4","F5","F6")
    used=set()
    for role in preferred:
        k=cmap.get(role)
        if k is not None and row.get(k) not in (None,""):
            slots.append((role,str(row[k]).strip())); used.add(k)
    # Generic PLAYER1..PLAYER12 fallback.
    for i in range(1,13):
        k=cmap.get(f"PLAYER{i}")
        if k is not None and k not in used and row.get(k) not in (None,""):
            slots.append((f"PLAYER{i}",str(row[k]).strip())); used.add(k)
    if not slots:
        k=cmap.get("PLAYERS")
        if k is not None and row.get(k) not in (None,""):
            text=str(row[k]); sep="|" if "|" in text else ";" if ";" in text else ","
            slots=[(f"PLAYER{i}",x.strip()) for i,x in enumerate(text.split(sep),1) if x.strip()]
    return tuple(slots)


def _players(row: Mapping[str, Any]) -> tuple[str, ...]:
    return tuple(v for _,v in _lineup_slots(row))


def validate_candidate_rows(rows: Sequence[Mapping[str, Any]]) -> None:
    if not rows:
        raise TerminalAIHybridError("RUN_INVALID:AI_TERMINAL_EMPTY_CANDIDATES")
    forbidden=sorted({_norm(k) for r in rows for k in r} & FORBIDDEN_POSTLOCK_FIELDS)
    if forbidden:
        raise TerminalAIHybridError("RUN_INVALID:POSTLOCK_FIELDS_ENTERED_AI_TERMINAL:"+",".join(forbidden))
    seen=set()
    for r in rows:
        lid=_lineup_id(r)
        if lid in seen:
            raise TerminalAIHybridError(f"RUN_INVALID:DUPLICATE_AI_LINEUP_ID:{lid}")
        seen.add(lid)
        p=_players(r)
        if p and len(p)!=len({x.casefold() for x in p}):
            raise TerminalAIHybridError(f"RUN_INVALID:DUPLICATE_PLAYER_IN_AI_CANDIDATE:{lid}")


def freeze_candidates(rows: Sequence[Mapping[str, Any]]) -> str:
    validate_candidate_rows(rows)
    ordered=sorted((dict(r) for r in rows), key=lambda r:_lineup_id(r))
    return sha256(_canonical_json(ordered)).hexdigest()


def feature_availability(rows: Sequence[Mapping[str, Any]]) -> dict[str, dict[str, int]]:
    cols={_norm(k) for r in rows for k in r}
    out={}
    for group,names in FEATURE_REGISTRY.items():
        present=[n for n in names if _norm(n) in cols]
        out[group]={"AVAILABLE":len(present),"DEFINED":len(names),"MISSING":len(names)-len(present)}
    return out


def _float(row: Mapping[str, Any], name: str, default: float=float("nan")) -> float:
    if name in row: k=name
    else:
        cmap={_norm(k):k for k in row}; k=cmap.get(_norm(name))
    if k is None: return default
    try:
        v=float(str(row.get(k,"")).replace("%","").replace(",","").strip())
        return v if math.isfinite(v) else default
    except Exception:
        return default


def _prob_value(row: Mapping[str, Any], name: str) -> float:
    if name in row: k=name
    else:
        cmap={_norm(k):k for k in row}; k=cmap.get(_norm(name))
    if k is None: return float("nan")
    raw=row.get(k)
    try: v=float(str(raw).replace("%","").strip())
    except Exception: return float("nan")
    if not math.isfinite(v) or v < 0: return float("nan")
    if isinstance(raw,str) and "%" in raw: return min(1.0,v/100.0)
    if v <= 1.0000001: return v
    if v <= 100.0000001: return v/100.0
    return float("nan")


def _pct(values: Sequence[float], higher: bool=True) -> list[float]:
    vals=[float(v) if math.isfinite(float(v)) else float("nan") for v in values]
    valid=sorted(set(v for v in vals if math.isfinite(v)))
    if not valid: return [float("nan")]*len(vals)
    if len(valid)==1: return [0.5 if math.isfinite(v) else float("nan") for v in vals]
    rank={v:i/(len(valid)-1) for i,v in enumerate(valid)}
    return [(rank[v] if higher else 1.0-rank[v]) if math.isfinite(v) else float("nan") for v in vals]


def _first_prob(row: Mapping[str,Any], *names: str) -> float:
    for n in names:
        v=_prob_value(row,n)
        if math.isfinite(v): return v
    return float("nan")


def _first_float(row: Mapping[str,Any], *names: str) -> float:
    for n in names:
        v=_float(row,n)
        if math.isfinite(v): return v
    return float("nan")


def _slot_aux(row: Mapping[str,Any], slot: str, suffix: str, cmap: Mapping[str,str]|None=None) -> Any:
    for name in (f"{slot}_{suffix}",f"{slot}{suffix}"):
        if name in row and row.get(name) not in (None,""): return row.get(name)
    cmap=dict(cmap) if cmap is not None else {_norm(k):k for k in row}
    for name in (f"{slot}_{suffix}",f"{slot}{suffix}"):
        k=cmap.get(_norm(name))
        if k is not None and row.get(k) not in (None,""): return row.get(k)
    return None


def _structural_relationship_features(rows: list[dict[str,Any]], *, sport: str, mode: str) -> None:
    """O(N * roster_size^2) relationship summaries with no pairwise candidate scan.

    Player sets are encoded as Python-int bitmasks.  Exact D1/D2 counts are
    recovered algebraically from subset frequencies; no candidate is removed.
    """
    profile=intelligence_profile(sport,mode)
    player_lists=[tuple(sorted(set(x.casefold() for x in _players(r) if x))) for r in rows]
    universe=sorted({x for arr in player_lists for x in arr}); player_to_bit={x:i for i,x in enumerate(universe)}
    masks=[]
    for arr in player_lists:
        mask=0
        for x in arr: mask |= (1<<player_to_bit[x])
        masks.append(mask)
    exact={}
    for i,mask in enumerate(masks): exact.setdefault(mask,[]).append(i)
    top01=[_first_prob(r,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01") for r in rows]
    p99=[_first_float(r,"MC_P99","BASE_MC_P99","P99") for r in rows]
    # aggregate = [row_count, top01_sum, top01_valid, p99_sum, p99_valid]
    def add(d,key,i):
        a=d.get(key)
        if a is None: a=[0,0.0,0,0.0,0]; d[key]=a
        a[0]+=1
        if math.isfinite(top01[i]): a[1]+=top01[i]; a[2]+=1
        if math.isfinite(p99[i]): a[3]+=p99[i]; a[4]+=1
    d1={}
    row_bits=[]
    for i,mask in enumerate(masks):
        bits=[]; z=mask
        while z:
            lsb=z & -z; bits.append(lsb); z-=lsb
        row_bits.append(bits)
        for b in bits: add(d1,mask^b,i)
    for i,r in enumerate(rows):
        arr=player_lists[i]; mask=masks[i]; bits=row_bits[i]; n=len(bits); fam=exact.get(mask,[]); fam_sib=max(0,len(fam)-1)
        r["AI_INTELLIGENCE_PROFILE_ID"]=profile["profile_id"]
        r["AI_PLAYERSET_CANONICAL"]="|".join(arr)
        r["AI_PLAYERSET_MASK"]=mask
        r["AI_PLAYERSET_SIZE"]=n
        r["AI_EXACT_PLAYERSET_FAMILY_ID"]=sha256("|".join(arr).encode()).hexdigest()[:16]
        r["AI_EXACT_PLAYERSET_SIBLING_COUNT"]=fam_sib
        fam_top=sum(top01[j] for j in fam if math.isfinite(top01[j])); fam_top_valid=sum(math.isfinite(top01[j]) for j in fam)
        fam_p99=sum(p99[j] for j in fam if math.isfinite(p99[j])); fam_p99_valid=sum(math.isfinite(p99[j]) for j in fam)
        if fam_top_valid: r["AI_EXACT_PLAYERSET_FAMILY_TOP01_MASS"]=round(fam_top,15)
        if profile.get("role_sensitive"):
            slots0=_lineup_slots(r); cpt0=next((p.casefold() for slot,p in slots0 if slot=="CPT"),"")
            ids=[]
            for j in fam:
                if j==i: continue
                cptj=next((p.casefold() for slot,p in _lineup_slots(rows[j]) if slot=="CPT"),"")
                if cptj!=cpt0: ids.append(_lineup_id(rows[j]))
            r["AI_RECIPROCAL_ROLE_SIBLING_COUNT"]=len(ids)
            if ids: r["AI_RECIPROCAL_ROLE_SIBLING_IDS"]="|".join(sorted(ids))
        else: r["AI_RECIPROCAL_ROLE_SIBLING_COUNT"]=0
        # D1 exact one-player mutation count/sums. Exact-family siblings appear in
        # each of n one-drop subsets, so subtract those repeats algebraically.
        sc=st=stv=sp=spv=0
        for b in bits:
            a=d1[mask^b]; sc+=a[0]-1; st+=a[1]-(top01[i] if math.isfinite(top01[i]) else 0.0); stv+=a[2]-(1 if math.isfinite(top01[i]) else 0); sp+=a[3]-(p99[i] if math.isfinite(p99[i]) else 0.0); spv+=a[4]-(1 if math.isfinite(p99[i]) else 0)
        d1_count=max(0,sc-n*fam_sib)
        d1_top_valid=max(0,stv-n*(fam_top_valid-(1 if math.isfinite(top01[i]) else 0)))
        d1_p99_valid=max(0,spv-n*(fam_p99_valid-(1 if math.isfinite(p99[i]) else 0)))
        d1_top=st-n*(fam_top-(top01[i] if math.isfinite(top01[i]) else 0.0))
        d1_p99=sp-n*(fam_p99-(p99[i] if math.isfinite(p99[i]) else 0.0))
        r["AI_D1_NEIGHBOR_COUNT"]=d1_count
        # Round only derived evidence serialization, not engine-owned inputs. This
        # removes addition-order floating noise and makes shuffled-row handoffs
        # semantically deterministic.
        if d1_top_valid: r["AI_D1_TOP01_DENSITY"]=round(d1_top/d1_top_valid,15)
        if d1_p99_valid: r["AI_D1_P99_DENSITY"]=round(d1_p99/d1_p99_valid,15)
        r["AI_D2_RELATIONSHIP_MODE"]="ON_DEMAND_NO_CANDIDATE_PRUNING" if profile.get("mutation_depth",1)>=2 else "NOT_PROFILED"
        # Team/script topology when native slot metadata is available.
        slots=_lineup_slots(r); teams=[]; role_team=None; orders=[]; supports=[]; cmap={_norm(k):k for k in r}
        for slot,_ in slots:
            team=_slot_aux(r,slot,"TEAM",cmap); order=_slot_aux(r,slot,"ORDER",cmap); sup=_slot_aux(r,slot,"CONDITIONAL_SUPPORT",cmap)
            if team not in (None,""):
                teams.append(str(team))
                if slot=="CPT": role_team=str(team)
            try: ov=int(float(order)) if order not in (None,"") else None
            except Exception: ov=None
            orders.append((slot,str(team) if team not in (None,"") else None,ov))
            try: supports.append(float(sup))
            except Exception: pass
        if teams:
            from collections import Counter
            c=Counter(teams); r["AI_TEAM_COUNT"]=len(c); r["AI_DOMINANT_TEAM_COUNT"]=max(c.values())
            if role_team is not None:
                r["AI_ROLE_SIDE_COUNT"]=c.get(role_team,0)
                batting=sorted(o for slot,t,o in orders if t==role_team and o is not None and 1<=o<=9)
                r["AI_ROLE_SIDE_HITTER_COUNT"]=len(batting)
                r["AI_BATTING_ADJACENCY_PAIRS"]=sum(1 for a,b in zip(batting,batting[1:]) if b-a==1)
        if supports: r["AI_LINEUP_CONDITIONAL_SUPPORT_SUM"]=sum(supports)


def enrich_ai_evidence(rows: Sequence[Mapping[str, Any]], *, sport: str, mode: str) -> list[dict[str, Any]]:
    """Add transparent sport/mode-tailored evidence; never overwrite engine metrics."""
    # Fail closed before any enrichment so realized/post-lock information can never
    # influence derived AI evidence, even transiently.
    validate_candidate_rows(rows)
    out=[dict(r) for r in rows]
    profile=intelligence_profile(sport,mode)
    win=[_first_prob(r,"MC_WIN_RATE","BASE_MC_WIN_RATE","WIN") for r in out]
    win_l=[_first_prob(r,"MC_WIN_LCB","BASE_MC_WIN_LCB") for r in out]
    t01=[_first_prob(r,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01") for r in out]
    t01_l=[_first_prob(r,"MC_TOP_0_1_LCB","BASE_MC_TOP_0_1_LCB") for r in out]
    p99=[_first_float(r,"MC_P99","BASE_MC_P99","P99") for r in out]
    p95=[_first_float(r,"MC_P95","BASE_MC_P95","P95") for r in out]
    dup=[_first_float(r,"PROJECTED_EXACT_MATCH_DUPLICATION","DUP") for r in out]
    code=[_first_float(r,"CURRENT_SELECTOR_PRE_SCORE","CURRENT_SELECTOR_SCORE") for r in out]
    trials=[_first_float(r,"MC_TRIALS","BASE_MC_TRIALS") for r in out]
    winp=_pct([x if math.isfinite(x) else -1 for x in win_l]); t01p=_pct([x if math.isfinite(x) else -1 for x in t01_l]); p99p=_pct(p99); dupp=_pct(dup,higher=False); codep=_pct(code)
    # sport/mode-specific independent support composite is deliberately an average
    # percentile of available profile fields, not a hard selector score.
    market_arrays=[]
    for fld in profile.get("market_fields",()):
        vals=[_first_float(r,fld) for r in out]
        if any(math.isfinite(x) for x in vals): market_arrays.append(_pct(vals))
    for i,r in enumerate(out):
        r["AI_INTELLIGENCE_PROFILE_ID"]=profile["profile_id"]
        r["AI_PROFILE_FAMILY_BASIS"]=profile["family_basis"]
        r["AI_PROFILE_SCRIPT_AXIS"]=profile["script_axis"]
        if math.isfinite(win[i]) and math.isfinite(win_l[i]): r["AI_WIN_UNCERTAINTY_GAP"]=max(0.0,win[i]-win_l[i])
        if math.isfinite(t01[i]) and math.isfinite(t01_l[i]): r["AI_TOP01_UNCERTAINTY_GAP"]=max(0.0,t01[i]-t01_l[i])
        if math.isfinite(p99[i]) and math.isfinite(p95[i]):
            r["AI_TAIL_SPREAD_P99_P95"]=p99[i]-p95[i]; r["AI_TAIL_ASYMMETRY"]=(p99[i]-p95[i])/max(1e-9,abs(p95[i]))
        if math.isfinite(dup[i]) and dup[i]>=0:
            if math.isfinite(win[i]): r["AI_DUP_ADJ_WIN"]=win[i]/(1+dup[i])
            if math.isfinite(t01[i]): r["AI_DUP_ADJ_TOP01"]=t01[i]/(1+dup[i])
        n=int(trials[i]) if math.isfinite(trials[i]) and trials[i]>=100 else 10000
        if math.isfinite(t01[i]): r["AI_TOP01_95_HALF_WIDTH"]=1.96*math.sqrt(max(0.0,t01[i]*(1-t01[i]))/n)
        if math.isfinite(win[i]): r["AI_WIN_95_HALF_WIDTH"]=1.96*math.sqrt(max(0.0,win[i]*(1-win[i]))/n)
        if math.isfinite(winp[i]): r["AI_WIN_LCB_PCTL"]=winp[i]
        if math.isfinite(t01p[i]): r["AI_TOP01_LCB_PCTL"]=t01p[i]
        if math.isfinite(p99p[i]): r["AI_P99_PCTL"]=p99p[i]
        if math.isfinite(dupp[i]): r["AI_LOW_DUP_PCTL"]=dupp[i]
        if math.isfinite(codep[i]): r["AI_CURRENT_SELECTOR_SCORE_PCTL"]=codep[i]
        support=[x for x in (winp[i],t01p[i],p99p[i],dupp[i]) if math.isfinite(x)]
        if support: r["AI_ELITE_SUPPORT_BREADTH"]=sum(x>=.90 for x in support); r["AI_ROBUST_TAIL_FLOOR_PCTL"]=min(support[:3]) if len(support)>=3 else min(support)
        if math.isfinite(t01p[i]) and math.isfinite(codep[i]): r["AI_TOP01_VS_CODE_DISAGREEMENT"]=t01p[i]-codep[i]
        if market_arrays:
            vals=[a[i] for a in market_arrays if math.isfinite(a[i])]
            if vals:
                mp=sum(vals)/len(vals); r["AI_MARKET_TAIL_SUPPORT_PCTL"]=mp
                if math.isfinite(t01p[i]): r["AI_MARKET_TAIL_VS_MC_DISAGREEMENT"]=mp-t01p[i]
    _structural_relationship_features(out,sport=sport,mode=mode)
    return out


def find_local_mutations(rows: Sequence[Mapping[str,Any]], anchor_id: str|int, *, sport: str, mode: str,
                         distance: int=1, preserve_role: bool=True) -> list[dict[str,Any]]:
    """Return existing local mutation candidates without pruning the AI universe.

    Uses enriched deterministic player-set bitmasks when present. The returned
    list is an analysis view; every original candidate remains AI eligible.
    """
    profile=intelligence_profile(sport,mode); by={_lineup_id(r):r for r in rows}; aid=str(anchor_id)
    if aid not in by: raise TerminalAIHybridError(f"RUN_INVALID:AI_MUTATION_ANCHOR_UNKNOWN:{aid}")
    anchor=by[aid]
    try: am=int(anchor.get("AI_PLAYERSET_MASK")); an=int(anchor.get("AI_PLAYERSET_SIZE"))
    except Exception:
        aset=set(x.casefold() for x in _players(anchor)); an=len(aset); universe=sorted({x.casefold() for r in rows for x in _players(r)}); mp={x:i for i,x in enumerate(universe)}; am=sum(1<<mp[x] for x in aset)
    anchor_role=next((p.casefold() for slot,p in _lineup_slots(anchor) if slot=="CPT"),"") if profile.get("role_sensitive") else ""
    out=[]
    for r in rows:
        if _lineup_id(r)==aid: continue
        if preserve_role and profile.get("role_sensitive"):
            role=next((p.casefold() for slot,p in _lineup_slots(r) if slot=="CPT"),"")
            if role!=anchor_role: continue
        try: cm=int(r.get("AI_PLAYERSET_MASK")); cn=int(r.get("AI_PLAYERSET_SIZE"))
        except Exception: continue
        if cn!=an: continue
        # For equal-size sets, one player mutation => xor has 2 bits; two => 4.
        if (am^cm).bit_count()!=2*int(distance): continue
        cand=dict(r)
        cand["AI_MUTATION_DISTANCE"]=int(distance)
        cand["AI_MUTATION_SHARED_PLAYERS"]=an-int(distance)
        out.append(cand)
    return out


def mutation_relationship(anchor: Mapping[str,Any], candidate: Mapping[str,Any], *, sport: str, mode: str) -> dict[str,Any]:
    """Mechanically compare two existing candidates; no selection or pruning occurs."""
    profile=intelligence_profile(sport,mode); ap=set(x.casefold() for x in _players(anchor)); cp=set(x.casefold() for x in _players(candidate))
    shared=len(ap&cp); dist=max(len(ap),len(cp))-shared
    at=_first_prob(anchor,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01"); ct=_first_prob(candidate,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01")
    aw=_first_prob(anchor,"MC_WIN_RATE","BASE_MC_WIN_RATE","WIN"); cw=_first_prob(candidate,"MC_WIN_RATE","BASE_MC_WIN_RATE","WIN")
    n=int(_first_float(anchor,"MC_TRIALS","BASE_MC_TRIALS")) if math.isfinite(_first_float(anchor,"MC_TRIALS","BASE_MC_TRIALS")) else 10000
    tb=1.96*math.sqrt(max(0.0,at*(1-at))/max(100,n)) if math.isfinite(at) else float("nan")
    wb=1.96*math.sqrt(max(0.0,aw*(1-aw))/max(100,n)) if math.isfinite(aw) else float("nan")
    out={"ANCHOR_LINEUP_ID":_lineup_id(anchor),"CANDIDATE_LINEUP_ID":_lineup_id(candidate),"SHARED_PLAYERS":shared,"MUTATION_DISTANCE":dist,"PROFILE_ID":profile["profile_id"]}
    if math.isfinite(at) and math.isfinite(ct): out["DELTA_TOP01"]=ct-at; out["TOP01_EQUIVALENT_95"]=abs(ct-at)<=tb
    if math.isfinite(aw) and math.isfinite(cw): out["DELTA_WIN"]=cw-aw; out["WIN_EQUIVALENT_95"]=abs(cw-aw)<=wb
    for key,names in {"DELTA_P95":("MC_P95","BASE_MC_P95","P95"),"DELTA_P99":("MC_P99","BASE_MC_P99","P99"),"DELTA_TOP10":("MC_TOP10_RATE","BASE_MC_TOP10_RATE","TOP10")}.items():
        a=_first_prob(anchor,*names) if "TOP10" in key else _first_float(anchor,*names); c=_first_prob(candidate,*names) if "TOP10" in key else _first_float(candidate,*names)
        if math.isfinite(a) and math.isfinite(c): out[key]=c-a
    out["SALARY_DELTA"]=_first_float(candidate,"SALARY")-_first_float(anchor,"SALARY") if math.isfinite(_first_float(candidate,"SALARY")) and math.isfinite(_first_float(anchor,"SALARY")) else float("nan")
    # Compare already-derived script evidence if present.
    for fld in ("AI_ROLE_SIDE_COUNT","AI_ROLE_SIDE_HITTER_COUNT","AI_BATTING_ADJACENCY_PAIRS","AI_LINEUP_CONDITIONAL_SUPPORT_SUM"):
        a=_first_float(anchor,fld); c=_first_float(candidate,fld)
        if math.isfinite(a) and math.isfinite(c): out[f"DELTA_{fld.removeprefix('AI_')}"]=c-a
    return out


def write_review_surface(rows: Sequence[Mapping[str, Any]], *, csv_path: str|Path, receipt_path: str|Path,
                         sport: str, mode: str, execution_id: str, context: Mapping[str,Any]|None=None) -> dict[str,Any]:
    rows=enrich_ai_evidence([dict(r) for r in rows],sport=sport,mode=mode)
    validate_candidate_rows(rows)
    csv_path=Path(csv_path); receipt_path=Path(receipt_path)
    csv_path.parent.mkdir(parents=True,exist_ok=True)
    fields=[]; seen=set()
    for r in rows:
        for k in r:
            if k not in seen: fields.append(k); seen.add(k)
    with csv_path.open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore"); w.writeheader(); w.writerows(rows)
    # Freeze the exact semantic surface the AI will reload. CSV serialization
    # normalizes bool/int/float cells to text, so hash after round-trip.
    frozen_rows=load_candidate_csv(csv_path)
    freeze=freeze_candidates(frozen_rows)
    context=dict(context or {})
    receipt={
        "PATCH_ID":PATCH_ID,"SELECTOR_MODE":SELECTOR_MODE,"SPORT":str(sport).upper(),"MODE":str(mode).upper(),
        "EXECUTION_ID":str(execution_id),"CANDIDATE_COUNT":len(frozen_rows),"CANDIDATE_FREEZE_SHA256":freeze,
        "CANDIDATE_SURFACE_PATH":str(csv_path),"CANDIDATE_SURFACE_SHA256":sha256(csv_path.read_bytes()).hexdigest(),
        "TOP5_POLICY_ID":TOP5_POLICY_ID,"FINAL_BOARD_SIZE":BOARD_SIZE,
        "FULL_HANDOFF_REQUIRED":True,"NO_PRUNING":True,"NO_TOP_N_SIEVE":True,"NO_AI_REVIEW_COHORT":True,
        "AI_AUTHORITY":"RANK_SORT_COMPARE_TIEBREAK_PORTFOLIO_SELECT_ONLY",
        "AI_MAY_CREATE_LINEUPS":False,"AI_MAY_MUTATE_METRICS":False,"AI_MAY_RECALIBRATE":False,
        "AI_MAY_USE_POSTLOCK_RESULTS":False,"CODE_SELECTOR_ROLE":"ADVISORY_COMPARATOR_ONLY_WHEN_AI_AUTHORITY_ENABLED",
        "FEATURE_AVAILABILITY":feature_availability(frozen_rows),"FEATURE_REGISTRY":FEATURE_REGISTRY,
        "INTELLIGENCE_PROFILE":intelligence_profile(sport,mode),
        "ALLOWED_REASON_CODES":sorted(ALLOWED_REASON_CODES),"CONTEXT":context,
    }
    receipt_path.write_text(json.dumps(receipt,indent=2,sort_keys=True),encoding="utf-8")
    receipt["RECEIPT_PATH"]=str(receipt_path)
    receipt["RECEIPT_SHA256"]=sha256(receipt_path.read_bytes()).hexdigest()
    return receipt


def load_candidate_csv(path: str|Path) -> list[dict[str,Any]]:
    with Path(path).open("r",encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))


def load_decision(path: str|Path) -> dict[str,Any]:
    obj=json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(obj,dict): raise TerminalAIHybridError("RUN_INVALID:AI_DECISION_NOT_OBJECT")
    return obj


def _overlap(a: Sequence[str], b: Sequence[str]) -> float:
    sa={str(x).casefold() for x in a if str(x).strip()}; sb={str(x).casefold() for x in b if str(x).strip()}
    return len(sa&sb)/max(1,min(len(sa),len(sb)))


def materialize_ai_board(rows: Sequence[Mapping[str,Any]], decision: Mapping[str,Any], *, board_size: int=BOARD_SIZE) -> list[dict[str,Any]]:
    """Materialize the user-visible board before formal legality/hash validation.

    This is intentionally not a validation gate. It only resolves the five AI-returned
    existing IDs to their frozen candidate rows so the board can be rendered first.
    Formal candidate-membership, reason-code, legality, and hash validation remains
    post-board in validate_ai_decision / the production seal.
    """
    picks=decision.get("selections")
    if not isinstance(picks,list) or len(picks)!=int(board_size):
        raise TerminalAIHybridError(f"RUN_INVALID:AI_BOARD_RENDER_SIZE_MISMATCH:{0 if not isinstance(picks,list) else len(picks)}:{board_size}")
    by_id={_lineup_id(dict(r)):dict(r) for r in rows}
    out=[]
    for rank,p in enumerate(picks,1):
        if not isinstance(p,dict):
            raise TerminalAIHybridError("RUN_INVALID:AI_BOARD_RENDER_SELECTION_NOT_OBJECT")
        lid=str(p.get("lineup_id",p.get("LINEUP_ID",p.get("LINEUP_INDEX",""))))
        # Lookup is board materialization, not the formal post-board membership receipt.
        if lid not in by_id:
            raise TerminalAIHybridError(f"RUN_INVALID:AI_BOARD_RENDER_UNKNOWN_ID:{lid}")
        r=dict(by_id[lid]); r["AI_TERMINAL_RANK"]=rank
        reasons=tuple(str(x) for x in (p.get("reason_codes") or []))
        if reasons: r["AI_REASON_CODES"]="|".join(reasons)
        out.append(r)
    return out


def validate_ai_decision(rows: Sequence[Mapping[str,Any]], decision: Mapping[str,Any], *, expected_freeze_hash: str|None=None,
                         board_size: int=BOARD_SIZE, sport: str|None=None, mode: str|None=None) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    rows=[dict(r) for r in rows]
    freeze=freeze_candidates(rows)
    if expected_freeze_hash and freeze != str(expected_freeze_hash):
        raise TerminalAIHybridError("RUN_INVALID:AI_FROZEN_MATRIX_HASH_MISMATCH")
    if decision.get("candidate_freeze_sha256") not in (None,"",freeze):
        raise TerminalAIHybridError("RUN_INVALID:AI_DECISION_HASH_MISMATCH")
    picks=decision.get("selections")
    if not isinstance(picks,list) or len(picks)!=int(board_size):
        raise TerminalAIHybridError(f"RUN_INVALID:AI_BOARD_SIZE_MISMATCH:{0 if not isinstance(picks,list) else len(picks)}:{board_size}")
    by_id={_lineup_id(r):r for r in rows}
    out=[]; ids=[]; all_reasons=[]
    for rank,p in enumerate(picks,1):
        if not isinstance(p,dict): raise TerminalAIHybridError("RUN_INVALID:AI_SELECTION_NOT_OBJECT")
        lid=str(p.get("lineup_id",p.get("LINEUP_ID",p.get("LINEUP_INDEX",""))))
        if lid not in by_id: raise TerminalAIHybridError(f"RUN_INVALID:AI_CREATED_UNSEEN_LINEUP:{lid}")
        if lid in ids: raise TerminalAIHybridError(f"RUN_INVALID:AI_DUPLICATE_LINEUP:{lid}")
        reasons=tuple(str(x) for x in (p.get("reason_codes") or []))
        if not reasons: raise TerminalAIHybridError(f"RUN_INVALID:AI_MISSING_REASON_CODES:{lid}")
        bad=sorted(set(reasons)-ALLOWED_REASON_CODES)
        if bad: raise TerminalAIHybridError(f"RUN_INVALID:AI_INVALID_REASON_CODES:{lid}:{','.join(bad)}")
        r=dict(by_id[lid]); r["AI_TERMINAL_RANK"]=rank; r["AI_REASON_CODES"]="|".join(reasons)
        out.append(r); ids.append(lid); all_reasons.extend(reasons)
    player_sets=[_players(r) for r in out]
    role_sensitive=False
    profile=None
    if sport is not None and mode is not None:
        profile=intelligence_profile(sport,mode); role_sensitive=bool(profile.get("role_sensitive"))
    if role_sensitive:
        signatures=[]
        for r in out:
            slots=_lineup_slots(r)
            cpt=next((player.casefold() for slot,player in slots if slot=="CPT"),"")
            utils=tuple(sorted(player.casefold() for slot,player in slots if slot!="CPT"))
            signatures.append((cpt,utils))
    else:
        signatures=[tuple(sorted(x.casefold() for x in p)) for p in player_sets]
    if len(set(signatures)) != len(out):
        raise TerminalAIHybridError("RUN_INVALID:AI_FINAL_EXACT_DUPLICATE_LINEUP")
    # Top-5 is a coordinated portfolio, not five independent ranks. Require the
    # decision to explicitly account for marginal portfolio value/diversification.
    portfolio_codes={"PORTFOLIO_MARGINAL_VALUE","CHAMPIONSHIP_UNION_COVERAGE","TOP01_UNION_COVERAGE","REGIME_COVERAGE","COUNTER_SCRIPT_COVERAGE","STRUCTURE_DIVERSIFICATION","DOMINANT_FAMILY_EVIDENCE","DOMINANT_FAMILY_SUPPORT","CONDITIONAL_CORE_FIT","LOCAL_CHAMPIONSHIP_DENSITY","DECK_DEPTH_PROTECTED"}
    if not (set(all_reasons)&portfolio_codes):
        raise TerminalAIHybridError("RUN_INVALID:AI_TOP5_PARLAY_PORTFOLIO_REASON_MISSING")
    overlaps=[]
    for i in range(len(out)):
        for j in range(i+1,len(out)):
            overlaps.append(_overlap(player_sets[i],player_sets[j]))
    receipt={
        "PATCH_ID":PATCH_ID,"STATUS":"PASS","CANDIDATE_FREEZE_SHA256":freeze,"FINAL_BOARD_SIZE":len(out),
        "SELECTED_LINEUP_IDS":ids,"TOP5_POLICY_ID":TOP5_POLICY_ID,"TOP5_PARLAY_VALIDATED":True,
        "MAX_PAIRWISE_PLAYER_OVERLAP":max(overlaps) if overlaps else 0.0,"AVG_PAIRWISE_PLAYER_OVERLAP":sum(overlaps)/len(overlaps) if overlaps else 0.0,
        "AI_CREATED_LINEUPS":False,"AI_MUTATED_METRICS":False,"POSTLOCK_RESULTS_USED":False,
        "CODE_SELECTOR_TERMINAL_AUTHORITY":False,"AI_TERMINAL_AUTHORITY":True,
        "INTELLIGENCE_PROFILE":profile,
    }
    return out,receipt
