from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Iterable, Mapping, Sequence

PATCH_ID = "APEX_GLOBAL_MODULAR_BLIND_BACKOPT_VALIDATION_v1"
FORBIDDEN_PRELOCK_KEYS = {
    "actual_fpts", "actual_score", "contest_rank", "final_rank", "winning_lineup",
    "winner_lineup", "postlock_result", "realized_score", "realized_rank",
}


def stable_hash(value: object) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
    return hashlib.sha256(raw).hexdigest()


def file_sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def assert_prelock_blind(payload: Mapping[str, object]) -> None:
    bad = sorted({str(k).lower() for k in payload}.intersection(FORBIDDEN_PRELOCK_KEYS))
    if bad:
        raise RuntimeError("BLIND_PRELOCK_OUTCOME_LEAK:" + ",".join(bad))


def seal_board(board_payload: object, selector_payload: object) -> dict[str, str]:
    return {
        "BOARD_SHA256": stable_hash(board_payload),
        "SELECTOR_LEDGER_SHA256": stable_hash(selector_payload),
        "SEAL_STATE": "SEALED_BEFORE_UNBLIND",
    }


def verify_seal(board_payload: object, selector_payload: object, seal: Mapping[str, str]) -> None:
    if stable_hash(board_payload) != seal.get("BOARD_SHA256"):
        raise RuntimeError("BLIND_BOARD_MUTATED_AFTER_SEAL")
    if stable_hash(selector_payload) != seal.get("SELECTOR_LEDGER_SHA256"):
        raise RuntimeError("BLIND_SELECTOR_LEDGER_MUTATED_AFTER_SEAL")


def canonical_lineup(row: Sequence[object]) -> tuple[str, ...]:
    return tuple(sorted(str(x) for x in row))


def family_recall_report(
    *,
    phase2_lineups: Iterable[Sequence[object]],
    handoff_lineups: Iterable[Sequence[object]],
    selector_reviewed_lineups: Iterable[Sequence[object]],
    board_lineups: Iterable[Sequence[object]],
    winner_lineup: Sequence[object],
    family_key,
) -> dict[str, object]:
    winner = canonical_lineup(winner_lineup)
    p2 = [canonical_lineup(x) for x in phase2_lineups]
    handoff = [canonical_lineup(x) for x in handoff_lineups]
    reviewed = [canonical_lineup(x) for x in selector_reviewed_lineups]
    board = [canonical_lineup(x) for x in board_lineups]
    winner_family = family_key(winner)
    p2_family = [x for x in p2 if family_key(x) == winner_family]
    born = winner in p2
    handed = winner in handoff
    selector_seen = winner in reviewed
    boarded = winner in board
    if not born:
        failure = "CALIBRATION_OR_GENERATOR_FAILURE"
    elif not handed:
        failure = "HANDOFF_RECALL_FAILURE"
    elif not selector_seen:
        failure = "SELECTOR_REVIEW_PARITY_FAILURE"
    elif not boarded:
        failure = "SELECTOR_OR_PORTFOLIO_FAILURE"
    else:
        failure = "CAPTURED"
    return {
        "WINNER_BORN": born,
        "WINNER_HANDOFF": handed,
        "WINNER_SELECTOR_REVIEWED": selector_seen,
        "WINNER_BOARD": boarded,
        "WINNING_FAMILY_BORN": bool(p2_family),
        "WINNING_FAMILY_PHASE2_COUNT": len(p2_family),
        "FAMILY_RECALL_RATE": (len(p2_family) / len(p2)) if p2 else 0.0,
        "FAILURE_CLASS": failure,
    }


def blind_run_manifest(
    *, engine_hash: str, calibration_hash: str, prelock_inputs: Mapping[str, object],
    phase2_hash: str, seal: Mapping[str, str],
) -> dict[str, object]:
    assert_prelock_blind(prelock_inputs)
    if seal.get("SEAL_STATE") != "SEALED_BEFORE_UNBLIND":
        raise RuntimeError("BLIND_RUN_NOT_SEALED")
    return {
        "PATCH_ID": PATCH_ID,
        "ENGINE_HASH": engine_hash,
        "CALIBRATION_HASH": calibration_hash,
        "PRELOCK_INPUT_HASH": stable_hash(prelock_inputs),
        "PHASE2_FREEZE_HASH": phase2_hash,
        **dict(seal),
        "UNBLIND_ALLOWED": True,
    }
