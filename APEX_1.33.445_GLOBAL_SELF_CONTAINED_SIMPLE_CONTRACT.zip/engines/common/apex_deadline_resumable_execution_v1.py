from __future__ import annotations
import hashlib, json, os, pickle, shutil, time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

PATCH_ID="APEX_GLOBAL_DEADLINE_RESUMABLE_EXECUTION_AND_STALE_HASH_QUARANTINE_v1"
SCHEMA_VERSION="1.0.0"

@dataclass
class RuntimeBudget:
    started_monotonic: float
    soft_limit_seconds: float
    reserve_seconds: float=15.0
    chunk_ema_seconds: Optional[float]=None
    completed_chunks: int=0
    @property
    def elapsed_seconds(self)->float: return time.monotonic()-self.started_monotonic
    @property
    def remaining_seconds(self)->float: return max(0.0,self.soft_limit_seconds-self.elapsed_seconds)
    def update_chunk_runtime(self,seconds:float,alpha:float=.25)->None:
        self.chunk_ema_seconds=float(seconds) if self.chunk_ema_seconds is None else alpha*float(seconds)+(1.0-alpha)*self.chunk_ema_seconds
        self.completed_chunks+=1
    def predicted_next_chunk_seconds(self)->float: return float(self.chunk_ema_seconds or 0.0)
    def should_yield(self)->bool: return self.remaining_seconds <= self.reserve_seconds+self.predicted_next_chunk_seconds()

def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def atomic_json(path:Path,obj:dict)->None:
    path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8') as f: json.dump(obj,f,indent=2,sort_keys=True); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)

def atomic_pickle(path:Path,obj:Any)->str:
    path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('wb') as f: pickle.dump(obj,f,protocol=pickle.HIGHEST_PROTOCOL); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path); return sha256_file(path)

def safe_run_id(run_id:str)->str:
    out=''.join(c for c in str(run_id) if c.isalnum() or c in ('-','_'))
    if not out: raise RuntimeError('RUN_INVALID:EMPTY_RUN_ID')
    return out

def run_root(base:Path,run_id:str)->Path:
    r=Path(base)/safe_run_id(run_id); r.mkdir(parents=True,exist_ok=True); return r

def identity_signature(*,run_id:str,state_version:str,player_pool_sha256:str,engine_sha256:str)->str:
    raw=json.dumps([str(run_id),str(state_version),str(player_pool_sha256),str(engine_sha256)],separators=(',',':')).encode()
    return hashlib.sha256(raw).hexdigest()

def initial_state(*,run_id:str,state_version:str,player_pool_sha256:str,engine_sha256:str)->dict:
    return {'PATCH_ID':PATCH_ID,'SCHEMA_VERSION':SCHEMA_VERSION,'RUN_ID':str(run_id),'STATE_VERSION':str(state_version),'PLAYER_POOL_SHA256':str(player_pool_sha256),'ENGINE_SHA256':str(engine_sha256),
            'IDENTITY_SIGNATURE':identity_signature(run_id=run_id,state_version=state_version,player_pool_sha256=player_pool_sha256,engine_sha256=engine_sha256),
            'CURRENT_PHASE':'INITIALIZED','EXECUTION_STATE':'RUNNING','LAST_SUCCESSFUL_CHUNK':-1,'TOTAL_CHUNKS':0,'BASE_SIM_TRIALS':0,'COMPLETED_LINEUP_CHUNKS':0,
            'LINEUP_TRIAL_EVALUATIONS':0,'CHUNK_EMA_SECONDS':None,'SAFE_YIELD_COUNT':0,'CHECKPOINT_MANIFEST':{},'LAST_CHECKPOINT_SHA256':''}

def quarantine_root(root:Path)->Path|None:
    if not root.exists(): return None
    q=root.with_name(root.name+f'.stale.{time.time_ns()}'); os.replace(root,q); root.mkdir(parents=True,exist_ok=True); return q

def load_or_initialize(*,base:Path,run_id:str,state_version:str,player_pool_sha256:str,engine_sha256:str)->tuple[Path,dict,bool]:
    root=run_root(base,run_id); sf=root/'.session_state.json'; fresh=initial_state(run_id=run_id,state_version=state_version,player_pool_sha256=player_pool_sha256,engine_sha256=engine_sha256)
    if not sf.exists(): atomic_json(sf,fresh); return root,fresh,False
    try: state=json.loads(sf.read_text(encoding='utf-8'))
    except Exception: state={}
    if state.get('IDENTITY_SIGNATURE')!=fresh['IDENTITY_SIGNATURE'] or state.get('SCHEMA_VERSION')!=SCHEMA_VERSION:
        quarantine_root(root); atomic_json(root/'.session_state.json',fresh); return root,fresh,True
    return root,state,False

def save_checkpoint(*,root:Path,state:dict,chunk_index:int,payload:Any,runtime_seconds:float,lineup_count:int,base_sim_trials:int)->Path:
    cp=root/'checkpoints'/f'chunk_{int(chunk_index):08d}.pkl'; digest=atomic_pickle(cp,payload)
    state.setdefault('CHECKPOINT_MANIFEST',{})[str(int(chunk_index))]={'path':str(cp),'sha256':digest,'chunk_index':int(chunk_index),'runtime_seconds':float(runtime_seconds),'lineup_count':int(lineup_count)}
    state['LAST_SUCCESSFUL_CHUNK']=int(chunk_index); state['LAST_CHECKPOINT_SHA256']=digest; state['COMPLETED_LINEUP_CHUNKS']=int(chunk_index)+1
    state['BASE_SIM_TRIALS']=int(base_sim_trials); state['LINEUP_TRIAL_EVALUATIONS']=int(state.get('LINEUP_TRIAL_EVALUATIONS',0))+int(lineup_count)*int(base_sim_trials)
    atomic_json(root/'.session_state.json',state); return cp

def verify_checkpoint(meta:dict)->bool:
    p=Path(str(meta.get('path',''))); return p.exists() and bool(meta.get('sha256')) and sha256_file(p)==str(meta['sha256'])

def rollback_to_last_valid(root:Path,state:dict)->dict:
    manifest=state.get('CHECKPOINT_MANIFEST',{}) or {}; last=-1
    for idx in range(int(state.get('TOTAL_CHUNKS',0))):
        meta=manifest.get(str(idx))
        if not meta or not verify_checkpoint(meta): break
        last=idx
    for k in list(manifest):
        if int(k)>last: manifest.pop(k,None)
    state['LAST_SUCCESSFUL_CHUNK']=last; state['COMPLETED_LINEUP_CHUNKS']=last+1; state['CHECKPOINT_MANIFEST']=manifest
    state['LAST_CHECKPOINT_SHA256']=manifest.get(str(last),{}).get('sha256','') if last>=0 else ''
    atomic_json(root/'.session_state.json',state); return state

def mark_resumable(root:Path,state:dict,budget:RuntimeBudget,next_chunk:int)->dict:
    state['EXECUTION_STATE']='RESUMABLE'; state['SAFE_YIELD_COUNT']=int(state.get('SAFE_YIELD_COUNT',0))+1; state['NEXT_CHUNK']=int(next_chunk); state['CHUNK_EMA_SECONDS']=budget.chunk_ema_seconds
    state['RUNTIME_BUDGET']={'elapsed_seconds':budget.elapsed_seconds,'remaining_seconds':budget.remaining_seconds,'predicted_next_chunk_seconds':budget.predicted_next_chunk_seconds()}
    atomic_json(root/'.session_state.json',state); return state


def compile_verified_chunks(*,root:Path,state:dict,output_name:str='PHASE2_BUILT_LINEUPS.pkl')->dict:
    total=int(state.get('TOTAL_CHUNKS',0))
    if total<=0: raise RuntimeError('RUN_INVALID:TOTAL_CHUNKS_ZERO')
    manifest=state.get('CHECKPOINT_MANIFEST',{}) or {}
    if len(manifest)!=total:
        raise RuntimeError(f'RUN_INVALID:CHECKPOINT_COUNT_MISMATCH:EXPECTED={total}:FOUND={len(manifest)}')
    rows=[]; verified=[]
    for idx in range(total):
        meta=manifest.get(str(idx))
        if not meta or not verify_checkpoint(meta):
            raise RuntimeError(f'RUN_INVALID:CHECKPOINT_INVALID:{idx}')
        p=Path(meta['path'])
        with p.open('rb') as f: payload=pickle.load(f)
        if isinstance(payload,list): rows.extend(payload)
        elif hasattr(payload,'to_dict'): rows.extend(payload.to_dict(orient='records'))
        else: rows.append(payload)
        verified.append({'chunk_index':idx,'path':str(p),'sha256':meta['sha256']})
    out=root/output_name; digest=atomic_pickle(out,rows)
    mf=root/(output_name+'.manifest.json')
    receipt={'PATCH_ID':PATCH_ID,'RUN_ID':state['RUN_ID'],'STATE_VERSION':state['STATE_VERSION'],'PLAYER_POOL_SHA256':state['PLAYER_POOL_SHA256'],'ENGINE_SHA256':state['ENGINE_SHA256'],
             'TOTAL_CHUNKS':total,'VERIFIED_CHUNKS':len(verified),'PHASE2_BUILT_LINEUPS':len(rows),'PHASE2_FILE':str(out),'PHASE2_SHA256':digest,'CHECKPOINTS':verified}
    atomic_json(mf,receipt)
    state.update({'CURRENT_PHASE':'PHASE_2_BUILT_LINEUPS_COMPLETE','EXECUTION_STATE':'RUNNING','PHASE2_BUILT_LINEUPS':len(rows),'PHASE2_FILE':str(out),'PHASE2_SHA256':digest,'PHASE2_MANIFEST':str(mf)})
    atomic_json(root/'.session_state.json',state)
    return receipt

def seal_phase_artifact(*,root:Path,state:dict,phase:str,artifact_path:Path,count_key:str,count:int,next_phase:str)->dict:
    artifact_path=Path(artifact_path)
    if not artifact_path.exists(): raise RuntimeError(f'RUN_INVALID:{phase}_ARTIFACT_MISSING:{artifact_path}')
    digest=sha256_file(artifact_path)
    state[f'{phase}_FILE']=str(artifact_path); state[f'{phase}_SHA256']=digest; state[count_key]=int(count)
    state['CURRENT_PHASE']=str(next_phase); state['EXECUTION_STATE']='RUNNING'
    atomic_json(root/'.session_state.json',state)
    return {'PHASE':phase,'FILE':str(artifact_path),'SHA256':digest,count_key:int(count),'NEXT_PHASE':next_phase}

def finalize_board_state(*,root:Path,state:dict,board_path:Path,board_size:int)->dict:
    receipt=seal_phase_artifact(root=root,state=state,phase='FINAL_BOARD',artifact_path=board_path,count_key='FINAL_BOARD_SIZE',count=board_size,next_phase='FINAL_BOARD_COMPLETE')
    state['EXECUTION_STATE']='COMPLETED'; state['CURRENT_PHASE']='FINAL_BOARD_COMPLETE'; atomic_json(root/'.session_state.json',state)
    receipt['EXECUTION_STATE']='COMPLETED'; return receipt
