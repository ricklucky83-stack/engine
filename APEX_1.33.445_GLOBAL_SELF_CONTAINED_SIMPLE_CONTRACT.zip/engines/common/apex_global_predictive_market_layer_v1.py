from __future__ import annotations

"""Global prediction-first market interpretation layer.

This layer runs after authoritative availability/identity reconciliation and
before any sport strategist or Phase 1 calibration. It converts betting-market
inputs and independent model evidence into frozen, player-aligned probability
signals. Downstream strategy may consume the frozen signals but may not mutate,
re-rank, or backfit them.
"""

import hashlib
import json
import math
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

PATCH_ID = "APEX_GLOBAL_PREDICTIVE_MARKET_LAYER_v1"
DOCTRINE_ID = PATCH_ID
CONTRACT_VERSION = "1.1"
LOAD_ORDER = "AFTER_AUTHORITATIVE_AVAILABILITY_AND_IDENTITY_RECONCILIATION_BEFORE_SPORTS_STRATEGIST"
DEFAULT_MIN_EDGE = 0.025
DEFAULT_EDGE_Z = 1.6448536269514722
DEFAULT_STALE_MINUTES = 90.0

FORBIDDEN_FORWARD_FIELDS = {
    "ACTUAL_FPTS", "REALIZED_FPTS", "FINAL_RANK", "CONTEST_RANK",
    "WINNING_LINEUP", "POSTLOCK_SCORE", "TARGET_ACTUAL_SCORE",
    "FINAL_BOARD_RANKS", "ACTUAL_RESULT", "SETTLED_RESULT",
}

PLAYER_LINE_ALIASES = ("PROP_LINE", "PLAYER_PROP_LINE", "BETTING_LINE", "LINE")
MODEL_MEAN_ALIASES = ("MODEL_MEAN", "PREDICTED_STAT", "STAT_PROJECTION", "PROJ_STAT")
MODEL_STD_ALIASES = ("MODEL_STD", "STAT_STDDEV", "STDDEV", "SIGMA")
MODEL_OVER_PROB_ALIASES = ("AI_OVER_PROBABILITY", "MODEL_OVER_PROBABILITY", "MORE_PROBABILITY", "OVER_PROBABILITY")
OVER_ODDS_ALIASES = ("OVER_ODDS", "MORE_ODDS", "OVER_PRICE", "MORE_PRICE")
UNDER_ODDS_ALIASES = ("UNDER_ODDS", "LESS_ODDS", "UNDER_PRICE", "LESS_PRICE")
OPEN_LINE_ALIASES = ("OPEN_LINE", "OPENING_LINE", "OPEN_PROP_LINE")
DISTRIBUTION_ALIASES = ("DISTRIBUTION", "DIST_TYPE", "MODEL_DISTRIBUTION")
STAT_TYPE_ALIASES = ("PROP_STAT", "STAT_TYPE", "MARKET_TYPE")
MONEYLINE_ALIASES = ("MONEYLINE", "ML", "TEAM_MONEYLINE")
OPP_MONEYLINE_ALIASES = ("OPP_MONEYLINE", "OPP_ML", "OPPONENT_MONEYLINE")
SPREAD_ALIASES = ("SPREAD", "TEAM_SPREAD")
TOTAL_ALIASES = ("TOTAL", "GAME_TOTAL", "O/U", "OU")
TEAM_TOTAL_ALIASES = ("TEAM_TOTAL", "TEAM_IMPLIED_TOTAL", "T RUNS", "T_RUNS")
MODEL_PROB_STD_ALIASES = ("MODEL_OVER_PROBABILITY_STD", "MODEL_PROB_STD", "PROBABILITY_STD", "EDGE_MODEL_STD")
MODEL_CALIBRATION_ERROR_ALIASES = ("MODEL_CALIBRATION_ERROR", "CALIBRATION_ERROR", "Brier_Error")
CONSENSUS_OVER_PROB_ALIASES = ("CONSENSUS_OVER_PROBABILITY", "CONSENSUS_MORE_PROBABILITY", "MARKET_CONSENSUS_OVER")
MARKET_DISAGREEMENT_ALIASES = ("MARKET_DISAGREEMENT", "MARKET_DISAGREEMENT_SCORE", "CROSS_BOOK_STD")
BOOK_COUNT_ALIASES = ("BOOK_COUNT", "SPORTSBOOK_COUNT", "BOOKS")
ALT_LINE_COUNT_ALIASES = ("ALT_LINE_COUNT", "ALTERNATE_LINE_COUNT", "ALT_LINES")
SNAPSHOT_AGE_ALIASES = ("MARKET_SNAPSHOT_AGE_MINUTES", "SNAPSHOT_AGE_MINUTES", "MARKET_AGE_MINUTES")
MARKET_STATUS_ALIASES = ("MARKET_STATUS", "PROP_STATUS", "BET_STATUS")
EXPLICIT_STALE_ALIASES = ("STALE_LINE_FLAG", "STALE_MARKET", "IS_STALE")
PROJECTION_MARKET_STATUS_ALIASES = ("PROJECTION_MARKET_STATUS", "MODEL_MARKET_STATUS", "PROJECTION_SOURCE_CLASS")
MARKET_TIMESTAMP_ALIASES = ("MARKET_SNAPSHOT_TIMESTAMP", "MARKET_TIMESTAMP", "ODDS_TIMESTAMP")
LOCK_TIMESTAMP_ALIASES = ("SLATE_LOCK_TIMESTAMP", "EVENT_LOCK_TIMESTAMP", "LOCK_TIMESTAMP")

LOW_COUNT_STATS = {
    "HR", "HOME_RUN", "HOME_RUNS", "TD", "TOUCHDOWN", "TOUCHDOWNS",
    "GOAL", "GOALS", "FIRST_TD", "ANYTIME_TD", "SACK", "SACKS",
    "INTERCEPTION", "INTERCEPTIONS", "STEAL", "STEALS", "BLOCK", "BLOCKS",
}


class PredictiveContractError(RuntimeError):
    pass


def _normalize(value: Any) -> str:
    return str(value or "").strip().upper().replace("-", "_").replace(" ", "_")


def _num(value: Any, default: float = math.nan) -> float:
    try:
        if value is None:
            return default
        if isinstance(value, str):
            value = value.replace("%", "").replace("$", "").replace(",", "").strip()
            if value.lower() in {"", "-", "nan", "none", "null"}:
                return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return _normalize(value) in {"1", "TRUE", "YES", "Y", "STALE", "SUSPENDED", "CLOSED"}


def _timestamp(value: Any) -> datetime | None:
    if value is None or str(value).strip() == "":
        return None
    text = str(value).strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _records(data: Any) -> list[dict[str, Any]]:
    if hasattr(data, "to_dict"):
        return [dict(x) for x in data.to_dict("records")]
    if isinstance(data, Mapping):
        return [dict(data)]
    return [dict(x) for x in data]


def _column_map(rows: Sequence[Mapping[str, Any]]) -> dict[str, str]:
    keys: set[str] = set()
    for row in rows:
        keys.update(map(str, row.keys()))
    return {_normalize(k): k for k in keys}


def _get(row: Mapping[str, Any], cmap: Mapping[str, str], aliases: Iterable[str], default: Any = None) -> Any:
    for alias in aliases:
        key = cmap.get(_normalize(alias))
        if key is not None:
            return row.get(key, default)
    return default


def stable_hash(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def american_implied_probability(odds: float) -> float:
    if not math.isfinite(odds):
        return math.nan
    # Decimal odds support for normalized feeds.
    if 1.0 < odds < 20.0:
        return 1.0 / odds
    if odds > 0:
        return 100.0 / (odds + 100.0)
    if odds < 0:
        return (-odds) / ((-odds) + 100.0)
    return math.nan


def _implied_array(values: np.ndarray) -> np.ndarray:
    out = np.full(values.shape, np.nan, dtype=np.float64)
    decimal = (values > 1.0) & (values < 20.0)
    pos = values >= 20.0
    neg = values < 0.0
    out[decimal] = 1.0 / values[decimal]
    out[pos] = 100.0 / (values[pos] + 100.0)
    out[neg] = (-values[neg]) / ((-values[neg]) + 100.0)
    return out


def _normal_cdf(z: np.ndarray) -> np.ndarray:
    # Fast deterministic approximation to Phi with max practical error well below
    # the decision margins used by this layer.
    z = np.asarray(z, dtype=np.float64)
    a = math.sqrt(2.0 / math.pi)
    return 0.5 * (1.0 + np.tanh(a * (z + 0.044715 * z * z * z)))


def _poisson_probabilities(mean: float, line: float) -> tuple[float, float, float]:
    if not (math.isfinite(mean) and mean >= 0.0 and math.isfinite(line)):
        return math.nan, math.nan, math.nan
    floor_line = math.floor(line)
    # P(X <= floor(line)) using stable recurrence. Player pools are small and
    # low-count Poisson markets are the only rows routed here.
    term = math.exp(-mean)
    cdf = term
    for k in range(1, max(0, floor_line) + 1):
        term *= mean / k
        cdf += term
    cdf = min(max(cdf, 0.0), 1.0)
    over = 1.0 - cdf
    if float(line).is_integer() and floor_line >= 0:
        push_term = math.exp(-mean)
        for k in range(1, floor_line + 1):
            push_term *= mean / k
        push = min(max(push_term, 0.0), 1.0)
        under = max(0.0, cdf - push)
    else:
        push = 0.0
        under = cdf
    return over, under, push


def _percentile(values: np.ndarray, valid: np.ndarray) -> np.ndarray:
    out = np.full(values.shape, 0.5, dtype=np.float64)
    idx = np.flatnonzero(valid & np.isfinite(values))
    if idx.size == 0:
        return out
    if idx.size == 1:
        out[idx] = 0.5
        return out
    order = idx[np.argsort(values[idx], kind="stable")]
    ranks = np.empty(order.size, dtype=np.float64)
    sorted_vals = values[order]
    i = 0
    while i < order.size:
        j = i + 1
        while j < order.size and sorted_vals[j] == sorted_vals[i]:
            j += 1
        ranks[i:j] = ((i + j - 1) / 2.0) / (order.size - 1)
        i = j
    out[order] = ranks
    return out


class PredictiveFeatures:
    __slots__ = (
        "decision_code", "model_over_probability", "market_over_probability",
        "edge", "edge_lower_bound", "edge_upper_bound", "confidence",
        "dfs_upside_score", "team_environment_score", "market_coverage_score",
        "market_movement_score", "market_disagreement_score",
        "player_market_available", "game_market_available", "stale_line",
        "tail_model_available", "prediction_frozen", "receipt",
    )

    def __init__(
        self,
        decision_code: np.ndarray,
        model_over_probability: np.ndarray,
        market_over_probability: np.ndarray,
        edge: np.ndarray,
        edge_lower_bound: np.ndarray,
        edge_upper_bound: np.ndarray,
        confidence: np.ndarray,
        dfs_upside_score: np.ndarray,
        team_environment_score: np.ndarray,
        market_coverage_score: np.ndarray,
        market_movement_score: np.ndarray,
        market_disagreement_score: np.ndarray,
        player_market_available: np.ndarray,
        game_market_available: np.ndarray,
        stale_line: np.ndarray,
        tail_model_available: np.ndarray,
        receipt: dict[str, Any],
    ) -> None:
        self.decision_code = decision_code
        self.model_over_probability = model_over_probability
        self.market_over_probability = market_over_probability
        self.edge = edge
        self.edge_lower_bound = edge_lower_bound
        self.edge_upper_bound = edge_upper_bound
        self.confidence = confidence
        self.dfs_upside_score = dfs_upside_score
        self.team_environment_score = team_environment_score
        self.market_coverage_score = market_coverage_score
        self.market_movement_score = market_movement_score
        self.market_disagreement_score = market_disagreement_score
        self.player_market_available = player_market_available
        self.game_market_available = game_market_available
        self.stale_line = stale_line
        self.tail_model_available = tail_model_available
        self.prediction_frozen = True
        self.receipt = receipt

def decision_labels(codes: np.ndarray) -> np.ndarray:
    codes = np.asarray(codes)
    return np.where(codes > 0, "MORE", np.where(codes < 0, "LESS", "PASS"))


def validate_predictive_adapter(
    available_fields: Iterable[str],
    *,
    executable_source_available: bool = True,
) -> dict[str, Any]:
    fields = {_normalize(x) for x in available_fields}
    forbidden = sorted(fields & FORBIDDEN_FORWARD_FIELDS)
    if forbidden:
        raise PredictiveContractError("RUN_INVALID:POSTLOCK_FIELDS_ENTERED_PREDICTIVE_LAYER:" + ",".join(forbidden))
    if not executable_source_available:
        raise PredictiveContractError("RUN_INVALID:PREDICTIVE_LAYER_EXECUTABLE_SOURCE_UNAVAILABLE")
    core = {"PLAYER", "SAL"}
    if not core.issubset(fields):
        raise PredictiveContractError("RUN_INVALID:PREDICTIVE_LAYER_CORE_FIELDS_MISSING:" + ",".join(sorted(core - fields)))
    return {
        "STATUS": "PASS",
        "PATCH_ID": PATCH_ID,
        "LOAD_ORDER": LOAD_ORDER,
        "AVAILABLE_FIELD_HASH": stable_hash(sorted(fields)),
        "POSTLOCK_RESULTS_USED": False,
        "RAW_AGGREGATE_PROJECTIONS_EXPORTED": False,
        "PREDICTIONS_MUTABLE_DOWNSTREAM": False,
        "FAIL_CLOSED_ON_CORRUPT_INPUT": True,
    }


def build_predictive_features(
    data: Any,
    *,
    sport: str,
    mode: str,
    min_edge: float = DEFAULT_MIN_EDGE,
    edge_z: float = DEFAULT_EDGE_Z,
    stale_minutes: float = DEFAULT_STALE_MINUTES,
    decision_threshold: float | None = None,
) -> PredictiveFeatures:
    """Build frozen prediction-first market features.

    ``decision_threshold`` is retained only for backward call compatibility and
    is intentionally ignored. Contract v1.1 prohibits a universal direction
    probability threshold; decisions are made from confidence-bounded,
    model-versus-no-vig market edge.
    """
    rows = _records(data)
    if not rows:
        raise PredictiveContractError("RUN_INVALID:PREDICTIVE_LAYER_EMPTY_POOL")
    cmap = _column_map(rows)
    adapter = validate_predictive_adapter(cmap.values())
    n = len(rows)

    def arr(aliases: Iterable[str]) -> np.ndarray:
        return np.asarray([_num(_get(r, cmap, aliases)) for r in rows], dtype=np.float64)

    line = arr(PLAYER_LINE_ALIASES)
    model_mean = arr(MODEL_MEAN_ALIASES)
    model_std = arr(MODEL_STD_ALIASES)
    explicit_over = arr(MODEL_OVER_PROB_ALIASES)
    explicit_over = np.where(explicit_over > 1.0, explicit_over / 100.0, explicit_over)
    model_prob_std = arr(MODEL_PROB_STD_ALIASES)
    model_prob_std = np.where(model_prob_std > 1.0, model_prob_std / 100.0, model_prob_std)
    calibration_error = arr(MODEL_CALIBRATION_ERROR_ALIASES)
    calibration_error = np.where(calibration_error > 1.0, calibration_error / 100.0, calibration_error)
    over_odds = arr(OVER_ODDS_ALIASES)
    under_odds = arr(UNDER_ODDS_ALIASES)
    open_line = arr(OPEN_LINE_ALIASES)
    moneyline = arr(MONEYLINE_ALIASES)
    opp_moneyline = arr(OPP_MONEYLINE_ALIASES)
    spread = arr(SPREAD_ALIASES)
    game_total = arr(TOTAL_ALIASES)
    team_total = arr(TEAM_TOTAL_ALIASES)
    consensus_over = arr(CONSENSUS_OVER_PROB_ALIASES)
    consensus_over = np.where(consensus_over > 1.0, consensus_over / 100.0, consensus_over)
    disagreement_input = arr(MARKET_DISAGREEMENT_ALIASES)
    disagreement_input = np.where(disagreement_input > 1.0, disagreement_input / 100.0, disagreement_input)
    book_count = arr(BOOK_COUNT_ALIASES)
    alt_line_count = arr(ALT_LINE_COUNT_ALIASES)
    snapshot_age = arr(SNAPSHOT_AGE_ALIASES)
    distributions = np.asarray([_normalize(_get(r, cmap, DISTRIBUTION_ALIASES, "")) for r in rows], dtype=object)
    stat_types = np.asarray([_normalize(_get(r, cmap, STAT_TYPE_ALIASES, "")) for r in rows], dtype=object)
    market_status = np.asarray([_normalize(_get(r, cmap, MARKET_STATUS_ALIASES, "")) for r in rows], dtype=object)
    source_status = np.asarray([_normalize(_get(r, cmap, PROJECTION_MARKET_STATUS_ALIASES, "UNKNOWN")) for r in rows], dtype=object)
    explicit_stale = np.asarray([_bool(_get(r, cmap, EXPLICIT_STALE_ALIASES, False)) for r in rows], dtype=bool)

    for row in rows:
        market_ts = _timestamp(_get(row, cmap, MARKET_TIMESTAMP_ALIASES))
        lock_ts = _timestamp(_get(row, cmap, LOCK_TIMESTAMP_ALIASES))
        if market_ts is not None and lock_ts is not None and market_ts > lock_ts:
            raise PredictiveContractError("RUN_INVALID:LOOKAHEAD_MARKET_SNAPSHOT_AFTER_LOCK")
    if np.any(np.isfinite(snapshot_age) & (snapshot_age < 0.0)):
        raise PredictiveContractError("RUN_INVALID:NEGATIVE_MARKET_SNAPSHOT_AGE_LOOKAHEAD_RISK")

    model_over = np.full(n, 0.5, dtype=np.float64)
    push_probability = np.zeros(n, dtype=np.float64)
    explicit_mask = np.isfinite(explicit_over) & (explicit_over >= 0.0) & (explicit_over <= 1.0)
    model_over[explicit_mask] = explicit_over[explicit_mask]

    mean_line_mask = np.isfinite(model_mean) & np.isfinite(line) & ~explicit_mask
    poisson_mask = mean_line_mask & (
        np.isin(distributions, ["POISSON", "COUNT", "DISCRETE_COUNT"])
        | np.isin(stat_types, list(LOW_COUNT_STATS))
        | ((line <= 3.5) & (model_mean <= 6.0) & (model_mean >= 0.0))
    )
    for i in np.flatnonzero(poisson_mask):
        over, under, push = _poisson_probabilities(float(model_mean[i]), float(line[i]))
        denom = over + under
        model_over[i] = over / denom if denom > 0 else 0.5
        push_probability[i] = push

    normal_mask = mean_line_mask & ~poisson_mask
    inferred_std = np.maximum.reduce((
        np.abs(model_mean) * 0.22,
        np.abs(line) * 0.18,
        np.ones(n, dtype=np.float64),
    ))
    sigma = np.where(np.isfinite(model_std) & (model_std > 0.0), model_std, inferred_std)
    z = np.divide(model_mean - line, sigma, out=np.zeros(n, dtype=np.float64), where=sigma > 0.0)
    model_over[normal_mask] = _normal_cdf(z[normal_mask])
    model_over = np.clip(model_over, 0.001, 0.999)

    over_implied = _implied_array(over_odds)
    under_implied = _implied_array(under_odds)
    pair = np.isfinite(over_implied) & np.isfinite(under_implied) & ((over_implied + under_implied) > 0.0)
    market_over = np.full(n, 0.5, dtype=np.float64)
    market_over[pair] = over_implied[pair] / (over_implied[pair] + under_implied[pair])
    only_over = np.isfinite(over_implied) & ~pair
    only_under = np.isfinite(under_implied) & ~pair
    market_over[only_over] = over_implied[only_over]
    market_over[only_under] = 1.0 - under_implied[only_under]
    consensus_mask = np.isfinite(consensus_over) & (consensus_over > 0.0) & (consensus_over < 1.0)
    market_over[consensus_mask] = consensus_over[consensus_mask]
    market_over = np.clip(market_over, 0.001, 0.999)

    player_model = np.isfinite(line) & (explicit_mask | np.isfinite(model_mean))
    player_market = np.isfinite(line) & (pair | only_over | only_under | consensus_mask)
    raw_edge = np.where(player_model & player_market, model_over - market_over, 0.0)

    independent = np.isin(source_status, ["MARKET_INDEPENDENT", "INDEPENDENT", "MODEL_ONLY", "RAW_MODEL"])
    partial = np.isin(source_status, ["PARTIALLY_MARKET_INFORMED", "PARTIAL", "PARTIAL_MARKET"])
    fully_market = np.isin(source_status, ["FULLY_MARKET_INFORMED", "MARKET_INFORMED", "MARKET_DERIVED", "FULL_MARKET"])
    unknown_source = ~(independent | partial | fully_market)
    shrink = np.where(independent, 1.0, np.where(partial, 0.5, 0.0))
    edge = raw_edge * shrink

    disagreement = np.where(
        np.isfinite(disagreement_input),
        np.clip(np.abs(disagreement_input), 0.0, 0.5),
        np.where(consensus_mask & pair, np.abs(market_over - (over_implied / np.maximum(over_implied + under_implied, 1e-12))), 0.0),
    )
    base_uncertainty = np.where(independent, 0.02, np.where(partial, 0.04, 0.08))
    model_uncertainty = np.where(np.isfinite(model_prob_std) & (model_prob_std > 0.0), model_prob_std, base_uncertainty)
    calibration_uncertainty = np.where(np.isfinite(calibration_error) & (calibration_error >= 0.0), calibration_error, 0.02)
    edge_uncertainty = np.sqrt(model_uncertainty ** 2 + calibration_uncertainty ** 2 + disagreement ** 2)
    edge_lower = edge - float(edge_z) * edge_uncertainty
    edge_upper = edge + float(edge_z) * edge_uncertainty

    suspended = np.isin(market_status, ["SUSPENDED", "CLOSED", "OFF_BOARD", "INACTIVE"])
    stale_line = explicit_stale | suspended | (np.isfinite(snapshot_age) & (snapshot_age > stale_minutes))
    fresh_age = np.isfinite(snapshot_age) & (snapshot_age >= 0.0) & (snapshot_age <= stale_minutes)
    market_coverage = (
        0.40 * pair.astype(float)
        + 0.15 * (np.isfinite(book_count) & (book_count >= 2.0)).astype(float)
        + 0.10 * np.isfinite(open_line).astype(float)
        + 0.15 * (np.isfinite(alt_line_count) & (alt_line_count >= 2.0)).astype(float)
        + 0.10 * fresh_age.astype(float)
        + 0.10 * consensus_mask.astype(float)
    )
    market_coverage = np.clip(market_coverage, 0.0, 1.0)
    actionable = player_model & pair & (market_coverage >= 0.40) & (independent | partial) & ~stale_line
    more = actionable & (edge_lower > min_edge)
    less = actionable & (edge_upper < -min_edge)
    decision = np.zeros(n, dtype=np.int8)
    decision[more] = 1
    decision[less] = -1

    team_ml_p = _implied_array(moneyline)
    opp_ml_p = _implied_array(opp_moneyline)
    ml_pair = np.isfinite(team_ml_p) & np.isfinite(opp_ml_p) & ((team_ml_p + opp_ml_p) > 0.0)
    win_probability = np.full(n, 0.5, dtype=np.float64)
    win_probability[ml_pair] = team_ml_p[ml_pair] / (team_ml_p[ml_pair] + opp_ml_p[ml_pair])
    ml_single = np.isfinite(team_ml_p) & ~ml_pair
    win_probability[ml_single] = team_ml_p[ml_single]
    spread_only = np.isfinite(spread) & ~(ml_pair | ml_single)
    win_probability[spread_only] = 1.0 / (1.0 + np.exp(np.clip(spread[spread_only] / 6.5, -20.0, 20.0)))

    derived_team_total = np.where(
        np.isfinite(team_total),
        team_total,
        np.where(np.isfinite(game_total) & np.isfinite(spread), game_total / 2.0 - spread / 2.0, np.nan),
    )
    game_market = np.isfinite(derived_team_total) | ml_pair | ml_single | np.isfinite(spread)
    total_rank = _percentile(derived_team_total, np.isfinite(derived_team_total))
    team_environment = np.where(game_market, np.clip(0.65 * total_rank + 0.35 * win_probability, 0.0, 1.0), 0.5)

    player_signal = np.where(player_model, model_over, 0.5)
    dfs_upside = np.where(
        player_model & game_market,
        0.75 * player_signal + 0.25 * team_environment,
        np.where(player_model, player_signal, np.where(game_market, team_environment, 0.5)),
    )
    dfs_upside = np.clip(dfs_upside, 0.0, 1.0)

    move_threshold = np.maximum(0.5, 0.04 * np.maximum(np.abs(line), 1.0))
    market_movement = np.divide(
        np.abs(line - open_line),
        move_threshold,
        out=np.zeros(n, dtype=np.float64),
        where=np.isfinite(open_line) & np.isfinite(line) & (move_threshold > 0.0),
    )
    market_movement = np.clip(market_movement, 0.0, 1.0)
    tail_model_available = (
        (np.isfinite(alt_line_count) & (alt_line_count >= 2.0))
        | np.isin(distributions, ["EMPIRICAL", "MIXTURE", "NEGATIVE_BINOMIAL", "LOGNORMAL", "SKEW_NORMAL"])
    )

    ci_separation = np.maximum(np.maximum(edge_lower - min_edge, -min_edge - edge_upper), 0.0)
    confidence = np.where(
        player_model & player_market,
        np.clip(0.55 * market_coverage + 0.35 * np.minimum(ci_separation / 0.10, 1.0) + 0.10 * independent.astype(float), 0.0, 1.0),
        np.where(game_market, 0.35, 0.0),
    )

    labels = decision_labels(decision)
    feature_payload = {
        "decision": labels.tolist(),
        "model_over_probability": np.round(model_over, 8).tolist(),
        "market_over_probability": np.round(market_over, 8).tolist(),
        "adjusted_edge": np.round(edge, 8).tolist(),
        "edge_lower_bound": np.round(edge_lower, 8).tolist(),
        "edge_upper_bound": np.round(edge_upper, 8).tolist(),
        "confidence": np.round(confidence, 8).tolist(),
        "dfs_upside_score": np.round(dfs_upside, 8).tolist(),
        "team_environment_score": np.round(team_environment, 8).tolist(),
        "market_coverage_score": np.round(market_coverage, 8).tolist(),
        "market_movement_score": np.round(market_movement, 8).tolist(),
        "market_disagreement_score": np.round(disagreement, 8).tolist(),
        "player_market_available": player_market.astype(int).tolist(),
        "game_market_available": game_market.astype(int).tolist(),
        "stale_line": stale_line.astype(int).tolist(),
        "tail_model_available": tail_model_available.astype(int).tolist(),
        "projection_source_status": source_status.tolist(),
        "push_probability": np.round(push_probability, 8).tolist(),
    }
    prediction_hash = stable_hash(feature_payload)
    pair_count = int(pair.sum())
    actionable_count = int(actionable.sum())
    receipt = {
        **adapter,
        "CONTRACT_VERSION": CONTRACT_VERSION,
        "SPORT": _normalize(sport),
        "MODE": _normalize(mode),
        "AI_ROLE": "PREDICTION_FIRST",
        "STRATEGIST_ROLE": "CONSUMER_ONLY_AFTER_PREDICTION_FREEZE",
        "UNIVERSAL_DIRECTION_THRESHOLD_USED": False,
        "LEGACY_DIRECTION_THRESHOLD_ARGUMENT_IGNORED": decision_threshold is not None,
        "REQUIRED_EDGE": float(min_edge),
        "EDGE_CONFIDENCE_Z": float(edge_z),
        "ROW_COUNT": n,
        "PLAYER_MARKET_ROWS": int(player_market.sum()),
        "TWO_SIDED_NO_VIG_ROWS": pair_count,
        "ACTIONABLE_PLAYER_MARKET_ROWS": actionable_count,
        "GAME_MARKET_ROWS": int(game_market.sum()),
        "MORE_DECISIONS": int((decision > 0).sum()),
        "LESS_DECISIONS": int((decision < 0).sum()),
        "PASS_DECISIONS": int((decision == 0).sum()),
        "STALE_LINE_SIGNALS": int(stale_line.sum()),
        "MARKET_MOVEMENT_ROWS": int((market_movement > 0.0).sum()),
        "TAIL_MODEL_ROWS": int(tail_model_available.sum()),
        "ALT_LINE_COVERAGE": int((np.isfinite(alt_line_count) & (alt_line_count >= 2.0)).sum()),
        "INDEPENDENT_PROJECTION_ROWS": int(independent.sum()),
        "PARTIAL_MARKET_INFORMED_ROWS": int(partial.sum()),
        "FULLY_MARKET_INFORMED_ROWS": int(fully_market.sum()),
        "UNKNOWN_PROJECTION_SOURCE_ROWS": int(unknown_source.sum()),
        "NO_VIG_CONVERSION_CHECK": "PASS" if pair_count else "PASS_NO_TWO_SIDED_ROWS",
        "CONSENSUS_MARKET_CHECK": "PASS" if int(consensus_mask.sum()) else "PASS_NO_CONSENSUS_ROWS",
        "LINE_MOVEMENT_HISTORY_CHECK": "PASS" if int(np.isfinite(open_line).sum()) else "PASS_NO_HISTORY_ROWS",
        "LOOKAHEAD_LEAKAGE_CHECK": "PASS",
        "SOURCE_MARKET_CONTAMINATION_CHECK": "PASS_ACTIONABLE_ROWS_CLASSIFIED" if actionable_count else "PASS_NO_UNCONTROLLED_EDGE_DECISIONS",
        "HEAVY_JUICE_TREATED_AS_CEILING": False,
        "AUTOMATIC_SHARP_MONEY_LABEL_USED": False,
        "ARBITRARY_FAT_TAIL_INJECTION_USED": False,
        "OWNERSHIP_USED_IN_PERFORMANCE_MODEL": False,
        "SPREAD_TOTAL_ONLY_MODE": "DEGRADED_FALLBACK",
        "MONTE_CARLO_MARKET_PARITY_CHECK": "CONTRACT_REQUIRED_AT_SIMULATION_STAGE",
        "PREDICTION_FROZEN": True,
        "PREDICTION_HASH": prediction_hash,
        "RAW_MARKET_INPUT_HASH": stable_hash({
            "line": np.where(np.isfinite(line), np.round(line, 8), None).tolist(),
            "open_line": np.where(np.isfinite(open_line), np.round(open_line, 8), None).tolist(),
            "over_odds": np.where(np.isfinite(over_odds), np.round(over_odds, 8), None).tolist(),
            "under_odds": np.where(np.isfinite(under_odds), np.round(under_odds, 8), None).tolist(),
            "moneyline": np.where(np.isfinite(moneyline), np.round(moneyline, 8), None).tolist(),
            "spread": np.where(np.isfinite(spread), np.round(spread, 8), None).tolist(),
            "total": np.where(np.isfinite(game_total), np.round(game_total, 8), None).tolist(),
            "team_total": np.where(np.isfinite(team_total), np.round(team_total, 8), None).tolist(),
            "source_status": source_status.tolist(),
            "snapshot_age": np.where(np.isfinite(snapshot_age), np.round(snapshot_age, 8), None).tolist(),
        }),
    }
    receipt["CONTRACT_HASH"] = stable_hash(receipt)
    return PredictiveFeatures(
        decision,
        model_over.astype(np.float32),
        market_over.astype(np.float32),
        edge.astype(np.float32),
        edge_lower.astype(np.float32),
        edge_upper.astype(np.float32),
        confidence.astype(np.float32),
        dfs_upside.astype(np.float32),
        team_environment.astype(np.float32),
        market_coverage.astype(np.float32),
        market_movement.astype(np.float32),
        disagreement.astype(np.float32),
        player_market,
        game_market,
        stale_line,
        tail_model_available,
        receipt,
    )

