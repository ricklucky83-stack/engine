from __future__ import annotations

"""Terminal-only AI Hybrid selection boundary.

The engine owns candidate birth, legality, calibration, simulation, ownership,
field construction, handoff and metric computation.  AI authority begins only
after the selector-reviewed candidate matrix has been frozen.  The AI may select
existing lineup IDs and attach bounded reason codes.  It cannot create lineups,
change metrics, recompute simulations, or use post-lock outcomes.
"""

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
import csv, json, math

PATCH_ID = "APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v2"
SELECTOR_MODE = "CODE_AI_HYBRID_TERMINAL_ONLY"
TOP5_POLICY_ID = "APEX_GLOBAL_TOP5_HIGH_CONFIDENCE_PARLAY_v1"
BOARD_SIZE = 5

FORBIDDEN_POSTLOCK_FIELDS = frozenset({
    "CONTEST_RANK","ACTUAL_FPTS","REALIZED_FPTS","POSTLOCK_SCORE","REALIZED_SCORE",
    "ACTUAL_SCORE","ACTUAL_RANK","FINAL_CONTEST_RANK","WINNING_LINEUP","TARGET_ACTUAL_SCORE",
})

ALLOWED_REASON_CODES = frozenset({
    # Existing authority vocabulary
    "ELITE_WIN_PATH","ELITE_TOP_0_1_PATH","ELITE_TOP_1_PATH","P99_TAIL","CVAR99_TAIL","P95_TAIL",
    "CORRELATION_PATH","LEVERAGE_PATH","LOW_DUPLICATION_PATH","SALARY_GEOMETRY_PATH",
    "STRUCTURE_DIVERSIFICATION","PORTFOLIO_MARGINAL_VALUE",
    # v2 terminal intelligence vocabulary
    "CHAMPIONSHIP_UNION_COVERAGE","TOP01_UNION_COVERAGE","TOP1_UNION_COVERAGE",
    "UNCERTAINTY_STABILITY","CROSS_SEED_STABILITY","REGIME_COVERAGE","COUNTER_SCRIPT_COVERAGE",
    "FIELD_MODEL_RELIABILITY","CURRENT_SELECTOR_SUPPORT","CURRENT_SELECTOR_DISAGREEMENT",
    "TAIL_ASYMMETRY","PARETO_FRONTIER","DUPLICATION_ADJUSTED_UPSIDE","FAMILY_CHAMPIONSHIP_MASS",
    "SIBLING_RECALL","DOMINANT_FAMILY_EVIDENCE",
})

FEATURE_REGISTRY = {
    "PRIMARY_TAIL": ["MC_WIN_RATE","MC_WIN_LCB","MC_TOP_0_1_RATE","MC_TOP_0_1_LCB","MC_TOP_1_RATE","MC_TOP_1_LCB"],
    "TAIL_SHAPE": ["MC_P95","MC_P99","MC_CVAR99","TAIL_ASYMMETRY","MC_MEAN"],
    "UNCERTAINTY": ["MC_TRIALS","RANK_STABILITY","CROSS_SEED_STABILITY","CALIBRATION_STABILITY"],
    "FIELD_RELATIVE": ["PROJECTED_EXACT_MATCH_DUPLICATION","P_UNIQUE","OWNERSHIP_PRODUCT","FIELD_MODEL_RELIABILITY"],
    "FAMILY": ["FAMILY_MC_WIN_RATE","FAMILY_MC_TOP_0_1_RATE","FAMILY_MC_TOP1_RATE","FAMILY_CHAMPIONSHIP_MASS","WINNING_SIBLING_COUNT"],
    "PORTFOLIO": ["COMMON_WORLD_WIN_BITS","COMMON_WORLD_TOP01_BITS","COMMON_WORLD_TOP1_BITS","PAIRWISE_OUTCOME_CORRELATION","LINEUP_OVERLAP"],
    "STRUCTURE": ["BRANCH","ROUTE","CPT_ROLE","SP_COUNT","RP_COUNT","SALARY","SALARY_GEOMETRY","SCENARIO_ID"],
    "CODE_COMPARATOR": ["CURRENT_SELECTOR_SELECTED","CURRENT_SELECTOR_RANK","CURRENT_SELECTOR_SCORE","GLOBAL_CORE_PROTECTED","GLOBAL_CORE_PRIORITY"],
    "MODEL_GOVERNANCE": ["FIELD_MODEL_SOURCE","FIELD_MODEL_RELIABILITY","OWNERSHIP_AUTHORITY","MARKET_MODEL_DIVERGENCE"],
}

class TerminalAIHybridError(RuntimeError):
    pass


def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")


def _canonical_json(obj: object) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _lineup_id(row: Mapping[str, Any]) -> str:
    for k in ("LINEUP_ID","LINEUP_INDEX","ID"):
        v=row.get(k)
        if v not in (None, ""):
            return str(v)
    raise TerminalAIHybridError("RUN_INVALID:AI_CANDIDATE_MISSING_LINEUP_ID")


def _players(row: Mapping[str, Any]) -> tuple[str, ...]:
    vals=[]
    for k in ("CPT","CAPTAIN","MVP"):
        if row.get(k) not in (None,""):
            vals.append(str(row[k]).strip()); break
    util_keys=[k for k in row if _norm(k).startswith("UTIL") and _norm(k) not in {"UTILS"}]
    for k in sorted(util_keys, key=lambda x: (_norm(x) != "UTIL", _norm(x))):
        if row.get(k) not in (None,""):
            vals.append(str(row[k]).strip())
    if len(vals) <= 1 and row.get("UTILS") not in (None,""):
        text=str(row["UTILS"])
        sep="|" if "|" in text else ";" if ";" in text else ","
        vals += [x.strip() for x in text.split(sep) if x.strip()]
    return tuple(vals)


def validate_candidate_rows(rows: Sequence[Mapping[str, Any]]) -> None:
    if not rows:
        raise TerminalAIHybridError("RUN_INVALID:AI_TERMINAL_EMPTY_CANDIDATES")
    forbidden=sorted({_norm(k) for r in rows for k in r} & FORBIDDEN_POSTLOCK_FIELDS)
    if forbidden:
        raise TerminalAIHybridError("RUN_INVALID:POSTLOCK_FIELDS_ENTERED_AI_TERMINAL:"+",".join(forbidden))
    seen=set()
    for r in rows:
        lid=_lineup_id(r)
        if lid in seen:
            raise TerminalAIHybridError(f"RUN_INVALID:DUPLICATE_AI_LINEUP_ID:{lid}")
        seen.add(lid)
        p=_players(r)
        if p and len(p)!=len({x.casefold() for x in p}):
            raise TerminalAIHybridError(f"RUN_INVALID:DUPLICATE_PLAYER_IN_AI_CANDIDATE:{lid}")


def freeze_candidates(rows: Sequence[Mapping[str, Any]]) -> str:
    validate_candidate_rows(rows)
    ordered=sorted((dict(r) for r in rows), key=lambda r:_lineup_id(r))
    return sha256(_canonical_json(ordered)).hexdigest()


def feature_availability(rows: Sequence[Mapping[str, Any]]) -> dict[str, dict[str, int]]:
    cols={_norm(k) for r in rows for k in r}
    out={}
    for group,names in FEATURE_REGISTRY.items():
        present=[n for n in names if _norm(n) in cols]
        out[group]={"AVAILABLE":len(present),"DEFINED":len(names),"MISSING":len(names)-len(present)}
    return out


def _float(row: Mapping[str, Any], name: str, default: float=float("nan")) -> float:
    cmap={_norm(k):k for k in row}
    k=cmap.get(_norm(name))
    if k is None: return default
    try:
        v=float(str(row.get(k,"")).replace("%","").replace(",","").strip())
        return v if math.isfinite(v) else default
    except Exception:
        return default


def _prob_value(row: Mapping[str, Any], name: str) -> float:
    cmap={_norm(k):k for k in row}; k=cmap.get(_norm(name))
    if k is None: return float("nan")
    raw=row.get(k)
    try: v=float(str(raw).replace("%","").strip())
    except Exception: return float("nan")
    if not math.isfinite(v) or v < 0: return float("nan")
    if isinstance(raw,str) and "%" in raw: return min(1.0,v/100.0)
    if v <= 1.0000001: return v
    if v <= 100.0000001: return v/100.0
    return float("nan")


def _pct(values: Sequence[float], higher: bool=True) -> list[float]:
    vals=[float(v) if math.isfinite(float(v)) else float("nan") for v in values]
    valid=sorted(set(v for v in vals if math.isfinite(v)))
    if not valid: return [float("nan")]*len(vals)
    if len(valid)==1: return [0.5 if math.isfinite(v) else float("nan") for v in vals]
    rank={v:i/(len(valid)-1) for i,v in enumerate(valid)}
    return [(rank[v] if higher else 1.0-rank[v]) if math.isfinite(v) else float("nan") for v in vals]


def enrich_ai_evidence(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Add transparent derived evidence; never overwrite engine-owned metrics."""
    out=[dict(r) for r in rows]
    win=[_prob_value(r,"MC_WIN_RATE") for r in out]
    win_l=[_prob_value(r,"MC_WIN_LCB") for r in out]
    t01=[_prob_value(r,"MC_TOP_0_1_RATE") for r in out]
    t01_l=[_prob_value(r,"MC_TOP_0_1_LCB") for r in out]
    p99=[_float(r,"MC_P99") for r in out]
    p95=[_float(r,"MC_P95") for r in out]
    dup=[_float(r,"PROJECTED_EXACT_MATCH_DUPLICATION") for r in out]
    code=[_float(r,"CURRENT_SELECTOR_PRE_SCORE") for r in out]
    winp=_pct(win_l); t01p=_pct(t01_l); p99p=_pct(p99); dupp=_pct(dup,higher=False); codep=_pct(code)
    for i,r in enumerate(out):
        if math.isfinite(win[i]) and math.isfinite(win_l[i]): r["AI_WIN_UNCERTAINTY_GAP"]=max(0.0,win[i]-win_l[i])
        if math.isfinite(t01[i]) and math.isfinite(t01_l[i]): r["AI_TOP01_UNCERTAINTY_GAP"]=max(0.0,t01[i]-t01_l[i])
        if math.isfinite(p99[i]) and math.isfinite(p95[i]):
            r["AI_TAIL_SPREAD_P99_P95"]=p99[i]-p95[i]
            r["AI_TAIL_ASYMMETRY"]=(p99[i]-p95[i])/max(1e-9,abs(p95[i]))
        if math.isfinite(dup[i]) and dup[i] >= 0:
            if math.isfinite(win[i]): r["AI_DUP_ADJ_WIN"]=win[i]/(1.0+dup[i])
            if math.isfinite(t01[i]): r["AI_DUP_ADJ_TOP01"]=t01[i]/(1.0+dup[i])
        if math.isfinite(winp[i]): r["AI_WIN_LCB_PCTL"]=winp[i]
        if math.isfinite(t01p[i]): r["AI_TOP01_LCB_PCTL"]=t01p[i]
        if math.isfinite(p99p[i]): r["AI_P99_PCTL"]=p99p[i]
        if math.isfinite(dupp[i]): r["AI_LOW_DUP_PCTL"]=dupp[i]
        if math.isfinite(codep[i]): r["AI_CURRENT_SELECTOR_SCORE_PCTL"]=codep[i]
        support=[x for x in (winp[i],t01p[i],p99p[i],dupp[i]) if math.isfinite(x)]
        if support:
            r["AI_ELITE_SUPPORT_BREADTH"]=sum(x>=0.90 for x in support)
            r["AI_ROBUST_TAIL_FLOOR_PCTL"]=min(support[:3]) if len(support)>=3 else min(support)
        if math.isfinite(t01p[i]) and math.isfinite(codep[i]):
            r["AI_TOP01_VS_CODE_DISAGREEMENT"]=t01p[i]-codep[i]
    return out


def write_review_surface(rows: Sequence[Mapping[str, Any]], *, csv_path: str|Path, receipt_path: str|Path,
                         sport: str, mode: str, execution_id: str, context: Mapping[str,Any]|None=None) -> dict[str,Any]:
    rows=enrich_ai_evidence([dict(r) for r in rows])
    validate_candidate_rows(rows)
    csv_path=Path(csv_path); receipt_path=Path(receipt_path)
    csv_path.parent.mkdir(parents=True,exist_ok=True)
    fields=[]; seen=set()
    for r in rows:
        for k in r:
            if k not in seen: fields.append(k); seen.add(k)
    with csv_path.open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore"); w.writeheader(); w.writerows(rows)
    # Freeze the exact semantic surface the AI will reload. CSV serialization
    # normalizes bool/int/float cells to text, so hash after round-trip.
    frozen_rows=load_candidate_csv(csv_path)
    freeze=freeze_candidates(frozen_rows)
    context=dict(context or {})
    receipt={
        "PATCH_ID":PATCH_ID,"SELECTOR_MODE":SELECTOR_MODE,"SPORT":str(sport).upper(),"MODE":str(mode).upper(),
        "EXECUTION_ID":str(execution_id),"CANDIDATE_COUNT":len(frozen_rows),"CANDIDATE_FREEZE_SHA256":freeze,
        "CANDIDATE_SURFACE_PATH":str(csv_path),"CANDIDATE_SURFACE_SHA256":sha256(csv_path.read_bytes()).hexdigest(),
        "TOP5_POLICY_ID":TOP5_POLICY_ID,"FINAL_BOARD_SIZE":BOARD_SIZE,
        "AI_AUTHORITY":"RANK_SORT_COMPARE_TIEBREAK_PORTFOLIO_SELECT_ONLY",
        "AI_MAY_CREATE_LINEUPS":False,"AI_MAY_MUTATE_METRICS":False,"AI_MAY_RECALIBRATE":False,
        "AI_MAY_USE_POSTLOCK_RESULTS":False,"CODE_SELECTOR_ROLE":"ADVISORY_COMPARATOR_ONLY_WHEN_AI_AUTHORITY_ENABLED",
        "FEATURE_AVAILABILITY":feature_availability(frozen_rows),"FEATURE_REGISTRY":FEATURE_REGISTRY,
        "ALLOWED_REASON_CODES":sorted(ALLOWED_REASON_CODES),"CONTEXT":context,
    }
    receipt_path.write_text(json.dumps(receipt,indent=2,sort_keys=True),encoding="utf-8")
    receipt["RECEIPT_PATH"]=str(receipt_path)
    receipt["RECEIPT_SHA256"]=sha256(receipt_path.read_bytes()).hexdigest()
    return receipt


def load_candidate_csv(path: str|Path) -> list[dict[str,Any]]:
    with Path(path).open("r",encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))


def load_decision(path: str|Path) -> dict[str,Any]:
    obj=json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(obj,dict): raise TerminalAIHybridError("RUN_INVALID:AI_DECISION_NOT_OBJECT")
    return obj


def _overlap(a: Sequence[str], b: Sequence[str]) -> float:
    sa={str(x).casefold() for x in a if str(x).strip()}; sb={str(x).casefold() for x in b if str(x).strip()}
    return len(sa&sb)/max(1,min(len(sa),len(sb)))


def validate_ai_decision(rows: Sequence[Mapping[str,Any]], decision: Mapping[str,Any], *, expected_freeze_hash: str|None=None,
                         board_size: int=BOARD_SIZE) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    rows=[dict(r) for r in rows]
    freeze=freeze_candidates(rows)
    if expected_freeze_hash and freeze != str(expected_freeze_hash):
        raise TerminalAIHybridError("RUN_INVALID:AI_FROZEN_MATRIX_HASH_MISMATCH")
    if decision.get("candidate_freeze_sha256") not in (None,"",freeze):
        raise TerminalAIHybridError("RUN_INVALID:AI_DECISION_HASH_MISMATCH")
    picks=decision.get("selections")
    if not isinstance(picks,list) or len(picks)!=int(board_size):
        raise TerminalAIHybridError(f"RUN_INVALID:AI_BOARD_SIZE_MISMATCH:{0 if not isinstance(picks,list) else len(picks)}:{board_size}")
    by_id={_lineup_id(r):r for r in rows}
    out=[]; ids=[]; all_reasons=[]
    for rank,p in enumerate(picks,1):
        if not isinstance(p,dict): raise TerminalAIHybridError("RUN_INVALID:AI_SELECTION_NOT_OBJECT")
        lid=str(p.get("lineup_id",p.get("LINEUP_ID",p.get("LINEUP_INDEX",""))))
        if lid not in by_id: raise TerminalAIHybridError(f"RUN_INVALID:AI_CREATED_UNSEEN_LINEUP:{lid}")
        if lid in ids: raise TerminalAIHybridError(f"RUN_INVALID:AI_DUPLICATE_LINEUP:{lid}")
        reasons=tuple(str(x) for x in (p.get("reason_codes") or []))
        if not reasons: raise TerminalAIHybridError(f"RUN_INVALID:AI_MISSING_REASON_CODES:{lid}")
        bad=sorted(set(reasons)-ALLOWED_REASON_CODES)
        if bad: raise TerminalAIHybridError(f"RUN_INVALID:AI_INVALID_REASON_CODES:{lid}:{','.join(bad)}")
        r=dict(by_id[lid]); r["AI_TERMINAL_RANK"]=rank; r["AI_REASON_CODES"]="|".join(reasons)
        out.append(r); ids.append(lid); all_reasons.extend(reasons)
    player_sets=[_players(r) for r in out]
    if len({tuple(sorted(x.casefold() for x in p)) for p in player_sets}) != len(out):
        raise TerminalAIHybridError("RUN_INVALID:AI_FINAL_EXACT_DUPLICATE_LINEUP")
    # Top-5 is a coordinated portfolio, not five independent ranks. Require the
    # decision to explicitly account for marginal portfolio value/diversification.
    portfolio_codes={"PORTFOLIO_MARGINAL_VALUE","CHAMPIONSHIP_UNION_COVERAGE","TOP01_UNION_COVERAGE","REGIME_COVERAGE","COUNTER_SCRIPT_COVERAGE","STRUCTURE_DIVERSIFICATION","DOMINANT_FAMILY_EVIDENCE"}
    if not (set(all_reasons)&portfolio_codes):
        raise TerminalAIHybridError("RUN_INVALID:AI_TOP5_PARLAY_PORTFOLIO_REASON_MISSING")
    overlaps=[]
    for i in range(len(out)):
        for j in range(i+1,len(out)):
            overlaps.append(_overlap(player_sets[i],player_sets[j]))
    receipt={
        "PATCH_ID":PATCH_ID,"STATUS":"PASS","CANDIDATE_FREEZE_SHA256":freeze,"FINAL_BOARD_SIZE":len(out),
        "SELECTED_LINEUP_IDS":ids,"TOP5_POLICY_ID":TOP5_POLICY_ID,"TOP5_PARLAY_VALIDATED":True,
        "MAX_PAIRWISE_PLAYER_OVERLAP":max(overlaps) if overlaps else 0.0,"AVG_PAIRWISE_PLAYER_OVERLAP":sum(overlaps)/len(overlaps) if overlaps else 0.0,
        "AI_CREATED_LINEUPS":False,"AI_MUTATED_METRICS":False,"POSTLOCK_RESULTS_USED":False,
        "CODE_SELECTOR_TERMINAL_AUTHORITY":False,"AI_TERMINAL_AUTHORITY":True,
    }
    return out,receipt
