from __future__ import annotations
import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Mapping, Sequence

PATCH_ID = "APEX_GLOBAL_DIAGNOSTIC_NO_LOST_REPAIR_AND_POINTER_EPOCH_FENCE_v3"
TERMINAL_ACCOUNTED_STATUSES = {"SUPERSEDED", "REJECTED"}
PROMOTABLE_STATUSES = {"VALIDATED", "QUEUED", "MERGE_READY", "ACTIVE", "MERGED"}
STATUS_PRECEDENCE = {"VALIDATED":10,"QUEUED":20,"MERGE_READY":30,"ACTIVE":40,"MERGED":40,"SUPERSEDED":50,"REJECTED":50}
class DiagnosticLedgerError(RuntimeError): pass

def _canonical_json(obj: Mapping) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",",":"), ensure_ascii=False).encode("utf-8")
def sha256_bytes(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def make_patch_id(*, sport: str, mode: str, slate_id: str, patch_hash: str) -> str:
    payload={"SPORT":sport.upper(),"MODE":mode.upper(),"SLATE_ID":str(slate_id),"PATCH_HASH":str(patch_hash)}
    return f"DIAG_{payload['SPORT']}_{payload['MODE']}_{payload['SLATE_ID']}_{sha256_bytes(_canonical_json(payload))[:20]}"
def _validate_terminal(status, superseded_by, reason, promoted_state_version, implementation_patch_ids):
    if status=="SUPERSEDED" and not superseded_by: raise DiagnosticLedgerError("SUPERSEDED_PATCH_REQUIRES_SUCCESSOR_PATCH_ID")
    if status=="REJECTED" and not reason: raise DiagnosticLedgerError("REJECTED_PATCH_REQUIRES_REASON")
    if status in {"ACTIVE","MERGED"}:
        if not promoted_state_version: raise DiagnosticLedgerError("MERGED_PATCH_REQUIRES_PROMOTED_STATE_VERSION")
        if not implementation_patch_ids: raise DiagnosticLedgerError("ACTIVE_PATCH_REQUIRES_IMPLEMENTATION_PATCH_IDS")
def build_receipt(*, patch_id: str, base_state_version: str, sport: str, mode: str, slate_id: str,
                  changed_components: Sequence[str], patch_hash: str, status: str="VALIDATED",
                  dependencies: Sequence[str]=(), conflict_keys: Sequence[str]=(), supersedes: Sequence[str]=(),
                  superseded_by: str|None=None, reason: str|None=None, promoted_state_version: str|None=None,
                  implementation_patch_ids: Sequence[str]=(), event_at_utc: str|None=None) -> dict:
    status=str(status).upper()
    if status not in STATUS_PRECEDENCE: raise DiagnosticLedgerError(f"INVALID_DIAGNOSTIC_STATUS:{status}")
    impl=sorted(set(map(str,implementation_patch_ids)))
    _validate_terminal(status,superseded_by,reason,promoted_state_version,impl)
    r={"SCHEMA":PATCH_ID,"PATCH_ID":str(patch_id),"BASE_STATE_VERSION":str(base_state_version),"SPORT":str(sport).upper(),
       "MODE":str(mode).upper(),"SLATE_ID":str(slate_id),"CHANGED_COMPONENTS":sorted(set(map(str,changed_components))),
       "PATCH_HASH":str(patch_hash),"DEPENDENCIES":sorted(set(map(str,dependencies))),"CONFLICT_KEYS":sorted(set(map(str,conflict_keys))),
       "SUPERSEDES":sorted(set(map(str,supersedes))),"SUPERSEDED_BY":str(superseded_by) if superseded_by else None,
       "REASON":str(reason) if reason else None,"PROMOTED_STATE_VERSION":str(promoted_state_version) if promoted_state_version else None,
       "IMPLEMENTATION_PATCH_IDS":impl,"EVENT_AT_UTC":event_at_utc or datetime.now(timezone.utc).isoformat(),"STATUS":status}
    r["RECEIPT_SHA256"]=sha256_bytes(_canonical_json(r)); return r
def persist_immutable_receipt(queue_dir: str|Path, receipt: Mapping) -> Path:
    root=Path(queue_dir); root.mkdir(parents=True,exist_ok=True); pid=str(receipt.get("PATCH_ID") or ""); rh=str(receipt.get("RECEIPT_SHA256") or "")
    if not pid or not rh: raise DiagnosticLedgerError("INVALID_DIAGNOSTIC_RECEIPT")
    p=root/f"{pid}.{receipt.get('STATUS','EVENT')}.{rh[:16]}.json"; data=json.dumps(dict(receipt),sort_keys=True,indent=2).encode()+b"\n"
    try: fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644)
    except FileExistsError:
        if p.read_bytes()!=data: raise DiagnosticLedgerError(f"IMMUTABLE_RECEIPT_COLLISION:{p.name}")
        return p
    with os.fdopen(fd,"wb") as f: f.write(data); f.flush(); os.fsync(f.fileno())
    return p
def load_receipts(queue_dir: str|Path) -> list[dict]:
    out=[]; root=Path(queue_dir)
    if not root.exists(): return out
    for p in sorted(root.glob("*.json")):
        obj=json.loads(p.read_text()); expected=obj.get("RECEIPT_SHA256"); chk=dict(obj); chk.pop("RECEIPT_SHA256",None)
        if expected!=sha256_bytes(_canonical_json(chk)): raise DiagnosticLedgerError(f"QUEUE_RECEIPT_HASH_MISMATCH:{p.name}")
        out.append(obj)
    return out
def queue_snapshot(receipts: Iterable[Mapping]) -> dict:
    rows=sorted((str(r.get("PATCH_ID")),str(r.get("RECEIPT_SHA256")),str(r.get("STATUS"))) for r in receipts)
    return {"QUEUE_COUNT":len(rows),"QUEUE_SNAPSHOT_SHA256":sha256_bytes(_canonical_json({"ROWS":rows})),"ROWS":rows}
def _event_key(r): return (str(r.get("EVENT_AT_UTC") or ""), STATUS_PRECEDENCE.get(str(r.get("STATUS") or "").upper(),0), str(r.get("RECEIPT_SHA256") or ""))
def _latest(rows,statuses):
    xs=[r for r in rows if str(r.get("STATUS") or "").upper() in statuses]
    return max(xs,key=_event_key) if xs else None
def build_promotion_set(receipts: Iterable[Mapping], active_patch_ids: Iterable[str], active_state_version: str|None=None) -> dict:
    rows=list(receipts); active=set(map(str,active_patch_ids)); by={}
    for r in rows: by.setdefault(str(r.get("PATCH_ID")),[]).append(r)
    promotion=[]; already=set(); terminal=set(); states={}; stale=[]
    for pid,events in sorted(by.items()):
        # Explicit supersession/rejection is authoritative when the diagnostic is not represented by current implementation patches.
        term=_latest(events,TERMINAL_ACCOUNTED_STATUSES)
        actives=sorted([r for r in events if str(r.get("STATUS") or "").upper() in {"ACTIVE","MERGED"}],key=_event_key,reverse=True)
        current_hit=False
        for r in actives:
            impl=set(map(str,r.get("IMPLEMENTATION_PATCH_IDS") or ()))
            schema=str(r.get("SCHEMA") or "")
            promoted=str(r.get("PROMOTED_STATE_VERSION") or "")
            if impl and impl.issubset(active): current_hit=True; break
            if schema.endswith("_v1") and not impl: current_hit=True; break  # read-only legacy grandfather
            if promoted and active_state_version and promoted==str(active_state_version): current_hit=True; break
        if current_hit:
            already.add(pid); states[pid]="ACTIVE_CURRENT"; continue
        if term is not None:
            terminal.add(pid); states[pid]=str(term.get("STATUS")).upper(); continue
        cand=_latest(events,PROMOTABLE_STATUSES)
        if cand is None: raise DiagnosticLedgerError(f"UNACCOUNTED_VALIDATED_PATCHES:{pid}")
        if str(cand.get("STATUS")).upper() in {"ACTIVE","MERGED"}: stale.append(pid); states[pid]="STALE_ACTIVE_REQUEUED"
        else: states[pid]=str(cand.get("STATUS")).upper()
        promotion.append(cand)
    pids=sorted(str(r["PATCH_ID"]) for r in promotion)
    accounted=already|terminal|set(pids); un=sorted(set(by)-accounted)
    if un: raise DiagnosticLedgerError("UNACCOUNTED_VALIDATED_PATCHES:"+",".join(un))
    return {"VALIDATED_DIAGNOSTICS_TOTAL":len(by),"PROMOTION_PATCH_IDS":pids,"PROMOTION_SET":promotion,"ALREADY_ACTIVE":sorted(already),
            "TERMINAL_ACCOUNTED":sorted(terminal),"STALE_ACTIVE_REQUEUED":sorted(stale),"PATCH_STATE":states,"UNACCOUNTED":[],"UNACCOUNTED_VALIDATED_PATCHES":0}
def require_promotion_coverage(plan: Mapping, merged_patch_ids: Iterable[str]) -> dict:
    req=set(map(str,plan.get("PROMOTION_PATCH_IDS") or ())); merged=set(map(str,merged_patch_ids or ())); missing=sorted(req-merged)
    if missing: raise DiagnosticLedgerError("VALIDATED_PATCHES_NOT_IMPLEMENTED:"+",".join(missing))
    return {"PROMOTION_REQUIRED_PATCHES":sorted(req),"PROMOTION_IMPLEMENTED_PATCHES":sorted(req&merged),"UNIMPLEMENTED_VALIDATED_PATCHES":0}
def detect_patch_conflicts(promotion_set: Sequence[Mapping]) -> dict:
    owners={}
    for r in promotion_set:
        pid=str(r.get("PATCH_ID")); keys=set(map(str,r.get("CONFLICT_KEYS") or ()))|set(map(str,r.get("CHANGED_COMPONENTS") or ()))
        for k in keys: owners.setdefault(k,[]).append(pid)
    conflicts={k:sorted(set(v)) for k,v in owners.items() if len(set(v))>1}
    return {"CONFLICT_COUNT":len(conflicts),"CONFLICTS":conflicts,"MERGE_STATE":"AUTO_MERGE_SAFE" if not conflicts else "EXPLICIT_RECONCILIATION_REQUIRED"}
def assert_queue_unchanged(before: Mapping, after: Mapping) -> None:
    if before.get("QUEUE_SNAPSHOT_SHA256")!=after.get("QUEUE_SNAPSHOT_SHA256"):
        raise DiagnosticLedgerError(f"DIAGNOSTIC_QUEUE_DRIFT:{before.get('QUEUE_SNAPSHOT_SHA256')}->{after.get('QUEUE_SNAPSHOT_SHA256')}")

# --- 3E single-pass incremental queue index ---
def build_incremental_queue_index(receipts: Iterable[Mapping]) -> dict:
    events = []
    latest = {}
    seen = set()
    for r in receipts:
        payload = json.dumps(dict(r), sort_keys=True, separators=(",", ":"))
        event_hash = hashlib.sha256(payload.encode("utf-8")).hexdigest()
        if event_hash in seen:
            continue
        seen.add(event_hash)
        rr = dict(r)
        rr["_EVENT_HASH"] = event_hash
        events.append(rr)
        pid = str(rr.get("PATCH_ID") or rr.get("DIAG_ID") or event_hash)
        prior = latest.get(pid)
        if prior is None or _event_key(rr) > _event_key(prior):
            latest[pid] = rr
    digest = hashlib.sha256("\n".join(sorted(seen)).encode("utf-8")).hexdigest()
    return {"EVENT_COUNT": len(seen), "EVENT_HASHES": sorted(seen), "LATEST_BY_PATCH": latest, "QUEUE_DIGEST": digest}


def apply_incremental_queue_delta(index: Mapping, new_receipts: Iterable[Mapping]) -> dict:
    prior_hashes = set(map(str, index.get("EVENT_HASHES") or ()))
    latest = {str(k): dict(v) for k, v in dict(index.get("LATEST_BY_PATCH") or {}).items()}
    added = 0
    for r in new_receipts:
        payload = json.dumps(dict(r), sort_keys=True, separators=(",", ":"))
        event_hash = hashlib.sha256(payload.encode("utf-8")).hexdigest()
        if event_hash in prior_hashes:
            continue
        prior_hashes.add(event_hash)
        added += 1
        rr = dict(r); rr["_EVENT_HASH"] = event_hash
        pid = str(rr.get("PATCH_ID") or rr.get("DIAG_ID") or event_hash)
        prior = latest.get(pid)
        if prior is None or _event_key(rr) > _event_key(prior):
            latest[pid] = rr
    digest = hashlib.sha256("\n".join(sorted(prior_hashes)).encode("utf-8")).hexdigest()
    return {"EVENT_COUNT": len(prior_hashes), "EVENT_HASHES": sorted(prior_hashes), "LATEST_BY_PATCH": latest, "QUEUE_DIGEST": digest, "DELTA_EVENTS_ADDED": added}
