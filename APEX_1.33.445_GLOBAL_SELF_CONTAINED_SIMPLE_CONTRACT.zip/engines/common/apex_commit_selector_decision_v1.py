from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import apex_durable_run_ledger_v1 as durable
import apex_terminal_ai_hybrid_selector_v6 as terminal_ai

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--run-root',required=True)
    ap.add_argument('--candidate-file',required=True)
    ap.add_argument('--candidate-receipt',required=True)
    ap.add_argument('--selected-id',action='append',required=True)
    ap.add_argument('--reason-code',action='append',default=[])
    ap.add_argument('--decision-file',required=True)
    ap.add_argument('--sport',required=True); ap.add_argument('--mode',required=True)
    a=ap.parse_args()
    rows=terminal_ai.load_candidate_csv(Path(a.candidate_file))
    receipt=json.loads(Path(a.candidate_receipt).read_text(encoding='utf-8'))
    freeze=terminal_ai.freeze_candidates(rows)
    expected=str(receipt.get('CANDIDATE_FREEZE_SHA256') or '')
    if expected and freeze!=expected: raise RuntimeError(f'CANDIDATE_FREEZE_MISMATCH:{freeze}:{expected}')
    reasons=a.reason_code or ['CHAT_SELECTOR_DECISION']
    decision={'candidate_freeze_sha256':freeze,'selections':[{'lineup_id':str(x),'reason_codes':list(reasons)} for x in a.selected_id]}
    chosen,validation=terminal_ai.validate_ai_decision(rows,decision,expected_freeze_hash=freeze,board_size=len(a.selected_id),sport=a.sport,mode=a.mode,preverified_freeze_hash=freeze)
    durable.atomic_write(Path(a.decision_file),durable._canonical(decision))
    event=durable.commit_selector_decision(root=Path(a.run_root),decision_path=Path(a.decision_file),freeze_sha256=freeze)
    print(json.dumps({'RUN_STATE':'AI_DECISION_COMMITTED','PATCH_ID':durable.PATCH_ID,'CANDIDATE_FREEZE_SHA256':freeze,'SELECTED_IDS':[str(x) for x in a.selected_id],'DECISION_FILE':str(Path(a.decision_file).resolve()),'DECISION_SHA256':durable.sha256_file(Path(a.decision_file)),'LEDGER_EVENT_SHA256':event['EVENT_SHA256'],'VALIDATION':validation},indent=2))
    return 0
if __name__=='__main__': raise SystemExit(main())
