from __future__ import annotations
import numpy as np

PATCH_ID='APEX_GLOBAL_LINEUP_SELF_CONFLICT_GATE_v1'

class LineupSelfConflictError(RuntimeError):
    pass

def mlb_showdown_evaluate(meta:dict)->dict:
    """Pregame structural contradiction gate for DraftKings MLB Showdown.

    Primary path is fully vectorized over the lineup-slot matrix. No per-lineup
    Python loop and no Monte Carlo pass is introduced. The gate uses only
    player identities, teams, and pitcher-role metadata already present in the
    construction path.
    """
    idx=np.asarray(meta['idx'],dtype=np.int32)
    if idx.ndim!=2:
        raise LineupSelfConflictError('SELF_CONFLICT_IDX_MUST_BE_2D')
    teams=np.asarray(meta['teams'],dtype=object)
    sp_ids=np.asarray(meta.get('sp_player_ids',[]),dtype=np.int32)
    rp_ids=np.asarray(meta.get('rp_player_ids',[]),dtype=np.int32)
    sp_count=np.asarray(meta['sp_count'],dtype=np.int8)
    cpt_sp=np.asarray(meta['cpt_sp'],dtype=bool)
    n=idx.shape[0]
    if len(sp_count)!=n or len(cpt_sp)!=n:
        raise LineupSelfConflictError('SELF_CONFLICT_META_LENGTH_MISMATCH')

    pool_n=len(teams)
    is_sp=np.zeros(pool_n,dtype=bool)
    is_rp=np.zeros(pool_n,dtype=bool)
    if sp_ids.size:
        is_sp[sp_ids]=True
    if rp_ids.size:
        is_rp[rp_ids]=True

    row_is_sp=is_sp[idx]
    sole_mask=(sp_count==1)
    sole_pos=np.argmax(row_is_sp,axis=1)
    sole_sp=idx[np.arange(n),sole_pos].astype(np.int32,copy=False)
    sole_sp=np.where(sole_mask,sole_sp,-1).astype(np.int32,copy=False)

    # The sole-SP team is broadcast across all six lineup slots. For non-sole-SP
    # rows, a harmless placeholder team is used and the final counts are zeroed.
    safe_sp=np.where(sole_mask,sole_sp,0)
    sole_team=teams[safe_sp]
    row_teams=teams[idx]
    hitter_cell=~(is_sp[idx] | is_rp[idx])
    opposing=(hitter_cell & (row_teams!=sole_team[:,None]))
    opposing_hitters=opposing.sum(axis=1,dtype=np.int16).astype(np.int8,copy=False)
    opposing_hitters=np.where(sole_mask,opposing_hitters,0).astype(np.int8,copy=False)

    hard=sole_mask & ((cpt_sp & (opposing_hitters>=3)) | ((~cpt_sp) & (opposing_hitters>=4)))
    penalty=np.zeros(n,dtype=np.float64)
    penalty[sole_mask & (~cpt_sp) & (opposing_hitters==3)]=0.18
    penalty[sole_mask & (opposing_hitters==2)]=0.05
    severity=np.full(n,'NONE',object)
    severity[sole_mask & (opposing_hitters==2)]='MODERATE'
    severity[sole_mask & (~cpt_sp) & (opposing_hitters==3)]='HIGH'
    severity[hard]='HARD_REJECT'

    return {
        'PATCH_ID':PATCH_ID,
        'HARD_REJECT':hard,
        'CONTRADICTION_PENALTY':penalty,
        'SOLE_SP_PLAYER_ID':sole_sp,
        'OPPOSING_HITTER_COUNT_VS_SOLE_SP':opposing_hitters,
        'SEVERITY':severity,
        'RULES':{
            'ONE_OPPOSING_HITTER':'ALLOW',
            'TWO_OPPOSING_HITTERS':'ALLOW_WITH_FRICTION',
            'THREE_OPPOSING_HITTERS_SP_UTIL':'ALLOW_RARE_WITH_HIGH_FRICTION',
            'THREE_PLUS_OPPOSING_HITTERS_SP_CPT':'HARD_REJECT',
            'FOUR_PLUS_OPPOSING_HITTERS_ANY_SOLE_SP':'HARD_REJECT',
        },
        'PERFORMANCE':{
            'IMPLEMENTATION':'VECTORIZED_NUMPY_BOOLEAN_MASK',
            'PYTHON_PER_LINEUP_LOOP':False,
            'EXTRA_MONTE_CARLO_PASSES':0,
            'EXTRA_FIELD_SIMULATION_PASSES':0,
        },
        'POSTLOCK_INPUT_USED':False,
    }

def apply_hard_gate(lineups,meta,evaluation):
    hard=np.asarray(evaluation['HARD_REJECT'],dtype=bool)
    if len(hard)!=len(lineups):
        raise LineupSelfConflictError('SELF_CONFLICT_MASK_LENGTH_MISMATCH')
    keep=~hard
    return np.asarray(lineups)[keep], {
        'PATCH_ID':PATCH_ID,
        'INPUT_LEGAL_LINEUPS':int(len(lineups)),
        'HARD_REJECTED_LINEUPS':int(hard.sum()),
        'SURVIVING_LEGAL_LINEUPS':int(keep.sum()),
        'HARD_REJECT_INDICES':np.flatnonzero(hard).astype(int).tolist(),
        'PERFORMANCE_IMPLEMENTATION':'VECTORIZED_NUMPY_BOOLEAN_MASK',
        'EXTRA_MONTE_CARLO_PASSES':0,
        'POSTLOCK_INPUT_USED':False,
    }
