from __future__ import annotations

"""Global shared intelligence curriculum for the terminal Hybrid AI selector.

One shared intelligence system learns championship-ranking principles across every
supported DFS sport and mode. Sport/mode profiles are context adapters only; they
do not create separate AI models or separate decision authorities. Preference
comparisons remain within a slate so contest outcomes are never compared across
incompatible fields. Historical resolved results are offline labels only.
"""

from typing import Any, Mapping, Sequence
import math

PATCH_ID = "APEX_GLOBAL_HYBRID_SELECTOR_INTELLIGENCE_v2"
OBJECTIVE = "MAXIMIZE_GLOBAL_WINNER_AND_TOP_0_1_CAPTURE_AT_5"
INTELLIGENCE_SCOPE = "GLOBAL_SHARED_ALL_SUPPORTED_SPORTS_ALL_MODES"
LIVE_AI_ROLE = "HYBRID_SELECTOR_REASONING_LAST_STEP_ONLY"
SPORT_MODE_PROFILE_ROLE = "CONTEXT_ADAPTER_ONLY_NOT_SEPARATE_AI_MODEL"

POSTLOCK_OUTCOME_FIELDS = frozenset({
    "CONTEST_RANK", "ACTUAL_RANK", "FINAL_CONTEST_RANK", "ACTUAL_FPTS",
    "REALIZED_FPTS", "POSTLOCK_SCORE", "REALIZED_SCORE", "ACTUAL_SCORE",
})
PLAYER_IDENTITY_FIELDS = frozenset({
    "CPT", "CAPTAIN", "MVP", "UTIL", "UTILS", "PLAYER_IDS", "PLAYERS",
    *(f"UTIL{i}" for i in range(1, 13)),
    *(f"PLAYER{i}" for i in range(1, 13)),
    *(f"P{i}_ID" for i in range(1, 13)),
})
SAFE_EXACT_FIELDS = frozenset({
    "LINEUP_ID", "LINEUP_INDEX", "BRANCH", "ROUTE", "CPT_ROLE", "SP_COUNT",
    "RP_COUNT", "SALARY", "SALARY_GEOMETRY", "SCENARIO_ID",
    "CURRENT_SELECTOR_SELECTED", "CURRENT_SELECTOR_RANK", "CURRENT_SELECTOR_SCORE",
    "GLOBAL_CORE_PROTECTED", "GLOBAL_CORE_PRIORITY",
})
SAFE_PREFIXES = (
    "AI_", "MC_", "BASE_MC_", "FAMILY_", "COMMON_WORLD_", "SAME_WORLD_",
    "WORLD_COVERAGE", "FAST_PATH_WORLD_", "TOTAL_RECURRENCE", "FAST_PATH_TOTAL_",
    "PROJECTED_EXACT_MATCH_DUPLICATION", "P_UNIQUE", "OWNERSHIP_PRODUCT",
    "FIELD_MODEL_RELIABILITY", "LINEUP_OVERLAP", "PAIRWISE_OUTCOME_CORRELATION",
)

class GlobalSelectorIntelligenceError(RuntimeError):
    pass

def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")

def _lineup_id(row: Mapping[str, Any]) -> str:
    for key in ("LINEUP_ID", "LINEUP_INDEX", "ID"):
        value = row.get(key)
        if value not in (None, ""):
            return str(value)
    raise GlobalSelectorIntelligenceError("GLOBAL_INTELLIGENCE_ROW_MISSING_LINEUP_ID")

def _rank(outcome: Mapping[str, Any]) -> int:
    for key in ("CONTEST_RANK", "FINAL_CONTEST_RANK", "ACTUAL_RANK", "RANK"):
        value = outcome.get(key)
        if value not in (None, ""):
            try:
                rank = int(float(value))
            except Exception as exc:
                raise GlobalSelectorIntelligenceError(f"GLOBAL_INTELLIGENCE_BAD_CONTEST_RANK:{value}") from exc
            if rank < 1:
                raise GlobalSelectorIntelligenceError(f"GLOBAL_INTELLIGENCE_BAD_CONTEST_RANK:{rank}")
            return rank
    raise GlobalSelectorIntelligenceError("GLOBAL_INTELLIGENCE_OUTCOME_RANK_MISSING")

def top01_cutoff(field_size: int) -> int:
    if int(field_size) < 1:
        raise GlobalSelectorIntelligenceError("GLOBAL_INTELLIGENCE_FIELD_SIZE_INVALID")
    return max(1, math.ceil(int(field_size) * 0.001))

def top1_cutoff(field_size: int) -> int:
    if int(field_size) < 1:
        raise GlobalSelectorIntelligenceError("GLOBAL_INTELLIGENCE_FIELD_SIZE_INVALID")
    return max(1, math.ceil(int(field_size) * 0.01))

def relevance_grade(rank: int, field_size: int) -> int:
    if int(rank) == 1:
        return 4
    if int(rank) <= top01_cutoff(field_size):
        return 3
    if int(rank) <= top1_cutoff(field_size):
        return 2
    return 0

def _safe_feature_row(row: Mapping[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {"LINEUP_ID": _lineup_id(row)}
    for key, value in row.items():
        ku = str(key).upper()
        if ku in POSTLOCK_OUTCOME_FIELDS or ku in PLAYER_IDENTITY_FIELDS:
            continue
        if ku in SAFE_EXACT_FIELDS or any(ku.startswith(prefix) for prefix in SAFE_PREFIXES):
            out[str(key)] = value
    return out

def build_listwise_training_rows(
    surface_rows: Sequence[Mapping[str, Any]],
    outcomes_by_lineup: Mapping[str, Mapping[str, Any]],
    *, field_size: int, sport: str, mode: str, slate_id: str,
) -> list[dict[str, Any]]:
    """Build one slate's rows for the shared global intelligence corpus."""
    if not surface_rows:
        raise GlobalSelectorIntelligenceError("GLOBAL_INTELLIGENCE_EMPTY_SELECTOR_SURFACE")
    sport_n, mode_n = _norm(sport), _norm(mode)
    ids: set[str] = set(); rows: list[dict[str, Any]] = []
    for src in surface_rows:
        lid = _lineup_id(src)
        if lid in ids:
            raise GlobalSelectorIntelligenceError(f"GLOBAL_INTELLIGENCE_DUPLICATE_LINEUP_ID:{lid}")
        ids.add(lid)
        outcome = outcomes_by_lineup.get(lid)
        if outcome is None:
            continue
        rank = _rank(outcome)
        rec = _safe_feature_row(src)
        rec.update({
            "TRAINING_PATCH_ID": PATCH_ID,
            "GLOBAL_INTELLIGENCE_SCOPE": INTELLIGENCE_SCOPE,
            "GLOBAL_SHARED_REASONER": True,
            "SPORT_MODE_PROFILE_ROLE": SPORT_MODE_PROFILE_ROLE,
            "SLATE_ID": str(slate_id),
            "SPORT": sport_n,
            "MODE": mode_n,
            "SPORT_MODE_CONTEXT": f"{sport_n}:{mode_n}",
            "FIELD_SIZE": int(field_size),
            "TARGET_CONTEST_RANK": rank,
            "TARGET_RELEVANCE_GRADE": relevance_grade(rank, field_size),
            "TARGET_WINNER": rank == 1,
            "TARGET_TOP_0_1": rank <= top01_cutoff(field_size),
            "TARGET_TOP_1": rank <= top1_cutoff(field_size),
        })
        rows.append(rec)
    if not rows:
        raise GlobalSelectorIntelligenceError("GLOBAL_INTELLIGENCE_NO_MATCHED_RESOLVED_ROWS")
    return rows

def build_global_training_corpus(slates: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Merge all supported sports/modes into one shared training corpus.

    Each slate keeps its sport/mode context tag. No separate model partitions are
    created. This is the canonical global learning surface.
    """
    corpus: list[dict[str, Any]] = []
    seen_slates: set[str] = set()
    for slate in slates:
        slate_id = str(slate.get("slate_id") or slate.get("SLATE_ID") or "")
        if not slate_id:
            raise GlobalSelectorIntelligenceError("GLOBAL_INTELLIGENCE_SLATE_ID_MISSING")
        if slate_id in seen_slates:
            raise GlobalSelectorIntelligenceError(f"GLOBAL_INTELLIGENCE_DUPLICATE_SLATE_ID:{slate_id}")
        seen_slates.add(slate_id)
        corpus.extend(build_listwise_training_rows(
            slate.get("surface_rows") or slate.get("SURFACE_ROWS") or [],
            slate.get("outcomes_by_lineup") or slate.get("OUTCOMES_BY_LINEUP") or {},
            field_size=int(slate.get("field_size") or slate.get("FIELD_SIZE") or 0),
            sport=str(slate.get("sport") or slate.get("SPORT") or ""),
            mode=str(slate.get("mode") or slate.get("MODE") or ""),
            slate_id=slate_id,
        ))
    if not corpus:
        raise GlobalSelectorIntelligenceError("GLOBAL_INTELLIGENCE_EMPTY_GLOBAL_CORPUS")
    return corpus

def _selector_rank(row: Mapping[str, Any]) -> float:
    try:
        v = float(row.get("CURRENT_SELECTOR_RANK"))
        if math.isfinite(v) and v > 0:
            return v
    except Exception:
        pass
    try:
        s = float(row.get("CURRENT_SELECTOR_SCORE"))
        if math.isfinite(s):
            return -s
    except Exception:
        pass
    return float("inf")

def mine_hard_negative_pairs(training_rows: Sequence[Mapping[str, Any]], *, max_negatives_per_positive: int = 8) -> list[dict[str, Any]]:
    """Mine hard negatives within each slate; never rank one contest against another."""
    by_slate: dict[str, list[dict[str, Any]]] = {}
    for row in training_rows:
        by_slate.setdefault(str(row.get("SLATE_ID", "")), []).append(dict(row))
    pairs: list[dict[str, Any]] = []
    for slate_id, slate_rows in by_slate.items():
        positives = [r for r in slate_rows if int(r.get("TARGET_RELEVANCE_GRADE", 0)) >= 3]
        negatives = [r for r in slate_rows if int(r.get("TARGET_RELEVANCE_GRADE", 0)) < 3]
        for pos in positives:
            pr = _selector_rank(pos); hard = []
            for neg in negatives:
                nr = _selector_rank(neg)
                selected = str(neg.get("CURRENT_SELECTOR_SELECTED", "")).strip().lower() in {"1","true","yes","y"}
                if selected or nr < pr:
                    hard.append((0 if selected else 1, nr, neg))
            hard.sort(key=lambda x: (x[0], x[1], str(x[2].get("LINEUP_ID", ""))))
            for _, _, neg in hard[:max(0, int(max_negatives_per_positive))]:
                pairs.append({
                    "TRAINING_PATCH_ID": PATCH_ID,
                    "GLOBAL_INTELLIGENCE_SCOPE": INTELLIGENCE_SCOPE,
                    "SLATE_ID": slate_id,
                    "SPORT": pos.get("SPORT"), "MODE": pos.get("MODE"),
                    "PREFERRED_LINEUP_ID": str(pos.get("LINEUP_ID")),
                    "REJECTED_LINEUP_ID": str(neg.get("LINEUP_ID")),
                    "PREFERRED_GRADE": int(pos.get("TARGET_RELEVANCE_GRADE", 0)),
                    "REJECTED_GRADE": int(neg.get("TARGET_RELEVANCE_GRADE", 0)),
                    "PREFERRED_CONTEST_RANK": int(pos.get("TARGET_CONTEST_RANK", 0)),
                    "REJECTED_CONTEST_RANK": int(neg.get("TARGET_CONTEST_RANK", 0)),
                    "HARD_NEGATIVE_REASON": "CODE_SELECTOR_OUTRANKED_CHAMPIONSHIP_ROW",
                })
    return pairs

def global_corpus_summary(training_rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    contexts = sorted({str(r.get("SPORT_MODE_CONTEXT", "")) for r in training_rows if r.get("SPORT_MODE_CONTEXT")})
    slates = {str(r.get("SLATE_ID", "")) for r in training_rows if r.get("SLATE_ID")}
    return {
        "PATCH_ID": PATCH_ID,
        "INTELLIGENCE_SCOPE": INTELLIGENCE_SCOPE,
        "GLOBAL_SHARED_REASONER": True,
        "SPORT_MODE_PROFILE_ROLE": SPORT_MODE_PROFILE_ROLE,
        "TRAINING_ROWS": len(training_rows),
        "SLATES": len(slates),
        "SPORT_MODE_CONTEXTS": contexts,
        "WINNER_ROWS": sum(bool(r.get("TARGET_WINNER")) for r in training_rows),
        "TOP_0_1_ROWS": sum(bool(r.get("TARGET_TOP_0_1")) for r in training_rows),
    }

def evaluate_top5_decision(selected_lineup_ids: Sequence[str], outcomes_by_lineup: Mapping[str, Mapping[str, Any]], *, field_size: int) -> dict[str, Any]:
    ids = [str(x) for x in selected_lineup_ids]
    if len(ids) != 5 or len(set(ids)) != 5:
        raise GlobalSelectorIntelligenceError("GLOBAL_INTELLIGENCE_TOP5_DECISION_INVALID")
    ranks = [_rank(outcomes_by_lineup[lid]) for lid in ids if lid in outcomes_by_lineup]
    return {
        "PATCH_ID": PATCH_ID, "OBJECTIVE": OBJECTIVE, "FINAL_BOARD_SIZE": 5,
        "MATCHED_OUTCOMES": len(ranks),
        "WINNER_CAPTURE_AT_5": any(r == 1 for r in ranks),
        "TOP_0_1_CAPTURE_AT_5": any(r <= top01_cutoff(field_size) for r in ranks),
        "TOP_1_CAPTURE_AT_5": any(r <= top1_cutoff(field_size) for r in ranks),
        "BEST_CONTEST_RANK_AT_5": min(ranks) if ranks else None,
    }

def intelligence_contract() -> dict[str, Any]:
    return {
        "PATCH_ID": PATCH_ID,
        "OBJECTIVE": OBJECTIVE,
        "INTELLIGENCE_SCOPE": INTELLIGENCE_SCOPE,
        "GLOBAL_SHARED_REASONER": True,
        "SPORT_MODE_PROFILE_ROLE": SPORT_MODE_PROFILE_ROLE,
        "LIVE_AI_ROLE": LIVE_AI_ROLE,
        "AI_UPSTREAM_AUTHORITY": False,
        "ENGINE_UPSTREAM_AUTHORITY": True,
        "PLAYER_NAME_MEMORIZATION": False,
        "HISTORICAL_OUTCOMES_FORWARD_INPUT": False,
        "PREFERENCE_COMPARISONS": "WITHIN_SLATE_ONLY",
        "TRAINING_FORMS": [
            "GLOBAL_BLIND_LISTWISE_REPLAY",
            "GRADED_WINNER_TOP01_TOP1_LABELS",
            "GLOBAL_HARD_NEGATIVE_LIBRARY",
            "WITHIN_SLATE_PAIRWISE_PREFERENCE_LESSONS",
            "CROSS_SPORT_TRANSFER_WITH_CONTEXT_ADAPTERS",
            "GLOBAL_TIME_ORDERED_WALK_FORWARD_EVALUATION",
        ],
        "PROMOTION_METRICS": [
            "GLOBAL_WINNER_CAPTURE_AT_5",
            "GLOBAL_TOP_0_1_CAPTURE_AT_5",
            "SPORT_MODE_NON_REGRESSION",
            "BEST_CONTEST_RANK_AT_5",
        ],
    }
