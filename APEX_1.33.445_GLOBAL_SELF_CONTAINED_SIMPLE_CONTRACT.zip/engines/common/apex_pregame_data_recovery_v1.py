from __future__ import annotations

import json
import math
import os
from pathlib import Path
from statistics import median
from typing import Dict, Iterable, Mapping

import pandas as pd

PATCH_ID = "GLOBAL_RECOVERABLE_EXTERNAL_DATA_GAP_SEARCH_REPAIR_RERUN_v1"




class RecoverableExternalDataGap(RuntimeError):
    """Global machine-readable recoverable external-data gap."""
    def __init__(self, variable: str, entities=(), detail: str = "PUBLIC_RECOVERY_REQUIRED"):
        self.variable = str(variable)
        self.entities = tuple(sorted({str(x).strip() for x in entities if str(x).strip()}))
        self.detail = str(detail)
        super().__init__(
            f"RUN_RECOVERABLE:EXTERNAL_DATA_GAP:{self.variable}:"
            f"ENTITIES={','.join(self.entities)}:DETAIL={self.detail}"
        )

def require_recoverable_external(variable: str, entities=(), detail: str = "PUBLIC_RECOVERY_REQUIRED"):
    raise RecoverableExternalDataGap(variable, entities, detail)

class RecoverablePregameDataGap(RuntimeError):
    """Machine-readable recoverable gap for the execution/orchestration layer."""

    def __init__(self, variable: str, teams: Iterable[str], detail: str = "PUBLIC_RECOVERY_REQUIRED"):
        self.variable = str(variable)
        self.teams = tuple(sorted({str(t).strip() for t in teams if str(t).strip()}))
        self.detail = str(detail)
        super().__init__(
            f"RUN_RECOVERABLE:PREGAME_DATA_GAP:{self.variable}:"
            f"TEAMS={','.join(self.teams)}:DETAIL={self.detail}"
        )


def _num(value):
    try:
        if value is None:
            return None
        if isinstance(value, str):
            value = value.replace('%', '').replace(',', '').strip()
            if value in {'', '-', 'nan', 'None', 'null'}:
                return None
        value = float(value)
        return value if math.isfinite(value) else None
    except Exception:
        return None


def _normalize_map(raw: Mapping) -> Dict[str, float]:
    out: Dict[str, float] = {}
    for team, value in raw.items():
        v = _num(value)
        if v is None:
            continue
        # Defensive MLB implied-team-run bounds. These are integrity bounds,
        # not model priors; values outside them require human/source review.
        if 1.0 <= v <= 9.0:
            out[str(team).strip().upper()] = float(v)
    return out


def _load_env_map() -> Dict[str, float]:
    raw = os.environ.get('APEX_TEAM_RUN_TOTALS_JSON', '').strip()
    if not raw:
        return {}
    try:
        payload = json.loads(raw)
    except Exception as exc:
        raise RecoverablePregameDataGap('T_RUNS', (), f'INVALID_APEX_TEAM_RUN_TOTALS_JSON:{exc}') from exc
    if not isinstance(payload, dict):
        raise RecoverablePregameDataGap('T_RUNS', (), 'TEAM_RUN_TOTALS_JSON_NOT_OBJECT')
    return _normalize_map(payload)


def _load_file_map() -> Dict[str, float]:
    path = os.environ.get('APEX_TEAM_RUN_TOTALS_FILE', '').strip()
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        raise RecoverablePregameDataGap('T_RUNS', (), f'TEAM_RUN_TOTALS_FILE_MISSING:{p}')
    try:
        if p.suffix.lower() in {'.json', '.jsn'}:
            payload = json.loads(p.read_text())
            if isinstance(payload, dict) and 'team_runs' in payload and isinstance(payload['team_runs'], dict):
                payload = payload['team_runs']
            if not isinstance(payload, dict):
                raise ValueError('JSON_NOT_OBJECT')
            return _normalize_map(payload)
        frame = pd.read_csv(p)
        team_col = next((c for c in ('TEAM', 'Team', 'team') if c in frame.columns), None)
        value_col = next((c for c in ('T Runs', 'T_Runs', 'T_RUNS', 'implied_runs', 'team_runs') if c in frame.columns), None)
        if team_col is None or value_col is None:
            raise ValueError('CSV_REQUIRES_TEAM_AND_T_RUNS_COLUMNS')
        return _normalize_map(dict(zip(frame[team_col], frame[value_col])))
    except RecoverablePregameDataGap:
        raise
    except Exception as exc:
        raise RecoverablePregameDataGap('T_RUNS', (), f'INVALID_TEAM_RUN_TOTALS_FILE:{exc}') from exc


def robust_consensus(source_maps: Iterable[Mapping[str, float]], max_deviation: float = 0.75) -> Dict[str, float]:
    """Median-centered outlier rejection, then arithmetic mean per team."""
    grouped: Dict[str, list[float]] = {}
    for source in source_maps:
        for team, value in _normalize_map(source).items():
            grouped.setdefault(team, []).append(float(value))
    out: Dict[str, float] = {}
    for team, vals in grouped.items():
        center = median(vals)
        kept = [x for x in vals if abs(x - center) <= max_deviation]
        if kept:
            out[team] = round(sum(kept) / len(kept), 3)
    return out


def repair_team_runs(pool: pd.DataFrame, require_two_sources: bool = False) -> tuple[pd.DataFrame, dict]:
    """
    Restore the exact production column ``T Runs`` when it is absent/incomplete.

    Recovery inputs are injected by the execution layer after public-source search:
      - APEX_TEAM_RUN_TOTALS_JSON='{"ATL":4.7,"MIL":4.2}'
      - APEX_TEAM_RUN_TOTALS_FILE=/path/to/verified_consensus.json|csv

    If neither can establish complete slate coverage, emit RUN_RECOVERABLE rather
    than an opaque schema crash. The execution layer must search, inject, and rerun.
    """
    team_col = next((c for c in ('TEAM', 'Team', 'team') if c in pool.columns), None)
    if team_col is None:
        raise RuntimeError('RUN_INVALID:MISSING_TEAM_COLUMN')

    teams = tuple(sorted({str(t).strip().upper() for t in pool[team_col].dropna() if str(t).strip()}))
    if not teams:
        raise RuntimeError('RUN_INVALID:NO_ACTIVE_TEAMS')

    repaired = pool.copy()
    existing = None
    for c in ('T Runs', 'T_Runs', 'T_RUNS'):
        if c in repaired.columns:
            existing = c
            break

    current: Dict[str, float] = {}
    if existing is not None:
        for team, grp in repaired.groupby(team_col, dropna=True):
            vals = [_num(x) for x in grp[existing].tolist()]
            vals = [x for x in vals if x is not None and x > 0]
            if vals:
                current[str(team).strip().upper()] = float(median(vals))

    missing = [t for t in teams if t not in current]
    if not missing:
        repaired['T Runs'] = repaired[team_col].astype(str).str.strip().str.upper().map(current)
        return repaired, {
            'patch_id': PATCH_ID,
            'status': 'NOT_NEEDED',
            'teams': list(teams),
            'team_runs': current,
            'source_count': 0,
        }

    sources = []
    env_map = _load_env_map()
    if env_map:
        sources.append(env_map)
    file_map = _load_file_map()
    if file_map:
        sources.append(file_map)

    if require_two_sources and len(sources) < 2:
        raise RecoverablePregameDataGap('T_RUNS', missing, 'CONSENSUS_REQUIRES_TWO_SOURCES')

    recovered = robust_consensus(sources) if sources else {}
    merged = dict(current)
    merged.update(recovered)
    still_missing = [t for t in teams if t not in merged]
    if still_missing:
        raise RecoverablePregameDataGap('T_RUNS', still_missing, 'PUBLIC_SEARCH_INJECT_RERUN_REQUIRED')

    repaired['T Runs'] = repaired[team_col].astype(str).str.strip().str.upper().map(merged)
    if repaired['T Runs'].isna().any():
        bad = sorted(set(repaired.loc[repaired['T Runs'].isna(), team_col].astype(str)))
        raise RuntimeError(f'RUN_INVALID:T_RUNS_REMAP_FAILED:{bad}')

    return repaired, {
        'patch_id': PATCH_ID,
        'status': 'REPAIRED',
        'teams': list(teams),
        'team_runs': {t: merged[t] for t in teams},
        'source_count': len(sources),
        'source_policy': 'MEDIAN_CENTERED_OUTLIER_REJECTION_THEN_MEAN',
    }
