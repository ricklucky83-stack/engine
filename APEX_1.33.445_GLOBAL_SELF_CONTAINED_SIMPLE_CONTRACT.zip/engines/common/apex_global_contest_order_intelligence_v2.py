from __future__ import annotations

"""Global contest-order intelligence framework.

Shared contract, sport x mode adapters.  This module never creates, deletes,
legalizes, simulates, or selects lineups.  It only attaches prelock ordering
signals and returns a deterministic order over an already-frozen surface.

The framework is global; learned coefficients are NOT shared across sports.
Sport/mode adapters may contribute certified structural lanes or native scores.
All comparisons are within one slate.
"""

from dataclasses import dataclass
from typing import Any, Mapping, Sequence
import math
import numpy as np

PATCH_ID = "APEX_GLOBAL_CONTEST_ORDER_INTELLIGENCE_v2"
ARCHITECTURE = "GLOBAL_SHARED_FRAMEWORK_PLUS_SPORT_MODE_ADAPTERS"
MEMBERSHIP_MUTATION_ALLOWED = False
UNIVERSAL_CROSS_SPORT_MODEL_ALLOWED = False
POSTLOCK_FIELDS = frozenset({
    "CONTEST_RANK","ACTUAL_RANK","FINAL_CONTEST_RANK","ACTUAL_FPTS",
    "REALIZED_FPTS","POSTLOCK_SCORE","REALIZED_SCORE","ACTUAL_SCORE",
    "WINNING_LINEUP","TARGET_ACTUAL_SCORE",
})

# Shared statistical channels.  We aggregate percentiles/ranks, not raw values,
# so sport-specific units do not leak into the common layer.
COMMON_WEIGHTS = {
    # Rank-1 remains the most important single seat, but production ordering is
    # explicitly a full ordinal problem: 1,2,3,4,... as close to realized
    # contest order as prelock information allows.
    "MOST_PROBABLE_BEST": 0.24,
    "EXTREME_TAIL": 0.16,
    "ORDINAL_POSTERIOR": 0.24,
    "SPORT_NATIVE": 0.18,
    "CROSS_WORLD": 0.08,
    "STABILITY": 0.06,
    "LOW_DUPLICATION": 0.04,
}

ORDERING_OBJECTIVE = "PREDICT_REALIZED_CONTEST_ORDER_1_2_3_4_ETC_AS_ACCURATELY_AS_POSSIBLE"
ORDERING_EVALUATION = {
    "PRIMARY": "TOP_WEIGHTED_ORDINAL_ACCURACY",
    "SECONDARY": ["WINNER_ORDER_RANK", "NDCG_AT_10", "NDCG_AT_25", "NDCG_AT_100",
                  "SPEARMAN_FULL_BOARD", "KENDALL_FULL_BOARD", "PAIRWISE_ORDER_ACCURACY"],
    "TIE_POLICY": "REALIZED_SCORE_TIES_SHARE_CONTEST_RANK; PREDICTIVE_ORDER_USES_STABLE_TIEBREAK_ONLY",
}

class GlobalOrderIntelligenceError(RuntimeError):
    pass


def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")


def _arr(x: Any, n: int, default: float = float("nan")) -> np.ndarray:
    if x is None:
        return np.full(n, default, dtype=np.float64)
    a = np.asarray(x, dtype=np.float64)
    if a.ndim == 0:
        a = np.full(n, float(a), dtype=np.float64)
    if len(a) != n:
        raise GlobalOrderIntelligenceError(f"GLOBAL_ORDER_LENGTH_MISMATCH:{len(a)}:{n}")
    return a


def _pct(a: np.ndarray, *, higher: bool = True) -> np.ndarray:
    a = np.asarray(a, dtype=np.float64)
    n = len(a)
    out = np.full(n, np.nan, dtype=np.float64)
    good = np.flatnonzero(np.isfinite(a))
    if len(good) == 0:
        return out
    vals = a[good]
    order = np.argsort(vals, kind="mergesort")
    ranks = np.empty(len(good), dtype=np.float64)
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and vals[order[j]] == vals[order[i]]:
            j += 1
        avg = ((i + j - 1) / 2.0 + 0.5) / max(1, len(order))
        ranks[order[i:j]] = avg
        i = j
    out[good] = ranks if higher else (1.0 - ranks)
    return out


def _blend(parts: Sequence[tuple[np.ndarray, float]], n: int) -> np.ndarray:
    num = np.zeros(n, dtype=np.float64)
    den = np.zeros(n, dtype=np.float64)
    for a, w in parts:
        good = np.isfinite(a)
        num[good] += a[good] * float(w)
        den[good] += float(w)
    return np.divide(num, den, out=np.full(n, 0.5, dtype=np.float64), where=den > 0)


def validate_prelock_mapping(mapping: Mapping[str, Any]) -> None:
    bad = sorted(k for k in mapping if str(k).upper() in POSTLOCK_FIELDS)
    if bad:
        raise GlobalOrderIntelligenceError("GLOBAL_ORDER_POSTLOCK_LEAKAGE:" + ",".join(bad))


@dataclass(frozen=True)
class OrderResult:
    order: np.ndarray
    order_rank: np.ndarray
    order_score: np.ndarray
    order_confidence: np.ndarray
    rank_uncertainty_width: np.ndarray
    most_probable_best_score: np.ndarray
    extreme_tail_score: np.ndarray
    ordinal_posterior_score: np.ndarray
    sport_native_pctl: np.ndarray
    adapter_priority_tier: np.ndarray
    adapter_priority_rank: np.ndarray
    receipt: dict[str, Any]


def rank_surface(
    metrics: Mapping[str, Any], *, sport: str, mode: str,
    sport_native_score: Any = None,
    world_breadth: Any = None,
    rank_stability: Any = None,
    projected_duplication: Any = None,
    expected_rank: Any = None,
    median_rank: Any = None,
    rank_p90: Any = None,
    pairwise_strength: Any = None,
    adapter_priority_tier: Any = None,
    adapter_priority_score: Any = None,
    adapter_id: str | None = None,
    adapter_live_authority: bool = False,
) -> OrderResult:
    """Rank a frozen candidate surface using shared statistical machinery.

    Certified adapter lanes may occupy early order positions, but cannot add/remove
    candidates.  All remaining rows are ordered by a common uncertainty-aware
    percentile ensemble.  The same coefficient vector is intentionally NOT learned
    across sports; only the common statistical aggregation is shared.
    """
    validate_prelock_mapping(metrics)
    # determine n from first array-like metric
    n = None
    for v in metrics.values():
        try:
            if np.asarray(v).ndim > 0:
                n = len(np.asarray(v)); break
        except Exception:
            pass
    if n is None or n <= 0:
        raise GlobalOrderIntelligenceError("GLOBAL_ORDER_EMPTY_SURFACE")

    top01 = _arr(metrics.get("top01_lcb", metrics.get("MC_TOP_0_1_LCB", metrics.get("top01_rate", metrics.get("MC_TOP_0_1_RATE")))), n)
    win = _arr(metrics.get("win_lcb", metrics.get("MC_WIN_LCB", metrics.get("win_rate", metrics.get("MC_WIN_RATE")))), n)
    p99 = _arr(metrics.get("p99", metrics.get("MC_P99")), n)
    p95 = _arr(metrics.get("p95", metrics.get("MC_P95")), n)
    # Prefer explicit uncertainty width.  Otherwise use Wilson gap when supplied.
    if metrics.get("rank_uncertainty_width") is not None:
        width = _arr(metrics.get("rank_uncertainty_width"), n)
    elif metrics.get("top01_ucb") is not None and metrics.get("top01_lcb") is not None:
        width = np.maximum(0.0, _arr(metrics.get("top01_ucb"),n) - _arr(metrics.get("top01_lcb"),n))
    else:
        width = np.full(n, np.nan, dtype=np.float64)

    top01p = _pct(top01); winp = _pct(win); p99p = _pct(p99); p95p = _pct(p95)
    mpb = _blend(((top01p,0.65),(winp,0.35)), n)
    tail = _blend(((p99p,0.70),(p95p,0.30)), n)

    # Full-ordinal posterior channels. These are intentionally optional so every
    # sport can enter production under the same contract before it has a learned
    # ordinal adapter. Lower expected/median/P90 rank is better; higher pairwise
    # strength is better.
    er = _arr(expected_rank,n) if expected_rank is not None else np.full(n,np.nan)
    mr = _arr(median_rank,n) if median_rank is not None else np.full(n,np.nan)
    r90 = _arr(rank_p90,n) if rank_p90 is not None else np.full(n,np.nan)
    ps = _arr(pairwise_strength,n) if pairwise_strength is not None else np.full(n,np.nan)
    ordinal = _blend(((_pct(er,higher=False),0.35),(_pct(mr,higher=False),0.25),
                      (_pct(r90,higher=False),0.20),(_pct(ps,higher=True),0.20)),n)
    ordinal_has_evidence = bool(np.any(np.isfinite(er)) or np.any(np.isfinite(mr)) or np.any(np.isfinite(r90)) or np.any(np.isfinite(ps)))
    if not ordinal_has_evidence:
        ordinal[:] = np.nan

    native = _arr(sport_native_score,n) if sport_native_score is not None else np.full(n,np.nan)
    nativep = _pct(native)
    world = _arr(world_breadth,n) if world_breadth is not None else np.full(n,np.nan)
    worldp = _pct(world)
    stability = _arr(rank_stability,n) if rank_stability is not None else np.full(n,np.nan)
    stabilityp = _pct(stability)
    if np.all(~np.isfinite(stabilityp)) and np.any(np.isfinite(width)):
        stabilityp = _pct(width, higher=False)
    dup = _arr(projected_duplication,n) if projected_duplication is not None else np.full(n,np.nan)
    lowdupp = _pct(dup,higher=False)

    base = _blend((
        (mpb,COMMON_WEIGHTS["MOST_PROBABLE_BEST"]),
        (tail,COMMON_WEIGHTS["EXTREME_TAIL"]),
        (ordinal,COMMON_WEIGHTS["ORDINAL_POSTERIOR"]),
        (nativep,COMMON_WEIGHTS["SPORT_NATIVE"]),
        (worldp,COMMON_WEIGHTS["CROSS_WORLD"]),
        (stabilityp,COMMON_WEIGHTS["STABILITY"]),
        (lowdupp,COMMON_WEIGHTS["LOW_DUPLICATION"]),
    ),n)

    # Rank-confidence penalty is intentionally small: uncertainty widens the rank
    # band rather than erasing a strong independent signal.
    channel_stack=np.vstack([mpb,tail,ordinal,nativep,worldp,stabilityp])
    spread=np.nanmax(channel_stack,axis=0)-np.nanmin(channel_stack,axis=0)
    spread=np.nan_to_num(spread,nan=0.0,posinf=1.0,neginf=0.0)
    confidence=np.clip(1.0-spread,0.0,1.0)
    score=np.clip(base - 0.05*spread,0.0,1.0)

    tier = _arr(adapter_priority_tier,n,0.0) if adapter_priority_tier is not None else np.zeros(n)
    apr = _arr(adapter_priority_score,n) if adapter_priority_score is not None else native.copy()
    apr_p=_pct(apr)
    # Certified lanes interleave by tier only when the sport adapter explicitly has
    # live order authority.  Otherwise all adapter evidence remains shadow features.
    live_tier=tier if adapter_live_authority else np.zeros(n)
    idx=np.arange(n,dtype=np.int64)
    # lexsort last key is primary: live tier desc, adapter score desc for tier rows,
    # global score desc, then deterministic index.
    live_adapter_sort=np.where(live_tier>0.0,np.nan_to_num(apr_p,nan=-1.0),-1.0)
    order=np.lexsort((idx,-score,-live_adapter_sort,-live_tier)).astype(np.int32)
    rank=np.empty(n,dtype=np.int32); rank[order]=np.arange(1,n+1,dtype=np.int32)

    receipt={
        "PATCH_ID":PATCH_ID,
        "ARCHITECTURE":ARCHITECTURE,
        "SPORT":_norm(sport),"MODE":_norm(mode),
        "MEMBERSHIP_MUTATION_ALLOWED":False,
        "UNIVERSAL_CROSS_SPORT_MODEL_ALLOWED":False,
        "SHARED_STATISTICAL_AGGREGATION":True,
        "SPORT_MODE_ADAPTER_REQUIRED":True,
        "ADAPTER_ID":str(adapter_id or f"{_norm(sport)}__{_norm(mode)}__DEFAULT_SHADOW"),
        "ADAPTER_LIVE_ORDER_AUTHORITY":bool(adapter_live_authority),
        "CANDIDATE_COUNT":int(n),
        "POSTLOCK_INPUT_USED":False,
        "ORDERING_OBJECTIVE":ORDERING_OBJECTIVE,
        "ORDERING_EVALUATION":dict(ORDERING_EVALUATION),
        "COMMON_WEIGHTS":dict(COMMON_WEIGHTS),
        "ORDINAL_POSTERIOR_CHANNEL_ACTIVE":ordinal_has_evidence,
        "RANK_UNCERTAINTY_OUTPUT":True,
        "MOST_PROBABLE_BEST_CHANNEL":True,
        "CROSS_WORLD_CONSENSUS_CHANNEL":True,
        "PORTFOLIO_DIVERSIFICATION_ROLE":"DOWNSTREAM_ONLY",
    }
    return OrderResult(order,rank,score,confidence,spread,mpb,tail,ordinal,nativep,tier.astype(np.int32),apr_p,receipt)


def attach_order_fields(rows: Sequence[Mapping[str,Any]], result: OrderResult) -> list[dict[str,Any]]:
    if len(rows) != len(result.order_rank):
        raise GlobalOrderIntelligenceError("GLOBAL_ORDER_ATTACH_LENGTH_MISMATCH")
    out=[]
    for i,row in enumerate(rows):
        r=dict(row)
        r["GLOBAL_ORDER_SCORE"]=float(result.order_score[i])
        r["GLOBAL_ORDER_RANK"]=int(result.order_rank[i])
        r["GLOBAL_ORDER_CONFIDENCE"]=float(result.order_confidence[i])
        r["GLOBAL_ORDER_UNCERTAINTY_WIDTH"]=float(result.rank_uncertainty_width[i])
        r["GLOBAL_MOST_PROBABLE_BEST_SCORE"]=float(result.most_probable_best_score[i])
        r["GLOBAL_EXTREME_TAIL_SCORE"]=float(result.extreme_tail_score[i])
        r["GLOBAL_ORDINAL_POSTERIOR_SCORE"]=float(result.ordinal_posterior_score[i]) if math.isfinite(float(result.ordinal_posterior_score[i])) else ""
        r["GLOBAL_SPORT_NATIVE_PCTL"]=float(result.sport_native_pctl[i]) if math.isfinite(float(result.sport_native_pctl[i])) else ""
        r["GLOBAL_ADAPTER_PRIORITY_TIER"]=int(result.adapter_priority_tier[i])
        out.append(r)
    return out


def contract() -> dict[str,Any]:
    return {
        "PATCH_ID":PATCH_ID,
        "ARCHITECTURE":ARCHITECTURE,
        "SCOPE":"ALL_SUPPORTED_SPORTS_AND_MODES",
        "ORDERING_OBJECTIVE":ORDERING_OBJECTIVE,
        "ORDERING_EVALUATION":dict(ORDERING_EVALUATION),
        "MEMBERSHIP_MUTATION_ALLOWED":False,
        "UNIVERSAL_CROSS_SPORT_MODEL_ALLOWED":False,
        "SPORT_MODE_ADAPTER_REQUIRED":True,
        "ORDER_OUTPUTS":["GLOBAL_ORDER_SCORE","GLOBAL_ORDER_RANK","GLOBAL_ORDER_CONFIDENCE","GLOBAL_ORDER_UNCERTAINTY_WIDTH","GLOBAL_ORDINAL_POSTERIOR_SCORE"],
        "DIAGNOSTIC_OUTPUTS":["WINNER_GLOBAL_ORDER_RANK","TOP5_TOP01_CAPTURE","NDCG_AT_10","NDCG_AT_25","NDCG_AT_100","SPEARMAN_FULL_BOARD","KENDALL_FULL_BOARD","PAIRWISE_ORDER_ACCURACY","RANK_STABILITY"],
        "PORTFOLIO_DIVERSIFICATION_ROLE":"DOWNSTREAM_ONLY_AFTER_LINEUP_ORDER_INTELLIGENCE",
        "HISTORICAL_OUTCOMES_FORWARD_INPUT":False,
    }
