from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Mapping

PATCH_ID = "APEX_GLOBAL_3E_SINGLE_PASS_REPAIR_TRANSACTION_v1"
STAGES = (
    "DIAGNOSED",
    "PATCHED",
    "TARGETED_TESTED",
    "SEALED",
    "CAS_VERIFIED",
    "POINTER_ROTATED",
    "READBACK_VERIFIED",
)


class RepairTransactionError(RuntimeError):
    pass


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parent_fingerprint(state_version: str, pointer_file_id: str, pointer_sha256: str) -> str:
    raw = f"{state_version}|{pointer_file_id}|{pointer_sha256}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def new_transaction(*, repair_id: str, parent_state_version: str, parent_pointer_file_id: str,
                    parent_pointer_sha256: str, root_cause: str, changed_components: Iterable[str]) -> dict:
    if not repair_id or not root_cause:
        raise RepairTransactionError("REPAIR_ID_AND_ROOT_CAUSE_REQUIRED")
    return {
        "PATCH_ID": PATCH_ID,
        "REPAIR_ID": str(repair_id),
        "ROOT_CAUSE": str(root_cause),
        "CHANGED_COMPONENTS": sorted(set(map(str, changed_components))),
        "PARENT_STATE_VERSION": str(parent_state_version),
        "PARENT_POINTER_FILE_ID": str(parent_pointer_file_id),
        "PARENT_POINTER_SHA256": str(parent_pointer_sha256),
        "PARENT_FINGERPRINT": _parent_fingerprint(parent_state_version, parent_pointer_file_id, parent_pointer_sha256),
        "EPOCH": 0,
        "COMPLETED_STAGES": [],
        "STAGE_COUNTS": {},
        "REBASE_COUNT": 0,
        "CREATED_AT_UTC": _utc(),
        "UPDATED_AT_UTC": _utc(),
    }


def advance(tx: Mapping, stage: str, *, receipt: Mapping | None = None) -> dict:
    stage = str(stage).upper()
    if stage not in STAGES:
        raise RepairTransactionError(f"UNKNOWN_REPAIR_STAGE:{stage}")
    out = deepcopy(dict(tx))
    done = list(out.get("COMPLETED_STAGES") or [])
    counts = dict(out.get("STAGE_COUNTS") or {})
    if stage in done or int(counts.get(stage, 0)) > 0:
        raise RepairTransactionError(f"DUPLICATE_REPAIR_STAGE_PROHIBITED:{stage}:EPOCH={out.get('EPOCH',0)}")
    expected = STAGES[len(done)] if len(done) < len(STAGES) else None
    if stage != expected:
        raise RepairTransactionError(f"REPAIR_STAGE_ORDER_VIOLATION:EXPECTED={expected}:GOT={stage}")
    done.append(stage)
    counts[stage] = 1
    out["COMPLETED_STAGES"] = done
    out["STAGE_COUNTS"] = counts
    out.setdefault("RECEIPTS", {})[stage] = dict(receipt or {})
    out["UPDATED_AT_UTC"] = _utc()
    if stage == "READBACK_VERIFIED":
        out["STATUS"] = "COMPLETE"
    return out


def rebase(tx: Mapping, *, parent_state_version: str, parent_pointer_file_id: str, parent_pointer_sha256: str) -> dict:
    out = deepcopy(dict(tx))
    new_fp = _parent_fingerprint(parent_state_version, parent_pointer_file_id, parent_pointer_sha256)
    if new_fp == str(out.get("PARENT_FINGERPRINT") or ""):
        raise RepairTransactionError("REBASE_PROHIBITED_WITHOUT_ACTIVE_PARENT_DRIFT")
    completed = list(out.get("COMPLETED_STAGES") or [])
    # Diagnosis and the minimal patch intent survive; every validation/seal stage must rerun on the new parent.
    preserved = [s for s in completed if s in {"DIAGNOSED", "PATCHED"}]
    out["PARENT_STATE_VERSION"] = str(parent_state_version)
    out["PARENT_POINTER_FILE_ID"] = str(parent_pointer_file_id)
    out["PARENT_POINTER_SHA256"] = str(parent_pointer_sha256)
    out["PARENT_FINGERPRINT"] = new_fp
    out["EPOCH"] = int(out.get("EPOCH", 0)) + 1
    out["REBASE_COUNT"] = int(out.get("REBASE_COUNT", 0)) + 1
    out["COMPLETED_STAGES"] = preserved
    out["STAGE_COUNTS"] = {s: 1 for s in preserved}
    out["RECEIPTS"] = {k: v for k, v in dict(out.get("RECEIPTS") or {}).items() if k in preserved}
    out["UPDATED_AT_UTC"] = _utc()
    out["STATUS"] = "REBASED"
    return out


def require_ready_to_seal(tx: Mapping) -> None:
    done = list(tx.get("COMPLETED_STAGES") or [])
    if done != list(STAGES[:3]):
        raise RepairTransactionError(f"REPAIR_NOT_READY_TO_SEAL:{done}")
    if any(int(v) != 1 for v in dict(tx.get("STAGE_COUNTS") or {}).values()):
        raise RepairTransactionError("REPAIR_STAGE_COUNT_NOT_SINGLE_PASS")


def assert_single_pass(tx: Mapping) -> None:
    bad = sorted(k for k, v in dict(tx.get("STAGE_COUNTS") or {}).items() if int(v) > 1)
    if bad:
        raise RepairTransactionError("DUPLICATE_REPAIR_WORK_DETECTED:" + ",".join(bad))


def load(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_atomic(path: str | Path, tx: Mapping) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(dict(tx), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(p)
