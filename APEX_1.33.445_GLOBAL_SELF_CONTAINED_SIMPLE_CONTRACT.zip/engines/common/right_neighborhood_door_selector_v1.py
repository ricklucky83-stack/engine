from __future__ import annotations
import hashlib, json
from typing import Mapping, Sequence
import numpy as np

PATCH_ID='APEX_RIGHT_NEIGHBORHOOD_DOOR_SELECTOR_v1'
ARCHITECTURE='NEIGHBORHOOD_ADMISSION_THEN_LOCAL_DOOR_SELECTION'

def _pct(v):
    x=np.asarray(v,dtype=np.float64); n=len(x)
    if n==0:return x
    x=np.nan_to_num(x,nan=-np.inf,posinf=np.inf,neginf=-np.inf)
    order=np.argsort(x,kind='stable'); out=np.empty(n,dtype=np.float64); sv=x[order]
    i=0
    while i<n:
        j=i+1
        while j<n and sv[j]==sv[i]: j+=1
        out[order[i:j]]=((i+j-1)/2.0+0.5)/n; i=j
    return out

def neighborhood_door_order(neighborhood_keys: Sequence[object], metrics: Mapping[str,np.ndarray], weights: Mapping[str,float], *, breadth:int=32, root_fraction:float=.0025, max_interleave:int=500):
    keys=np.asarray(neighborhood_keys,dtype=object); n=len(keys)
    if n==0:return np.empty(0,dtype=np.int64), {'PATCH_ID':PATCH_ID,'ARCHITECTURE':ARCHITECTURE,'NEIGHBORHOOD_COUNT':0}
    score=np.zeros(n,dtype=np.float64); used=[]
    for name,w in weights.items():
        if name not in metrics: continue
        a=np.asarray(metrics[name],dtype=np.float64)
        if len(a)!=n: raise RuntimeError(f'RN_DOOR_METRIC_LENGTH_MISMATCH:{name}:{len(a)}:{n}')
        score += float(w)*_pct(a); used.append((name,float(w)))
    if not used: raise RuntimeError('RN_DOOR_NO_METRICS')
    labels=np.asarray([str(k) for k in keys],dtype=object)
    codes,inv=np.unique(labels,return_inverse=True); g=len(codes)
    score_pct=_pct(score); base_rank=np.empty(n,dtype=np.int64); base_rank[np.argsort(-score,kind='stable')]=np.arange(1,n+1)
    gscore=np.zeros(g); gbest=np.full(g,n+1,dtype=np.int64)
    for z in range(g):
        ix=np.flatnonzero(inv==z); vals=np.sort(score_pct[ix])[::-1]
        gscore[z]=float(vals[0]+.22*np.mean(vals[:min(3,len(vals))])+.08*np.mean(vals[:min(8,len(vals))])); gbest[z]=int(base_rank[ix].min())
    gorder=np.lexsort((codes,-gscore)); grank=np.empty(g,dtype=np.int64); grank[gorder]=np.arange(1,g+1)
    root_cut=max(50,int(np.ceil(n*float(root_fraction)))); width=max(12,min(g,int(breadth)))
    admitted=(gbest<=root_cut)|(grank<=width)
    local=np.zeros(n)
    for z in range(g):
        ix=np.flatnonzero(inv==z); local[ix]=_pct(score[ix])
    door=.70*local+.30*score_pct
    admitted_groups=[int(z) for z in gorder if admitted[z]]
    group_orders={z: np.flatnonzero(inv==z)[np.argsort(-door[np.flatnonzero(inv==z)],kind='stable')] for z in admitted_groups}
    selected=[]; remaining=set(range(n)); depth=0
    while remaining and admitted_groups and len(selected)<min(n,int(max_interleave)):
        progressed=False
        for z in admitted_groups:
            go=group_orders[z]
            if depth<len(go):
                i=int(go[depth])
                if i in remaining:selected.append(i);remaining.remove(i);progressed=True
                if len(selected)>=min(n,int(max_interleave)):break
        if not progressed:break
        depth+=1
    if remaining:
        rest=np.asarray(sorted(remaining),dtype=np.int64); rest=rest[np.lexsort((rest,-door[rest],-score[rest]))]; selected.extend(rest.tolist())
    order=np.asarray(selected,dtype=np.int64)
    receipt={'PATCH_ID':PATCH_ID,'ARCHITECTURE':ARCHITECTURE,'NEIGHBORHOOD_COUNT':int(g),'ADMITTED_NEIGHBORHOODS':int(admitted.sum()),'ROOT_CUT':int(root_cut),'BREADTH':int(width),'METRIC_WEIGHTS':used,'MC_PRIMARY_AUTHORITY':False,'GLOBAL_SINGLE_SCORE_AUTHORITY':False}
    receipt['ORDER_SHA256']=hashlib.sha256(order.tobytes()).hexdigest()
    return order,receipt
