#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, os, select, subprocess, time, fcntl
from pathlib import Path
import importlib.util, sys

_CORE_PATH = Path(__file__).with_name("apex_global_championship_core_v1.py")
_core_spec = importlib.util.spec_from_file_location("apex_global_championship_core_v1", _CORE_PATH)
if _core_spec is None or _core_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_CHAMPIONSHIP_CORE_MODULE_UNAVAILABLE")
championship_core = importlib.util.module_from_spec(_core_spec)
sys.modules.setdefault(_core_spec.name, championship_core)
_core_spec.loader.exec_module(championship_core)

# Live execution is engine-only. Terminal AI/Chat selection is not loaded.
terminal_ai = None

_ENGINE_ONLY_PATH = Path(__file__).with_name("apex_engine_only_execution_contract_v1.py")
_engine_only_spec = importlib.util.spec_from_file_location("apex_engine_only_execution_contract_v1", _ENGINE_ONLY_PATH)
if _engine_only_spec is None or _engine_only_spec.loader is None:
    raise RuntimeError("RUN_INVALID:ENGINE_ONLY_EXECUTION_CONTRACT_UNAVAILABLE")
engine_only = importlib.util.module_from_spec(_engine_only_spec)
sys.modules.setdefault(_engine_only_spec.name, engine_only)
_engine_only_spec.loader.exec_module(engine_only)

_REPORTING_PATH = Path(__file__).with_name("apex_execution_reporting_guard_v1.py")
_reporting_spec = importlib.util.spec_from_file_location("apex_execution_reporting_guard_v1", _REPORTING_PATH)
if _reporting_spec is None or _reporting_spec.loader is None:
    raise RuntimeError("RUN_INVALID:EXECUTION_REPORTING_GUARD_UNAVAILABLE")
execution_reporting_guard = importlib.util.module_from_spec(_reporting_spec)
sys.modules.setdefault(_reporting_spec.name, execution_reporting_guard)
_reporting_spec.loader.exec_module(execution_reporting_guard)

_STEP_PROOF_PATH = Path(__file__).with_name("apex_global_step_proof_gate_v1.py")
_step_proof_spec = importlib.util.spec_from_file_location("apex_global_step_proof_gate_v1", _STEP_PROOF_PATH)
if _step_proof_spec is None or _step_proof_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_STEP_PROOF_GATE_UNAVAILABLE")
global_step_proof_gate = importlib.util.module_from_spec(_step_proof_spec)
sys.modules.setdefault(_step_proof_spec.name, global_step_proof_gate)
_step_proof_spec.loader.exec_module(global_step_proof_gate)

_ROLE_PATH = Path(__file__).with_name("apex_chat_engine_role_boundary_v1.py")
_role_spec = importlib.util.spec_from_file_location("apex_chat_engine_role_boundary_v1", _ROLE_PATH)
if _role_spec is None or _role_spec.loader is None:
    raise RuntimeError("RUN_INVALID:CHAT_ENGINE_ROLE_BOUNDARY_UNAVAILABLE")
chat_role_boundary = importlib.util.module_from_spec(_role_spec)
sys.modules.setdefault(_role_spec.name, chat_role_boundary)
_role_spec.loader.exec_module(chat_role_boundary)

_RECOVERY_BOUNDARY_PATH = Path(__file__).with_name("apex_external_data_recovery_boundary_v1.py")
_recovery_spec = importlib.util.spec_from_file_location("apex_external_data_recovery_boundary_v1", _RECOVERY_BOUNDARY_PATH)
if _recovery_spec is None or _recovery_spec.loader is None:
    raise RuntimeError("RUN_INVALID:EXTERNAL_DATA_RECOVERY_BOUNDARY_UNAVAILABLE")
external_recovery = importlib.util.module_from_spec(_recovery_spec)
sys.modules.setdefault(_recovery_spec.name, external_recovery)
_recovery_spec.loader.exec_module(external_recovery)

_DURABLE_PATH = Path(__file__).with_name("apex_durable_run_ledger_v1.py")
_durable_spec = importlib.util.spec_from_file_location("apex_durable_run_ledger_v1", _DURABLE_PATH)
if _durable_spec is None or _durable_spec.loader is None:
    raise RuntimeError("RUN_INVALID:DURABLE_RUN_LEDGER_MODULE_UNAVAILABLE")
durable_run = importlib.util.module_from_spec(_durable_spec)
sys.modules.setdefault(_durable_spec.name, durable_run)
_durable_spec.loader.exec_module(durable_run)

_FAST_PATH_PATH = Path(__file__).with_name("apex_fast_path_execution_contract_v1.py")
_fast_spec = importlib.util.spec_from_file_location("apex_fast_path_execution_contract_v1", _FAST_PATH_PATH)
if _fast_spec is None or _fast_spec.loader is None:
    raise RuntimeError("RUN_INVALID:FAST_PATH_EXECUTION_CONTRACT_UNAVAILABLE")
fast_path_contract = importlib.util.module_from_spec(_fast_spec)
sys.modules.setdefault(_fast_spec.name, fast_path_contract)
_fast_spec.loader.exec_module(fast_path_contract)

_GLOBAL_PARITY_PATH = Path(__file__).with_name("apex_global_engine_parity_atomic_v1.py")
_global_parity_spec = importlib.util.spec_from_file_location("apex_global_engine_parity_atomic_v1", _GLOBAL_PARITY_PATH)
if _global_parity_spec is None or _global_parity_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_ENGINE_PARITY_MODULE_UNAVAILABLE")
global_engine_parity = importlib.util.module_from_spec(_global_parity_spec)
sys.modules.setdefault(_global_parity_spec.name, global_engine_parity)
_global_parity_spec.loader.exec_module(global_engine_parity)

_EXTERNAL_CALLER_BOUNDARY_PATH = Path(__file__).with_name("apex_global_external_caller_boundary_v1.py")
_external_caller_spec = importlib.util.spec_from_file_location("apex_global_external_caller_boundary_v1", _EXTERNAL_CALLER_BOUNDARY_PATH)
if _external_caller_spec is None or _external_caller_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_EXTERNAL_CALLER_BOUNDARY_UNAVAILABLE")
external_caller_boundary = importlib.util.module_from_spec(_external_caller_spec)
sys.modules.setdefault(_external_caller_spec.name, external_caller_boundary)
_external_caller_spec.loader.exec_module(external_caller_boundary)

_HOLDOUT_PATH = Path(__file__).with_name("apex_global_forward_holdout_capture_v1.py")
_holdout_spec = importlib.util.spec_from_file_location("apex_global_forward_holdout_capture_v1", _HOLDOUT_PATH)
if _holdout_spec is None or _holdout_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_FORWARD_HOLDOUT_CAPTURE_MODULE_UNAVAILABLE")
forward_holdout = importlib.util.module_from_spec(_holdout_spec)
sys.modules.setdefault(_holdout_spec.name, forward_holdout)
_holdout_spec.loader.exec_module(forward_holdout)



_RESUME_PATH = Path(__file__).with_name('apex_deadline_resumable_execution_v1.py')
_resume_spec = importlib.util.spec_from_file_location('apex_deadline_resumable_execution_v1', _RESUME_PATH)
if _resume_spec is None or _resume_spec.loader is None:
    raise RuntimeError('RUN_INVALID:DEADLINE_RESUMABLE_EXECUTION_MODULE_UNAVAILABLE')
resume_state = importlib.util.module_from_spec(_resume_spec)
sys.modules.setdefault(_resume_spec.name, resume_state)
_resume_spec.loader.exec_module(resume_state)

from engines.common import apex_global_contest_order_intelligence_v3 as global_order

PATCH_ID = "APEX_GLOBAL_PRODUCTION_BOARD_FIRST_NO_DIAGNOSTIC_CRITICAL_PATH_v1"
INTEGRITY_PATCH_ID = "APEX_GLOBAL_PRODUCTION_BOARD_ARTIFACT_HASH_PARITY_GATE_v1"
EXECUTION_PATH_PRIMACY_PATCH_ID = "APEX_GLOBAL_EXECUTION_PATH_PRIMACY_EFFICIENCY_STANDARD_v2"
GLOBAL_CORE5_TERMINAL_PATCH_ID = "APEX_GLOBAL_FINAL_PLAYABLE_CORE5_TERMINAL_ENFORCEMENT_v1"
GLOBAL_MAX_ENTRY_TERMINAL_PATCH_ID = "APEX_GLOBAL_MAX_ENTRY_FINAL_PORTFOLIO_MEMBERSHIP_v1"
GLOBAL_FINAL_PLAYABLE_BOARD_SIZE = 5
CFB_SHOWDOWN_LIVE_EXECUTION_HARD_CONTRACT_PATCH_ID = "CFB_SHOWDOWN_LIVE_EXECUTION_HARD_CONTRACT_v1"
MLB_SHOWDOWN_STRUCTURAL_COHERENCE_SEAL_PATCH_ID = "MLB_SD_FINAL_BOARD_STRUCTURAL_COHERENCE_SEAL_v1"
FAST_PATH_CORRECTIVE_PATCH_ID = "APEX_GLOBAL_FAST_PATH_STALL_AND_TERMINAL_PARITY_CORRECTIVE_ACTION_v1"
FINAL_BOARD_FIRST_STATS_SECOND_PATCH_ID = "APEX_GLOBAL_FINAL_BOARD_FIRST_STATS_SECOND_SOURCE_PROVENANCE_HARD_GATE_v1"
BOARD_FIRST_USER_VISIBLE_HARD_GATE_ID = "APEX_GLOBAL_BOARD_FIRST_USER_VISIBLE_HARD_GATE_v1"
LIVE_NO_AUDIT_DIAGNOSTIC_TEST_PATCH_ID = "APEX_GLOBAL_LIVE_RUN_NO_AUDIT_DIAGNOSTIC_TEST_HARD_CORRECTIVE_ACTION_v1"
COMPLETED_BOARD_RECOVERY_PATCH_ID = "APEX_GLOBAL_COMPLETED_BOARD_RECOVERY_BEFORE_FAILURE_v1"
RUN_UNTIL_BOARD_PATCH_ID = "APEX_GLOBAL_RUN_UNTIL_BOARD_OR_TRUE_RUN_INVALID_v1"
AUTONOMOUS_SUPERVISOR_PATCH_ID = "APEX_GLOBAL_SINGLE_FLIGHT_AUTONOMOUS_SUPERVISOR_v1"
TERMINAL_SURFACE_SUCCESS_DOMINANCE_PATCH_ID = "APEX_GLOBAL_VALID_TERMINAL_SURFACE_SUCCESS_DOMINANCE_v1"
GLOBAL_CHUNK_STREAM_PATCH_ID = "APEX_GLOBAL_CHUNK_STREAM_ONLY_EXECUTION_v3"
HYBRID_SELECTOR_LAST_STEP_FENCE_PATCH_ID = "APEX_GLOBAL_HYBRID_SELECTOR_LAST_STEP_EXECUTION_FENCE_v1"
HYBRID_SELECTOR_HANDOFF_RETURN_CODE = 42
ENGINE_OWNED_TERMINAL_AUTHORITY_PATCH_ID = "APEX_GLOBAL_ENGINE_OWNED_TERMINAL_AUTHORITY_RESET_v1"
GLOBAL_STEP_PROOF_GATE_PATCH_ID = "APEX_GLOBAL_STEP_PROOF_GATE_v1"
END_TO_END_ENGINE_OWNERSHIP_PATCH_ID = "APEX_GLOBAL_END_TO_END_ENGINE_OWNERSHIP_HARD_FENCE_v1"

class BoardSealError(RuntimeError):
    pass


def _completed_board_receipt_candidates(output_dir: Path, sport: str, mode: str, execution_id: str) -> list[Path]:
    """Return newest exact-slate completion receipts without scanning unrelated state files."""
    s=str(sport).upper().replace(" ","_"); m=str(mode).upper().replace(" ","_"); x=str(execution_id)
    exact=f"DK_{s}_{m}_{x}_FINAL_RECEIPT.json"
    found=[]
    direct=output_dir/exact
    if direct.exists(): found.append(direct)
    # Sport runtimes commonly write one slate subdirectory below the requested output dir.
    for q in output_dir.glob(f"*/{exact}"):
        if q not in found: found.append(q)
    return sorted(found,key=lambda q:q.stat().st_mtime_ns if q.exists() else 0,reverse=True)

def _recover_completed_same_slate_board(*, output_dir: Path, sport: str, mode: str, execution_id: str, env: dict) -> dict|None:
    """Recover a previously completed exact-slate board before any rerun.

    This is intentionally stricter than stale-board reuse: the receipt must prove
    BOARD_READY + TOOL_PROVEN_EXECUTED, exact sport/mode/execution-id, current pool
    hash parity when available, and exact board-file hash parity.
    """
    pool_path=env.get('APEX_ORIGINAL_PLAYER_POOL') or env.get('APEX_PLAYER_POOL')
    pool_sha=None
    if pool_path and Path(pool_path).exists():
        try: pool_sha=_sha256_file(Path(pool_path))
        except Exception: pool_sha=None
    expected_state=str(env.get('APEX_GLOBAL_STATE_VERSION') or '').strip()
    for receipt_path in _completed_board_receipt_candidates(output_dir,sport,mode,execution_id):
        try:
            receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
            if str(receipt.get('RUN_STATE','')).upper()!='BOARD_READY': continue
            if str(receipt.get('EXECUTION_STATE','')).upper()!='TOOL_PROVEN_EXECUTED': continue
            if str(receipt.get('SPORT','')).upper()!=str(sport).upper(): continue
            if str(receipt.get('MODE','')).upper()!=str(mode).upper(): continue
            if str(receipt.get('EXECUTION_ID',''))!=str(execution_id): continue
            if str(sport).upper()=='CFB' and str(mode).upper()=='SHOWDOWN':
                if receipt.get('CFB_SHOWDOWN_MAX_ENTRY_PORTFOLIO_PASSTHROUGH') is not True:
                    continue
            if expected_state and receipt.get('GLOBAL_STATE_VERSION') and str(receipt.get('GLOBAL_STATE_VERSION'))!=expected_state: continue
            if pool_sha and receipt.get('POOL_SHA256') and str(receipt.get('POOL_SHA256'))!=pool_sha: continue
            board_sha=str(receipt.get('BOARD_SHA256') or receipt.get('BOARD_ARTIFACT_SHA256') or '').strip()
            board_candidates=[]
            for key in ('FINAL_BOARD_PATH','BOARD_ARTIFACT_PATH'):
                raw=receipt.get(key)
                if raw: board_candidates.append(Path(str(raw)))
            sibling=receipt_path.with_name(receipt_path.name.replace('_FINAL_RECEIPT.json','_FINAL_BOARD.csv'))
            board_candidates.append(sibling)
            board_path=None
            for q in board_candidates:
                if q.exists() and q.is_file() and 'PREVALIDATION' not in q.name.upper():
                    if board_sha and _sha256_file(q)!=board_sha: continue
                    board_path=q; break
            if board_path is None: continue
            rows=_load_board(board_path)
            if not rows: continue
            declared=receipt.get('FINAL_BOARD_SIZE')
            if declared is not None and int(declared)!=len(rows): continue
            return {
                'RUN_STATE':'BOARD_READY',
                'EXECUTION_STATE':'TOOL_PROVEN_EXECUTED',
                'PATCH_ID':COMPLETED_BOARD_RECOVERY_PATCH_ID,
                'SPORT':str(sport).upper(),'MODE':str(mode).upper(),'EXECUTION_ID':str(execution_id),
                'FINAL_BOARD_SIZE':len(rows),'FINAL_BOARD':rows,
                'RECOVERED_COMPLETED_SAME_SLATE_ARTIFACT':True,
                'NO_RERUN':True,
                'RECOVERY_REASON':'VERIFIED_COMPLETED_BOARD_FOUND_BEFORE_PROCESS_LAUNCH',
                'BOARD_ARTIFACT_PATH':str(board_path),
                'BOARD_ARTIFACT_SHA256':_sha256_file(board_path),
                'PRODUCTION_RECEIPT_PATH':str(receipt_path),
                'PRODUCTION_RECEIPT_SHA256':_sha256_file(receipt_path),
                'POOL_SHA256':receipt.get('POOL_SHA256'),
                'GLOBAL_STATE_VERSION':receipt.get('GLOBAL_STATE_VERSION'),
                'MACHINE_BOARD_PARITY':'PASS',
            }
        except Exception:
            continue
    return None



def _preload_rebase_proven_active_legacy_root(*, base: Path, run_id: str, state_version: str,
                                               player_pool_sha256: str, engine_sha256: str,
                                               sport: str, mode: str, execution_id: str,
                                               env: dict[str, str]) -> dict:
    """Rebase an already restored legacy root across one promoted state version without quarantine."""
    if str(env.get('APEX_LEGACY_RESUME_MIGRATION_ALLOWED','0')).strip() != '1':
        return {'STATUS':'NOT_REQUESTED'}
    active_root=(Path(base)/resume_state.safe_run_id(run_id)).resolve()
    expected_checkpoint=str(env.get('APEX_LEGACY_RESUME_EXPECTED_CHECKPOINT') or '').strip()
    expected_checkpoint_sha=str(env.get('APEX_LEGACY_RESUME_EXPECTED_CHECKPOINT_SHA256') or '').strip().lower()
    expected_pool_sha=str(env.get('APEX_LEGACY_RESUME_EXPECTED_POOL_SHA256') or '').strip().lower()
    expected_old_state=str(env.get('APEX_LEGACY_RESUME_EXPECTED_CONTROLLER_STATE_VERSION') or '').strip()
    original_pool_raw=str(env.get('APEX_ORIGINAL_PLAYER_POOL') or env.get('APEX_PROVIDER_PLAYER_POOL') or env.get('APEX_PLAYER_POOL') or '').strip()
    if not active_root.exists() or not all((expected_checkpoint,expected_checkpoint_sha,expected_pool_sha,original_pool_raw)):
        return {'STATUS':'ACTIVE_ROOT_PROOF_INCOMPLETE'}
    original_pool=Path(original_pool_raw)
    if not original_pool.exists() or _sha256_file(original_pool).lower()!=expected_pool_sha:
        return {'STATUS':'ORIGINAL_POOL_SHA_MISMATCH'}
    session_path=active_root/'.session_state.json'
    controller_path=active_root/'generic_chunk_nfl_classic'/'controller_state.json'
    if not session_path.exists() or not controller_path.exists():
        return {'STATUS':'ACTIVE_LEGACY_STATE_FILES_MISSING'}
    try:
        session=json.loads(session_path.read_text(encoding='utf-8'))
        controller=json.loads(controller_path.read_text(encoding='utf-8'))
    except Exception:
        return {'STATUS':'ACTIVE_LEGACY_STATE_PARSE_FAILED'}
    restore=dict(session.get('LEGACY_ROOT_RESTORE') or {})
    if str(restore.get('STATUS') or '')!='PROVEN_PRELOAD_RESTORE':
        return {'STATUS':'ACTIVE_ROOT_NOT_PROVEN_RESTORED_LEGACY'}
    ident=dict(controller.get('IDENTITY') or {})
    if expected_old_state and str(ident.get('STATE_VERSION') or '')!=expected_old_state:
        return {'STATUS':'LEGACY_CONTROLLER_STATE_VERSION_MISMATCH'}
    if str(ident.get('SPORT') or '').upper()!=str(sport).upper() or str(ident.get('MODE') or '').upper()!=str(mode).upper():
        return {'STATUS':'LEGACY_CONTROLLER_COORDINATE_MISMATCH'}
    checkpoint=Path(expected_checkpoint).resolve()
    try: checkpoint.relative_to(active_root)
    except Exception: return {'STATUS':'EXPECTED_CHECKPOINT_NOT_UNDER_ACTIVE_ROOT'}
    if not checkpoint.exists() or _sha256_file(checkpoint).lower()!=expected_checkpoint_sha:
        return {'STATUS':'ACTIVE_LEGACY_CHECKPOINT_SHA_MISMATCH'}
    if str(controller.get('CHECKPOINT') or '')!=str(checkpoint):
        return {'STATUS':'ACTIVE_LEGACY_CHECKPOINT_LOGICAL_PATH_MISMATCH'}
    session.update({
        'STATE_VERSION':str(state_version),'PLAYER_POOL_SHA256':str(player_pool_sha256),'ENGINE_SHA256':str(engine_sha256),
        'IDENTITY_SIGNATURE':resume_state.identity_signature(run_id=run_id,state_version=state_version,player_pool_sha256=player_pool_sha256,engine_sha256=engine_sha256),
        'CURRENT_PHASE':'LEGACY_ACTIVE_ROOT_REBASED_PRELOAD','EXECUTION_STATE':'RESUMABLE',
        'LEGACY_ACTIVE_ROOT_REBASE':{
            'STATUS':'PROVEN_ACTIVE_ROOT_REBASE','PRIOR_SESSION_STATE_VERSION':str(session.get('STATE_VERSION') or ''),
            'NEW_STATE_VERSION':str(state_version),'CHECKPOINT':str(checkpoint),'CHECKPOINT_SHA256':expected_checkpoint_sha,
            'ORIGINAL_POOL_SHA256':expected_pool_sha,'SPORT':str(sport).upper(),'MODE':str(mode).upper(),'EXECUTION_ID':str(execution_id),
        },
    })
    resume_state.atomic_json(session_path,session)
    return {'STATUS':'PROVEN_ACTIVE_ROOT_REBASE','ACTIVE_ROOT':str(active_root),'CHECKPOINT':str(checkpoint),'CHECKPOINT_SHA256':expected_checkpoint_sha}

def _preload_restore_proven_legacy_run_root(*, base: Path, run_id: str, state_version: str,
                                             player_pool_sha256: str, engine_sha256: str,
                                             sport: str, mode: str, execution_id: str,
                                             env: dict[str, str]) -> dict:
    """Restore one exact quarantined legacy run before load_or_initialize can stale it again.

    This is recovery-only control-plane logic. It never edits checkpoint payload bytes and
    it never merges a restarted run with the legacy run. A current restart, if present, is
    quarantined separately before the proven legacy root is atomically restored.
    """
    if str(env.get('APEX_LEGACY_RESUME_MIGRATION_ALLOWED','0')).strip() != '1':
        return {'STATUS':'NOT_REQUESTED'}
    stale_raw=str(env.get('APEX_LEGACY_RESUME_EXPECTED_STALE_ROOT') or '').strip()
    expected_checkpoint=str(env.get('APEX_LEGACY_RESUME_EXPECTED_CHECKPOINT') or '').strip()
    expected_checkpoint_sha=str(env.get('APEX_LEGACY_RESUME_EXPECTED_CHECKPOINT_SHA256') or '').strip().lower()
    expected_pool_sha=str(env.get('APEX_LEGACY_RESUME_EXPECTED_POOL_SHA256') or '').strip().lower()
    expected_old_state=str(env.get('APEX_LEGACY_RESUME_EXPECTED_CONTROLLER_STATE_VERSION') or '').strip()
    original_pool_raw=str(env.get('APEX_ORIGINAL_PLAYER_POOL') or env.get('APEX_PROVIDER_PLAYER_POOL') or env.get('APEX_PLAYER_POOL') or '').strip()
    if not all((stale_raw, expected_checkpoint, expected_checkpoint_sha, expected_pool_sha, original_pool_raw)):
        return {'STATUS':'PROOF_INCOMPLETE'}
    stale_root=Path(stale_raw).resolve()
    active_root=(Path(base)/resume_state.safe_run_id(run_id)).resolve()
    base_resolved=Path(base).resolve()
    try:
        stale_root.relative_to(base_resolved)
        active_root.relative_to(base_resolved)
    except Exception:
        return {'STATUS':'PATH_OUTSIDE_RESUME_BASE'}
    if stale_root == active_root or not stale_root.exists() or not stale_root.is_dir():
        return {'STATUS':'STALE_ROOT_MISSING'}
    if not stale_root.name.startswith(active_root.name + '.stale.'):
        return {'STATUS':'STALE_ROOT_NAME_MISMATCH'}
    original_pool=Path(original_pool_raw)
    if not original_pool.exists() or _sha256_file(original_pool).lower()!=expected_pool_sha:
        return {'STATUS':'ORIGINAL_POOL_SHA_MISMATCH'}
    session_path=stale_root/'.session_state.json'
    controller_path=stale_root/'generic_chunk_nfl_classic'/'controller_state.json'
    if not session_path.exists() or not controller_path.exists():
        return {'STATUS':'LEGACY_STATE_FILES_MISSING'}
    try:
        session=json.loads(session_path.read_text(encoding='utf-8'))
        controller=json.loads(controller_path.read_text(encoding='utf-8'))
    except Exception:
        return {'STATUS':'LEGACY_STATE_PARSE_FAILED'}
    ident=dict(controller.get('IDENTITY') or {})
    same_coords=(
        str(ident.get('SPORT') or '').upper()==str(sport).upper() and
        str(ident.get('MODE') or '').upper()==str(mode).upper() and
        str(ident.get('TARGET_SOURCE') or '')=='engines/nfl/nfl_classic_raw_pool_runtime_v1.py' and
        str(ident.get('TARGET_FUNCTION') or '')=='run'
    )
    if not same_coords:
        return {'STATUS':'LEGACY_CONTROLLER_COORDINATE_MISMATCH'}
    if expected_old_state and (str(ident.get('STATE_VERSION') or '')!=expected_old_state or str(session.get('STATE_VERSION') or '')!=expected_old_state):
        return {'STATUS':'LEGACY_STATE_VERSION_MISMATCH'}
    logical_checkpoint=Path(expected_checkpoint).resolve()
    try:
        rel_checkpoint=logical_checkpoint.relative_to(active_root)
    except Exception:
        return {'STATUS':'EXPECTED_CHECKPOINT_NOT_UNDER_ACTIVE_ROOT'}
    physical_checkpoint=stale_root/rel_checkpoint
    if not physical_checkpoint.exists() or _sha256_file(physical_checkpoint).lower()!=expected_checkpoint_sha:
        return {'STATUS':'LEGACY_CHECKPOINT_SHA_MISMATCH'}
    if str(controller.get('CHECKPOINT') or '') != str(logical_checkpoint):
        return {'STATUS':'LEGACY_CHECKPOINT_LOGICAL_PATH_MISMATCH'}
    aborted_restart=None
    if active_root.exists():
        meaningful=any(active_root.iterdir())
        if meaningful:
            aborted_restart=active_root.with_name(active_root.name+f'.aborted_restart.{time.time_ns()}')
            os.replace(active_root,aborted_restart)
        else:
            active_root.rmdir()
    os.replace(stale_root,active_root)
    restored_session=json.loads((active_root/'.session_state.json').read_text(encoding='utf-8'))
    restored_session.update({
        'STATE_VERSION':str(state_version),
        'PLAYER_POOL_SHA256':str(player_pool_sha256),
        'ENGINE_SHA256':str(engine_sha256),
        'IDENTITY_SIGNATURE':resume_state.identity_signature(run_id=run_id,state_version=state_version,player_pool_sha256=player_pool_sha256,engine_sha256=engine_sha256),
        'CURRENT_PHASE':'LEGACY_ROOT_RESTORED_PRELOAD',
        'EXECUTION_STATE':'RESUMABLE',
        'LEGACY_ROOT_RESTORE':{
            'STATUS':'PROVEN_PRELOAD_RESTORE',
            'SOURCE_STALE_ROOT':str(stale_root),
            'EXPECTED_CHECKPOINT':str(logical_checkpoint),
            'CHECKPOINT_SHA256':expected_checkpoint_sha,
            'ORIGINAL_POOL_SHA256':expected_pool_sha,
            'PRIOR_STATE_VERSION':expected_old_state,
            'NEW_STATE_VERSION':str(state_version),
            'SPORT':str(sport).upper(),'MODE':str(mode).upper(),'EXECUTION_ID':str(execution_id),
            'ABORTED_RESTART_ROOT':str(aborted_restart) if aborted_restart else None,
        },
    })
    resume_state.atomic_json(active_root/'.session_state.json',restored_session)
    return {
        'STATUS':'PROVEN_PRELOAD_RESTORE',
        'ACTIVE_ROOT':str(active_root),
        'CHECKPOINT':str(active_root/rel_checkpoint),
        'CHECKPOINT_SHA256':expected_checkpoint_sha,
        'ABORTED_RESTART_ROOT':str(aborted_restart) if aborted_restart else None,
    }

def _strict_core5_terminal_contract(sport: str, mode: str) -> tuple[bool, str, str]:
    # Global production authority: contest MAX ENTRY caps final playable
    # membership. Core5 may remain an internal quality/order concept, but it
    # cannot evict engine-selected rows from the final playable portfolio.
    s = str(sport).upper(); m = str(mode).upper()
    return False, GLOBAL_MAX_ENTRY_TERMINAL_PATCH_ID, f"{s}_{m}"

def _global_max_entry_cap(source_count: int) -> int:
    # APEX_MLB_SD_MAX_ENTRY_METADATA_ONLY_v1
    # Retained only as a compatibility helper. MAX ENTRY has no authority to
    # cap a production surface; always return the complete engine-owned source.
    return int(source_count)

def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def _canonical_run_identity(*, state_token: str, pool_sha256: str, engine_sha256: str,
                            platform: str, sport: str, mode: str, execution_id: str) -> str:
    # Live startup identity is intentionally control-plane-hash-free.  The reset
    # contract prohibits bundle/pool/engine hash gates before execution.
    raw = f"{platform}_{sport}_{mode}_{execution_id}_{state_token}"
    out = "".join(c if (c.isalnum() or c in "-_") else "_" for c in raw)
    return out[:180] or "APEX_RUN"


def _acquire_single_flight_lease(*, base: Path, run_identity: str):
    """Block on an exact-run lease; the surviving owner resumes/reuses the same run state."""
    lease_dir = base / ".single_flight_leases"
    lease_dir.mkdir(parents=True, exist_ok=True)
    lease_path = lease_dir / f"{run_identity}.lock"
    handle = lease_path.open("a+", encoding="utf-8")
    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
    handle.seek(0); handle.truncate(0)
    handle.write(json.dumps({
        "PATCH_ID": AUTONOMOUS_SUPERVISOR_PATCH_ID,
        "RUN_IDENTITY": run_identity,
        "OWNER_PID": os.getpid(),
    }, sort_keys=True) + "\n")
    handle.flush(); os.fsync(handle.fileno())
    return handle, lease_path


def _progress_fingerprint(*, return_code: int, failure_code: str, terminal_obj: object,
                          resume_state_obj: dict, candidate: Path | None) -> str:
    candidate_sig = _signature(candidate) if candidate is not None and candidate.exists() else None
    stable = {
        "RETURN_CODE": int(return_code),
        "FAILURE_CODE": str(failure_code),
        "TERMINAL": terminal_obj if isinstance(terminal_obj, dict) else {},
        "CURRENT_PHASE": str(resume_state_obj.get("CURRENT_PHASE", "")),
        "ENGINE_OWNED_CHECKPOINT": str(resume_state_obj.get("ENGINE_OWNED_CHECKPOINT", "")),
        "ENGINE_OWNED_CONTROLLER_STATE": str(resume_state_obj.get("ENGINE_OWNED_CONTROLLER_STATE", "")),
        "ENGINE_OWNED_STAGE_INDEX": int(resume_state_obj.get("ENGINE_OWNED_STAGE_INDEX", 0) or 0),
        "CANDIDATE_SIGNATURE": candidate_sig,
    }
    return hashlib.sha256(json.dumps(stable, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()


def _terminal_candidate_surface(pending_native_board: dict, *, sport: str, mode: str,
                                execution_id: str, output_dir: Path) -> tuple[list[dict], str, dict]:
    raise BoardSealError("RUN_INVALID:AI_CHAT_TERMINAL_SURFACE_PATH_REMOVED_ENGINE_ONLY")

def _engine_internal_terminal_decision(*args, **kwargs):
    raise BoardSealError("RUN_INVALID:NON_ENGINE_TERMINAL_DECISION_PROHIBITED")

def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    tmp.write_bytes(data)
    os.replace(tmp, path)

def _canonical_json_bytes(obj: object) -> bytes:
    return (json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")

def _validated_rows(rows: object, declared_size: object | None = None) -> list[dict]:
    if not isinstance(rows, list) or not rows:
        raise BoardSealError("FINAL_BOARD_ROWS_MISSING")
    if not all(isinstance(row, dict) for row in rows):
        raise BoardSealError("FINAL_BOARD_ROWS_NOT_OBJECTS")
    if declared_size is not None:
        try:
            d = int(declared_size)
        except Exception as exc:
            raise BoardSealError("FINAL_BOARD_SIZE_INVALID") from exc
        if d != len(rows):
            raise BoardSealError(f"FINAL_BOARD_SIZE_MISMATCH:{d}:{len(rows)}")
    return rows

def _board_payload_hash(rows: list[dict]) -> str:
    payload = {"FINAL_BOARD_SIZE": len(rows), "FINAL_BOARD": rows}
    return _sha256_bytes(_canonical_json_bytes(payload))


def _render_board_before_validation(*, rows: list[dict], sport: str, mode: str, execution_id: str, output_dir: Path) -> dict:
    raise BoardSealError("RUN_INVALID:PREVALIDATION_BOARD_RENDER_REMOVED_ENGINE_ONLY")

def _postboard_invalid(*, sport: str, mode: str, execution_id: str, failure_code: str, board_artifact: dict|None=None) -> int:
    raise BoardSealError("RUN_INVALID:POSTBOARD_AI_VALIDATION_PATH_REMOVED_ENGINE_ONLY")

def _recursive_paths(obj: object, wanted_keys: set[str]) -> list[str]:
    out=[]
    if isinstance(obj,dict):
        for k,v in obj.items():
            if str(k).upper() in wanted_keys and isinstance(v,(str,Path)) and str(v): out.append(str(v))
            out.extend(_recursive_paths(v,wanted_keys))
    elif isinstance(obj,list):
        for v in obj: out.extend(_recursive_paths(v,wanted_keys))
    return out


def _prepare_global_full_handoff_ai_surface(obj: dict, *, sport: str, mode: str, execution_id: str, output_dir: Path) -> dict:
    raise BoardSealError("RUN_INVALID:AI_CHAT_HANDOFF_ADAPTER_REMOVED_ENGINE_ONLY")

def _row_lineup_id(row: dict, ordinal: int) -> str:
    if row.get("LINEUP_ID") not in (None, ""):
        return str(row["LINEUP_ID"])
    payload={k:v for k,v in row.items() if str(k).upper() not in {"RANK","FINAL_RANK","SELECTED","REJECTED","REJECTION_REASON"}}
    raw=_canonical_json_bytes(payload)
    return "L"+hashlib.sha256(raw).hexdigest()[:20]

def _write_terminal_selector_ledger(*, source_rows: list[dict] | None, final_rows: list[dict],
                                    execution_id: str, output_dir: Path, stem: str,
                                    preverified_source_hash: str|None=None, source_csv: Path|None=None) -> dict:
    if source_csv is None and source_rows is None: raise BoardSealError("TERMINAL_SELECTOR_SOURCE_MISSING")
    source_hash=str(preverified_source_hash or _board_payload_hash(source_rows or []))
    run_artifact_id=hashlib.sha256(f"{execution_id}|{source_hash}|{_board_payload_hash(final_rows)}".encode("utf-8")).hexdigest()
    final_ids=[_row_lineup_id(r,i) for i,r in enumerate(final_rows)]; final_set=set(final_ids); final_rank={lid:i+1 for i,lid in enumerate(final_ids)}
    ledger_path=output_dir/f"{stem}_TERMINAL_SELECTOR_LEDGER.csv"; selected=[]; row_count=0
    with ledger_path.open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=["RUN_ARTIFACT_ID","EXECUTION_ID","LINEUP_ID","SOURCE_ORDINAL","SELECTED","FINAL_RANK"]); w.writeheader()
        if source_csv is not None:
            with Path(source_csv).open("r",encoding="utf-8-sig",newline="") as sf:
                iterator=csv.DictReader(sf)
                for i,row in enumerate(iterator):
                    lid=_row_lineup_id(dict(row),i); sel=lid in final_set; row_count+=1
                    w.writerow({"RUN_ARTIFACT_ID":run_artifact_id,"EXECUTION_ID":str(execution_id),"LINEUP_ID":lid,"SOURCE_ORDINAL":i+1,
                        "SELECTED":sel,"FINAL_RANK":final_rank.get(lid,0)})
                    if sel: selected.append((final_rank[lid],lid))
        else:
            for i,row in enumerate(source_rows or []):
                lid=_row_lineup_id(row,i); sel=lid in final_set; row_count+=1
                w.writerow({"RUN_ARTIFACT_ID":run_artifact_id,"EXECUTION_ID":str(execution_id),"LINEUP_ID":lid,"SOURCE_ORDINAL":i+1,
                    "SELECTED":sel,"FINAL_RANK":final_rank.get(lid,0)})
                if sel:selected.append((final_rank[lid],lid))
    selected_ids=[lid for _,lid in sorted(selected)]
    if len(selected_ids)!=len(final_rows) or selected_ids!=final_ids: raise BoardSealError("TERMINAL_SELECTOR_BOARD_LINEUP_ID_MISMATCH")
    return {"PATCH_ID":FAST_PATH_CORRECTIVE_PATCH_ID,"RUN_ARTIFACT_ID":run_artifact_id,"PATH":str(ledger_path),"SHA256":_sha256_file(ledger_path),
        "ROWS":row_count,"SELECTED_ROWS":len(selected_ids),"SELECTED_LINEUP_IDS":selected_ids,"BOARD_LINEUP_IDS":final_ids,
        "TERMINAL_ARTIFACT_RECONCILIATION":"PASS","STREAMED_SOURCE_LEDGER":source_csv is not None}

def _verify_source_terminal_reconciliation(obj: dict) -> dict:
    # Enforce native same-run selector/board parity when a sport runtime emits
    # the hard terminal reconciliation contract (WNBA Classic v1.33.94+).
    if obj.get("TERMINAL_ARTIFACT_RECONCILIATION") != "PASS":
        return {"STATUS":"NOT_DECLARED_LEGACY_SOURCE"}
    ledger_path=Path(str(obj.get("SELECTOR_LEDGER_PATH") or ""))
    expected_sha=str(obj.get("SELECTOR_LEDGER_SHA256") or "")
    run_id=str(obj.get("RUN_ARTIFACT_ID") or "")
    rows=_validated_rows(obj.get("FINAL_BOARD"), obj.get("FINAL_BOARD_SIZE"))
    board_ids=[str(r.get("LINEUP_ID") or "") for r in rows]
    if not ledger_path.exists() or not expected_sha or _sha256_file(ledger_path)!=expected_sha:
        raise BoardSealError("SOURCE_SELECTOR_LEDGER_HASH_OR_PATH_FAILURE")
    with ledger_path.open("r",encoding="utf-8-sig",newline="") as f:
        ledger=list(csv.DictReader(f))
    selected=[]; ledger_run_ids=set()
    for r in ledger:
        val=str(r.get("SELECTED","")).strip().lower()
        if val in {"1","true","yes","y"}:
            selected.append(str(r.get("LINEUP_ID") or ""))
            ledger_run_ids.add(str(r.get("RUN_ARTIFACT_ID") or ""))
    if len(selected)!=len(rows):
        raise BoardSealError(f"SOURCE_SELECTOR_SELECTED_COUNT_MISMATCH:{len(selected)}:{len(rows)}")
    if selected!=board_ids:
        raise BoardSealError("SOURCE_SELECTOR_BOARD_LINEUP_ID_MISMATCH")
    if not run_id or ledger_run_ids!={run_id}:
        raise BoardSealError("SOURCE_SELECTOR_RUN_ARTIFACT_ID_MISMATCH")
    if int(obj.get("SELECTED_LEDGER_ROWS",-1))!=len(rows):
        raise BoardSealError("SOURCE_SELECTOR_DECLARED_SELECTED_COUNT_MISMATCH")
    return {"STATUS":"PASS","RUN_ARTIFACT_ID":run_id,"SELECTED_ROWS":len(selected),"LEDGER_SHA256":expected_sha}

def _validate_mlb_showdown_structural_coherence(rows: list[dict], *, stage: str) -> dict:
    """Fail-closed terminal duplicate of MLB Showdown structural conflict gates.

    This intentionally validates machine-emitted metadata instead of trying to
    reconstruct teams/roles from display names.  Missing metadata is therefore
    itself an integrity failure for a production MLB Showdown board.
    """
    required = (
        "SP_COUNT", "CPT_IS_SP", "OPPOSING_HITTERS_VS_SOLE_SP",
        "MAX_OPPOSING_HITTERS_VS_ROSTERED_SP", "SELF_CONFLICT_SEVERITY",
        "SIDE_COMMITMENT_SEVERITY",
    )
    checked = 0
    for i, row in enumerate(rows, 1):
        missing = [k for k in required if k not in row]
        if missing:
            raise BoardSealError(
                f"MLB_SD_STRUCTURAL_COHERENCE_METADATA_MISSING:{stage}:ROW={i}:FIELDS={','.join(missing)}"
            )
        try:
            sp_count = int(row["SP_COUNT"])
            cpt_is_sp_raw = row["CPT_IS_SP"]
            if isinstance(cpt_is_sp_raw, str):
                cpt_is_sp = cpt_is_sp_raw.strip().lower() in {"1", "true", "yes", "y"}
            else:
                cpt_is_sp = bool(cpt_is_sp_raw)
            opp_sole = int(row["OPPOSING_HITTERS_VS_SOLE_SP"])
            max_opp = int(row["MAX_OPPOSING_HITTERS_VS_ROSTERED_SP"])
        except Exception as exc:
            raise BoardSealError(f"MLB_SD_STRUCTURAL_COHERENCE_METADATA_INVALID:{stage}:ROW={i}") from exc
        self_sev = str(row["SELF_CONFLICT_SEVERITY"]).upper()
        side_sev = str(row["SIDE_COMMITMENT_SEVERITY"]).upper()
        # Exact standing engine gates duplicated at terminal render boundary.
        if "HARD_REJECT" in self_sev or "HARD_REJECT" in side_sev:
            raise BoardSealError(f"MLB_SD_STRUCTURAL_HARD_REJECT_SURVIVED:{stage}:ROW={i}")
        if max_opp >= 5:
            raise BoardSealError(f"MLB_SD_OPPOSING_SP_PLUS_FIVE_HITTERS_REJECT:{stage}:ROW={i}")
        if sp_count == 1 and cpt_is_sp and opp_sole >= 3:
            raise BoardSealError(f"MLB_SD_SOLE_SP_CPT_3PLUS_OPPOSING_HITTERS_REJECT:{stage}:ROW={i}")
        if sp_count == 1 and (not cpt_is_sp) and opp_sole >= 4:
            raise BoardSealError(f"MLB_SD_SOLE_SP_4PLUS_OPPOSING_HITTERS_REJECT:{stage}:ROW={i}")
        checked += 1
    return {
        "PATCH_ID": MLB_SHOWDOWN_STRUCTURAL_COHERENCE_SEAL_PATCH_ID,
        "STATUS": "PASS",
        "STAGE": stage,
        "ROWS_CHECKED": checked,
        "MISSING_METADATA_FAILS_CLOSED": True,
        "OPPOSING_SP_PLUS_FIVE_HITTERS_ALLOWED": False,
    }


def _first_numeric(row: dict, *keys: str) -> float:
    for key in keys:
        v=row.get(key)
        try:
            if v is not None and str(v).strip() != "":
                x=float(v)
                if math.isfinite(x):
                    return x
        except Exception:
            pass
    return float("nan")


def _global_ordinal_full_surface(rows: list[dict], *, sport: str, mode: str) -> tuple[list[dict], dict]:
    if not rows:
        raise BoardSealError("RUN_INVALID:ZERO_DOT00001_QUALIFIERS")
    metrics={
        "top01_lcb":[_first_numeric(r,"MC_TOP_0_1_LCB","BASE_MC_TOP_0_1_LCB","MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01_RATE") for r in rows],
        "win_rate":[_first_numeric(r,"MC_WIN_LCB","BASE_MC_WIN_LCB","MC_WIN_RATE","BASE_MC_WIN_RATE","WIN_RATE") for r in rows],
        "p99":[_first_numeric(r,"MC_P99","BASE_MC_P99","P99") for r in rows],
        "p95":[_first_numeric(r,"MC_P95","BASE_MC_P95","P95") for r in rows],
        "rank_uncertainty_width":[_first_numeric(r,"GLOBAL_ORDER_UNCERTAINTY_WIDTH","AI_TOP01_95_HALF_WIDTH","RANK_UNCERTAINTY_WIDTH") for r in rows],
    }
    result=global_order.rank_surface(
        metrics,sport=sport,mode=mode,
        sport_native_score=[_first_numeric(r,"SPORT_NATIVE_ORDER_SCORE","STRATEGY_SCORE","SELECT_SCORE") for r in rows],
        world_breadth=[_first_numeric(r,"WORLD_COVERAGE","WORLD_COVERAGE_COUNT","FAST_PATH_WORLD_COVERAGE_RATE") for r in rows],
        rank_stability=[_first_numeric(r,"RANK_STABILITY","CROSS_SEED_STABILITY","CALIBRATION_STABILITY") for r in rows],
        projected_duplication=[_first_numeric(r,"PROJECTED_EXACT_MATCH_DUPLICATION","DUP") for r in rows],
        expected_rank=[_first_numeric(r,"AI_EXPECTED_CONTEST_RANK","EXPECTED_RANK","POSTERIOR_EXPECTED_RANK") for r in rows],
        median_rank=[_first_numeric(r,"AI_MEDIAN_CONTEST_RANK","MEDIAN_RANK","POSTERIOR_MEDIAN_RANK") for r in rows],
        rank_p90=[_first_numeric(r,"AI_CONTEST_RANK_P90","RANK_P90","POSTERIOR_RANK_P90") for r in rows],
        pairwise_strength=[_first_numeric(r,"AI_PAIRWISE_ORDER_STRENGTH","PAIRWISE_STRENGTH","PAIRWISE_BEAT_PROB") for r in rows],
        adapter_live_authority=False,
        exact_role_head_live_authority=False,
    )
    enriched=global_order.attach_order_fields(rows,result)
    # Notion authority: ordinal score controls terminal order. Stable original
    # row order is the final tie-break; membership is unchanged.
    indexed=list(enumerate(enriched))
    indexed.sort(key=lambda z:(-float(z[1]["GLOBAL_ORDINAL_POSTERIOR_SCORE"]),-float(z[1]["GLOBAL_ORDER_SCORE"]),z[0]))
    ordered=[r for _,r in indexed]
    for i,r in enumerate(ordered,1):
        r["GLOBAL_ORDINAL_RANK"]=i
        r["GLOBAL_ORDINAL_SCORE_AUTHORITY"]="GLOBAL_ORDINAL_POSTERIOR_SCORE"
    receipt=dict(result.receipt)
    receipt.update({
        "PATCH_ID":"APEX_GLOBAL_NFL_STYLE_ORDINAL_NO_QUOTA_v1",
        "SOURCE_ROWS":len(rows),
        "FINAL_ROWS":len(ordered),
        "MEMBERSHIP_MUTATION_ALLOWED":False,
        "OUTPUT_LINEUP_QUOTA":"NONE",
        "MAX_ENTRY_FINAL_MEMBERSHIP_AUTHORITY":False,
        "MAX_ENTRY_METADATA_ONLY":True,
        "NO_FORCED_BOARD_SIZE":True,
        "NO_BACKFILL":True,
        "ADAPTIVE_BUBBLE_ALLOWED":False,
        "ORDINAL_SCORE_REQUIRED_FOR_EVERY_QUALIFIED_BUILD":True,
        "ORDINAL_SCORE_AUTHORITY":"GLOBAL_ORDINAL_POSTERIOR_SCORE",
    })
    return ordered,receipt

def _seal_board(*, rows: object, sport: str, mode: str, execution_id: str, output_dir: Path,
                board_source: str, declared_size: object | None = None, source_board_file: Path | None = None,
                ai_terminal_validated: bool = False, ai_terminal_receipt: dict | None = None,
                terminal_source_rows: list[dict] | None = None,
                terminal_source_preverified_hash: str | None = None,
                terminal_source_csv: Path | None = None,
                engine_execution_contract_receipt: dict | None = None) -> dict:
    if ai_terminal_validated or ai_terminal_receipt:
        raise BoardSealError("RUN_INVALID:AI_OR_CHAT_TERMINAL_AUTHORITY_PROHIBITED")
    if not isinstance(engine_execution_contract_receipt, dict) or engine_execution_contract_receipt.get("STATUS") != "PASS":
        raise BoardSealError("RUN_INVALID:ENGINE_EXECUTION_CONTRACT_RECEIPT_REQUIRED_BEFORE_BOARD_SEAL")
    if engine_execution_contract_receipt.get("CHAT_EXECUTION_AUTHORITY") is not False:
        raise BoardSealError("RUN_INVALID:CHAT_EXECUTION_AUTHORITY_NOT_FALSE_AT_BOARD_SEAL")
    native_rows = _validated_rows(rows, declared_size)
    # Prefer the full frozen selector/candidate surface when the runtime provides it.
    # Sport-native terminal compression cannot own global membership.
    source_rows = [dict(r) for r in (terminal_source_rows if terminal_source_rows else native_rows)]
    if not source_rows:
        raise BoardSealError("RUN_INVALID:ZERO_DOT00001_QUALIFIERS")
    mlb_sd_source_coherence = None
    if str(sport).upper() == "MLB" and str(mode).upper() == "SHOWDOWN":
        mlb_sd_source_coherence = _validate_mlb_showdown_structural_coherence(source_rows, stage="SOURCE_QUALIFIED_SURFACE")
    clean_rows, core_receipt = _global_ordinal_full_surface(source_rows, sport=sport, mode=mode)
    required_board_size = len(clean_rows)
    strict_core5 = False
    strict_patch_id = "DISABLED_BY_GLOBAL_ORDINAL_NO_QUOTA"
    strict_scope = f"{str(sport).upper()}_{str(mode).upper()}"
    global_max_entry_portfolio = False
    cfb_showdown_max_entry = False
    mlb_sd_final_coherence = None
    if str(sport).upper() == "MLB" and str(mode).upper() == "SHOWDOWN":
        mlb_sd_final_coherence = _validate_mlb_showdown_structural_coherence(clean_rows, stage="FINAL_CORE5")
    if len(clean_rows) != required_board_size:
        raise BoardSealError("RUN_INVALID:QUALIFIED_SURFACE_MEMBERSHIP_CHANGED")
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"APEX_{sport.upper()}_{mode.upper()}_{execution_id}_PRODUCTION_BOARD"
    artifact_path = output_dir / f"{stem}_READY.json"
    receipt_path = output_dir / f"{stem}_RECEIPT.json"
    terminal_ledger = _write_terminal_selector_ledger(
        source_rows=(terminal_source_rows if terminal_source_rows is not None else source_rows),
        final_rows=clean_rows, execution_id=str(execution_id),
        output_dir=output_dir, stem=stem,
        preverified_source_hash=terminal_source_preverified_hash, source_csv=terminal_source_csv,
    )
    _capture_pool_path = os.environ.get("APEX_ORIGINAL_PLAYER_POOL") or os.environ.get("APEX_PLAYER_POOL")
    _capture_pool_sha = None
    if _capture_pool_path and Path(_capture_pool_path).exists():
        try: _capture_pool_sha = _sha256_file(Path(_capture_pool_path))
        except Exception: _capture_pool_sha = None
    forward_holdout_receipt = forward_holdout.freeze_prelock_holdout(
        sport=sport, mode=mode, execution_id=str(execution_id), output_dir=output_dir,
        final_rows=clean_rows, selector_surface_csv=terminal_source_csv,
        selector_surface_rows=(None if terminal_source_csv is not None else (terminal_source_rows if terminal_source_rows is not None else source_rows)),
        selector_freeze_sha256=terminal_source_preverified_hash,
        terminal_ledger_path=Path(terminal_ledger["PATH"]),
        state_version=(os.environ.get("APEX_GLOBAL_STATE_VERSION") or os.environ.get("APEX_STATE_VERSION")),
        player_pool_sha256=_capture_pool_sha,
    )
    payload_hash = _board_payload_hash(clean_rows)
    source_sha = _sha256_file(source_board_file) if source_board_file and source_board_file.exists() else None
    artifact = {
        "RUN_STATE": "BOARD_READY",
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "PATCH_ID": PATCH_ID,
        "INTEGRITY_PATCH_ID": INTEGRITY_PATCH_ID,
        "SPORT": sport.upper(),
        "MODE": mode.upper(),
        "EXECUTION_ID": str(execution_id),
        "BOARD_SOURCE": board_source,
        "ENGINE_ONLY_EXECUTION_CONTRACT": dict(engine_execution_contract_receipt),
        "CHAT_EXECUTION_AUTHORITY": False,
        "CHAT_FALLBACK_ALLOWED": False,
        "FINAL_BOARD_FIRST_STATS_SECOND_PATCH_ID": FINAL_BOARD_FIRST_STATS_SECOND_PATCH_ID,
        "USER_VISIBLE_BOARD_SOURCE": "SEALED_MACHINE_FINAL_BOARD_ARTIFACT_ONLY",
        "NONBOARD_ARTIFACTS_AS_BOARD_SOURCE": "HARD_REJECT",
        "FINAL_BOARD_RENDER_ORDER": 1,
        "RUN_METRICS_STATS_RENDER_ORDER": 2,
        "OUTPUT_SEQUENCE": ["FINAL_BOARD", "RUN_METRICS_STATS"],
        "BOARD_FIRST_USER_VISIBLE_HARD_GATE_ID": BOARD_FIRST_USER_VISIBLE_HARD_GATE_ID,
        "RENDER_FINAL_BOARD_NOW": True,
        "STATUS_ONLY_RESPONSE_AFTER_BOARD_READY_PROHIBITED": True,
        "RECEIPTS_BEFORE_USER_VISIBLE_BOARD_PROHIBITED": True,
        "USER_VISIBLE_TERMINAL_PRIORITY": "FINAL_BOARD",
        "FINAL_BOARD_SIZE": len(clean_rows),
        "FINAL_PLAYABLE_BOARD_SIZE_REQUIRED": required_board_size,
        "GLOBAL_FINAL_PLAYABLE_CORE5_TERMINAL_PATCH_ID": (GLOBAL_CORE5_TERMINAL_PATCH_ID if strict_core5 else None),
        "DIRECT_NATIVE_BOARD_RENDERING_PROHIBITED": True,
        "FINAL_BOARD": clean_rows,
        "GLOBAL_CHAMPIONSHIP_CORE": core_receipt,
        "GLOBAL_ORDINAL_SCORE_AUTHORITY": "GLOBAL_ORDINAL_POSTERIOR_SCORE",
        "GLOBAL_ORDINAL_SCORE_REQUIRED_EVERY_BUILD": True,
        "OUTPUT_LINEUP_QUOTA": "NONE",
        "MAX_ENTRY_FINAL_MEMBERSHIP_AUTHORITY": False,
        "MAX_ENTRY_METADATA_ONLY": True,
        "NO_FORCED_BOARD_SIZE": True,
        "NO_BACKFILL": True,
        "ADAPTIVE_BUBBLE_ALLOWED": False,
        "GLOBAL_MAX_ENTRY_PORTFOLIO_PASSTHROUGH": False,
        "MAX_ENTRY_CONTROLS_FINAL_PORTFOLIO_MEMBERSHIP": False,
        "CFB_SHOWDOWN_MAX_ENTRY_PORTFOLIO_PASSTHROUGH": False,
        "AI_TERMINAL_AUTHORITY": bool(ai_terminal_validated),
        "PHASE2_LINEAGE_AUDIT_V1": ((ai_terminal_receipt or {}).get("PHASE2_LINEAGE_AUDIT_V1") if ai_terminal_validated else None),
        "BOARD_PAYLOAD_SHA256": payload_hash,
        "RUN_ARTIFACT_ID": terminal_ledger["RUN_ARTIFACT_ID"],
        "TERMINAL_SELECTOR_LEDGER_PATH": terminal_ledger["PATH"],
        "TERMINAL_SELECTOR_LEDGER_SHA256": terminal_ledger["SHA256"],
        "TERMINAL_SELECTOR_SELECTED_ROWS": terminal_ledger["SELECTED_ROWS"],
        "TERMINAL_ARTIFACT_RECONCILIATION": terminal_ledger["TERMINAL_ARTIFACT_RECONCILIATION"],
        "FORWARD_HOLDOUT_CAPTURE_PATCH_ID": forward_holdout.PATCH_ID,
        "FORWARD_HOLDOUT_CAPTURE_STATUS": forward_holdout_receipt["STATUS"],
        "FORWARD_HOLDOUT_PRELOCK_MANIFEST_PATH": forward_holdout_receipt["PRELOCK_MANIFEST_PATH"],
        "FORWARD_HOLDOUT_PRELOCK_MANIFEST_SHA256": forward_holdout_receipt["PRELOCK_MANIFEST_SHA256"],
        "FORWARD_HOLDOUT_SELECTOR_SURFACE_ROWS": forward_holdout_receipt["SELECTOR_SURFACE_ROWS"],
        "FORWARD_HOLDOUT_SELECTOR_SURFACE_SHA256": forward_holdout_receipt["SELECTOR_SURFACE_SHA256"],
        "FORWARD_HOLDOUT_OUTCOME_ATTACHED": False,
        "SOURCE_BOARD_FILE": str(source_board_file) if source_board_file else None,
        "SOURCE_BOARD_FILE_SHA256": source_sha,
        "MLB_SHOWDOWN_STRUCTURAL_COHERENCE_SEAL": mlb_sd_final_coherence,
    }
    _atomic_write(artifact_path, _canonical_json_bytes(artifact))
    artifact_sha = _sha256_file(artifact_path)
    receipt = {
        "RECEIPT_TYPE": "APEX_PRODUCTION_BOARD_ARTIFACT_HASH_PARITY",
        "STATUS": "PASS",
        "PATCH_ID": PATCH_ID,
        "INTEGRITY_PATCH_ID": INTEGRITY_PATCH_ID,
        "SPORT": sport.upper(),
        "MODE": mode.upper(),
        "EXECUTION_ID": str(execution_id),
        "ENGINE_ONLY_EXECUTION_CONTRACT": dict(engine_execution_contract_receipt),
        "CHAT_EXECUTION_AUTHORITY": False,
        "CHAT_FALLBACK_ALLOWED": False,
        "FINAL_BOARD_FIRST_STATS_SECOND_PATCH_ID": FINAL_BOARD_FIRST_STATS_SECOND_PATCH_ID,
        "USER_VISIBLE_BOARD_SOURCE": "SEALED_MACHINE_FINAL_BOARD_ARTIFACT_ONLY",
        "NONBOARD_ARTIFACTS_AS_BOARD_SOURCE": "HARD_REJECT",
        "FINAL_BOARD_RENDER_ORDER": 1,
        "RUN_METRICS_STATS_RENDER_ORDER": 2,
        "OUTPUT_SEQUENCE": ["FINAL_BOARD", "RUN_METRICS_STATS"],
        "BOARD_FIRST_USER_VISIBLE_HARD_GATE_ID": BOARD_FIRST_USER_VISIBLE_HARD_GATE_ID,
        "RENDER_FINAL_BOARD_NOW": True,
        "STATUS_ONLY_RESPONSE_AFTER_BOARD_READY_PROHIBITED": True,
        "RECEIPTS_BEFORE_USER_VISIBLE_BOARD_PROHIBITED": True,
        "USER_VISIBLE_TERMINAL_PRIORITY": "FINAL_BOARD",
        "FINAL_BOARD_SIZE": len(clean_rows),
        "FINAL_PLAYABLE_BOARD_SIZE_REQUIRED": required_board_size,
        "SOURCE_NATIVE_BOARD_SIZE": len(source_rows),
        "GLOBAL_FINAL_PLAYABLE_CORE5_TERMINAL_PATCH_ID": (GLOBAL_CORE5_TERMINAL_PATCH_ID if strict_core5 else None),
        "DIRECT_NATIVE_BOARD_RENDERING_PROHIBITED": True,
        "GLOBAL_CHAMPIONSHIP_CORE_PATCH_ID": championship_core.PATCH_ID,
        "GLOBAL_CHAMPIONSHIP_CORE": core_receipt,
        "GLOBAL_MAX_ENTRY_PORTFOLIO_PASSTHROUGH": False,
        "MAX_ENTRY_CONTROLS_FINAL_PORTFOLIO_MEMBERSHIP": False,
        "CFB_SHOWDOWN_MAX_ENTRY_PORTFOLIO_PASSTHROUGH": False,
        "AI_TERMINAL_AUTHORITY": bool(ai_terminal_validated),
        "BOARD_PAYLOAD_SHA256": payload_hash,
        "RUN_ARTIFACT_ID": terminal_ledger["RUN_ARTIFACT_ID"],
        "TERMINAL_SELECTOR_LEDGER_PATH": terminal_ledger["PATH"],
        "TERMINAL_SELECTOR_LEDGER_SHA256": terminal_ledger["SHA256"],
        "TERMINAL_SELECTOR_SELECTED_ROWS": terminal_ledger["SELECTED_ROWS"],
        "TERMINAL_ARTIFACT_RECONCILIATION": terminal_ledger["TERMINAL_ARTIFACT_RECONCILIATION"],
        "FORWARD_HOLDOUT_CAPTURE_PATCH_ID": forward_holdout.PATCH_ID,
        "FORWARD_HOLDOUT_CAPTURE_STATUS": forward_holdout_receipt["STATUS"],
        "FORWARD_HOLDOUT_PRELOCK_MANIFEST_PATH": forward_holdout_receipt["PRELOCK_MANIFEST_PATH"],
        "FORWARD_HOLDOUT_PRELOCK_MANIFEST_SHA256": forward_holdout_receipt["PRELOCK_MANIFEST_SHA256"],
        "FORWARD_HOLDOUT_SELECTOR_SURFACE_ROWS": forward_holdout_receipt["SELECTOR_SURFACE_ROWS"],
        "FORWARD_HOLDOUT_SELECTOR_SURFACE_SHA256": forward_holdout_receipt["SELECTOR_SURFACE_SHA256"],
        "FORWARD_HOLDOUT_OUTCOME_ATTACHED": False,
        "BOARD_ARTIFACT_PATH": str(artifact_path),
        "BOARD_ARTIFACT_SHA256": artifact_sha,
        "SOURCE_BOARD_FILE": str(source_board_file) if source_board_file else None,
        "SOURCE_BOARD_FILE_SHA256": source_sha,
        "RETURN_FINAL_BOARD_MUST_EQUAL_ARTIFACT_FINAL_BOARD": True,
        "USER_VISIBLE_BOARD_RECONSTRUCTION_PROHIBITED": True,
        "MLB_SHOWDOWN_NATIVE_BOARD_TERMINAL_PROHIBITED": strict_scope == "MLB_SHOWDOWN",
        "MLB_SHOWDOWN_STRUCTURAL_COHERENCE_SEAL_PATCH_ID": MLB_SHOWDOWN_STRUCTURAL_COHERENCE_SEAL_PATCH_ID if strict_scope == "MLB_SHOWDOWN" else None,
        "MLB_SHOWDOWN_SOURCE_STRUCTURAL_COHERENCE": mlb_sd_source_coherence,
        "MLB_SHOWDOWN_FINAL_STRUCTURAL_COHERENCE": mlb_sd_final_coherence,
        "NFL_CLASSIC_NATIVE_BOARD_TERMINAL_PROHIBITED": strict_scope == "NFL_CLASSIC",
        "NFL_SHOWDOWN_NATIVE_BOARD_TERMINAL_PROHIBITED": strict_scope == "NFL_SHOWDOWN",
        "STRICT_CORE5_TERMINAL_PATCH_ID": strict_patch_id or None,
        "FINAL_PLAYABLE_CORE5_ENFORCED": bool(strict_core5),
        "GLOBAL_FINAL_PLAYABLE_CORE5_ENFORCED": bool(strict_core5),
        "FINAL_PLAYABLE_BOARD_SIZE_REQUIRED": required_board_size,
        "DIRECT_NATIVE_BOARD_RENDERING_PROHIBITED": True,
    }
    _atomic_write(receipt_path, _canonical_json_bytes(receipt))
    receipt_sha = _sha256_file(receipt_path)
    verified = _verify_seal(artifact_path, receipt_path)
    if verified["STATUS"] != "PASS":
        raise BoardSealError("BOARD_ARTIFACT_HASH_PARITY_VERIFY_FAILED")
    return {
        "RUN_STATE": "BOARD_READY",
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "PATCH_ID": PATCH_ID,
        "INTEGRITY_PATCH_ID": INTEGRITY_PATCH_ID,
        "SPORT": sport.upper(),
        "MODE": mode.upper(),
        "EXECUTION_ID": str(execution_id),
        "ENGINE_ONLY_EXECUTION_CONTRACT": dict(engine_execution_contract_receipt),
        "CHAT_EXECUTION_AUTHORITY": False,
        "CHAT_FALLBACK_ALLOWED": False,
        "FINAL_BOARD_SIZE": len(clean_rows),
        "FINAL_PLAYABLE_BOARD_SIZE_REQUIRED": required_board_size,
        "GLOBAL_FINAL_PLAYABLE_CORE5_TERMINAL_PATCH_ID": (GLOBAL_CORE5_TERMINAL_PATCH_ID if strict_core5 else None),
        "DIRECT_NATIVE_BOARD_RENDERING_PROHIBITED": True,
        "FINAL_BOARD": clean_rows,
        "GLOBAL_CHAMPIONSHIP_CORE": core_receipt,
        "GLOBAL_ORDINAL_SCORE_AUTHORITY": "GLOBAL_ORDINAL_POSTERIOR_SCORE",
        "GLOBAL_ORDINAL_SCORE_REQUIRED_EVERY_BUILD": True,
        "OUTPUT_LINEUP_QUOTA": "NONE",
        "MAX_ENTRY_FINAL_MEMBERSHIP_AUTHORITY": False,
        "MAX_ENTRY_METADATA_ONLY": True,
        "NO_FORCED_BOARD_SIZE": True,
        "NO_BACKFILL": True,
        "ADAPTIVE_BUBBLE_ALLOWED": False,
        "GLOBAL_MAX_ENTRY_PORTFOLIO_PASSTHROUGH": False,
        "MAX_ENTRY_CONTROLS_FINAL_PORTFOLIO_MEMBERSHIP": False,
        "CFB_SHOWDOWN_MAX_ENTRY_PORTFOLIO_PASSTHROUGH": False,
        "AI_TERMINAL_AUTHORITY": bool(ai_terminal_validated),
        "BOARD_PAYLOAD_SHA256": payload_hash,
        "RUN_ARTIFACT_ID": terminal_ledger["RUN_ARTIFACT_ID"],
        "TERMINAL_SELECTOR_LEDGER_PATH": terminal_ledger["PATH"],
        "TERMINAL_SELECTOR_LEDGER_SHA256": terminal_ledger["SHA256"],
        "TERMINAL_SELECTOR_SELECTED_ROWS": terminal_ledger["SELECTED_ROWS"],
        "TERMINAL_ARTIFACT_RECONCILIATION": terminal_ledger["TERMINAL_ARTIFACT_RECONCILIATION"],
        "FORWARD_HOLDOUT_CAPTURE_PATCH_ID": forward_holdout.PATCH_ID,
        "FORWARD_HOLDOUT_CAPTURE_STATUS": forward_holdout_receipt["STATUS"],
        "FORWARD_HOLDOUT_PRELOCK_MANIFEST_PATH": forward_holdout_receipt["PRELOCK_MANIFEST_PATH"],
        "FORWARD_HOLDOUT_PRELOCK_MANIFEST_SHA256": forward_holdout_receipt["PRELOCK_MANIFEST_SHA256"],
        "FORWARD_HOLDOUT_SELECTOR_SURFACE_ROWS": forward_holdout_receipt["SELECTOR_SURFACE_ROWS"],
        "FORWARD_HOLDOUT_SELECTOR_SURFACE_SHA256": forward_holdout_receipt["SELECTOR_SURFACE_SHA256"],
        "FORWARD_HOLDOUT_OUTCOME_ATTACHED": False,
        "BOARD_ARTIFACT_PATH": str(artifact_path),
        "BOARD_ARTIFACT_SHA256": artifact_sha,
        "PRODUCTION_RECEIPT_PATH": str(receipt_path),
        "PRODUCTION_RECEIPT_SHA256": receipt_sha,
        "MACHINE_BOARD_PARITY": "PASS",
        "FINAL_BOARD_FIRST_STATS_SECOND_PATCH_ID": FINAL_BOARD_FIRST_STATS_SECOND_PATCH_ID,
        "USER_VISIBLE_BOARD_SOURCE": "SEALED_MACHINE_FINAL_BOARD_ARTIFACT_ONLY",
        "USER_VISIBLE_BOARD_ARTIFACT_PATH": str(artifact_path),
        "NONBOARD_ARTIFACTS_AS_BOARD_SOURCE": "HARD_REJECT",
        "FINAL_BOARD_RENDER_ORDER": 1,
        "RUN_METRICS_STATS_RENDER_ORDER": 2,
        "OUTPUT_SEQUENCE": ["FINAL_BOARD", "RUN_METRICS_STATS"],
        "BOARD_FIRST_USER_VISIBLE_HARD_GATE_ID": BOARD_FIRST_USER_VISIBLE_HARD_GATE_ID,
        "RENDER_FINAL_BOARD_NOW": True,
        "STATUS_ONLY_RESPONSE_AFTER_BOARD_READY_PROHIBITED": True,
        "RECEIPTS_BEFORE_USER_VISIBLE_BOARD_PROHIBITED": True,
        "USER_VISIBLE_TERMINAL_PRIORITY": "FINAL_BOARD",
        "POSTBOARD_ARTIFACTS": "SKIPPED_PRODUCTION_DEFAULT",
        "MLB_SHOWDOWN_NATIVE_BOARD_TERMINAL_PROHIBITED": strict_scope == "MLB_SHOWDOWN",
        "MLB_SHOWDOWN_STRUCTURAL_COHERENCE_SEAL_PATCH_ID": MLB_SHOWDOWN_STRUCTURAL_COHERENCE_SEAL_PATCH_ID if strict_scope == "MLB_SHOWDOWN" else None,
        "MLB_SHOWDOWN_FINAL_STRUCTURAL_COHERENCE": mlb_sd_final_coherence,
        "NFL_CLASSIC_NATIVE_BOARD_TERMINAL_PROHIBITED": strict_scope == "NFL_CLASSIC",
        "NFL_SHOWDOWN_NATIVE_BOARD_TERMINAL_PROHIBITED": strict_scope == "NFL_SHOWDOWN",
        "STRICT_CORE5_TERMINAL_PATCH_ID": strict_patch_id or None,
        "FINAL_PLAYABLE_CORE5_ENFORCED": bool(strict_core5),
        "GLOBAL_FINAL_PLAYABLE_CORE5_ENFORCED": bool(strict_core5),
        "FINAL_PLAYABLE_BOARD_SIZE_REQUIRED": required_board_size,
        "DIRECT_NATIVE_BOARD_RENDERING_PROHIBITED": True,
    }

def _verify_seal(artifact_path: Path, receipt_path: Path) -> dict:
    try:
        artifact_bytes = artifact_path.read_bytes()
        artifact = json.loads(artifact_bytes)
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        rows = _validated_rows(artifact.get("FINAL_BOARD"), artifact.get("FINAL_BOARD_SIZE"))
        payload_hash = _board_payload_hash(rows)
        checks = {
            "PAYLOAD_HASH": payload_hash == artifact.get("BOARD_PAYLOAD_SHA256") == receipt.get("BOARD_PAYLOAD_SHA256"),
            "ARTIFACT_HASH": _sha256_bytes(artifact_bytes) == receipt.get("BOARD_ARTIFACT_SHA256"),
            "SIZE": int(receipt.get("FINAL_BOARD_SIZE", -1)) == len(rows),
            "RETURN_POLICY": receipt.get("RETURN_FINAL_BOARD_MUST_EQUAL_ARTIFACT_FINAL_BOARD") is True,
            "TERMINAL_PARITY": artifact.get("TERMINAL_ARTIFACT_RECONCILIATION") == "PASS" == receipt.get("TERMINAL_ARTIFACT_RECONCILIATION"),
            "TERMINAL_SELECTOR_COUNT": int(receipt.get("TERMINAL_SELECTOR_SELECTED_ROWS", -1)) == len(rows),
            "RUN_ARTIFACT_ID": bool(artifact.get("RUN_ARTIFACT_ID")) and artifact.get("RUN_ARTIFACT_ID") == receipt.get("RUN_ARTIFACT_ID"),
        }
        return {"STATUS": "PASS" if all(checks.values()) else "FAIL", "CHECKS": checks}
    except Exception as exc:
        return {"STATUS": "FAIL", "ERROR": f"{type(exc).__name__}:{exc}"}

def _load_board(path: Path):
    if not path.exists() or path.stat().st_size <= 0:
        return None
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
        return rows if rows else None
    except Exception:
        return None

def _signature(path: Path | None):
    if not path or not path.exists():
        return None
    st = path.stat()
    return (st.st_size, st.st_mtime_ns)

def _durable_terminal_recovery(*, root: Path, sport: str, mode: str, execution_id: str, output_dir: Path) -> dict | None:
    """Recover only an already committed engine-owned Core-5 board.

    Legacy AI surface/decision events are intentionally ignored in live production.
    """
    board_event=durable_run.latest_event(root,"CORE5_BOARD_COMMITTED")
    if board_event is None:
        return None
    payload=dict(board_event.get("PAYLOAD") or {})
    board_meta=dict(payload.get("BOARD") or {})
    board_path=durable_run.validate_committed_artifact(board_meta)
    artifact=json.loads(board_path.read_text(encoding="utf-8"))
    if str(artifact.get("RUN_STATE",""))!="BOARD_READY":
        raise BoardSealError("DURABLE_ENGINE_BOARD_RUN_STATE_INVALID")
    _strict_core5, _strict_patch_id, _strict_scope = _strict_core5_terminal_contract(sport, mode)
    _artifact_size = int(artifact.get("FINAL_BOARD_SIZE",0) or 0)
    if _strict_core5:
        if False and _artifact_size != GLOBAL_FINAL_PLAYABLE_BOARD_SIZE:
            raise BoardSealError("DURABLE_ENGINE_BOARD_SIZE_INVALID")
    else:
        if _artifact_size <= 0:
            raise BoardSealError("DURABLE_GLOBAL_MAX_ENTRY_BOARD_INVALID")
    artifact=dict(artifact)
    artifact["DURABLE_RUN_PATCH_ID"]=durable_run.PATCH_ID
    artifact["DURABLE_ENGINE_BOARD_RECOVERY"]=True
    artifact["BOARD_ARTIFACT_PATH"]=str(board_path)
    artifact["BOARD_ARTIFACT_SHA256"]=_sha256_file(board_path)
    artifact["AI_TERMINAL_AUTHORITY"]=False
    artifact["CHAT_EXECUTION_AUTHORITY"]=False
    artifact["OPENAI_LIVE_AUTHORITY"]=False
    return artifact


def _finalize_pending_terminal_surface(*, pending_native_board: dict, root: Path, resume_state_obj: dict,
                                       sport: str, mode: str, execution_id: str, output_dir: Path,
                                       child_return_code: int | None = None, source_board_file: Path | None = None) -> dict:
    """Seal the engine-owned terminal board without Chat/OpenAI continuation.

    The sport engine owns candidate generation, simulation, native selection, and the
    deterministic global championship-core compression.  Chat only triggers and reports.
    """
    rows=pending_native_board.get('FINAL_BOARD') if isinstance(pending_native_board,dict) else None
    source_file=Path(source_board_file).resolve() if source_board_file is not None else None
    if not isinstance(rows,list) or not rows:
        if source_file is not None and source_file.exists():
            rows=_load_board(source_file)
    if not isinstance(rows,list) or not rows:
        raise BoardSealError('ENGINE_OWNED_TERMINAL_SOURCE_MISSING')
    declared_size=len(rows)
    if str(sport).upper()=="CFB" and str(mode).upper()=="SHOWDOWN":
        requested=pending_native_board.get("REQUESTED_PORTFOLIO_SIZE", pending_native_board.get("ENTRY_LIMIT"))
        if requested is None:
            raise BoardSealError("CFB_SHOWDOWN_MAX_ENTRY_TERMINAL_RECEIPT_MISSING")
        declared_size=int(requested)
        if declared_size != len(rows):
            raise BoardSealError(f"CFB_SHOWDOWN_MAX_ENTRY_TERMINAL_RECEIPT_SIZE_MISMATCH:{len(rows)}:{declared_size}")
    if any(k in pending_native_board for k in ('AI_TERMINAL_CANDIDATE_SURFACE_PATH','AI_TERMINAL_CANDIDATE_RECEIPT_PATH','AI_TERMINAL_AUTHORITY')):
        if pending_native_board.get('AI_TERMINAL_AUTHORITY') or pending_native_board.get('AI_TERMINAL_CANDIDATE_SURFACE_PATH'):
            raise BoardSealError('RUN_INVALID:AI_CHAT_TERMINAL_SURFACE_PROHIBITED')
    terminal_contract_input=dict(pending_native_board)
    terminal_contract_input.setdefault('CHAT_EXECUTION_AUTHORITY', False)
    terminal_contract_input.setdefault('AI_EXECUTION_AUTHORITY', False)
    _req=json.loads(os.environ.get('APEX_MODE_REQUIREMENTS_JSON','{}') or '{}')
    engine_contract_receipt=engine_only.validate_terminal_source(terminal_contract_input, requirements=_req)
    sealed=_seal_board(
        rows=rows,sport=sport,mode=mode,execution_id=execution_id,output_dir=output_dir,
        board_source='ENGINE_OWNED_TERMINAL_BOARD',declared_size=declared_size,
        source_board_file=source_file,ai_terminal_validated=False,
        engine_execution_contract_receipt=engine_contract_receipt,
    )
    sealed['ENGINE_ONLY_EXECUTION_CONTRACT']=engine_contract_receipt
    _release=engine_only.validate_protected_release(
        os.environ.get('APEX_RELEASE_RECEIPT'), board_path=sealed['BOARD_ARTIFACT_PATH'], run_id=execution_id,
        engine_version=str(pending_native_board.get('STATE_VERSION') or ''),
        input_sha256=str(pending_native_board.get('INPUT_SHA256') or ''),
        policy_sha256=str(pending_native_board.get('POLICY_SHA256') or ''), public_key_path=os.environ.get('APEX_PUBLISHER_PUBLIC_KEY_FILE'))
    sealed['PROTECTED_RELEASE']=_release
    sealed['RUN_STATE']='VERIFIED_COMPLETE'
    selected_ids=[_row_lineup_id(dict(r),i) for i,r in enumerate(sealed['FINAL_BOARD'])]
    durable_run.commit_board(
        root=root,board_path=Path(sealed['BOARD_ARTIFACT_PATH']),
        board_payload_sha256=str(sealed['BOARD_PAYLOAD_SHA256']),
        final_board_size=int(sealed['FINAL_BOARD_SIZE']),selected_ids=selected_ids,
    )
    resume_state.finalize_board_state(
        root=root,state=resume_state_obj,board_path=Path(sealed['BOARD_ARTIFACT_PATH']),
        board_size=int(sealed['FINAL_BOARD_SIZE'])
    )
    sealed['ENGINE_OWNED_TERMINAL_AUTHORITY_PATCH_ID']=ENGINE_OWNED_TERMINAL_AUTHORITY_PATCH_ID
    sealed['CHAT_EXECUTION_AUTHORITY']=False
    sealed['OPENAI_LIVE_AUTHORITY']=False
    sealed['AI_TERMINAL_AUTHORITY']=False
    sealed['CHILD_RETURN_CODE_AFTER_VALID_NATIVE_SURFACE']=child_return_code
    sealed['RECOVERED_AFTER_NONZERO_CHILD_EXIT']=bool(child_return_code not in (None,0))
    return sealed


def _terminate(proc: subprocess.Popen) -> None:
    if proc.poll() is not None:
        return
    try:
        proc.terminate(); proc.wait(timeout=1.0)
    except Exception:
        try: proc.kill(); proc.wait(timeout=1.0)
        except Exception: pass

def _resolve_certified_chunk_stream_entrypoint(*, registry: dict, sport: str, mode: str, root: Path) -> Path:
    """Resolve the only live production route: a certified engine-owned chunk controller.

    Raw runtime ENTRYPOINT is metadata only. It is never a live fallback. A mode that has
    not been certified for chunk-and-stream fails closed until a native adapter exists.
    """
    sport_u=str(sport).upper(); mode_u=str(mode).upper()
    matches=[]
    for entry in registry.get('ENGINES',[]):
        if str(entry.get('SPORT','')).upper()!=sport_u:
            continue
        modes={str(x).upper() for x in (entry.get('MODES') or [])}
        if mode_u in modes:
            matches.append(entry)
    if not matches:
        raise RuntimeError(f'RUN_INVALID:ENGINE_REGISTRY_ROUTE_MISSING:{sport_u}:{mode_u}')
    for entry in matches:
        if entry.get('CHUNK_STREAM_REQUIRED') is not True:
            raise RuntimeError(f'RUN_INVALID:GLOBAL_CHUNK_STREAM_NOT_REQUIRED_IN_REGISTRY:{sport_u}:{mode_u}')
        status_map=entry.get('CHUNK_STREAM_MODE_STATUS') or {}
        status=str(status_map.get(mode_u) or status_map.get(str(mode)) or '').upper()
        if status!='CERTIFIED':
            raise RuntimeError(f'RUN_INVALID:CHUNK_STREAM_ADAPTER_REQUIRED:{sport_u}:{mode_u}:{status or "UNDECLARED"}')
        rel=None
        controllers=entry.get('CHUNK_STREAM_CONTROLLERS') or {}
        if isinstance(controllers,dict):
            rel=controllers.get(mode_u) or controllers.get(str(mode))
        if not rel:
            rel=entry.get('CHUNK_STREAM_ENTRYPOINT')
        if not rel and entry.get('ENTRYPOINT_IS_CHUNK_STREAM_CONTROLLER') is True:
            rel=entry.get('ENTRYPOINT')
        if not rel:
            raise RuntimeError(f'RUN_INVALID:CHUNK_STREAM_CONTROLLER_MISSING:{sport_u}:{mode_u}')
        path=(Path(root)/str(rel)).resolve()
        if not path.exists() or not path.is_file():
            raise RuntimeError(f'RUN_INVALID:CHUNK_STREAM_CONTROLLER_FILE_MISSING:{sport_u}:{mode_u}:{path}')
        return path
    raise RuntimeError(f'RUN_INVALID:CHUNK_STREAM_ADAPTER_REQUIRED:{sport_u}:{mode_u}')


def _machine_emit(payload: dict, provenance: dict, *, stream=None) -> dict:
    stamped=execution_reporting_guard.stamp(payload,provenance)
    execution_reporting_guard.validate(stamped,require_reportable=False)
    print(json.dumps(stamped,indent=2,default=str),file=(stream or sys.stdout),flush=True)
    return stamped

def _invalid(*, sport: str, mode: str, execution_id: str, failure_code: str, child_return_code=None, stderr_tail=None, provenance=None) -> int:
    payload={
        "RUN_STATE": "RUN_INVALID",
        "PATCH_ID": PATCH_ID,
        "INTEGRITY_PATCH_ID": INTEGRITY_PATCH_ID,
        "SPORT": sport.upper(),
        "MODE": mode.upper(),
        "EXECUTION_ID": str(execution_id),
        "FINAL_BOARD_SIZE": 0,
        "MACHINE_BOARD_PARITY": "FAIL",
        "FAILURE_CODE": failure_code,
        "CHILD_RETURN_CODE": child_return_code,
        "STDERR_TAIL": stderr_tail or [],
    }
    if provenance is not None:
        _machine_emit(payload,provenance)
    else:
        print(json.dumps(payload,indent=2),flush=True)
    return child_return_code or 2

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--sport', required=True)
    ap.add_argument('--mode', required=True)
    ap.add_argument('--execution-id', required=True)
    ap.add_argument('--output-dir', required=False, default=None)
    ap.add_argument('--board-file', required=False, default=None)
    ap.add_argument('--board-glob', required=False, default=None)
    a=ap.parse_args()
    machine_reporting_provenance=execution_reporting_guard.new_run_provenance(a.execution_id)
    cmd=[]
    env=dict(os.environ)
    _requested_out_dir=a.output_dir or env.get('APEX_OUTPUT_DIR')
    if _requested_out_dir:
        out_dir=Path(_requested_out_dir).resolve()
    else:
        out_dir=(Path('/mnt/data') / f"apex_run_{a.sport.lower()}_{a.mode.lower()}_{a.execution_id}").resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    # FIRST EXECUTABLE LIVE-RUN GATE: current Notion authority + caller-control rejection.
    # No data governance, simulation, generation, selector, recovery, or board work is allowed before this passes.
    try:
        _registry_path_early=Path(__file__).resolve().parents[2]/'engine_registry.json'
        _registry_early=json.loads(_registry_path_early.read_text(encoding='utf-8'))
        _state_version_early=str(_registry_early.get('STATE_VERSION') or '').strip()
        if not _state_version_early:
            raise engine_only.EngineOnlyExecutionError('RUN_INVALID:ACTIVE_STATE_VERSION_MISSING')
        _caller_control_receipt=engine_only.reject_caller_execution_controls(env, board_file=a.board_file, board_glob=a.board_glob)
        _notion_authority_receipt=engine_only.validate_live_notion_authority_receipt(
            env.get('APEX_NOTION_AUTHORITY_RECEIPT'),
            expected_state_version=_state_version_early, sport=a.sport, mode=a.mode,
        )
        env.update(engine_only.production_env())
        env['APEX_NOTION_AUTHORITY_RECEIPT_SHA256']=str(_notion_authority_receipt['NOTION_RECEIPT_SHA256'])
        env['APEX_NOTION_AUTHORITY_FILE_SHA256']=str(_notion_authority_receipt['NOTION_RECEIPT_FILE_SHA256'])
        env['APEX_ENGINE_LINEUP_BUILDER_PATCH_ID']='APEX_ENGINE_LINEUP_BUILDER_CANONICAL_v1'
        _mode_requirements=engine_only.mode_requirements(_registry_early,a.sport,a.mode)
        _global_engine_parity_receipt=global_engine_parity.resolve(
            registry=_registry_early, sport=a.sport, mode=a.mode, root=Path(__file__).resolve().parents[2],
            notion_receipt=_notion_authority_receipt, mode_requirements=_mode_requirements,
        )
        _parity_path=out_dir/'GLOBAL_ENGINE_PARITY_RECEIPT.json'
        _parity_path.write_text(json.dumps(_global_engine_parity_receipt,indent=2,sort_keys=True)+'\n',encoding='utf-8')
        env['APEX_GLOBAL_ENGINE_PARITY']='PASS'
        env['APEX_GLOBAL_ENGINE_PARITY_PATCH_ID']=str(_global_engine_parity_receipt['PATCH_ID'])
        env['APEX_GLOBAL_ENGINE_PARITY_RECEIPT']=str(_parity_path)
        env['APEX_GLOBAL_ENGINE_PARITY_JSON']=json.dumps(_global_engine_parity_receipt,sort_keys=True,separators=(',',':'))
        _entry=_resolve_certified_chunk_stream_entrypoint(registry=_registry_early,sport=a.sport,mode=a.mode,root=Path(__file__).resolve().parents[2])
        cmd=[sys.executable,str(_entry)]
        env['APEX_AUTHORITATIVE_ENGINE_ENTRYPOINT']=str(_entry)
        env['APEX_POLICY_SHA256']=hashlib.sha256(json.dumps(_registry_early,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        env['APEX_MODE_REQUIREMENTS_JSON']=json.dumps(_mode_requirements,sort_keys=True,separators=(',',':'))
    except Exception as exc:
        return _invalid(
            sport=a.sport, mode=a.mode, execution_id=a.execution_id,
            failure_code=f'ENGINE_ONLY_PREEXECUTION_GATE_FAILED:{type(exc).__name__}:{exc}'
        )
    # Reset contract: no pre-execution board/hash recovery gate. Load current data and execute.
    # Global assumption governance / point-in-time preflight.
    pool_env=env.get('APEX_PLAYER_POOL')
    if pool_env and Path(pool_env).exists():
        try:
            common_dir=str(Path(__file__).resolve().parent)
            engine_root=str(Path(__file__).resolve().parents[2])
            if engine_root not in sys.path: sys.path.insert(0,engine_root)
            if common_dir not in sys.path: sys.path.insert(0,common_dir)
            import apex_data_governor_v1 as _gov
            import apex_preflight_sanity_v1 as _pf
            field_size=int(env.get('APEX_FIELD_SIZE','0') or 0) or None
            governed=_gov.govern_player_pool(pool_env,sport=a.sport,mode=a.mode,field_size=field_size,output_dir=out_dir,
                provider=env.get('APEX_PLAYER_POOL_PROVIDER','PLAYER_FILE'),event_timestamp=env.get('APEX_SLATE_EVENT_TIMESTAMP'),
                contest_type=env.get('APEX_CONTEST_TYPE'),max_entries=env.get('APEX_MAX_ENTRIES'),user_entries=env.get('APEX_USER_ENTRIES'),
                entry_fee=env.get('APEX_ENTRY_FEE'),payout_curve=env.get('APEX_PAYOUT_STRUCTURE'),pct_to_first=env.get('APEX_PCT_TO_FIRST'),
                pct_paid=env.get('APEX_PCT_PAID'),stake_bucket=env.get('APEX_STAKE_BUCKET'),slate_size=env.get('APEX_SLATE_SIZE'))
            _pf.run_preflight(governed['player_pool'],governed['provenance'],governed['contest_payload'])
            env['APEX_ORIGINAL_PLAYER_POOL']=pool_env
            env['APEX_PLAYER_POOL']=governed['player_pool']
            env['APEX_PROVENANCE_FILE']=governed['provenance']
            env['APEX_DATA_GOVERNOR_PATCH_ID']=_gov.PATCH_ID
            env['APEX_FORWARD_ENVIRONMENT']='FORWARD_PRELOCK'
            if governed['contest_payload'].get('ENTRY_LIMIT_PROFILE') is not None:
                env['APEX_ENTRY_LIMIT_GAME_THEORY_PATCH_ID']=str(governed['contest_payload'].get('ENTRY_LIMIT_GAME_THEORY_PATCH_ID') or '')
                env['APEX_ENTRY_LIMIT_PROFILE_JSON']=json.dumps(governed['contest_payload']['ENTRY_LIMIT_PROFILE'],sort_keys=True,separators=(',',':'))
                env['APEX_PORTFOLIO_OBJECTIVE']=str(governed['contest_payload'].get('PORTFOLIO_OBJECTIVE') or '')
        except Exception as exc:
            return _invalid(sport=a.sport, mode=a.mode, execution_id=a.execution_id, failure_code=f'DATA_GOVERNANCE_FAILED:{type(exc).__name__}:{exc}')
    # Global ownership authority bridge: provider RST is prior-only.
    # If a player-pool path is supplied, derive contest ownership once before the sport engine.
    pool_env=env.get("APEX_PLAYER_POOL")
    if pool_env and Path(pool_env).exists():
        try:
            common_dir=str(Path(__file__).resolve().parent)
            engine_root=str(Path(__file__).resolve().parents[2])
            if engine_root not in sys.path: sys.path.insert(0,engine_root)
            if common_dir not in sys.path: sys.path.insert(0,common_dir)
            import apex_contest_derived_ownership_v1 as _own
            own_out=out_dir / f"APEX_{a.sport.upper()}_{a.mode.upper()}_{a.execution_id}_OWNERSHIP_DERIVED_POOL.csv"
            repaired=_own.repair_player_pool_file(
                pool_env, a.sport, a.mode,
                field_size=int(env.get("APEX_FIELD_SIZE","0") or 0) or None,
                contest_type=env.get("APEX_CONTEST_TYPE"),
                output_path=own_out,
            )
            env["APEX_PROVIDER_PLAYER_POOL"]=pool_env
            env["APEX_PLAYER_POOL"]=repaired
            env["APEX_OWNERSHIP_AUTHORITY"]="APEX_EXPECTED_OWNERSHIP"
            env["APEX_OWNERSHIP_PATCH_ID"]=_own.PATCH_ID
        except Exception as exc:
            return _invalid(sport=a.sport, mode=a.mode, execution_id=a.execution_id,
                failure_code=f"OWNERSHIP_DERIVATION_FAILED:{type(exc).__name__}:{exc}")
    env.update({
        'PYTHONUNBUFFERED':'1',
        'APEX_EXECUTION_MODE':'PRODUCTION',
        'APEX_PRODUCTION_FAST':'1',
        'APEX_DIAGNOSTICS_DISABLED':'1',
        'APEX_POSTBOARD_ARTIFACTS':'0',
        'APEX_BOARD_FIRST_RENDERING':'BOARD_FIRST_RENDERING_v2',
        'APEX_GLOBAL_PRODUCTION_CRITICAL_PATH':PATCH_ID,
        'APEX_GLOBAL_PRODUCTION_BOARD_INTEGRITY':INTEGRITY_PATCH_ID,
        'APEX_RUN_UNTIL_BOARD_PATCH_ID':RUN_UNTIL_BOARD_PATCH_ID,
        'APEX_RUN_UNTIL_BOARD_OR_TRUE_INVALID':'1',
        'APEX_GLOBAL_ASSUMPTION_GOVERNANCE':'APEX_GLOBAL_ASSUMPTION_GOVERNANCE_v1',
        'APEX_POINT_IN_TIME_FIREWALL':'APEX_GLOBAL_POINT_IN_TIME_PREFLIGHT_FIREWALL_v1',
        'APEX_CONTEST_FIELD_REALISM':'APEX_GLOBAL_CONTEST_FIELD_REALISM_CONTRACT_v1',
        'APEX_EXECUTION_PATH_PRIMACY':EXECUTION_PATH_PRIMACY_PATCH_ID,
        'APEX_ROW_WISE_LEGALITY_CHECKS':'BAN',
        'APEX_MID_RUN_RAW_IO_READS':'PROHIBIT',
        'APEX_ONE_PASS_FROZEN_DATA_FLOW':'ENFORCE',
        'APEX_VECTOR_KERNELS_REQUIRED':'1',
        'APEX_GLOBAL_CHUNK_STREAM_REQUIRED':'1','APEX_CHUNK_STREAM_ONLY':'1',
        'APEX_GLOBAL_CHUNK_STREAM_PATCH_ID':GLOBAL_CHUNK_STREAM_PATCH_ID,
        'APEX_MONOLITHIC_LARGE_PHASE_EXECUTION':'PROHIBITED',
        'APEX_EXPENSIVE_ORDER_ONLY_MC':'PROHIBIT',
        'APEX_GLOBAL_CHAMPIONSHIP_CORE_REQUIRED':'1',
        'APEX_GLOBAL_CHAMPIONSHIP_CORE_SIZE':'5',
        'APEX_GLOBAL_CHAMPIONSHIP_SATELLITES':'0',
        'APEX_GLOBAL_END_TO_END_ENGINE_OWNERSHIP':END_TO_END_ENGINE_OWNERSHIP_PATCH_ID,
        'APEX_LIVE_PIPELINE_CONTROL':'ENGINE_OWNS_END_TO_END',
        'APEX_EXTERNAL_STAGE_ENTRY':'PROHIBITED',
        'APEX_EXTERNAL_STAGE_SUBSTITUTION':'PROHIBITED',
        'APEX_EXTERNAL_CHECKPOINT_SELECTION':'PROHIBITED',
        'APEX_EXTERNAL_TERMINAL_ORDER_SELECTION':'PROHIBITED',
        'APEX_CHAT_ENGINE_ROLE_BOUNDARY':chat_role_boundary.PATCH_ID,
        'APEX_CHAT_ROLE':chat_role_boundary.CHAT_ROLE,
        'APEX_CHAT_INTERNAL_ENGINE_CONTROL':'PROHIBITED',
        'APEX_CHAT_SELECTOR_BOUNDARY_ONLY':'0',
        'APEX_CHAT_EXECUTION_AUTHORITY':'0',
        'APEX_AI_EXECUTION_AUTHORITY':'0',
        'APEX_AI_SELECTOR_AUTHORITY':'0',
        'APEX_AI_RERANK_AUTHORITY':'0',
        'APEX_AI_PUBLISH_AUTHORITY':'0',
        'APEX_ENGINE_ONLY_EXECUTION_CONTRACT':engine_only.PATCH_ID,
        'APEX_ENGINE_LINEUP_BUILDER_PATCH_ID':'APEX_ENGINE_LINEUP_BUILDER_CANONICAL_v1',
        'APEX_BUILD_TARGET':str(_registry_early.get('GLOBAL_BUILD_TARGET') or 'FIELD_RELATIVE_DOT00001'),
        'APEX_MIN_MC_WORLDS':str(int(_mode_requirements.get('MIN_MC_WORLDS') or 0)),
        'APEX_FULL_ENUMERATION_REQUIRED':'1' if bool(_mode_requirements.get('FULL_ENUMERATION_REQUIRED')) else '0',
        'APEX_CANDIDATE_LINEAGE_REQUIRED':'1' if bool(_mode_requirements.get('CANDIDATE_LINEAGE_REQUIRED')) else '0',
        'APEX_CHAT_LIVE_INTERVENTION':'PROHIBITED',
        'APEX_CHAT_LATENCY_BASED_RESTART':'PROHIBITED',
        'APEX_CHAT_LIVE_PATCHING':'PROHIBITED',
        'APEX_CHAT_CHECKPOINT_MUTATION':'PROHIBITED',
        'APEX_ENGINE_CHECKPOINT_AUTHORITY':'1',
        'APEX_ENGINE_PROCESS_LIFECYCLE_AUTHORITY':'1',
        'APEX_ENGINE_TERMINAL_AUTHORITY':'1',
        'APEX_GLOBAL_STEP_PROOF_REQUIRED':'1',
        'APEX_GLOBAL_STEP_PROOF_GATE_PATCH_ID':GLOBAL_STEP_PROOF_GATE_PATCH_ID,
        'APEX_NEXT_STEP_WITHOUT_PROOF':'PROHIBITED',
        'APEX_EVERY_STEP_PUBLIC_PROOF_LEDGER':'REQUIRED',
        'APEX_PUBLIC_PROOF_LEDGER_FAIL_CLOSED':'TRUE',
        'APEX_OPENAI_LIVE_AUTHORITY':'0',
        'APEX_AI_ROLE':'DIAGNOSTIC_ONLY',
        'APEX_AI_UPSTREAM_AUTHORITY':'0',
        'APEX_PLUGINS_SUPPORT_ALLOWED':'1',
        'APEX_PLUGINS_EXECUTION_AUTHORITY':'0',
        'APEX_SPORT':a.sport.upper(),
        'APEX_SPORT_MODE':a.mode.upper(),
        'APEX_MODE':a.mode.upper(),
    })
    # Persistent top-level execution identity. Child engines may consume these same
    # state coordinates for chunk-level checkpoints; the runner persists terminal/retry state.
    _pool_path=Path(env.get('APEX_PLAYER_POOL','')) if env.get('APEX_PLAYER_POOL') else None
    # Durable identity must be derived from immutable run inputs, not regenerated
    # governance/ownership artifacts whose mtimes change on every invocation.
    _identity_pool_raw=(env.get('APEX_ORIGINAL_PLAYER_POOL') or env.get('APEX_PROVIDER_PLAYER_POOL') or env.get('APEX_PLAYER_POOL'))
    _identity_pool_path=Path(_identity_pool_raw) if _identity_pool_raw else None
    _pool_sha=_sha256_file(_identity_pool_path) if (_identity_pool_path is not None and _identity_pool_path.exists()) else ''
    _engine_path=next((Path(x) for x in reversed(cmd) if str(x).endswith('.py') and Path(x).exists()), None)
    _engine_sha=_sha256_file(_engine_path) if (_engine_path is not None and _engine_path.exists()) else ''
    try:
        _registry_state=json.loads((Path(__file__).resolve().parents[2]/'engine_registry.json').read_text(encoding='utf-8')).get('STATE_VERSION')
    except Exception:
        _registry_state=None
    _state_version=str(_registry_state or env.get('APEX_GLOBAL_STATE_VERSION') or env.get('APEX_STATE_VERSION') or 'UNSPECIFIED')
    if _identity_pool_path is not None and _identity_pool_path.exists():
        _pst=_identity_pool_path.stat()
        _pool_startup_identity=f"{_identity_pool_path.name}_{_pst.st_size}_{_pool_sha[:24]}"
    else:
        _pool_startup_identity='NO_POOL_FILE'
    _state_token=f"{_state_version}_{_pool_startup_identity}"
    _platform=str(env.get('APEX_PLATFORM') or 'DK').upper()
    _resume_base=Path(env.get('APEX_RESUMABLE_STATE_BASE','/tmp/apex_production_state'))
    _run_identity=_canonical_run_identity(state_token=_state_token,pool_sha256=_pool_sha,engine_sha256=_engine_sha,platform=_platform,sport=a.sport,mode=a.mode,execution_id=a.execution_id)
    _run_id=f"{a.sport.upper()}_{a.mode.upper()}_{a.execution_id}_{_run_identity[:16]}"
    _single_flight_handle,_single_flight_path=_acquire_single_flight_lease(base=_resume_base,run_identity=_run_identity)
    env.update({'APEX_SINGLE_FLIGHT_PATCH_ID':AUTONOMOUS_SUPERVISOR_PATCH_ID,'APEX_SINGLE_FLIGHT_RUN_IDENTITY':_run_identity,'APEX_SINGLE_FLIGHT_LEASE_PATH':str(_single_flight_path)})
    _preload_active_rebase=_preload_rebase_proven_active_legacy_root(
        base=_resume_base,run_id=_run_id,state_version=_state_version,player_pool_sha256=_pool_sha,engine_sha256=_engine_sha,
        sport=a.sport,mode=a.mode,execution_id=a.execution_id,env=env,
    )
    if _preload_active_rebase.get('STATUS')=='PROVEN_ACTIVE_ROOT_REBASE':
        print(json.dumps({'RUN_STATE':'LEGACY_ACTIVE_ROOT_REBASED_PRELOAD','EXECUTION_STATE':'RESUMABLE',**_preload_active_rebase},default=str),file=sys.stderr,flush=True)
        _preload_legacy_restore={'STATUS':'SKIPPED_ACTIVE_ROOT_REBASED'}
    else:
        _preload_legacy_restore=_preload_restore_proven_legacy_run_root(
            base=_resume_base,run_id=_run_id,state_version=_state_version,player_pool_sha256=_pool_sha,engine_sha256=_engine_sha,
            sport=a.sport,mode=a.mode,execution_id=a.execution_id,env=env,
        )
        if _preload_legacy_restore.get('STATUS')=='PROVEN_PRELOAD_RESTORE':
            print(json.dumps({'RUN_STATE':'LEGACY_ROOT_RESTORED_PRELOAD','EXECUTION_STATE':'RESUMABLE',**_preload_legacy_restore},default=str),file=sys.stderr,flush=True)
    _resume_root,_resume_state,_resume_quarantined=resume_state.load_or_initialize(base=_resume_base,run_id=_run_id,state_version=_state_version,player_pool_sha256=_pool_sha,engine_sha256=_engine_sha)
    if str(env.get('APEX_LEGACY_RESUME_MIGRATION_ALLOWED','0')).strip()=='1':
        durable_run.migrate_legacy_identity_if_proven(
            root=_resume_root,
            requested_run_identity=_run_identity,
            metadata={
                'STATE_TOKEN':_state_token,'STATE_VERSION':_state_version,'POOL_SHA256':_pool_sha,'ENGINE_SHA256':_engine_sha,
                'PLATFORM':_platform,'SPORT':a.sport.upper(),'MODE':a.mode.upper(),'EXECUTION_ID':str(a.execution_id),
            },
            expected_legacy_run_identity=str(env.get('APEX_LEGACY_RESUME_EXPECTED_RUN_IDENTITY') or ''),
            expected_original_pool_sha256=str(env.get('APEX_LEGACY_RESUME_EXPECTED_POOL_SHA256') or ''),
            current_original_pool_sha256=_pool_sha,
            expected_checkpoint=str(env.get('APEX_LEGACY_RESUME_EXPECTED_CHECKPOINT') or ''),
            expected_legacy_state_version=str(env.get('APEX_LEGACY_RESUME_EXPECTED_CONTROLLER_STATE_VERSION') or ''),
        )
    _resume_state['CURRENT_PHASE']='ENGINE_DISPATCH'; _resume_state['EXECUTION_STATE']='RUNNING'
    resume_state.atomic_json(_resume_root/'.session_state.json',_resume_state)
    env.update({'APEX_RESUMABLE_RUN_ROOT':str(_resume_root),'APEX_RESUMABLE_RUN_ID':_run_id,'APEX_RESUMABLE_STATE_VERSION':_state_version})
    try:
        _step_chain = global_step_proof_gate.initialize(root=_resume_root, execution_id=a.execution_id, sport=a.sport, mode=a.mode)
        _registry_path = Path(__file__).resolve().parents[2]/'engine_registry.json'
        if _step_chain.get('STEP_COUNT',0) == 0:
            _authority_proof = global_step_proof_gate.prove_authority(
                root=_resume_root, state_version=_state_version, registry_path=_registry_path,
                direct_engine_sha256=str(env.get('APEX_DIRECT_ENGINE_SHA256') or env.get('APEX_BUNDLE_SHA256') or ''),
                notion_authority_receipt=_notion_authority_receipt,
            )
            print(json.dumps({'RUN_STATE':'STEP_PROOF','STEP':'AUTHORITY_RESOLVED',**_authority_proof},default=str),file=sys.stderr,flush=True)
            _input_authority = _identity_pool_path if (_identity_pool_path is not None and _identity_pool_path.exists()) else _pool_path
            if _input_authority is None or not _input_authority.exists():
                raise global_step_proof_gate.GlobalStepProofError('INPUT_POOL_PROOF_SOURCE_MISSING')
            _input_proof = global_step_proof_gate.prove_input_binding(root=_resume_root, player_pool=_input_authority, expected_sha256=_pool_sha)
            print(json.dumps({'RUN_STATE':'STEP_PROOF','STEP':'INPUT_BOUND',**_input_proof},default=str),file=sys.stderr,flush=True)
    except Exception as exc:
        return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,failure_code=f'GLOBAL_STEP_PROOF_BOOT_FAILED:{type(exc).__name__}:{exc}')
    _durable_info=durable_run.initialize(
        root=_resume_root,run_identity=_run_identity,metadata={
            'STATE_TOKEN':_state_token,'STATE_VERSION':_state_version,'POOL_SHA256':_pool_sha,'ENGINE_SHA256':_engine_sha,
            'PLATFORM':_platform,'SPORT':a.sport.upper(),'MODE':a.mode.upper(),'EXECUTION_ID':str(a.execution_id),
        },
    )
    env.update({'APEX_DURABLE_RUN_LEDGER_PATCH_ID':durable_run.PATCH_ID,'APEX_DURABLE_RUN_ROOT':str(_resume_root)})
    board_file=None  # caller board injection prohibited by end-to-end hard fence
    pre_board_sig=_signature(board_file)
    pre_glob_sigs={}
    # caller board glob injection prohibited by end-to-end hard fence
    retry_attempt=0
    _invocation_started=time.monotonic()
    _checkpoint_continue_count=0
    _checkpoint_progress_token=None
    _checkpoint_no_progress_count=0
    _generic_progress_token=None
    _generic_no_progress_count=0
    _no_progress_limit=max(2,int(env.get('APEX_DETERMINISTIC_NO_PROGRESS_LIMIT','3')))
    while True:
        try:
            _durable_terminal=_durable_terminal_recovery(root=_resume_root,sport=a.sport,mode=a.mode,execution_id=a.execution_id,output_dir=out_dir)
        except Exception as exc:
            return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,failure_code=f'DURABLE_TERMINAL_RECOVERY_FAILED:{type(exc).__name__}:{exc}')
        if _durable_terminal is not None:
            if str(_durable_terminal.get('RUN_STATE','')) == 'HYBRID_SELECTOR_HANDOFF_REQUIRED':
                _durable_terminal=None
            else:
                resume_state.finalize_board_state(root=_resume_root,state=_resume_state,board_path=Path(_durable_terminal['BOARD_ARTIFACT_PATH']),board_size=int(_durable_terminal['FINAL_BOARD_SIZE']))
                try:
                    _terminal_proof=global_step_proof_gate.prove_terminal_board(root=_resume_root,terminal=_durable_terminal)
                    _chain_final=global_step_proof_gate.final_chain_receipt(root=_resume_root)
                    _durable_terminal['GLOBAL_STEP_PROOF']={'TERMINAL':_terminal_proof,'CHAIN':_chain_final}
                    print(json.dumps({'RUN_STATE':'STEP_PROOF','STEP':'TERMINAL_BOARD_PROVEN',**_terminal_proof},default=str),file=sys.stderr,flush=True)
                except Exception as exc:
                    return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,failure_code=f'GLOBAL_STEP_PROOF_TERMINAL_RECOVERY_FAILED:{type(exc).__name__}:{exc}')
                print(json.dumps(_durable_terminal,indent=2),flush=True)
                return 0
        env['APEX_TERMINAL_RETRY_ATTEMPT']=str(retry_attempt)
        _resume_state['CURRENT_PHASE']='ENGINE_RUNNING'; _resume_state['EXECUTION_STATE']='RUNNING'; _resume_state['RETRY_ATTEMPT']=int(retry_attempt); resume_state.atomic_json(_resume_root/'.session_state.json',_resume_state)
        _cmd_targets=[Path(x).resolve() for x in cmd if str(x).endswith('.py') and Path(x).exists()]
        if not _cmd_targets:
            return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,failure_code='AUTHORITATIVE_SPORT_RUNTIME_MISSING')
        _actual_target=_cmd_targets[-1]
        try:
            _registry=json.loads((Path(__file__).resolve().parents[2]/'engine_registry.json').read_text(encoding='utf-8'))
            _entry=_resolve_certified_chunk_stream_entrypoint(
                registry=_registry,sport=a.sport,mode=a.mode,root=Path(__file__).resolve().parents[2]
            )
        except Exception as exc:
            return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,failure_code=f'AUTHORITATIVE_CHUNK_STREAM_RUNTIME_RESOLUTION_FAILED:{type(exc).__name__}:{exc}')
        if _actual_target != _entry:
            return _invalid(
                sport=a.sport, mode=a.mode, execution_id=a.execution_id,
                failure_code=f'CANONICAL_ENTRYPOINT_SUBSTITUTION_PROHIBITED:{_actual_target}:{_entry}'
            )
        env['APEX_AUTHORITATIVE_ENGINE_ENTRYPOINT']=str(_entry)
        env['APEX_POLICY_SHA256']=hashlib.sha256(json.dumps(_registry_early,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        env['APEX_MODE_REQUIREMENTS_JSON']=json.dumps(_mode_requirements,sort_keys=True,separators=(',',':'))
        env['APEX_CHUNK_STREAM_EXECUTION_ENTRYPOINT']=str(_entry)
        try:
            _engine_bind_proof=global_step_proof_gate.prove_engine_binding(root=_resume_root,entrypoint=_entry,command=cmd)
            print(json.dumps({'RUN_STATE':'STEP_PROOF','STEP':'ENGINE_BOUND',**_engine_bind_proof},default=str),file=sys.stderr,flush=True)
        except Exception as exc:
            return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,failure_code=f'GLOBAL_STEP_PROOF_ENGINE_BIND_FAILED:{type(exc).__name__}:{exc}')
        try:
            role_receipt=external_caller_boundary.enforce_live_production_child(cmd, env)
        except Exception as exc:
            return _invalid(sport=a.sport, mode=a.mode, execution_id=a.execution_id,
                failure_code=f'ENGINE_ONLY_CALLER_BOUNDARY_FAILED:{type(exc).__name__}:{exc}')
        env['APEX_CHAT_ENGINE_ROLE_RECEIPT_STATUS']=str(role_receipt.get('STATUS','PASS'))
        proc=subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1, env=env)
        process_launched=True
        try:
            _process_proof=global_step_proof_gate.prove_process_launch(root=_resume_root,pid=proc.pid,entrypoint=_entry)
            print(json.dumps({'RUN_STATE':'STEP_PROOF','STEP':'PROCESS_LAUNCHED',**_process_proof},default=str),file=sys.stderr,flush=True)
        except Exception as exc:
            _terminate(proc)
            return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,failure_code=f'GLOBAL_STEP_PROOF_PROCESS_LAUNCH_FAILED:{type(exc).__name__}:{exc}')
        last_size=None; stable=0; stderr_tail=[]; json_buf=None; pending_native_board=None; last_terminal_obj=None
        while True:
            streams=[s for s in (proc.stdout,proc.stderr) if s is not None]
            if streams:
                ready,_,_=select.select(streams,[],[],0.05)
                for s in ready:
                    line=s.readline()
                    if not line: continue
                    if s is proc.stderr:
                        stderr_tail.append(line.rstrip()); stderr_tail=stderr_tail[-12:]
                        continue
                    txt=line.strip()
                    if not txt: continue
                    candidates=[]
                    try:
                        candidates.append(json.loads(txt))
                        json_buf=None
                    except Exception:
                        if json_buf is None and txt.startswith('{'):
                            json_buf=txt
                        elif json_buf is not None:
                            json_buf += '\n' + txt
                        if json_buf is not None:
                            try:
                                candidates.append(json.loads(json_buf)); json_buf=None
                            except Exception:
                                pass
                    for obj in candidates:
                        if not isinstance(obj,dict):
                            continue
                        _state=str(obj.get('RUN_STATE',''))
                        if _state:
                            last_terminal_obj=obj
                        _strict_core5, _strict_patch_id, _strict_scope = _strict_core5_terminal_contract(a.sport, a.mode)
                        _native_ready = _state in {'NATIVE_BOARD_READY_FOR_GLOBAL_CORE5','BOARD_READY','TOOL_PROVEN_EXECUTED'}
                        if _native_ready:
                            # Do not terminate the child at first board signal. The sport engine
                            # must finish writing its selector ledger, identity map, receipt, and
                            # any same-run seals. Premature termination created stale/mixed artifacts.
                            pending_native_board=obj
            candidate=board_file
            pre_sig=pre_board_sig
            if candidate is None and a.board_glob:
                found=sorted(out_dir.glob(a.board_glob), key=lambda p:p.stat().st_mtime_ns if p.exists() else 0, reverse=True)
                candidate=found[0].resolve() if found else None
                pre_sig=pre_glob_sigs.get(str(candidate)) if candidate else None
            if candidate and candidate.exists():
                sig=_signature(candidate)
                fresh = pre_sig is None or sig != pre_sig
                if fresh:
                    size=candidate.stat().st_size
                    stable = stable+1 if size>0 and size==last_size else 0
                    last_size=size
                    if stable>=2:
                        # Fresh board file is evidence only until the child exits cleanly.
                        # Never kill a still-writing production engine because a board CSV appeared.
                        pass
            rc=proc.poll()
            if rc is not None:
                if pending_native_board is not None:
                    try:
                        terminal=_finalize_pending_terminal_surface(
                            pending_native_board=pending_native_board,root=_resume_root,resume_state_obj=_resume_state,
                            sport=a.sport,mode=a.mode,execution_id=a.execution_id,output_dir=out_dir,child_return_code=rc,
                            source_board_file=(candidate if candidate is not None and candidate.exists() else None))
                        _terminal_proof=global_step_proof_gate.prove_terminal_board(root=_resume_root,terminal=terminal)
                        _chain_final=global_step_proof_gate.final_chain_receipt(root=_resume_root)
                        terminal['GLOBAL_STEP_PROOF']={'TERMINAL':_terminal_proof,'CHAIN':_chain_final}
                        print(json.dumps({'RUN_STATE':'STEP_PROOF','STEP':'TERMINAL_BOARD_PROVEN',**_terminal_proof},default=str),file=sys.stderr,flush=True)
                        print(json.dumps(terminal,indent=2),flush=True)
                        return 0
                    except Exception as exc:
                        # A valid terminal surface dominates the child exit.  If the surface itself
                        # is not valid, preserve fail-closed behavior and continue normal recovery.
                        stderr_tail.append(f'TERMINAL_SURFACE_SALVAGE_FAILED:{type(exc).__name__}:{exc}')
                        stderr_tail=stderr_tail[-12:]
                        if rc == 0:
                            return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,
                                failure_code=f'AUTONOMOUS_TERMINAL_SEAL_FAILED:{type(exc).__name__}:{exc}',child_return_code=rc,stderr_tail=stderr_tail)
                _recovery=external_recovery.detect(stderr_tail,last_terminal_obj)
                if _recovery is not None:
                    _request=external_recovery.build_request(recovery=_recovery,sport=a.sport,mode=a.mode,execution_id=a.execution_id,output_dir=out_dir,env=env,child_return_code=rc)
                    _variable=str(_request.get('VARIABLE') or _request.get('FAILURE_CODE') or 'UNRESOLVED_EXTERNAL_DATA')
                    _resume_state['EXECUTION_STATE']='FAILED'; _resume_state['CURRENT_PHASE']='EXTERNAL_DATA_PROVIDER_REQUIRED'; _resume_state['LAST_RECOVERABLE_FAILURE_CODE']=_variable; resume_state.atomic_json(_resume_root/'.session_state.json',_resume_state)
                    return _invalid(sport=a.sport, mode=a.mode, execution_id=a.execution_id,
                        failure_code=f'EXTERNAL_DATA_PROVIDER_REQUIRED:{_variable}', child_return_code=rc, stderr_tail=stderr_tail)
                # Checkpoint continuation is supervisor-owned. It never escapes to Chat.
                if rc == 75 and isinstance(last_terminal_obj,dict) and str(last_terminal_obj.get('RUN_STATE','')) == 'CHECKPOINTED_CONTINUE':
                    _resume_state['EXECUTION_STATE']='RESUMABLE'
                    _resume_state['CURRENT_PHASE']='ENGINE_CHECKPOINTED_CONTINUE'
                    _resume_state['ENGINE_REPORTED_NEXT_STAGE']=str(last_terminal_obj.get('NEXT_STAGE') or '')
                    _resume_state['ENGINE_OWNED_CHECKPOINT']=str(last_terminal_obj.get('CHECKPOINT') or '')
                    _resume_state['ENGINE_OWNED_CONTROLLER_STATE']=str(last_terminal_obj.get('CONTROLLER_STATE') or '')
                    _resume_state['ENGINE_OWNED_STAGE_INDEX']=int(last_terminal_obj.get('STAGE_INDEX',0) or 0)
                    _resume_state['CANONICAL_REENTRYPOINT']=str(_entry)
                    _resume_state['CALLER_STAGE_SELECTION_AUTHORITY']=False
                    resume_state.atomic_json(_resume_root/'.session_state.json',_resume_state)
                    _checkpoint_continue_count += 1
                    _progress=_progress_fingerprint(return_code=rc,failure_code='CHECKPOINTED_CONTINUE',terminal_obj=last_terminal_obj,resume_state_obj=_resume_state,candidate=candidate)
                    if _progress == _checkpoint_progress_token:
                        _checkpoint_no_progress_count += 1
                    else:
                        _checkpoint_progress_token=_progress; _checkpoint_no_progress_count=0
                    if _checkpoint_no_progress_count >= _no_progress_limit:
                        return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,
                            failure_code=f'DETERMINISTIC_NO_PROGRESS:CHECKPOINTED_CONTINUE:{_checkpoint_no_progress_count+1}',child_return_code=rc,stderr_tail=stderr_tail)
                    try:
                        _checkpoint_proof=global_step_proof_gate.prove_checkpoint_advance(
                            root=_resume_root, terminal_event=last_terminal_obj, child_return_code=rc, pid=proc.pid)
                        _advance_gate=global_step_proof_gate.require_ready_for_next_launch(
                            root=_resume_root, completed_stage=str(last_terminal_obj.get('COMPLETED_STAGE') or ''),
                            next_stage=str(last_terminal_obj.get('NEXT_STAGE') or ''))
                        print(json.dumps({'RUN_STATE':'STEP_PROOF','STEP':'CHECKPOINT_ADVANCE',**_checkpoint_proof,'ADVANCE_GATE':_advance_gate},default=str),file=sys.stderr,flush=True)
                    except Exception as exc:
                        return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,
                            failure_code=f'GLOBAL_STEP_PROOF_ADVANCE_BLOCKED:{type(exc).__name__}:{exc}',child_return_code=rc,stderr_tail=stderr_tail)
                    _machine_emit({
                        'RUN_STATE':'ENGINE_INTERNAL_AUTO_CONTINUE',
                        'EXECUTION_STATE':'RUNNING',
                        'PATCH_ID':AUTONOMOUS_SUPERVISOR_PATCH_ID,
                        'GLOBAL_STEP_PROOF_GATE':GLOBAL_STEP_PROOF_GATE_PATCH_ID,
                        'STEP_PROOF_RECEIPT_SHA256':_checkpoint_proof.get('STEP_RECEIPT_SHA256'),
                        'COMPLETED_STAGE':last_terminal_obj.get('COMPLETED_STAGE'),
                        'NEXT_STAGE':last_terminal_obj.get('NEXT_STAGE'),
                        'AUTO_CONTINUE_COUNT':_checkpoint_continue_count,
                        'NO_PROGRESS_COUNT':_checkpoint_no_progress_count,
                        'EXTERNAL_RESUME_REQUIRED':False,
                    },machine_reporting_provenance,stream=sys.stderr)
                    break
                if candidate and candidate.exists():
                    sig=_signature(candidate); fresh=pre_sig is None or sig != pre_sig
                    if fresh:
                        rows=_load_board(candidate)
                        if rows:
                            _strict_core5, _strict_patch_id, _strict_scope = _strict_core5_terminal_contract(a.sport, a.mode)
                            try:
                                sealed=_seal_board(rows=rows, sport=a.sport, mode=a.mode, execution_id=a.execution_id,
                                    output_dir=out_dir, board_source='FRESH_BOARD_FILE_AFTER_CHILD_EXIT', source_board_file=candidate)
                            except Exception as exc:
                                return _invalid(sport=a.sport, mode=a.mode, execution_id=a.execution_id,
                                    failure_code=f'BOARD_SEAL_FAILED:{type(exc).__name__}:{exc}', child_return_code=rc, stderr_tail=stderr_tail)
                            try:
                                resume_state.finalize_board_state(root=_resume_root,state=_resume_state,board_path=Path(sealed['BOARD_ARTIFACT_PATH']),board_size=int(sealed['FINAL_BOARD_SIZE']))
                            except Exception:
                                pass
                            try:
                                _terminal_proof=global_step_proof_gate.prove_terminal_board(root=_resume_root,terminal=sealed)
                                _chain_final=global_step_proof_gate.final_chain_receipt(root=_resume_root)
                                sealed['GLOBAL_STEP_PROOF']={'TERMINAL':_terminal_proof,'CHAIN':_chain_final}
                                print(json.dumps({'RUN_STATE':'STEP_PROOF','STEP':'TERMINAL_BOARD_PROVEN',**_terminal_proof},default=str),file=sys.stderr,flush=True)
                            except Exception as exc:
                                return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,
                                    failure_code=f'GLOBAL_STEP_PROOF_FINAL_BOARD_BLOCKED:{type(exc).__name__}:{exc}',child_return_code=rc,stderr_tail=stderr_tail)
                            print(json.dumps(sealed, indent=2)); return 0
                stale = bool(candidate and candidate.exists())
                failure=('STALE_OR_MISSING_MACHINE_BOARD_ARTIFACT' if stale else 'MACHINE_BOARD_ARTIFACT_MISSING')
                child_state='' if not isinstance(last_terminal_obj,dict) else str(last_terminal_obj.get('RUN_STATE',''))
                child_failure=failure if not isinstance(last_terminal_obj,dict) else str(last_terminal_obj.get('FAILURE_CODE') or failure)
                disposition=fast_path_contract.terminal_disposition(
                    run_state=child_state, failure_code=child_failure, child_return_code=rc)
                if disposition.get('DISPOSITION')=='TRUE_RUN_INVALID':
                    return _invalid(sport=a.sport, mode=a.mode, execution_id=a.execution_id,
                        failure_code=child_failure, child_return_code=rc, stderr_tail=stderr_tail)
                _fingerprint=_progress_fingerprint(return_code=rc,failure_code=child_failure,terminal_obj=last_terminal_obj,resume_state_obj=_resume_state,candidate=candidate)
                if _fingerprint == _generic_progress_token:
                    _generic_no_progress_count += 1
                else:
                    _generic_progress_token=_fingerprint; _generic_no_progress_count=0
                if _generic_no_progress_count >= _no_progress_limit:
                    return _invalid(sport=a.sport,mode=a.mode,execution_id=a.execution_id,
                        failure_code=f'DETERMINISTIC_NO_PROGRESS:{child_failure}:REPEATS={_generic_no_progress_count+1}',child_return_code=rc,stderr_tail=stderr_tail)
                retry_attempt += 1
                _resume_state['EXECUTION_STATE']='RESUMABLE'; _resume_state['CURRENT_PHASE']='ENGINE_RETRY_PENDING'; _resume_state['LAST_CHILD_RETURN_CODE']=rc; _resume_state['LAST_RECOVERABLE_FAILURE_CODE']=child_failure; _resume_state['RETRY_ATTEMPT']=retry_attempt; _resume_state['NO_PROGRESS_COUNT']=_generic_no_progress_count; resume_state.atomic_json(_resume_root/'.session_state.json',_resume_state)
                env['APEX_LAST_RECOVERABLE_EXIT_CODE']=str(rc)
                env['APEX_LAST_RECOVERABLE_FAILURE_CODE']=child_failure
                time.sleep(min(2.0, 0.10 * (2 ** min(retry_attempt, 5))))
                break

if __name__=='__main__':
    raise SystemExit(main())
