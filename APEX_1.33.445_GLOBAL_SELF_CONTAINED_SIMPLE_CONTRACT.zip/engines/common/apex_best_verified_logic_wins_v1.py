#!/usr/bin/env python3
"""Evidence-first production authority arbiter.

This module does not score lineups or consume live contest outcomes. It decides
which already-validated implementation should be authoritative at promotion
boundaries. Production incumbency is never a positive metric; it is used only
when the verified evidence vectors are exactly tied.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

PATCH_ID = "APEX_GLOBAL_BEST_VERIFIED_LOGIC_WINS_v1"

EVIDENCE_ORDER = (
    "WINNER_CAPTURE_COUNT",
    "PERFECT_CAPTURE_COUNT",
    "TOP_0_1_CAPTURE_COUNT",
    "NONREGRESSION_FAILURE_NEGATED",
    "NONREGRESSION_PASS_COUNT",
    "STRUCTURAL_PRELOCK_INTEGRITY",
    "BYTE_COMPLETE_BLIND_CONTROL_COUNT",
    "VERIFIED_CASE_COUNT",
)

class AuthorityEvidenceError(ValueError):
    pass

def _b(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().upper()
    if text in {"TRUE", "PASS", "YES", "Y", "1"}:
        return True
    if text in {"FALSE", "FAIL", "NO", "N", "0", "BLOCK"}:
        return False
    raise AuthorityEvidenceError(f"INVALID_BOOLEAN:{value}")

def _i(value: Any, default: int = 0) -> int:
    if value is None or value == "":
        return default
    n = int(value)
    if n < 0:
        raise AuthorityEvidenceError(f"NEGATIVE_COUNT:{value}")
    return n

@dataclass(frozen=True)
class Evidence:
    logic_id: str
    hard_integrity_pass: bool
    forward_isolation_pass: bool
    deterministic_replay_pass: bool
    state_compatibility_pass: bool
    identity_constant_free_pass: bool
    validation_depth_gate_pass: bool
    winner_capture_count: int
    perfect_capture_count: int
    top_0_1_capture_count: int
    nonregression_failure_count: int
    nonregression_pass_count: int
    structural_prelock_integrity: bool
    byte_complete_blind_control_count: int
    verified_case_count: int

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "Evidence":
        logic_id = str(raw.get("LOGIC_ID") or raw.get("PATCH_ID") or "").strip()
        if not logic_id:
            raise AuthorityEvidenceError("LOGIC_ID_REQUIRED")
        return cls(
            logic_id=logic_id,
            hard_integrity_pass=_b(raw.get("HARD_INTEGRITY_PASS"), True),
            forward_isolation_pass=_b(raw.get("FORWARD_ISOLATION_PASS"), True),
            deterministic_replay_pass=_b(raw.get("DETERMINISTIC_REPLAY_PASS"), True),
            state_compatibility_pass=_b(raw.get("STATE_COMPATIBILITY_PASS"), True),
            identity_constant_free_pass=_b(raw.get("IDENTITY_CONSTANT_FREE_PASS"), True),
            validation_depth_gate_pass=_b(raw.get("VALIDATION_DEPTH_GATE_PASS"), True),
            winner_capture_count=_i(raw.get("WINNER_CAPTURE_COUNT")),
            perfect_capture_count=_i(raw.get("PERFECT_CAPTURE_COUNT")),
            top_0_1_capture_count=_i(raw.get("TOP_0_1_CAPTURE_COUNT")),
            nonregression_failure_count=_i(raw.get("NONREGRESSION_FAILURE_COUNT")),
            nonregression_pass_count=_i(raw.get("NONREGRESSION_PASS_COUNT")),
            structural_prelock_integrity=_b(raw.get("STRUCTURAL_PRELOCK_INTEGRITY"), True),
            byte_complete_blind_control_count=_i(raw.get("BYTE_COMPLETE_BLIND_CONTROL_COUNT")),
            verified_case_count=_i(raw.get("VERIFIED_CASE_COUNT")),
        )

    def hard_gate_failures(self) -> list[str]:
        pairs = {
            "HARD_INTEGRITY_PASS": self.hard_integrity_pass,
            "FORWARD_ISOLATION_PASS": self.forward_isolation_pass,
            "DETERMINISTIC_REPLAY_PASS": self.deterministic_replay_pass,
            "STATE_COMPATIBILITY_PASS": self.state_compatibility_pass,
            "IDENTITY_CONSTANT_FREE_PASS": self.identity_constant_free_pass,
        }
        return [name for name, passed in pairs.items() if not passed]

    def evidence_vector(self) -> tuple[int, ...]:
        return (
            self.winner_capture_count,
            self.perfect_capture_count,
            self.top_0_1_capture_count,
            -self.nonregression_failure_count,
            self.nonregression_pass_count,
            int(self.structural_prelock_integrity),
            self.byte_complete_blind_control_count,
            self.verified_case_count,
        )

    def evidence_named(self) -> dict[str, int]:
        return dict(zip(EVIDENCE_ORDER, self.evidence_vector()))

def compare_authority(incumbent_raw: Mapping[str, Any], challenger_raw: Mapping[str, Any], *, operator_validation_depth_override: bool = False) -> dict[str, Any]:
    incumbent = Evidence.from_mapping(incumbent_raw)
    challenger = Evidence.from_mapping(challenger_raw)
    incumbent_hard = incumbent.hard_gate_failures()
    challenger_hard = challenger.hard_gate_failures()

    if incumbent_hard and challenger_hard:
        return {"PATCH_ID": PATCH_ID, "AUTHORITY": "NONE", "DECISION": "BLOCK_BOTH_HARD_GATE_FAILURE", "INCUMBENT_HARD_GATE_FAILURES": incumbent_hard, "CHALLENGER_HARD_GATE_FAILURES": challenger_hard, "INCUMBENCY_USED_AS_POSITIVE_EVIDENCE": False}
    if challenger_hard:
        return {"PATCH_ID": PATCH_ID, "AUTHORITY": incumbent.logic_id, "DECISION": "KEEP_INCUMBENT_CHALLENGER_HARD_GATE_FAILURE", "CHALLENGER_HARD_GATE_FAILURES": challenger_hard, "INCUMBENCY_USED_AS_POSITIVE_EVIDENCE": False}
    if incumbent_hard:
        if not challenger.validation_depth_gate_pass and not operator_validation_depth_override:
            return {"PATCH_ID": PATCH_ID, "AUTHORITY": "NONE", "DECISION": "BLOCK_INCUMBENT_HARD_FAIL_CHALLENGER_DEPTH_GATE", "INCUMBENT_HARD_GATE_FAILURES": incumbent_hard, "INCUMBENCY_USED_AS_POSITIVE_EVIDENCE": False}
        return {"PATCH_ID": PATCH_ID, "AUTHORITY": challenger.logic_id, "DECISION": "PROMOTE_CHALLENGER_INCUMBENT_HARD_GATE_FAILURE", "OPERATOR_VALIDATION_DEPTH_OVERRIDE": bool(operator_validation_depth_override), "INCUMBENCY_USED_AS_POSITIVE_EVIDENCE": False}

    iv = incumbent.evidence_vector()
    cv = challenger.evidence_vector()
    if cv > iv:
        if not challenger.validation_depth_gate_pass and not operator_validation_depth_override:
            return {"PATCH_ID": PATCH_ID, "AUTHORITY": incumbent.logic_id, "DECISION": "CHALLENGER_BETTER_EVIDENCE_BUT_VALIDATION_DEPTH_GATE_BLOCKED", "INCUMBENT_EVIDENCE": incumbent.evidence_named(), "CHALLENGER_EVIDENCE": challenger.evidence_named(), "INCUMBENCY_USED_AS_POSITIVE_EVIDENCE": False}
        return {"PATCH_ID": PATCH_ID, "AUTHORITY": challenger.logic_id, "DECISION": "PROMOTE_CHALLENGER_BETTER_VERIFIED_EVIDENCE", "INCUMBENT_EVIDENCE": incumbent.evidence_named(), "CHALLENGER_EVIDENCE": challenger.evidence_named(), "OPERATOR_VALIDATION_DEPTH_OVERRIDE": bool(operator_validation_depth_override), "INCUMBENCY_USED_AS_POSITIVE_EVIDENCE": False}
    if cv < iv:
        return {"PATCH_ID": PATCH_ID, "AUTHORITY": incumbent.logic_id, "DECISION": "KEEP_INCUMBENT_BETTER_VERIFIED_EVIDENCE", "INCUMBENT_EVIDENCE": incumbent.evidence_named(), "CHALLENGER_EVIDENCE": challenger.evidence_named(), "INCUMBENCY_USED_AS_POSITIVE_EVIDENCE": False}
    return {"PATCH_ID": PATCH_ID, "AUTHORITY": incumbent.logic_id, "DECISION": "KEEP_INCUMBENT_EXACT_EVIDENCE_TIE_ONLY", "INCUMBENT_EVIDENCE": incumbent.evidence_named(), "CHALLENGER_EVIDENCE": challenger.evidence_named(), "INCUMBENCY_USED_AS_POSITIVE_EVIDENCE": True}

def _load(path: str) -> Mapping[str, Any]:
    obj = json.loads(Path(path).read_text())
    if not isinstance(obj, dict):
        raise AuthorityEvidenceError("EVIDENCE_FILE_MUST_BE_JSON_OBJECT")
    return obj

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--incumbent", required=True)
    ap.add_argument("--challenger", required=True)
    ap.add_argument("--operator-validation-depth-override", action="store_true")
    ap.add_argument("--out")
    args = ap.parse_args()
    result = compare_authority(_load(args.incumbent), _load(args.challenger), operator_validation_depth_override=args.operator_validation_depth_override)
    text = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.out:
        Path(args.out).write_text(text)
    print(text, end="")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
