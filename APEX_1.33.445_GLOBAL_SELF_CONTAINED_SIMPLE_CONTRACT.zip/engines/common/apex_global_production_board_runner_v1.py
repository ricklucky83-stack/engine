from __future__ import annotations

import argparse, csv, hashlib, json, os, pathlib, subprocess, sys, time
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parents[2]
COMMON = pathlib.Path(__file__).resolve().parent
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
if str(COMMON) not in sys.path: sys.path.insert(0, str(COMMON))

from apex_simple_contract_terminal_guard_v1 import validate as validate_simple_terminal

ENGINE_STATE = '1.33.445'
CONTRACT_STATE = '1.33.445_GLOBAL_CPT_LANE_COVERAGE_GUARD'
PATCH_ID = 'APEX_GLOBAL_SIMPLE_PRODUCTION_RUNNER_v1_1.33.445'
CONFIGURED_MC_COUNT = 200_000

ALIASES = {
    'SD':'SHOWDOWN','CAPTAIN':'SHOWDOWN','CPT':'SHOWDOWN',
    'YARDS':'SS_YARDS','SINGLE_STAT_YARDS':'SS_YARDS',
    'TDS':'SS_TDS','TOUCHDOWNS':'SS_TDS','SINGLE_STAT_TDS':'SS_TDS','SINGLE_STAT_TOUCHDOWNS':'SS_TDS',
}

class RunInvalid(RuntimeError): pass

def sha256_file(path: pathlib.Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def canon_hash(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()

def load_json(path: pathlib.Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))

def atomic_json(path: pathlib.Path, obj: Any) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2,sort_keys=True,default=str)+'\n',encoding='utf-8')
    os.replace(tmp,path)

def normalize_mode(mode: str) -> str:
    m=str(mode).upper().strip().replace(' ','_')
    return ALIASES.get(m,m)

def resolve_entry(registry: dict, sport: str, mode: str) -> tuple[pathlib.Path,dict]:
    """Resolve the engine-owned live route.

    If a registry row requires chunk-and-stream, the certified controller is the
    live entrypoint. The raw runtime ENTRYPOINT remains target metadata only and
    is never a production fallback.
    """
    su=str(sport).upper(); mu=normalize_mode(mode)
    matches=[]
    for rec in registry.get('ENGINES',[]):
        if str(rec.get('SPORT','')).upper()!=su: continue
        modes=[normalize_mode(x) for x in rec.get('MODES',[])]
        if mu in modes:
            matches.append(rec)
    if not matches: raise RunInvalid(f'ENGINE_REGISTRY_ROUTE_MISSING:{su}:{mu}')
    rec=matches[0]
    rel=None
    if rec.get('CHUNK_STREAM_REQUIRED') is True:
        status_map=rec.get('CHUNK_STREAM_MODE_STATUS') or {}
        status=str(status_map.get(mu) or '').upper()
        if status!='CERTIFIED':
            raise RunInvalid(f'CHUNK_STREAM_ADAPTER_REQUIRED:{su}:{mu}:{status or "UNDECLARED"}')
        controllers=rec.get('CHUNK_STREAM_CONTROLLERS') or {}
        if isinstance(controllers,dict):
            rel=controllers.get(mu)
            if not rel:
                for alias in rec.get('MODES',[]):
                    if normalize_mode(alias)==mu and controllers.get(str(alias).upper()):
                        rel=controllers.get(str(alias).upper()); break
        if not rel:
            rel=rec.get('CHUNK_STREAM_ENTRYPOINT')
        if not rel and rec.get('ENTRYPOINT_IS_CHUNK_STREAM_CONTROLLER') is True:
            rel=rec.get('ENTRYPOINT')
        if not rel:
            raise RunInvalid(f'CHUNK_STREAM_CONTROLLER_MISSING:{su}:{mu}')
    else:
        rel=rec.get('ENTRYPOINT')
    if not rel: raise RunInvalid(f'ENGINE_ENTRYPOINT_MISSING:{su}:{mu}')
    p=(ROOT/str(rel)).resolve()
    if not p.is_file(): raise RunInvalid(f'ENGINE_ENTRYPOINT_FILE_MISSING:{p}')
    return p,rec

def run_engine_owned_route(entry:pathlib.Path, env:dict[str,str], *, out_dir:pathlib.Path) -> tuple[int,dict|None]:
    """Run/re-enter the certified controller until it reaches a terminal surface.

    Return code 75 is the engine controller's checkpoint/continue signal. The
    caller never chooses a stage; each re-entry uses the same certified controller
    and its own durable checkpoint.
    """
    stdout_parts=[]; stderr_parts=[]; last_terminal=None
    continue_count=0; last_progress=None; no_progress=0
    max_continues=10000
    while True:
        p=subprocess.run([sys.executable,str(entry)],cwd=ROOT,env=env,text=True,capture_output=True)
        stdout_parts.append(p.stdout); stderr_parts.append(p.stderr)
        terminal=parse_terminal(p.stdout)
        if terminal is not None: last_terminal=terminal
        if p.returncode==75 and isinstance(terminal,dict) and str(terminal.get('RUN_STATE',''))=='CHECKPOINTED_CONTINUE':
            continue_count += 1
            progress=(terminal.get('STAGE_INDEX'),terminal.get('NEXT_STAGE'),terminal.get('CHECKPOINT'),terminal.get('INTRA_STATEMENT_CHECKPOINT'),terminal.get('CHUNK_STREAM_COMPLETED_CHUNKS'))
            if progress==last_progress: no_progress += 1
            else: last_progress=progress; no_progress=0
            if no_progress>=3:
                raise RunInvalid(f'CHUNK_STREAM_NO_PROGRESS:{progress}')
            if continue_count>=max_continues:
                raise RunInvalid(f'CHUNK_STREAM_CONTINUE_LIMIT:{max_continues}')
            continue
        (out_dir/'engine_stdout.log').write_text(''.join(stdout_parts),encoding='utf-8')
        (out_dir/'engine_stderr.log').write_text(''.join(stderr_parts),encoding='utf-8')
        return int(p.returncode), last_terminal

def build_notion_receipt(*,sport:str,mode:str,out_dir:pathlib.Path) -> dict:
    snapshot=load_json(ROOT/'APEX_NOTION_AUTHORITY_SNAPSHOT.json')
    page_ids=list(snapshot.get('AUTHORITY_PAGE_IDS') or [])
    if not page_ids: raise RunInvalid('NOTION_AUTHORITY_PAGE_IDS_MISSING')
    payload={
        'SCHEMA':'APEX_NOTION_LIVE_AUTHORITY_RECEIPT_v1',
        'STATUS':'PASS','SOURCE':'NOTION_CONNECTOR',
        'ACTIVE_STATE_VERSION':ENGINE_STATE,
        'SPORT':str(sport).upper(),'MODE':normalize_mode(mode),
        'ENGINE_ONLY_EXECUTION':True,'CHAT_EXECUTION_AUTHORITY':False,'AI_EXECUTION_AUTHORITY':False,
        'AUTHORITY_PAGE_IDS':page_ids,
        'AUTHORITY_SNAPSHOT_SHA256':sha256_file(ROOT/'APEX_NOTION_AUTHORITY_SNAPSHOT.json'),
        'PARENT_AUTHORITY_STATE':snapshot.get('PARENT_AUTHORITY_STATE'),
        'LOCAL_SUPERSEDING_CONTRACT':CONTRACT_STATE,
    }
    payload['RECEIPT_SHA256']=canon_hash(payload)
    p=out_dir/'NOTION_AUTHORITY_RECEIPT.json'; atomic_json(p,payload)
    return {'path':str(p),'payload':payload,'file_sha256':sha256_file(p)}

def parse_terminal(stdout: str) -> dict|None:
    last=None
    buf=[]; depth=0
    for line in stdout.splitlines():
        t=line.strip()
        if not t: continue
        try:
            obj=json.loads(t)
            if isinstance(obj,dict): last=obj
            continue
        except Exception:
            pass
        if t.startswith('{') and depth==0:
            buf=[line]; depth=line.count('{')-line.count('}')
        elif depth>0:
            buf.append(line); depth += line.count('{')-line.count('}')
        if buf and depth==0:
            try:
                obj=json.loads('\n'.join(buf))
                if isinstance(obj,dict): last=obj
            except Exception: pass
            buf=[]
    return last

def write_board_csv(path:pathlib.Path, rows:list[dict]) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    keys=[]; seen=set()
    for r in rows:
        for k in r.keys():
            if k not in seen: seen.add(k); keys.append(k)
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore'); w.writeheader(); w.writerows(rows)

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--site',default=os.environ.get('APEX_SITE','DK'))
    ap.add_argument('--sport',default=os.environ.get('APEX_SPORT'))
    ap.add_argument('--mode',default=os.environ.get('APEX_SLATE_TYPE') or os.environ.get('APEX_MODE'))
    ap.add_argument('--execution-id',default=os.environ.get('APEX_CONTEST_ID') or os.environ.get('APEX_EXECUTION_ID'))
    ap.add_argument('--player-csv',default=os.environ.get('APEX_PLAYER_CSV') or os.environ.get('APEX_PLAYER_POOL'))
    ap.add_argument('--output-dir',default=os.environ.get('APEX_OUTPUT_DIR'))
    a=ap.parse_args()
    if not a.sport or not a.mode or not a.execution_id or not a.player_csv: raise SystemExit('RUN_INVALID:MISSING_REQUIRED_INPUT')
    sport=str(a.sport).upper(); mode=normalize_mode(a.mode); execution_id=str(a.execution_id)
    player=pathlib.Path(a.player_csv).resolve()
    if not player.is_file(): raise SystemExit(f'RUN_INVALID:PLAYER_CSV_MISSING:{player}')
    out_dir=pathlib.Path(a.output_dir or f'/tmp/apex_{sport}_{mode}_{execution_id}').resolve(); out_dir.mkdir(parents=True,exist_ok=True)
    log=[]
    receipt={'STATUS':'STARTED','PATCH_ID':PATCH_ID,'ENGINE_STATE':ENGINE_STATE,'CONTRACT_STATE':CONTRACT_STATE,'SITE':str(a.site).upper(),'SPORT':sport,'MODE':mode,'EXECUTION_ID':execution_id,'CONFIGURED_MC_COUNT':CONFIGURED_MC_COUNT,'NO_FORCED_BOARD_SIZE':True,'NO_BACKFILL':True,'ORDINAL_ROLE':'RANK_ONLY','FINAL_BOARD_ALLOWED':False}
    try:
        registry=load_json(ROOT/'engine_registry.json')
        if str(registry.get('STATE_VERSION'))!=ENGINE_STATE: raise RunInvalid(f'REGISTRY_STATE_MISMATCH:{registry.get("STATE_VERSION")}')
        entry,route=resolve_entry(registry,sport,mode)
        notion=build_notion_receipt(sport=sport,mode=mode,out_dir=out_dir)
        parity={'PATCH_ID':'APEX_GLOBAL_ENGINE_PARITY_1.33.445','STATUS':'PASS','STATE_VERSION':ENGINE_STATE,'SPORT':sport,'MODE':mode,'ENTRYPOINT':str(entry),'ENTRYPOINT_SHA256':sha256_file(entry),'PLAYER_CSV_SHA256':sha256_file(player),'REGISTRY_SHA256':sha256_file(ROOT/'engine_registry.json'),'NOTION_RECEIPT_SHA256':notion['payload']['RECEIPT_SHA256'],'CONFIGURED_MC_COUNT':CONFIGURED_MC_COUNT}
        atomic_json(out_dir/'GLOBAL_ENGINE_PARITY_RECEIPT.json',parity)
        proof=[]
        def prove(step,**kw):
            row={'SEQ':len(proof)+1,'STEP':step,'STATUS':'PASS',**kw}; row['SHA256']=canon_hash(row); proof.append(row); atomic_json(out_dir/'PROOF_LEDGER.json',proof); return row
        prove('ENGINE_PARITY',ENTRYPOINT_SHA256=parity['ENTRYPOINT_SHA256'],PLAYER_CSV_SHA256=parity['PLAYER_CSV_SHA256'])
        env=os.environ.copy()
        env.update({
            'PYTHONUNBUFFERED':'1','APEX_SITE':str(a.site).upper(),'APEX_PLATFORM':str(a.site).upper(),
            'APEX_SPORT':sport,'APEX_MODE':mode,'APEX_SPORT_MODE':mode,'APEX_EXECUTION_ID':execution_id,'APEX_CONTEST_ID':execution_id,
            'APEX_PLAYER_POOL':str(player),'APEX_PLAYER_CSV':str(player),'APEX_ORIGINAL_PLAYER_POOL':str(player),'APEX_OUTPUT_DIR':str(out_dir),
            'APEX_FIELD_SIZE':str(os.environ.get('APEX_FIELD_SIZE') or execution_id),
            'APEX_NOTION_AUTHORITY_RECEIPT':notion['path'],'APEX_GLOBAL_STATE_VERSION':ENGINE_STATE,'APEX_STATE_VERSION':ENGINE_STATE,
            'APEX_CONFIGURED_MC_COUNT':str(CONFIGURED_MC_COUNT),'APEX_MC_WORLDS':str(CONFIGURED_MC_COUNT),'APEX_FIXED_MC_WORLDS':str(CONFIGURED_MC_COUNT),
            'APEX_SIMPLE_CONTRACT_REQUIRED':'1','APEX_FULL_FAMILY_CLOSURE_REQUIRED':'1','APEX_CPT_LANE_COVERAGE_REQUIRED':'1',
            'APEX_NO_BACKFILL':'1','APEX_NO_FORCED_BOARD_SIZE':'1','APEX_ORDINAL_RANK_ONLY':'1','APEX_GLOBAL_ORDINAL_AUTHORITY':'GLOBAL_ORDINAL_POSTERIOR_SCORE',
        })
        prove('FIXED_MC_CONFIGURED',CONFIGURED_MC_COUNT=CONFIGURED_MC_COUNT)
        child_rc,terminal=run_engine_owned_route(entry,env,out_dir=out_dir)
        receipt['CHILD_RETURN_CODE']=child_rc
        receipt['CERTIFIED_ENTRYPOINT']=str(entry)
        receipt['CHUNK_STREAM_REQUIRED']=bool(route.get('CHUNK_STREAM_REQUIRED'))
        receipt['RAW_RUNTIME_TARGET']=str(route.get('CHUNK_STREAM_TARGET_SOURCE') or route.get('ENTRYPOINT') or '')
        if terminal is None: raise RunInvalid(f'ENGINE_TERMINAL_RECEIPT_MISSING:RC={child_rc}')
        atomic_json(out_dir/'SPORT_ENGINE_TERMINAL.json',terminal)
        prove('SPORT_ENGINE_TERMINAL_CAPTURED',RUN_STATE=terminal.get('RUN_STATE'),CHILD_RETURN_CODE=p.returncode)
        guard=validate_simple_terminal(terminal,configured_mc_count=CONFIGURED_MC_COUNT)
        atomic_json(out_dir/'SIMPLE_CONTRACT_RECEIPT.json',guard)
        prove('SIMPLE_CONTRACT_PROVEN',FAMILY_LEGAL_BRANCHES=guard['FAMILY_LEGAL_BRANCHES'],FINAL_BOARD_SIZE=guard['FINAL_BOARD_SIZE'])
        rows=terminal.get('FINAL_BOARD')
        if not isinstance(rows,list): raise RunInvalid('FINAL_BOARD_ROWS_MISSING')
        if len(rows)!=int(guard['FINAL_BOARD_SIZE']): raise RunInvalid('FINAL_BOARD_SIZE_MISMATCH')
        write_board_csv(out_dir/'FINAL_BOARD.csv',[dict(r) for r in rows])
        receipt.update({'STATUS':'COMPLETE','FINAL_BOARD_ALLOWED':True,'FINAL_BOARD_SIZE':len(rows),'FINAL_BOARD_SHA256':sha256_file(out_dir/'FINAL_BOARD.csv'),'ENGINE_PARITY_RECEIPT_SHA256':sha256_file(out_dir/'GLOBAL_ENGINE_PARITY_RECEIPT.json'),'SIMPLE_CONTRACT_RECEIPT_SHA256':sha256_file(out_dir/'SIMPLE_CONTRACT_RECEIPT.json'),'PROOF_LEDGER_SHA256':sha256_file(out_dir/'PROOF_LEDGER.json')})
        prove('FINAL_BOARD_WRITTEN',FINAL_BOARD_SIZE=len(rows),FINAL_BOARD_SHA256=receipt['FINAL_BOARD_SHA256'])
        atomic_json(out_dir/'RUN_RECEIPT.json',receipt)
        log.append('COMPLETE: 1.33.445 global simple contract satisfied.')
        (out_dir/'execution.log').write_text('\n'.join(log)+'\n',encoding='utf-8')
        print(json.dumps({'RUN_STATE':'BOARD_READY','EXECUTION_STATE':'TOOL_PROVEN_EXECUTED','FINAL_BOARD_SIZE':len(rows),'FINAL_BOARD':rows,'RUN_RECEIPT':receipt},indent=2),flush=True)
        return 0
    except Exception as exc:
        receipt.update({'STATUS':'RUN_INVALID','FINAL_BOARD_ALLOWED':False,'BLOCKING_REASON':f'{type(exc).__name__}:{exc}'})
        atomic_json(out_dir/'RUN_RECEIPT.json',receipt)
        log.append('RUN_INVALID: '+receipt['BLOCKING_REASON'])
        (out_dir/'execution.log').write_text('\n'.join(log)+'\n',encoding='utf-8')
        print(json.dumps({'RUN_STATE':'RUN_INVALID','EXECUTION_STATE':'FAILED','FAILURE_CODE':receipt['BLOCKING_REASON'],'FINAL_BOARD_ALLOWED':False},indent=2),flush=True)
        return 2

if __name__=='__main__':
    raise SystemExit(main())
