from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from typing import Callable, Iterable
import math
import numpy as np
from engines.common import apex_entry_limit_game_theory_v1 as entry_limit_game

PATCH_ID = "APEX_GLOBAL_CONTEST_FIELD_REALISM_CONTRACT_v1"
ENTRY_LIMIT_PATCH_ID = entry_limit_game.PATCH_ID

@dataclass(frozen=True)
class ContestPayload:
    field_size: int
    entry_fee: float | None = None
    max_entries: int | None = None
    payout_curve: tuple = ()
    contest_type: str = "GPP"
    user_entries: int | None = None
    pct_to_first: float | None = None
    pct_paid: float | None = None
    stake_bucket: str | None = None
    slate_size: int | None = None

class SyntheticFieldError(RuntimeError):
    pass

def _canon(lineup):
    return tuple(lineup)

def derive_field_statistics(lineups):
    lineups = [_canon(x) for x in lineups]
    n = len(lineups)
    if not n:
        raise SyntheticFieldError("EMPTY_SYNTHETIC_FIELD")
    players, pairs, exact = Counter(), Counter(), Counter(lineups)
    for lu in lineups:
        uniq = tuple(dict.fromkeys(lu))
        players.update(uniq)
        for i, a in enumerate(uniq):
            for b in uniq[i + 1:]:
                pairs[tuple(sorted((a, b)))] += 1
    return {
        "FIELD_LINEUPS": n,
        "PLAYER_OWNERSHIP": {k: v / n for k, v in players.items()},
        "PAIR_OWNERSHIP": {f"{a}|{b}": v / n for (a, b), v in pairs.items()},
        "EXACT_LINEUP_DUPLICATION": {"|".join(map(str, k)): v for k, v in exact.items()},
        "MAX_EXACT_DUPLICATION": max(exact.values()),
    }

class SyntheticFieldGenerator:
    """Production-safe field generator. Samples only from legal lineup objects."""
    def __init__(self, payload: ContestPayload, seed: int | None = None):
        self.payload = payload
        self.rng = np.random.default_rng(seed)

    def _legal_source(self, legal_lineups=None, legal_lineup_builder=None, lineup_weights=None):
        if legal_lineups is None:
            if legal_lineup_builder is None:
                raise SyntheticFieldError("LEGAL_LINEUP_SOURCE_REQUIRED")
            legal_lineups = list(legal_lineup_builder())
        else:
            legal_lineups = list(legal_lineups)
        if not legal_lineups:
            raise SyntheticFieldError("EMPTY_LEGAL_LINEUP_UNIVERSE")
        n = len(legal_lineups)
        w = np.ones(n, float) if lineup_weights is None else np.asarray(lineup_weights, float)
        if len(w) != n or np.any(~np.isfinite(w)) or np.any(w < 0) or w.sum() <= 0:
            raise SyntheticFieldError("INVALID_LINEUP_WEIGHTS")
        return legal_lineups, w / w.sum()

    def generate_opponent_portfolios(self, *, legal_lineups: Iterable | None = None, legal_lineup_builder: Callable | None = None, lineup_weights=None):
        """Generate opponent entries as coordinated owner-level portfolios.

        Within an owner portfolio, exact lineup duplicates are suppressed when the
        legal universe has enough distinct lineups. This preserves the fact that a
        28-max/150-max opponent has a portfolio, not 28/150 independent identities.
        """
        legal_lineups, p = self._legal_source(legal_lineups, legal_lineup_builder, lineup_weights)
        cap = int(self.payload.max_entries or 1)
        ours = int(self.payload.user_entries or 0)
        sizes = entry_limit_game.opponent_portfolio_sizes(
            field_size=int(self.payload.field_size), max_entries=cap, user_entries=ours
        )
        portfolios = []
        n = len(legal_lineups)
        for size in sizes:
            replace = size > n
            idx = self.rng.choice(n, size=int(size), replace=replace, p=p)
            portfolios.append([_canon(legal_lineups[int(i)]) for i in np.atleast_1d(idx)])
        flat = [lu for portfolio in portfolios for lu in portfolio]
        stats = derive_field_statistics(flat) if flat else {
            "FIELD_LINEUPS": 0, "PLAYER_OWNERSHIP": {}, "PAIR_OWNERSHIP": {},
            "EXACT_LINEUP_DUPLICATION": {}, "MAX_EXACT_DUPLICATION": 0,
        }
        stats.update({
            "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
            "CONTEST_MAX_ENTRIES": cap,
            "USER_ENTRIES": ours,
            "OPPONENT_PORTFOLIOS": len(portfolios),
            "OPPONENT_PORTFOLIO_SIZES": sizes,
            "OPPONENT_ENTRY_COUNT": len(flat),
            "SYMMETRIC_ENTRY_LIMIT": True,
        })
        return portfolios, stats

    def generate(self, *, legal_lineups: Iterable | None = None, legal_lineup_builder: Callable | None = None, lineup_weights=None):
        # Backward-compatible flat field API. When max_entries is known, build the
        # field through owner portfolios first, then flatten for legacy consumers.
        if self.payload.max_entries:
            portfolios, stats = self.generate_opponent_portfolios(
                legal_lineups=legal_lineups, legal_lineup_builder=legal_lineup_builder, lineup_weights=lineup_weights
            )
            return [lu for portfolio in portfolios for lu in portfolio], stats
        legal_lineups, p = self._legal_source(legal_lineups, legal_lineup_builder, lineup_weights)
        idx = self.rng.choice(len(legal_lineups), size=int(self.payload.field_size), replace=True, p=p)
        field = [_canon(legal_lineups[int(i)]) for i in idx]
        stats = derive_field_statistics(field)
        stats.update({
            "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
            "SYMMETRIC_ENTRY_LIMIT": False,
            "ENTRY_LIMIT_CONTEXT_MISSING": True,
        })
        return field, stats

def selector_evidence_gate(*, tail_equity, expected_field_ownership, rarity_bonus=0.0, geometry_bonus=0.0, min_tail_equity=0.0):
    q = float(tail_equity or 0.0)
    if not math.isfinite(q) or q <= max(0.0, float(min_tail_equity)):
        return {"decision": "REJECT_LINEUP", "edge": float("-inf")}
    own = max(1e-9, float(expected_field_ownership))
    base = math.log(max(1e-9, q)) - math.log(own)
    edge = base + min(0.10, max(-0.10, float(rarity_bonus))) + min(0.10, max(-0.10, float(geometry_bonus)))
    return {"decision": "PROMOTE_TO_BOARD" if edge > 0 else "REJECT_LINEUP", "edge": edge}

class SelectorEvidenceGate:
    @staticmethod
    def evaluate_lineup_edge(candidate_scores, field_scores, contest_payload: ContestPayload, min_top001_prob=0.0):
        c = np.asarray(candidate_scores, float)
        f = np.asarray(field_scores, float)
        if c.ndim != 1 or f.ndim != 2 or f.shape[0] != c.shape[0]:
            raise SyntheticFieldError("SIMULATION_SHAPE_MISMATCH")
        k = max(1, int(math.ceil(contest_payload.field_size * 0.001)))
        kth = np.partition(f, f.shape[1] - k, axis=1)[:, f.shape[1] - k]
        prob = float(np.mean(c >= kth))
        return {
            "decision": "PROMOTE_TO_BOARD" if prob > float(min_top001_prob) else "REJECT_LINEUP",
            "top001_probability": prob,
            "threshold_rank": k,
        }
