from __future__ import annotations

"""Global exact-role common-world terminal head intelligence.

This kernel is sport-agnostic. Sport/mode adapters own roster-role semantics,
family construction, and the common-world score tape. The shared layer only
compares already-legal, already-selected lineups on the exact same stochastic
worlds and returns uncertainty-aware ordinal evidence.

Family evidence is context only. It can identify neighborhoods and break exact
ties, but it cannot override the exact-role common-world posterior.
"""

from dataclasses import dataclass
from typing import Any, Sequence
import math
import numpy as np

PATCH_ID = "APEX_GLOBAL_CONDITIONAL_FAMILY_ORDINAL_HEAD_v1"
MEMBERSHIP_MUTATION_ALLOWED = False
POSTLOCK_INPUT_ALLOWED = False
FAMILY_CONTEXT_TERMINAL_AUTHORITY = False
EXACT_ROLE_COMMON_WORLD_HEAD_AUTHORITY = True
DEFAULT_HEAD_SIZE = 15
MIN_LIVE_COMMON_WORLDS = 4096
TARGET_COMMON_WORLDS = 10000


class ConditionalFamilyOrdinalHeadError(RuntimeError):
    pass


def _pct(a: np.ndarray, *, higher: bool = True) -> np.ndarray:
    a=np.asarray(a,dtype=np.float64)
    out=np.full(len(a),np.nan,dtype=np.float64)
    good=np.flatnonzero(np.isfinite(a))
    if len(good)==0:
        return out
    vals=a[good]
    order=np.argsort(vals,kind="mergesort")
    ranks=np.empty(len(good),dtype=np.float64)
    i=0
    while i<len(order):
        j=i+1
        while j<len(order) and vals[order[j]]==vals[order[i]]:
            j+=1
        avg=((i+j-1)/2.0+0.5)/max(1,len(order))
        ranks[order[i:j]]=avg
        i=j
    out[good]=ranks if higher else (1.0-ranks)
    return out


def _blend(parts: Sequence[tuple[np.ndarray,float]], n: int) -> np.ndarray:
    num=np.zeros(n,dtype=np.float64)
    den=np.zeros(n,dtype=np.float64)
    for a,w in parts:
        a=np.asarray(a,dtype=np.float64)
        good=np.isfinite(a)
        num[good]+=a[good]*float(w)
        den[good]+=float(w)
    return np.divide(num,den,out=np.full(n,0.5,dtype=np.float64),where=den>0)


@dataclass(frozen=True)
class ExactRoleHeadResult:
    head_score: np.ndarray
    p_rank1: np.ndarray
    p_top3: np.ndarray
    p_top5: np.ndarray
    p_top10: np.ndarray
    expected_rank: np.ndarray
    median_rank: np.ndarray
    rank_p90: np.ndarray
    rank_std: np.ndarray
    pairwise_strength: np.ndarray
    pairwise_margin_mean: np.ndarray
    p_sibling_best: np.ndarray
    rank_stability: np.ndarray
    rank_uncertainty_width: np.ndarray
    order: np.ndarray
    receipt: dict[str,Any]


def _validate_scores(lineup_world_scores: Any) -> np.ndarray:
    x=np.asarray(lineup_world_scores,dtype=np.float64)
    if x.ndim!=2 or x.shape[0]<1 or x.shape[1]<2:
        raise ConditionalFamilyOrdinalHeadError("GLOBAL_HEAD_SCORE_TAPE_SHAPE_INVALID")
    if not np.all(np.isfinite(x)):
        raise ConditionalFamilyOrdinalHeadError("GLOBAL_HEAD_SCORE_TAPE_NONFINITE")
    return x


def _family_labels(family_ids: Any, n: int) -> np.ndarray:
    if family_ids is None:
        return np.arange(n,dtype=np.int64)
    x=np.asarray(family_ids)
    if x.ndim!=1 or len(x)!=n:
        raise ConditionalFamilyOrdinalHeadError("GLOBAL_HEAD_FAMILY_LENGTH_MISMATCH")
    return x


def evaluate_exact_role_common_world_head(
    lineup_world_scores: Any,
    *,
    family_ids: Any = None,
    family_context_score: Any = None,
    base_order_score: Any = None,
    head_size: int = DEFAULT_HEAD_SIZE,
    min_live_worlds: int = MIN_LIVE_COMMON_WORLDS,
    target_worlds: int = TARGET_COMMON_WORLDS,
    chunk_worlds: int = 256,
) -> ExactRoleHeadResult:
    """Return exact-role common-world ordinal evidence for a frozen board.

    Input shape is ``[worlds, lineups]``. The caller is responsible for exact
    sport/mode scoring (including multiplier slots such as CPT) before calling
    this function. No player identity, postlock truth, or lineup membership
    mutation is used here.
    """
    scores=_validate_scores(lineup_world_scores)
    worlds,n=scores.shape
    fam=_family_labels(family_ids,n)
    if family_context_score is None:
        family=np.full(n,np.nan,dtype=np.float64)
    else:
        family=np.asarray(family_context_score,dtype=np.float64).reshape(-1)
        if len(family)!=n:
            raise ConditionalFamilyOrdinalHeadError("GLOBAL_HEAD_FAMILY_CONTEXT_LENGTH_MISMATCH")
    if base_order_score is None:
        base=np.zeros(n,dtype=np.float64)
    else:
        base=np.asarray(base_order_score,dtype=np.float64).reshape(-1)
        if len(base)!=n:
            raise ConditionalFamilyOrdinalHeadError("GLOBAL_HEAD_BASE_ORDER_LENGTH_MISMATCH")
        base=np.nan_to_num(base,nan=-1.0,posinf=-1.0,neginf=-1.0)

    # Competition ranks (ties share rank) and pairwise comparisons are computed
    # on the same worlds. Chunking bounds memory for 150-row boards.
    ranks=np.empty((worlds,n),dtype=np.uint16 if n<65535 else np.uint32)
    beat=np.zeros((n,n),dtype=np.float64)
    tie=np.zeros((n,n),dtype=np.float64)
    c=max(1,int(chunk_worlds))
    for lo in range(0,worlds,c):
        hi=min(worlds,lo+c)
        s=scores[lo:hi]
        # cmp[w,i,j] => lineup i beats lineup j.
        cmp=s[:,:,None] > s[:,None,:]
        eq=s[:,:,None] == s[:,None,:]
        beat += cmp.sum(axis=0,dtype=np.float64)
        tie += eq.sum(axis=0,dtype=np.float64)
        ranks[lo:hi]=(1 + cmp.sum(axis=1,dtype=np.int32)).astype(ranks.dtype)

    denom=float(worlds)
    p_rank1=np.mean(ranks==1,axis=0)
    p_top3=np.mean(ranks<=3,axis=0)
    p_top5=np.mean(ranks<=5,axis=0)
    p_top10=np.mean(ranks<=min(10,n),axis=0)
    expected=np.mean(ranks,axis=0,dtype=np.float64)
    median=np.median(ranks,axis=0).astype(np.float64)
    p90=np.quantile(ranks,0.90,axis=0).astype(np.float64)
    std=np.std(ranks,axis=0,dtype=np.float64)
    stability=1.0/(1.0+std)
    uncertainty=np.maximum(0.0,p90-median)

    pairprob=(beat + 0.5*tie)/denom
    np.fill_diagonal(pairprob,np.nan)
    pairwise=np.nanmean(pairprob,axis=1)

    # Mean pairwise scoring margin, retained as telemetry; rankings use its
    # percentile only as a late discriminator, not raw cross-sport units.
    score_mean=np.mean(scores,axis=0)
    if n>1:
        pair_margin=(n*score_mean-score_mean.sum())/(n-1)
    else:
        pair_margin=np.zeros(n,dtype=np.float64)

    # Within-family best probability. Ties split one unit of probability across
    # the tied family members so each family's probabilities sum to ~1.
    sibling=np.ones(n,dtype=np.float64)
    for label in np.unique(fam):
        ids=np.flatnonzero(fam==label)
        if len(ids)<=1:
            sibling[ids]=1.0
            continue
        ss=scores[:,ids]
        mx=np.max(ss,axis=1,keepdims=True)
        is_best=(ss==mx)
        tie_count=np.sum(is_best,axis=1,keepdims=True)
        sibling[ids]=np.mean(is_best/np.maximum(1,tie_count),axis=0)

    # Shared deterministic aggregation. No family-context term enters the score.
    # Family is allowed only as a tie-break after exact-role posterior evidence.
    head_score=_blend((
        (_pct(p_rank1),0.24),
        (_pct(p_top3),0.18),
        (_pct(p_top5),0.14),
        (_pct(expected,higher=False),0.14),
        (_pct(p90,higher=False),0.10),
        (_pct(pairwise),0.10),
        (_pct(sibling),0.06),
        (_pct(stability),0.03),
        (_pct(pair_margin),0.01),
    ),n)

    family_tie=np.nan_to_num(_pct(family),nan=-1.0)
    idx=np.arange(n,dtype=np.int64)
    order=np.lexsort((idx,-base,-family_tie,-head_score)).astype(np.int32)

    hs=min(max(1,int(head_size)),n)
    top=order[:hs]
    unresolved=0
    max_halfwidth=0.0
    if len(top)>=2:
        for a in range(len(top)):
            for b in range(a+1,len(top)):
                p=float(pairprob[top[a],top[b]])
                if not math.isfinite(p):
                    continue
                se=math.sqrt(max(0.0,p*(1.0-p))/max(1,worlds))
                hw=1.96*se
                max_halfwidth=max(max_halfwidth,hw)
                if abs(p-0.5) <= hw:
                    unresolved+=1

    min_live=max(1,int(min_live_worlds))
    target=max(min_live,int(target_worlds))
    live=bool(worlds>=min_live)
    add=max(0,min_live-worlds)
    if live and unresolved>0 and worlds<target:
        add=max(add,target-worlds)

    receipt={
        "PATCH_ID":PATCH_ID,
        "MEMBERSHIP_MUTATION_ALLOWED":False,
        "POSTLOCK_INPUT_USED":False,
        "FAMILY_CONTEXT_TERMINAL_AUTHORITY":False,
        "FAMILY_CONTEXT_ROLE":"DISCOVERY_PRIOR_AND_TIEBREAK_ONLY",
        "EXACT_ROLE_COMMON_WORLD_HEAD_AUTHORITY":True,
        "COMMON_WORLDS":int(worlds),
        "LINEUPS":int(n),
        "HEAD_SIZE":int(hs),
        "MIN_LIVE_COMMON_WORLDS":int(min_live),
        "TARGET_COMMON_WORLDS":int(target),
        "LIVE_HEAD_AUTHORITY_READY":live,
        "UNRESOLVED_HEAD_PAIRS":int(unresolved),
        "MAX_HEAD_PAIR_95_HALF_WIDTH":float(max_halfwidth),
        "ADDITIONAL_WORLDS_RECOMMENDED":int(add),
        "ADAPTIVE_EXPANSION_RECOMMENDED":bool(add>0),
        "ROLE_SCORING_AUTHORITY":"SPORT_MODE_ADAPTER_EXACT_ROLE_SCORE_TAPE",
        "OUTPUT_CHANNELS":[
            "P_BOARD_RANK_1","P_BOARD_RANK_TOP3","P_BOARD_RANK_TOP5","P_BOARD_RANK_TOP10",
            "EXPECTED_BOARD_RANK","MEDIAN_BOARD_RANK","BOARD_RANK_P90","BOARD_RANK_STD",
            "PAIRWISE_BEAT_STRENGTH","PAIRWISE_MARGIN_MEAN","P_SIBLING_BEST",
            "RANK_STABILITY","RANK_UNCERTAINTY_WIDTH","EXACT_ROLE_HEAD_SCORE",
        ],
    }
    return ExactRoleHeadResult(
        head_score=head_score,
        p_rank1=p_rank1,
        p_top3=p_top3,
        p_top5=p_top5,
        p_top10=p_top10,
        expected_rank=expected,
        median_rank=median,
        rank_p90=p90,
        rank_std=std,
        pairwise_strength=pairwise,
        pairwise_margin_mean=pair_margin,
        p_sibling_best=sibling,
        rank_stability=stability,
        rank_uncertainty_width=uncertainty,
        order=order,
        receipt=receipt,
    )


def contract() -> dict[str,Any]:
    return {
        "PATCH_ID":PATCH_ID,
        "SCOPE":"ALL_SUPPORTED_SPORTS_AND_MODES_WITH_EXACT_ROLE_COMMON_WORLD_SCORE_TAPES",
        "MEMBERSHIP_MUTATION_ALLOWED":False,
        "POSTLOCK_INPUT_ALLOWED":False,
        "FAMILY_CONTEXT_TERMINAL_AUTHORITY":False,
        "FAMILY_CONTEXT_ROLE":"DISCOVERY_PRIOR_AND_TIEBREAK_ONLY",
        "EXACT_ROLE_COMMON_WORLD_HEAD_AUTHORITY":True,
        "MIN_LIVE_COMMON_WORLDS":MIN_LIVE_COMMON_WORLDS,
        "TARGET_COMMON_WORLDS":TARGET_COMMON_WORLDS,
        "DEFAULT_HEAD_SIZE":DEFAULT_HEAD_SIZE,
        "UNSUPPORTED_ADAPTER_BEHAVIOR":"DETERMINISTIC_NO_OP_HEAD_AUTHORITY_OFF",
        "WINNER_REMOVED_HEAD_ROBUSTNESS_REQUIRED":True,
    }
