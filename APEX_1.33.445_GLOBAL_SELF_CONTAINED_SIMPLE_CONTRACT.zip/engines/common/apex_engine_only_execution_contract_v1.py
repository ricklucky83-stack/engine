from __future__ import annotations

import base64, hashlib, json, os
from pathlib import Path
from typing import Any, Mapping
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

PATCH_ID = "APEX_GLOBAL_ENGINE_ONLY_END_TO_END_HARD_FENCE_v4"
NOTION_RECEIPT_SCHEMA = "APEX_NOTION_LIVE_AUTHORITY_RECEIPT_v1"
RELEASE_SCHEMA = "APEX_PROTECTED_BOARD_RELEASE_v1"
CHAT_EXECUTION_AUTHORITY = False
AI_EXECUTION_AUTHORITY = False
CHAT_FALLBACK_ALLOWED = False
MANUAL_RERANK_ALLOWED = False
MANUAL_BOARD_ALLOWED = False
UNIMPLEMENTED_BEHAVIOR = "RUN_INVALID"
AI_ALLOWED_SCOPES = ("RESEARCH","PROPOSED_IMPROVEMENTS","EXPLAIN_VERIFIED_RESULTS")

# Live production is a single opaque engine transaction. External callers may
# trigger or report it, but may not choose a stage, entrypoint, checkpoint,
# sorter, selector, terminal surface, or alternate continuation path.
CANONICAL_LIVE_ENTRYPOINT = "engines/common/apex_global_production_board_runner_v1.py"
CHAT_STAGE_SELECTION_AUTHORITY = False
CHAT_STAGE_SUBSTITUTION_AUTHORITY = False
CHAT_TERMINAL_ORDER_AUTHORITY = False
CALLER_CHECKPOINT_SELECTION_AUTHORITY = False
CALLER_ENTRYPOINT_SELECTION_AUTHORITY = False
CALLER_TERMINAL_SURFACE_AUTHORITY = False
CHECKPOINT_RESUME_MODE = "ENGINE_OWNED_CANONICAL_REENTRY_ONLY"

FORBIDDEN_CALLER_ENV_KEYS = (
    "APEX_PHASE1_TRIALS","APEX_BASE_TRIALS","APEX_EXTRA_TRIALS","APEX_MC_TRIAL_CHUNK",
    "APEX_CHAT_ALLOW_LIVE_INTERVENTION","APEX_CHAT_ALLOW_LATENCY_RESTART",
    "APEX_CHAT_ALLOW_LIVE_PATCHING","APEX_CHAT_ALLOW_CHECKPOINT_MUTATION",
    "APEX_AI_ALLOW_LIVE_INTERVENTION","APEX_AI_SELECTOR_OVERRIDE","APEX_AI_BOARD_OVERRIDE",
    "APEX_MANUAL_LINEUP_PAYLOAD","APEX_MANUAL_RERANK_PAYLOAD",
    # Caller-selected execution topology is prohibited. These values may only be
    # created internally by the canonical production runner after this gate passes.
    "APEX_CALLER_ENTRYPOINT","APEX_CALLER_STAGE","APEX_START_STAGE","APEX_NEXT_STAGE",
    "APEX_RESUME_STAGE","APEX_STAGE_OVERRIDE","APEX_ENGINE_STAGE_OVERRIDE",
    "APEX_TERMINAL_SORTER_OVERRIDE","APEX_TERMINAL_SELECTOR_OVERRIDE",
    "APEX_ORDINAL_OVERRIDE","APEX_SELECTOR_OVERRIDE","APEX_SORTER_OVERRIDE",
    "APEX_CHECKPOINT_OVERRIDE","APEX_CHECKPOINT_IN","APEX_CONTROLLER_STATE_OVERRIDE",
    "APEX_MANUAL_TERMINAL_SURFACE","APEX_MANUAL_BOARD_FILE","APEX_MANUAL_BOARD_GLOB",
    "APEX_DIRECT_CONTROLLER_ENTRYPOINT","APEX_DIRECT_RUNTIME_ENTRYPOINT",
)

class EngineOnlyExecutionError(RuntimeError):
    pass

def _canon(obj: Mapping[str,Any]) -> bytes:
    return json.dumps(dict(obj),sort_keys=True,separators=(",",":"),default=str).encode()

def _sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def _receipt_hash(payload: Mapping[str,Any]) -> str:
    body={k:v for k,v in dict(payload).items() if k!='RECEIPT_SHA256'}
    return hashlib.sha256(_canon(body)).hexdigest()

def validate_live_notion_authority_receipt(receipt_path, *, expected_state_version:str, sport:str, mode:str) -> dict[str,Any]:
    if not receipt_path: raise EngineOnlyExecutionError('RUN_INVALID:LIVE_NOTION_AUTHORITY_RECEIPT_REQUIRED')
    p=Path(receipt_path).resolve()
    if not p.is_file(): raise EngineOnlyExecutionError(f'RUN_INVALID:LIVE_NOTION_AUTHORITY_RECEIPT_MISSING:{p}')
    obj=json.loads(p.read_text(encoding='utf-8'))
    required={'SCHEMA':NOTION_RECEIPT_SCHEMA,'STATUS':'PASS','SOURCE':'NOTION_CONNECTOR',
              'ACTIVE_STATE_VERSION':str(expected_state_version),'SPORT':str(sport).upper(),'MODE':str(mode).upper(),
              'ENGINE_ONLY_EXECUTION':True,'CHAT_EXECUTION_AUTHORITY':False,'AI_EXECUTION_AUTHORITY':False}
    for k,v in required.items():
        if obj.get(k)!=v: raise EngineOnlyExecutionError(f'RUN_INVALID:LIVE_NOTION_AUTHORITY_RECEIPT_FIELD:{k}')
    pages=obj.get('AUTHORITY_PAGE_IDS')
    if not isinstance(pages,list) or not pages: raise EngineOnlyExecutionError('RUN_INVALID:LIVE_NOTION_AUTHORITY_PAGE_IDS_MISSING')
    declared=str(obj.get('RECEIPT_SHA256') or '').lower()
    if declared != _receipt_hash(obj): raise EngineOnlyExecutionError('RUN_INVALID:LIVE_NOTION_AUTHORITY_RECEIPT_HASH_MISMATCH')
    return {'PATCH_ID':PATCH_ID,'STATUS':'PASS','NOTION_RECEIPT_PATH':str(p),'NOTION_RECEIPT_FILE_SHA256':_sha256_file(p),
            'NOTION_RECEIPT_SHA256':declared,'AUTHORITY_PAGE_IDS':list(pages),'ACTIVE_STATE_VERSION':str(expected_state_version),
            'SPORT':str(sport).upper(),'MODE':str(mode).upper(),'ENGINE_ONLY_EXECUTION':True,
            'CHAT_EXECUTION_AUTHORITY':False,'AI_EXECUTION_AUTHORITY':False}

def reject_caller_execution_controls(env: Mapping[str,str], *, board_file: str|None=None, board_glob: str|None=None) -> dict[str,Any]:
    bad=[k for k in FORBIDDEN_CALLER_ENV_KEYS if str(env.get(k,'')).strip()]
    if board_file: bad.append('CLI:--board-file')
    if board_glob: bad.append('CLI:--board-glob')
    if bad: raise EngineOnlyExecutionError('RUN_INVALID:CALLER_ENGINE_CONTROL_PROHIBITED:'+','.join(sorted(bad)))
    return {
        'PATCH_ID':PATCH_ID,'STATUS':'PASS','CHAT_EXECUTION_AUTHORITY':False,'AI_EXECUTION_AUTHORITY':False,
        'CHAT_FALLBACK_ALLOWED':False,'MANUAL_RERANK_ALLOWED':False,'MANUAL_BOARD_ALLOWED':False,
        'CHAT_STAGE_SELECTION_AUTHORITY':False,'CHAT_STAGE_SUBSTITUTION_AUTHORITY':False,
        'CHAT_TERMINAL_ORDER_AUTHORITY':False,'CALLER_CHECKPOINT_SELECTION_AUTHORITY':False,
        'CALLER_ENTRYPOINT_SELECTION_AUTHORITY':False,'CALLER_TERMINAL_SURFACE_AUTHORITY':False,
        'CANONICAL_LIVE_ENTRYPOINT':CANONICAL_LIVE_ENTRYPOINT,
        'CHECKPOINT_RESUME_MODE':CHECKPOINT_RESUME_MODE,
    }

def production_env() -> dict[str,str]:
    return {
      'APEX_ENGINE_ONLY_EXECUTION_CONTRACT':PATCH_ID,
      'APEX_CHAT_EXECUTION_AUTHORITY':'0','APEX_AI_EXECUTION_AUTHORITY':'0','APEX_AI_SELECTOR_AUTHORITY':'0',
      'APEX_AI_RERANK_AUTHORITY':'0','APEX_AI_PUBLISH_AUTHORITY':'0','APEX_AI_LIVE_INTERVENTION':'PROHIBITED',
      'APEX_CHAT_LIVE_INTERVENTION':'PROHIBITED','APEX_CHAT_LATENCY_BASED_RESTART':'PROHIBITED',
      'APEX_CHAT_LIVE_PATCHING':'PROHIBITED','APEX_CHAT_CHECKPOINT_MUTATION':'PROHIBITED',
      'APEX_MANUAL_RERANK':'PROHIBITED','APEX_MANUAL_BOARD':'PROHIBITED',
      'APEX_CHAT_STAGE_SELECTION_AUTHORITY':'0','APEX_CHAT_STAGE_SUBSTITUTION_AUTHORITY':'0',
      'APEX_CHAT_TERMINAL_ORDER_AUTHORITY':'0','APEX_CALLER_CHECKPOINT_SELECTION_AUTHORITY':'0',
      'APEX_CALLER_ENTRYPOINT_SELECTION_AUTHORITY':'0','APEX_CALLER_TERMINAL_SURFACE_AUTHORITY':'0',
      'APEX_CANONICAL_LIVE_ENTRYPOINT':CANONICAL_LIVE_ENTRYPOINT,
      'APEX_CHECKPOINT_RESUME_MODE':CHECKPOINT_RESUME_MODE,
      'APEX_LIVE_PIPELINE_CONTROL':'ENGINE_OWNS_END_TO_END',
      'APEX_UNIMPLEMENTED_BEHAVIOR':UNIMPLEMENTED_BEHAVIOR,'APEX_PROTECTED_RELEASE_REQUIRED':'1',
      'APEX_AI_ALLOWED_SCOPES':','.join(AI_ALLOWED_SCOPES),
    }

def mode_requirements(registry: Mapping[str,Any], sport:str, mode:str) -> dict[str,Any]:
    su=str(sport).upper(); mu=str(mode).upper()
    rec=None
    for e in registry.get('ENGINES',[]) if isinstance(registry,dict) else []:
        if str(e.get('SPORT','')).upper()==su and mu in [str(x).upper() for x in e.get('MODES',[])]:
            rec=e; break
    if rec is None: raise EngineOnlyExecutionError(f'RUN_INVALID:ENGINE_REGISTRY_ROUTE_MISSING:{su}:{mu}')
    min_mc=0
    for key in ('MIN_MC_WORLDS','REQUIRED_MC_WORLDS','BASE_MC_TRIALS','MC_WORLDS'):
        try:
            val=int(rec.get(key) or 0)
        except Exception: val=0
        if val>0: min_mc=max(min_mc,val)
    full_enum=bool(rec.get('FULL_ENUMERATION_REQUIRED',False) or rec.get('FULL_LEGAL_UNIVERSE_ENUMERATION_REQUIRED',False))
    lineage=bool(rec.get('CANDIDATE_LINEAGE_REQUIRED', registry.get('ENGINE_ONLY_LINEAGE_REQUIRED',True)))
    return {'SPORT':su,'MODE':mu,'MIN_MC_WORLDS':min_mc,'FULL_ENUMERATION_REQUIRED':full_enum,
            'CANDIDATE_LINEAGE_REQUIRED':lineage,'ENTRYPOINT':rec.get('CHUNK_STREAM_ENTRYPOINT') or rec.get('ENTRYPOINT')}

def validate_terminal_source(payload: Mapping[str,Any], *, requirements: Mapping[str,Any]|None=None) -> dict[str,Any]:
    p=dict(payload or {}); req=dict(requirements or {})
    if p.get('CHAT_EXECUTION_AUTHORITY') is not False: raise EngineOnlyExecutionError('RUN_INVALID:CHAT_EXECUTION_AUTHORITY_NOT_FALSE')
    if p.get('AI_EXECUTION_AUTHORITY',False) not in (False,None): raise EngineOnlyExecutionError('RUN_INVALID:AI_EXECUTION_AUTHORITY_NOT_FALSE')
    worlds=int(p.get('MC_WORLDS') or p.get('PHASE1_MC_WORLDS') or p.get('BASE_SIM_TRIALS') or 0)
    minimum=int(req.get('MIN_MC_WORLDS') or 0)
    if worlds<=0: raise EngineOnlyExecutionError('RUN_INVALID:ZERO_MC_WORLDS')
    if minimum and worlds<minimum: raise EngineOnlyExecutionError(f'RUN_INVALID:MC_WORLDS_BELOW_MODE_MINIMUM:{worlds}<{minimum}')
    field=int(p.get('FAKE_FIELD_LINEUPS') or p.get('PUBLIC_FIELD_SIMS') or p.get('FIELD_SIZE') or 0)
    if field<=0: raise EngineOnlyExecutionError('RUN_INVALID:ZERO_PUBLIC_FIELD')
    if bool(req.get('FULL_ENUMERATION_REQUIRED')) and p.get('FULL_ENUMERATION_COMPLETE') is not True:
        raise EngineOnlyExecutionError('RUN_INVALID:FULL_ENUMERATION_PROOF_MISSING')
    phase2=int(p.get('PHASE2_BUILT_LINEUPS') or 0); reviewed=int(p.get('SELECTOR_REVIEWED_LINEUPS') or 0)
    if phase2<=0 or reviewed!=phase2: raise EngineOnlyExecutionError(f'RUN_INVALID:BIRTH_SELECTOR_REVIEW_PARITY:{phase2}!={reviewed}')
    if bool(req.get('CANDIDATE_LINEAGE_REQUIRED')):
        ledgers=p.get('LINEAGE_LEDGER_PATHS')
        if not isinstance(ledgers,dict) or not ledgers: raise EngineOnlyExecutionError('RUN_INVALID:LINEAGE_LEDGER_PATHS_MISSING')
        for key in ('BIRTH','QUALIFICATION','SELECTOR'):
            lp=Path(str(ledgers.get(key) or '')).resolve()
            if not lp.is_file(): raise EngineOnlyExecutionError(f'RUN_INVALID:LINEAGE_LEDGER_FILE_MISSING:{key}')
    notion=str(p.get('NOTION_AUTHORITY_RECEIPT_SHA256') or '')
    if not notion: raise EngineOnlyExecutionError('RUN_INVALID:NOTION_AUTHORITY_RECEIPT_HASH_MISSING_AT_TERMINAL')
    return {'PATCH_ID':PATCH_ID,'STATUS':'PASS','SPORT':req.get('SPORT'),'MODE':req.get('MODE'),'MC_WORLDS':worlds,
            'MIN_MC_WORLDS':minimum,'PUBLIC_FIELD_SIMS':field,'PHASE2_BUILT_LINEUPS':phase2,
            'SELECTOR_REVIEWED_LINEUPS':reviewed,'FULL_ENUMERATION_REQUIRED':bool(req.get('FULL_ENUMERATION_REQUIRED')),
            'FULL_ENUMERATION_COMPLETE':p.get('FULL_ENUMERATION_COMPLETE'),
            'CHAT_EXECUTION_AUTHORITY':False,'AI_EXECUTION_AUTHORITY':False,'CHAT_FALLBACK_ALLOWED':False}

def _load_ed25519_public_key(path):
    key=serialization.load_pem_public_key(Path(path).read_bytes())
    if not isinstance(key,Ed25519PublicKey): raise EngineOnlyExecutionError('RUN_INVALID:PUBLISHER_PUBLIC_KEY_NOT_ED25519')
    return key

def validate_protected_release(receipt_path, *, board_path, run_id:str, engine_version:str, input_sha256:str, policy_sha256:str, public_key_path) -> dict[str,Any]:
    if not receipt_path or not public_key_path: raise EngineOnlyExecutionError('RUN_INVALID:PROTECTED_RELEASE_SIGNATURE_REQUIRED')
    rp=Path(receipt_path).resolve(); bp=Path(board_path).resolve(); kp=Path(public_key_path).resolve()
    if not rp.is_file() or not bp.is_file() or not kp.is_file(): raise EngineOnlyExecutionError('RUN_INVALID:PROTECTED_RELEASE_ARTIFACT_MISSING')
    obj=json.loads(rp.read_text(encoding='utf-8')); sig_b64=str(obj.pop('SIGNATURE_B64','') or '')
    required={'SCHEMA':RELEASE_SCHEMA,'STATUS':'AUTHORIZED','RUN_ID':str(run_id),'ENGINE_VERSION':str(engine_version),
              'BOARD_SHA256':_sha256_file(bp),'INPUT_SHA256':str(input_sha256),'POLICY_SHA256':str(policy_sha256)}
    for k,v in required.items():
        if obj.get(k)!=v: raise EngineOnlyExecutionError(f'RUN_INVALID:RELEASE_RECEIPT_FIELD:{k}')
    try: _load_ed25519_public_key(kp).verify(base64.b64decode(sig_b64,validate=True),_canon(obj))
    except (ValueError,InvalidSignature) as exc: raise EngineOnlyExecutionError('RUN_INVALID:PROTECTED_RELEASE_SIGNATURE_INVALID') from exc
    return {'STATUS':'PASS','SCHEMA':RELEASE_SCHEMA,'RELEASE_RECEIPT_SHA256':_sha256_file(rp),'BOARD_SHA256':required['BOARD_SHA256'],'RUN_ID':str(run_id)}
