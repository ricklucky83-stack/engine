from __future__ import annotations
"""MLB Showdown prospective contest-order training persistence.

This module has ZERO live selection or ordering authority. It reads the already
frozen prelock terminal candidate CSV, appends canonical prelock projection/role
and MC-authority channels, and writes a NEW immutable training snapshot.
Postlock truth is forbidden. Persistence failure is intended to be nonblocking
when called from the production runtime.
"""
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping
import csv, json, math, os, tempfile

import numpy as np
import pandas as pd

PATCH_ID = "MLB_SD_ORDER_PRELOCK_SURFACE_v2"
AUTHORITY_METHOD = "POOL_FPTS_PLUS_CONFIRMED_ROLE_ORDER_v1"
MC_AUTHORITY_METHOD = "TOP01_WIN_P99_LEXICOGRAPHIC_v1"
LIVE_ORDER_AUTHORITY = False
MEMBERSHIP_AUTHORITY = False
POSTLOCK_INPUT_ALLOWED = False

FORBIDDEN = frozenset({
    "CONTEST_RANK","ACTUAL_FPTS","REALIZED_FPTS","ACTUAL_SCORE","REALIZED_SCORE",
    "POSTLOCK_SCORE","ACTUAL_RANK","FINAL_CONTEST_RANK","WINNER","WINNER_FLAG",
    "WINNER_LABEL","IS_WINNER","PERFECT","PERFECT_FLAG","IS_PERFECT",
    "TOP_0_1_FLAG","TOP01_FLAG","IS_TOP01","IS_TOP_0_1","TOP_1_FLAG","IS_TOP1",
    "IS_TOP_1","REALIZED_OWNERSHIP","POSTLOCK_OWNERSHIP","EXACT_FIELD_RANK",
})
PROJ_ALIASES = ("FPTS","PROJ","PROJECTION","PROJECTED FPTS","PROJECTED_FPTS")


def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace("-","_").replace(" ","_")


def _f(x: Any, default=float("nan")) -> float:
    try:
        v=float(str(x).replace("%","").replace(",","").strip())
        return v if math.isfinite(v) else default
    except Exception:
        return default


def _sha(path: str|Path) -> str:
    h=sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1<<20), b""):
            h.update(b)
    return h.hexdigest()


def _atomic_json(path: Path, obj: Mapping[str,Any]) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=path.name+".",suffix=".tmp",dir=str(path.parent)); os.close(fd)
    p=Path(tmp)
    try:
        p.write_text(json.dumps(dict(obj),indent=2,sort_keys=True),encoding="utf-8")
        os.replace(p,path)
    finally:
        if p.exists(): p.unlink(missing_ok=True)


def _pool_map(pool: pd.DataFrame) -> tuple[dict[str,dict[str,Any]],str|None]:
    cols={_norm(c):c for c in pool.columns}
    name_col=cols.get("PLAYER") or cols.get("NAME")
    if not name_col: raise ValueError("ORDER_TRAINING_POOL_PLAYER_COLUMN_MISSING")
    proj_col=next((cols[_norm(a)] for a in PROJ_ALIASES if _norm(a) in cols),None)
    lineup_col=cols.get("LINEUP")
    confirmed_col=cols.get("APEX_CONFIRMED_STARTER")
    out={}
    for _,r in pool.iterrows():
        name=str(r.get(name_col,"")).strip()
        if not name: continue
        line=str(r.get(lineup_col,"")).strip().upper() if lineup_col else ""
        confirmed=bool(r.get(confirmed_col,False)) if confirmed_col else False
        if line=="SP":
            role=1.0 if (confirmed or confirmed_col is None) else 0.90
        else:
            try:
                order=int(float(line)); role=float(np.clip((10-order)/9.0,0.0,1.0))
            except Exception:
                role=0.0
        out[name.casefold()]={"projection":_f(r.get(proj_col)) if proj_col else float("nan"),"role":role,"lineup":line}
    return out, proj_col


def _rank_pct(v: np.ndarray) -> np.ndarray:
    s=pd.Series(v,dtype="float64")
    return s.rank(method="average",pct=True,ascending=True,na_option="keep").to_numpy(float)


def _mc_lex_pct(top01: np.ndarray, win: np.ndarray, p99: np.ndarray) -> np.ndarray:
    n=len(top01); ids=np.arange(n,dtype=np.int64)
    a=np.nan_to_num(top01,nan=-np.inf); b=np.nan_to_num(win,nan=-np.inf); c=np.nan_to_num(p99,nan=-np.inf)
    order=np.lexsort((ids,-c,-b,-a))
    pct=np.empty(n,dtype=float)
    if n==1: pct[order]=1.0
    else: pct[order]=1.0-np.arange(n,dtype=float)/(n-1)
    return pct


def persist_mlb_showdown_order_surface(*, terminal_csv: str|Path, terminal_receipt: Mapping[str,Any],
                                        pool: pd.DataFrame, execution_id: str, output_dir: str|Path,
                                        context: Mapping[str,Any]|None=None, chunk_size: int=10000) -> dict[str,Any]:
    src=Path(terminal_csv); out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    if not src.exists(): raise FileNotFoundError(src)
    header=pd.read_csv(src,nrows=0).columns.tolist(); norm_header={_norm(c) for c in header}
    leak=sorted(norm_header & FORBIDDEN)
    if leak: raise ValueError("ORDER_TRAINING_POSTLOCK_LEAK:"+",".join(leak))
    required={"LINEUP_ID","CPT","UTIL1","UTIL2","UTIL3","UTIL4","UTIL5","MC_TOP_0_1_RATE","MC_WIN_RATE","MC_P99"}
    miss=sorted(required-norm_header)
    if miss: raise ValueError("ORDER_TRAINING_REQUIRED_COLUMNS_MISSING:"+",".join(miss))
    pmap,proj_col=_pool_map(pool)
    lids=[]; proj=[]; role=[]; top01=[]; win=[]; p99=[]
    roster_cols=["CPT","UTIL1","UTIL2","UTIL3","UTIL4","UTIL5"]
    use=[c for c in ["LINEUP_ID",*roster_cols,"MC_TOP_0_1_RATE","MC_WIN_RATE","MC_P99"] if c in header]
    for ch in pd.read_csv(src,usecols=use,chunksize=chunk_size,low_memory=False):
        for _,r in ch.iterrows():
            lid=str(r["LINEUP_ID"]).strip(); lids.append(lid)
            names=[str(r[x]).strip() for x in roster_cols]
            vals=[pmap.get(n.casefold(),{}) for n in names]
            pv=[_f(x.get("projection")) for x in vals]
            weights=[1.5,1,1,1,1,1]
            proj.append(float(sum(w*x for w,x in zip(weights,pv))) if all(math.isfinite(x) for x in pv) else float("nan"))
            rv=[_f(x.get("role"),0.0) for x in vals]
            role.append(float(sum(w*x for w,x in zip(weights,rv))/sum(weights)))
            top01.append(_f(r.get("MC_TOP_0_1_RATE"))); win.append(_f(r.get("MC_WIN_RATE"))); p99.append(_f(r.get("MC_P99")))
    if not lids: raise ValueError("ORDER_TRAINING_EMPTY_TERMINAL_SURFACE")
    if len(lids)!=len(set(lids)): raise ValueError("ORDER_TRAINING_DUPLICATE_LINEUP_ID")
    proj=np.asarray(proj,float); role=np.asarray(role,float); top01=np.asarray(top01,float); win=np.asarray(win,float); p99=np.asarray(p99,float)
    proj_pct=_rank_pct(proj); role_pct=_rank_pct(role)
    # Equal-axis diagnostic composite only; raw components are preserved so future
    # learned models are not forced to inherit this blend.
    pr=np.nanmean(np.vstack([proj_pct,role_pct]),axis=0)
    mc_pct=_mc_lex_pct(top01,win,p99)
    extra={lid:(proj[i],role[i],proj_pct[i],role_pct[i],pr[i],mc_pct[i]) for i,lid in enumerate(lids)}
    path=out/f"DK_MLB_SD_{execution_id}_ORDER_TRAINING_PRELOCK.csv"
    manifest_path=out/f"DK_MLB_SD_{execution_id}_ORDER_TRAINING_PRELOCK_MANIFEST.json"
    error_path=out/f"DK_MLB_SD_{execution_id}_ORDER_TRAINING_PRELOCK_ERROR.json"
    if path.exists() or manifest_path.exists(): raise FileExistsError(f"ORDER_TRAINING_IMMUTABLE_SURFACE_EXISTS:{execution_id}")
    append_fields=["PROJECTION_TOTAL_PRELOCK","ROLE_MEAN_PRELOCK","PROJECTION_PCTL","ROLE_PCTL","PROJECTION_ROLE_PCTL","MC_AUTHORITY_PCTL","AUTHORITY_CHANNEL_CLASS"]
    fields=[*header,*[x for x in append_fields if x not in header]]
    fd,tmp=tempfile.mkstemp(prefix=path.name+".",suffix=".tmp",dir=str(out)); os.close(fd); tp=Path(tmp)
    row_count=0
    try:
        with src.open("r",encoding="utf-8-sig",newline="") as fi, tp.open("w",encoding="utf-8",newline="") as fo:
            rd=csv.DictReader(fi); wr=csv.DictWriter(fo,fieldnames=fields,extrasaction="ignore"); wr.writeheader()
            for r in rd:
                lid=str(r.get("LINEUP_ID","")).strip(); x=extra[lid]
                r.update({
                    "PROJECTION_TOTAL_PRELOCK":x[0],"ROLE_MEAN_PRELOCK":x[1],"PROJECTION_PCTL":x[2],"ROLE_PCTL":x[3],
                    "PROJECTION_ROLE_PCTL":x[4],"MC_AUTHORITY_PCTL":x[5],"AUTHORITY_CHANNEL_CLASS":"PRELOCK_CALIBRATION_ONLY",
                })
                wr.writerow(r); row_count+=1
            fo.flush(); os.fsync(fo.fileno())
        os.replace(tp,path)
    finally:
        if tp.exists(): tp.unlink(missing_ok=True)
    src_sha=_sha(src); expected_sha=str(terminal_receipt.get("CANDIDATE_SURFACE_SHA256") or "")
    source_hash_match=(not expected_sha) or expected_sha==src_sha
    projection_complete=bool(np.isfinite(proj).all())
    replay_ready=bool(source_hash_match and projection_complete and row_count==len(lids))
    manifest={
        "PATCH_ID":PATCH_ID,"STATUS":"PASS" if replay_ready else "PASS_PARTIAL","SPORT":"MLB","MODE":"SHOWDOWN",
        "EXECUTION_ID":str(execution_id),"ARTIFACT_ROLE":"IMMUTABLE_PRELOCK_CONTEST_ORDER_TRAINING_SURFACE",
        "SOURCE_TERMINAL_CSV":str(src),"SOURCE_TERMINAL_CSV_SHA256":src_sha,
        "SOURCE_TERMINAL_FREEZE_SHA256":str(terminal_receipt.get("CANDIDATE_FREEZE_SHA256") or ""),
        "SOURCE_TERMINAL_RECEIPT_SHA256":str(terminal_receipt.get("RECEIPT_SHA256") or ""),
        "SOURCE_TERMINAL_HASH_MATCH":source_hash_match,"SURFACE_CSV":str(path),"SURFACE_CSV_SHA256":_sha(path),
        "ROW_COUNT":row_count,"SOURCE_ROW_COUNT":len(lids),"ROW_PARITY":row_count==len(lids),"COLUMN_COUNT":len(fields),"COLUMNS":fields,
        "PROJECTION_SOURCE_COLUMN":proj_col,"PROJECTION_COMPLETE":projection_complete,"AUTHORITY_METHOD":AUTHORITY_METHOD,
        "MC_AUTHORITY_METHOD":MC_AUTHORITY_METHOD,"AUTHORITY_REPLAY_READY":replay_ready,
        "CANDIDATE_PRUNING":0,"MEMBERSHIP_MUTATED":False,"SELECTOR_ORDER_MUTATED":False,"LIVE_ORDER_AUTHORITY":False,
        "PRODUCTION_SELECTION_AUTHORITY":False,"POSTLOCK_FIELDS_PRESENT":False,"PERSISTENCE_FAILURE_BLOCKS_LIVE_BOARD":False,
        "CONTEXT":dict(context or {}),"ERROR_RECEIPT_RESERVED":str(error_path),
    }
    _atomic_json(manifest_path,manifest); manifest["MANIFEST_PATH"]=str(manifest_path); manifest["MANIFEST_SHA256"]=_sha(manifest_path)
    return manifest


def write_nonblocking_failure(*, execution_id: str, output_dir: str|Path, error: BaseException, context: Mapping[str,Any]|None=None) -> dict[str,Any]:
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True); p=out/f"DK_MLB_SD_{execution_id}_ORDER_TRAINING_PRELOCK_ERROR.json"
    r={"PATCH_ID":PATCH_ID,"STATUS":"FAILED_NONBLOCKING","AUTHORITY_REPLAY_READY":False,"PERSISTENCE_FAILURE_BLOCKS_LIVE_BOARD":False,
       "ERROR_TYPE":type(error).__name__,"ERROR":str(error),"CONTEXT":dict(context or {})}
    _atomic_json(p,r); r["ERROR_RECEIPT_PATH"]=str(p); return r
