from __future__ import annotations
import hashlib, json, os
from pathlib import Path
from typing import Iterator, Sequence, TypeVar

PATCH_ID = 'MLB_PHASE2_STRICT_BLOCK_RESUMPTION_v1'
BLOCK_ROWS = 4096
SINGLE_PASS_ALLOWED = False
T = TypeVar('T')


def stable_pool_hash(path: str | os.PathLike) -> str:
    p = Path(path)
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def block_ranges(total: int, block_rows: int = BLOCK_ROWS) -> Iterator[tuple[int,int,int]]:
    block_rows = int(block_rows)
    if block_rows != BLOCK_ROWS:
        raise RuntimeError(f'RUN_INVALID:MLB_PHASE2_BLOCK_ROWS_MUST_EQUAL_{BLOCK_ROWS}')
    total = int(total)
    for block_idx, start in enumerate(range(0, total, block_rows)):
        yield block_idx, start, min(total, start + block_rows)


class MLBPhase2Checkpoint:
    def __init__(self, root: str | os.PathLike, execution_id: str, pool_hash: str, stage: str):
        self.dir = Path(root) / 'mlb_checkpoints' / str(execution_id) / str(stage)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.meta = self.dir / 'mlb_execution_state.json'
        self.pool_hash = str(pool_hash)
        self.stage = str(stage)

    def read(self) -> dict:
        if not self.meta.exists():
            return {'completed_block_index': -1, 'completed_parent_index': -1, 'total_lineups_built': 0, 'pool_verification_hash': self.pool_hash, 'gate_token': 'PENDING'}
        state = json.loads(self.meta.read_text(encoding='utf-8'))
        if state.get('pool_verification_hash') != self.pool_hash:
            raise RuntimeError('RUN_INVALID:MLB_PHASE2_STALE_CHECKPOINT_POOL_HASH_MISMATCH')
        return state

    def commit(self, block_idx: int, completed_parent_idx: int, lineup_count: int) -> None:
        state = {
            'patch_id': PATCH_ID,
            'stage': self.stage,
            'block_rows': BLOCK_ROWS,
            'single_pass_allowed': False,
            'completed_block_index': int(block_idx),
            'completed_parent_index': int(completed_parent_idx),
            'total_lineups_built': int(lineup_count),
            'pool_verification_hash': self.pool_hash,
            'gate_token': 'BLOCK_COMMITTED',
        }
        tmp = self.meta.with_suffix('.json.tmp')
        tmp.write_text(json.dumps(state, indent=2, sort_keys=True) + '\n', encoding='utf-8')
        os.replace(tmp, self.meta)
