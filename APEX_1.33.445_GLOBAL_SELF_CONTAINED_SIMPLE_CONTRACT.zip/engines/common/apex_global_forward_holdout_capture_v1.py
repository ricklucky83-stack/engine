from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

PATCH_ID = "APEX_GLOBAL_FORWARD_HOLDOUT_AUTO_CAPTURE_v1"
SCHEMA_VERSION = "APEX_FORWARD_HOLDOUT_CAPSULE_v1"
OUTCOME_ATTACHMENT_SCHEMA = "APEX_FORWARD_HOLDOUT_OUTCOME_ATTACHMENT_v1"

_POSTLOCK_PREFIXES = ("ACTUAL_", "REALIZED_", "POSTLOCK_", "RESULT_")
_POSTLOCK_EXACT = {"CONTEST_RANK", "CONTEST_FINISH", "FINISH_RANK", "ACTUAL_POINTS", "REALIZED_POINTS"}

class ForwardHoldoutCaptureError(RuntimeError):
    pass


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _canonical_json_bytes(obj: object) -> bytes:
    return (json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _lineup_id(row: dict, ordinal: int) -> str:
    for key in ("LINEUP_ID", "lineup_id", "LINEUP_INDEX", "lineup_index", "global_id", "GLOBAL_ID"):
        value = row.get(key)
        if value not in (None, ""):
            return str(value)
    stable = {str(k): row[k] for k in sorted(row)}
    return "anon_" + hashlib.sha256(_canonical_json_bytes(stable)).hexdigest()[:24]


def _postlock_columns(fieldnames: Iterable[str]) -> list[str]:
    bad = []
    for raw in fieldnames:
        name = str(raw).strip().upper()
        if name in _POSTLOCK_EXACT or any(name.startswith(p) for p in _POSTLOCK_PREFIXES):
            bad.append(str(raw))
    return sorted(set(bad))


def _copy_or_write_surface(*, source_csv: Path | None, source_rows: list[dict] | None, target: Path) -> tuple[int, list[str]]:
    if source_csv is not None:
        source_csv = Path(source_csv)
        if not source_csv.exists():
            raise ForwardHoldoutCaptureError(f"SOURCE_SELECTOR_SURFACE_MISSING:{source_csv}")
        with source_csv.open("r", encoding="utf-8-sig", newline="") as f:
            r = csv.DictReader(f)
            fields = list(r.fieldnames or [])
            bad = _postlock_columns(fields)
            if bad:
                raise ForwardHoldoutCaptureError("POSTLOCK_FIELDS_IN_PRELOCK_SURFACE:" + ",".join(bad))
            rows = sum(1 for _ in r)
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_name(target.name + f".tmp.{os.getpid()}")
        shutil.copyfile(source_csv, tmp)
        os.replace(tmp, target)
        return rows, fields
    rows_in = list(source_rows or [])
    if not rows_in:
        raise ForwardHoldoutCaptureError("SOURCE_SELECTOR_SURFACE_EMPTY")
    fields, seen = [], set()
    for row in rows_in:
        for k in row:
            if k not in seen:
                fields.append(str(k)); seen.add(k)
    bad = _postlock_columns(fields)
    if bad:
        raise ForwardHoldoutCaptureError("POSTLOCK_FIELDS_IN_PRELOCK_SURFACE:" + ",".join(bad))
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + f".tmp.{os.getpid()}")
    with tmp.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader(); w.writerows(rows_in)
    os.replace(tmp, target)
    return len(rows_in), fields


def freeze_prelock_holdout(*, sport: str, mode: str, execution_id: str, output_dir: Path,
                           final_rows: list[dict], selector_surface_csv: Path | None = None,
                           selector_surface_rows: list[dict] | None = None,
                           selector_freeze_sha256: str | None = None,
                           terminal_ledger_path: Path | None = None,
                           state_version: str | None = None,
                           player_pool_sha256: str | None = None) -> dict:
    """Freeze a forward-only holdout capsule before any resolved outcome is attached.

    This function has zero selector authority. It copies the complete frozen selector
    surface, seals the final Core-5, records hashes/timestamps, and explicitly forbids
    outcome fields in the prelock surface.
    """
    if not final_rows:
        raise ForwardHoldoutCaptureError("FINAL_BOARD_EMPTY")
    stem = f"APEX_{str(sport).upper()}_{str(mode).upper()}_{execution_id}_FORWARD_HOLDOUT"
    root = Path(output_dir) / f"{stem}_CAPSULE"
    root.mkdir(parents=True, exist_ok=True)
    surface_path = root / "selector_surface.csv"
    board_path = root / "winner_circle_board.json"
    manifest_path = root / "prelock_manifest.json"

    row_count, fields = _copy_or_write_surface(source_csv=selector_surface_csv, source_rows=selector_surface_rows, target=surface_path)
    surface_sha = _sha256_file(surface_path)
    if selector_surface_csv is not None and selector_freeze_sha256:
        # Freeze hash may be a semantic candidate hash rather than raw file SHA; preserve both.
        declared_freeze = str(selector_freeze_sha256)
    else:
        declared_freeze = str(selector_freeze_sha256 or surface_sha)

    board_obj = {
        "SCHEMA_VERSION": SCHEMA_VERSION,
        "SPORT": str(sport).upper(), "MODE": str(mode).upper(), "EXECUTION_ID": str(execution_id),
        "FINAL_BOARD_SIZE": len(final_rows), "FINAL_BOARD": final_rows,
    }
    _atomic_write(board_path, _canonical_json_bytes(board_obj))
    board_sha = _sha256_file(board_path)

    ledger_sha = None
    ledger_copy = None
    if terminal_ledger_path is not None:
        terminal_ledger_path = Path(terminal_ledger_path)
        if not terminal_ledger_path.exists():
            raise ForwardHoldoutCaptureError(f"TERMINAL_LEDGER_MISSING:{terminal_ledger_path}")
        ledger_copy = root / "terminal_selector_ledger.csv"
        tmp = ledger_copy.with_name(ledger_copy.name + f".tmp.{os.getpid()}")
        shutil.copyfile(terminal_ledger_path, tmp); os.replace(tmp, ledger_copy)
        ledger_sha = _sha256_file(ledger_copy)

    board_ids = [_lineup_id(dict(r), i) for i, r in enumerate(final_rows)]
    manifest = {
        "SCHEMA_VERSION": SCHEMA_VERSION,
        "PATCH_ID": PATCH_ID,
        "STATUS": "PRELOCK_FROZEN_OUTCOME_PENDING",
        "CAPTURED_AT_UTC": _utc_now(),
        "SPORT": str(sport).upper(), "MODE": str(mode).upper(), "EXECUTION_ID": str(execution_id),
        "GLOBAL_STATE_VERSION": str(state_version or "UNSPECIFIED"),
        "PLAYER_POOL_SHA256": str(player_pool_sha256 or ""),
        "SELECTOR_SURFACE_PATH": str(surface_path),
        "SELECTOR_SURFACE_ROWS": int(row_count),
        "SELECTOR_SURFACE_COLUMNS": fields,
        "SELECTOR_SURFACE_SHA256": surface_sha,
        "SELECTOR_FREEZE_SHA256": declared_freeze,
        "FINAL_BOARD_PATH": str(board_path),
        "FINAL_BOARD_SHA256": board_sha,
        "FINAL_BOARD_SIZE": len(final_rows),
        "FINAL_BOARD_LINEUP_IDS": board_ids,
        "TERMINAL_SELECTOR_LEDGER_PATH": str(ledger_copy) if ledger_copy else None,
        "TERMINAL_SELECTOR_LEDGER_SHA256": ledger_sha,
        "OUTCOME_ATTACHED": False,
        "OUTCOME_ARTIFACT": None,
        "POSTLOCK_FIELDS_IN_SELECTOR_SURFACE": [],
        "HISTORICAL_OUTCOME_FORWARD_INPUT_ALLOWED": False,
        "LIVE_SELECTOR_AUTHORITY_CHANGED": False,
        "GENERATOR_AUTHORITY_CHANGED": False,
        "SIMULATION_AUTHORITY_CHANGED": False,
        "CLEAN_HOLDOUT_ELIGIBILITY": "PENDING_RESOLVED_OUTCOME_ATTACHMENT",
    }
    _atomic_write(manifest_path, _canonical_json_bytes(manifest))
    manifest_sha = _sha256_file(manifest_path)
    return {
        "PATCH_ID": PATCH_ID,
        "STATUS": "PASS",
        "CAPSULE_DIR": str(root),
        "PRELOCK_MANIFEST_PATH": str(manifest_path),
        "PRELOCK_MANIFEST_SHA256": manifest_sha,
        "SELECTOR_SURFACE_PATH": str(surface_path),
        "SELECTOR_SURFACE_ROWS": int(row_count),
        "SELECTOR_SURFACE_SHA256": surface_sha,
        "FINAL_BOARD_PATH": str(board_path),
        "FINAL_BOARD_SHA256": board_sha,
        "OUTCOME_ATTACHED": False,
        "CLEAN_HOLDOUT_ELIGIBILITY": "PENDING_RESOLVED_OUTCOME_ATTACHMENT",
    }


def attach_resolved_outcome(*, prelock_manifest: Path, outcome_file: Path,
                            observed_at_utc: str | None = None) -> dict:
    """Attach a resolved outcome without mutating the immutable prelock manifest."""
    prelock_manifest = Path(prelock_manifest); outcome_file = Path(outcome_file)
    if not prelock_manifest.exists():
        raise ForwardHoldoutCaptureError(f"PRELOCK_MANIFEST_MISSING:{prelock_manifest}")
    if not outcome_file.exists():
        raise ForwardHoldoutCaptureError(f"OUTCOME_FILE_MISSING:{outcome_file}")
    manifest = json.loads(prelock_manifest.read_text(encoding="utf-8"))
    captured = datetime.fromisoformat(str(manifest["CAPTURED_AT_UTC"]).replace("Z", "+00:00"))
    observed = datetime.fromisoformat(observed_at_utc.replace("Z", "+00:00")) if observed_at_utc else datetime.now(timezone.utc)
    if observed <= captured:
        raise ForwardHoldoutCaptureError("OUTCOME_TIMESTAMP_NOT_AFTER_PRELOCK_FREEZE")
    root = prelock_manifest.parent
    outcome_copy = root / ("resolved_outcome" + outcome_file.suffix.lower())
    tmp = outcome_copy.with_name(outcome_copy.name + f".tmp.{os.getpid()}")
    shutil.copyfile(outcome_file, tmp); os.replace(tmp, outcome_copy)
    attachment = {
        "SCHEMA_VERSION": OUTCOME_ATTACHMENT_SCHEMA,
        "PATCH_ID": PATCH_ID,
        "STATUS": "RESOLVED_OUTCOME_ATTACHED_POSTLOCK",
        "PRELOCK_MANIFEST_SHA256": _sha256_file(prelock_manifest),
        "PRELOCK_CAPTURED_AT_UTC": manifest["CAPTURED_AT_UTC"],
        "OUTCOME_OBSERVED_AT_UTC": observed.isoformat(),
        "OUTCOME_PATH": str(outcome_copy),
        "OUTCOME_SHA256": _sha256_file(outcome_copy),
        "SPORT": manifest["SPORT"], "MODE": manifest["MODE"], "EXECUTION_ID": manifest["EXECUTION_ID"],
        "FORWARD_SELECTOR_IMPORT_PROHIBITED": True,
        "CLEAN_HOLDOUT_ELIGIBILITY": "ELIGIBLE_FOR_POSTLOCK_MATCH_AND_SCORING",
    }
    out = root / "postlock_outcome_attachment.json"
    _atomic_write(out, _canonical_json_bytes(attachment))
    attachment["ATTACHMENT_PATH"] = str(out)
    attachment["ATTACHMENT_SHA256"] = _sha256_file(out)
    return attachment
