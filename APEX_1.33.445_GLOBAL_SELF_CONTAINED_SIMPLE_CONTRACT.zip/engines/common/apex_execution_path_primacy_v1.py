from __future__ import annotations
from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping
import numpy as np

PATCH_ID='APEX_GLOBAL_EXECUTION_PATH_PRIMACY_EFFICIENCY_STANDARD_v1'
MANDATORY_OPTIMIZATION_DECK={
 'ROW_WISE_LEGALITY_CHECKS':'BAN','MID_RUN_RAW_IO_READS':'PROHIBIT','ONE_PASS_FROZEN_DATA_FLOW':'ENFORCE',
 'VECTORIZED_NUMPY_KERNELS':True,'LATE_PRUNING':'REPLACE_WITH_STRUCTURAL_SHORTLIST_BEFORE_DIVERSIFICATION',
 'PANDAS_HEAVY_CORE_PATH':'PROHIBIT','WEAK_LINEUP_HEAVY_MC':'PROHIBIT'}

@dataclass(frozen=True)
class FrozenSlate:
    arrays: Mapping[str,np.ndarray]
    row_count: int

def freeze_static_slate_artifacts(**arrays) -> FrozenSlate:
    frozen={}
    n=None
    for name,value in arrays.items():
        a=np.ascontiguousarray(np.asarray(value))
        if n is None:n=len(a)
        elif len(a)!=n: raise ValueError(f'FROZEN_SLATE_LENGTH_MISMATCH:{name}:{len(a)}:{n}')
        a.setflags(write=False); frozen[name]=a
    return FrozenSlate(MappingProxyType(frozen),int(n or 0))

def vectorized_legality_mask(lineup_ids:np.ndarray,salary:np.ndarray,eligible:np.ndarray,*,salary_min:int,salary_max:int,roster_size:int)->np.ndarray:
    ids=np.asarray(lineup_ids,dtype=np.int32)
    if ids.ndim!=2 or ids.shape[1]!=roster_size: raise ValueError('LINEUP_MATRIX_SHAPE_MISMATCH')
    sal=np.asarray(salary)[ids].sum(axis=1)
    uniq=np.apply_along_axis(lambda r: len(np.unique(r))==roster_size,1,ids)
    elig=np.asarray(eligible,dtype=bool)[ids].all(axis=1)
    return (sal>=salary_min)&(sal<=salary_max)&uniq&elig

def early_structural_prune(*,core_completion_count,minimum_core_completions:int,ceiling_score=None,minimum_ceiling=None,structural_variance=None,minimum_structural_variance=None)->np.ndarray:
    c=np.asarray(core_completion_count)
    mask=c>=int(minimum_core_completions)
    if ceiling_score is not None and minimum_ceiling is not None: mask &= np.asarray(ceiling_score)>=float(minimum_ceiling)
    if structural_variance is not None and minimum_structural_variance is not None: mask &= np.asarray(structural_variance)>=float(minimum_structural_variance)
    return np.flatnonzero(mask).astype(np.int32,copy=False)

def shortlist_before_diversification(primary_score,eligible_indices,*,max_rows:int|None=None)->np.ndarray:
    idx=np.asarray(eligible_indices,dtype=np.int32); score=np.asarray(primary_score,dtype=np.float64)
    if not len(idx): return idx
    if max_rows is None or len(idx)<=max_rows: return idx[np.argsort(-score[idx],kind='stable')]
    k=int(max_rows); part=np.argpartition(score[idx],len(idx)-k)[-k:]
    chosen=idx[part]; return chosen[np.argsort(-score[chosen],kind='stable')]

def percentile_rank_numpy(values)->np.ndarray:
    x=np.asarray(values,dtype=np.float64); n=x.size
    if n==0:return x.copy()
    x=np.nan_to_num(x,nan=-np.inf,posinf=np.inf,neginf=-np.inf)
    order=np.argsort(x,kind='stable'); sorted_x=x[order]
    starts=np.r_[0,np.flatnonzero(sorted_x[1:]!=sorted_x[:-1])+1]
    ends=np.r_[starts[1:],n]
    avg=((starts+ends-1)/2.0+0.5)/n
    ranks=np.repeat(avg,ends-starts)
    out=np.empty(n,dtype=np.float64); out[order]=ranks
    return out
