from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping, Protocol

PATCH_ID = "APEX_GLOBAL_CROSS_CHAT_STABLE_POINTER_CAS_v1"
ACTIVE_TITLE = "APEX_GLOBAL_STATE_LATEST.txt"
CAPABILITY = "STABLE_POINTER_IN_PLACE_CAS_V1"


class StablePointerCASError(RuntimeError):
    pass


class PointerRegistry(Protocol):
    def discover_exact_active_pointer(self) -> dict: ...
    def compare_and_swap_pointer_in_place(self, **kwargs: Any) -> dict: ...


def canonical_pointer_bytes(pointer: Mapping[str, Any]) -> bytes:
    return (json.dumps(dict(pointer), indent=2, sort_keys=True) + "\n").encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def next_pointer_epoch(pointer: Mapping[str, Any]) -> int:
    return int(pointer.get("POINTER_EPOCH", 0) or 0) + 1


def require_unique_active(found: Mapping[str, Any]) -> None:
    if found.get("EXACT_TITLE_COUNT") not in (None, 1):
        raise StablePointerCASError("ACTIVE_POINTER_EXACT_TITLE_NOT_UNIQUE")
    if str(found.get("TITLE") or ACTIVE_TITLE) != ACTIVE_TITLE:
        raise StablePointerCASError("ACTIVE_POINTER_TITLE_MISMATCH")


def _file_id(found: Mapping[str, Any]) -> str:
    return str(found.get("FILE_ID") or found.get("ACTIVE_POINTER_FILE_ID") or "")


def _bytes_sha(found: Mapping[str, Any]) -> str:
    return str(found.get("POINTER_BYTES_SHA256") or found.get("BYTES_SHA256") or "")


def stable_pointer_cas(
    registry: PointerRegistry,
    *,
    before: Mapping[str, Any],
    pointer_payload: Mapping[str, Any],
    expected_pointer_sha256: str | None = None,
) -> dict:
    """Update the one active pointer object in place, guarded by parent identity + bytes.

    The registry implementation MUST make compare_and_swap_pointer_in_place atomic
    with respect to expected file ID, pointer epoch, and full parent bytes SHA-256.
    This module never deletes, retires, renames, or replaces the active pointer object.
    """
    pre = registry.discover_exact_active_pointer()
    require_unique_active(pre)

    active_id = _file_id(pre)
    pinned_id = str(before.get("FILE_ID") or before.get("ACTIVE_POINTER_FILE_ID") or "")
    if not pinned_id:
        raise StablePointerCASError("ACTIVE_POINTER_FILE_ID_REQUIRED")
    if active_id != pinned_id:
        raise StablePointerCASError(f"STALE_POINTER_OBJECT:{pinned_id}:{active_id}")

    observed_sha = _bytes_sha(pre)
    pinned_sha = str(expected_pointer_sha256 or before.get("POINTER_BYTES_SHA256") or "")
    if not pinned_sha:
        raise StablePointerCASError("PARENT_POINTER_BYTES_SHA256_REQUIRED")
    if observed_sha and observed_sha != pinned_sha:
        raise StablePointerCASError(f"STALE_POINTER_BYTES:{pinned_sha}:{observed_sha}")

    old_epoch = int(before.get("POINTER_EPOCH", 0) or 0)
    new_epoch = old_epoch + 1
    final_payload = dict(pointer_payload)
    final_payload.update(
        {
            "ACTIVE_POINTER_FILE": ACTIVE_TITLE,
            "ACTIVE_POINTER_FILE_ID": pinned_id,
            "ACTIVE_POINTER_RESOLUTION": "UNIQUE_EXACT_TITLE_STABLE_ID_CAS",
            "POINTER_EPOCH": new_epoch,
            "POINTER_OBJECT_FENCE": "SUPERSEDED_BY_STABLE_POINTER_IN_PLACE_CAS_v1",
            "PARENT_POINTER_BYTES_SHA256": pinned_sha,
        }
    )
    caps = set(map(str, final_payload.get("POINTER_CAPABILITIES") or ()))
    caps.add(CAPABILITY)
    # Keep OBJECT_ID_FENCE_V1 temporarily for compatibility with older immutable bootstrap readers.
    caps.add("OBJECT_ID_FENCE_V1")
    final_payload["POINTER_CAPABILITIES"] = sorted(caps)
    final_bytes = canonical_pointer_bytes(final_payload)
    final_sha = sha256_bytes(final_bytes)

    write = registry.compare_and_swap_pointer_in_place(
        file_id=pinned_id,
        active_title=ACTIVE_TITLE,
        expected_pointer_sha256=pinned_sha,
        expected_pointer_epoch=old_epoch,
        pointer_payload=final_payload,
        pointer_bytes=final_bytes,
    )
    if write.get("CAS") not in ("PASS", True):
        raise StablePointerCASError("POINTER_COMPARE_AND_SWAP_FAILED")

    rb = registry.discover_exact_active_pointer()
    require_unique_active(rb)
    if _file_id(rb) != pinned_id:
        raise StablePointerCASError("ACTIVE_POINTER_FILE_ID_CHANGED")
    if int(rb.get("POINTER_EPOCH", new_epoch)) != new_epoch:
        raise StablePointerCASError("POINTER_EPOCH_READBACK_MISMATCH")
    rb_sha = _bytes_sha(rb)
    if rb_sha and rb_sha != final_sha:
        raise StablePointerCASError("POINTER_BYTES_READBACK_MISMATCH")

    return {
        "POINTER_STABLE_ID_CAS": "PASS",
        "POINTER_COMPARE_AND_SWAP": "PASS",
        "ACTIVE_POINTER_FILE_ID": pinned_id,
        "POINTER_EPOCH": new_epoch,
        "PARENT_POINTER_BYTES_SHA256": pinned_sha,
        "POINTER_BYTES_SHA256": final_sha,
        "READBACK": rb,
        "POINTER_PAYLOAD": final_payload,
    }
