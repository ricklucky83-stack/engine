#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, importlib, io, json, os, pickle, sys, time, types
from pathlib import Path
from typing import Any

PATCH_ID='MLB_SHOWDOWN_LIVESET_CHECKPOINT_AND_TERMINAL_MEMORY_SAFETY_v1'
INTERNAL_SUBCHUNK_CONTINUE_RC=76
SRC=Path(os.environ['APEX_INTERNAL_SPLIT_SOURCE']).resolve()
STAGE_NAME=str(os.environ.get('APEX_INTERNAL_SPLIT_STAGE_NAME','UNNAMED'))
START=int(os.environ['APEX_INTERNAL_SPLIT_START'])
END=int(os.environ['APEX_INTERNAL_SPLIT_END'])
CK_IN=str(os.environ.get('APEX_INTERNAL_SPLIT_CHECKPOINT_IN',''))
CK_OUT=str(os.environ.get('APEX_INTERNAL_SPLIT_CHECKPOINT_OUT',''))
FINAL=os.environ.get('APEX_INTERNAL_SPLIT_FINAL','0')=='1'
EXPECTED_SHA=str(os.environ.get('APEX_INTERNAL_SPLIT_SOURCE_SHA256','')).strip().lower()

if EXPECTED_SHA:
    actual=hashlib.sha256(SRC.read_bytes()).hexdigest()
    if actual!=EXPECTED_SHA:
        raise RuntimeError(f'RUN_INVALID:MLB_SD_CHUNK_SOURCE_SHA_MISMATCH:{actual}:{EXPECTED_SHA}')

STATE_ROOT=SRC.parents[2]
ENGINE_DIR=SRC.parent
for p in (STATE_ROOT,ENGINE_DIR,STATE_ROOT/'engines/common'):
    s=str(p)
    if s not in sys.path: sys.path.insert(0,s)

# Import the active runtime as code authority. Its __main__ delegate never fires here.
eng=importlib.import_module('engines.mlb.mlb_showdown_raw_pool_runtime_v1_7')
ns=eng.__dict__
BASELINE_KEYS=set(ns)
RUNTIME_MUTABLE_GLOBALS={
    '_LAST_FIELD_RECEIPT','_LAST_MC_ENV_RECEIPT','_LAST_STRATEGY_RECEIPT',
    '_LAST_ATTACKABLE_PA_RECEIPT','_LAST_TEAM_RUN_PATHS',
}
FROZEN_CONTEXT_TAG='__APEX_FROZEN_SLATE_CONTEXT_V1__'

def checkpoint_encode(value:Any)->Any:
    cls=ns.get('FrozenSlateContext')
    if cls is not None and isinstance(value,cls):
        return {FROZEN_CONTEXT_TAG:value.as_dict()}
    return value

def checkpoint_decode(value:Any)->Any:
    if isinstance(value,dict) and FROZEN_CONTEXT_TAG in value:
        cls=ns.get('FrozenSlateContext')
        if cls is None:
            raise RuntimeError('RUN_INVALID:MLB_SD_FROZEN_CONTEXT_CLASS_MISSING')
        return cls(value[FROZEN_CONTEXT_TAG])
    return value

def restore_frozen_context_contract()->None:
    """Recover old checkpoints that predate explicit FrozenSlateContext encoding.

    Reconstruction uses only already-frozen prelock checkpoint state: meta and
    the Phase-2 field receipt. No simulation, ranking, selector, or postlock
    inputs are recomputed here.
    """
    if 'meta' not in ns or '_LAST_FIELD_RECEIPT' not in ns:
        return
    rebuilt=[]
    if 'phase1_slate_context' not in ns:
        ctx=ns['build_phase1_context'](ns['meta'])
        prior=str(ns.get('phase1_context_seal') or '')
        if prior and prior!=ctx.sha256:
            raise RuntimeError(f'RUN_INVALID:MLB_SD_PHASE1_CONTEXT_RECOVERY_HASH_MISMATCH:{prior}:{ctx.sha256}')
        ns['phase1_slate_context']=ctx
        ns['phase1_context_seal']=ctx.sha256
        rebuilt.append('phase1_slate_context')
    _field_receipt=ns.get('_LAST_FIELD_RECEIPT') or {}
    _phase2_ready=all(k in _field_receipt for k in ('TARGET_DUAL_SP_SHARE','TARGET_SP_CPT_SHARE'))
    if 'frozen_slate_context' not in ns and _phase2_ready:
        ctx=ns['merge_phase2_context'](ns['phase1_slate_context'],_field_receipt)
        prior=str(ns.get('slate_context_seal') or '')
        if prior and prior!=ctx.sha256:
            raise RuntimeError(f'RUN_INVALID:MLB_SD_PHASE2_CONTEXT_RECOVERY_HASH_MISMATCH:{prior}:{ctx.sha256}')
        ns['frozen_slate_context']=ctx
        ns['slate_context_seal']=ctx.sha256
        rebuilt.append('frozen_slate_context')
    if rebuilt:
        print(json.dumps({'RUN_STATE':'CHECKPOINT_CONTEXT_RECOVERED','PATCH_ID':PATCH_ID,'FIELDS':rebuilt}),file=sys.stderr,flush=True)

def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()



def _future_live_names(run_node:ast.FunctionDef, completed_end:int)->set[str]:
    """Names read by any later run-body statement, including nested callbacks.

    This is a checkpoint storage filter only. It does not alter execution order or values.
    """
    live=set()
    for stmt in run_node.body:
        if int(getattr(stmt,'lineno',-1))<=int(completed_end):
            continue
        for node in ast.walk(stmt):
            if isinstance(node,ast.Name) and isinstance(node.ctx,ast.Load):
                live.add(node.id)
    return live

def _cgroup_memory()->dict[str,int|None]:
    def read_int(path):
        try:
            raw=Path(path).read_text().strip()
            return None if raw=='max' else int(raw)
        except Exception:
            return None
    return {'CURRENT':read_int('/sys/fs/cgroup/memory.current'),'MAX':read_int('/sys/fs/cgroup/memory.max')}

def atomic_pickle(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('wb') as f:
        pickle.dump(obj,f,protocol=5); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)

def load_checkpoint(path:Path)->dict[str,Any]:
    with path.open('rb') as f: return pickle.load(f)

def rebind_runtime_authority()->None:
    # Checkpoints contain data, never active runtime/file authority.
    ns['POOL_PATH']=Path(os.environ['APEX_PLAYER_POOL']).resolve()
    ns['OUT']=Path(os.environ.get('APEX_OUTPUT_DIR','/mnt/data')).resolve()
    ns['FIELD_SIZE']=int(os.environ['APEX_FIELD_SIZE'])
    ns['EXECUTION_ID']=str(os.environ.get('APEX_EXECUTION_ID',ns['FIELD_SIZE']))
    # APEX_MLB_SD_MAX_ENTRY_METADATA_ONLY_v1
    _max_entry_raw=os.environ.get('APEX_USER_ENTRIES') or os.environ.get('APEX_MAX_ENTRIES') or os.environ.get('APEX_BOARD_SIZE')
    try:
        ns['MAX_ENTRY_METADATA']=(int(_max_entry_raw) if _max_entry_raw is not None and str(_max_entry_raw).strip() else None)
    except Exception:
        ns['MAX_ENTRY_METADATA']=None
    ns['OUTPUT_LINEUP_QUOTA']=None
    if 'pool' in ns:
        try: ns['simulate_players']._environment=ns['environment_from_pool'](ns['pool'])
        except Exception: pass

if CK_IN:
    data=load_checkpoint(Path(CK_IN))
    for k,v in data.items():
        if k in {'POOL_PATH','OUT','FIELD_SIZE','EXECUTION_ID','BOARD_SIZE','MAX_ENTRY_METADATA','OUTPUT_LINEUP_QUOTA'}: continue
        ns[k]=checkpoint_decode(v)
    rebind_runtime_authority()
    restore_frozen_context_contract()
else:
    rebind_runtime_authority()

tree=ast.parse(SRC.read_text(encoding='utf-8'))
runs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run']
if len(runs)!=1: raise RuntimeError(f'RUN_INVALID:MLB_SD_RUN_FUNCTION_NOT_UNIQUE:{len(runs)}')
run_node=runs[0]
selected=[n for n in run_node.body if int(getattr(n,'lineno',-1))>=START and int(getattr(n,'end_lineno',getattr(n,'lineno',-1)))<=END]
if not selected:
    raise RuntimeError(f'RUN_INVALID:MLB_SD_CHUNK_STAGE_EMPTY:{STAGE_NAME}:{START}:{END}')
if int(selected[0].lineno)!=START:
    raise RuntimeError(f'RUN_INVALID:MLB_SD_CHUNK_STAGE_START_NOT_STATEMENT:{STAGE_NAME}:{START}:{selected[0].lineno}')
if int(selected[-1].end_lineno)!=END:
    raise RuntimeError(f'RUN_INVALID:MLB_SD_CHUNK_STAGE_END_NOT_STATEMENT:{STAGE_NAME}:{END}:{selected[-1].end_lineno}')
FUTURE_LIVE_NAMES=_future_live_names(run_node,END)
mod=ast.Module(body=selected,type_ignores=[]); ast.fix_missing_locations(mod)
t0=time.time()
try:
    exec(compile(mod,str(SRC),'exec'),ns,ns)
except RuntimeError as exc:
    msg=str(exc)
    if msg.startswith('CHECKPOINTED_CONTINUE:CROSS_WORLD_WINDOW:'):
        print(json.dumps({'RUN_STATE':'INTERNAL_SUBCHUNK_COMMITTED','PATCH_ID':PATCH_ID,'STAGE':STAGE_NAME,'DETAIL':msg,'SECONDS':round(time.time()-t0,3)}),file=sys.stderr,flush=True)
        raise SystemExit(INTERNAL_SUBCHUNK_CONTINUE_RC)
    raise
sec=time.time()-t0
print(json.dumps({'RUN_STATE':'INTERNAL_CHUNK_EXECUTED','PATCH_ID':PATCH_ID,'STAGE':STAGE_NAME,'START':START,'END':END,'SECONDS':round(sec,3)}),file=sys.stderr,flush=True)

if not FINAL:
    if not CK_OUT: raise RuntimeError('RUN_INVALID:MLB_SD_CHUNK_CHECKPOINT_OUT_MISSING')
    data={}
    persisted_keys=[]
    for k,v in ns.items():
        if k.startswith('__') or isinstance(v,types.ModuleType) or callable(v) or isinstance(v,io.IOBase): continue
        if k in BASELINE_KEYS and k not in RUNTIME_MUTABLE_GLOBALS: continue
        if k not in FUTURE_LIVE_NAMES and k not in RUNTIME_MUTABLE_GLOBALS: continue
        encoded=checkpoint_encode(v)
        try: pickle.dumps(encoded,protocol=5)
        except Exception: continue
        data[k]=encoded; persisted_keys.append(k)
    out=Path(CK_OUT); t1=time.time(); atomic_pickle(out,data)
    mem=_cgroup_memory()
    sidecar=Path(str(out)+'.receipt.json')
    sidecar.write_text(json.dumps({'PATCH_ID':PATCH_ID,'STAGE':STAGE_NAME,'LIVESET_ONLY':True,'PERSISTED_KEYS':sorted(persisted_keys),'PERSISTED_KEY_COUNT':len(persisted_keys),'FUTURE_LIVE_NAME_COUNT':len(FUTURE_LIVE_NAMES),'CHECKPOINT_BYTES':out.stat().st_size,'MEMORY_CURRENT':mem['CURRENT'],'MEMORY_MAX':mem['MAX']},indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps({'RUN_STATE':'INTERNAL_CHECKPOINT_COMMITTED','PATCH_ID':PATCH_ID,'STAGE':STAGE_NAME,'CHECKPOINT':str(out),'CHECKPOINT_SHA256':sha256_file(out),'BYTES':out.stat().st_size,'LIVESET_ONLY':True,'PERSISTED_KEY_COUNT':len(persisted_keys),'MEMORY_CURRENT':mem['CURRENT'],'MEMORY_MAX':mem['MAX'],'SECONDS':round(time.time()-t1,3)}),file=sys.stderr,flush=True)
