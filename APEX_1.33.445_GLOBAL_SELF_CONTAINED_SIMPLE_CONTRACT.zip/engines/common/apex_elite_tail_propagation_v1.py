from __future__ import annotations

"""Unbroken elite-tail propagation and lineage guard.

This module never creates lineups and never uses ownership/projection as an
elite-tail admission or eviction criterion. It converts existing simulation
metrics into uncertainty-aware evidence, stamps a deterministic handoff
passport, identifies the protected championship anchor, and validates that a
terminal decision did not discard a statistically superior elite-tail row.

Adaptive re-simulation is exposed as a callback contract so sport runtimes can
run additional trials on overlapping bubble candidates without duplicating
sport physics in this global module.
"""

from hashlib import sha256
from typing import Any, Callable, Mapping, Sequence
import json, math

PATCH_ID = "APEX_GLOBAL_ELITE_TAIL_PROPAGATION_CHAIN_v1"
MULTI_SEED_PATCH_ID = "APEX_GLOBAL_MULTI_SEED_UNTIL_SEPARATION_v1"
PHASE2_STREAM_PROTOCOL = "PHASE2_STREAM_PROTOCOL_V1.1"
OBJECTIVE = "LEXICOGRAPHIC_P_CONTEST_RANK1_THEN_P_TOP_0_1"

class EliteTailPropagationError(RuntimeError):
    pass

def _f(row: Mapping[str,Any], *names: str, default: float=float("nan")) -> float:
    for n in names:
        if n in row:
            try:
                v=float(row[n])
                if math.isfinite(v): return v
            except Exception: pass
    return default

def _prob(row: Mapping[str,Any], *names: str) -> float:
    v=_f(row,*names)
    if not math.isfinite(v): return float("nan")
    if v > 1.0 and v <= 100.0: v /= 100.0
    return min(1.0,max(0.0,v))

def _truthy(v: Any) -> bool:
    if isinstance(v,bool): return v
    return str(v).strip().lower() in {"1","true","yes","y"}

def _lineup_id(row: Mapping[str,Any]) -> str:
    for k in ("LINEUP_ID","LINEUP_INDEX","ID","lineup_id"):
        if str(row.get(k,"")) != "": return str(row[k])
    payload=json.dumps(dict(row),sort_keys=True,separators=(",",":"),default=str).encode()
    return sha256(payload).hexdigest()[:24]

def _trials(row: Mapping[str,Any]) -> int:
    n=_f(row,"MC_TRIALS","BASE_SIM_TRIALS","SIM_TRIALS","N_TRIALS",default=0.0)
    return max(0,int(n)) if math.isfinite(n) else 0

def _wilson(p: float, n: int, z: float=1.959963984540054) -> tuple[float,float]:
    if not math.isfinite(p) or n <= 0: return (0.0,1.0)
    p=min(1.0,max(0.0,p)); den=1.0+z*z/n
    ctr=(p+z*z/(2*n))/den
    rad=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/den
    return max(0.0,ctr-rad),min(1.0,ctr+rad)

def _neighborhood_id(row: Mapping[str,Any], sport: str, mode: str) -> str:
    for k in ("BIRTH_NEIGHBORHOOD_ID","CORE_FAMILY_ID","MACRO_FAMILY_ID","FAMILY_ID","VALUE_FAMILY_ID","FAMILY_SHAPE"):
        if str(row.get(k,"")) not in ("","nan","None"):
            return f"{str(sport).upper()}:{str(mode).upper()}:{k}:{row[k]}"
    players=[]
    for k,v in row.items():
        ku=str(k).upper()
        if ku in {"CPT","UTIL1","UTIL2","UTIL3","UTIL4","UTIL5","P","P1","P2","C","1B","2B","3B","SS","OF1","OF2","OF3"} and str(v).strip():
            players.append(str(v).strip().casefold())
    core="|".join(sorted(players)[:5]) or _lineup_id(row)
    return f"{str(sport).upper()}:{str(mode).upper()}:DERIVED:{sha256(core.encode()).hexdigest()[:16]}"

def _family_priors(rows: list[dict[str,Any]]) -> dict[str,tuple[float,float,int]]:
    groups: dict[str,list[dict[str,Any]]] = {}
    for r in rows: groups.setdefault(str(r["BIRTH_NEIGHBORHOOD_ID"]),[]).append(r)
    out={}
    for gid,rs in groups.items():
        wins=[]; tops=[]
        for r in rs:
            pw=_prob(r,"MC_WIN_RATE","WIN_RATE","BASE_MC_WIN_RATE")
            pt=_prob(r,"MC_TOP_0_1_RATE","TOP_0.1_RATE","TOP_0_1_RATE","BASE_MC_TOP01_RATE")
            if math.isfinite(pw): wins.append(pw)
            if math.isfinite(pt): tops.append(pt)
        out[gid]=(sum(wins)/len(wins) if wins else 0.0, sum(tops)/len(tops) if tops else 0.0, len(rs))
    return out

def _posterior(p: float, n: int, prior_mean: float, prior_strength: float) -> float:
    if not math.isfinite(p): p=0.0
    if n <= 0: return prior_mean
    k=p*n
    return (k + prior_mean*prior_strength) / (n + prior_strength)

def enrich_elite_tail_lineage(rows: Sequence[Mapping[str,Any]], *, sport: str, mode: str, execution_id: str, copy_rows: bool=True) -> list[dict[str,Any]]:
    out=[dict(r) for r in rows] if copy_rows else (rows if isinstance(rows,list) and all(isinstance(r,dict) for r in rows) else [dict(r) for r in rows])
    if not out: return out
    for r in out:
        r["BIRTH_NEIGHBORHOOD_ID"]=_neighborhood_id(r,sport,mode)
    priors=_family_priors(out)
    scored=[]
    for r in out:
        n=_trials(r)
        pw=_prob(r,"MC_WIN_RATE","WIN_RATE","BASE_MC_WIN_RATE")
        pt=_prob(r,"MC_TOP_0_1_RATE","TOP_0.1_RATE","TOP_0_1_RATE","BASE_MC_TOP01_RATE")
        if not math.isfinite(pw): pw=0.0
        if not math.isfinite(pt): pt=0.0
        wlo,whi=_wilson(pw,n); tlo,thi=_wilson(pt,n)
        gwin,gtop,gsize=priors[r["BIRTH_NEIGHBORHOOD_ID"]]
        # bounded empirical-Bayes pull toward structural neighborhood mean.
        strength=min(64.0,max(4.0,4.0*math.sqrt(max(1,gsize))))
        wpost=_posterior(pw,n,gwin,strength)
        tpost=_posterior(pt,n,gtop,strength)
        p99=_f(r,"MC_P99","P99","BASE_MC_P99",default=float("-inf"))
        r.update({
            "ELITE_TAIL_PATCH_ID":PATCH_ID,
            "PHASE2_STREAM_PROTOCOL":PHASE2_STREAM_PROTOCOL,
            "ELITE_RANK1_POSTERIOR":wpost,
            "ELITE_TOP01_POSTERIOR":tpost,
            "ELITE_RANK1_LCB":wlo,
            "ELITE_RANK1_UCB":whi,
            "ELITE_TOP01_LCB":tlo,
            "ELITE_TOP01_UCB":thi,
            "ELITE_TAIL_MC_TRIALS":n,
            "ELITE_NEIGHBORHOOD_SIZE":gsize,
        })
        scored.append((wlo,tlo,wpost,tpost,p99,_lineup_id(r),r))
    scored.sort(key=lambda x:(x[0],x[1],x[2],x[3],x[4],x[5]),reverse=True)
    champion_id=scored[0][5]
    # Recall guard is deliberately broad: any observed rare-event support OR top-decile
    # robust objective evidence is protected. This is a propagation flag, not a cull.
    nrows=len(scored); cut=max(1,math.ceil(nrows*0.10))
    protected_ids={x[5] for x in scored[:cut]}
    for _,_,_,_,_,lid,r in scored:
        observed=(_prob(r,"MC_WIN_RATE","WIN_RATE","BASE_MC_WIN_RATE") > 0 or _prob(r,"MC_TOP_0_1_RATE","TOP_0.1_RATE","TOP_0_1_RATE","BASE_MC_TOP01_RATE") > 0)
        qualified=bool(observed or lid in protected_ids)
        r["IS_ELITE_TAIL_QUALIFIED"]=qualified
        r["PROTECTED_CHAMPION"]=bool(lid==champion_id)
        r["IMMUNE_TO_MEDIAN_CUTOFF"]=qualified
        r["IMMUNE_TO_FAMILY_QUOTA"]=qualified
        r["IMMUNE_TO_OWNERSHIP_PREFERENCE"]=qualified
        r["IMMUNE_TO_DIVERSIFICATION_EVICTION"]=qualified
        passport_payload={
            "patch":PATCH_ID,"execution_id":str(execution_id),"sport":str(sport).upper(),"mode":str(mode).upper(),
            "lineup_id":lid,"birth_neighborhood_id":r["BIRTH_NEIGHBORHOOD_ID"],
            "rank1_posterior":r["ELITE_RANK1_POSTERIOR"],"top01_posterior":r["ELITE_TOP01_POSTERIOR"],
        }
        r["HANDOFF_IMMUNITY_TOKEN"]=sha256(json.dumps(passport_payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
        r["SIM_VARIANCE_METRICS"]=json.dumps({
            "crn_identifier":str(r.get("CRN_IDENTIFIER") or r.get("COMMON_WORLD_ID") or f"{execution_id}:COMMON_WORLD"),
            "mc_trials":r["ELITE_TAIL_MC_TRIALS"],
            "rank1_lcb":r["ELITE_RANK1_LCB"],"rank1_ucb":r["ELITE_RANK1_UCB"],
            "top01_lcb":r["ELITE_TOP01_LCB"],"top01_ucb":r["ELITE_TOP01_UCB"],
            "multi_seed_separation_delta":_f(r,"MULTI_SEED_SEPARATION_DELTA","CROSS_SEED_STABILITY",default=0.0),
        },sort_keys=True,separators=(",",":"))
    # Bubble overlap flags: no direct sort may pretend statistical separation when
    # confidence intervals overlap the board boundary.
    board_boundary=scored[min(4,len(scored)-1)][6]
    bwlo=float(board_boundary["ELITE_RANK1_LCB"]); bwhi=float(board_boundary["ELITE_RANK1_UCB"])
    btlo=float(board_boundary["ELITE_TOP01_LCB"]); bthi=float(board_boundary["ELITE_TOP01_UCB"])
    for r in out:
        overlap=(float(r["ELITE_RANK1_UCB"])>=bwlo and float(r["ELITE_RANK1_LCB"])<=bwhi and
                 float(r["ELITE_TOP01_UCB"])>=btlo and float(r["ELITE_TOP01_LCB"])<=bthi)
        r["ADAPTIVE_BUBBLE_RESIM_REQUIRED"]=bool(overlap and r["IS_ELITE_TAIL_QUALIFIED"])
        r["ADAPTIVE_BUBBLE_STATUS"]="REQUIRED_IF_NOT_ALREADY_SEPARATED" if r["ADAPTIVE_BUBBLE_RESIM_REQUIRED"] else "NOT_REQUIRED"
    return out


def _elite_order(rows: Sequence[Mapping[str,Any]]) -> list[dict[str,Any]]:
    # Ordering never mutates row mappings; keep references instead of cloning the full terminal surface.
    ordered=list(rows)
    ordered.sort(key=lambda r:(
        _f(r,"ELITE_RANK1_LCB",default=0.0),
        _f(r,"ELITE_TOP01_LCB",default=0.0),
        _f(r,"ELITE_RANK1_POSTERIOR",default=0.0),
        _f(r,"ELITE_TOP01_POSTERIOR",default=0.0),
        _f(r,"MC_P99","P99","BASE_MC_P99",default=float("-inf")),
        _lineup_id(r),
    ),reverse=True)
    return ordered

def _interval_overlap(a_lo: float, a_hi: float, b_lo: float, b_hi: float) -> bool:
    return float(a_hi) >= float(b_lo) and float(a_lo) <= float(b_hi)

def _boundary_bubble(rows: Sequence[Mapping[str,Any]], board_size: int) -> tuple[list[dict[str,Any]],list[str],dict[str,Any]|None,list[dict[str,Any]]]:
    ordered=_elite_order(rows)
    if not ordered:
        return [],[],None,[]
    k=min(max(1,int(board_size)),len(ordered))
    selected=ordered[:k]
    selected_ids=[_lineup_id(r) for r in selected]
    if len(ordered) <= k:
        return [],selected_ids,selected[-1],[]
    boundary=selected[-1]
    unresolved=[]
    for r in ordered[k:]:
        rank_overlap=_interval_overlap(
            _f(r,"ELITE_RANK1_LCB",default=0.0),_f(r,"ELITE_RANK1_UCB",default=1.0),
            _f(boundary,"ELITE_RANK1_LCB",default=0.0),_f(boundary,"ELITE_RANK1_UCB",default=1.0),
        )
        top_overlap=_interval_overlap(
            _f(r,"ELITE_TOP01_LCB",default=0.0),_f(r,"ELITE_TOP01_UCB",default=1.0),
            _f(boundary,"ELITE_TOP01_LCB",default=0.0),_f(boundary,"ELITE_TOP01_UCB",default=1.0),
        )
        if rank_overlap and top_overlap:
            unresolved.append(r)
    if not unresolved:
        return [],selected_ids,boundary,[]
    bubble_ids={_lineup_id(boundary)}
    bubble_ids.update(_lineup_id(r) for r in unresolved)
    # Re-sim any provisional board member statistically entangled with an outsider,
    # not merely the fifth seat. This prevents a moving-boundary artifact.
    for s in selected:
        for r in unresolved:
            if (_interval_overlap(_f(s,"ELITE_RANK1_LCB",default=0.0),_f(s,"ELITE_RANK1_UCB",default=1.0),_f(r,"ELITE_RANK1_LCB",default=0.0),_f(r,"ELITE_RANK1_UCB",default=1.0)) and
                _interval_overlap(_f(s,"ELITE_TOP01_LCB",default=0.0),_f(s,"ELITE_TOP01_UCB",default=1.0),_f(r,"ELITE_TOP01_LCB",default=0.0),_f(r,"ELITE_TOP01_UCB",default=1.0))):
                bubble_ids.add(_lineup_id(s)); break
    bubble=[dict(r) for r in rows if _lineup_id(r) in bubble_ids]
    return bubble,selected_ids,boundary,unresolved

def _separation_delta(boundary: Mapping[str,Any]|None, unresolved: Sequence[Mapping[str,Any]]) -> float:
    if boundary is None or not unresolved:
        return float("inf")
    rank_gap=_f(boundary,"ELITE_RANK1_LCB",default=0.0)-max(_f(r,"ELITE_RANK1_UCB",default=1.0) for r in unresolved)
    if rank_gap > 0:
        return float(rank_gap)
    top_gap=_f(boundary,"ELITE_TOP01_LCB",default=0.0)-max(_f(r,"ELITE_TOP01_UCB",default=1.0) for r in unresolved)
    return float(top_gap)

def multi_seed_until_separation(
    rows: Sequence[Mapping[str,Any]], *,
    simulator: Callable[[list[dict[str,Any]],int,int],Sequence[Mapping[str,Any]]],
    sport: str, mode: str, execution_id: str, board_size: int=5,
    base_extra_trials: int=10000, max_rounds: int=3, seed0: int=910001, copy_rows: bool=True,
) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    """Deterministically reduce rare-event boundary noise with sport-native seeds.

    The callback owns all sports physics and must return the exact same lineup IDs
    with cumulative refreshed metrics and strictly increased ``MC_TRIALS``.  This
    global loop only identifies confidence-overlap candidates, schedules seeds,
    verifies lineage/cardinality, and repeats until the inclusion boundary is
    separated or the configured budget is exhausted.  An unresolved max-budget
    cohort is explicitly labeled statistically equivalent; it is never falsely
    declared separated.
    """
    if simulator is None:
        raise EliteTailPropagationError("RUN_INVALID:MULTI_SEED_SIMULATOR_CALLBACK_MISSING")
    if int(base_extra_trials) <= 0 or int(max_rounds) <= 0:
        raise EliteTailPropagationError("RUN_INVALID:MULTI_SEED_BUDGET_INVALID")
    current=enrich_elite_tail_lineage(rows,sport=sport,mode=mode,execution_id=str(execution_id),copy_rows=copy_rows)
    round_count: dict[str,int]={}
    extra_by_id: dict[str,int]={}
    seeds_by_id: dict[str,list[int]]={}
    rounds=[]; total_world_trials=0; total_lineup_trial_evals=0
    status="NOT_REQUIRED"
    final_boundary=None; final_unresolved=[]
    for round_idx in range(int(max_rounds)):
        bubble,selected_ids,boundary,unresolved=_boundary_bubble(current,board_size)
        final_boundary=boundary; final_unresolved=unresolved
        bubble_ids={_lineup_id(r) for r in bubble}
        for r in current:
            r["ADAPTIVE_BUBBLE_RESIM_REQUIRED"]=_lineup_id(r) in bubble_ids
            r["ADAPTIVE_BUBBLE_STATUS"]="MULTI_SEED_REQUIRED" if _lineup_id(r) in bubble_ids else "NOT_REQUIRED"
        if not bubble:
            status="SEPARATED" if rounds else "NOT_REQUIRED"
            break
        extra_trials=int(base_extra_trials)*(2**round_idx)
        seed=int(seed0)+round_idx
        before={_lineup_id(r):_trials(r) for r in bubble}
        refreshed=[dict(r) for r in simulator([dict(r) for r in bubble],extra_trials,seed)]
        returned={_lineup_id(r):r for r in refreshed}
        expected=set(before)
        if set(returned)!=expected:
            missing=sorted(expected-set(returned)); extra=sorted(set(returned)-expected)
            raise EliteTailPropagationError(f"RUN_INVALID:MULTI_SEED_CALLBACK_ID_PARITY:missing={','.join(missing)}:extra={','.join(extra)}")
        for lid,r in returned.items():
            after=_trials(r)
            if after <= before[lid]:
                raise EliteTailPropagationError(f"RUN_INVALID:MULTI_SEED_TRIAL_COUNT_NOT_INCREASED:{lid}:{before[lid]}:{after}")
            round_count[lid]=round_count.get(lid,0)+1
            extra_by_id[lid]=extra_by_id.get(lid,0)+(after-before[lid])
            seeds_by_id.setdefault(lid,[]).append(seed)
        for i,r in enumerate(current):
            lid=_lineup_id(r)
            if lid in returned:
                merged=dict(r); merged.update(returned[lid]); current[i]=merged
        total_world_trials += extra_trials
        total_lineup_trial_evals += extra_trials*len(bubble)
        rounds.append({
            "round":round_idx+1,"seed":seed,"extra_world_trials":extra_trials,
            "bubble_lineups":len(bubble),"boundary_lineup_id":_lineup_id(boundary) if boundary is not None else None,
            "unresolved_outside_lineups":len(unresolved),
        })
        current=enrich_elite_tail_lineage(current,sport=sport,mode=mode,execution_id=str(execution_id),copy_rows=False)
    else:
        bubble,selected_ids,final_boundary,final_unresolved=_boundary_bubble(current,board_size)
        status="MAX_BUDGET_EQUIVALENT" if bubble else "SEPARATED"

    # Recompute final boundary state even when loop exited early.
    bubble,selected_ids,final_boundary,final_unresolved=_boundary_bubble(current,board_size)
    if status not in {"MAX_BUDGET_EQUIVALENT"} and not bubble:
        status="SEPARATED" if rounds else "NOT_REQUIRED"
    elif bubble and len(rounds)>=int(max_rounds):
        status="MAX_BUDGET_EQUIVALENT"
    delta=_separation_delta(final_boundary,final_unresolved)
    _selected_id_set=set(selected_ids); _bubble_id_set={_lineup_id(x) for x in bubble}
    for r in current:
        lid=_lineup_id(r)
        r["MULTI_SEED_PATCH_ID"]=MULTI_SEED_PATCH_ID
        r["MULTI_SEED_CONVERGENCE_STATUS"]=status
        r["MULTI_SEED_ROUNDS"]=int(round_count.get(lid,0))
        r["MULTI_SEED_EXTRA_TRIALS"]=int(extra_by_id.get(lid,0))
        r["MULTI_SEED_SEEDS"]="|".join(str(x) for x in seeds_by_id.get(lid,[]))
        r["MULTI_SEED_SEPARATION_DELTA"]=delta if math.isfinite(delta) else 1.0
        r["MULTI_SEED_SELECTED_BOUNDARY"]=lid in _selected_id_set
        r["ADAPTIVE_BUBBLE_RESIM_REQUIRED"]=lid in _bubble_id_set
        r["ADAPTIVE_BUBBLE_STATUS"]=("MAX_BUDGET_EQUIVALENT" if lid in _bubble_id_set else "RESOLVED") if rounds else r.get("ADAPTIVE_BUBBLE_STATUS","NOT_REQUIRED")
        try:
            sm=json.loads(str(r.get("SIM_VARIANCE_METRICS") or "{}"))
        except Exception:
            sm={}
        sm.update({
            "multi_seed_patch_id":MULTI_SEED_PATCH_ID,"multi_seed_rounds":int(round_count.get(lid,0)),
            "multi_seed_extra_trials":int(extra_by_id.get(lid,0)),"multi_seed_seeds":seeds_by_id.get(lid,[]),
            "multi_seed_convergence_status":status,"multi_seed_separation_delta":r["MULTI_SEED_SEPARATION_DELTA"],
        })
        r["SIM_VARIANCE_METRICS"]=json.dumps(sm,sort_keys=True,separators=(",",":"))
    receipt={
        "PATCH_ID":MULTI_SEED_PATCH_ID,"STATUS":status,"SPORT":str(sport).upper(),"MODE":str(mode).upper(),
        "EXECUTION_ID":str(execution_id),"BOARD_SIZE":int(board_size),"ROUNDS_EXECUTED":len(rounds),
        "SEEDS":[int(x["seed"]) for x in rounds],"ROUND_LEDGER":rounds,
        "EXTRA_WORLD_TRIALS_TOTAL":int(total_world_trials),
        "EXTRA_LINEUP_TRIAL_EVALUATIONS":int(total_lineup_trial_evals),
        "UNRESOLVED_BOUNDARY_LINEUPS":len(bubble),
        "UNRESOLVED_OUTSIDE_LINEUPS":len(final_unresolved),
        "SEPARATION_ACHIEVED":bool(not bubble),
        "FINAL_BOUNDARY_LINEUP_ID":_lineup_id(final_boundary) if final_boundary is not None else None,
        "FINAL_SEPARATION_DELTA":delta if math.isfinite(delta) else None,
        "CRN_WITHIN_EACH_SEED_REQUIRED":True,"SPORT_NATIVE_SIMULATOR_ONLY":True,
        "DIRECT_SPARSE_RATE_SORT_BEFORE_LOOP":False,
    }
    return current,receipt

def adaptive_bubble_resimulation(rows: Sequence[Mapping[str,Any]], *, simulator: Callable[[list[dict[str,Any]],int,int],Sequence[Mapping[str,Any]]],
                                 base_extra_trials: int=20000, max_rounds: int=4, seed0: int=900001) -> list[dict[str,Any]]:
    """Run isolated extra simulation on statistically overlapping elite candidates.

    The caller supplies the sport-native simulator callback; this module never
    substitutes generic sports physics. The callback receives (bubble_rows,
    extra_trials, seed) and must return the same lineup IDs with refreshed metrics.
    """
    current=[dict(r) for r in rows]
    for round_idx in range(max_rounds):
        bubble=[r for r in current if bool(r.get("ADAPTIVE_BUBBLE_RESIM_REQUIRED"))]
        if not bubble: break
        refreshed=[dict(r) for r in simulator(bubble,base_extra_trials*(2**round_idx),seed0+round_idx)]
        by={_lineup_id(r):r for r in refreshed}
        for i,r in enumerate(current):
            lid=_lineup_id(r)
            if lid in by:
                merged=dict(r); merged.update(by[lid]); current[i]=merged
        # Caller must re-run enrich_elite_tail_lineage after refreshed metrics.
        break
    return current

def validate_terminal_selection(rows: Sequence[Mapping[str,Any]], selected_ids: Sequence[str]) -> dict[str,Any]:
    rs=[dict(r) for r in rows]; selected={str(x) for x in selected_ids}
    if not rs: raise EliteTailPropagationError("RUN_INVALID:ELITE_TAIL_EMPTY_CANDIDATE_SURFACE")
    required=("BIRTH_NEIGHBORHOOD_ID","HANDOFF_IMMUNITY_TOKEN","SIM_VARIANCE_METRICS","ELITE_RANK1_POSTERIOR","ELITE_TOP01_POSTERIOR")
    for r in rs:
        if any(str(r.get(k,""))=="" for k in required):
            raise EliteTailPropagationError(f"RUN_INVALID:ELITE_TAIL_LINEAGE_MISSING:{_lineup_id(r)}")
    protected=[r for r in rs if str(r.get("PROTECTED_CHAMPION","")).lower() in {"true","1","yes"} or r.get("PROTECTED_CHAMPION") is True]
    if len(protected)!=1:
        raise EliteTailPropagationError(f"RUN_INVALID:PROTECTED_CHAMPION_CARDINALITY:{len(protected)}")
    champ=_lineup_id(protected[0])
    if champ not in selected:
        raise EliteTailPropagationError(f"RUN_INVALID:PROTECTED_CHAMPION_EVICTED:{champ}")
    selected_rows=[r for r in rs if _lineup_id(r) in selected]
    nonselected=[r for r in rs if _lineup_id(r) not in selected and _truthy(r.get("IS_ELITE_TAIL_QUALIFIED"))]
    # Hard reject only statistically clear domination. Overlapping intervals remain
    # bubble candidates and must not be falsely ordered by ownership/diversification.
    for loser in nonselected:
        ll1=float(loser["ELITE_RANK1_LCB"]); llt=float(loser["ELITE_TOP01_LCB"])
        dominated=[s for s in selected_rows if ll1 > float(s["ELITE_RANK1_UCB"]) and llt > float(s["ELITE_TOP01_UCB"])]
        if dominated:
            raise EliteTailPropagationError(f"RUN_INVALID:STATISTICALLY_SUPERIOR_ELITE_TAIL_EVICTED:{_lineup_id(loser)}")
    return {
        "PATCH_ID":PATCH_ID,"STATUS":"PASS","OBJECTIVE":OBJECTIVE,
        "PROTECTED_CHAMPION_LINEUP_ID":champ,"SELECTED_COUNT":len(selected_rows),
        "ELITE_QUALIFIED_COUNT":sum(1 for r in rs if _truthy(r.get("IS_ELITE_TAIL_QUALIFIED"))),
        "BUBBLE_RESIM_REQUIRED_COUNT":sum(1 for r in rs if _truthy(r.get("ADAPTIVE_BUBBLE_RESIM_REQUIRED"))),
        "OWNERSHIP_CULL_AUTHORITY":False,"FAMILY_QUOTA_CULL_AUTHORITY":False,
        "MEDIAN_PROJECTION_CULL_AUTHORITY":False,"DIVERSIFICATION_EVICTION_AUTHORITY_OVER_PROTECTED":False,
    }
