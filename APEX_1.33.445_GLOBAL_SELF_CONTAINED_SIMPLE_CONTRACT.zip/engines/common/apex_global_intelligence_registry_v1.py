#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Mapping

PATCH_ID = "APEX_GLOBAL_INTELLIGENCE_PROVIDER_REGISTRY_v1"
REGISTRY_SCOPE = "GLOBAL_ENGINE"

# These are capability/provider identities only. ChatGPT-managed connectors keep
# their own OAuth/session credentials outside the engine artifact. The engine
# accepts frozen evidence/context from them but never stores connector secrets.
PROVIDERS: dict[str, dict[str, Any]] = {
    "OPENAI": {
        "kind": "external_api",
        "credential_policy": "ONE_GLOBAL_ENGINE_SECRET_REUSED",
        "secret_env": "OPENAI_API_KEY",
        "per_sport_credentials": False,
    },
    "AIRTABLE": {"kind": "chatgpt_plugin", "credential_policy": "PLATFORM_MANAGED_CONNECTION", "per_sport_credentials": False},
    "NOTION": {"kind": "chatgpt_plugin", "credential_policy": "PLATFORM_MANAGED_CONNECTION", "per_sport_credentials": False},
    "EXA": {"kind": "chatgpt_plugin", "credential_policy": "PLATFORM_MANAGED_CONNECTION", "per_sport_credentials": False},
    "ACUMEN_TALARION": {"kind": "chatgpt_plugin", "credential_policy": "PLATFORM_MANAGED_CONNECTION", "per_sport_credentials": False},
    "DATA": {"kind": "chatgpt_plugin", "credential_policy": "PLATFORM_MANAGED_CONNECTION", "per_sport_credentials": False},
    "DATACAMP": {"kind": "chatgpt_plugin", "credential_policy": "PLATFORM_MANAGED_CONNECTION", "per_sport_credentials": False},
    "GOOGLE_DRIVE": {"kind": "chatgpt_plugin", "credential_policy": "PLATFORM_MANAGED_CONNECTION", "per_sport_credentials": False},
    # User-directed research stack. These may be native ChatGPT capabilities rather
    # than separately installable OAuth apps, so they are governed as capabilities.
    "RESEARCH": {"kind": "native_research_capability", "credential_policy": "CHATGPT_SESSION", "per_sport_credentials": False},
    "DEEP_RESEARCH": {"kind": "native_research_capability", "credential_policy": "CHATGPT_SESSION", "per_sport_credentials": False},
    "STUDY": {"kind": "native_research_capability", "credential_policy": "CHATGPT_SESSION", "per_sport_credentials": False},
}

# Explicitly not in the active APEX research stack by user direction.
DISABLED_PROVIDERS = {"CONSENSUS"}

_SECRET_TOKENS = (
    "api_key", "apikey", "access_token", "refresh_token", "oauth", "bearer",
    "secret", "password", "private_key", "authorization", "cookie", "session_token",
)


def _canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _sha(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj)).hexdigest()


def _assert_no_secrets(obj: Any, path: str = "$") -> None:
    if isinstance(obj, Mapping):
        for key, value in obj.items():
            k = str(key).casefold()
            if any(tok in k for tok in _SECRET_TOKENS):
                raise ValueError(f"GLOBAL_PLUGIN_CONTEXT_SECRET_FIELD_REJECTED:{path}.{key}")
            _assert_no_secrets(value, f"{path}.{key}")
    elif isinstance(obj, list):
        for i, value in enumerate(obj):
            _assert_no_secrets(value, f"{path}[{i}]")


def active_registry() -> dict[str, Any]:
    return {
        "PATCH_ID": PATCH_ID,
        "SCOPE": REGISTRY_SCOPE,
        "AUTH_INITIALIZATION": "ONCE_PER_ENGINE_SESSION_OR_PLATFORM_CONNECTION",
        "PER_SPORT_AUTH": False,
        "PER_MODE_AUTH": False,
        "PER_SLATE_AUTH": False,
        "REUSE_EXISTING_CONNECTIONS": True,
        "REAUTH_ONLY_IF_PROVIDER_CONNECTION_UNAVAILABLE_OR_EXPIRED": True,
        "PROVIDERS": {k: dict(v) for k, v in PROVIDERS.items()},
        "DISABLED_PROVIDERS": sorted(DISABLED_PROVIDERS),
    }


def _load_external_context() -> dict[str, Any]:
    """Load optional frozen provider evidence supplied by the ChatGPT orchestration layer.

    This is deliberately evidence transport, not credential transport. ChatGPT plugins
    remain platform-managed and can write a context packet for the engine to consume.
    """
    raw = os.environ.get("APEX_GLOBAL_INTELLIGENCE_CONTEXT_JSON", "").strip()
    path = os.environ.get("APEX_GLOBAL_INTELLIGENCE_CONTEXT_PATH", "").strip()
    if raw and path:
        raise ValueError("GLOBAL_PLUGIN_CONTEXT_AMBIGUOUS_SOURCE")
    if raw:
        obj = json.loads(raw)
    elif path:
        p = Path(path)
        if not p.exists() or not p.is_file():
            raise ValueError(f"GLOBAL_PLUGIN_CONTEXT_PATH_MISSING:{p}")
        obj = json.loads(p.read_text(encoding="utf-8"))
    else:
        return {}
    if not isinstance(obj, dict):
        raise ValueError("GLOBAL_PLUGIN_CONTEXT_NOT_OBJECT")
    _assert_no_secrets(obj)
    return obj


def freeze_run_context(*, sport: str, mode: str, execution_id: str, base_context: Mapping[str, Any] | None = None) -> dict[str, Any]:
    base = dict(base_context or {})
    _assert_no_secrets(base)
    evidence = _load_external_context()
    registry = active_registry()
    packet = {
        "GLOBAL_INTELLIGENCE_REGISTRY": registry,
        "GLOBAL_INTELLIGENCE_EVIDENCE": evidence,
        "SPORT": str(sport).upper(),
        "MODE": str(mode).upper(),
        "EXECUTION_ID": str(execution_id),
    }
    freeze_sha = _sha(packet)
    out = dict(base)
    out.update({
        "GLOBAL_INTELLIGENCE_PATCH_ID": PATCH_ID,
        "GLOBAL_INTELLIGENCE_SCOPE": REGISTRY_SCOPE,
        "GLOBAL_INTELLIGENCE_CONTEXT_FREEZE_SHA256": freeze_sha,
        "GLOBAL_INTELLIGENCE_REGISTRY": registry,
        "GLOBAL_INTELLIGENCE_EVIDENCE": evidence,
        "GLOBAL_INTELLIGENCE_NO_SECRETS": True,
        "GLOBAL_INTELLIGENCE_EXECUTION_AUTHORITY": False,
        "GLOBAL_INTELLIGENCE_SUPPORT_AUTHORITY": True,
    })
    return out


def provider_enabled(name: str) -> bool:
    key = str(name).upper().replace(" ", "_")
    return key in PROVIDERS and key not in DISABLED_PROVIDERS
