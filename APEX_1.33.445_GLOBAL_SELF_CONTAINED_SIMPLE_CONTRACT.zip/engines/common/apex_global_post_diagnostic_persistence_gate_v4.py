from __future__ import annotations
from engines.common.apex_stable_pointer_cas_v1 import stable_pointer_cas
from pathlib import Path
from typing import Any, Protocol

from engines.common.apex_diagnostic_merge_ledger_v3 import (
    build_promotion_set,
    load_receipts,
    queue_snapshot,
    require_promotion_coverage,
    assert_queue_unchanged,
)

PATCH_ID = "APEX_GLOBAL_POST_DIAGNOSTIC_PERSISTENCE_AND_PROMOTION_ENFORCEMENT_v4"
TRIGGERS = {"PASS_LOCAL","DIAGNOSIS_COMPLETE","VALIDATED_PATCH","VALIDATED_CALIBRATION_CHANGE","VALIDATED_SELECTOR_CHANGE","VALIDATED_HANDOFF_CHANGE","VALIDATED_SPORT_RULE_CHANGE","VALIDATED_ENGINE_CHANGE","VALIDATED_DOCTRINE_CHANGE"}

class StatePersistenceError(RuntimeError): pass
class PointerRotationFailure(RuntimeError): pass
class PointerDriftError(RuntimeError): pass
class DiagnosticQueueDriftError(RuntimeError): pass
class DiagnosticQueueRescanUnavailable(RuntimeError): pass

class DriveHandler(Protocol):
    def rebuild_and_verify_complete_manifest(self, **kwargs: Any) -> dict: ...
    def write_immutable_bundle(self, **kwargs: Any) -> dict: ...
    def verify_bundle_readback(self, **kwargs: Any) -> dict: ...
    def persist_promotion_receipt(self, **kwargs: Any) -> dict: ...

class GlobalRegistry(Protocol):
    def read_active_pointer(self) -> dict: ...
    def write_versioned_pointer_source(self, **kwargs: Any) -> dict: ...
    def discover_exact_active_pointer(self) -> dict: ...
    def compare_and_swap_pointer_in_place(self, **kwargs: Any) -> dict: ...
    def readback_verify(self) -> dict: ...
    def rollback_pointer(self, **kwargs: Any) -> None: ...


def increment_patch_version(version: str) -> str:
    parts = version.split('.')
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        raise ValueError(f"INVALID_STATE_VERSION:{version}")
    return f"{parts[0]}.{parts[1]}.{int(parts[2])+1}"


def next_unused_patch_version(active_version: str, burned_versions=()) -> str:
    candidate = increment_patch_version(active_version)
    burned = {str(v) for v in burned_versions}
    while candidate in burned:
        candidate = increment_patch_version(candidate)
    return candidate


def _state_digest_from_write(write: dict) -> str:
    bundle_sha = str(write.get('BUNDLE_SHA256') or '').strip().lower()
    if len(bundle_sha) != 64:
        raise StatePersistenceError('BUNDLE_SHA256_REQUIRED_FOR_STATE_DIGEST')
    return 'sha256:' + bundle_sha


def _match_pointer(rb: dict, version: str, write: dict) -> bool:
    expected_digest = _state_digest_from_write(write)
    return (str(rb.get('STATE_VERSION')) == version
            and rb.get('BUNDLE_FILE_ID') == write.get('BUNDLE_FILE_ID')
            and rb.get('BUNDLE_SHA256') == write.get('BUNDLE_SHA256')
            and rb.get('ENCODED_SHA256') == write.get('ENCODED_SHA256')
            and str(rb.get('STATE_DIGEST') or '') == expected_digest)


def _live_queue_receipts(local_state: Any, drive_handler: DriveHandler) -> list[dict]:
    reader = getattr(drive_handler, 'read_diagnostic_queue_receipts', None)
    if callable(reader):
        rows = reader()
        if rows is None:
            raise DiagnosticQueueRescanUnavailable('DIAGNOSTIC_QUEUE_RESCAN_RETURNED_NONE')
        return list(rows)
    queue_dir = getattr(local_state, 'diagnostic_queue_dir', None)
    if queue_dir:
        return load_receipts(Path(queue_dir))
    raise DiagnosticQueueRescanUnavailable('DIAGNOSTIC_QUEUE_RESCAN_UNAVAILABLE')


def _live_plan(local_state: Any, drive_handler: DriveHandler, active_pointer: dict) -> tuple[list[dict], dict, dict]:
    receipts = _live_queue_receipts(local_state, drive_handler)
    snapshot = queue_snapshot(receipts)
    plan = build_promotion_set(receipts, active_pointer.get('GLOBAL_PATCHES') or (), active_state_version=active_pointer.get('STATE_VERSION'))
    coverage = require_promotion_coverage(plan, getattr(local_state, 'merged_patch_ids', ()) or ())
    return receipts, snapshot, {**plan, **coverage}


def enforce_global_promotion_lifecycle(local_state: Any, drive_handler: DriveHandler, global_registry: GlobalRegistry) -> Any:
    status = getattr(local_state, 'repair_status', None)
    if status not in TRIGGERS:
        return local_state

    before = global_registry.read_active_pointer()
    active = str(before['STATE_VERSION'])
    requested_parent = str(getattr(local_state, 'parent_state_version', active))
    if requested_parent != active:
        raise PointerDriftError(f"ACTIVE_POINTER_DRIFT:{requested_parent}->{active}")

    _, queue_before, plan_before = _live_plan(local_state, drive_handler, before)
    local_state.diagnostic_queue_snapshot = queue_before
    local_state.diagnostic_promotion_plan = plan_before

    burned = tuple(getattr(local_state, 'burned_state_versions', ()) or ())
    new_version = next_unused_patch_version(active, burned)
    try:
        seal = drive_handler.rebuild_and_verify_complete_manifest(
            state_version=new_version,
            parent_state_version=active,
            root=getattr(local_state, 'bundle_root', None),
            metadata=getattr(local_state, 'manifest_metadata', None),
            changed_components=getattr(local_state, 'changed_components', None),
        )
        if not (seal.get('MANIFEST_FRESHLY_REBUILT') is True and seal.get('MANIFEST_EXACT_FILESET') is True and seal.get('INTERNAL_MANIFEST_CHECK') == 'PASS' and int(seal.get('MANIFEST_ENTRY_COUNT', 0)) > 0 and bool(seal.get('MANIFEST_SHA256'))):
            raise StatePersistenceError('FRESH_COMPLETE_MANIFEST_SEAL_REQUIRED')
        write = drive_handler.write_immutable_bundle(
            target_directory='/Drive/Sealed_Patches/', state_version=new_version,
            parent_state_version=active, parent_bundle_hash=before.get('BUNDLE_SHA256'),
            manifest=getattr(local_state,'current_manifest'), hashes=getattr(local_state,'computed_sha256'),
            frozen_candidate=getattr(local_state,'frozen_candidate_universe',None),
        )
    except Exception as exc:
        raise StatePersistenceError(f"CANNOT_SERIALIZE_IMMUTABLE_STATE:{exc}") from exc

    local_state.persisted_to_drive = True
    local_state.new_immutable_state_created = True

    pre_rotate = global_registry.read_active_pointer()
    if str(pre_rotate.get('STATE_VERSION')) != active or pre_rotate.get('BUNDLE_SHA256') != before.get('BUNDLE_SHA256'):
        raise PointerDriftError(f"PRE_ROTATION_POINTER_DRIFT:{active}->{pre_rotate.get('STATE_VERSION')}")

    # Mandatory live queue rescan. Never substitute the old in-memory snapshot.
    _, queue_after, plan_after = _live_plan(local_state, drive_handler, pre_rotate)
    try:
        assert_queue_unchanged(queue_before, queue_after)
    except Exception as exc:
        raise DiagnosticQueueDriftError(str(exc)) from exc
    if plan_after.get('UNIMPLEMENTED_VALIDATED_PATCHES', 0) != 0:
        raise DiagnosticQueueDriftError('UNIMPLEMENTED_VALIDATED_PATCHES')

    versioned = global_registry.write_versioned_pointer_source(
        from_version=active, to_version=new_version, bundle_file_id=write['BUNDLE_FILE_ID'],
        bundle_hash=write['BUNDLE_SHA256'], encoded_hash=write['ENCODED_SHA256'])
    pointer_payload = {**before, 'STATE_VERSION': new_version, 'PARENT_STATE_VERSION': active,
                       'BUNDLE_FILE_ID': write['BUNDLE_FILE_ID'], 'BUNDLE_SHA256': write['BUNDLE_SHA256'],
                       'ENCODED_SHA256': write['ENCODED_SHA256'],
                       'STATE_DIGEST': _state_digest_from_write(write),
                       'VERSIONED_POINTER_SOURCE_FILE_ID': versioned.get('FILE_ID')}
    exact_pre = global_registry.discover_exact_active_pointer()
    pre_id = str(exact_pre.get('FILE_ID') or exact_pre.get('ACTIVE_POINTER_FILE_ID') or '')
    before_id = str(before.get('FILE_ID') or before.get('ACTIVE_POINTER_FILE_ID') or '')
    if not before_id or pre_id != before_id:
        raise PointerDriftError(f"PRE_COMMIT_POINTER_OBJECT_DRIFT:{before_id}->{pre_id}")
    pre_sha = str(exact_pre.get('POINTER_BYTES_SHA256') or exact_pre.get('BYTES_SHA256') or '')
    if not pre_sha:
        raise PointerDriftError('PRE_COMMIT_POINTER_BYTES_SHA256_REQUIRED')
    before_for_cas = {**before, 'FILE_ID': before_id, 'ACTIVE_POINTER_FILE_ID': before_id, 'POINTER_BYTES_SHA256': pre_sha}
    cas = stable_pointer_cas(global_registry, before=before_for_cas, pointer_payload=pointer_payload, expected_pointer_sha256=pre_sha)
    rb = global_registry.readback_verify()
    rb['POINTER_STABLE_ID_CAS'] = cas.get('POINTER_STABLE_ID_CAS')
    rb['POINTER_COMPARE_AND_SWAP'] = cas.get('POINTER_COMPARE_AND_SWAP')
    bundle_rb = drive_handler.verify_bundle_readback(
        state_version=new_version, bundle_file_id=write['BUNDLE_FILE_ID'],
        expected_bundle_sha256=write['BUNDLE_SHA256'], expected_encoded_sha256=write['ENCODED_SHA256'])
    checks = _match_pointer(rb, new_version, write) and rb.get('POINTER_STABLE_ID_CAS') == 'PASS' and rb.get('POINTER_COMPARE_AND_SWAP') == 'PASS' and bool(rb.get('POINTER_SOURCE_BYTE_PARITY', False)) and bundle_rb.get('ENCODED_HASH_CHECK') == 'PASS' and bundle_rb.get('BUNDLE_HASH_CHECK') == 'PASS' and bundle_rb.get('INTERNAL_MANIFEST_CHECK') == 'PASS' and bundle_rb.get('MANIFEST_EXACT_FILESET') is True and bundle_rb.get('MANIFEST_SHA256') == seal.get('MANIFEST_SHA256')
    if not checks:
        local_state.global_pointer_rotated = False
        global_registry.rollback_pointer(previous_pointer=before)
        raise PointerRotationFailure('GLOBAL_POINTER_OR_BUNDLE_READBACK_MISMATCH_ROLLBACK_INITIATED')

    local_state.global_pointer_rotated = True
    local_state.pointer_readback_verified = True
    local_state.bundle_readback_verified = True
    local_state.global_repair_status = 'COMMITTED'
    local_state.state_version = new_version
    local_state.diagnostic_queue_snapshot_pre_rotation = queue_after
    drive_handler.persist_promotion_receipt(
        state_version=new_version, parent_state_version=active, pointer_readback=rb,
        bundle_readback=bundle_rb, status='COMMITTED', diagnostic_promotion_plan=plan_after)
    return local_state


def require_committed(local_state: Any) -> None:
    required = (
        getattr(local_state,'persisted_to_drive',False),
        getattr(local_state,'new_immutable_state_created',False),
        getattr(local_state,'global_pointer_rotated',False),
        getattr(local_state,'pointer_readback_verified',False),
        getattr(local_state,'bundle_readback_verified',False),
        getattr(local_state,'global_repair_status',None) == 'COMMITTED',
    )
    if not all(required):
        raise StatePersistenceError('VOLATILE_OR_PARTIAL_PROMOTION_EXIT_PROHIBITED')
