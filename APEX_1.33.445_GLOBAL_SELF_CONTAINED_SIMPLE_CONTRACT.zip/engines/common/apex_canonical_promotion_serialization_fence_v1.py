from __future__ import annotations

"""APEX canonical promotion serialization fence.

Promotion-only hard gate. It prevents two classes of cross-chat corruption:
1) an older/stale branch replacing a newer canonical bundle;
2) two windows independently minting the same state version.

The caller must provide a fresh Drive version-scan receipt twice: once before candidate
promotion and once immediately before the write. The live DFS slate path is untouched;
this module is not a CSV startup gate.
"""

from dataclasses import dataclass, asdict
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping
import argparse
import json
import re
import zipfile

PATCH_ID = "APEX_GLOBAL_CANONICAL_PROMOTION_SERIALIZATION_FENCE_v1"
SCHEMA_VERSION = "1.0"
CANONICAL_TITLE = "APEX_DIRECT_ENGINE.zip"
CANONICAL_DRIVE_FILE_ID = "1hqxCtbX1JXapIB_da4rhOcVksPHhdbLH"
ARCHIVE_PREFIX = "APEX_DIRECT_ENGINE_v"


class PromotionFenceError(RuntimeError):
    pass


def _sha(path: str | Path) -> str:
    h = sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _version_tuple(value: str) -> tuple[int, ...]:
    s = str(value or "").strip()
    m = re.fullmatch(r"v?(\d+(?:\.\d+)+)", s)
    if not m:
        raise PromotionFenceError(f"PROMOTION_HALT:INVALID_STATE_VERSION:{s}")
    return tuple(int(x) for x in m.group(1).split("."))


def _read_json_from_zip(path: str | Path, member: str) -> dict[str, Any]:
    with zipfile.ZipFile(path, "r") as zf:
        try:
            raw = zf.read(member)
        except KeyError as exc:
            raise PromotionFenceError(f"PROMOTION_HALT:MISSING_BUNDLE_METADATA:{member}") from exc
    try:
        obj = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise PromotionFenceError(f"PROMOTION_HALT:INVALID_BUNDLE_METADATA:{member}:{exc}") from exc
    if not isinstance(obj, dict):
        raise PromotionFenceError(f"PROMOTION_HALT:INVALID_BUNDLE_METADATA_OBJECT:{member}")
    return obj


def _metadata(path: str | Path) -> dict[str, Any]:
    reg = _read_json_from_zip(path, "engine_registry.json")
    state = _read_json_from_zip(path, "state_contract.json")
    version = str(reg.get("ACTIVE_STATE_VERSION") or state.get("ACTIVE_STATE_VERSION") or "")
    if not version:
        raise PromotionFenceError("PROMOTION_HALT:ACTIVE_STATE_VERSION_MISSING")
    parent_version = str(state.get("PARENT_STATE_VERSION") or reg.get("PARENT_STATE_VERSION") or "")
    parent_sha = str(state.get("PARENT_BUNDLE_SHA256") or reg.get("PARENT_BUNDLE_SHA256") or "").lower()
    rebase_sha = str(
        state.get("CANONICAL_REBASE_SOURCE_SHA256")
        or reg.get("CANONICAL_REBASE_SOURCE_SHA256")
        or parent_sha
        or ""
    ).lower()
    return {
        "STATE_VERSION": version,
        "PARENT_STATE_VERSION": parent_version,
        "PARENT_BUNDLE_SHA256": parent_sha,
        "CANONICAL_REBASE_SOURCE_SHA256": rebase_sha,
        "BYTES_SHA256": _sha(path),
        "PATH": str(Path(path)),
    }




def _read_bundle_json(path: str | Path, member: str) -> dict[str, Any]:
    return _read_json_from_zip(path, member)


def _route_entry(registry: Mapping[str, Any], sport: str, mode: str) -> dict[str, Any]:
    su, mu = str(sport).upper(), str(mode).upper()
    matches=[]
    for rec in registry.get("ENGINES", []) or []:
        if not isinstance(rec, Mapping):
            continue
        if str(rec.get("SPORT", "")).upper()!=su:
            continue
        modes={str(x).upper() for x in (rec.get("MODES") or [])}
        if mu in modes:
            matches.append(dict(rec))
    if len(matches)!=1:
        raise PromotionFenceError(f"PROMOTION_HALT:PROTECTED_ROUTE_RESOLUTION:{su}:{mu}:{len(matches)}")
    return matches[0]


def _dotted_value(obj: Mapping[str, Any], path: str) -> Any:
    cur: Any = obj
    for part in str(path).split('.'):
        if not isinstance(cur, Mapping) or part not in cur:
            raise KeyError(path)
        cur = cur[part]
    return cur


def _validate_protected_route_invariants(canonical_zip: str | Path, candidate_zip: str | Path) -> list[dict[str, Any]]:
    canonical_state = _read_bundle_json(canonical_zip, "state_contract.json")
    rules = canonical_state.get("PROMOTION_PROTECTED_ROUTE_INVARIANTS") or []
    if not rules:
        return []
    candidate_reg = _read_bundle_json(candidate_zip, "engine_registry.json")
    checked=[]
    for rule in rules:
        if not isinstance(rule, Mapping):
            raise PromotionFenceError("PROMOTION_HALT:PROTECTED_ROUTE_RULE_INVALID")
        sport=str(rule.get("SPORT") or "").upper(); mode=str(rule.get("MODE") or "").upper(); path=str(rule.get("PATH") or "")
        expected=rule.get("VALUE")
        if not sport or not mode or not path:
            raise PromotionFenceError("PROMOTION_HALT:PROTECTED_ROUTE_RULE_INCOMPLETE")
        entry=_route_entry(candidate_reg,sport,mode)
        try:
            actual=_dotted_value(entry,path)
        except KeyError as exc:
            raise PromotionFenceError(f"PROMOTION_HALT:PROTECTED_ROUTE_AUTHORITY_DROPPED:{sport}:{mode}:{path}:MISSING") from exc
        if actual != expected:
            raise PromotionFenceError(f"PROMOTION_HALT:PROTECTED_ROUTE_AUTHORITY_DRIFT:{sport}:{mode}:{path}:{actual!r}!={expected!r}")
        checked.append({"SPORT":sport,"MODE":mode,"PATH":path,"VALUE":expected})
    return checked

def _load_scan(scan: str | Path | Mapping[str, Any]) -> dict[str, Any]:
    if isinstance(scan, Mapping):
        obj = dict(scan)
    else:
        obj = json.loads(Path(scan).read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise PromotionFenceError("PROMOTION_HALT:VERSION_SCAN_RECEIPT_INVALID")
    return obj


def validate_version_scan(scan: str | Path | Mapping[str, Any], candidate_version: str) -> dict[str, Any]:
    obj = _load_scan(scan)
    if str(obj.get("STATUS")) != "PASS":
        raise PromotionFenceError("PROMOTION_HALT:VERSION_SCAN_PASS_REQUIRED")
    if str(obj.get("CANDIDATE_VERSION")) != str(candidate_version):
        raise PromotionFenceError(
            f"PROMOTION_HALT:VERSION_SCAN_CANDIDATE_MISMATCH:{obj.get('CANDIDATE_VERSION')}!={candidate_version}"
        )
    exact_title = f"{ARCHIVE_PREFIX}{candidate_version}.zip"
    observed_titles = [str(x) for x in obj.get("OBSERVED_TITLES", [])]
    observed_versions = [str(x) for x in obj.get("OBSERVED_STATE_VERSIONS", [])]
    available = bool(obj.get("CANDIDATE_VERSION_AVAILABLE"))
    if exact_title in observed_titles or str(candidate_version) in observed_versions or not available:
        raise PromotionFenceError(f"PROMOTION_HALT:STATE_VERSION_ALREADY_EXISTS:{candidate_version}")
    if not bool(obj.get("DRIVE_ARCHIVE_SCAN_PERFORMED")):
        raise PromotionFenceError("PROMOTION_HALT:DRIVE_ARCHIVE_SCAN_REQUIRED")
    return obj


@dataclass(frozen=True)
class FenceReceipt:
    PATCH_ID: str
    SCHEMA_VERSION: str
    STATUS: str
    CANONICAL_DRIVE_FILE_ID: str
    CANONICAL_TITLE: str
    CANONICAL_STATE_VERSION: str
    CANONICAL_BYTES_SHA256: str
    CANDIDATE_STATE_VERSION: str
    CANDIDATE_PARENT_STATE_VERSION: str
    CANDIDATE_PARENT_BUNDLE_SHA256: str
    CANDIDATE_REBASE_SOURCE_SHA256: str
    CANDIDATE_BYTES_SHA256: str
    EXACT_PARENT_VERSION_MATCH: bool
    EXACT_PARENT_HASH_MATCH: bool
    CANDIDATE_VERSION_STRICTLY_NEWER: bool
    VERSION_UNUSED_AT_PREFLIGHT: bool
    DIRECT_WRITE_WITHOUT_RECEIPT_ALLOWED: bool = False
    STALE_BRANCH_OVERWRITE_ALLOWED: bool = False
    STATE_VERSION_REUSE_ALLOWED: bool = False


def preflight_candidate(
    canonical_zip: str | Path,
    candidate_zip: str | Path,
    version_scan_receipt: str | Path | Mapping[str, Any],
    *,
    canonical_drive_file_id: str = CANONICAL_DRIVE_FILE_ID,
) -> dict[str, Any]:
    current = _metadata(canonical_zip)
    candidate = _metadata(candidate_zip)
    validate_version_scan(version_scan_receipt, candidate["STATE_VERSION"])
    protected_route_invariants = _validate_protected_route_invariants(canonical_zip, candidate_zip)

    exact_parent_version = candidate["PARENT_STATE_VERSION"] == current["STATE_VERSION"]
    exact_parent_hash = (
        candidate["PARENT_BUNDLE_SHA256"] == current["BYTES_SHA256"]
        and candidate["CANONICAL_REBASE_SOURCE_SHA256"] == current["BYTES_SHA256"]
    )
    newer = _version_tuple(candidate["STATE_VERSION"]) > _version_tuple(current["STATE_VERSION"])
    if not exact_parent_version:
        raise PromotionFenceError(
            "PROMOTION_HALT:STALE_BRANCH_PARENT_VERSION:"
            f"candidate_parent={candidate['PARENT_STATE_VERSION']}:canonical={current['STATE_VERSION']}"
        )
    if not exact_parent_hash:
        raise PromotionFenceError(
            "PROMOTION_HALT:STALE_BRANCH_PARENT_HASH:"
            f"candidate_parent_sha={candidate['PARENT_BUNDLE_SHA256']}:"
            f"candidate_rebase_sha={candidate['CANONICAL_REBASE_SOURCE_SHA256']}:"
            f"canonical_sha={current['BYTES_SHA256']}"
        )
    if not newer:
        raise PromotionFenceError(
            "PROMOTION_HALT:CANDIDATE_VERSION_NOT_NEWER:"
            f"candidate={candidate['STATE_VERSION']}:canonical={current['STATE_VERSION']}"
        )
    receipt = asdict(FenceReceipt(
        PATCH_ID=PATCH_ID,
        SCHEMA_VERSION=SCHEMA_VERSION,
        STATUS="PASS",
        CANONICAL_DRIVE_FILE_ID=str(canonical_drive_file_id),
        CANONICAL_TITLE=CANONICAL_TITLE,
        CANONICAL_STATE_VERSION=current["STATE_VERSION"],
        CANONICAL_BYTES_SHA256=current["BYTES_SHA256"],
        CANDIDATE_STATE_VERSION=candidate["STATE_VERSION"],
        CANDIDATE_PARENT_STATE_VERSION=candidate["PARENT_STATE_VERSION"],
        CANDIDATE_PARENT_BUNDLE_SHA256=candidate["PARENT_BUNDLE_SHA256"],
        CANDIDATE_REBASE_SOURCE_SHA256=candidate["CANONICAL_REBASE_SOURCE_SHA256"],
        CANDIDATE_BYTES_SHA256=candidate["BYTES_SHA256"],
        EXACT_PARENT_VERSION_MATCH=True,
        EXACT_PARENT_HASH_MATCH=True,
        CANDIDATE_VERSION_STRICTLY_NEWER=True,
        VERSION_UNUSED_AT_PREFLIGHT=True,
    ))
    receipt["PROTECTED_ROUTE_INVARIANTS_CHECK"] = "PASS"
    receipt["PROTECTED_ROUTE_INVARIANTS"] = protected_route_invariants
    return receipt


def precommit_recheck(
    fresh_canonical_zip: str | Path,
    candidate_zip: str | Path,
    preflight_receipt: Mapping[str, Any],
    fresh_version_scan_receipt: str | Path | Mapping[str, Any],
) -> dict[str, Any]:
    if str(preflight_receipt.get("STATUS")) != "PASS" or str(preflight_receipt.get("PATCH_ID")) != PATCH_ID:
        raise PromotionFenceError("PROMOTION_HALT:VALID_PREFLIGHT_RECEIPT_REQUIRED")
    candidate_version = str(preflight_receipt.get("CANDIDATE_STATE_VERSION"))
    validate_version_scan(fresh_version_scan_receipt, candidate_version)
    fresh = _metadata(fresh_canonical_zip)
    candidate_sha = _sha(candidate_zip)
    if fresh["STATE_VERSION"] != str(preflight_receipt.get("CANONICAL_STATE_VERSION")):
        raise PromotionFenceError(
            "PROMOTION_HALT:CANONICAL_VERSION_DRIFT_AFTER_PREFLIGHT:"
            f"was={preflight_receipt.get('CANONICAL_STATE_VERSION')}:now={fresh['STATE_VERSION']}"
        )
    if fresh["BYTES_SHA256"] != str(preflight_receipt.get("CANONICAL_BYTES_SHA256")):
        raise PromotionFenceError(
            "PROMOTION_HALT:CANONICAL_BYTES_DRIFT_AFTER_PREFLIGHT:"
            f"was={preflight_receipt.get('CANONICAL_BYTES_SHA256')}:now={fresh['BYTES_SHA256']}"
        )
    if candidate_sha != str(preflight_receipt.get("CANDIDATE_BYTES_SHA256")):
        raise PromotionFenceError(
            "PROMOTION_HALT:CANDIDATE_BYTES_CHANGED_AFTER_PREFLIGHT:"
            f"was={preflight_receipt.get('CANDIDATE_BYTES_SHA256')}:now={candidate_sha}"
        )
    return {
        **dict(preflight_receipt),
        "PRECOMMIT_RECHECK": "PASS",
        "VERSION_UNUSED_AT_PRECOMMIT": True,
        "FRESH_CANONICAL_STATE_VERSION": fresh["STATE_VERSION"],
        "FRESH_CANONICAL_BYTES_SHA256": fresh["BYTES_SHA256"],
        "WRITE_AUTHORIZED_FOR_EXACT_CANDIDATE_SHA256": candidate_sha,
    }


def verify_postwrite_readback(readback_zip: str | Path, precommit_receipt: Mapping[str, Any]) -> dict[str, Any]:
    if str(precommit_receipt.get("PRECOMMIT_RECHECK")) != "PASS":
        raise PromotionFenceError("PROMOTION_HALT:PRECOMMIT_RECHECK_REQUIRED")
    rb = _metadata(readback_zip)
    expected_sha = str(precommit_receipt.get("CANDIDATE_BYTES_SHA256"))
    expected_version = str(precommit_receipt.get("CANDIDATE_STATE_VERSION"))
    if rb["BYTES_SHA256"] != expected_sha:
        raise PromotionFenceError(
            f"PROMOTION_HALT:DRIVE_READBACK_SHA_MISMATCH:expected={expected_sha}:actual={rb['BYTES_SHA256']}"
        )
    if rb["STATE_VERSION"] != expected_version:
        raise PromotionFenceError(
            f"PROMOTION_HALT:DRIVE_READBACK_VERSION_MISMATCH:expected={expected_version}:actual={rb['STATE_VERSION']}"
        )
    return {
        **dict(precommit_receipt),
        "POSTWRITE_READBACK": "PASS",
        "READBACK_STATE_VERSION": rb["STATE_VERSION"],
        "READBACK_BYTES_SHA256": rb["BYTES_SHA256"],
    }


def _write_json(path: str | Path, obj: Mapping[str, Any]) -> None:
    Path(path).write_text(json.dumps(dict(obj), indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("preflight")
    p.add_argument("canonical_zip"); p.add_argument("candidate_zip"); p.add_argument("version_scan"); p.add_argument("receipt")
    c = sub.add_parser("precommit")
    c.add_argument("fresh_canonical_zip"); c.add_argument("candidate_zip"); c.add_argument("preflight_receipt"); c.add_argument("fresh_version_scan"); c.add_argument("receipt")
    r = sub.add_parser("readback")
    r.add_argument("readback_zip"); r.add_argument("precommit_receipt"); r.add_argument("receipt")
    args = ap.parse_args()
    if args.cmd == "preflight":
        out = preflight_candidate(args.canonical_zip, args.candidate_zip, args.version_scan)
    elif args.cmd == "precommit":
        prior = json.loads(Path(args.preflight_receipt).read_text(encoding="utf-8"))
        out = precommit_recheck(args.fresh_canonical_zip, args.candidate_zip, prior, args.fresh_version_scan)
    else:
        prior = json.loads(Path(args.precommit_receipt).read_text(encoding="utf-8"))
        out = verify_postwrite_readback(args.readback_zip, prior)
    _write_json(args.receipt, out)
    print(json.dumps(out, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
