#!/usr/bin/env python3
from __future__ import annotations
import ast, importlib, hashlib, io, json, os, pickle, sqlite3, sys, time, types
from pathlib import Path
from collections import Counter, defaultdict
from functools import lru_cache
from dataclasses import asdict
from typing import Any, Iterable, Mapping, Sequence
import csv, gc, faulthandler, heapq, itertools, math, zipfile
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix

PATCH_ID = 'MLB_CLASSIC_STAGE0_STATELESS_MICROCHUNK_PLUS_CROSS_PATTERN_BLOCK_RESUME_v1'
SRC = Path(os.environ['APEX_INTERNAL_SPLIT_SOURCE']).resolve()
STAGE_NAME = os.environ.get('APEX_INTERNAL_SPLIT_STAGE_NAME','UNNAMED')
START = int(os.environ['APEX_INTERNAL_SPLIT_START'])
END = int(os.environ['APEX_INTERNAL_SPLIT_END'])
CK_IN = os.environ.get('APEX_INTERNAL_SPLIT_CHECKPOINT_IN','')
CK_OUT = os.environ.get('APEX_INTERNAL_SPLIT_CHECKPOINT_OUT','')
FINAL = os.environ.get('APEX_INTERNAL_SPLIT_FINAL','0') == '1'
EXPECTED_SHA256 = os.environ.get('APEX_INTERNAL_SPLIT_SOURCE_SHA256','').strip().lower()

if EXPECTED_SHA256:
    actual = hashlib.sha256(SRC.read_bytes()).hexdigest()
    if actual != EXPECTED_SHA256:
        raise RuntimeError(f'RUN_INVALID:SOURCE_SHA256_MISMATCH:{actual}:{EXPECTED_SHA256}')


def _pin_active_engine_imports() -> tuple[Path, Path]:
    active_engine_dir = SRC.parent.resolve()
    active_common_dir = SRC.resolve().parents[1] / 'common'
    active_state_root = SRC.resolve().parents[2]
    kept=[]
    for entry in sys.path:
        s=str(entry)
        if '/apex_state_1_33_' in s and not s.startswith(str(active_state_root)):
            continue
        kept.append(entry)
    sys.path[:] = [str(active_engine_dir), str(active_common_dir)] + [x for x in kept if str(x) not in {str(active_engine_dir),str(active_common_dir)}]
    for name,mod in list(sys.modules.items()):
        f=getattr(mod,'__file__',None)
        if not f:
            continue
        sf=str(f)
        if '/apex_state_1_33_' in sf and not sf.startswith(str(active_state_root)):
            sys.modules.pop(name,None)
    return active_engine_dir, active_common_dir


def _active_output_dir() -> Path:
    return Path(os.environ.get('APEX_OUTPUT_DIR','/mnt/data')).resolve()


def _rebind_runtime_authority(ns: dict[str, Any]) -> None:
    # Checkpoint payloads carry data only. Runtime paths remain owned by the
    # currently active production invocation.
    ns['OUT'] = _active_output_dir()


def hydrate(ns: dict[str, Any]) -> None:
    engine_dir, common_dir = _pin_active_engine_imports()
    handoff_dir = engine_dir
    ns['ENGINE_DIR']=engine_dir
    ns['HANDOFF_DIR']=handoff_dir
    ns['COMMON_ENGINE_DIR']=common_dir
    aliases = {
        'mlb_phase2_blocks':'mlb_phase2_strict_block_resumption_v1',
        'phase1_sync':'global_phase1_calibration_hybrid_sync_v1',
        'profile_mod':'global_dfs_core_closure_profile_calibration_v2',
        'classic_mod':'mlb_classic_small_slate_distributed_geometry_v2',
        'sibling_closure_mod':'mlb_classic_deterministic_family_sibling_closure_v1',
        'cross_pattern_closure_mod':'mlb_classic_cross_pattern_family_sibling_closure_v3',
        'adaptive_family_door_mod':'mlb_classic_adaptive_family_door_recall_v1',
        'adjacent_431_closure_mod':'mlb_classic_5_2_1_to_4_3_1_adjacent_family_closure_v1',
        'elite_431_recall_mod':'mlb_classic_431_elite_assembly_recall_v1',
        'macro_spine_mod':'mlb_classic_deterministic_macro_spine_recall_v1',
        'rank_lattice_521_mod':'mlb_classic_fast_521_distributed_rank_lattice_v1',
        'spine_closure_mod':'mlb_classic_five_stack_salary_complement_spine_closure_v1',
        'phase_identity_mod':'mlb_classic_phase_identity_contract_v1',
        'lattice_fast':'mlb_exact_lattice_compatibility_v1',
        'selector_mod':'global_code_ai_hybrid_selector_authority_v1',
        'advisor_selector':'mlb_advisor_tail_selector_v1',
        'classic_historical_selector':'mlb_classic_historical_consensus_selector_v1',
        'noninferior_portfolio_selector':'mlb_classic_noninferior_trophy_portfolio_selector_v1',
        'common_world_portfolio_selector':'mlb_classic_multi_event_common_world_marginal_portfolio_v1',
        'orientation_sibling_mod':'mlb_classic_orientation_protected_sibling_inversion_v1',
        'rs44_satellite_mod':'mlb_classic_rs44_same_game_deep_rep_satellite_v1',
        'rs44_v7_mod':'mlb_classic_blind_low_total_anchored_44_stratified_coverage_v7',
        'same_world_system':'apex_same_world_championship_system_v1',
        'rnwd_authority':'mlb_right_neighborhood_wrong_door_authority_v1',
        'attackable_pa_mod':'mlb_hitter_attackable_pa_adjustment_v1',
        'handoff_contract':'handoff_contract',
    }
    for alias,name in aliases.items():
        ns[alias] = importlib.import_module(name)
    exact = importlib.import_module('apex_exact_tail_metric_kernel_v1')
    ns['mlb_exact_metrics'] = exact.mlb_exact_metrics
    fk = importlib.import_module('mlb_fast_kernels_v1_20')
    ns['fast_kernel_runtime_receipt']=fk.runtime_receipt
    ns['score_lineup_block_numba']=fk.score_lineup_block_numba
    ns['score_lineup_block_numba_serial']=fk.score_lineup_block_numba_serial
    ns['_parent_noninferior_selector_api']=ns['noninferior_portfolio_selector'].select_portfolio
    ns.update({
        'csv':csv,'gc':gc,'faulthandler':faulthandler,'hashlib':hashlib,'heapq':heapq,'itertools':itertools,
        'json':json,'math':math,'os':os,'sys':sys,'time':time,'zipfile':zipfile,'sqlite3':sqlite3,'pickle':pickle,
        'np':np,'Bounds':Bounds,'LinearConstraint':LinearConstraint,'milp':milp,'csr_matrix':csr_matrix,
        'Counter':Counter,'defaultdict':defaultdict,'asdict':asdict,'lru_cache':lru_cache,'Path':Path,
        'Any':Any,'Iterable':Iterable,'Mapping':Mapping,'Sequence':Sequence,
    })
    tree=ast.parse(SRC.read_text(encoding='utf-8'))
    f_nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    mod=ast.Module(body=f_nodes,type_ignores=[]); ast.fix_missing_locations(mod)
    exec(compile(mod,str(SRC),'exec'),ns,ns)
    if '_strategy_features_receipt' in ns:
        ns['strategy_features']=types.SimpleNamespace(receipt=ns['_strategy_features_receipt'])
    # Compatibility bridge for memory-safe selector stages. The raw runtime no
    # longer materializes candidate-sized Top-0.1 bit copies; expose a lightweight
    # indexed handle for legacy downstream selector calls without copying rows.
    if '_selector_top01_bits' not in ns and 'base_top01_bits' in ns and '_selector_short_indices' in ns:
        ns['_selector_top01_bits'] = (
            'APEX_INDEXED_WORLD_BITS_V1',
            ns['base_top01_bits'],
            np.asarray(ns['_selector_short_indices'], dtype=np.int64),
        )


_DEAD_AFTER_ADAPTIVE_BUBBLE = (
    'frontier_history_matrix','lineup_id_to_history_row','phase3_scores',
    'field_lines','field_scores','field_candidate_indices','field_sim_indices',
    'batch_surface','current_lines','base_bubble_lines',
)

def prune_dead_checkpoint_state(ns: dict[str, Any], stage_name: str) -> tuple[str, ...]:
    removed=[]
    if str(stage_name)=='PHASE3_ADAPTIVE_BUBBLE':
        for key in _DEAD_AFTER_ADAPTIVE_BUBBLE:
            if key in ns:
                ns.pop(key,None); removed.append(key)
    return tuple(removed)

def sha256_file(path: Path, block_bytes: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        while True:
            block = f.read(block_bytes)
            if not block:
                break
            h.update(block)
    return h.hexdigest()

def _fsync_dir(path: Path) -> None:
    flags=getattr(os,'O_DIRECTORY',0) | os.O_RDONLY
    fd=os.open(str(path),flags)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def dump_state(ns: dict[str, Any], path: Path) -> None:
    data: dict[str, Any] = {}
    for k,v in ns.items():
        if k.startswith('__') or isinstance(v,types.ModuleType) or callable(v) or k.startswith('_strategy_'):
            continue
        if k == 'strategy_features':
            try: data['_strategy_features_receipt']=dict(v.receipt)
            except Exception: pass
            continue
        if isinstance(v,io.IOBase): continue
        try: pickle.dumps(v,protocol=5)
        except Exception: continue
        data[k]=v
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('wb') as f:
        pickle.dump(data,f,protocol=5); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)
    _fsync_dir(path.parent)

if CK_IN:
    # Checkpoints carry data, never code authority. Pin active module roots before
    # unpickling so cross-version resume resolves classes from the current engine.
    _active_engine_dir,_active_common_dir=_pin_active_engine_imports()
    os.environ['APEX_ENGINE_DIR']=str(_active_engine_dir)
    os.environ['APEX_HANDOFF_DIR']=str(_active_engine_dir)
    with open(CK_IN,'rb') as f: ns=pickle.load(f)
    ns['ENGINE_DIR']=_active_engine_dir
    ns['HANDOFF_DIR']=_active_engine_dir
    ns['COMMON_ENGINE_DIR']=_active_common_dir
    # Cross-version checkpoints carry data, not runtime path authority. Always
    # rebind output location to the active production invocation before hydrate.
    _rebind_runtime_authority(ns)
    ns['__name__']='__main__'; ns['__file__']=str(SRC); ns['__package__']=None; ns['__cached__']=None
    hydrate(ns)
    # Reassert active authority after hydration so stale checkpoint values cannot
    # regain output-path authority. Required aliases must come from active code.
    _rebind_runtime_authority(ns)
    if 'rs44_v7_mod' not in ns or not isinstance(ns['rs44_v7_mod'], types.ModuleType):
        raise RuntimeError('RUN_INVALID:RS44_V7_ACTIVE_MODULE_HYDRATION_MISSING')
    if Path(ns['OUT']).resolve() != _active_output_dir():
        raise RuntimeError('RUN_INVALID:CHECKPOINT_OUTPUT_AUTHORITY_REBIND_FAILED')
else:
    ns={'__name__':'__main__','__file__':str(SRC),'__package__':None,'__cached__':None}

lines=SRC.read_text(encoding='utf-8').splitlines(keepends=True)
if START < 1 or END < START or END > len(lines):
    raise RuntimeError(f'RUN_INVALID:INVALID_INTERNAL_STAGE_BOUNDS:{START}:{END}:{len(lines)}')
code=''.join(lines[START-1:END])
t0=time.time()
try:
    _loop_kind=os.environ.get('APEX_INTERNAL_LOOP_KIND')
    if _loop_kind == 'STAGE0_BASE_PATTERN_BIRTH':
        start_i=int(os.environ.get('APEX_INTERNAL_PATTERN_START','0'))
        end_i=int(os.environ.get('APEX_INTERNAL_PATTERN_END','0'))
        tree=ast.parse(code)
        loops=[n for n in tree.body if isinstance(n,ast.For)]
        if len(loops)!=1:
            raise RuntimeError(f'RUN_INVALID:STAGE0_PATTERN_LOOP_NOT_UNIQUE:{len(loops)}')
        loop=loops[0]
        loop.iter=ast.Subscript(value=ast.Name(id='PATTERNS',ctx=ast.Load()),slice=ast.Slice(lower=ast.Constant(start_i),upper=ast.Constant(end_i)),ctx=ast.Load())
        ast.fix_missing_locations(tree)
        exec(compile(tree,str(SRC),'exec'),ns,ns)
    elif _loop_kind == 'CROSS_PATTERN_PARENT_BLOCK':
        start_i=int(os.environ.get('APEX_INTERNAL_CROSS_PARENT_START','0'))
        end_i=int(os.environ.get('APEX_INTERNAL_CROSS_PARENT_END','0'))
        block_i=int(os.environ.get('APEX_INTERNAL_CROSS_BLOCK_INDEX','0'))
        tree=ast.parse(code)
        loops=[n for n in tree.body if isinstance(n,ast.For)]
        if len(loops)!=1:
            raise RuntimeError(f'RUN_INVALID:CROSS_PATTERN_PARENT_LOOP_NOT_UNIQUE:{len(loops)}')
        loop=loops[0]
        # Execute one exact source block. Only the outer block iterable changes;
        # the source body, candidate materialization, counters, and commit remain unchanged.
        loop.iter=ast.List(elts=[ast.Tuple(elts=[ast.Constant(block_i),ast.Constant(start_i),ast.Constant(end_i)],ctx=ast.Load())],ctx=ast.Load())
        ast.fix_missing_locations(tree)
        exec(compile(tree,str(SRC),'exec'),ns,ns)
    elif _loop_kind == 'RAW_SELECTOR_PACKET':
        start_i=int(os.environ.get('APEX_INTERNAL_PACKET_START','0'))
        end_i=int(os.environ.get('APEX_INTERNAL_PACKET_END','0'))
        tree=ast.parse(code)
        loops=[n for n in tree.body if isinstance(n,ast.For)]
        if len(loops)!=1:
            raise RuntimeError(f'RUN_INVALID:RAW_SELECTOR_PACKET_LOOP_NOT_UNIQUE:{len(loops)}')
        loop=loops[0]
        # Preserve the source loop body exactly; only replace its iterable with a
        # deterministic contiguous slice and global enumerate start.
        loop.iter=ast.Call(
            func=ast.Name(id='enumerate',ctx=ast.Load()),
            args=[ast.Subscript(value=ast.Name(id='handoff_indices',ctx=ast.Load()),slice=ast.Slice(lower=ast.Constant(start_i),upper=ast.Constant(end_i)),ctx=ast.Load())],
            keywords=[ast.keyword(arg='start',value=ast.Constant(start_i))],
        )
        ast.fix_missing_locations(tree)
        exec(compile(tree,str(SRC),'exec'),ns,ns)
    else:
        exec(compile(code,str(SRC),'exec'),ns,ns)
except SystemExit as exc:
    if int(exc.code or 0) == 0 and FINAL:
        raise
    raise
sec=time.time()-t0
print(json.dumps({'RUN_STATE':'INTERNAL_CHUNK_EXECUTED','PATCH_ID':PATCH_ID,'STAGE':STAGE_NAME,'START':START,'END':END,'SECONDS':round(sec,3)}),file=sys.stderr,flush=True)
if not FINAL:
    if not CK_OUT: raise RuntimeError('RUN_INVALID:INTERNAL_CHECKPOINT_OUT_MISSING')
    _dead_removed=prune_dead_checkpoint_state(ns,STAGE_NAME)
    if _dead_removed:
        print(json.dumps({'RUN_STATE':'INTERNAL_DEAD_STATE_PRUNED','PATCH_ID':PATCH_ID,'STAGE':STAGE_NAME,'REMOVED':list(_dead_removed)}),file=sys.stderr,flush=True)
    out=Path(CK_OUT); t1=time.time(); dump_state(ns,out)
    digest=sha256_file(out)
    print(json.dumps({'RUN_STATE':'INTERNAL_CHECKPOINT_COMMITTED','PATCH_ID':PATCH_ID,'STAGE':STAGE_NAME,'CHECKPOINT':str(out),'CHECKPOINT_SHA256':digest,'BYTES':out.stat().st_size,'SECONDS':round(time.time()-t1,3)}),file=sys.stderr,flush=True)
