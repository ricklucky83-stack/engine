from __future__ import annotations

from dataclasses import dataclass, asdict
from math import ceil
from typing import Iterable, Dict, Any

try:
    from scipy.stats import beta
except Exception:  # fail closed if interval cannot be computed
    beta = None

PATCH_ID = "ABSOLUTE_TAIL_CALIBRATION_GATE_v1"

@dataclass(frozen=True)
class TailSupportResult:
    actual_rank: int
    field_size: int
    exceed_count: int
    trials: int
    observed_tail_rate: float
    reference_frequency: float
    materiality_factor: float
    support_floor: float
    ci_level: float
    ci_lower: float
    ci_upper: float
    support_status: str
    failure_class: str


def clopper_pearson(k: int, n: int, level: float = 0.95) -> tuple[float, float]:
    if beta is None:
        raise RuntimeError("SCIPY_REQUIRED_FOR_EXACT_BINOMIAL_INTERVAL")
    if n <= 0 or k < 0 or k > n:
        raise ValueError("INVALID_BINOMIAL_COUNTS")
    alpha = 1.0 - float(level)
    lo = 0.0 if k == 0 else float(beta.ppf(alpha / 2.0, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(1.0 - alpha / 2.0, k + 1, n - k))
    return lo, hi


def classify_tail_support(
    *,
    actual_rank: int,
    field_size: int,
    exceed_count: int,
    trials: int,
    ci_level: float = 0.95,
    materiality_factor: float = 4.0,
) -> TailSupportResult:
    """Post-lock calibration classifier.

    This gate does NOT require an ex-post elite lineup to have ranked highly ex ante.
    It asks only whether the simulator assigns materially insufficient probability mass
    to reaching the realized lineup score.

    Reference frequency is actual_rank / field_size. Because contest rank is not the
    same estimand as a lineup's self-score exceedance probability, the gate uses a
    conservative materiality factor. Calibration failure is declared only when the
    *upper* exact-binomial confidence bound is below reference_frequency/factor.
    """
    if actual_rank <= 0 or field_size <= 0 or actual_rank > field_size:
        raise ValueError("INVALID_CONTEST_RANK_OR_FIELD")
    if materiality_factor < 1.0:
        raise ValueError("MATERIALITY_FACTOR_MUST_BE_AT_LEAST_1")
    lo, hi = clopper_pearson(int(exceed_count), int(trials), ci_level)
    obs = float(exceed_count) / float(trials)
    ref = float(actual_rank) / float(field_size)
    floor = ref / float(materiality_factor)
    if hi < floor:
        status = "OUTSIDE_CALIBRATED_TAIL_SUPPORT"
        failure = "SIMULATION_CALIBRATION_FAILURE"
    else:
        status = "INSIDE_CALIBRATED_TAIL_SUPPORT"
        failure = "VARIANCE_NO_STRUCTURAL_FAILURE"
    return TailSupportResult(
        actual_rank=int(actual_rank), field_size=int(field_size), exceed_count=int(exceed_count),
        trials=int(trials), observed_tail_rate=obs, reference_frequency=ref,
        materiality_factor=float(materiality_factor), support_floor=floor,
        ci_level=float(ci_level), ci_lower=lo, ci_upper=hi,
        support_status=status, failure_class=failure,
    )


def classify_elite_set(rows: Iterable[Dict[str, Any]], *, field_size: int,
                       ci_level: float = 0.95, materiality_factor: float = 4.0) -> Dict[str, Any]:
    results = []
    for row in rows:
        r = classify_tail_support(
            actual_rank=int(row["actual_rank"]), field_size=int(field_size),
            exceed_count=int(row["exceed_count"]), trials=int(row["trials"]),
            ci_level=ci_level, materiality_factor=materiality_factor,
        )
        d = asdict(r)
        if "lineup_id" in row:
            d["lineup_id"] = row["lineup_id"]
        if "actual_score" in row:
            d["actual_score"] = float(row["actual_score"])
        results.append(d)
    any_fail = any(x["failure_class"] == "SIMULATION_CALIBRATION_FAILURE" for x in results)
    return {
        "PATCH_ID": PATCH_ID,
        "FIELD_SIZE": int(field_size),
        "CI_LEVEL": float(ci_level),
        "MATERIALITY_FACTOR": float(materiality_factor),
        "ROWS": results,
        "ELITE_ROWS_TESTED": len(results),
        "OUTSIDE_SUPPORT_COUNT": sum(x["support_status"] == "OUTSIDE_CALIBRATED_TAIL_SUPPORT" for x in results),
        "PRIMARY_FAILURE": "SIMULATION_CALIBRATION_FAILURE" if any_fail else "VARIANCE_NO_STRUCTURAL_FAILURE",
    }
