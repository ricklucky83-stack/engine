from __future__ import annotations

"""Market-independent outcome-regime kernel.

Market prices may initialize a weak prior, but market spread/total values are never
passed into state-transition logic.  Team-sport transitions consume only the live
state (time remaining, score margin, possession) plus frozen model/latent factors.
The module also exposes a sport-level contract receipt for engines that have not yet
implemented a native transition adapter.
"""

from dataclasses import dataclass
import hashlib
import json
import math
from typing import Any, Mapping, Sequence

import numpy as np
from engines.common import apex_global_side_selection_accuracy_v1 as side_accuracy

PATCH_ID = "APEX_GLOBAL_MARKET_INDEPENDENT_OUTCOME_REGIME_KERNEL_v1"
DOCTRINE_ID = PATCH_ID
CONTRACT_VERSION = "1.0"
MAX_MARKET_PRIOR_WEIGHT = 0.30
TEAM_SPORTS = {"NFL", "CFB", "CBB", "NBA", "WNBA", "NHL", "MLB"}
INDIVIDUAL_SPORTS = {"TENNIS", "PGA", "GOLF", "MMA", "UFC"}


def stable_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def _num(x: Any, default: float = math.nan) -> float:
    try:
        if x is None:
            return default
        if isinstance(x, str):
            x = x.replace("%", "").replace(",", "").strip()
            if x.lower() in {"", "-", "nan", "none", "null"}:
                return default
        v = float(x)
        return v if math.isfinite(v) else default
    except Exception:
        return default


def _student_t(rng: np.random.Generator, size: int, df: float = 5.0) -> np.ndarray:
    z = rng.standard_normal(size)
    chi = rng.chisquare(df, size=size)
    return z / np.sqrt(np.maximum(chi / df, 1e-8))


def _corr_t_pair(rng: np.random.Generator, size: int, rho: float, df: float = 5.0) -> tuple[np.ndarray, np.ndarray]:
    a = _student_t(rng, size, df)
    b = _student_t(rng, size, df)
    r = float(np.clip(rho, -0.95, 0.95))
    return a, r * a + math.sqrt(max(1e-8, 1.0 - r * r)) * b


@dataclass(frozen=True)
class FootballRegimes:
    teams: tuple[str, str]
    scores: np.ndarray             # (2, trials)
    pass_script: np.ndarray        # (2, trials), centered around 0
    rush_script: np.ndarray        # (2, trials), centered around 0
    pace_script: np.ndarray        # (trials,), centered around 0
    offense_latent: np.ndarray     # (2, trials)
    defense_latent: np.ndarray     # (2, trials)
    receipt: dict[str, Any]


def _market_points_for_two_teams(
    team0: str,
    team1: str,
    market_total: float | None,
    market_spread_team0: float | None,
) -> tuple[float, float] | None:
    total = _num(market_total)
    spread0 = _num(market_spread_team0)
    if not (math.isfinite(total) and total > 0 and math.isfinite(spread0)):
        return None
    # Spread is team0 line: -5 means team0 favored by five.
    margin0 = -spread0
    p0 = max(3.0, 0.5 * (total + margin0))
    p1 = max(3.0, total - p0)
    return p0, p1


def _football_transition_probabilities(
    *,
    q: np.ndarray,
    t_rem: np.ndarray,
    margin_poss: np.ndarray,
    base_td: np.ndarray,
    base_fg: np.ndarray,
    offense: np.ndarray,
    defense: np.ndarray,
    pace: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """State transition kernel. Intentionally has no spread/total parameters."""
    late = t_rem <= 900.0
    trailing = margin_poss < -3.0
    leading = margin_poss > 7.0
    competitive = np.abs(margin_poss) <= 7.0
    pass_bias = 0.18 * (late & trailing) - 0.12 * (late & leading) + 0.05 * competitive + 0.035 * pace
    drive_speed = np.clip(1.0 + 0.20 * (late & trailing) - 0.14 * (late & leading) + 0.10 * pace, 0.65, 1.45)
    td = np.clip(base_td + 0.055 * offense - 0.045 * defense + 0.018 * pace + 0.015 * (late & trailing), 0.035, 0.58)
    fg = np.clip(base_fg + 0.012 * offense - 0.008 * defense - 0.006 * (late & trailing), 0.025, 0.30)
    turnover = np.clip(0.105 - 0.018 * offense + 0.020 * defense + 0.012 * (late & trailing), 0.035, 0.25)
    return td, fg, turnover, pass_bias, drive_speed


def simulate_football_regimes(
    *,
    teams: Sequence[str],
    model_points: Sequence[float],
    trials: int,
    seed: int,
    market_total: float | None = None,
    market_spread_team0: float | None = None,
    market_prior_weight: float = 0.25,
    sport: str = "CFB",
    mode: str = "REGIME_KERNEL",
) -> FootballRegimes:
    if len(teams) != 2 or len(model_points) != 2:
        raise ValueError("football regime kernel requires exactly two teams")
    if trials <= 0:
        raise ValueError("trials must be positive")
    w = float(np.clip(market_prior_weight, 0.0, MAX_MARKET_PRIOR_WEIGHT))
    mp = np.maximum(np.asarray(model_points, dtype=np.float64), 3.0)
    market = _market_points_for_two_teams(str(teams[0]), str(teams[1]), market_total, market_spread_team0)
    if market is None:
        anchor = mp.copy(); w_used = 0.0
    else:
        anchor = (1.0 - w) * mp + w * np.asarray(market, dtype=np.float64); w_used = w

    rng = np.random.default_rng(int(seed))
    common, pace = _corr_t_pair(rng, trials, rho=0.25, df=4.5)
    off0, off1 = _corr_t_pair(rng, trials, rho=-0.08, df=4.5)
    def0, def1 = _corr_t_pair(rng, trials, rho=-0.05, df=5.0)
    off = np.vstack([off0, off1]).astype(np.float32)
    deff = np.vstack([def0, def1]).astype(np.float32)
    # Shared game environment is intentionally fat-tailed.
    off[0] += (0.24 * common).astype(np.float32); off[1] += (0.24 * common).astype(np.float32)

    # Initial scoring rates. Market has ended here; no line value enters transitions.
    expected_drives = 11.5
    pts_per_drive = np.clip(anchor / expected_drives, 0.9, 3.5)
    base_td = np.clip((pts_per_drive - 0.55) / 7.0, 0.10, 0.42)
    base_fg = np.clip((pts_per_drive - 7.0 * base_td) / 3.0 + 0.10, 0.06, 0.24)

    score = np.zeros((2, trials), dtype=np.float32)
    remaining = np.full(trials, 3600.0, dtype=np.float32)
    poss = rng.integers(0, 2, size=trials, dtype=np.int8)
    pass_sum = np.zeros((2, trials), dtype=np.float32)
    rush_sum = np.zeros((2, trials), dtype=np.float32)
    poss_count = np.zeros((2, trials), dtype=np.float32)
    drive_count = np.zeros(trials, dtype=np.int16)

    # 36 drives is above realistic regulation tails; time exhaustion usually ends earlier.
    for _ in range(36):
        active = remaining > 0.0
        if not np.any(active):
            break
        idx = np.flatnonzero(active)
        p = poss[idx].astype(np.int64)
        o = 1 - p
        margin = score[p, idx] - score[o, idx]
        q = np.clip(4 - (remaining[idx] // 900).astype(np.int8), 1, 4)
        td0 = base_td[p]
        fg0 = base_fg[p]
        td, fg, to, pb, speed = _football_transition_probabilities(
            q=q,
            t_rem=remaining[idx],
            margin_poss=margin,
            base_td=td0,
            base_fg=fg0,
            offense=off[p, idx],
            defense=deff[o, idx],
            pace=pace[idx],
        )
        u = rng.random(len(idx))
        td_hit = u < td
        fg_hit = (~td_hit) & (u < td + fg)
        # turnover and punt both change possession; turnover only affects duration/pace.
        to_hit = (~td_hit) & (~fg_hit) & (u < td + fg + to)
        score[p[td_hit], idx[td_hit]] += 7.0
        score[p[fg_hit], idx[fg_hit]] += 3.0

        for team_id in (0, 1):
            m = p == team_id
            if np.any(m):
                ii = idx[m]
                pass_sum[team_id, ii] += pb[m].astype(np.float32)
                rush_sum[team_id, ii] -= pb[m].astype(np.float32)
                poss_count[team_id, ii] += 1.0

        base_duration = rng.lognormal(mean=math.log(145.0), sigma=0.32, size=len(idx))
        duration = np.clip(base_duration / speed, 38.0, 330.0)
        duration[to_hit] *= 0.78
        remaining[idx] = np.maximum(0.0, remaining[idx] - duration.astype(np.float32))
        poss[idx] = (1 - p).astype(np.int8)
        drive_count[idx] += 1

    denom = np.maximum(poss_count, 1.0)
    pass_script = np.clip(pass_sum / denom, -0.35, 0.35)
    rush_script = np.clip(rush_sum / denom, -0.35, 0.35)
    pace_z = ((drive_count.astype(np.float32) - float(np.mean(drive_count))) / max(float(np.std(drive_count)), 1.0)).astype(np.float32)
    s0 = score[0].astype(np.float64); s1 = score[1].astype(np.float64)
    margin = s0 - s1
    total = s0 + s1
    p0 = float(np.mean(margin > 0) + 0.5 * np.mean(margin == 0))
    p1 = 1.0 - p0
    market_favorite = None
    if market is not None:
        market_favorite = str(teams[0] if market[0] >= market[1] else teams[1])
    favorite_win = None
    upset = None
    if market_favorite is not None:
        favorite_win = p0 if market_favorite == str(teams[0]) else p1
        upset = 1.0 - favorite_win
    side_receipt = side_accuracy.prelock_game_side_receipt(
        sport=str(sport).upper(), mode=str(mode).upper(), teams=teams,
        spread_team0=market_spread_team0,
        win_probabilities={str(teams[0]): p0, str(teams[1]): p1},
    )
    receipt = {
        "PATCH_ID": PATCH_ID,
        "GLOBAL_SIDE_SELECTION_ACCURACY_PATCH_ID": side_accuracy.PATCH_ID,
        "PRELOCK_SIDE_SELECTION_RECEIPT": side_receipt,
        "CONTRACT_VERSION": CONTRACT_VERSION,
        "SPORT": "FOOTBALL",
        "TRIALS": int(trials),
        "TEAMS": [str(teams[0]), str(teams[1])],
        "MODEL_POINTS": [float(mp[0]), float(mp[1])],
        "INITIAL_ANCHOR_POINTS": [float(anchor[0]), float(anchor[1])],
        "MARKET_PRIOR_WEIGHT": float(w_used),
        "MAX_MARKET_PRIOR_WEIGHT": float(MAX_MARKET_PRIOR_WEIGHT),
        "MARKET_LINES_IN_STATE_TRANSITIONS": False,
        "STATE_VECTOR": ["QUARTER", "TIME_REMAINING", "MARGIN", "POSSESSION"],
        "COPULA_KERNEL": "STUDENT_T_LATENT_FACTORS_DF_4P5_5P0",
        "TEAM_WIN_PROBABILITIES": {str(teams[0]): p0, str(teams[1]): p1},
        "MARKET_FAVORITE": market_favorite,
        "MARKET_FAVORITE_WIN_PROBABILITY": favorite_win,
        "UPSET_RATE_VS_MARKET_FAVORITE": upset,
        "CLOSE_GAME_RATE_7_OR_LESS": float(np.mean(np.abs(margin) <= 7.0)),
        "TEAM_BLOWOUT_14_PLUS": {str(teams[0]): float(np.mean(margin >= 14.0)), str(teams[1]): float(np.mean(margin <= -14.0))},
        "SHOOTOUT_RATE_60_PLUS": float(np.mean(total >= 60.0)),
        "LOW_TOTAL_RATE_35_OR_LESS": float(np.mean(total <= 35.0)),
        "MARGIN_P05_P50_P95": [float(x) for x in np.quantile(margin, [0.05, 0.50, 0.95])],
        "TOTAL_P05_P50_P95": [float(x) for x in np.quantile(total, [0.05, 0.50, 0.95])],
        "REGIME_HASH": stable_hash({"scores": np.round(score[:, : min(2048, trials)], 3).tolist(), "seed": int(seed), "trials": int(trials)}),
        "POSTLOCK_RESULTS_USED": False,
    }
    return FootballRegimes(
        teams=(str(teams[0]), str(teams[1])), scores=score, pass_script=pass_script.astype(np.float32),
        rush_script=rush_script.astype(np.float32), pace_script=pace_z, offense_latent=off, defense_latent=deff, receipt=receipt,
    )


def sport_contract_receipt(*, sport: str, mode: str, adapter_consumes_regimes: bool) -> dict[str, Any]:
    s = str(sport).upper().strip(); m = str(mode).upper().strip()
    if s not in TEAM_SPORTS | INDIVIDUAL_SPORTS:
        raise ValueError(f"unsupported sport:{s}")
    return {
        "PATCH_ID": PATCH_ID,
        "CONTRACT_VERSION": CONTRACT_VERSION,
        "SPORT": s,
        "MODE": m,
        "MARKET_ROLE": "WEAK_INITIAL_PRIOR_ONLY",
        "MARKET_LINES_IN_STATE_TRANSITIONS": False,
        "MAX_MARKET_PRIOR_WEIGHT": MAX_MARKET_PRIOR_WEIGHT,
        "FAT_TAIL_REQUIREMENT": "STUDENT_T_OR_VALIDATED_HEAVY_TAIL_NATIVE_EQUIVALENT",
        "TERMINAL_OBJECTIVE": "P_LINEUP_GT_FIELD_MAXIMUM",
        "TEAM_WIN_OR_OUTCOME_REGIME_RECEIPT_REQUIRED": s in TEAM_SPORTS,
        "SPORT_NATIVE_ADAPTER_CONSUMES_REGIMES": bool(adapter_consumes_regimes),
        "POSTLOCK_RESULTS_USED": False,
    }
