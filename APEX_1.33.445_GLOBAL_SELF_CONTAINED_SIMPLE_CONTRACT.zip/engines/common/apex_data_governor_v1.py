from __future__ import annotations
from dataclasses import dataclass, asdict, field
from enum import Enum
from pathlib import Path
from datetime import datetime, timezone
import json, math, re
import pandas as pd
from engines.common import apex_entry_limit_game_theory_v1 as entry_limit_game

PATCH_ID = "APEX_GLOBAL_ASSUMPTION_GOVERNANCE_v1"
FIREWALL_ID = "APEX_GLOBAL_POINT_IN_TIME_PREFLIGHT_FIREWALL_v1"

class SourceClass(str, Enum):
    OBSERVED_LIVE="OBSERVED_LIVE"; PRIMARY_PROJECTED="PRIMARY_PROJECTED"; SECONDARY_PROJECTED="SECONDARY_PROJECTED"
    CONSENSUS_DERIVED="CONSENSUS_DERIVED"; MODEL_DERIVED="MODEL_DERIVED"; EXTERNAL_REPAIRED="EXTERNAL_REPAIRED"
    IDENTITY_RECONCILED="IDENTITY_RECONCILED"; STALE="STALE"; POST_LOCK_ACTUAL="POST_LOCK_ACTUAL"; POST_LOCK_DERIVED="POST_LOCK_DERIVED"

@dataclass
class ProvenanceVector:
    value: object
    source: str
    source_class: str
    event_timestamp: str | None
    retrieval_timestamp: str
    identity_certainty: float = 1.0
    source_agreement: float = 1.0
    historical_reliability: float = 1.0
    coverage: float = 1.0
    confidence: float = 0.0
    freshness_state: str = "FRESH"
    repair_chain: list[str] = field(default_factory=list)
    variance_scalar: float = 1.0

@dataclass(frozen=True)
class FeatureEnvelope:
    feature: str; source: str; source_class: str; event_timestamp: str | None; retrieval_timestamp: str
    confidence: float; identity_confidence: float; freshness_state: str; environment: str
    repair_chain: tuple[str, ...] = field(default_factory=tuple); uncertainty_multiplier: float = 1.0

class GovernanceError(RuntimeError): pass
class PostLockLeakageError(GovernanceError): pass
class MissingContestPayloadError(GovernanceError): pass
class RecoverableDataGap(GovernanceError):
    def __init__(self, feature, reason, context=None):
        super().__init__(f"RECOVERABLE_DATA_GAP:{feature}:{reason}")
        self.feature, self.reason, self.context = feature, reason, context or {}

FORWARD_FORBIDDEN_PATTERNS = (
    r"^% Drafted$", r"^DK % Drafted$", r"ACTUAL[_ ]?(FPTS|POINTS|SCORE)",
    r"CONTEST[_ ]?(FINISH|RANK)", r"FINAL[_ ]?RANK", r"WINNING[_ ]?LINEUP"
)
QUALITY = {
    SourceClass.OBSERVED_LIVE:.98, SourceClass.PRIMARY_PROJECTED:.88, SourceClass.SECONDARY_PROJECTED:.78,
    SourceClass.CONSENSUS_DERIVED:.90, SourceClass.MODEL_DERIVED:.82, SourceClass.EXTERNAL_REPAIRED:.72,
    SourceClass.IDENTITY_RECONCILED:.76, SourceClass.STALE:.35, SourceClass.POST_LOCK_ACTUAL:1.0, SourceClass.POST_LOCK_DERIVED:.95,
}

def _now_dt(): return datetime.now(timezone.utc)
def _now(): return _now_dt().isoformat()
def _parse_ts(v):
    if not v: return None
    try: return datetime.fromisoformat(str(v).replace("Z", "+00:00")).astimezone(timezone.utc)
    except Exception: return None

def load_policy(root=None):
    root = Path(root) if root else Path(__file__).resolve().parents[2]
    return json.loads((root / "doctrine/APEX_GLOBAL_FEATURE_POLICY_REGISTRY_v1.json").read_text())

def policy_for(feature, policy):
    features = policy.get("FEATURES", {})
    x, seen = features.get(feature), set()
    while isinstance(x, dict) and "alias_of" in x and x["alias_of"] not in seen:
        seen.add(x["alias_of"]); x = features.get(x["alias_of"])
    out = dict(policy.get("DEFAULT", {}))
    if isinstance(x, dict): out.update(x)
    return out

def infer_source_class(feature):
    u = str(feature).upper()
    if re.search(r"% DRAFTED|ACTUAL|CONTEST[_ ]?(RANK|FINISH)|FINAL[_ ]?RANK", u): return SourceClass.POST_LOCK_ACTUAL
    if any(k in u for k in ("STATUS", "STARTER", "LINEUP", "ACTIVE", "OUT")): return SourceClass.OBSERVED_LIVE
    return SourceClass.PRIMARY_PROJECTED

def freshness_factor(event_ts, ttl_seconds):
    ts = _parse_ts(event_ts)
    if ts is None: return "UNKNOWN", .72, float("inf")
    age = max(0.0, (_now_dt() - ts).total_seconds())
    if ttl_seconds <= 0: return ("FRESH" if age <= 0 else "STALE"), (1.0 if age <= 0 else 0.0), age
    if age <= ttl_seconds: return "FRESH", 1.0, age
    if age <= 2 * ttl_seconds: return "AGING", math.exp(-(age - ttl_seconds) / ttl_seconds), age
    return "STALE", max(.05, math.exp(-(age - ttl_seconds) / ttl_seconds)), age

def calculate_confidence(source_class, *, agreement=1.0, freshness=1.0, identity=1.0, coverage=1.0, historical=1.0):
    sc, out = SourceClass(source_class), 1.0
    for x in (QUALITY[sc], agreement, freshness, identity, coverage, historical):
        out *= max(0.0, min(1.0, float(x)))
    return max(0.0, min(1.0, out))

def uncertainty_multiplier(conf, max_mult=1.5, floor=.75):
    if conf >= floor: return 1.0
    return 1.0 + (max_mult - 1.0) * min(1.0, max(0.0, (floor - conf) / max(floor, 1e-9)))

def assert_forward_clean(columns):
    bad = [str(c) for c in columns if any(re.search(p, str(c), re.I) for p in FORWARD_FORBIDDEN_PATTERNS)]
    if bad: raise PostLockLeakageError("ENGINE_INTEGRITY_HALT:POSTLOCK_FEATURE_PRESENT_IN_FORWARD_MATRIX:" + ",".join(sorted(set(bad))))

class PreFlightEnvironmentFirewall:
    ENV_MANIFESTS = {
        "FORWARD_PRELOCK": {"FORBIDDEN_PATTERNS": FORWARD_FORBIDDEN_PATTERNS},
        "CALIBRATION_POSTLOCK": {"FORBIDDEN_PATTERNS": ()},
        "RESEARCH": {"FORBIDDEN_PATTERNS": ()},
    }
    @classmethod
    def verify_integrity(cls, feature_name, environment):
        if environment not in cls.ENV_MANIFESTS:
            raise GovernanceError("ENGINE_INTEGRITY_HALT:UNKNOWN_RUNTIME_ENVIRONMENT:" + str(environment))
        for p in cls.ENV_MANIFESTS[environment]["FORBIDDEN_PATTERNS"]:
            if re.search(p, str(feature_name), re.I):
                raise PostLockLeakageError("ENGINE_INTEGRITY_HALT:POSTLOCK_FEATURE_PRESENT_IN_FORWARD_MATRIX:" + str(feature_name))

class DataGovernor:
    def __init__(self, environment="FORWARD_PRELOCK", root=None, recovery_callback=None):
        self.environment, self.policy, self.recovery_callback = environment, load_policy(root), recovery_callback
    def validate_and_ingest(self, feature_name, vector: ProvenanceVector, context=None):
        PreFlightEnvironmentFirewall.verify_integrity(feature_name, self.environment)
        pol = policy_for(feature_name, self.policy)
        state, fresh, _ = freshness_factor(vector.event_timestamp, int(pol.get("ttl_seconds", 21600)))
        vector.freshness_state = state
        vector.confidence = calculate_confidence(vector.source_class, agreement=vector.source_agreement, freshness=fresh, identity=vector.identity_certainty, coverage=vector.coverage, historical=vector.historical_reliability)
        missing = vector.value is None or (hasattr(vector.value, "isna") and bool(vector.value.isna().all()))
        stale = state == "STALE" and bool(pol.get("required_fresh", False))
        if missing or stale:
            if pol.get("recoverable", True): return self._recover(feature_name, vector, context or {}, "MISSING" if missing else "STALE")
            raise GovernanceError("ENGINE_INTEGRITY_HALT:UNRECOVERABLE_REQUIRED_FEATURE:" + feature_name)
        vector.variance_scalar = uncertainty_multiplier(vector.confidence, float(pol.get("max_uncertainty_multiplier", 1.5)), float(pol.get("confidence_floor", .75)))
        return vector
    def _recover(self, feature_name, failed_vector, context, reason):
        if self.recovery_callback:
            repaired = self.recovery_callback(feature_name, failed_vector, context)
            if repaired is not None:
                repaired.repair_chain = list(failed_vector.repair_chain) + [f"{feature_name}:{reason}:RECOVERED:{_now()}"]
                return self.validate_and_ingest(feature_name, repaired, context)
        raise RecoverableDataGap(feature_name, reason, context)

def build_contest_payload(**kw):
    field_size = kw.get("field_size")
    if field_size is None or int(field_size) <= 0: raise MissingContestPayloadError("FIELD_SIZE_REQUIRED")
    max_entries_raw = kw.get("max_entries")
    user_entries_raw = kw.get("user_entries")
    max_entries = None if max_entries_raw in (None, "") else int(max_entries_raw)
    user_entries = None if user_entries_raw in (None, "") else int(user_entries_raw)
    entry_profile = None
    if max_entries is not None:
        entry_profile = entry_limit_game.profile_dict(
            field_size=int(field_size), max_entries=max_entries, user_entries=user_entries
        )
    return {
        "SPORT": str(kw.get("sport")).upper(), "MODE": str(kw.get("mode")).upper(), "FIELD_SIZE": int(field_size),
        "CONTEST_TYPE": kw.get("contest_type"), "MAX_ENTRIES": max_entries, "USER_ENTRIES": user_entries,
        "ENTRY_FEE": kw.get("entry_fee"), "PAYOUT_CURVE": kw.get("payout_curve"), "PCT_TO_FIRST": kw.get("pct_to_first"),
        "PCT_PAID": kw.get("pct_paid"), "STAKE_BUCKET": kw.get("stake_bucket"), "SLATE_SIZE": kw.get("slate_size"),
        "ENTRY_LIMIT_GAME_THEORY_PATCH_ID": entry_limit_game.PATCH_ID,
        "ENTRY_LIMIT_PROFILE": entry_profile,
        "ENTRY_LIMIT_SYMMETRY_REQUIRED": True,
        "PORTFOLIO_OBJECTIVE": entry_limit_game.OBJECTIVE,
        "ENVIRONMENT": "FORWARD_PRELOCK", "GOVERNANCE_PATCH_ID": PATCH_ID,
    }

def govern_player_pool(path, *, sport, mode, field_size, output_dir, provider="PLAYER_FILE", event_timestamp=None, contest_type=None, max_entries=None, user_entries=None, entry_fee=None, payout_curve=None, pct_to_first=None, pct_paid=None, stake_bucket=None, slate_size=None):
    path, outdir = Path(path), Path(output_dir); outdir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(path); assert_forward_clean(df.columns); gov, envelopes = DataGovernor(), {}
    for c in map(str, df.columns):
        sc = infer_source_class(c); pv = ProvenanceVector(df[c], provider, sc.value, event_timestamp, _now())
        try: pv = gov.validate_and_ingest(c, pv, {"sport": sport, "mode": mode})
        except RecoverableDataGap:
            pol = policy_for(c, gov.policy); state, fresh, _ = freshness_factor(event_timestamp, int(pol.get("ttl_seconds", 21600)))
            pv.freshness_state = state; pv.confidence = calculate_confidence(sc, freshness=fresh)
            pv.variance_scalar = uncertainty_multiplier(pv.confidence, float(pol.get("max_uncertainty_multiplier", 1.5)), float(pol.get("confidence_floor", .75)))
        envelopes[c] = asdict(FeatureEnvelope(c, provider, pv.source_class, event_timestamp, pv.retrieval_timestamp, pv.confidence, pv.identity_certainty, pv.freshness_state, "FORWARD_PRELOCK", tuple(pv.repair_chain), pv.variance_scalar))
    payload = build_contest_payload(sport=sport, mode=mode, field_size=field_size, contest_type=contest_type, max_entries=max_entries, user_entries=user_entries, entry_fee=entry_fee, payout_curve=payout_curve, pct_to_first=pct_to_first, pct_paid=pct_paid, stake_bucket=stake_bucket, slate_size=slate_size)
    governed = outdir / (path.stem + ".apex_governed.csv"); df.to_csv(governed, index=False)
    meta = outdir / (path.stem + ".apex_provenance.json")
    meta.write_text(json.dumps({"PATCH_ID": PATCH_ID, "FIREWALL_ID": FIREWALL_ID, "SOURCE_FILE": str(path), "GOVERNED_FILE": str(governed), "CONTEST_PAYLOAD": payload, "FEATURE_ENVELOPES": envelopes}, indent=2) + "\n")
    return {"player_pool": str(governed), "provenance": str(meta), "contest_payload": payload}
