from __future__ import annotations

import os
from pathlib import Path
from typing import Sequence

PATCH_ID = "APEX_GLOBAL_EXTERNAL_CALLER_TRIGGER_REPORT_ONLY_BOUNDARY_v2"
CALLER_ROLE = "TRIGGER_REPORT_ONLY"
LIVE_RUN_CONTROL_POLICY = "ENGINE_OWNS_END_TO_END_PIPELINE_AND_CONTINUATION"

FORBIDDEN_ENV_KEYS = (
    "APEX_CHAT_ALLOW_LIVE_INTERVENTION",
    "APEX_CHAT_ALLOW_LATENCY_RESTART",
    "APEX_CHAT_ALLOW_LIVE_PATCHING",
    "APEX_CHAT_ALLOW_CHECKPOINT_MUTATION",
    "APEX_AI_ALLOW_LIVE_INTERVENTION",
    "APEX_AI_SELECTOR_OVERRIDE",
    "APEX_AI_BOARD_OVERRIDE",
    "APEX_MANUAL_RERANK_PAYLOAD",
    "APEX_MANUAL_LINEUP_PAYLOAD",
    "APEX_SPLIT_SOURCE",
    "APEX_SPLIT_START",
    "APEX_SPLIT_END",
    "APEX_SPLIT_CHECKPOINT_IN",
    "APEX_SPLIT_CHECKPOINT_OUT",
    "APEX_PAIR_SLICE_START",
    "APEX_PAIR_SLICE_END",
)

class ExternalCallerBoundaryError(RuntimeError):
    pass


def _py_targets(command: Sequence[str]) -> list[Path]:
    return [Path(str(x)) for x in command if str(x).endswith('.py')]


def enforce_live_production_child(command: Sequence[str], env: dict[str,str]) -> dict:
    if str(env.get('APEX_EXECUTION_MODE','PRODUCTION')).upper() != 'PRODUCTION':
        return {'PATCH_ID':PATCH_ID,'STATUS':'NOT_APPLICABLE_NON_PRODUCTION'}
    for key in FORBIDDEN_ENV_KEYS:
        if str(env.get(key,'')).strip():
            raise ExternalCallerBoundaryError(f'RUN_INVALID:EXTERNAL_CALLER_ENGINE_CONTROL_PROHIBITED:{key}')
    expected=str(env.get('APEX_AUTHORITATIVE_ENGINE_ENTRYPOINT','')).strip()
    targets=_py_targets(command)
    if not expected:
        raise ExternalCallerBoundaryError('RUN_INVALID:AUTHORITATIVE_ENGINE_ENTRYPOINT_REQUIRED')
    if not targets:
        raise ExternalCallerBoundaryError('RUN_INVALID:AUTHORITATIVE_ENGINE_ENTRYPOINT_CHILD_MISSING')
    actual=targets[-1].resolve(); exp=Path(expected).resolve()
    if actual != exp:
        raise ExternalCallerBoundaryError(f'RUN_INVALID:AUTHORITATIVE_ENGINE_ENTRYPOINT_MISMATCH:{actual}:{exp}')
    return {
        'PATCH_ID':PATCH_ID,'STATUS':'PASS','CALLER_ROLE':CALLER_ROLE,
        'LIVE_RUN_CONTROL_POLICY':LIVE_RUN_CONTROL_POLICY,
        'EXTERNAL_CALLER_ENGINE_INTERNAL_OPERATION_ALLOWED':False,
        'EXTERNAL_CALLER_STAGE_SELECTION_AUTHORITY':False,
        'EXTERNAL_CALLER_STAGE_SUBSTITUTION_AUTHORITY':False,
        'EXTERNAL_CALLER_CHECKPOINT_SELECTION_AUTHORITY':False,
        'EXTERNAL_CALLER_TERMINAL_ORDER_AUTHORITY':False,
        'EXTERNAL_CALLER_SELECTOR_AUTHORITY':False,
        'EXTERNAL_CALLER_RERANK_AUTHORITY':False,
        'EXTERNAL_CALLER_PUBLISH_AUTHORITY':False,
        'AUTHORITATIVE_ENGINE_ENTRYPOINT':str(exp),
    }


def production_env(authoritative_entrypoint: str|os.PathLike[str]) -> dict[str,str]:
    return {
        'APEX_GLOBAL_EXTERNAL_CALLER_BOUNDARY':PATCH_ID,
        'APEX_AUTHORITATIVE_ENGINE_ENTRYPOINT':str(Path(authoritative_entrypoint).resolve()),
        'APEX_CHAT_EXECUTION_AUTHORITY':'0',
        'APEX_AI_EXECUTION_AUTHORITY':'0',
        'APEX_AI_SELECTOR_AUTHORITY':'0',
        'APEX_AI_RERANK_AUTHORITY':'0',
        'APEX_AI_PUBLISH_AUTHORITY':'0',
        'APEX_MANUAL_ENGINE_CONTROL':'PROHIBITED',
        'APEX_EXTERNAL_CALLER_STAGE_SELECTION':'PROHIBITED',
        'APEX_EXTERNAL_CALLER_STAGE_SUBSTITUTION':'PROHIBITED',
        'APEX_EXTERNAL_CALLER_CHECKPOINT_SELECTION':'PROHIBITED',
        'APEX_EXTERNAL_CALLER_TERMINAL_ORDER':'PROHIBITED',
        'APEX_ENGINE_PROCESS_LIFECYCLE_AUTHORITY':'1',
        'APEX_ENGINE_CHECKPOINT_AUTHORITY':'1',
        'APEX_ENGINE_TERMINAL_ORDER_AUTHORITY':'1',
    }
