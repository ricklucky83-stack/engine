from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import pandas as pd

CONTRACT_ID = "APEX_PIPELINE_IDENTITY_LEDGER_AND_PARITY_v1"
CONTRACT_VERSION = "1.0.0"
PROVENANCE_PRELOCK = "PRELOCK_SEALED_OR_LIVE_PRODUCTION"


class LedgerIntegrityError(RuntimeError):
    """Hard pipeline-integrity failure. The message is a stable failure code."""


@dataclass(frozen=True)
class StageSeal:
    stage: str
    path: str
    rows: int
    file_sha256: str
    identity_sha256: str
    provenance: str = PROVENANCE_PRELOCK

    def as_dict(self) -> dict[str, Any]:
        return {
            "STAGE": self.stage,
            "PATH": self.path,
            "ROWS": self.rows,
            "FILE_SHA256": self.file_sha256,
            "IDENTITY_SHA256": self.identity_sha256,
            "PROVENANCE": self.provenance,
        }


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def canonical_lineup_id(
    player_ids: Sequence[str],
    slot_labels: Sequence[str] | None = None,
    *,
    digest_chars: int = 24,
) -> str:
    """Return immutable lineup identity from player IDs plus role/slot identity.

    Identical role labels (e.g. six Tennis UTIL slots) are order-insensitive.
    Distinct role labels (e.g. CPT/FLEX, QB/RB/WR) remain player-role sensitive.
    """
    ids = [str(x).strip() for x in player_ids]
    if not ids or any(not x for x in ids):
        raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:EMPTY_PLAYER_ID")
    if len(set(ids)) != len(ids):
        raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:DUPLICATE_PLAYER_ID")

    if slot_labels is None:
        slots = ["UTIL"] * len(ids)
    else:
        slots = [str(x).strip().upper() or "UTIL" for x in slot_labels]
        if len(slots) != len(ids):
            raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:SLOT_CARDINALITY")

    # Canonical tokens preserve role assignment but ignore arbitrary row ordering.
    role_player_tokens = sorted(f"{slot}:{pid}" for slot, pid in zip(slots, ids))
    payload = {
        "PLAYER_IDS": sorted(ids),
        "ROLE_PLAYER_TOKENS": role_player_tokens,
        "ROSTER_SIZE": len(ids),
    }
    digest = _sha256_bytes(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    )
    return digest[: int(digest_chars)]


def identity_digest(lineup_ids: Iterable[str]) -> str:
    ids = [str(x) for x in lineup_ids]
    # Preserve multiplicity explicitly. Duplicate identities are a hard error.
    if len(ids) != len(set(ids)):
        raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:DUPLICATE_LINEUP_ID")
    return _sha256_bytes("\n".join(sorted(ids)).encode("utf-8"))


def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _atomic_write_csv(path: Path, frame: pd.DataFrame) -> None:
    # Stable newline/column order for hash receipts.
    text = frame.to_csv(index=False, lineterminator="\n")
    _atomic_write_text(path, text)


def build_identity_frame(
    *,
    stage: str,
    lineup_player_ids: Sequence[Sequence[str]],
    slot_labels: Sequence[str] | Sequence[Sequence[str]] | None = None,
    extra_columns: Mapping[str, Sequence[Any]] | None = None,
) -> pd.DataFrame:
    n = len(lineup_player_ids)
    if n == 0:
        raise LedgerIntegrityError(f"{stage.upper()}_LEDGER_MISSING:EMPTY_STAGE")

    # slot_labels may be one roster template or row-specific role assignments.
    row_slots: list[list[str]] = []
    if slot_labels is None:
        row_slots = [["UTIL"] * len(row) for row in lineup_player_ids]
    elif slot_labels and isinstance(slot_labels[0], str):  # type: ignore[index]
        template = [str(x) for x in slot_labels]  # type: ignore[arg-type]
        row_slots = [template for _ in lineup_player_ids]
    else:
        row_slots = [[str(x) for x in row] for row in slot_labels]  # type: ignore[arg-type]
        if len(row_slots) != n:
            raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:SLOT_ROW_CARDINALITY")

    records: list[dict[str, Any]] = []
    for ordinal, (players, slots) in enumerate(zip(lineup_player_ids, row_slots), start=1):
        pids = [str(x) for x in players]
        if len(slots) != len(pids):
            raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:SLOT_CARDINALITY")
        rec: dict[str, Any] = {
            "STAGE": str(stage),
            "STAGE_ORDINAL": ordinal,
            "LINEUP_ID": canonical_lineup_id(pids, slots),
            "PLAYER_IDS": "|".join(pids),
            "ROLE_PLAYER_TOKENS": "|".join(sorted(f"{str(s).upper()}:{p}" for s, p in zip(slots, pids))),
            "ROSTER_SIZE": len(pids),
        }
        for i, (pid, slot) in enumerate(zip(pids, slots), start=1):
            rec[f"P{i}_ID"] = pid
            rec[f"P{i}_ROLE"] = str(slot).upper()
        records.append(rec)

    frame = pd.DataFrame.from_records(records)
    if extra_columns:
        for name, values in extra_columns.items():
            vals = list(values)
            if len(vals) != n:
                raise LedgerIntegrityError(f"IDENTITY_HASH_MISMATCH:EXTRA_COLUMN_CARDINALITY:{name}")
            frame[str(name)] = vals
    return frame


def seal_stage_ledger(
    *,
    stage: str,
    path: str | Path,
    lineup_player_ids: Sequence[Sequence[str]],
    slot_labels: Sequence[str] | Sequence[Sequence[str]] | None = None,
    extra_columns: Mapping[str, Sequence[Any]] | None = None,
    provenance: str = PROVENANCE_PRELOCK,
) -> StageSeal:
    p = Path(path)
    frame = build_identity_frame(
        stage=stage,
        lineup_player_ids=lineup_player_ids,
        slot_labels=slot_labels,
        extra_columns=extra_columns,
    )
    _atomic_write_csv(p, frame)
    return StageSeal(
        stage=stage,
        path=str(p),
        rows=len(frame),
        file_sha256=sha256_file(p),
        identity_sha256=identity_digest(frame["LINEUP_ID"].astype(str).tolist()),
        provenance=provenance,
    )


def require_original_sealed_ledger(
    path: str | Path,
    *,
    missing_code: str,
    expected_file_sha256: str | None = None,
    expected_identity_sha256: str | None = None,
) -> StageSeal:
    """Read an existing sealed ledger only; never reconstruct missing post-lock state."""
    p = Path(path)
    if not p.exists():
        raise LedgerIntegrityError(missing_code)
    actual_file_sha = sha256_file(p)
    if expected_file_sha256 and actual_file_sha != expected_file_sha256:
        raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:FILE_SHA256")
    frame = pd.read_csv(p, dtype=str, keep_default_na=False)
    if "LINEUP_ID" not in frame.columns:
        raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:LINEUP_ID_COLUMN_MISSING")
    actual_identity = identity_digest(frame["LINEUP_ID"].tolist())
    if expected_identity_sha256 and actual_identity != expected_identity_sha256:
        raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:IDENTITY_SHA256")
    return StageSeal(
        stage=str(frame["STAGE"].iloc[0]) if "STAGE" in frame.columns and len(frame) else "UNKNOWN",
        path=str(p),
        rows=len(frame),
        file_sha256=actual_file_sha,
        identity_sha256=actual_identity,
    )


def verify_pipeline_parity(
    *,
    phase2: StageSeal,
    handoff: StageSeal,
    selector: StageSeal,
    receipt_path: str | Path,
) -> dict[str, Any]:
    if phase2.rows != handoff.rows:
        raise LedgerIntegrityError(
            f"HANDOFF_RECALL_FAILURE:SEALED_BUILT_NE_HANDOFF:{phase2.rows}:{handoff.rows}"
        )
    if handoff.rows != selector.rows:
        raise LedgerIntegrityError(
            f"HANDOFF_RECALL_FAILURE:HANDOFF_NE_SELECTOR_REVIEWED:{handoff.rows}:{selector.rows}"
        )

    if not (phase2.identity_sha256 == handoff.identity_sha256 == selector.identity_sha256):
        raise LedgerIntegrityError(
            "HANDOFF_RECALL_FAILURE:IDENTITY_HASH_MISMATCH"
        )

    receipt = {
        "CONTRACT_ID": CONTRACT_ID,
        "CONTRACT_VERSION": CONTRACT_VERSION,
        "SEALED_BUILT_LINEUPS": phase2.rows,
        "HANDOFF_SURVIVORS": handoff.rows,
        "SELECTOR_REVIEWED_LINEUPS": selector.rows,
        "COUNT_PARITY": "PASS",
        "IDENTITY_PARITY": "PASS",
        "PIPELINE_PARITY": "PASS",
        "PHASE2": phase2.as_dict(),
        "HANDOFF": handoff.as_dict(),
        "SELECTOR": selector.as_dict(),
        "NO_POSTLOCK_RECONSTRUCTION": True,
    }
    _atomic_write_text(Path(receipt_path), json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    receipt["RECEIPT_SHA256"] = sha256_file(receipt_path)
    return receipt


__all__ = [
    "CONTRACT_ID",
    "CONTRACT_VERSION",
    "LedgerIntegrityError",
    "StageSeal",
    "canonical_lineup_id",
    "identity_digest",
    "seal_stage_ledger",
    "require_original_sealed_ledger",
    "verify_pipeline_parity",
]


def reseal_stage_from_parent_ledger(
    *,
    parent_path: str | Path,
    stage: str,
    path: str | Path,
    extra_columns: Mapping[str, Sequence[Any]] | None = None,
    provenance: str = PROVENANCE_PRELOCK,
) -> StageSeal:
    """Fast-path reseal preserving canonical lineup identity from a sealed parent ledger.

    This avoids rebuilding canonical player-role identities row-by-row at downstream
    stages. The parent LINEUP_ID/PLAYER_IDS/ROLE_PLAYER_TOKENS and Pn role columns
    are retained byte-for-value; only STAGE/STAGE_ORDINAL and requested stage metric
    columns are emitted. Duplicate or malformed parent identities fail closed.
    """
    src = Path(parent_path)
    if not src.exists():
        raise LedgerIntegrityError(f"{str(stage).upper()}_PARENT_LEDGER_MISSING")
    parent = pd.read_csv(src, dtype=str, keep_default_na=False)
    required = ["LINEUP_ID", "PLAYER_IDS", "ROLE_PLAYER_TOKENS", "ROSTER_SIZE"]
    if any(c not in parent.columns for c in required):
        raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:PARENT_IDENTITY_COLUMNS_MISSING")
    ids = parent["LINEUP_ID"].astype(str).tolist()
    parent_identity_sha = identity_digest(ids)
    n = len(parent)
    identity_cols = ["STAGE", "STAGE_ORDINAL", "LINEUP_ID", "PLAYER_IDS", "ROLE_PLAYER_TOKENS", "ROSTER_SIZE"]
    max_slots = 0
    for c in parent.columns:
        if c.startswith("P") and c.endswith("_ID"):
            try: max_slots = max(max_slots, int(c[1:-3]))
            except Exception: pass
    for i in range(1, max_slots + 1):
        for suffix in ("_ID", "_ROLE"):
            c = f"P{i}{suffix}"
            if c in parent.columns: identity_cols.append(c)
    frame = parent[identity_cols].copy()
    frame["STAGE"] = str(stage)
    frame["STAGE_ORDINAL"] = range(1, n + 1)
    if extra_columns:
        for name, values in extra_columns.items():
            vals = list(values)
            if len(vals) != n:
                raise LedgerIntegrityError(f"IDENTITY_HASH_MISMATCH:EXTRA_COLUMN_CARDINALITY:{name}")
            frame[str(name)] = vals
    # Verify downstream identity is unchanged before write.
    if identity_digest(frame["LINEUP_ID"].astype(str).tolist()) != parent_identity_sha:
        raise LedgerIntegrityError("IDENTITY_HASH_MISMATCH:FAST_RESEAL_PARENT_PARITY")
    p = Path(path)
    _atomic_write_csv(p, frame)
    return StageSeal(
        stage=str(stage), path=str(p), rows=n,
        file_sha256=sha256_file(p), identity_sha256=parent_identity_sha,
        provenance=provenance,
    )
