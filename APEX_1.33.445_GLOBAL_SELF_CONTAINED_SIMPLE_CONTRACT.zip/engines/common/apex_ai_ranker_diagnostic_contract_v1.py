from __future__ import annotations

from typing import Any, Mapping, Sequence

PATCH_ID = "APEX_AI_RANKER_DIAGNOSTIC_CONTRACT_v1"
REQUIRED_KEYS = (
    "AI_AUTHORITY",
    "SELECTOR_MODE",
    "NATIVE_RANKER_TOP5",
    "FINAL_BOARD_TOP5",
    "PROTECTED_RESERVE_NATIVE_RANKS",
    "POSTLOCK_GRADED_TOP5",
    "WINNER_NATIVE_RANK",
    "WINNER_FINAL_BOARD_RANK",
    "TOP01_CAPTURE_BY_RANK_BUCKET",
)


def required_fields() -> list[str]:
    return list(REQUIRED_KEYS)


def validate_prelock_surface(surface: Mapping[str, Any]) -> dict[str, Any]:
    missing=[k for k in REQUIRED_KEYS[:5] if k not in surface]
    if missing:
        raise RuntimeError("AI_RANKER_DIAGNOSTIC_MISSING_PRELOCK_FIELDS:"+",".join(missing))
    if bool(surface.get("POSTLOCK_INPUT_USED", False)):
        raise RuntimeError("AI_RANKER_DIAGNOSTIC_POSTLOCK_LEAKAGE")
    return {"PATCH_ID":PATCH_ID,"STATUS":"PASS","MISSING":[],"POSTLOCK_INPUT_USED":False}


def classify_ranker(*, winner_native_rank: int | None, top5_contest_ranks: Sequence[int | None], top01_cutoff: int) -> str:
    top5_hits=sum(1 for r in top5_contest_ranks if r is not None and int(r) <= int(top01_cutoff))
    if winner_native_rank is not None and int(winner_native_rank) <= 5:
        return "RANKER_SOLVED_WINNER_TOP5"
    if top5_hits >= 1:
        return "RANKER_PARTIAL_TOP01_TOP5"
    return "RANKER_MISS_TOP5"
