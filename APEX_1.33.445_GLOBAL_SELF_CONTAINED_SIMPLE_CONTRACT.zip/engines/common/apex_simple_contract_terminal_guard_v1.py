from __future__ import annotations
from typing import Any
PATCH_ID='APEX_SIMPLE_CONTRACT_TERMINAL_GUARD_v1_1.33.445'
class SimpleContractTerminalError(RuntimeError): pass

def _first(p:dict,*keys,default=None):
    for k in keys:
        if k in p and p[k] is not None: return p[k]
    return default

def _truth(p:dict,*keys):
    return bool(_first(p,*keys,default=False))

def validate(payload:dict, *, configured_mc_count:int=200000)->dict[str,Any]:
    p=dict(payload or {})
    worlds=int(_first(p,'MC_WORLDS','PHASE1_MC_WORLDS','PHASE1_MC_TRIALS','BASE_SIM_TRIALS',default=0) or 0)
    if worlds!=int(configured_mc_count): raise SimpleContractTerminalError(f'MC_COUNT_MISMATCH:{worlds}!={configured_mc_count}')
    if not _truth(p,'MC_FIRST_COMPLETE','MC_FIRST_COMPLETED','PHASE1_MC_COMPLETE','PHASE1_COMPLETE'): raise SimpleContractTerminalError('MC_FIRST_PROOF_MISSING')
    fam=int(_first(p,'CHAMPIONSHIP_FAMILIES_IDENTIFIED','CHAMPIONSHIP_FAMILY_COUNT','FAMILY_COUNT',default=0) or 0)
    if fam<=0: raise SimpleContractTerminalError('CHAMPIONSHIP_FAMILY_DISCOVERY_PROOF_MISSING')
    if not _truth(p,'CPT_LANE_COVERAGE_COMPLETE'): raise SimpleContractTerminalError('CPT_LANE_COVERAGE_INCOMPLETE')
    mand=int(_first(p,'MANDATORY_CPT_LANES',default=0) or 0); cov=int(_first(p,'COVERED_CPT_LANES',default=-1) or -1)
    if mand<=0 or cov!=mand: raise SimpleContractTerminalError('MANDATORY_CPT_LANE_PARITY_FAILED')
    if not _truth(p,'STACK_SHAPE_COVERAGE_COMPLETE'): raise SimpleContractTerminalError('STACK_SHAPE_COVERAGE_INCOMPLETE')
    if not _truth(p,'PUNT_FILLER_BRANCH_COVERAGE_COMPLETE'): raise SimpleContractTerminalError('PUNT_FILLER_BRANCH_COVERAGE_INCOMPLETE')
    if not _truth(p,'FULL_FAMILY_CLOSURE_COMPLETE'): raise SimpleContractTerminalError('FULL_FAMILY_CLOSURE_INCOMPLETE')
    legal=int(_first(p,'FAMILY_LEGAL_BRANCHES','FAMILY_CLOSURE_LEGAL_BRANCHES','LEGAL_BRANCH_COUNT',default=0) or 0)
    born=int(_first(p,'FAMILY_BORN_BRANCHES','FAMILY_CLOSURE_BORN_BRANCHES','BORN_BRANCH_COUNT',default=-1) or -1)
    scored=int(_first(p,'FAMILY_SCORED_BRANCHES','FAMILY_CLOSURE_SCORED_BRANCHES','SCORED_BRANCH_COUNT',default=-2) or -2)
    if legal<=0 or not (legal==born==scored): raise SimpleContractTerminalError(f'FAMILY_CLOSURE_PARITY_FAILED:{legal}:{born}:{scored}')
    if not _truth(p,'EXACT_COMMON_WORLD_SCORING_COMPLETE'): raise SimpleContractTerminalError('EXACT_COMMON_WORLD_SCORING_PROOF_MISSING')
    if not _truth(p,'DOT00001_GATE_COMPLETE','.00001_GATE_COMPLETE','GATE_00001_COMPLETE'): raise SimpleContractTerminalError('DOT00001_GATE_PROOF_MISSING')
    if not _truth(p,'SAME_WORLD_DOMINANCE_PRUNING_COMPLETE','DOMINANCE_PRUNING_COMPLETE'): raise SimpleContractTerminalError('DOMINANCE_PRUNING_PROOF_MISSING')
    ordinal=str(_first(p,'ORDINAL_SELECTOR','GLOBAL_ORDINAL_SCORE_AUTHORITY',default=''))
    if ordinal!='GLOBAL_ORDINAL_POSTERIOR_SCORE': raise SimpleContractTerminalError(f'ORDINAL_SELECTOR_INVALID:{ordinal}')
    if not _truth(p,'ORDINAL_ORDERING_COMPLETE','ORDINAL_CHECKOFF_COMPLETE'): raise SimpleContractTerminalError('ORDINAL_ORDERING_CHECKOFF_MISSING')
    if _truth(p,'BACKFILL_USED'): raise SimpleContractTerminalError('BACKFILL_PROHIBITED')
    if _truth(p,'FORCED_BOARD_SIZE'): raise SimpleContractTerminalError('FORCED_BOARD_SIZE_PROHIBITED')
    survivors=int(_first(p,'NON_DOMINATED_SURVIVORS','FINAL_BOARD_SIZE',default=-1) or -1)
    final_size=int(_first(p,'FINAL_BOARD_SIZE',default=-2) or -2)
    if final_size!=survivors: raise SimpleContractTerminalError(f'PORTFOLIO_NOT_SURVIVOR_SET:{final_size}!={survivors}')
    return {'PATCH_ID':PATCH_ID,'STATUS':'PASS','CONFIGURED_MC_COUNT':int(configured_mc_count),'MC_WORLDS':worlds,'CHAMPIONSHIP_FAMILIES_IDENTIFIED':fam,'FAMILY_LEGAL_BRANCHES':legal,'FAMILY_BORN_BRANCHES':born,'FAMILY_SCORED_BRANCHES':scored,'ORDINAL_SELECTOR':'GLOBAL_ORDINAL_POSTERIOR_SCORE','FINAL_BOARD_SIZE':final_size,'NO_FORCED_BOARD_SIZE':True,'NO_BACKFILL':True,'PORTFOLIO_EQUALS_SURVIVOR_SET':True}
