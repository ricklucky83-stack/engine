from __future__ import annotations
from typing import Any

from apex_global_complete_ordinal_evidence_v1 import (
    MC_WORLDS, DOT00001_THRESHOLD, ORDINAL_AUTHORITY, REQUIRED_ORDINAL_FIELDS,
)

PATCH_ID = 'APEX_SIMPLE_CONTRACT_TERMINAL_GUARD_v3_1.33.445_GLOBAL_TARGET_RANK_00001'


class SimpleContractTerminalError(RuntimeError):
    pass


def _first(p: dict, *keys, default=None):
    for k in keys:
        if k in p and p[k] is not None:
            return p[k]
    return default


def _truth(p: dict, *keys):
    return bool(_first(p, *keys, default=False))


def validate(payload: dict, *, configured_mc_count: int = MC_WORLDS) -> dict[str, Any]:
    p = dict(payload or {})
    worlds = int(_first(p, 'MC_WORLDS', 'PHASE1_MC_WORLDS', 'PHASE1_MC_TRIALS', 'BASE_SIM_TRIALS', default=0) or 0)
    if worlds != int(configured_mc_count) or worlds != MC_WORLDS:
        raise SimpleContractTerminalError(f'MC_COUNT_MISMATCH:{worlds}!={MC_WORLDS}')
    if not _truth(p, 'MC_FIRST_COMPLETE', 'MC_FIRST_COMPLETED', 'PHASE1_MC_COMPLETE', 'PHASE1_COMPLETE'):
        raise SimpleContractTerminalError('MC_FIRST_PROOF_MISSING')

    if _truth(p, 'OLDER_SELECTION_PIPELINE_FALLBACK_USED'):
        raise SimpleContractTerminalError('OLDER_SELECTION_PIPELINE_FALLBACK_PROHIBITED')
    if _truth(p, 'DISCOVERY_RESTRICTIVE_PLAYER_POOL_USED'):
        raise SimpleContractTerminalError('RESTRICTIVE_DISCOVERY_POOL_PROHIBITED')
    if _truth(p, 'DISCOVERY_CPT_TOP_PLAYER_LIMIT_USED') or _truth(p, 'DISCOVERY_FLEX_TOP_PLAYER_LIMIT_USED'):
        raise SimpleContractTerminalError('DISCOVERY_TOP_PLAYER_LIMIT_PROHIBITED')
    if _truth(p, 'DISCOVERY_BOUNDED_POSITION_ADDITIONS_USED') or _truth(p, 'DISCOVERY_BOUNDED_TEAM_ADDITIONS_USED'):
        raise SimpleContractTerminalError('DISCOVERY_BOUNDED_ADDITIONS_PROHIBITED')

    if _truth(p, 'PRE_GATE_FAMILY_CAP_USED'):
        raise SimpleContractTerminalError('PRE_GATE_FAMILY_CAP_PROHIBITED')
    if _truth(p, 'PRE_GATE_BRANCH_CAP_USED'):
        raise SimpleContractTerminalError('PRE_GATE_BRANCH_CAP_PROHIBITED')
    if _truth(p, 'TOP_K_CLOSURE_CAP_USED'):
        raise SimpleContractTerminalError('TOP_K_CLOSURE_CAP_PROHIBITED')
    if _truth(p, 'PRE_SCORE_PRUNING_USED'):
        raise SimpleContractTerminalError('PRE_SCORE_PRUNING_PROHIBITED')
    if not _truth(p, 'CHAMPIONSHIP_NEIGHBORHOOD_EXHAUSTED'):
        raise SimpleContractTerminalError('CHAMPIONSHIP_NEIGHBORHOOD_NOT_EXHAUSTED')
    if not _truth(p, 'SCORE_EVERY_COMPLETE_LEGAL_BUILD'):
        raise SimpleContractTerminalError('EVERY_COMPLETE_BUILD_NOT_SCORED')

    fam = int(_first(p, 'CHAMPIONSHIP_FAMILIES_IDENTIFIED', 'CHAMPIONSHIP_FAMILY_COUNT', 'FAMILY_COUNT', default=0) or 0)
    if fam > 0:
        if not _truth(p, 'CPT_LANE_COVERAGE_COMPLETE'):
            raise SimpleContractTerminalError('CPT_LANE_COVERAGE_INCOMPLETE')
        mand = int(_first(p, 'MANDATORY_CPT_LANES', default=0) or 0)
        cov = int(_first(p, 'COVERED_CPT_LANES', default=-1) or -1)
        if mand < 0 or cov != mand:
            raise SimpleContractTerminalError('MANDATORY_CPT_LANE_PARITY_FAILED')

    if not _truth(p, 'FULL_FAMILY_CLOSURE_COMPLETE'):
        raise SimpleContractTerminalError('FULL_FAMILY_CLOSURE_INCOMPLETE')
    legal = int(_first(p, 'FAMILY_LEGAL_BRANCHES', 'FAMILY_CLOSURE_LEGAL_BRANCHES', 'LEGAL_BRANCH_COUNT', default=0) or 0)
    born = int(_first(p, 'FAMILY_BORN_BRANCHES', 'FAMILY_CLOSURE_BORN_BRANCHES', 'BORN_BRANCH_COUNT', default=0) or 0)
    scored = int(_first(p, 'FAMILY_SCORED_BRANCHES', 'FAMILY_CLOSURE_SCORED_BRANCHES', 'SCORED_BRANCH_COUNT', default=0) or 0)
    if not (legal == born == scored):
        raise SimpleContractTerminalError(f'FAMILY_CLOSURE_PARITY_FAILED:{legal}:{born}:{scored}')
    if fam > 0 and legal <= 0:
        raise SimpleContractTerminalError('FAMILY_CLOSURE_ZERO_AFTER_DISCOVERY')

    if not _truth(p, 'EXACT_COMMON_WORLD_SCORING_COMPLETE'):
        raise SimpleContractTerminalError('EXACT_COMMON_WORLD_SCORING_PROOF_MISSING')
    if not _truth(p, 'DOT00001_GATE_COMPLETE', '.00001_GATE_COMPLETE', 'GATE_00001_COMPLETE'):
        raise SimpleContractTerminalError('DOT00001_GATE_PROOF_MISSING')
    threshold = float(_first(p, 'DOT00001_GATE_THRESHOLD', 'GATE_THRESHOLD', default=-1.0))
    if abs(threshold - DOT00001_THRESHOLD) > 1e-12:
        raise SimpleContractTerminalError(f'DOT00001_THRESHOLD_INVALID:{threshold}')
    gate_definition = str(_first(p, 'DOT00001_GATE_DEFINITION', default='')).upper()
    if gate_definition != 'SAME_WORLD_CHAMPIONSHIP_RANK_THRESHOLD':
        raise SimpleContractTerminalError(f'DOT00001_GATE_DEFINITION_INVALID:{gate_definition}')
    target_rank = int(_first(p, 'DOT00001_TARGET_RANK', default=0) or 0)
    if target_rank < 1:
        raise SimpleContractTerminalError(f'DOT00001_TARGET_RANK_INVALID:{target_rank}')
    membership_rule = str(_first(p, 'DOT00001_MEMBERSHIP_RULE', default='')).upper()
    if 'AT_LEAST_ONE' not in membership_rule and 'AT LEAST ONE' not in membership_rule:
        raise SimpleContractTerminalError('DOT00001_MEMBERSHIP_RULE_NOT_AT_LEAST_ONE_WORLD')

    if not _truth(p, 'SAME_WORLD_DOMINANCE_PRUNING_COMPLETE', 'DOMINANCE_PRUNING_COMPLETE'):
        raise SimpleContractTerminalError('DOMINANCE_PRUNING_PROOF_MISSING')
    tol = float(_first(p, 'DOMINANCE_TOLERANCE', default=-1.0))
    if tol < 0:
        raise SimpleContractTerminalError('DOMINANCE_TOLERANCE_MISSING')

    ordinal = str(_first(p, 'ORDINAL_SELECTOR', 'GLOBAL_ORDINAL_SCORE_AUTHORITY', default=''))
    if ordinal != ORDINAL_AUTHORITY:
        raise SimpleContractTerminalError(f'ORDINAL_SELECTOR_INVALID:{ordinal}')
    if str(_first(p, 'ORDINAL_ROLE', default='')).upper() != 'RANK_ONLY':
        raise SimpleContractTerminalError('ORDINAL_NOT_RANK_ONLY')
    if _truth(p, 'ORDINAL_MEMBERSHIP_MUTATION_ALLOWED'):
        raise SimpleContractTerminalError('ORDINAL_MEMBERSHIP_MUTATION_PROHIBITED')
    if not _truth(p, 'ORDINAL_ORDERING_COMPLETE', 'ORDINAL_CHECKOFF_COMPLETE'):
        raise SimpleContractTerminalError('ORDINAL_ORDERING_CHECKOFF_MISSING')

    if _truth(p, 'BACKFILL_USED'):
        raise SimpleContractTerminalError('BACKFILL_PROHIBITED')
    if _truth(p, 'FORCED_BOARD_SIZE'):
        raise SimpleContractTerminalError('FORCED_BOARD_SIZE_PROHIBITED')

    survivors = int(_first(p, 'NON_DOMINATED_SURVIVORS', 'FINAL_BOARD_SIZE', default=-1) or 0)
    final_size = int(_first(p, 'FINAL_BOARD_SIZE', default=-2) or 0)
    if final_size != survivors:
        raise SimpleContractTerminalError(f'PORTFOLIO_NOT_SURVIVOR_SET:{final_size}!={survivors}')
    rows = _first(p, 'FINAL_BOARD', default=[])
    if not isinstance(rows, list) or len(rows) != final_size:
        raise SimpleContractTerminalError('FINAL_BOARD_ROWS_SIZE_MISMATCH')
    for i, row in enumerate(rows):
        if not isinstance(row, dict):
            raise SimpleContractTerminalError(f'FINAL_BOARD_ROW_INVALID:{i}')
        missing = [k for k in REQUIRED_ORDINAL_FIELDS if k not in row]
        if missing:
            raise SimpleContractTerminalError(f'ORDINAL_EVIDENCE_MISSING:{i}:' + ','.join(missing))

    return {
        'PATCH_ID': PATCH_ID,
        'STATUS': 'PASS',
        'CONFIGURED_MC_COUNT': int(configured_mc_count),
        'MC_WORLDS': worlds,
        'CHAMPIONSHIP_FAMILIES_IDENTIFIED': fam,
        'FAMILY_LEGAL_BRANCHES': legal,
        'FAMILY_BORN_BRANCHES': born,
        'FAMILY_SCORED_BRANCHES': scored,
        'DOT00001_GATE_THRESHOLD': DOT00001_THRESHOLD,
        'DOT00001_GATE_DEFINITION': gate_definition,
        'DOT00001_TARGET_RANK': target_rank,
        'ORDINAL_SELECTOR': ORDINAL_AUTHORITY,
        'ORDINAL_ROLE': 'RANK_ONLY',
        'FINAL_BOARD_SIZE': final_size,
        'NO_FORCED_BOARD_SIZE': True,
        'NO_BACKFILL': True,
        'PORTFOLIO_EQUALS_SURVIVOR_SET': True,
        'PRE_GATE_FAMILY_CAP_USED': False,
        'PRE_GATE_BRANCH_CAP_USED': False,
        'TOP_K_CLOSURE_CAP_USED': False,
        'PRE_SCORE_PRUNING_USED': False,
        'OLDER_SELECTION_PIPELINE_FALLBACK_USED': False,
    }
