from __future__ import annotations

"""Global pre-calibration sports strategy and salary-unlock layer.

The layer is deterministic, result-blind, player-name agnostic, and designed to
run after authoritative availability/lineup reconciliation but before Phase 1.
It converts sport-specific role evidence into opportunity, credibility, stale-
role suppression, and salary-unlock features. Engines remain responsible for
sport-native simulation; this module supplies the shared strategy contract.
"""

import hashlib
import importlib.util
import json
import math
import sys
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

_PREDICTIVE_PATH = Path(__file__).with_name("apex_global_predictive_market_layer_v1.py")
_predictive_spec = importlib.util.spec_from_file_location("apex_global_predictive_market_layer_v1", _PREDICTIVE_PATH)
if _predictive_spec is None or _predictive_spec.loader is None:
    raise RuntimeError("RUN_INVALID:GLOBAL_PREDICTIVE_MARKET_LAYER_UNAVAILABLE")
global_predictive = importlib.util.module_from_spec(_predictive_spec)
sys.modules.setdefault(_predictive_spec.name, global_predictive)
_predictive_spec.loader.exec_module(global_predictive)

PATCH_ID = "APEX_GLOBAL_SPORTS_STRATEGIST_AND_VALUE_UNLOCK_v1"
DOCTRINE_ID = PATCH_ID
PREDICTIVE_LAYER_PATCH_ID = global_predictive.PATCH_ID
CONTRACT_VERSION = "1.1"
LOAD_ORDER = "AFTER_PREDICTIVE_LAYER_FREEZE_BEFORE_PHASE1_CALIBRATION"

TEAM_MINUTE_SPORTS = {"WNBA": 200.0, "NBA": 240.0, "CBB": 200.0}
TEAM_OPPORTUNITY_SPORTS = {"WNBA", "NBA", "CBB", "NFL", "CFB", "NHL", "MLB"}
INDIVIDUAL_SPORTS = {"TENNIS", "PGA", "GOLF", "MMA", "UFC"}
SUPPORTED_SPORTS = TEAM_OPPORTUNITY_SPORTS | INDIVIDUAL_SPORTS

SPORT_PROFILES: dict[str, dict[str, Any]] = {
    "WNBA": {"mechanic": "MINUTES_USAGE_ROLE_TRANSFER", "dimensions": ("CREATION", "SCORING", "INTERIOR", "DEFENSE", "CLOSING"), "team_budget": 200.0},
    "NBA": {"mechanic": "MINUTES_USAGE_ROLE_TRANSFER", "dimensions": ("CREATION", "SCORING", "INTERIOR", "DEFENSE", "CLOSING"), "team_budget": 240.0},
    "CBB": {"mechanic": "MINUTES_USAGE_ROLE_TRANSFER", "dimensions": ("CREATION", "SCORING", "INTERIOR", "DEFENSE", "CLOSING"), "team_budget": 200.0},
    "MLB": {"mechanic": "LINEUP_PA_STARTER_BULLPEN_ROLE", "dimensions": ("BATTING_ORDER", "PLATE_APPEARANCE", "RUN_CREATION", "STARTER_LEASH", "BULLPEN_ROLE")},
    "NFL": {"mechanic": "SNAP_ROUTE_TOUCH_RED_ZONE_TRANSFER", "dimensions": ("SNAPS", "ROUTES", "TARGETS", "CARRIES", "RED_ZONE", "PROTECTION")},
    "CFB": {"mechanic": "SNAP_ROUTE_TOUCH_PACE_ROLE_TRANSFER", "dimensions": ("SNAPS", "ROUTES", "TARGETS", "CARRIES", "PACE", "ROLE_CERTAINTY")},
    "NHL": {"mechanic": "LINE_POWER_PLAY_GOALIE_ROLE_TRANSFER", "dimensions": ("EV_LINE", "POWER_PLAY", "SHOT_VOLUME", "BLOCKS", "GOALIE_START")},
    "TENNIS": {"mechanic": "MATCH_STATUS_SURFACE_SERVE_RETURN_VOLATILITY", "dimensions": ("MATCH_STATUS", "SURFACE", "SERVE", "RETURN", "FATIGUE", "VOLATILITY")},
    "PGA": {"mechanic": "ROUND_TEE_WEATHER_SCORING_ROLE", "dimensions": ("ROUND", "TEE_TIME", "WEATHER", "BIRDIE", "BOGEY_AVOIDANCE", "VOLATILITY")},
    "GOLF": {"mechanic": "ROUND_TEE_WEATHER_SCORING_ROLE", "dimensions": ("ROUND", "TEE_TIME", "WEATHER", "BIRDIE", "BOGEY_AVOIDANCE", "VOLATILITY")},
    "MMA": {"mechanic": "FIGHT_STATUS_STYLE_PACE_FINISH", "dimensions": ("FIGHT_STATUS", "STYLE_MATCHUP", "PACE", "TAKEDOWN", "FINISH", "DURABILITY")},
    "UFC": {"mechanic": "FIGHT_STATUS_STYLE_PACE_FINISH", "dimensions": ("FIGHT_STATUS", "STYLE_MATCHUP", "PACE", "TAKEDOWN", "FINISH", "DURABILITY")},
}

FORBIDDEN_FORWARD_FIELDS = {
    "ACTUAL_FPTS", "REALIZED_FPTS", "FINAL_RANK", "CONTEST_RANK", "WINNING_LINEUP",
    "POSTLOCK_SCORE", "TARGET_ACTUAL_SCORE", "FINAL_BOARD_RANKS",
}

class StrategyContractError(RuntimeError):
    pass


def _normalize(value: Any) -> str:
    return str(value or "").strip().upper().replace("-", "_").replace(" ", "_")


def _num(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        if isinstance(value, str):
            value = value.replace("%", "").replace("$", "").replace(",", "").strip()
            if value in {"", "-", "nan", "None"}:
                return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


def _records(data: Any) -> list[dict[str, Any]]:
    if hasattr(data, "to_dict"):
        return [dict(x) for x in data.to_dict("records")]
    if isinstance(data, Mapping):
        return [dict(data)]
    return [dict(x) for x in data]


def _column_map(rows: Sequence[Mapping[str, Any]]) -> dict[str, str]:
    keys: set[str] = set()
    for row in rows:
        keys.update(map(str, row.keys()))
    return {_normalize(k): k for k in keys}


def _get(row: Mapping[str, Any], cmap: Mapping[str, str], *names: str, default: Any = None) -> Any:
    for name in names:
        key = cmap.get(_normalize(name))
        if key is not None:
            return row.get(key, default)
    return default


def stable_hash(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def profile_for(sport: str, mode: str) -> dict[str, Any]:
    s = _normalize(sport)
    m = _normalize(mode)
    if s not in SPORT_PROFILES:
        raise StrategyContractError(f"RUN_INVALID:SPORTS_STRATEGY_PROFILE_UNDEFINED:{s}")
    return {"patch_id": PATCH_ID, "contract_version": CONTRACT_VERSION, "sport": s, "mode": m, **SPORT_PROFILES[s]}


def validate_strategy_adapter(
    sport: str,
    mode: str,
    available_fields: Iterable[str],
    *,
    executable_source_available: bool = True,
) -> dict[str, Any]:
    profile = profile_for(sport, mode)
    fields = {_normalize(x) for x in available_fields}
    forbidden = sorted(fields & FORBIDDEN_FORWARD_FIELDS)
    if forbidden:
        raise StrategyContractError("RUN_INVALID:POSTLOCK_FIELDS_ENTERED_STRATEGY_LAYER:" + ",".join(forbidden))
    if not executable_source_available:
        raise StrategyContractError(f"RUN_INVALID:SPORTS_STRATEGY_EXECUTABLE_SOURCE_UNAVAILABLE:{profile['sport']}:{profile['mode']}")
    core = {"PLAYER", "SAL"}
    if not core.issubset(fields):
        raise StrategyContractError("RUN_INVALID:SPORTS_STRATEGY_CORE_FIELDS_MISSING:" + ",".join(sorted(core-fields)))
    return {
        "STATUS": "PASS",
        "PATCH_ID": PATCH_ID,
        "LOAD_ORDER": LOAD_ORDER,
        "SPORT": profile["sport"],
        "MODE": profile["mode"],
        "MECHANIC": profile["mechanic"],
        "DIMENSIONS": list(profile["dimensions"]),
        "AVAILABLE_FIELD_HASH": stable_hash(sorted(fields)),
        "PLAYER_NAME_CONSTANTS_USED": False,
        "POSTLOCK_RESULTS_USED": False,
        "FAIL_CLOSED": True,
    }


class StrategyFeatures:
    __slots__ = ("opportunity_score", "role_credibility", "stale_role_suppressed", "direct_opportunity_absorber", "salary_unlock", "strategic_leverage", "predictive_features", "receipt")

    def __init__(self, opportunity_score: np.ndarray, role_credibility: np.ndarray, stale_role_suppressed: np.ndarray, direct_opportunity_absorber: np.ndarray, salary_unlock: np.ndarray, strategic_leverage: np.ndarray, predictive_features: Any, receipt: dict[str, Any]) -> None:
        self.opportunity_score = opportunity_score
        self.role_credibility = role_credibility
        self.stale_role_suppressed = stale_role_suppressed
        self.direct_opportunity_absorber = direct_opportunity_absorber
        self.salary_unlock = salary_unlock
        self.strategic_leverage = strategic_leverage
        self.predictive_features = predictive_features
        self.receipt = receipt


def _percentile(values: np.ndarray) -> np.ndarray:
    n = len(values)
    if n == 0:
        return np.asarray([], dtype=np.float32)
    order = np.argsort(values, kind="stable")
    out = np.empty(n, dtype=np.float64)
    sorted_vals = values[order]
    i = 0
    while i < n:
        j = i + 1
        while j < n and sorted_vals[j] == sorted_vals[i]:
            j += 1
        out[order[i:j]] = ((i + j - 1) / 2.0 + 0.5) / n
        i = j
    return out.astype(np.float32)


def build_strategy_features(data: Any, *, sport: str, mode: str) -> StrategyFeatures:
    rows = _records(data)
    if not rows:
        raise StrategyContractError("RUN_INVALID:SPORTS_STRATEGY_EMPTY_POOL")
    cmap = _column_map(rows)
    adapter = validate_strategy_adapter(sport, mode, cmap.values())
    s = adapter["SPORT"]
    predictive_features = global_predictive.build_predictive_features(rows, sport=sport, mode=mode)
    if not predictive_features.prediction_frozen:
        raise StrategyContractError("ENGINE_INTEGRITY_HALT:PREDICTION_NOT_FROZEN_BEFORE_STRATEGY")
    n = len(rows)
    salary = np.asarray([_num(_get(r, cmap, "SAL", "SALARY"), 0.0) for r in rows], dtype=np.float64)
    if np.any(salary <= 0):
        raise StrategyContractError("RUN_INVALID:SPORTS_STRATEGY_INVALID_SALARY")
    salary_relief = 1.0 - _percentile(salary)
    opportunity = np.zeros(n, dtype=np.float64)
    credibility = np.ones(n, dtype=np.float64)
    stale = np.zeros(n, dtype=bool)
    absorber = np.zeros(n, dtype=bool)

    if s in {"WNBA", "NBA", "CBB"}:
        current = np.asarray([_num(_get(r, cmap, "MIN", "PROJECTED_MINUTES"), 0.0) for r in rows])
        recent = np.asarray([_num(_get(r, cmap, "MIN.1", "RECENT_MINUTES", "L5_MIN"), 0.0) for r in rows])
        historical = np.asarray([_num(_get(r, cmap, "AMIN", "AVERAGE_MINUTES"), 0.0) for r in rows])
        lineup = np.asarray([_normalize(_get(r, cmap, "LINEUP", "STARTER_STATUS")) for r in rows], dtype=object)
        starter = np.isin(lineup, ["YES", "Y", "START", "STARTER"])
        bench = np.isin(lineup, ["BN", "BENCH", "OUT_OF_ROTATION"])
        stale = (historical >= 18.0) & (current < 12.0) & (recent < 6.0) & bench
        credibility = np.maximum.reduce((np.clip(current/24.0,0,1), .70*np.clip(recent/24.0,0,1), .95*starter.astype(float)))
        credibility = np.where(stale, np.minimum(credibility, .12), credibility)
        role_growth = np.maximum(0.0, np.maximum(recent, historical*.85)-current)
        opportunity = np.clip(.60*credibility + .40*np.clip(role_growth/12.0,0,1),0,1)
        absorber = (~stale) & (credibility >= .30) & ((starter) | (current >= 7.5) | (recent >= 10.0))
    elif s == "MLB":
        lineup_raw = [_normalize(_get(r, cmap, "LINEUP")) for r in rows]
        order = np.asarray([_num(x, 10.0) if re_fullmatch_digit_1_9(x) else 10.0 for x in lineup_raw])
        pos = np.asarray([_normalize(_get(r, cmap, "POS", "POSITION")) for r in rows], dtype=object)
        is_pitcher = pos == "P"
        is_sp = np.asarray([x == "SP" for x in lineup_raw])
        is_bench = np.asarray([x in {"BN", "BENCH", ""} for x in lineup_raw])
        team_runs = np.asarray([_num(_get(r, cmap, "T RUNS", "TEAM_TOTAL"), 4.5) for r in rows])
        order_edge = np.where(is_pitcher, np.where(is_sp, .72, .30), np.clip((10.0-order)/9.0,0,1))
        opportunity = np.clip(.65*order_edge + .20*_percentile(team_runs) + .15*salary_relief,0,1)
        credibility = np.where(is_bench, .05, np.where(is_pitcher, np.where(is_sp,.95,.35), .95))
        stale = is_bench
        absorber = (~stale) & (((~is_pitcher) & (order <= 6)) | is_sp)
    elif s in {"NFL", "CFB"}:
        snaps = np.asarray([_num(_get(r,cmap,"SNAPS","SNAP%","PROJECTED SNAPS"),0) for r in rows])
        routes = np.asarray([_num(_get(r,cmap,"ROUTES","ROUTE%"),0) for r in rows])
        touches = np.asarray([_num(_get(r,cmap,"TARGETS","CARRIES","TOUCHES"),0) for r in rows])
        opportunity = np.clip(.45*_percentile(snaps)+.30*_percentile(routes)+.25*_percentile(touches),0,1)
        credibility = np.clip(np.maximum(_percentile(snaps), _percentile(routes)),0,1)
        absorber = credibility >= .45
    elif s == "NHL":
        line = np.asarray([_num(_get(r,cmap,"LINE","EV LINE"),4) for r in rows])
        pp = np.asarray([_num(_get(r,cmap,"PP LINE","POWER PLAY"),3) for r in rows])
        shots = np.asarray([_num(_get(r,cmap,"SHOTS","SOG"),0) for r in rows])
        opportunity = np.clip(.45*np.clip((5-line)/4,0,1)+.30*np.clip((4-pp)/3,0,1)+.25*_percentile(shots),0,1)
        credibility = np.where(line<=3,.90,.45)
        absorber = credibility>=.55
    elif s == "TENNIS":
        projection = np.asarray([_num(_get(r,cmap,"FPTS","PROJECTION","WEAK_PROJECTION"),0) for r in rows])
        value = np.asarray([_num(_get(r,cmap,"VAL","VALUE"),0) for r in rows])
        win = np.asarray([_num(_get(r,cmap,"WIN %","WIN_PROBABILITY"),0) for r in rows])
        if win.max(initial=0) > 1.0: win /= 100.0
        opportunity = np.clip(.45*_percentile(projection)+.35*_percentile(value)+.20*_percentile(win),0,1)
        credibility = np.where(projection>0,.90,.55)
        absorber = credibility>=.50
    elif s in {"PGA", "GOLF"}:
        birdie = np.asarray([_num(_get(r,cmap,"BIRDIE RATE","BIRDIE%","BIRDIES"),0) for r in rows])
        bogey = np.asarray([_num(_get(r,cmap,"BOGEY AVOIDANCE","BOGEY%"),0) for r in rows])
        projection = np.asarray([_num(_get(r,cmap,"FPTS","PROJECTION"),0) for r in rows])
        opportunity = np.clip(.45*_percentile(birdie)+.35*_percentile(projection)+.20*_percentile(-bogey),0,1)
        credibility = np.where(projection>0,.88,.50)
        absorber = credibility>=.50
    elif s in {"MMA", "UFC"}:
        win = np.asarray([_num(_get(r,cmap,"WIN %","WIN_PROBABILITY"),0) for r in rows])
        finish = np.asarray([_num(_get(r,cmap,"FINISH %","FINISH_PROBABILITY","ITD"),0) for r in rows])
        pace = np.asarray([_num(_get(r,cmap,"PACE","SIG STR","TAKEDOWNS"),0) for r in rows])
        if win.max(initial=0)>1: win/=100.0
        if finish.max(initial=0)>1: finish/=100.0
        opportunity = np.clip(.45*_percentile(win)+.35*_percentile(finish)+.20*_percentile(pace),0,1)
        credibility = np.where(win>0,.90,.50)
        absorber = credibility>=.50
    else:
        raise StrategyContractError(f"RUN_INVALID:SPORTS_STRATEGY_PROFILE_UNDEFINED:{s}")

    # Prediction-first handoff. The strategist consumes only frozen derived
    # probabilities/context; raw market lines and raw model means are not exported
    # into Phase 1. Role credibility remains authoritative, while predictive
    # evidence changes how the strategist interprets upside and game environment.
    predictive_evidence = predictive_features.player_market_available | predictive_features.game_market_available
    predictive_confidence = predictive_features.confidence.astype(np.float64)
    predictive_upside = predictive_features.dfs_upside_score.astype(np.float64)
    opportunity_blend = np.where(predictive_evidence, 0.10 + 0.20 * predictive_confidence, 0.0)
    opportunity = np.clip((1.0 - opportunity_blend) * opportunity + opportunity_blend * predictive_upside, 0.0, 1.0)

    # Legitimate salary unlock still requires inexpensive salary and current
    # sport-native opportunity. A betting signal alone cannot manufacture value.
    salary_unlock = (~stale) & absorber & (salary_relief >= .45) & (opportunity >= .45) & (credibility >= .30)
    leverage = np.clip(.62*opportunity + .23*salary_relief + .15*credibility,0,1)
    market_edge_score = np.clip(0.5 + predictive_features.edge.astype(np.float64) / 0.20, 0.0, 1.0)
    predictive_leverage = np.clip(0.70 * predictive_upside + 0.30 * market_edge_score, 0.0, 1.0)
    leverage_blend = np.where(predictive_evidence, 0.08 + 0.12 * predictive_confidence, 0.0)
    leverage = np.clip((1.0 - leverage_blend) * leverage + leverage_blend * predictive_leverage, 0.0, 1.0)
    leverage = np.where(stale, 0.0, leverage)
    receipt = {
        **adapter,
        "ROW_COUNT": n,
        "SALARY_UNLOCK_COUNT": int(salary_unlock.sum()),
        "DIRECT_OPPORTUNITY_ABSORBER_COUNT": int(absorber.sum()),
        "STALE_ROLE_SUPPRESSED_COUNT": int(stale.sum()),
        "PREDICTIVE_LAYER_PATCH_ID": predictive_features.receipt["PATCH_ID"],
        "PREDICTIVE_LAYER_STATUS": predictive_features.receipt["STATUS"],
        "PREDICTION_HASH": predictive_features.receipt["PREDICTION_HASH"],
        "RAW_MARKET_INPUT_HASH": predictive_features.receipt["RAW_MARKET_INPUT_HASH"],
        "PLAYER_MARKET_ROWS": predictive_features.receipt["PLAYER_MARKET_ROWS"],
        "GAME_MARKET_ROWS": predictive_features.receipt["GAME_MARKET_ROWS"],
        "MORE_DECISIONS": predictive_features.receipt["MORE_DECISIONS"],
        "LESS_DECISIONS": predictive_features.receipt["LESS_DECISIONS"],
        "PASS_DECISIONS": predictive_features.receipt["PASS_DECISIONS"],
        "STALE_LINE_SIGNALS": predictive_features.receipt["STALE_LINE_SIGNALS"],
        "PREDICTION_FROZEN": predictive_features.receipt["PREDICTION_FROZEN"],
        "STRATEGY_CONSUMED_PREDICTION_HASH": predictive_features.receipt["PREDICTION_HASH"],
        "FEATURE_HASH": stable_hash({
            "opportunity": np.round(opportunity,6).tolist(),
            "credibility": np.round(credibility,6).tolist(),
            "stale": stale.astype(int).tolist(),
            "absorber": absorber.astype(int).tolist(),
            "unlock": salary_unlock.astype(int).tolist(),
            "leverage": np.round(leverage,6).tolist(),
            "prediction_hash": predictive_features.receipt["PREDICTION_HASH"],
        }),
    }
    receipt["CONTRACT_HASH"] = stable_hash(receipt)
    return StrategyFeatures(
        opportunity.astype(np.float32), credibility.astype(np.float32), stale,
        absorber, salary_unlock, leverage.astype(np.float32), predictive_features, receipt,
    )


def re_fullmatch_digit_1_9(value: str) -> bool:
    return len(value) == 1 and value in "123456789"


def projection_multiplier(features: StrategyFeatures, *, minimum: float = 0.98, maximum: float = 1.03) -> np.ndarray:
    if maximum < minimum:
        raise ValueError("maximum must be >= minimum")
    scaled = minimum + (maximum-minimum)*features.strategic_leverage
    scaled = np.where(features.stale_role_suppressed, minimum, scaled)
    return scaled.astype(np.float32)
