from __future__ import annotations

import itertools
import json
import math
from pathlib import Path
from typing import Any, Iterable, Iterator, Protocol, Sequence

import numpy as np
import pandas as pd

from engines.common.apex_global_complete_ordinal_evidence_v1 import (
    MC_WORLDS,
    DOT00001_THRESHOLD,
    ORDINAL_AUTHORITY,
    rank_all_survivors,
    target_rank_for_field,
)

PATCH_ID = "APEX_GLOBAL_EXHAUSTIVE_CHAMPIONSHIP_PIPELINE_v2"
DOMINANCE_TOLERANCE = 1e-6
DEFAULT_ROW_CHUNK = 128


class ChampionshipAdapter(Protocol):
    sport: str
    mode: str
    roster_size: int
    core_size: int
    has_cpt: bool
    player_count: int

    def simulate(self, worlds: int, seed: int) -> tuple[np.ndarray, dict[str, Any]]: ...
    def iter_legal_rows(self, chunk_size: int = DEFAULT_ROW_CHUNK) -> Iterator[np.ndarray]: ...
    def score_rows(self, rows: np.ndarray, sims: np.ndarray) -> np.ndarray: ...
    def lineup_identity(self, row: np.ndarray) -> tuple[int, ...]: ...
    def cpt_player(self, row: np.ndarray) -> int | None: ...
    def player_name(self, player_id: int) -> str: ...
    def render_row(self, row: np.ndarray) -> dict[str, Any]: ...


def _topk_update(top: np.ndarray, scores: np.ndarray) -> np.ndarray:
    if scores.size == 0:
        return top
    k = int(top.shape[0])
    combo = np.concatenate([top, np.asarray(scores, dtype=np.float32)], axis=0)
    if combo.shape[0] <= k:
        return np.sort(combo, axis=0)[-k:]
    return np.partition(combo, -k, axis=0)[-k:]


def _row_components(identity: tuple[int, ...], core_size: int) -> tuple[list[tuple[int, ...]], list[tuple[int, ...]], list[tuple[int, ...]]]:
    ident = tuple(sorted(int(x) for x in identity))
    return (
        [tuple(x) for x in itertools.combinations(ident, 2)],
        [tuple(x) for x in itertools.combinations(ident, 3)],
        [tuple(x) for x in itertools.combinations(ident, int(core_size))],
    )


def _mask_or(store: dict[Any, np.ndarray], key: Any, mask: np.ndarray) -> None:
    packed = np.packbits(np.asarray(mask, dtype=np.uint8), bitorder="little")
    if key in store:
        np.bitwise_or(store[key], packed, out=store[key])
    else:
        store[key] = packed.copy()


def _packed_count(packed: np.ndarray | None, worlds: int) -> int:
    if packed is None:
        return 0
    bits = np.unpackbits(np.asarray(packed, dtype=np.uint8), bitorder="little", count=int(worlds))
    return int(bits.sum())


def _pressure_summary(values: np.ndarray) -> dict[str, float]:
    v = np.asarray(values, dtype=np.float64)
    v = v[np.isfinite(v)]
    if v.size == 0:
        return {"mean": 0.0, "median": 0.0, "p90": 0.0}
    return {
        "mean": float(np.mean(v)),
        "median": float(np.median(v)),
        "p90": float(np.quantile(v, 0.90)),
    }


def _strict_same_world_dominance(scores: np.memmap, tolerance: float = DOMINANCE_TOLERANCE) -> tuple[np.ndarray, int]:
    n = int(scores.shape[0])
    dominated = np.zeros(n, dtype=bool)
    tol = float(tolerance)
    for i in range(n):
        if dominated[i]:
            continue
        a = np.asarray(scores[i], dtype=np.float32)
        for j in range(n):
            if i == j or dominated[i]:
                continue
            b = np.asarray(scores[j], dtype=np.float32)
            if bool(np.all(b >= a - tol)) and bool(np.any(b > a + tol)):
                dominated[i] = True
                break
    keep = np.flatnonzero(~dominated).astype(np.int32)
    return keep, int(dominated.sum())


def _component_record(
    key: tuple[int, ...],
    adapter: ChampionshipAdapter,
    masks: dict[tuple[int, ...], np.ndarray],
    opportunity_lineups: dict[tuple[int, ...], int],
    success_events: dict[tuple[int, ...], int],
    worlds: int,
    baseline_success_probability: float,
) -> dict[str, Any]:
    supported_worlds = _packed_count(masks.get(key), worlds)
    eligible_lineups = int(opportunity_lineups.get(key, 0))
    eligible_lineup_worlds = int(eligible_lineups * int(worlds))
    successes = int(success_events.get(key, 0))
    conditional_probability = float(successes) / float(eligible_lineup_worlds) if eligible_lineup_worlds > 0 else 0.0
    conditional_lift = conditional_probability / baseline_success_probability if baseline_success_probability > 0 else 0.0
    eligible_worlds = int(worlds) if eligible_lineups > 0 else 0
    opp_norm = float(supported_worlds) / float(eligible_worlds) if eligible_worlds > 0 else 0.0
    return {
        "player_ids": [int(x) for x in key],
        "players": [adapter.player_name(int(x)) for x in key],
        "distinct_qualifying_worlds": supported_worlds,
        "eligible_lineups": eligible_lineups,
        "eligible_worlds": eligible_worlds,
        "eligible_lineup_worlds": eligible_lineup_worlds,
        "qualifying_lineup_world_events": successes,
        "conditional_success_probability": conditional_probability,
        "baseline_success_probability": baseline_success_probability,
        "conditional_lift": conditional_lift,
        "opportunity_normalized_recurrence": opp_norm,
    }


def run_global_contract(
    adapter: ChampionshipAdapter,
    *,
    field_size: int,
    execution_id: str,
    board_path: str | Path,
    receipt_path: str | Path,
    seed: int,
    row_chunk: int = DEFAULT_ROW_CHUNK,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Literal global APEX simple contract.

    Order is fixed:
      200K MC -> complete-surface championship discovery -> exhaustive neighborhood
      -> exact common-world scoring -> same-world .00001 target-rank gate
      -> strict same-world dominance -> complete rank-only ordinal.

    Sport adapters own only simulation, roster legality, row enumeration and scoring.
    No adapter selector/orderer is called here.
    """
    worlds = MC_WORLDS
    field_size = int(field_size)
    if field_size <= 0:
        raise RuntimeError("RUN_INVALID:FIELD_SIZE_NONPOSITIVE")
    target_rank = target_rank_for_field(field_size)
    top_keep = max(10, int(target_rank))
    board_path = Path(board_path).resolve()
    receipt_path = Path(receipt_path).resolve()
    out_dir = board_path.parent
    out_dir.mkdir(parents=True, exist_ok=True)

    # STEP 1: MC first. No lineup selector runs before this call.
    sims, simulation_receipt = adapter.simulate(worlds, int(seed))
    sims = np.asarray(sims, dtype=np.float32)
    if sims.ndim != 2 or int(sims.shape[1]) != worlds:
        raise RuntimeError(f"RUN_INVALID:SPORT_ADAPTER_MC_SHAPE:{sims.shape}")

    # Complete legal surface pass. This is discovery/scoring infrastructure, not membership.
    top = np.full((top_keep, worlds), -np.inf, dtype=np.float32)
    winner = np.full(worlds, -np.inf, dtype=np.float32)
    best_without = np.full((int(adapter.player_count), worlds), -np.inf, dtype=np.float32)
    best_cpt_forbidden = np.full((int(adapter.player_count), worlds), -np.inf, dtype=np.float32) if adapter.has_cpt else None
    legal_surface_count = 0

    for rows in adapter.iter_legal_rows(int(row_chunk)):
        rows = np.asarray(rows, dtype=np.int32)
        if rows.size == 0:
            continue
        sc = np.asarray(adapter.score_rows(rows, sims), dtype=np.float32)
        if sc.shape != (len(rows), worlds):
            raise RuntimeError(f"RUN_INVALID:SPORT_ADAPTER_SCORE_SHAPE:{sc.shape}")
        legal_surface_count += int(len(rows))
        top = _topk_update(top, sc)
        winner = np.maximum(winner, np.max(sc, axis=0))
        identities = [set(adapter.lineup_identity(r)) for r in rows]
        for p in range(int(adapter.player_count)):
            mask = np.fromiter((p not in ident for ident in identities), dtype=bool, count=len(identities))
            if np.any(mask):
                best_without[p] = np.maximum(best_without[p], np.max(sc[mask], axis=0))
            if adapter.has_cpt and best_cpt_forbidden is not None:
                cmask = np.fromiter((adapter.cpt_player(r) != p for r in rows), dtype=bool, count=len(rows))
                if np.any(cmask):
                    best_cpt_forbidden[p] = np.maximum(best_cpt_forbidden[p], np.max(sc[cmask], axis=0))

    if legal_surface_count <= 0:
        raise RuntimeError("RUN_INVALID:ZERO_COMPLETE_LEGAL_SURFACE")

    top = np.sort(top, axis=0)
    target_threshold = top[-int(target_rank)]
    top1_threshold = top[-1]
    top3_threshold = top[-min(3, top_keep)]
    top10_threshold = top[-min(10, top_keep)]

    # Discovery uses the entire complete legal surface. No top-player, CPT, FLEX,
    # position, team, family or top-K discovery pool is permitted.
    discovered_rows: list[np.ndarray] = []
    discovered_cores: set[tuple[int, ...]] = set()
    discovered_cpt_lanes: set[int] = set()
    discovery_qualifying_world_events = 0
    for rows in adapter.iter_legal_rows(int(row_chunk)):
        rows = np.asarray(rows, dtype=np.int32)
        if rows.size == 0:
            continue
        sc = np.asarray(adapter.score_rows(rows, sims), dtype=np.float32)
        qual = sc >= (target_threshold[None, :] - DOMINANCE_TOLERANCE)
        for i in np.flatnonzero(np.any(qual, axis=1)):
            row = rows[int(i)].copy()
            discovered_rows.append(row)
            ident = adapter.lineup_identity(row)
            for core in itertools.combinations(sorted(ident), int(adapter.core_size)):
                discovered_cores.add(tuple(int(x) for x in core))
            cpt = adapter.cpt_player(row)
            if cpt is not None:
                discovered_cpt_lanes.add(int(cpt))
            discovery_qualifying_world_events += int(np.count_nonzero(qual[int(i)]))

    # STEP 2: exhaustive closure of every discovered championship neighborhood.
    # Membership is still unset. Only exact duplicate rows are removed.
    closure_seen: set[tuple[int, ...]] = set()
    closure_rows: list[np.ndarray] = []
    gated_rows: list[np.ndarray] = []
    gated_masks: list[np.ndarray] = []
    family_branch_count: dict[tuple[int, ...], int] = {core: 0 for core in discovered_cores}
    pair_opportunities: dict[tuple[int, ...], int] = {}
    trio_opportunities: dict[tuple[int, ...], int] = {}
    core_opportunities: dict[tuple[int, ...], int] = {}

    for rows in adapter.iter_legal_rows(int(row_chunk)):
        for raw in np.asarray(rows, dtype=np.int32):
            ident = adapter.lineup_identity(raw)
            row_cores = [tuple(int(x) for x in x) for x in itertools.combinations(sorted(ident), int(adapter.core_size))]
            matched = [core for core in row_cores if core in discovered_cores]
            if not matched:
                continue
            row_key = tuple(int(x) for x in raw.tolist())
            if row_key in closure_seen:
                continue
            closure_seen.add(row_key)
            row = np.asarray(raw, dtype=np.int32).copy()
            closure_rows.append(row)
            for core in matched:
                family_branch_count[core] = int(family_branch_count.get(core, 0)) + 1
            pairs, trios, cores = _row_components(ident, int(adapter.core_size))
            for key in pairs:
                pair_opportunities[key] = int(pair_opportunities.get(key, 0)) + 1
            for key in trios:
                trio_opportunities[key] = int(trio_opportunities.get(key, 0)) + 1
            for key in cores:
                core_opportunities[key] = int(core_opportunities.get(key, 0)) + 1

    closure_count = int(len(closure_rows))
    if discovered_cores and closure_count <= 0:
        raise RuntimeError("RUN_INVALID:DISCOVERED_CHAMPIONSHIP_NEIGHBORHOOD_ZERO_CLOSURE")

    # Exact common-world scoring and hard target-rank gate. Any lineup that reaches
    # TARGET_RANK or better in >=1 frozen world survives membership admission.
    for start in range(0, closure_count, int(row_chunk)):
        chunk = np.asarray(closure_rows[start:start + int(row_chunk)], dtype=np.int32)
        if len(chunk) == 0:
            continue
        sc = np.asarray(adapter.score_rows(chunk, sims), dtype=np.float32)
        qual = sc >= (target_threshold[None, :] - DOMINANCE_TOLERANCE)
        for i in np.flatnonzero(np.any(qual, axis=1)):
            gated_rows.append(chunk[int(i)].copy())
            gated_masks.append(np.packbits(qual[int(i)].astype(np.uint8), bitorder="little"))

    gated = np.asarray(gated_rows, dtype=np.int32) if gated_rows else np.empty((0, int(adapter.roster_size)), dtype=np.int32)

    # Materialize exact gated common-world score vectors once. This is after the gate.
    # A zero-survivor gate is a valid terminal membership state; do not create a
    # zero-length memmap for it.
    score_file = out_dir / "DOT00001_GATED_COMMON_WORLD_SCORES.f32"
    if len(gated):
        gated_scores = np.memmap(score_file, mode="w+", dtype=np.float32, shape=(len(gated), worlds))
        for start in range(0, len(gated), int(row_chunk)):
            chunk = gated[start:start + int(row_chunk)]
            if len(chunk):
                gated_scores[start:start + len(chunk)] = adapter.score_rows(chunk, sims)
        gated_scores.flush()
        keep_local, dominated_count = _strict_same_world_dominance(gated_scores, DOMINANCE_TOLERANCE)
    else:
        gated_scores = None
        keep_local = np.empty(0, dtype=np.int32)
        dominated_count = 0

    # STEP 3a: strict same-world dominance after gate only.
    survivor_rows = gated[keep_local] if len(keep_local) else np.empty((0, int(adapter.roster_size)), dtype=np.int32)

    # Complete component-level ordinal evidence is computed from all gated qualifiers.
    pair_masks: dict[tuple[int, ...], np.ndarray] = {}
    trio_masks: dict[tuple[int, ...], np.ndarray] = {}
    core_masks: dict[tuple[int, ...], np.ndarray] = {}
    cpt_masks: dict[int, np.ndarray] = {}
    pair_success_events: dict[tuple[int, ...], int] = {}
    trio_success_events: dict[tuple[int, ...], int] = {}
    core_success_events: dict[tuple[int, ...], int] = {}
    total_success_events = 0

    for i, row in enumerate(gated):
        sc = np.asarray(gated_scores[i], dtype=np.float32)
        target_mask = sc >= (target_threshold - DOMINANCE_TOLERANCE)
        success_count = int(np.count_nonzero(target_mask))
        total_success_events += success_count
        ident = adapter.lineup_identity(row)
        pairs, trios, cores = _row_components(ident, int(adapter.core_size))
        for key in pairs:
            _mask_or(pair_masks, key, target_mask)
            pair_success_events[key] = int(pair_success_events.get(key, 0)) + success_count
        for key in trios:
            _mask_or(trio_masks, key, target_mask)
            trio_success_events[key] = int(trio_success_events.get(key, 0)) + success_count
        for key in cores:
            _mask_or(core_masks, key, target_mask)
            core_success_events[key] = int(core_success_events.get(key, 0)) + success_count
        cpt = adapter.cpt_player(row)
        if cpt is not None:
            one_mask = sc >= (top1_threshold - DOMINANCE_TOLERANCE)
            _mask_or(cpt_masks, int(cpt), one_mask)

    baseline_success_probability = (
        float(total_success_events) / float(max(1, closure_count) * worlds)
        if closure_count > 0 else 0.0
    )

    survivor_records: list[dict[str, Any]] = []
    for local_index, gated_index in enumerate(keep_local.tolist()):
        row = gated[int(gated_index)]
        sc = np.asarray(gated_scores[int(gated_index)], dtype=np.float32)
        ident = adapter.lineup_identity(row)
        pairs, trios, cores = _row_components(ident, int(adapter.core_size))
        target_mask = sc >= (target_threshold - DOMINANCE_TOLERANCE)
        one_mask = sc >= (top1_threshold - DOMINANCE_TOLERANCE)
        top3_mask = sc >= (top3_threshold - DOMINANCE_TOLERANCE)
        top10_mask = sc >= (top10_threshold - DOMINANCE_TOLERANCE)

        pair_components = [_component_record(k, adapter, pair_masks, pair_opportunities, pair_success_events, worlds, baseline_success_probability) for k in pairs]
        trio_components = [_component_record(k, adapter, trio_masks, trio_opportunities, trio_success_events, worlds, baseline_success_probability) for k in trios]
        core_components = [_component_record(k, adapter, core_masks, core_opportunities, core_success_events, worlds, baseline_success_probability) for k in cores]

        # Replacement pressure definition is exact and world-native:
        # winner_score - best complete legal score with player excluded.
        rp_components = []
        rp_vectors = []
        for p in ident:
            alt = np.asarray(best_without[int(p)], dtype=np.float32)
            valid = np.isfinite(alt)
            pressure = np.where(valid, winner - alt, np.nan)
            summary = _pressure_summary(pressure)
            rp_components.append({"player_id": int(p), "player": adapter.player_name(int(p)), **summary})
            rp_vectors.append(pressure)
        rp_all = np.concatenate([np.asarray(x, dtype=np.float64) for x in rp_vectors]) if rp_vectors else np.empty(0, dtype=np.float64)
        rp_summary = _pressure_summary(rp_all)

        cpt = adapter.cpt_player(row)
        if cpt is not None and best_cpt_forbidden is not None:
            alt = np.asarray(best_cpt_forbidden[int(cpt)], dtype=np.float32)
            valid = np.isfinite(alt)
            cpt_pressure_vector = np.where(valid, winner - alt, np.nan)
            cpt_summary = _pressure_summary(cpt_pressure_vector)
            cpt_component = {"player_id": int(cpt), "player": adapter.player_name(int(cpt)), **cpt_summary}
            cpt_count = _packed_count(cpt_masks.get(int(cpt)), worlds)
        else:
            cpt_summary = {"mean": 0.0, "median": 0.0, "p90": 0.0}
            cpt_component = {"applicable": False}
            cpt_count = 0

        pair_count = int(sum(int(x["distinct_qualifying_worlds"]) for x in pair_components))
        trio_count = int(sum(int(x["distinct_qualifying_worlds"]) for x in trio_components))
        core_count = int(sum(int(x["distinct_qualifying_worlds"]) for x in core_components))
        cond_lift = float(np.mean([float(x["conditional_lift"]) for x in core_components])) if core_components else 0.0
        opp_norm = float(np.mean([float(x["opportunity_normalized_recurrence"]) for x in core_components])) if core_components else 0.0

        record = dict(adapter.render_row(row))
        record.update({
            "LINEUP_KEY": "|".join(str(x) for x in row.tolist()),
            "DOT00001_TARGET_RANK": int(target_rank),
            "TARGET_RANK_COUNT": int(np.count_nonzero(target_mask)),
            "TARGET_RANK_RATE_EXACT": float(np.count_nonzero(target_mask)) / float(worlds),
            "#1_COUNT": int(np.count_nonzero(one_mask)),
            "#1_RATE_EXACT": float(np.count_nonzero(one_mask)) / float(worlds),
            "CPT_#1_COUNT": int(cpt_count),
            "CPT_#1_RATE_EXACT": float(cpt_count) / float(worlds),
            "REPLACEMENT_PRESSURE": float(rp_summary["mean"]),
            "REPLACEMENT_PRESSURE_MEAN": float(rp_summary["mean"]),
            "REPLACEMENT_PRESSURE_MEDIAN": float(rp_summary["median"]),
            "REPLACEMENT_PRESSURE_P90": float(rp_summary["p90"]),
            "REPLACEMENT_PRESSURE_COMPONENTS": json.dumps(rp_components, separators=(",", ":"), sort_keys=True),
            "CPT_ROLE_PRESSURE": float(cpt_summary["mean"]),
            "CPT_ROLE_PRESSURE_COMPONENT": json.dumps(cpt_component, separators=(",", ":"), sort_keys=True),
            "PAIR_#1_COUNT": pair_count,
            "TRIO_#1_COUNT": trio_count,
            "CORE_#1_COUNT": core_count,
            "PAIR_#1_COMPONENTS": json.dumps(pair_components, separators=(",", ":"), sort_keys=True),
            "TRIO_#1_COMPONENTS": json.dumps(trio_components, separators=(",", ":"), sort_keys=True),
            "CORE_#1_COMPONENTS": json.dumps(core_components, separators=(",", ":"), sort_keys=True),
            "DISTINCT_WORLD_SUPPORT": int(np.count_nonzero(target_mask)),
            "CONDITIONAL_LIFT": cond_lift,
            "OPPORTUNITY_NORMALIZED_RECURRENCE": opp_norm,
            "TOP3_COUNT": int(np.count_nonzero(top3_mask)),
            "TOP10_COUNT": int(np.count_nonzero(top10_mask)),
        })
        survivor_records.append(record)

    # STEP 3b: ordinal is rank-only. No membership mutation, no board truncation.
    ordered, ordinal_receipt = rank_all_survivors(survivor_records)
    board_df = pd.DataFrame(ordered)
    board_df.to_csv(board_path, index=False)

    family_ledger = []
    for i, core in enumerate(sorted(discovered_cores)):
        count = int(family_branch_count.get(core, 0))
        family_ledger.append({
            "family_id": f"CORE_{int(adapter.core_size)}_{i:08d}",
            "core_player_ids": [int(x) for x in core],
            "core_players": [adapter.player_name(int(x)) for x in core],
            "legal_branch_count": count,
            "born_branch_count": count,
            "scored_branch_count": count,
            "closure_complete": True,
            "branch_quota": None,
        })

    covered_cpt_lanes = set()
    if adapter.has_cpt:
        for row in closure_rows:
            cpt = adapter.cpt_player(row)
            if cpt is not None:
                covered_cpt_lanes.add(int(cpt))

    payload: dict[str, Any] = {
        "RUN_STATE": "BOARD_READY",
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
        "STATE_VERSION": "1.33.445",
        "PATCH_ID": PATCH_ID,
        "SPORT": str(adapter.sport).upper(),
        "MODE": str(adapter.mode).upper(),
        "EXECUTION_ID": str(execution_id),
        "MC_WORLDS": worlds,
        "MC_FIRST_COMPLETE": True,
        "SPORT_ADAPTER_OWNS": ["SIMULATION_LOGIC", "ROSTER_LEGALITY", "SCORING_LOGIC"],
        "OLDER_SELECTION_PIPELINE_FALLBACK_USED": False,
        "COMPLETE_LEGAL_DISCOVERY_SURFACE": True,
        "DISCOVERY_LEGAL_LINEUPS": legal_surface_count,
        "DISCOVERY_RESTRICTIVE_PLAYER_POOL_USED": False,
        "DISCOVERY_CPT_TOP_PLAYER_LIMIT_USED": False,
        "DISCOVERY_FLEX_TOP_PLAYER_LIMIT_USED": False,
        "DISCOVERY_BOUNDED_POSITION_ADDITIONS_USED": False,
        "DISCOVERY_BOUNDED_TEAM_ADDITIONS_USED": False,
        "CHAMPIONSHIP_DISCOVERY_LINEUPS": len(discovered_rows),
        "CHAMPIONSHIP_CORE_SIZE": int(adapter.core_size),
        "CHAMPIONSHIP_CORE_COUNT": len(discovered_cores),
        "CHAMPIONSHIP_FAMILIES_IDENTIFIED": len(discovered_cores),
        "CHAMPIONSHIP_FAMILIES": [list(x) for x in sorted(discovered_cores)],
        "CPT_LANE_COVERAGE_COMPLETE": (not adapter.has_cpt) or discovered_cpt_lanes.issubset(covered_cpt_lanes),
        "MANDATORY_CPT_LANES": len(discovered_cpt_lanes),
        "COVERED_CPT_LANES": len(discovered_cpt_lanes.intersection(covered_cpt_lanes)),
        "MISSING_CPT_LANES": sorted(int(x) for x in discovered_cpt_lanes - covered_cpt_lanes),
        "PRE_GATE_FAMILY_CAP_USED": False,
        "PRE_GATE_BRANCH_CAP_USED": False,
        "TOP_K_CLOSURE_CAP_USED": False,
        "PRE_SCORE_PRUNING_USED": False,
        "EXACT_DUPLICATE_REMOVAL_ONLY_BEFORE_SCORING": True,
        "CHAMPIONSHIP_NEIGHBORHOOD_EXHAUSTED": True,
        "FULL_FAMILY_CLOSURE_COMPLETE": True,
        "FAMILY_CLOSURE_LEDGER_PRESENT": True,
        "FAMILY_CLOSURE_LEDGER": family_ledger,
        "FAMILY_LEGAL_BRANCHES": closure_count,
        "FAMILY_BORN_BRANCHES": closure_count,
        "FAMILY_SCORED_BRANCHES": closure_count,
        "SCORE_EVERY_COMPLETE_LEGAL_BUILD": True,
        "EXACT_COMMON_WORLD_SCORING_COMPLETE": True,
        "DOT00001_GATE_THRESHOLD": DOT00001_THRESHOLD,
        "DOT00001_GATE_DEFINITION": "SAME_WORLD_CHAMPIONSHIP_RANK_THRESHOLD",
        "DOT00001_TARGET_RANK": int(target_rank),
        "DOT00001_MEMBERSHIP_RULE": "KEEP_IF_TARGET_RANK_OR_BETTER_IN_AT_LEAST_ONE_OF_200000_FROZEN_WORLDS",
        "DOT00001_GATE_COMPLETE": True,
        "DOT00001_QUALIFIERS": int(len(gated)),
        "SAME_WORLD_DOMINANCE_PRUNING_COMPLETE": True,
        "DOMINANCE_TOLERANCE": float(DOMINANCE_TOLERANCE),
        "DOMINANCE_RULE": "REMOVE_ONLY_IF_ANOTHER_SURVIVOR_IS_NO_WORSE_IN_EVERY_COMMON_WORLD_AND_STRICTLY_BETTER_IN_AT_LEAST_ONE",
        "DOMINATED_PRUNED": int(dominated_count),
        "NON_DOMINATED_SURVIVORS": int(len(ordered)),
        "ORDINAL_SELECTOR": ORDINAL_AUTHORITY,
        "GLOBAL_ORDINAL_SCORE_AUTHORITY": ORDINAL_AUTHORITY,
        "ORDINAL_ROLE": "RANK_ONLY",
        "ORDINAL_MEMBERSHIP_MUTATION_ALLOWED": False,
        "ORDINAL_ORDERING_COMPLETE": True,
        "ORDINAL_CHECKOFF_COMPLETE": True,
        "ORDINAL_RECEIPT": ordinal_receipt,
        "ORDINAL_COMPONENT_EVIDENCE_PRESERVED": True,
        "REPLACEMENT_PRESSURE_FORMULA": "PLAYER_WORLD: WINNER_SCORE - BEST_COMPLETE_LEGAL_SCORE_WITH_PLAYER_EXCLUDED; LINEUP MEAN/MEDIAN/P90 OVER ALL LINEUP_PLAYER_X_WORLD COMPONENT VALUES",
        "CPT_ROLE_PRESSURE_FORMULA": "CPT_PLAYER_WORLD: WINNER_SCORE - BEST_COMPLETE_LEGAL_SCORE_WITH_PLAYER_FORBIDDEN_AT_CPT_BUT_ALLOWED_AT_FLEX; LINEUP VALUE=MEAN_ACROSS_WORLDS",
        "PAIR_TRIO_CORE_COUNT_FORMULA": "SUM_OF_COMPONENT_DISTINCT_QUALIFYING_WORLD_COUNTS; EACH_COMPONENT_COUNTS_EACH_WORLD_AT_MOST_ONCE",
        "CONDITIONAL_LIFT_FORMULA": "COMPONENT: P(TARGET_RANK_SUCCESS | COMPONENT_PRESENT_IN_LEGAL_LINEUP_WORLD_OPPORTUNITY) / BASELINE_P(TARGET_RANK_SUCCESS); LINEUP=MEAN_OF_EXPLICIT_CORE_COMPONENT_LIFTS",
        "CONDITIONAL_LIFT_BASELINE_SUCCESS_PROBABILITY": baseline_success_probability,
        "OPPORTUNITY_NORMALIZED_RECURRENCE_FORMULA": "COMPONENT_DISTINCT_QUALIFYING_WORLDS / EXPLICIT_ELIGIBLE_WORLDS; LINEUP=MEAN_OF_EXPLICIT_CORE_COMPONENT_VALUES",
        "BACKFILL_USED": False,
        "FORCED_BOARD_SIZE": False,
        "NO_FORCED_BOARD_SIZE": True,
        "NO_BACKFILL": True,
        "SIMULATION_RECEIPT": simulation_receipt,
        "DISCOVERY_QUALIFYING_WORLD_EVENTS": int(discovery_qualifying_world_events),
        "FINAL_BOARD_SIZE": int(len(ordered)),
        "FINAL_BOARD": ordered,
    }
    receipt_path.write_text(json.dumps(payload, indent=2, default=str) + "\n", encoding="utf-8")
    return board_df, payload
