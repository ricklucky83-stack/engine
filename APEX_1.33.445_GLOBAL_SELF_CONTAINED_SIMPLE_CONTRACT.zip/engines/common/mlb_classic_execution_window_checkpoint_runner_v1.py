from __future__ import annotations
import ast, importlib, hashlib, io, json, os, pickle, sys, time, types
from pathlib import Path
from collections import Counter, defaultdict
from functools import lru_cache
from dataclasses import asdict
from typing import Any, Iterable, Mapping, Sequence
import numpy as np

SRC = Path(os.environ['APEX_SPLIT_SOURCE'])
EXPECTED_SHA256 = os.environ.get('APEX_SPLIT_SOURCE_SHA256','').strip().lower()
STAGE_NAME = os.environ.get('APEX_SPLIT_STAGE_NAME','UNNAMED')
if EXPECTED_SHA256:
    actual_sha256 = hashlib.sha256(SRC.read_bytes()).hexdigest()
    if actual_sha256 != EXPECTED_SHA256:
        raise RuntimeError(f'RUN_INVALID:SOURCE_SHA256_MISMATCH:{actual_sha256}:{EXPECTED_SHA256}')
START = int(os.environ.get('APEX_SPLIT_START','1'))
END = int(os.environ['APEX_SPLIT_END'])
CK_IN = os.environ.get('APEX_SPLIT_CHECKPOINT_IN','')
CK_OUT = os.environ.get('APEX_SPLIT_CHECKPOINT_OUT','')
FINAL = os.environ.get('APEX_SPLIT_FINAL','0') == '1'

# Imports required by extracted functions and downstream source.
import csv, gc, faulthandler, hashlib, heapq, itertools, math, zipfile
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csr_matrix


def hydrate(ns: dict[str, Any]) -> None:
    engine_dir = Path(ns['ENGINE_DIR'])
    handoff_dir = Path(ns['HANDOFF_DIR'])
    common_dir = Path(SRC).resolve().parents[1] / 'common'
    for p in (engine_dir, handoff_dir, common_dir):
        if str(p) not in sys.path: sys.path.insert(0, str(p))
    module_aliases = {
        'mlb_phase2_blocks':'mlb_phase2_strict_block_resumption_v1',
        'phase1_sync':'global_phase1_calibration_hybrid_sync_v1',
        'profile_mod':'global_dfs_core_closure_profile_calibration_v2',
        'classic_mod':'mlb_classic_small_slate_distributed_geometry_v2',
        'sibling_closure_mod':'mlb_classic_deterministic_family_sibling_closure_v1',
        'cross_pattern_closure_mod':'mlb_classic_cross_pattern_family_sibling_closure_v3',
        'adaptive_family_door_mod':'mlb_classic_adaptive_family_door_recall_v1',
        'adjacent_431_closure_mod':'mlb_classic_5_2_1_to_4_3_1_adjacent_family_closure_v1',
        'elite_431_recall_mod':'mlb_classic_431_elite_assembly_recall_v1',
        'macro_spine_mod':'mlb_classic_deterministic_macro_spine_recall_v1',
        'spine_closure_mod':'mlb_classic_five_stack_salary_complement_spine_closure_v1',
        'phase_identity_mod':'mlb_classic_phase_identity_contract_v1',
        'lattice_fast':'mlb_exact_lattice_compatibility_v1',
        'selector_mod':'global_code_ai_hybrid_selector_authority_v1',
        'advisor_selector':'mlb_advisor_tail_selector_v1',
        'classic_historical_selector':'mlb_classic_historical_consensus_selector_v1',
        'noninferior_portfolio_selector':'mlb_classic_noninferior_trophy_portfolio_selector_v1',
        'common_world_portfolio_selector':'mlb_classic_noninferior_common_world_top01_portfolio_v1',
        'orientation_sibling_mod':'mlb_classic_orientation_protected_sibling_inversion_v1',
        'rnwd_authority':'mlb_right_neighborhood_wrong_door_authority_v1',
        'attackable_pa_mod':'mlb_hitter_attackable_pa_adjustment_v1',
        'handoff_contract':'handoff_contract',
    }
    for alias, name in module_aliases.items(): ns[alias] = importlib.import_module(name)
    fk = importlib.import_module('mlb_fast_kernels_v1_20')
    ns['fast_kernel_runtime_receipt']=fk.runtime_receipt
    ns['score_lineup_block_numba']=fk.score_lineup_block_numba
    ns['score_lineup_block_numba_serial']=fk.score_lineup_block_numba_serial
    ns['_parent_noninferior_selector_api']=ns['noninferior_portfolio_selector'].select_portfolio
    ns.update({
        'csv':csv,'gc':gc,'faulthandler':faulthandler,'hashlib':hashlib,'heapq':heapq,'itertools':itertools,'json':json,'math':math,'os':os,'sys':sys,'time':time,'zipfile':zipfile,
        'np':np,'Bounds':Bounds,'LinearConstraint':LinearConstraint,'milp':milp,'csr_matrix':csr_matrix,
        'Counter':Counter,'defaultdict':defaultdict,'asdict':asdict,'lru_cache':lru_cache,'Path':Path,'Any':Any,'Iterable':Iterable,'Mapping':Mapping,'Sequence':Sequence,
    })
    # Recreate top-level functions from authoritative source without executing top-level engine work.
    tree = ast.parse(SRC.read_text())
    f_nodes = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    mod = ast.Module(body=f_nodes, type_ignores=[])
    ast.fix_missing_locations(mod)
    exec(compile(mod, str(SRC), 'exec'), ns, ns)
    # Dynamic strategy object is only needed downstream for its frozen receipt.
    if '_strategy_features_receipt' in ns:
        ns['strategy_features'] = types.SimpleNamespace(receipt=ns['_strategy_features_receipt'])


def dump_state(ns: dict[str, Any], path: Path) -> None:
    data: dict[str, Any] = {}
    for k,v in ns.items():
        if k.startswith('__'): continue
        if isinstance(v, types.ModuleType): continue
        if callable(v): continue
        if k.startswith('_strategy_'): continue
        if k == 'strategy_features':
            try: data['_strategy_features_receipt'] = dict(v.receipt)
            except Exception: pass
            continue
        # Exclude known import machinery / streams.
        if isinstance(v, (io.IOBase,)): continue
        try:
            pickle.dumps(v, protocol=5)
        except Exception:
            continue
        data[k]=v
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('wb') as f: pickle.dump(data,f,protocol=5)
    os.replace(tmp,path)

if CK_IN:
    for _p in (os.environ.get('APEX_ENGINE_DIR',''), os.environ.get('APEX_HANDOFF_DIR','')):
        if _p and _p not in sys.path: sys.path.insert(0,_p)
    _common = str(SRC.resolve().parents[1] / 'common')
    if _common not in sys.path: sys.path.insert(0,_common)
    with open(CK_IN,'rb') as f: ns=pickle.load(f)
    ns['__name__']='__main__'; ns['__file__']=str(SRC); ns['__package__']=None; ns['__cached__']=None
    hydrate(ns)
else:
    ns={'__name__':'__main__','__file__':str(SRC),'__package__':None,'__cached__':None}

lines=SRC.read_text().splitlines(keepends=True)
if START < 1 or END < START or END > len(lines):
    raise RuntimeError(f'RUN_INVALID:INVALID_STAGE_BOUNDS:{START}:{END}:{len(lines)}')
code=''.join(lines[START-1:END])
t0=time.time()
exec(compile(code, str(SRC), 'exec'), ns, ns)
print(json.dumps({'SPLIT_STAGE':'EXEC_DONE','STAGE_NAME':STAGE_NAME,'START':START,'END':END,'SEC':round(time.time()-t0,3)}), file=sys.stderr, flush=True)
if not FINAL:
    if not CK_OUT: raise RuntimeError('MISSING_CHECKPOINT_OUT')
    t1=time.time(); out=Path(CK_OUT); out.parent.mkdir(parents=True,exist_ok=True); dump_state(ns,out)
    print(json.dumps({'SPLIT_STAGE':'CHECKPOINT_DONE','STAGE_NAME':STAGE_NAME,'PATH':str(out),'BYTES':out.stat().st_size,'SEC':round(time.time()-t1,3)}), file=sys.stderr, flush=True)
