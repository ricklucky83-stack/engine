from __future__ import annotations
import hashlib, json, os, time
from pathlib import Path
from typing import Any

PATCH_ID='APEX_GLOBAL_STEP_PROOF_GATE_v1_1.33.445'
class GlobalStepProofError(RuntimeError): pass

def _canon(o: Any)->bytes:
    return json.dumps(o,sort_keys=True,separators=(',',':'),default=str).encode()

def _sha_file(p: Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def _ledger(root: Path)->Path:
    p=Path(root)/'GLOBAL_STEP_PROOF_LEDGER.jsonl'; p.parent.mkdir(parents=True,exist_ok=True); return p

def _rows(root: Path):
    p=_ledger(root)
    out=[]
    if p.exists():
        for line in p.read_text(encoding='utf-8').splitlines():
            if line.strip(): out.append(json.loads(line))
    return out

def _append(root: Path, step: str, payload: dict)->dict:
    rows=_rows(root); prev=rows[-1].get('STEP_RECEIPT_SHA256') if rows else None
    body={'PATCH_ID':PATCH_ID,'STEP':step,'SEQ':len(rows)+1,'PREV_SHA256':prev,'AT_NS':time.time_ns(),**payload}
    body['STEP_RECEIPT_SHA256']=hashlib.sha256(_canon(body)).hexdigest()
    with _ledger(root).open('a',encoding='utf-8') as f: f.write(json.dumps(body,sort_keys=True)+'\n')
    return body

def initialize(*,root,execution_id,sport,mode):
    rows=_rows(Path(root))
    return {'PATCH_ID':PATCH_ID,'STATUS':'PASS','STEP_COUNT':len(rows),'EXECUTION_ID':str(execution_id),'SPORT':str(sport).upper(),'MODE':str(mode).upper()}

def prove_authority(*,root,state_version,registry_path,direct_engine_sha256,notion_authority_receipt):
    rp=Path(registry_path)
    if not rp.is_file(): raise GlobalStepProofError('REGISTRY_MISSING')
    if not isinstance(notion_authority_receipt,dict) or notion_authority_receipt.get('STATUS')!='PASS': raise GlobalStepProofError('NOTION_AUTHORITY_NOT_PROVEN')
    return _append(Path(root),'AUTHORITY_RESOLVED',{'STATUS':'PASS','STATE_VERSION':str(state_version),'REGISTRY_SHA256':_sha_file(rp),'DIRECT_ENGINE_SHA256':str(direct_engine_sha256 or ''),'NOTION_RECEIPT_SHA256':str(notion_authority_receipt.get('NOTION_RECEIPT_SHA256') or '')})

def prove_input_binding(*,root,player_pool,expected_sha256):
    p=Path(player_pool)
    if not p.is_file(): raise GlobalStepProofError('PLAYER_POOL_MISSING')
    actual=_sha_file(p)
    if expected_sha256 and actual.lower()!=str(expected_sha256).lower(): raise GlobalStepProofError('PLAYER_POOL_SHA_MISMATCH')
    return _append(Path(root),'INPUT_BOUND',{'STATUS':'PASS','PLAYER_POOL':str(p),'PLAYER_POOL_SHA256':actual})

def prove_engine_binding(*,root,entrypoint,command):
    p=Path(entrypoint)
    if not p.is_file(): raise GlobalStepProofError('ENTRYPOINT_MISSING')
    return _append(Path(root),'ENGINE_BOUND',{'STATUS':'PASS','ENTRYPOINT':str(p.resolve()),'ENTRYPOINT_SHA256':_sha_file(p),'COMMAND':[str(x) for x in command]})

def prove_process_launch(*,root,pid,entrypoint):
    if int(pid)<=0: raise GlobalStepProofError('INVALID_PID')
    return _append(Path(root),'PROCESS_LAUNCHED',{'STATUS':'PASS','PID':int(pid),'ENTRYPOINT':str(Path(entrypoint).resolve())})

def prove_checkpoint_advance(*,root,terminal_event,child_return_code,pid):
    if int(child_return_code)!=75: raise GlobalStepProofError('CHECKPOINT_RETURN_CODE_INVALID')
    if str((terminal_event or {}).get('RUN_STATE'))!='CHECKPOINTED_CONTINUE': raise GlobalStepProofError('CHECKPOINT_EVENT_INVALID')
    return _append(Path(root),'CHECKPOINT_ADVANCE',{'STATUS':'PASS','PID':int(pid),'COMPLETED_STAGE':terminal_event.get('COMPLETED_STAGE'),'NEXT_STAGE':terminal_event.get('NEXT_STAGE'),'CHECKPOINT':terminal_event.get('CHECKPOINT')})

def require_ready_for_next_launch(*,root,completed_stage,next_stage):
    if not str(next_stage or ''): raise GlobalStepProofError('NEXT_STAGE_MISSING')
    return {'PATCH_ID':PATCH_ID,'STATUS':'PASS','COMPLETED_STAGE':str(completed_stage or ''),'NEXT_STAGE':str(next_stage)}

def prove_terminal_board(*,root,terminal):
    if not isinstance(terminal,dict) or int(terminal.get('FINAL_BOARD_SIZE',0) or 0)<0: raise GlobalStepProofError('TERMINAL_BOARD_INVALID')
    return _append(Path(root),'TERMINAL_BOARD_PROVEN',{'STATUS':'PASS','FINAL_BOARD_SIZE':int(terminal.get('FINAL_BOARD_SIZE',0) or 0),'BOARD_PAYLOAD_SHA256':terminal.get('BOARD_PAYLOAD_SHA256'),'RUN_STATE':terminal.get('RUN_STATE')})

def final_chain_receipt(*,root):
    rows=_rows(Path(root)); last=rows[-1].get('STEP_RECEIPT_SHA256') if rows else None
    return {'PATCH_ID':PATCH_ID,'STATUS':'PASS','STEP_COUNT':len(rows),'FINAL_STEP_RECEIPT_SHA256':last,'LEDGER_PATH':str(_ledger(Path(root)))}
