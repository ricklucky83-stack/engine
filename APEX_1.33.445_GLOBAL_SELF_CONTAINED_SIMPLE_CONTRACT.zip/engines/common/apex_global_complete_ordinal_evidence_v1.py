from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Mapping, Sequence

MC_WORLDS = 200_000
DOT00001_THRESHOLD = 0.00001
ORDINAL_AUTHORITY = "GLOBAL_COMPLETE_ORDINAL_EVIDENCE_RANK_v2"

REQUIRED_ORDINAL_FIELDS = (
    "#1_COUNT",
    "#1_RATE_EXACT",
    "CPT_#1_COUNT",
    "CPT_#1_RATE_EXACT",
    "REPLACEMENT_PRESSURE_MEAN",
    "REPLACEMENT_PRESSURE_MEDIAN",
    "REPLACEMENT_PRESSURE_P90",
    "CPT_ROLE_PRESSURE",
    "PAIR_#1_COUNT",
    "TRIO_#1_COUNT",
    "CORE_#1_COUNT",
    "DISTINCT_WORLD_SUPPORT",
    "CONDITIONAL_LIFT",
    "OPPORTUNITY_NORMALIZED_RECURRENCE",
    "TOP3_COUNT",
    "TOP10_COUNT",
)

# Rank-only evidence order. All seven user-requested evidence signals participate:
# REPLACEMENT_PRESSURE, CPT_ROLE_PRESSURE, PAIR, TRIO, CORE,
# CONDITIONAL_LIFT, OPPORTUNITY_NORMALIZED_RECURRENCE.
ORDINAL_FIELD_ORDER = (
    "#1_COUNT",
    "REPLACEMENT_PRESSURE_MEAN",
    "REPLACEMENT_PRESSURE_MEDIAN",
    "REPLACEMENT_PRESSURE_P90",
    "CPT_ROLE_PRESSURE",
    "CPT_#1_COUNT",
    "PAIR_#1_COUNT",
    "TRIO_#1_COUNT",
    "CORE_#1_COUNT",
    "DISTINCT_WORLD_SUPPORT",
    "CONDITIONAL_LIFT",
    "OPPORTUNITY_NORMALIZED_RECURRENCE",
    "TOP3_COUNT",
    "TOP10_COUNT",
)


def target_rank_for_field(field_size: int) -> int:
    n = int(field_size)
    if n <= 0:
        raise RuntimeError("RUN_INVALID:FIELD_SIZE_NONPOSITIVE")
    return max(1, int(math.ceil(float(n) * DOT00001_THRESHOLD)))


def exact_rate(raw_count: int, worlds: int = MC_WORLDS) -> float:
    if int(worlds) <= 0:
        raise RuntimeError("RUN_INVALID:MC_WORLDS_NONPOSITIVE")
    return float(int(raw_count)) / float(int(worlds))


def clears_dot00001_target_rank(target_rank_world_count: int) -> bool:
    # Membership is NOT a probability threshold. One qualifying frozen world is enough.
    return int(target_rank_world_count) >= 1


def minimum_dot00001_count(worlds: int = MC_WORLDS) -> int:
    # Retained only for compatibility with old imports. The new gate is same-world
    # target-rank attainment, and therefore requires >=1 qualifying world.
    if int(worlds) <= 0:
        raise RuntimeError("RUN_INVALID:MC_WORLDS_NONPOSITIVE")
    return 1


def _num(v: Any) -> float:
    try:
        x = float(v)
        return x if math.isfinite(x) else 0.0
    except Exception:
        return 0.0


def _membership_key(row: Mapping[str, Any]) -> str:
    for key in ("LINEUP_KEY", "lineup_key", "LINEUP_ID", "lineup_id"):
        if key in row:
            return str(row[key])
    roster_keys = [
        k for k in (
            "CPT", "FLEX1", "FLEX2", "FLEX3", "FLEX4", "FLEX5",
            "QB", "RB1", "RB2", "WR1", "WR2", "WR3", "FLEX", "SFLEX",
        ) if k in row
    ]
    if roster_keys:
        return "|".join(str(row[k]) for k in roster_keys)
    return hashlib.sha256(json.dumps(dict(row), sort_keys=True, default=str).encode()).hexdigest()


def membership_fingerprint(rows: Sequence[Mapping[str, Any]]) -> str:
    keys = sorted(_membership_key(r) for r in rows)
    return hashlib.sha256("\n".join(keys).encode()).hexdigest()


def require_complete_ordinal_evidence(rows: Sequence[Mapping[str, Any]]) -> None:
    for i, row in enumerate(rows):
        missing = [k for k in REQUIRED_ORDINAL_FIELDS if k not in row]
        if missing:
            raise RuntimeError(f"RUN_INVALID:ORDINAL_EVIDENCE_MISSING:ROW={i}:" + ",".join(missing))


def _evidence_tuple(row: Mapping[str, Any]) -> tuple[float, ...]:
    return tuple(_num(row.get(k, 0.0)) for k in ORDINAL_FIELD_ORDER)


def rank_all_survivors(rows: Sequence[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Order every survivor and preserve genuine evidence ties.

    Membership must already be fixed by the hard same-world target-rank gate followed
    by strict same-world dominance. This function never selects, truncates, backfills,
    applies exposure logic, or changes membership.
    """
    src = [dict(r) for r in rows]
    require_complete_ordinal_evidence(src)
    before = membership_fingerprint(src)

    indexed = list(enumerate(src))
    indexed.sort(key=lambda item: tuple(-x for x in _evidence_tuple(item[1])) + (_membership_key(item[1]), item[0]))

    ordered: list[dict[str, Any]] = []
    previous_evidence: tuple[float, ...] | None = None
    previous_rank = 0
    for position, (_source_i, raw) in enumerate(indexed, 1):
        row = dict(raw)
        evidence = _evidence_tuple(row)
        if previous_evidence is not None and evidence == previous_evidence:
            rank = previous_rank
            tied = True
        else:
            rank = position
            tied = False
        row["RANK"] = int(rank)
        row["ORDINAL_EVIDENCE_TIE"] = bool(tied or (previous_evidence is not None and evidence == previous_evidence))
        row["ORDINAL_AUTHORITY"] = ORDINAL_AUTHORITY
        row["ORDINAL_EVIDENCE_VECTOR"] = json.dumps({k: row.get(k) for k in ORDINAL_FIELD_ORDER}, separators=(",", ":"), sort_keys=False)
        ordered.append(row)
        previous_evidence = evidence
        previous_rank = int(rank)

    # Mark first member of multi-row tie groups too, without changing the evidence ordering.
    by_rank: dict[int, int] = {}
    for row in ordered:
        by_rank[int(row["RANK"])] = int(by_rank.get(int(row["RANK"]), 0)) + 1
    for row in ordered:
        row["ORDINAL_EVIDENCE_TIE"] = bool(by_rank[int(row["RANK"])] > 1)

    after = membership_fingerprint(ordered)
    if len(ordered) != len(src) or before != after:
        raise RuntimeError("RUN_INVALID:ORDINAL_MEMBERSHIP_MUTATION")

    receipt = {
        "ORDINAL_AUTHORITY": ORDINAL_AUTHORITY,
        "ORDINAL_ROLE": "RANK_ONLY",
        "ORDINAL_INPUT_SURVIVORS": len(src),
        "ORDINAL_OUTPUT_SURVIVORS": len(ordered),
        "ORDINAL_MEMBERSHIP_MUTATION_ALLOWED": False,
        "ORDINAL_MEMBERSHIP_UNCHANGED": True,
        "ORDINAL_MEMBERSHIP_SHA256_BEFORE": before,
        "ORDINAL_MEMBERSHIP_SHA256_AFTER": after,
        "ORDINAL_FIELD_ORDER": list(ORDINAL_FIELD_ORDER),
        "REQUIRED_ORDINAL_FIELDS": list(REQUIRED_ORDINAL_FIELDS),
        "GENUINE_EVIDENCE_TIES_PRESERVED": True,
        "EXPOSURE_SELECTOR_USED": False,
        "BOARD_SIZE_TRUNCATION_USED": False,
        "BACKFILL_USED": False,
    }
    return ordered, receipt


def global_contract_receipt() -> dict[str, Any]:
    return {
        "SCOPE": "GLOBAL_ALL_SPORTS_ALL_SITES_ALL_SLATE_TYPES_ALL_RUNNERS",
        "MC_WORLDS": MC_WORLDS,
        "DOT00001_GATE_THRESHOLD": DOT00001_THRESHOLD,
        "DOT00001_GATE_DEFINITION": "SAME_WORLD_CHAMPIONSHIP_RANK_THRESHOLD",
        "DOT00001_TARGET_RANK_FORMULA": "max(1, ceil(FIELD_SIZE * 0.00001))",
        "DOT00001_SURVIVOR_MEMBERSHIP_RULE": "KEEP_IF_TARGET_RANK_OR_BETTER_IN_AT_LEAST_ONE_FROZEN_WORLD",
        "RECURRENCE_CONTROLS_MEMBERSHIP": False,
        "PRE_GATE_FAMILY_CAP_ALLOWED": False,
        "PRE_GATE_BRANCH_CAP_ALLOWED": False,
        "TOP_K_CLOSURE_CAP_ALLOWED": False,
        "PRE_SCORE_PRUNING_ALLOWED": False,
        "SCORE_EVERY_COMPLETE_LEGAL_BUILD": True,
        "DOMINANCE_PRUNE_POSITION": "AFTER_DOT00001_GATE_ONLY",
        "ORDINAL_AUTHORITY": ORDINAL_AUTHORITY,
        "ORDINAL_ROLE": "RANK_ONLY",
        "ORDINAL_MEMBERSHIP_MUTATION_ALLOWED": False,
        "GENUINE_EVIDENCE_TIES_PRESERVED": True,
        "NO_FORCED_BOARD_SIZE": True,
        "NO_BACKFILL": True,
        "REQUIRED_ORDINAL_FIELDS": list(REQUIRED_ORDINAL_FIELDS),
        "ORDINAL_FIELD_ORDER": list(ORDINAL_FIELD_ORDER),
    }
