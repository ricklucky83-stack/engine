from __future__ import annotations

"""Terminal-only AI Hybrid selection boundary.

The engine owns candidate birth, legality, calibration, simulation, ownership,
field construction, handoff and metric computation.  AI authority begins only
after the complete calibration-qualified/selector-reviewed candidate matrix is handed off.
No Top-N sieve, cohort reduction, Pareto pruning, or selector pruning is allowed.
The AI may select
existing lineup IDs and attach bounded reason codes.  It cannot create lineups,
change metrics, recompute simulations, or use post-lock outcomes.
"""

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
import csv, json, math, os, sqlite3, tempfile
from engines.common import apex_elite_tail_propagation_v1 as elite_tail
from engines.common import apex_entry_limit_game_theory_v1 as entry_limit_game
from engines.common import apex_global_mc_signal_doctrine_v1 as mc_signal_doctrine
from engines.common import apex_global_championship_head_policy_v1 as championship_head_policy
from engines.common import apex_global_contest_order_intelligence_v3 as global_order
from engines.common import apex_global_hybrid_selector_intelligence_v4 as global_intelligence_v3

PATCH_ID = "APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v6"
SELECTOR_MODE = "CODE_AI_HYBRID_TERMINAL_ONLY_FULL_HANDOFF_GLOBAL_SHARED_INTELLIGENCE"
TOP5_POLICY_ID = championship_head_policy.PATCH_ID
BOARD_SIZE = 5
TERMINAL_SURFACE_ATOMIC_PUBLISH_PATCH_ID = "APEX_GLOBAL_TERMINAL_SURFACE_ATOMIC_PUBLISH_v1"
CODE_DOC_PARITY_PATCH_ID = "APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v6_CODE_DOC_PARITY_SEAL_v1"
REPAIR_PATCH_ID = "APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v6_REPAIR_AND_TOP01_CURRICULUM_BRIDGE_v1"
INTELLIGENCE_TRAINING_PATCH_ID = global_intelligence_v3.PATCH_ID
GLOBAL_ORDER_INTELLIGENCE_PATCH_ID = global_order.PATCH_ID
ENTRY_LIMIT_GAME_THEORY_PATCH_ID = entry_limit_game.PATCH_ID

TENNIS_CLASSIC_RANK1_POSTERIOR_POLICY = {
    "objective": "MAXIMIZE_CONTEST_RANK1_CAPTURE_CONDITIONAL_ON_CANDIDATE_BIRTH",
    "full_handoff_required": True,
    "current_selector_role": "COMPARATOR_NOT_AUTHORITY",
    "player_core_top01_density_weight": 0.20,
    "player_core_win_density_weight": 0.06,
    "d1_top01_density_weight": 0.16,
    "top01_lcb_weight": 0.24,
    "win_lcb_weight": 0.06,
    "p99_weight": 0.08,
    "cvar99_weight": 0.06,
    "market_support_weight": 0.05,
    "low_dup_weight": 0.03,
    "uncertainty_stability_weight": 0.06,
    "same_match_pair_penalty": 0.08,
    "same_match_elite_tail_relief_max": 0.50,
    "recovery_posterior_pctl_min": 0.80,
    "recovery_selector_pctl_max": 0.50,
    "recovery_underrank_gap_min": 0.40,
    "production_inputs": "PRELOCK_ONLY",
    "resolved_results_role": "OFFLINE_TRAINING_AND_DIAGNOSTIC_ONLY",
    "player_name_constants": False,
    "postlock_selector_fields": False,
    "no_top_n_sieve": True,
    "no_candidate_pruning": True,
}


def _fsync_parent(path: Path) -> None:
    try:
        fd=os.open(str(Path(path).parent), os.O_RDONLY)
        try: os.fsync(fd)
        finally: os.close(fd)
    except Exception:
        pass

def _drop_page_cache(path: Path) -> None:
    # Execution-only memory safety.  Large terminal artifacts are durable on disk;
    # they do not need to remain charged to the cgroup page cache after fsync.
    if not hasattr(os, "posix_fadvise") or not hasattr(os, "POSIX_FADV_DONTNEED"):
        return
    try:
        fd=os.open(str(path), os.O_RDONLY)
        try: os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
        finally: os.close(fd)
    except Exception:
        pass

def _atomic_write_csv(path: Path, fields: Sequence[str], rows: Sequence[Mapping[str,Any]]) -> None:
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp_name=tempfile.mkstemp(prefix=f".{path.name}.",suffix=".tmp",dir=str(path.parent)); os.close(fd)
    tmp=Path(tmp_name)
    try:
        with tmp.open("w",encoding="utf-8",newline="") as f:
            w=csv.DictWriter(f,fieldnames=list(fields),extrasaction="ignore"); w.writeheader(); w.writerows(rows)
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path); _fsync_parent(path); _drop_page_cache(path)
    finally:
        try: tmp.unlink()
        except FileNotFoundError: pass

def _atomic_write_json(path: Path, obj: Mapping[str,Any]) -> None:
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp_name=tempfile.mkstemp(prefix=f".{path.name}.",suffix=".tmp",dir=str(path.parent)); os.close(fd)
    tmp=Path(tmp_name)
    try:
        with tmp.open("w",encoding="utf-8") as f:
            json.dump(obj,f,indent=2,sort_keys=True); f.write("\n"); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path); _fsync_parent(path)
    finally:
        try: tmp.unlink()
        except FileNotFoundError: pass

FORBIDDEN_POSTLOCK_FIELDS = frozenset({
    "CONTEST_RANK","ACTUAL_FPTS","REALIZED_FPTS","POSTLOCK_SCORE","REALIZED_SCORE",
    "ACTUAL_SCORE","ACTUAL_RANK","FINAL_CONTEST_RANK","WINNING_LINEUP","TARGET_ACTUAL_SCORE",
})

ALLOWED_REASON_CODES = frozenset({
    # Existing authority vocabulary
    "ELITE_WIN_PATH","ELITE_TOP_0_1_PATH","ELITE_TOP_1_PATH","P99_TAIL","CVAR99_TAIL","P95_TAIL",
    "CORRELATION_PATH","LEVERAGE_PATH","LOW_DUPLICATION_PATH","SALARY_GEOMETRY_PATH",
    "STRUCTURE_DIVERSIFICATION","PORTFOLIO_MARGINAL_VALUE",
    # v2 terminal intelligence vocabulary
    "CHAMPIONSHIP_UNION_COVERAGE","TOP01_UNION_COVERAGE","TOP1_UNION_COVERAGE",
    "UNCERTAINTY_STABILITY","CROSS_SEED_STABILITY","REGIME_COVERAGE","COUNTER_SCRIPT_COVERAGE",
    "FIELD_MODEL_RELIABILITY","CURRENT_SELECTOR_SUPPORT","CURRENT_SELECTOR_DISAGREEMENT",
    "TAIL_ASYMMETRY","PARETO_FRONTIER","DUPLICATION_ADJUSTED_UPSIDE","FAMILY_CHAMPIONSHIP_MASS",
    "SIBLING_RECALL","DOMINANT_FAMILY_EVIDENCE",
    # v4 relationship / conditional-mutation intelligence vocabulary
    "RECIPROCAL_ROLE_SIBLING","RECIPROCAL_CPT_SIBLING","PROBABILITY_EQUIVALENT",
    "ONE_PLAYER_MUTATION","TWO_PLAYER_MUTATION","CONDITIONAL_CORE_FIT",
    "SCRIPT_COMPLETION","CPT_SIDE_SCRIPT_COMPLETION","TAIL_MAGNITUDE_GAIN",
    "LOCAL_CHAMPIONSHIP_DENSITY","SUBFAMILY_CHAMPIONSHIP_MASS",
    "MARKET_TAIL_DISAGREEMENT","DECK_DEPTH_PROTECTED","DOMINANT_FAMILY_SUPPORT",
    "CHAMPIONSHIP_DECK","SEAT_SPECIFIC_SIBLING_RETENTION",
    "SPORT_NATIVE_LANE_AUTHORITY","ROOT_CHAMPIONSHIP_FAMILY_PROTECTED",
    "SAME_LANE_FAMILY_REPLACEMENT","METRIC_DOMINANCE_VETO",
    "CORRELATED_HIGH_CONFIDENCE_ANCHOR_PRESS","RUNBACK_PATH","NEGATIVE_CORRELATION_COUNTER_SCRIPT",
    # MLB Showdown role-allocation discontinuity candidate vocabulary
    "HITTER_CPT_DISCONTINUITY","ROLE_SWAP_TAIL_EQUIVALENCE","ROLE_LEVERAGE_LOG_RATIO",
    "DUPLICATION_RELEASE","SALARY_UNLOCK_CLOSURE","EXACT_PLAYERSET_ROLE_SWAP",
    "CROSS_WORLD_RECURRENCE_BREADTH",
    "CHAMPIONSHIP_NEIGHBORHOOD_PROTECTED","PAIRWISE_STRENGTH","WORLD_BREADTH",
    "STABLE_TAIL_PRESENCE","HEAD_MULTI_SIGNAL_AGREEMENT",
    # Global contest-entry-limit game theory
    "ENTRY_LIMIT_FIRST_PLACE_EQUITY","SINGLE_ENTRY_ONE_SHOT_EACH",
    "MARGINAL_NEW_WIN_WORLD_COVERAGE","OPPONENT_PORTFOLIO_SYMMETRY",
})

FEATURE_REGISTRY = {
    "PRIMARY_TAIL": ["MC_WIN_RATE","MC_WIN_LCB","MC_TOP_0_1_RATE","MC_TOP_0_1_LCB","MC_TOP_1_RATE","MC_TOP_1_LCB"],
    "TAIL_SHAPE": ["MC_P95","MC_P99","MC_CVAR99","TAIL_ASYMMETRY","MC_MEAN"],
    "UNCERTAINTY": ["MC_TRIALS","RANK_STABILITY","CROSS_SEED_STABILITY","CALIBRATION_STABILITY"],
    "FIELD_RELATIVE": ["PROJECTED_EXACT_MATCH_DUPLICATION","P_UNIQUE","OWNERSHIP_PRODUCT","FIELD_MODEL_RELIABILITY"],
    "FAMILY": ["FAMILY_MC_WIN_RATE","FAMILY_MC_TOP_0_1_RATE","FAMILY_MC_TOP1_RATE","FAMILY_CHAMPIONSHIP_MASS","WINNING_SIBLING_COUNT"],
    "PORTFOLIO": ["COMMON_WORLD_WIN_BITS","COMMON_WORLD_TOP01_BITS","COMMON_WORLD_TOP1_BITS","PAIRWISE_OUTCOME_CORRELATION","LINEUP_OVERLAP"],
    "RECURRENCE": ["WORLD_COVERAGE","WORLD_COVERAGE_COUNT","FAST_PATH_WORLD_COVERAGE_RATE","TOTAL_RECURRENCE","FAST_PATH_TOTAL_RECURRENCE"],
    "STRUCTURE": ["BRANCH","ROUTE","CPT_ROLE","SP_COUNT","RP_COUNT","SALARY","SALARY_GEOMETRY","SCENARIO_ID"],
    "CODE_COMPARATOR": ["CURRENT_SELECTOR_SELECTED","CURRENT_SELECTOR_RANK","CURRENT_SELECTOR_SCORE","GLOBAL_CORE_PROTECTED","GLOBAL_CORE_PRIORITY"],
    "MODEL_GOVERNANCE": ["FIELD_MODEL_SOURCE","FIELD_MODEL_RELIABILITY","OWNERSHIP_AUTHORITY","MARKET_MODEL_DIVERGENCE"],
    "RELATIONSHIPS": ["AI_EXACT_PLAYERSET_FAMILY_ID","AI_EXACT_PLAYERSET_SIBLING_COUNT","AI_RECIPROCAL_ROLE_SIBLING_COUNT","AI_D1_NEIGHBOR_COUNT","AI_D1_TOP01_DENSITY","AI_D2_RELATIONSHIP_MODE"],
    "PROBABILITY_EQUIVALENCE": ["AI_TOP01_95_HALF_WIDTH","AI_WIN_95_HALF_WIDTH"],
    "SPORT_MODE_INTELLIGENCE": ["AI_INTELLIGENCE_PROFILE_ID","AI_TEAM_COUNT","AI_DOMINANT_TEAM_COUNT","AI_ROLE_SIDE_COUNT","AI_BATTING_ADJACENCY_PAIRS","AI_MARKET_TAIL_SUPPORT_PCTL","AI_MARKET_TAIL_VS_MC_DISAGREEMENT"],
    "TENNIS_RANK1": ["AI_TENNIS_PLAYER_CORE_TOP01_DENSITY","AI_TENNIS_PLAYER_CORE_WIN_DENSITY","AI_TENNIS_D1_TOP01_DENSITY_PCTL","AI_TENNIS_RANK1_POSTERIOR","AI_TENNIS_RANK1_POSTERIOR_PCTL","AI_TENNIS_TOP01_TAIL_CONSENSUS"],
}

class TerminalAIHybridError(RuntimeError):
    pass


def _norm(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")

MODE_ALIASES = {
    "SD": "SHOWDOWN", "SHOWDOWN_CAPT": "SHOWDOWN_CAPTAIN", "SHOWDOWN_CPT": "SHOWDOWN_CAPTAIN",
    "CAPTAIN": "SHOWDOWN_CAPTAIN", "CPT": "SHOWDOWN_CAPTAIN",
    "SHOWDOWN_FLAT6": "SHOWDOWN_FLAT_6", "SHOWDOWN_FLAT_6": "SHOWDOWN_FLAT_6", "FLAT_6": "SHOWDOWN_FLAT_6",
    "SS_HRS": "SS_HRS", "SS_HR": "SS_HRS", "HRS": "SS_HRS", "HR_SPECIAL": "SS_HRS",
    "SS_TDS": "SS_TDS", "SS_TD": "SS_TDS", "TDS": "SS_TDS", "TD": "SS_TDS",
    "TOUCHDOWNS": "SS_TDS", "SINGLE_STAT_TDS": "SS_TDS", "SINGLE_STAT_TOUCHDOWNS": "SS_TDS",
    "SS_YARDS": "SS_YARDS", "YARDS": "SS_YARDS", "SINGLE_STAT_YARDS": "SS_YARDS",
}
SPORT_ALIASES = {"GOLF": "PGA", "UFC": "MMA"}

# Exact sport x contest-type context adapters for the ONE global shared intelligence system.
# They only translate sport-native structure into comparable terminal evidence. They are
# not separate AI models and never birth, prune, legalize, or simulate lineups.
_PROFILE_ROWS = {
    ("MLB","SHOWDOWN"): dict(
        roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=2,
        family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="TEAM_STACK_BATTING_ORDER",
        market_fields=("TT_LEVERAGE_SCORE","LINEUP_MARKET_TT","STRATEGY_SCORE"),
        exact_role_swap_family=True, role_swap_tail_equivalence_95=True,
        hitter_cpt_discontinuity_lane=True, salary_unlock_closure=True,
        tail_sacrifice_mode="FEASIBILITY_GATE_NOT_LINEAR_PENALTY",
        closure_neighborhood="EXACT_PLAYERSET_RECIPROCAL_CPT_ROLE_SWAP_ONLY",
        closure_radius=1,
        player_set_lock=True, structural_family_lock=True, dual_sp_state_lock=True,
        chalk_util_spine_retention=1.0,
        salary_savings_reward=False,
    ),
    ("MLB","CLASSIC"): dict(roster_size=10, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="STACK_GEOMETRY_TEAM_CORE", script_axis="TEAM_STACK_PITCHER_HITTER_COVARIANCE", market_fields=("LINEUP_MARKET_TT","STACK_MARKET_TOTAL","STRATEGY_SCORE")),
    ("MLB","SS_HRS"): dict(roster_size=None, role_sensitive=False, role_slot=None, mutation_depth=1, family_basis="CORRELATED_HR_EVENT_CORE", script_axis="HR_CORRELATION_GAME_ENVIRONMENT", market_fields=("HR_MARKET_SUPPORT","LINEUP_MARKET_TT","STRATEGY_SCORE")),
    ("WNBA","CLASSIC"): dict(roster_size=6, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="GAME_ROLE_MINUTES_CORE", script_axis="MINUTES_USAGE_GAME_CORRELATION", market_fields=("STRATEGY_SCORE","ROLE_CREDIBILITY","MINUTES_STABILITY"), family_overlap_required=5, probability_equivalence_95=True, championship_deck=True, seat_specific_sibling_retention=True),
    ("WNBA","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=2, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="TEAM_ROLE_GAME_SCRIPT", market_fields=("STRATEGY_SCORE","ROLE_CREDIBILITY","MINUTES_STABILITY"), family_overlap_required=5, probability_equivalence_95=True, championship_deck=True, seat_specific_sibling_retention=True, sport_native_lane_authority=True, root_championship_family_protected=True, same_lane_family_replacement_only=True, role_contract={"HIGH_CONFIDENCE_CORE":3,"RUNBACK":1,"COUNTER_SCRIPT":1}),
    ("NFL","CLASSIC"): dict(roster_size=9, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="STACK_BRINGBACK_ROLE_CORE", script_axis="PASS_RUSH_GAME_SCRIPT", market_fields=("STRATEGY_SCORE","ROUTE_TOUCH_SUPPORT","RED_ZONE_SUPPORT")),
    ("NFL","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=2, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="TEAM_GAME_SCRIPT_ROLE_CORRELATION", market_fields=("STRATEGY_SCORE","ROUTE_TOUCH_SUPPORT","RED_ZONE_SUPPORT")),
    ("NFL","SS_TDS"): dict(
        roster_size=3, role_sensitive=False, role_slot=None, mutation_depth=1,
        family_basis="TOUCHDOWN_SCORER_TRIAD", script_axis="TEAM_TD_ENVIRONMENT_SCORER_ALLOCATION",
        market_fields=("TD_MARKET_SUPPORT","RED_ZONE_SUPPORT","STRATEGY_SCORE"),
        probability_equivalence_95=True, championship_deck=True,
        sport_native_lane_authority=True, root_championship_family_protected=True,
    ),
    ("NFL","SS_YARDS"): dict(
        roster_size=3, role_sensitive=False, role_slot=None, mutation_depth=1,
        family_basis="YARDAGE_TRIAD", script_axis="RUSH_RECEIVE_YARD_WORLD_FIELD_RELATIVE_COVERAGE",
        market_fields=("STRATEGY_SCORE",),
        probability_equivalence_95=True, championship_deck=True,
        sport_native_lane_authority=True, root_championship_family_protected=True,
    ),
    ("CFB","CLASSIC"): dict(roster_size=9, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="STACK_PACE_ROLE_CORE", script_axis="PACE_ROLE_GAME_SCRIPT", market_fields=("STRATEGY_SCORE","ROUTE_TOUCH_SUPPORT","PACE_SUPPORT")),
    ("CFB","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=2, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="DRIVE_REGIME_ROLE_CORRELATION", market_fields=("STRATEGY_SCORE","ROLE_CERTAINTY","REGIME_SUPPORT")),
    ("PGA","CLASSIC"): dict(roster_size=6, role_sensitive=False, role_slot=None, mutation_depth=1, family_basis="GOLFER_TAIL_WEATHER_CORE", script_axis="TEE_WEATHER_BIRDIE_VOLATILITY", market_fields=("STRATEGY_SCORE","BIRDIE_SUPPORT","WEATHER_SUPPORT")),
    ("PGA","SHOWDOWN_FLAT_6"): dict(roster_size=6, role_sensitive=False, role_slot=None, mutation_depth=1, family_basis="ROUND_TAIL_WEATHER_CORE", script_axis="ROUND_TEE_WEATHER_BIRDIE_VOLATILITY", market_fields=("STRATEGY_SCORE","BIRDIE_SUPPORT","ROUND_SUPPORT")),
    ("PGA","SHOWDOWN_CAPTAIN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=1, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="ROUND_TEE_WEATHER_BIRDIE_VOLATILITY", market_fields=("STRATEGY_SCORE","BIRDIE_SUPPORT","ROUND_SUPPORT")),
    ("TENNIS","CLASSIC"): dict(roster_size=6, role_sensitive=False, role_slot=None, mutation_depth=1, family_basis="MATCH_SCENARIO_VOLATILITY_CORE", script_axis="MATCH_SURFACE_SERVE_RETURN", market_fields=("STRATEGY_SCORE","MATCH_WIN_SUPPORT","VOLATILITY_SUPPORT")),
    ("TENNIS","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=1, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="MATCH_SCENARIO_SERVE_RETURN", market_fields=("STRATEGY_SCORE","MATCH_WIN_SUPPORT","VOLATILITY_SUPPORT")),
    ("MMA","CLASSIC"): dict(roster_size=6, role_sensitive=False, role_slot=None, mutation_depth=1, family_basis="FIGHT_STYLE_FINISH_CORE", script_axis="FIGHT_STYLE_PACE_FINISH", market_fields=("STRATEGY_SCORE","FINISH_SUPPORT","PACE_SUPPORT")),
    ("MMA","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=1, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="FIGHT_STYLE_PACE_FINISH", market_fields=("STRATEGY_SCORE","FINISH_SUPPORT","PACE_SUPPORT")),
    ("NBA","CLASSIC"): dict(roster_size=8, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="GAME_ROLE_MINUTES_CORE", script_axis="MINUTES_USAGE_GAME_CORRELATION", market_fields=("STRATEGY_SCORE","ROLE_CREDIBILITY","MINUTES_STABILITY")),
    ("NBA","SHOWDOWN"): dict(roster_size=6, role_sensitive=True, role_slot="CPT", mutation_depth=2, family_basis="PLAYERSET_CPT_RECIPROCAL", script_axis="TEAM_ROLE_GAME_SCRIPT", market_fields=("STRATEGY_SCORE","ROLE_CREDIBILITY","MINUTES_STABILITY")),
    ("CBB","CLASSIC"): dict(roster_size=8, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="GAME_ROLE_MINUTES_CORE", script_axis="MINUTES_USAGE_GAME_CORRELATION", market_fields=("STRATEGY_SCORE","ROLE_CREDIBILITY","MINUTES_STABILITY")),
    ("NHL","CLASSIC"): dict(roster_size=9, role_sensitive=False, role_slot=None, mutation_depth=2, family_basis="LINE_PP_GOALIE_CORE", script_axis="LINE_POWERPLAY_SHOT_GOALIE", market_fields=("STRATEGY_SCORE","SHOT_SUPPORT","POWER_PLAY_SUPPORT")),
}


def normalize_sport_mode(sport: str, mode: str) -> tuple[str,str]:
    s=SPORT_ALIASES.get(_norm(sport),_norm(sport)); m=MODE_ALIASES.get(_norm(mode),_norm(mode))
    return s,m


def intelligence_profile(sport: str, mode: str) -> dict[str,Any]:
    s,m=normalize_sport_mode(sport,mode)
    key=(s,m)
    if key not in _PROFILE_ROWS:
        raise TerminalAIHybridError(f"RUN_INVALID:AI_INTELLIGENCE_PROFILE_UNDEFINED:{s}:{m}")
    p=dict(_PROFILE_ROWS[key]); p.update({"sport":s,"mode":m,"profile_id":f"{s}_{m}_TERMINAL_INTELLIGENCE_v6"})
    return p


def selector_contract_metadata() -> dict[str,Any]:
    """Source-of-truth metadata for the terminal-only hybrid selector boundary."""
    return {
        "patch_id": PATCH_ID,
        "repair_patch_id": REPAIR_PATCH_ID,
        "code_doc_parity_patch_id": CODE_DOC_PARITY_PATCH_ID,
        "intelligence_training_patch_id": INTELLIGENCE_TRAINING_PATCH_ID,
        "top5_policy_id": TOP5_POLICY_ID,
        "entry_limit_game_theory_patch_id": ENTRY_LIMIT_GAME_THEORY_PATCH_ID,
        "entry_limit_objective": entry_limit_game.OBJECTIVE,
        "entry_limit_symmetry": "OUR_PORTFOLIO_AND_OPPONENT_PORTFOLIOS_USE_SAME_CONTEST_MAX_ENTRY_LIMIT",
        "independent_top_n_portfolio_selection": False,
        "board_size": BOARD_SIZE,
        "authority_stage": "LAST_STEP_ONLY_AFTER_COMPLETE_FROZEN_SELECTOR_HANDOFF",
        "ai_upstream_authority": False,
        "plugins_support_allowed": True,
        "plugins_execution_authority": False,
        "training_target": "GLOBAL_WINNER_AND_TOP_0_1_CAPTURE_AT_5",
        "intelligence_scope": "GLOBAL_FRAMEWORK_ALL_SUPPORTED_SPORTS_ALL_MODES",
        "global_shared_reasoner": False,
        "global_order_intelligence_patch_id": GLOBAL_ORDER_INTELLIGENCE_PATCH_ID,
        "global_framework": True,
        "sport_mode_profile_role": "SPORT_MODE_ORDER_ADAPTER",
        "cross_sport_transfer_learning": False,
        "cross_sport_shared_coefficients": False,
        "preference_comparisons": "WITHIN_SLATE_ONLY",
        "mc_signal_doctrine_patch_id": mc_signal_doctrine.PATCH_ID,
        "mc_metrics_role": mc_signal_doctrine.MC_METRICS_ROLE,
        "raw_mc_literal_authority": False,
        "championship_head_policy_id": championship_head_policy.PATCH_ID,
        "top5_is_championship_neighborhood": True,
        "diversification_start_seat": championship_head_policy.DIVERSIFICATION_START_SEAT,
        "diversification_allowed_inside_head": False,
        "tennis_classic_rank1_posterior_policy": dict(TENNIS_CLASSIC_RANK1_POSTERIOR_POLICY),
        "forbidden_postlock_fields": sorted(FORBIDDEN_POSTLOCK_FIELDS),
    }



def entry_limit_selector_profile(*, field_size: int, max_entries: int, user_entries: int | None = None) -> dict[str,Any]:
    """Return the prelock contest-game profile consumed by terminal selection."""
    return entry_limit_game.profile_dict(
        field_size=field_size, max_entries=max_entries, user_entries=user_entries
    )


def select_entry_limit_portfolio(success_matrix, *, entry_budget: int, lineup_quality=None) -> dict[str,Any]:
    """Select by marginal first-place world coverage under the contest entry budget."""
    return entry_limit_game.select_joint_portfolio(
        success_matrix, entry_budget=entry_budget, lineup_quality=lineup_quality
    )

def _canonical_json(obj: object) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _lineup_id(row: Mapping[str, Any]) -> str:
    for k in ("LINEUP_ID","LINEUP_INDEX","ID"):
        v=row.get(k)
        if v not in (None, ""):
            return str(v)
    raise TerminalAIHybridError("RUN_INVALID:AI_CANDIDATE_MISSING_LINEUP_ID")


def _lineup_slots(row: Mapping[str, Any]) -> tuple[tuple[str,str], ...]:
    """Return the complete role-aware lineup slot map across Showdown and Classic schemas.

    v5 fixes the mixed Classic schema defect exposed by WNBA calibration: a row such as
    G1/G2/F1/F2/F3/UTIL must return all six players. UTIL is not allowed to short-circuit
    the position slots. Multiplier-only schemas still return CPT + UTIL1..UTIL5.
    """
    cmap={_norm(k):k for k in row}
    slots=[]
    used=set()

    # Multiplier role, if present.
    for role in ("CPT","CAPTAIN","MVP"):
        k=cmap.get(role)
        if k is not None and row.get(k) not in (None,""):
            slots.append(("CPT",str(row[k]).strip())); used.add(k); break

    # Classic / flat position schemas take precedence over a bare UTIL column.
    preferred=("QB","RB1","RB2","WR1","WR2","WR3","TE","FLEX","DST",
               "P1","P2","C","1B","2B","3B","SS","OF1","OF2","OF3",
               "G1","G2","G3","G4","G5","G6","F1","F2","F3","F4","F5","F6")
    classic_present=any(cmap.get(role) is not None and row.get(cmap.get(role)) not in (None,"") for role in preferred)
    if classic_present:
        for role in preferred:
            k=cmap.get(role)
            if k is not None and row.get(k) not in (None,""):
                slots.append((role,str(row[k]).strip())); used.add(k)
        # UTIL is part of the Classic lineup, not a separate schema.
        k=cmap.get("UTIL")
        if k is not None and k not in used and row.get(k) not in (None,""):
            slots.append(("UTIL",str(row[k]).strip())); used.add(k)
        for i in range(1,13):
            k=cmap.get(f"PLAYER{i}")
            if k is not None and k not in used and row.get(k) not in (None,""):
                slots.append((f"PLAYER{i}",str(row[k]).strip())); used.add(k)
        return tuple(slots)

    # Showdown / UTIL-only schemas.
    util_keys=[k for k in row if (_norm(k)=="UTIL" or (_norm(k).startswith("UTIL") and _norm(k)[4:].isdigit()))]
    for k in sorted(util_keys,key=lambda x:(_norm(x)!="UTIL",_norm(x))):
        if k not in used and row.get(k) not in (None,""):
            slots.append((_norm(k),str(row[k]).strip())); used.add(k)
    if row.get(cmap.get("UTILS",""),None) not in (None,""):
        text=str(row[cmap["UTILS"]]); sep="|" if "|" in text else ";" if ";" in text else ","
        for i,x in enumerate((x.strip() for x in text.split(sep) if x.strip()),1):
            slots.append((f"UTIL{i}",x))
    if slots: return tuple(slots)

    # Generic PLAYER1..PLAYER12 fallback.
    for i in range(1,13):
        k=cmap.get(f"PLAYER{i}")
        if k is not None and row.get(k) not in (None,""):
            slots.append((f"PLAYER{i}",str(row[k]).strip()))
    if not slots:
        # Sealed pipeline identity ledgers use P1_ID..Pn_ID and/or PLAYER_IDS.
        # These are immutable pre-lock identities and are valid relationship inputs.
        for i in range(1,13):
            k=cmap.get(f"P{i}_ID")
            if k is not None and row.get(k) not in (None,""):
                slots.append((f"PLAYER{i}",str(row[k]).strip()))
    if not slots:
        k=cmap.get("PLAYER_IDS") or cmap.get("PLAYERS")
        if k is not None and row.get(k) not in (None,""):
            text=str(row[k]); sep="|" if "|" in text else ";" if ";" in text else ","
            slots=[(f"PLAYER{i}",x.strip()) for i,x in enumerate(text.split(sep),1) if x.strip()]
    return tuple(slots)


def _players(row: Mapping[str, Any]) -> tuple[str, ...]:
    return tuple(v for _,v in _lineup_slots(row))


def validate_candidate_rows(rows: Sequence[Mapping[str, Any]]) -> None:
    if not rows:
        raise TerminalAIHybridError("RUN_INVALID:AI_TERMINAL_EMPTY_CANDIDATES")
    forbidden=sorted({_norm(k) for r in rows for k in r} & FORBIDDEN_POSTLOCK_FIELDS)
    if forbidden:
        raise TerminalAIHybridError("RUN_INVALID:POSTLOCK_FIELDS_ENTERED_AI_TERMINAL:"+",".join(forbidden))
    seen=set()
    for r in rows:
        lid=_lineup_id(r)
        if lid in seen:
            raise TerminalAIHybridError(f"RUN_INVALID:DUPLICATE_AI_LINEUP_ID:{lid}")
        seen.add(lid)
        p=_players(r)
        if p and len(p)!=len({x.casefold() for x in p}):
            raise TerminalAIHybridError(f"RUN_INVALID:DUPLICATE_PLAYER_IN_AI_CANDIDATE:{lid}")


def freeze_candidates(rows: Sequence[Mapping[str, Any]]) -> str:
    validate_candidate_rows(rows)
    ordered=sorted((dict(r) for r in rows), key=lambda r:_lineup_id(r))
    return sha256(_canonical_json(ordered)).hexdigest()


def feature_availability(rows: Sequence[Mapping[str, Any]]) -> dict[str, dict[str, int]]:
    cols={_norm(k) for r in rows for k in r}
    out={}
    for group,names in FEATURE_REGISTRY.items():
        present=[n for n in names if _norm(n) in cols]
        out[group]={"AVAILABLE":len(present),"DEFINED":len(names),"MISSING":len(names)-len(present)}
    return out


def _float(row: Mapping[str, Any], name: str, default: float=float("nan")) -> float:
    if name in row: k=name
    else:
        cmap={_norm(k):k for k in row}; k=cmap.get(_norm(name))
    if k is None: return default
    try:
        v=float(str(row.get(k,"")).replace("%","").replace(",","").strip())
        return v if math.isfinite(v) else default
    except Exception:
        return default


def _prob_value(row: Mapping[str, Any], name: str) -> float:
    if name in row: k=name
    else:
        cmap={_norm(k):k for k in row}; k=cmap.get(_norm(name))
    if k is None: return float("nan")
    raw=row.get(k)
    try: v=float(str(raw).replace("%","").strip())
    except Exception: return float("nan")
    if not math.isfinite(v) or v < 0: return float("nan")
    if isinstance(raw,str) and "%" in raw: return min(1.0,v/100.0)
    if v <= 1.0000001: return v
    if v <= 100.0000001: return v/100.0
    return float("nan")


def _pct(values: Sequence[float], higher: bool=True) -> list[float]:
    vals=[float(v) if math.isfinite(float(v)) else float("nan") for v in values]
    valid=sorted(set(v for v in vals if math.isfinite(v)))
    if not valid: return [float("nan")]*len(vals)
    if len(valid)==1: return [0.5 if math.isfinite(v) else float("nan") for v in vals]
    rank={v:i/(len(valid)-1) for i,v in enumerate(valid)}
    return [(rank[v] if higher else 1.0-rank[v]) if math.isfinite(v) else float("nan") for v in vals]


def _first_prob(row: Mapping[str,Any], *names: str) -> float:
    for n in names:
        v=_prob_value(row,n)
        if math.isfinite(v): return v
    return float("nan")


def _first_float(row: Mapping[str,Any], *names: str) -> float:
    for n in names:
        v=_float(row,n)
        if math.isfinite(v): return v
    return float("nan")


def _slot_aux(row: Mapping[str,Any], slot: str, suffix: str, cmap: Mapping[str,str]|None=None) -> Any:
    for name in (f"{slot}_{suffix}",f"{slot}{suffix}"):
        if name in row and row.get(name) not in (None,""): return row.get(name)
    cmap=dict(cmap) if cmap is not None else {_norm(k):k for k in row}
    for name in (f"{slot}_{suffix}",f"{slot}{suffix}"):
        k=cmap.get(_norm(name))
        if k is not None and row.get(k) not in (None,""): return row.get(k)
    return None


def _structural_relationship_features(rows: list[dict[str,Any]], *, sport: str, mode: str) -> None:
    """O(N * roster_size^2) relationship summaries with no pairwise candidate scan.

    Player sets are encoded as Python-int bitmasks.  Exact D1/D2 counts are
    recovered algebraically from subset frequencies; no candidate is removed.
    """
    profile=intelligence_profile(sport,mode)
    player_lists=[tuple(sorted(set(x.casefold() for x in _players(r) if x))) for r in rows]
    universe=sorted({x for arr in player_lists for x in arr}); player_to_bit={x:i for i,x in enumerate(universe)}
    masks=[]
    for arr in player_lists:
        mask=0
        for x in arr: mask |= (1<<player_to_bit[x])
        masks.append(mask)
    exact={}
    for i,mask in enumerate(masks): exact.setdefault(mask,[]).append(i)
    top01=[_first_prob(r,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01") for r in rows]
    p99=[_first_float(r,"MC_P99","BASE_MC_P99","P99") for r in rows]
    # aggregate = [row_count, top01_sum, top01_valid, p99_sum, p99_valid]
    def add(d,key,i):
        a=d.get(key)
        if a is None: a=[0,0.0,0,0.0,0]; d[key]=a
        a[0]+=1
        if math.isfinite(top01[i]): a[1]+=top01[i]; a[2]+=1
        if math.isfinite(p99[i]): a[3]+=p99[i]; a[4]+=1
    d1={}
    row_bits=[]
    for i,mask in enumerate(masks):
        bits=[]; z=mask
        while z:
            lsb=z & -z; bits.append(lsb); z-=lsb
        row_bits.append(bits)
        for b in bits: add(d1,mask^b,i)
    for i,r in enumerate(rows):
        arr=player_lists[i]; mask=masks[i]; bits=row_bits[i]; n=len(bits); fam=exact.get(mask,[]); fam_sib=max(0,len(fam)-1)
        r["AI_INTELLIGENCE_PROFILE_ID"]=profile["profile_id"]
        r["AI_PLAYERSET_CANONICAL"]="|".join(arr)
        r["AI_PLAYERSET_MASK"]=mask
        r["AI_PLAYERSET_SIZE"]=n
        r["AI_EXACT_PLAYERSET_FAMILY_ID"]=sha256("|".join(arr).encode()).hexdigest()[:16]
        r["AI_EXACT_PLAYERSET_SIBLING_COUNT"]=fam_sib
        fam_top=sum(top01[j] for j in fam if math.isfinite(top01[j])); fam_top_valid=sum(math.isfinite(top01[j]) for j in fam)
        fam_p99=sum(p99[j] for j in fam if math.isfinite(p99[j])); fam_p99_valid=sum(math.isfinite(p99[j]) for j in fam)
        if fam_top_valid: r["AI_EXACT_PLAYERSET_FAMILY_TOP01_MASS"]=round(fam_top,15)
        if profile.get("role_sensitive"):
            slots0=_lineup_slots(r); cpt0=next((p.casefold() for slot,p in slots0 if slot=="CPT"),"")
            ids=[]
            for j in fam:
                if j==i: continue
                cptj=next((p.casefold() for slot,p in _lineup_slots(rows[j]) if slot=="CPT"),"")
                if cptj!=cpt0: ids.append(_lineup_id(rows[j]))
            r["AI_RECIPROCAL_ROLE_SIBLING_COUNT"]=len(ids)
            if ids: r["AI_RECIPROCAL_ROLE_SIBLING_IDS"]="|".join(sorted(ids))
        else: r["AI_RECIPROCAL_ROLE_SIBLING_COUNT"]=0
        # D1 exact one-player mutation count/sums. Exact-family siblings appear in
        # each of n one-drop subsets, so subtract those repeats algebraically.
        sc=st=stv=sp=spv=0
        for b in bits:
            a=d1[mask^b]; sc+=a[0]-1; st+=a[1]-(top01[i] if math.isfinite(top01[i]) else 0.0); stv+=a[2]-(1 if math.isfinite(top01[i]) else 0); sp+=a[3]-(p99[i] if math.isfinite(p99[i]) else 0.0); spv+=a[4]-(1 if math.isfinite(p99[i]) else 0)
        d1_count=max(0,sc-n*fam_sib)
        d1_top_valid=max(0,stv-n*(fam_top_valid-(1 if math.isfinite(top01[i]) else 0)))
        d1_p99_valid=max(0,spv-n*(fam_p99_valid-(1 if math.isfinite(p99[i]) else 0)))
        d1_top=st-n*(fam_top-(top01[i] if math.isfinite(top01[i]) else 0.0))
        d1_p99=sp-n*(fam_p99-(p99[i] if math.isfinite(p99[i]) else 0.0))
        r["AI_D1_NEIGHBOR_COUNT"]=d1_count
        # Round only derived evidence serialization, not engine-owned inputs. This
        # removes addition-order floating noise and makes shuffled-row handoffs
        # semantically deterministic.
        if d1_top_valid: r["AI_D1_TOP01_DENSITY"]=round(d1_top/d1_top_valid,15)
        if d1_p99_valid: r["AI_D1_P99_DENSITY"]=round(d1_p99/d1_p99_valid,15)
        r["AI_D2_RELATIONSHIP_MODE"]="ON_DEMAND_NO_CANDIDATE_PRUNING" if profile.get("mutation_depth",1)>=2 else "NOT_PROFILED"
        # Team/script topology when native slot metadata is available.
        slots=_lineup_slots(r); teams=[]; role_team=None; orders=[]; supports=[]; cmap={_norm(k):k for k in r}
        for slot,_ in slots:
            team=_slot_aux(r,slot,"TEAM",cmap); order=_slot_aux(r,slot,"ORDER",cmap); sup=_slot_aux(r,slot,"CONDITIONAL_SUPPORT",cmap)
            if team not in (None,""):
                teams.append(str(team))
                if slot=="CPT": role_team=str(team)
            try: ov=int(float(order)) if order not in (None,"") else None
            except Exception: ov=None
            orders.append((slot,str(team) if team not in (None,"") else None,ov))
            try: supports.append(float(sup))
            except Exception: pass
        if teams:
            from collections import Counter
            c=Counter(teams); r["AI_TEAM_COUNT"]=len(c); r["AI_DOMINANT_TEAM_COUNT"]=max(c.values())
            if role_team is not None:
                r["AI_ROLE_SIDE_COUNT"]=c.get(role_team,0)
                batting=sorted(o for slot,t,o in orders if t==role_team and o is not None and 1<=o<=9)
                r["AI_ROLE_SIDE_HITTER_COUNT"]=len(batting)
                r["AI_BATTING_ADJACENCY_PAIRS"]=sum(1 for a,b in zip(batting,batting[1:]) if b-a==1)
        if supports: r["AI_LINEUP_CONDITIONAL_SUPPORT_SUM"]=sum(supports)


def enrich_ai_evidence(rows: Sequence[Mapping[str, Any]], *, sport: str, mode: str, copy_rows: bool=True) -> list[dict[str, Any]]:
    """Add transparent sport/mode-tailored evidence; never overwrite engine metrics.

    copy_rows=False is execution-only memory control for caller-owned transient row dicts;
    feature calculations and selector semantics are unchanged.
    """
    # Fail closed before any enrichment so realized/post-lock information can never
    # influence derived AI evidence, even transiently.
    validate_candidate_rows(rows)
    out=[dict(r) for r in rows] if copy_rows else (rows if isinstance(rows,list) and all(isinstance(r,dict) for r in rows) else [dict(r) for r in rows])
    profile=intelligence_profile(sport,mode)
    win=[_first_prob(r,"MC_WIN_RATE","BASE_MC_WIN_RATE","WIN") for r in out]
    win_l=[_first_prob(r,"MC_WIN_LCB","BASE_MC_WIN_LCB") for r in out]
    t01=[_first_prob(r,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01") for r in out]
    t01_l=[_first_prob(r,"MC_TOP_0_1_LCB","BASE_MC_TOP_0_1_LCB") for r in out]
    p99=[_first_float(r,"MC_P99","BASE_MC_P99","P99") for r in out]
    p95=[_first_float(r,"MC_P95","BASE_MC_P95","P95") for r in out]
    dup=[_first_float(r,"PROJECTED_EXACT_MATCH_DUPLICATION","DUP") for r in out]
    code=[_first_float(r,"CURRENT_SELECTOR_PRE_SCORE","CURRENT_SELECTOR_SCORE") for r in out]
    trials=[_first_float(r,"MC_TRIALS","BASE_MC_TRIALS") for r in out]
    world_cov=[_first_float(r,"WORLD_COVERAGE","WORLD_COVERAGE_COUNT","FAST_PATH_WORLD_COVERAGE_RATE") for r in out]
    total_rec=[_first_float(r,"TOTAL_RECURRENCE","FAST_PATH_TOTAL_RECURRENCE") for r in out]
    winp=_pct([x if math.isfinite(x) else -1 for x in win_l]); t01p=_pct([x if math.isfinite(x) else -1 for x in t01_l]); p99p=_pct(p99); dupp=_pct(dup,higher=False); codep=_pct(code); worldp=_pct(world_cov); recp=_pct(total_rec)
    # sport/mode-specific independent support composite is deliberately an average
    # percentile of available profile fields, not a hard selector score.
    market_arrays=[]
    for fld in profile.get("market_fields",()):
        vals=[_first_float(r,fld) for r in out]
        if any(math.isfinite(x) for x in vals): market_arrays.append(_pct(vals))
    for i,r in enumerate(out):
        r["AI_INTELLIGENCE_PROFILE_ID"]=profile["profile_id"]
        r["AI_PROFILE_FAMILY_BASIS"]=profile["family_basis"]
        r["AI_PROFILE_SCRIPT_AXIS"]=profile["script_axis"]
        r["AI_MC_SIGNAL_DOCTRINE_PATCH_ID"]=mc_signal_doctrine.PATCH_ID
        r["AI_MC_METRICS_ROLE"]=mc_signal_doctrine.MC_METRICS_ROLE
        r["AI_RAW_MC_LITERAL_AUTHORITY"]=False
        r["AI_CHAMPIONSHIP_HEAD_POLICY_ID"]=championship_head_policy.PATCH_ID
        r["AI_TOP5_IS_CHAMPIONSHIP_NEIGHBORHOOD"]=True
        r["AI_DIVERSIFICATION_ALLOWED_INSIDE_HEAD"]=False
        if math.isfinite(win[i]) and math.isfinite(win_l[i]): r["AI_WIN_UNCERTAINTY_GAP"]=max(0.0,win[i]-win_l[i])
        if math.isfinite(t01[i]) and math.isfinite(t01_l[i]): r["AI_TOP01_UNCERTAINTY_GAP"]=max(0.0,t01[i]-t01_l[i])
        if math.isfinite(p99[i]) and math.isfinite(p95[i]):
            r["AI_TAIL_SPREAD_P99_P95"]=p99[i]-p95[i]; r["AI_TAIL_ASYMMETRY"]=(p99[i]-p95[i])/max(1e-9,abs(p95[i]))
        if math.isfinite(dup[i]) and dup[i]>=0:
            if math.isfinite(win[i]): r["AI_DUP_ADJ_WIN"]=win[i]/(1+dup[i])
            if math.isfinite(t01[i]): r["AI_DUP_ADJ_TOP01"]=t01[i]/(1+dup[i])
        n=int(trials[i]) if math.isfinite(trials[i]) and trials[i]>=100 else 10000
        if math.isfinite(t01[i]): r["AI_TOP01_95_HALF_WIDTH"]=1.96*math.sqrt(max(0.0,t01[i]*(1-t01[i]))/n)
        if math.isfinite(win[i]): r["AI_WIN_95_HALF_WIDTH"]=1.96*math.sqrt(max(0.0,win[i]*(1-win[i]))/n)
        if math.isfinite(winp[i]): r["AI_WIN_LCB_PCTL"]=winp[i]
        if math.isfinite(t01p[i]): r["AI_TOP01_LCB_PCTL"]=t01p[i]
        if math.isfinite(p99p[i]): r["AI_P99_PCTL"]=p99p[i]
        if math.isfinite(dupp[i]): r["AI_LOW_DUP_PCTL"]=dupp[i]
        if math.isfinite(codep[i]): r["AI_CURRENT_SELECTOR_SCORE_PCTL"]=codep[i]
        if math.isfinite(worldp[i]): r["AI_WORLD_COVERAGE_PCTL"]=worldp[i]
        if math.isfinite(recp[i]): r["AI_TOTAL_RECURRENCE_PCTL"]=recp[i]
        if math.isfinite(worldp[i]):
            # User-governed priority: recurrence across many independent worlds is
            # primary; repeated hits concentrated inside fewer worlds are a tie-break.
            r["AI_CROSS_WORLD_BREADTH_PRIORITY"]=worldp[i] + (0.10*recp[i] if math.isfinite(recp[i]) else 0.0)
        support=[x for x in (winp[i],t01p[i],p99p[i],dupp[i]) if math.isfinite(x)]
        if support: r["AI_ELITE_SUPPORT_BREADTH"]=sum(x>=.90 for x in support); r["AI_ROBUST_TAIL_FLOOR_PCTL"]=min(support[:3]) if len(support)>=3 else min(support)
        if math.isfinite(t01p[i]) and math.isfinite(codep[i]): r["AI_TOP01_VS_CODE_DISAGREEMENT"]=t01p[i]-codep[i]
        if market_arrays:
            vals=[a[i] for a in market_arrays if math.isfinite(a[i])]
            if vals:
                mp=sum(vals)/len(vals); r["AI_MARKET_TAIL_SUPPORT_PCTL"]=mp
                if math.isfinite(t01p[i]): r["AI_MARKET_TAIL_VS_MC_DISAGREEMENT"]=mp-t01p[i]
    _structural_relationship_features(out,sport=sport,mode=mode)

    # Tennis Classic rank-1 recognition is retained as transparent pre-lock AI evidence.
    # Historical outcomes calibrate this policy offline; realized results never enter forward rows.
    if profile.get("sport")=="TENNIS" and profile.get("mode")=="CLASSIC":
        pol=TENNIS_CLASSIC_RANK1_POSTERIOR_POLICY
        t01_eff=[_first_prob(r,"MC_TOP_0_1_LCB","BASE_MC_TOP_0_1_LCB","MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP_0_1_RATE","TOP01") for r in out]
        win_eff=[_first_prob(r,"MC_WIN_LCB","BASE_MC_WIN_LCB","MC_WIN_RATE","BASE_MC_WIN_RATE","WIN_RATE","WIN") for r in out]
        p99v=[_first_float(r,"MC_P99","BASE_MC_P99","P99") for r in out]
        cvarv=[_first_float(r,"MC_CVAR99","BASE_MC_CVAR99","CVAR99") for r in out]
        d1v=[_first_float(r,"AI_D1_TOP01_DENSITY") for r in out]
        marketv=[_first_float(r,"AI_MARKET_TAIL_SUPPORT_PCTL") for r in out]
        dupv=[_first_float(r,"PROJECTED_EXACT_MATCH_DUPLICATION","DUP") for r in out]
        hwv=[_first_float(r,"AI_TOP01_95_HALF_WIDTH") for r in out]
        same_match=[_first_float(r,"SAME_MATCH_PAIR_COUNT") for r in out]
        player_stats={}
        for i,r in enumerate(out):
            for pl in _players(r):
                key=str(pl).casefold(); a=player_stats.get(key)
                if a is None: a=[0,0.0,0,0.0,0]; player_stats[key]=a
                a[0]+=1
                if math.isfinite(t01_eff[i]): a[1]+=t01_eff[i]; a[2]+=1
                if math.isfinite(win_eff[i]): a[3]+=win_eff[i]; a[4]+=1
        core_t01=[]; core_win=[]
        for r in out:
            tv=[]; wv=[]
            for pl in _players(r):
                a=player_stats.get(str(pl).casefold())
                if not a: continue
                if a[2]: tv.append(a[1]/a[2])
                if a[4]: wv.append(a[3]/a[4])
            core_t01.append(sum(tv)/len(tv) if tv else float("nan"))
            core_win.append(sum(wv)/len(wv) if wv else float("nan"))
        core_t01_p=_pct(core_t01); core_win_p=_pct(core_win); d1p=_pct(d1v)
        t01e_p=_pct(t01_eff); wine_p=_pct(win_eff); p99e_p=_pct(p99v); cvare_p=_pct(cvarv)
        lowdup_p=_pct(dupv,higher=False); stability_p=_pct(hwv,higher=False)
        raw=[]
        for i,r in enumerate(out):
            def v(arr,default=.5):
                x=arr[i]; return x if math.isfinite(x) else default
            score=(pol["player_core_top01_density_weight"]*v(core_t01_p)+pol["player_core_win_density_weight"]*v(core_win_p)+
                   pol["d1_top01_density_weight"]*v(d1p)+pol["top01_lcb_weight"]*v(t01e_p)+pol["win_lcb_weight"]*v(wine_p)+
                   pol["p99_weight"]*v(p99e_p)+pol["cvar99_weight"]*v(cvare_p)+pol["market_support_weight"]*v(marketv)+
                   pol["low_dup_weight"]*v(lowdup_p)+pol["uncertainty_stability_weight"]*v(stability_p))
            sm=same_match[i]
            if math.isfinite(sm) and sm>0:
                relief=pol["same_match_elite_tail_relief_max"]*min(v(t01e_p),v(p99e_p))
                score-=pol["same_match_pair_penalty"]*min(1.0,sm)*(1.0-relief)
            raw.append(score)
            r["AI_TENNIS_PLAYER_CORE_TOP01_DENSITY"]=round(core_t01[i],15) if math.isfinite(core_t01[i]) else ""
            r["AI_TENNIS_PLAYER_CORE_WIN_DENSITY"]=round(core_win[i],15) if math.isfinite(core_win[i]) else ""
            r["AI_TENNIS_D1_TOP01_DENSITY_PCTL"]=d1p[i] if math.isfinite(d1p[i]) else ""
            r["AI_TENNIS_RANK1_POSTERIOR"]=round(score,12)
            r["AI_TENNIS_TOP01_TAIL_CONSENSUS"]=round(min(v(core_t01_p),v(d1p),v(t01e_p),v(p99e_p),v(cvare_p)),12)
        postp=_pct(raw)
        for i,r in enumerate(out):
            posterior_pctl=postp[i] if math.isfinite(postp[i]) else float("nan")
            selector_pctl=codep[i] if math.isfinite(codep[i]) else float("nan")
            gap=(posterior_pctl-selector_pctl) if math.isfinite(posterior_pctl) and math.isfinite(selector_pctl) else float("nan")
            r["AI_TENNIS_RANK1_POSTERIOR_PCTL"]=posterior_pctl if math.isfinite(posterior_pctl) else ""
            r["AI_TENNIS_SELECTOR_UNDERRANK_GAP"]=round(gap,12) if math.isfinite(gap) else ""
            r["AI_TENNIS_RANK1_RECOVERY_FLAG"]=bool(
                math.isfinite(posterior_pctl) and math.isfinite(selector_pctl) and math.isfinite(gap) and
                posterior_pctl >= pol["recovery_posterior_pctl_min"] and
                selector_pctl <= pol["recovery_selector_pctl_max"] and
                gap >= pol["recovery_underrank_gap_min"]
            )

    # Mandatory global order-intelligence surface.  This never mutates membership.
    # Sport/mode-specific evidence is supplied as an adapter channel; coefficients are
    # not learned/shared across sports.
    native=[]; world=[]; stability=[]; duplication=[]; tier=[]; tier_score=[]
    for r in out:
        native.append(_first_float(r,"SPORT_NATIVE_ORDER_SCORE","AI_TENNIS_RANK1_POSTERIOR","AI_MARKET_TAIL_SUPPORT_PCTL","STRATEGY_SCORE"))
        world.append(_first_float(r,"AI_CROSS_WORLD_BREADTH_PRIORITY","WORLD_COVERAGE","WORLD_COVERAGE_COUNT","FAST_PATH_WORLD_COVERAGE_RATE"))
        stability.append(_first_float(r,"RANK_STABILITY","CROSS_SEED_STABILITY","CALIBRATION_STABILITY"))
        duplication.append(_first_float(r,"PROJECTED_EXACT_MATCH_DUPLICATION","DUP"))
        _tier = _first_float(r,"SPORT_NATIVE_ORDER_TIER")
        tier.append(_tier if math.isfinite(_tier) else 0.0)
        tier_score.append(_first_float(r,"SPORT_NATIVE_ORDER_PRIORITY_SCORE","SPORT_NATIVE_ORDER_SCORE","AI_TENNIS_RANK1_POSTERIOR"))
    gom={
        "top01_lcb":[_first_prob(r,"MC_TOP_0_1_LCB","BASE_MC_TOP_0_1_LCB","MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE") for r in out],
        "win_rate":[_first_prob(r,"MC_WIN_LCB","BASE_MC_WIN_LCB","MC_WIN_RATE","BASE_MC_WIN_RATE") for r in out],
        "p99":[_first_float(r,"MC_P99","BASE_MC_P99","P99") for r in out],
        "p95":[_first_float(r,"MC_P95","BASE_MC_P95","P95") for r in out],
        "rank_uncertainty_width":[_first_float(r,"AI_TOP01_95_HALF_WIDTH") for r in out],
    }
    go=global_order.rank_surface(
        gom,sport=sport,mode=mode,sport_native_score=native,world_breadth=world,
        rank_stability=stability,projected_duplication=duplication,
        expected_rank=[_first_float(r,"AI_EXPECTED_CONTEST_RANK","EXPECTED_RANK","POSTERIOR_EXPECTED_RANK") for r in out],
        median_rank=[_first_float(r,"AI_MEDIAN_CONTEST_RANK","MEDIAN_RANK","POSTERIOR_MEDIAN_RANK") for r in out],
        rank_p90=[_first_float(r,"AI_CONTEST_RANK_P90","RANK_P90","POSTERIOR_RANK_P90") for r in out],
        pairwise_strength=[_first_float(r,"AI_PAIRWISE_ORDER_STRENGTH","PAIRWISE_STRENGTH","PAIRWISE_BEAT_PROB") for r in out],
        adapter_priority_tier=tier,adapter_priority_score=tier_score,
        adapter_id=profile["profile_id"],adapter_live_authority=bool(profile.get("global_order_adapter_live",False)),
    )
    for i,r in enumerate(out):
        r["GLOBAL_ORDER_SCORE"]=float(go.order_score[i])
        r["GLOBAL_ORDER_RANK"]=int(go.order_rank[i])
        r["GLOBAL_ORDER_CONFIDENCE"]=float(go.order_confidence[i])
        r["GLOBAL_ORDER_UNCERTAINTY_WIDTH"]=float(go.rank_uncertainty_width[i])
        r["GLOBAL_MOST_PROBABLE_BEST_SCORE"]=float(go.most_probable_best_score[i])
        r["GLOBAL_EXTREME_TAIL_SCORE"]=float(go.extreme_tail_score[i])
        r["GLOBAL_ORDINAL_POSTERIOR_SCORE"]=float(go.ordinal_posterior_score[i]) if math.isfinite(float(go.ordinal_posterior_score[i])) else ""
        r["GLOBAL_ORDER_PATCH_ID"]=global_order.PATCH_ID
    return out


def find_local_mutations(rows: Sequence[Mapping[str,Any]], anchor_id: str|int, *, sport: str, mode: str,
                         distance: int=1, preserve_role: bool=True) -> list[dict[str,Any]]:
    """Return existing local mutation candidates without pruning the AI universe.

    Uses enriched deterministic player-set bitmasks when present. The returned
    list is an analysis view; every original candidate remains AI eligible.
    """
    profile=intelligence_profile(sport,mode); by={_lineup_id(r):r for r in rows}; aid=str(anchor_id)
    if aid not in by: raise TerminalAIHybridError(f"RUN_INVALID:AI_MUTATION_ANCHOR_UNKNOWN:{aid}")
    anchor=by[aid]
    try: am=int(anchor.get("AI_PLAYERSET_MASK")); an=int(anchor.get("AI_PLAYERSET_SIZE"))
    except Exception:
        aset=set(x.casefold() for x in _players(anchor)); an=len(aset); universe=sorted({x.casefold() for r in rows for x in _players(r)}); mp={x:i for i,x in enumerate(universe)}; am=sum(1<<mp[x] for x in aset)
    anchor_role=next((p.casefold() for slot,p in _lineup_slots(anchor) if slot=="CPT"),"") if profile.get("role_sensitive") else ""
    out=[]
    for r in rows:
        if _lineup_id(r)==aid: continue
        if preserve_role and profile.get("role_sensitive"):
            role=next((p.casefold() for slot,p in _lineup_slots(r) if slot=="CPT"),"")
            if role!=anchor_role: continue
        try: cm=int(r.get("AI_PLAYERSET_MASK")); cn=int(r.get("AI_PLAYERSET_SIZE"))
        except Exception: continue
        if cn!=an: continue
        # For equal-size sets, one player mutation => xor has 2 bits; two => 4.
        if (am^cm).bit_count()!=2*int(distance): continue
        cand=dict(r)
        cand["AI_MUTATION_DISTANCE"]=int(distance)
        cand["AI_MUTATION_SHARED_PLAYERS"]=an-int(distance)
        out.append(cand)
    return out


def mutation_relationship(anchor: Mapping[str,Any], candidate: Mapping[str,Any], *, sport: str, mode: str) -> dict[str,Any]:
    """Mechanically compare two existing candidates; no selection or pruning occurs."""
    profile=intelligence_profile(sport,mode); ap=set(x.casefold() for x in _players(anchor)); cp=set(x.casefold() for x in _players(candidate))
    shared=len(ap&cp); dist=max(len(ap),len(cp))-shared
    at=_first_prob(anchor,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01"); ct=_first_prob(candidate,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01")
    aw=_first_prob(anchor,"MC_WIN_RATE","BASE_MC_WIN_RATE","WIN"); cw=_first_prob(candidate,"MC_WIN_RATE","BASE_MC_WIN_RATE","WIN")
    n=int(_first_float(anchor,"MC_TRIALS","BASE_MC_TRIALS")) if math.isfinite(_first_float(anchor,"MC_TRIALS","BASE_MC_TRIALS")) else 10000
    tb=1.96*math.sqrt(max(0.0,at*(1-at))/max(100,n)) if math.isfinite(at) else float("nan")
    wb=1.96*math.sqrt(max(0.0,aw*(1-aw))/max(100,n)) if math.isfinite(aw) else float("nan")
    out={"ANCHOR_LINEUP_ID":_lineup_id(anchor),"CANDIDATE_LINEUP_ID":_lineup_id(candidate),"SHARED_PLAYERS":shared,"MUTATION_DISTANCE":dist,"PROFILE_ID":profile["profile_id"]}
    if math.isfinite(at) and math.isfinite(ct): out["DELTA_TOP01"]=ct-at; out["TOP01_EQUIVALENT_95"]=abs(ct-at)<=tb
    if math.isfinite(aw) and math.isfinite(cw): out["DELTA_WIN"]=cw-aw; out["WIN_EQUIVALENT_95"]=abs(cw-aw)<=wb
    for key,names in {"DELTA_P95":("MC_P95","BASE_MC_P95","P95"),"DELTA_P99":("MC_P99","BASE_MC_P99","P99"),"DELTA_TOP10":("MC_TOP10_RATE","BASE_MC_TOP10_RATE","TOP10")}.items():
        a=_first_prob(anchor,*names) if "TOP10" in key else _first_float(anchor,*names); c=_first_prob(candidate,*names) if "TOP10" in key else _first_float(candidate,*names)
        if math.isfinite(a) and math.isfinite(c): out[key]=c-a
    out["SALARY_DELTA"]=_first_float(candidate,"SALARY")-_first_float(anchor,"SALARY") if math.isfinite(_first_float(candidate,"SALARY")) and math.isfinite(_first_float(anchor,"SALARY")) else float("nan")
    # Compare already-derived script evidence if present.
    for fld in ("AI_ROLE_SIDE_COUNT","AI_ROLE_SIDE_HITTER_COUNT","AI_BATTING_ADJACENCY_PAIRS","AI_LINEUP_CONDITIONAL_SUPPORT_SUM"):
        a=_first_float(anchor,fld); c=_first_float(candidate,fld)
        if math.isfinite(a) and math.isfinite(c): out[f"DELTA_{fld.removeprefix('AI_')}"]=c-a
    return out




def _role_swap_cpt_name(row: Mapping[str,Any]) -> str:
    return next((p for slot,p in _lineup_slots(row) if slot=="CPT"), "")

def _role_swap_is_hitter_cpt(row: Mapping[str,Any]) -> bool:
    role=_norm(row.get("CPT_ROLE", row.get("CAPTAIN_ROLE", row.get("CPT_POS", ""))))
    if role in {"SP","P","PITCHER","STARTING_PITCHER"}:
        return False
    if role in {"HITTER","BATTER","C","1B","2B","3B","SS","OF","DH"}:
        return True
    # When role metadata is absent, never guess from the player name.
    return False

def _role_swap_prob_band(row: Mapping[str,Any], p: float) -> float:
    n=_first_float(row,"MC_TRIALS","BASE_MC_TRIALS","TRIALS")
    n=int(n) if math.isfinite(n) and n>=100 else 10000
    if not math.isfinite(p):
        return float("nan")
    return 1.96*math.sqrt(max(0.0,p*(1.0-p))/n)

def _role_swap_metric(row: Mapping[str,Any], names: Sequence[str], default: float=float("nan")) -> float:
    return _metric_any(row,tuple(names),default)

def mlb_sd_role_swap_evidence(anchor: Mapping[str,Any], candidate: Mapping[str,Any]) -> dict[str,Any]:
    """Compare exact-player-set MLB Showdown CPT siblings without pruning either row.

    TailSacrifice is a feasibility gate, not a compensating score term. The Hitter-CPT
    candidate is lane-eligible only when its MC Top-0.1 loss is inside the joint 95%
    uncertainty band (with the engine's existing 0.002 absolute probability floor).
    MC remains a diagnostic guard; it does not become terminal ranking truth.
    """
    ap=tuple(sorted(x.casefold() for x in _players(anchor)))
    cp=tuple(sorted(x.casefold() for x in _players(candidate)))
    if ap!=cp:
        raise TerminalAIHybridError("RUN_INVALID:MLB_SD_ROLE_SWAP_PLAYERSET_MISMATCH")
    acpt=_role_swap_cpt_name(anchor); ccpt=_role_swap_cpt_name(candidate)
    if not acpt or not ccpt or acpt.casefold()==ccpt.casefold():
        raise TerminalAIHybridError("RUN_INVALID:MLB_SD_ROLE_SWAP_CPT_NOT_RECIPROCAL")

    at=_first_prob(anchor,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01")
    ct=_first_prob(candidate,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01")
    ab=_role_swap_prob_band(anchor,at); cb=_role_swap_prob_band(candidate,ct)
    finite_bands=[x for x in (ab,cb,0.002) if math.isfinite(x)]
    eq_band=max(finite_bands) if finite_bands else 0.002
    raw_loss=(at-ct) if math.isfinite(at) and math.isfinite(ct) else float("nan")
    excess=max(0.0,raw_loss-eq_band) if math.isfinite(raw_loss) else float("nan")
    tail_eq=(not math.isfinite(raw_loss)) or raw_loss<=eq_band

    aown=_role_swap_metric(anchor,("CPT_OWNERSHIP","CPT_OWN","ROLE_CPT_OWNERSHIP","PROJECTED_CPT_OWNERSHIP"))
    cown=_role_swap_metric(candidate,("CPT_OWNERSHIP","CPT_OWN","ROLE_CPT_OWNERSHIP","PROJECTED_CPT_OWNERSHIP"))
    eps=0.05  # percentage-point stabilizer; prevents singular 1/p leverage explosions
    role_lev=math.log((max(aown,0.0)+eps)/(max(cown,0.0)+eps)) if math.isfinite(aown) and math.isfinite(cown) else float("nan")

    adup=_role_swap_metric(anchor,("PROJECTED_EXACT_MATCH_DUPLICATION","EXPECTED_DUPLICATES","DUPLICATION","DUPES"))
    cdup=_role_swap_metric(candidate,("PROJECTED_EXACT_MATCH_DUPLICATION","EXPECTED_DUPLICATES","DUPLICATION","DUPES"))
    dup_release=math.log((max(adup,0.0)+1.0)/(max(cdup,0.0)+1.0)) if math.isfinite(adup) and math.isfinite(cdup) else float("nan")

    asal=_role_swap_metric(anchor,("SALARY","TOTAL_SALARY")); csal=_role_swap_metric(candidate,("SALARY","TOTAL_SALARY"))
    salary_release=(asal-csal) if math.isfinite(asal) and math.isfinite(csal) else float("nan")
    ap99=_first_float(anchor,"MC_P99","BASE_MC_P99","P99"); cp99=_first_float(candidate,"MC_P99","BASE_MC_P99","P99")

    hitter=_role_swap_is_hitter_cpt(candidate)
    lane_eligible=bool(hitter and tail_eq)
    return {
        "ANCHOR_LINEUP_ID":_lineup_id(anchor),
        "CANDIDATE_LINEUP_ID":_lineup_id(candidate),
        "ANCHOR_CPT":acpt,"CANDIDATE_CPT":ccpt,
        "EXACT_PLAYERSET_ROLE_SWAP":True,
        "HITTER_CPT_CANDIDATE":hitter,
        "DELTA_TOP01":(ct-at) if math.isfinite(at) and math.isfinite(ct) else None,
        "TAIL_EQUIVALENCE_95_BAND":eq_band,
        "TAIL_SACRIFICE_RAW":raw_loss if math.isfinite(raw_loss) else None,
        "TAIL_SACRIFICE_EXCESS":excess if math.isfinite(excess) else None,
        "ROLE_SWAP_TAIL_EQUIVALENT_95":bool(tail_eq),
        "DELTA_P99":(cp99-ap99) if math.isfinite(cp99) and math.isfinite(ap99) else None,
        "ROLE_LEVERAGE_LOG_RATIO":role_lev if math.isfinite(role_lev) else None,
        "DUPLICATION_RELEASE_LOG_RATIO":dup_release if math.isfinite(dup_release) else None,
        "SAME_SET_SALARY_RELEASE":salary_release if math.isfinite(salary_release) else None,
        "MLB_SD_HITTER_CPT_DISCONTINUITY_LANE_ELIGIBLE":lane_eligible,
        "TAIL_SACRIFICE_MODE":"FEASIBILITY_GATE_NOT_LINEAR_PENALTY",
        "P99_AUTHORITY":"DIAGNOSTIC_ONLY",
    }

def mlb_sd_exact_role_swap_family(rows: Sequence[Mapping[str,Any]], seed_id: str|int) -> list[dict[str,Any]]:
    """Return exact-player-set reciprocal-CPT evidence around one MLB SD seed."""
    validate_candidate_rows(rows)
    enriched=enrich_ai_evidence([dict(r) for r in rows],sport="MLB",mode="SHOWDOWN")
    by={_lineup_id(r):r for r in enriched}; sid=str(seed_id)
    if sid not in by:
        raise TerminalAIHybridError(f"RUN_INVALID:MLB_SD_ROLE_SWAP_SEED_UNKNOWN:{sid}")
    seed=by[sid]; fam_id=seed.get("AI_EXACT_PLAYERSET_FAMILY_ID")
    out=[]
    for r in enriched:
        if _lineup_id(r)==sid or r.get("AI_EXACT_PLAYERSET_FAMILY_ID")!=fam_id:
            continue
        if _role_swap_cpt_name(r).casefold()==_role_swap_cpt_name(seed).casefold():
            continue
        out.append(mlb_sd_role_swap_evidence(seed,r))
    return sorted(out,key=lambda x:(not x["MLB_SD_HITTER_CPT_DISCONTINUITY_LANE_ELIGIBLE"], -(x["ROLE_LEVERAGE_LOG_RATIO"] or -1e9), x["CANDIDATE_LINEUP_ID"]))



def _mlb_sd_sp_names(row: Mapping[str,Any]) -> frozenset[str]:
    """Return role-confirmed starting pitchers in one MLB Showdown lineup.

    Uses slot/player metadata only. It never infers pitcher identity from names.
    """
    cmap={_norm(k):k for k in row}
    out=set()
    for slot,player in _lineup_slots(row):
        role=_slot_aux(row,slot,"ROLE",cmap) or _slot_aux(row,slot,"POS",cmap) or _slot_aux(row,slot,"POSITION",cmap)
        starter=_slot_aux(row,slot,"CONFIRMED_STARTER",cmap)
        rr=_norm(role)
        starter_ok=(str(starter).strip().upper() in {"1","TRUE","T","YES","Y"}) if starter not in (None,"") else True
        if rr in {"SP","P","PITCHER","STARTING_PITCHER"} and starter_ok:
            out.add(str(player).strip().casefold())
    return frozenset(out)

def _mlb_sd_team_shape(row: Mapping[str,Any]) -> tuple[int,int]|None:
    """Coarse structural family: (team_count, dominant_team_count) when metadata exists."""
    tc=_first_float(row,"AI_TEAM_COUNT","TEAM_COUNT")
    dc=_first_float(row,"AI_DOMINANT_TEAM_COUNT","DOMINANT_TEAM_COUNT","MAX_TEAM_COUNT")
    if math.isfinite(tc) and math.isfinite(dc):
        return int(tc),int(dc)
    cmap={_norm(k):k for k in row}; teams=[]
    for slot,_ in _lineup_slots(row):
        team=_slot_aux(row,slot,"TEAM",cmap)
        if team not in (None,""): teams.append(str(team))
    if not teams: return None
    from collections import Counter
    c=Counter(teams)
    return len(c),max(c.values())

def _mlb_sd_structural_family_token(row: Mapping[str,Any]) -> tuple[Any,...]:
    """Frozen MLB-SD family identity for ROLE_SWAP_ONLY laboratory comparisons.

    Uses only pre-existing structural metadata. Missing fields are represented by None;
    no player/team/post-lock truth is introduced.
    """
    def first(names):
        for n in names:
            v=row.get(n)
            if v not in (None,""):
                return _norm(v)
        return None
    return (
        first(("STRUCTURAL_FAMILY","FAMILY","BRANCH","ROUTE")),
        first(("STACK_SHAPE","TEAM_SPLIT","TEAM_SHAPE")),
        first(("GAME_SCRIPT_CLASS","SCENARIO_ID","SCRIPT_CLASS")),
        int(_first_float(row,"SP_COUNT")) if math.isfinite(_first_float(row,"SP_COUNT")) else None,
        _mlb_sd_team_shape(row),
    )

def mlb_sd_role_swap_closure_neighborhood(rows: Sequence[Mapping[str,Any]], anchor_id: str|int) -> list[dict[str,Any]]:
    """Frozen one-player closure laboratory: exact six identities, CPT/UTIL role swap only.

    Hard invariants:
      * Hamming radius = 1 in role assignment, not player identity;
      * exact same six-player set;
      * CPT changes to one former UTIL and prior CPT remains in the six-player set;
      * confirmed-SP set unchanged;
      * structural family/team shape unchanged when metadata is available;
      * Dual-SP state unchanged;
      * salary is legality/feasibility only and never a positive objective term;
      * tail equivalence is a hard protected-lane gate;
      * role dislocation / duplication release are sibling-ranking evidence only.
    """
    validate_candidate_rows(rows)
    enriched=enrich_ai_evidence([dict(r) for r in rows],sport="MLB",mode="SHOWDOWN")
    by={_lineup_id(r):r for r in enriched}; aid=str(anchor_id)
    if aid not in by:
        raise TerminalAIHybridError(f"RUN_INVALID:MLB_SD_ROLE_SWAP_ANCHOR_UNKNOWN:{aid}")
    a=by[aid]
    aset=frozenset(x.casefold() for x in _players(a)); acpt=_role_swap_cpt_name(a).casefold()
    if len(aset)!=6 or not acpt:
        raise TerminalAIHybridError("RUN_INVALID:MLB_SD_ROLE_SWAP_ANCHOR_SCHEMA")
    asp=_mlb_sd_sp_names(a); afam=_mlb_sd_structural_family_token(a)
    a_dual=(len(asp)==2) if asp else (int(_first_float(a,"SP_COUNT"))==2 if math.isfinite(_first_float(a,"SP_COUNT")) else None)
    out=[]
    for r in enriched:
        lid=_lineup_id(r)
        if lid==aid: continue
        cset=frozenset(x.casefold() for x in _players(r)); ccpt=_role_swap_cpt_name(r).casefold()
        if cset!=aset or not ccpt or ccpt==acpt: continue
        # Reciprocal role swap: new CPT was a member of anchor UTIL set; old CPT remains rostered.
        if ccpt not in aset or acpt not in cset: continue
        csp=_mlb_sd_sp_names(r)
        if asp and csp!=asp: continue
        cfam=_mlb_sd_structural_family_token(r)
        # Compare only dimensions known on both rows; unknown metadata cannot manufacture a mismatch.
        fam_mismatch=False
        for av,cv in zip(afam,cfam):
            if av is not None and cv is not None and av!=cv:
                fam_mismatch=True; break
        if fam_mismatch: continue
        c_dual=(len(csp)==2) if csp else (int(_first_float(r,"SP_COUNT"))==2 if math.isfinite(_first_float(r,"SP_COUNT")) else None)
        if a_dual is not None and c_dual is not None and a_dual!=c_dual: continue

        ev=mlb_sd_role_swap_evidence(a,r)
        ev.update({
            "CLOSURE_RADIUS":1,
            "CLOSURE_CLASS":"ROLE_SWAP_ONLY",
            "PLAYER_SET_FROZEN":True,
            "PLAYER_ADDITIONS":0,
            "PLAYER_REMOVALS":0,
            "STRUCTURAL_FAMILY_FROZEN":True,
            "SP_SET_FROZEN":True,
            "DUAL_SP_STATE_FROZEN":True if a_dual is not None else None,
            "CHALK_UTIL_SPINE_RETENTION":1.0,
            "SALARY_OBJECTIVE":"CONSTRAINT_ONLY",
            "RAW_SALARY_SAVINGS_REWARD":False,
            "CLOSURE_CONTRACT":"EXACT_PLAYERSET_RECIPROCAL_CPT_ROLE_SWAP_ONLY",
        })
        out.append(ev)
    return sorted(out,key=lambda x:(
        not x["MLB_SD_HITTER_CPT_DISCONTINUITY_LANE_ELIGIBLE"],
        -(x["ROLE_LEVERAGE_LOG_RATIO"] if x["ROLE_LEVERAGE_LOG_RATIO"] is not None else -1e9),
        -(x["DUPLICATION_RELEASE_LOG_RATIO"] if x["DUPLICATION_RELEASE_LOG_RATIO"] is not None else -1e9),
        x["CANDIDATE_LINEUP_ID"],
    ))

# Compatibility name retained for research callers, but semantics are now the frozen
# ROLE_SWAP_ONLY contract. No one-bat player mutation remains active in this candidate.
def mlb_sd_one_bat_closure_neighborhood(rows: Sequence[Mapping[str,Any]], anchor_id: str|int) -> list[dict[str,Any]]:
    return mlb_sd_role_swap_closure_neighborhood(rows,anchor_id)

def championship_deck_relationships(rows: Sequence[Mapping[str,Any]], seed_id: str|int, *, sport: str, mode: str) -> list[dict[str,Any]]:
    """Return probability-equivalent local siblings around an existing seed lineup.

    This is an evidence view only: it never prunes the full handoff and never chooses the
    final board. For non-multiplier WNBA Classic, the calibrated default is a 5-of-6
    one-player sibling family. Repeated incoming players are retained when they occupy
    different mutation seats; that is championship-deck evidence, not duplication.
    """
    validate_candidate_rows(rows)
    profile=intelligence_profile(sport,mode)
    by={_lineup_id(r):r for r in rows}; sid=str(seed_id)
    if sid not in by: raise TerminalAIHybridError(f"RUN_INVALID:AI_CHAMPIONSHIP_DECK_SEED_UNKNOWN:{sid}")
    seed=by[sid]; splayers=tuple(x.casefold() for x in _players(seed)); sset=set(splayers)
    required=int(profile.get("family_overlap_required", max(1,len(sset)-1)))
    if required >= len(sset): required=max(1,len(sset)-1)
    st01=_first_prob(seed,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01")
    swin=_first_prob(seed,"MC_WIN_RATE","BASE_MC_WIN_RATE","WIN")
    sn=_first_float(seed,"MC_TRIALS","BASE_MC_TRIALS")
    sn=int(sn) if math.isfinite(sn) and sn>=100 else 10000
    sb01=1.96*math.sqrt(max(0.0,st01*(1-st01))/sn) if math.isfinite(st01) else float("nan")
    sbwin=1.96*math.sqrt(max(0.0,swin*(1-swin))/sn) if math.isfinite(swin) else float("nan")
    out=[]
    for r in rows:
        lid=_lineup_id(r)
        if lid==sid: continue
        p=tuple(x.casefold() for x in _players(r)); pset=set(p)
        overlap=len(sset & pset)
        if overlap < required: continue
        # v5 championship deck is local; WNBA Classic defaults to exact one-player siblings.
        if profile.get("championship_deck") and overlap != len(sset)-1: continue
        ct01=_first_prob(r,"MC_TOP_0_1_RATE","BASE_MC_TOP_0_1_RATE","TOP01")
        cwin=_first_prob(r,"MC_WIN_RATE","BASE_MC_WIN_RATE","WIN")
        cn=_first_float(r,"MC_TRIALS","BASE_MC_TRIALS"); cn=int(cn) if math.isfinite(cn) and cn>=100 else sn
        cb01=1.96*math.sqrt(max(0.0,ct01*(1-ct01))/cn) if math.isfinite(ct01) else float("nan")
        cbwin=1.96*math.sqrt(max(0.0,cwin*(1-cwin))/cn) if math.isfinite(cwin) else float("nan")
        top_band=max(x for x in (sb01,cb01,0.002) if math.isfinite(x)) if math.isfinite(st01) and math.isfinite(ct01) else float("nan")
        win_band=max(x for x in (sbwin,cbwin,0.002) if math.isfinite(x)) if math.isfinite(swin) and math.isfinite(cwin) else float("nan")
        top_eq=(not math.isfinite(top_band)) or abs(ct01-st01)<=top_band
        win_eq=(not math.isfinite(win_band)) or abs(cwin-swin)<=win_band
        if profile.get("probability_equivalence_95") and not (top_eq and win_eq): continue
        incoming=sorted(pset-sset); outgoing=sorted(sset-pset)
        out.append({
            "SEED_LINEUP_ID":sid,"CANDIDATE_LINEUP_ID":lid,"OVERLAP_WITH_SEED":overlap,
            "INCOMING_PLAYERS":"|".join(incoming),"OUTGOING_PLAYERS":"|".join(outgoing),
            "DELTA_TOP01":ct01-st01 if math.isfinite(ct01) and math.isfinite(st01) else None,
            "TOP01_95_EQUIVALENCE_BAND":top_band if math.isfinite(top_band) else None,
            "DELTA_WIN":cwin-swin if math.isfinite(cwin) and math.isfinite(swin) else None,
            "WIN_95_EQUIVALENCE_BAND":win_band if math.isfinite(win_band) else None,
            "PROBABILITY_EQUIVALENT_95":bool(top_eq and win_eq),
            "DELTA_P95":_first_float(r,"MC_P95","BASE_MC_P95","P95")-_first_float(seed,"MC_P95","BASE_MC_P95","P95"),
            "DELTA_P99":_first_float(r,"MC_P99","BASE_MC_P99","P99")-_first_float(seed,"MC_P99","BASE_MC_P99","P99"),
            "SEAT_SPECIFIC_SIBLING_RETENTION":bool(profile.get("seat_specific_sibling_retention",False)),
        })
    incoming_counts={}
    for x in out:
        for name in filter(None,x["INCOMING_PLAYERS"].split("|")): incoming_counts[name]=incoming_counts.get(name,0)+1
    for x in out:
        x["INCOMING_FAMILY_SUPPORT_COUNT"]=max([incoming_counts.get(name,0) for name in filter(None,x["INCOMING_PLAYERS"].split("|"))] or [0])
    return sorted(out,key=lambda x:(-x["INCOMING_FAMILY_SUPPORT_COUNT"], -x["OVERLAP_WITH_SEED"], x["CANDIDATE_LINEUP_ID"]))

def write_review_surface(rows: Sequence[Mapping[str, Any]], *, csv_path: str|Path, receipt_path: str|Path,
                         sport: str, mode: str, execution_id: str, context: Mapping[str,Any]|None=None,
                         resim_callback=None, multi_seed_base_trials: int=10000,
                         multi_seed_max_rounds: int=3, multi_seed_seed0: int=910001,
                         memory_safe_inplace: bool=False) -> dict[str,Any]:
    base_rows=(rows if memory_safe_inplace and isinstance(rows,list) and all(isinstance(r,dict) for r in rows) else [dict(r) for r in rows])
    multi_seed_receipt={
        "PATCH_ID": elite_tail.MULTI_SEED_PATCH_ID,"STATUS":"NOT_REQUIRED","ROUNDS_EXECUTED":0,
        "EXTRA_WORLD_TRIALS_TOTAL":0,"EXTRA_LINEUP_TRIAL_EVALUATIONS":0,"UNRESOLVED_BOUNDARY_LINEUPS":0,
        "SEPARATION_ACHIEVED":True,
    }
    if resim_callback is not None:
        base_rows,multi_seed_receipt=elite_tail.multi_seed_until_separation(
            base_rows, simulator=resim_callback, sport=sport, mode=mode, execution_id=str(execution_id),
            board_size=BOARD_SIZE, base_extra_trials=int(multi_seed_base_trials),
            max_rounds=int(multi_seed_max_rounds), seed0=int(multi_seed_seed0), copy_rows=not memory_safe_inplace)
    rows=enrich_ai_evidence(base_rows,sport=sport,mode=mode,copy_rows=not memory_safe_inplace); validate_candidate_rows(rows)
    csv_path=Path(csv_path); receipt_path=Path(receipt_path); csv_path.parent.mkdir(parents=True,exist_ok=True)
    fields=[]; seen=set()
    for r in rows:
        for k in r:
            if k not in seen: fields.append(k); seen.add(k)
    _atomic_write_csv(csv_path,fields,rows)
    # Release the caller-owned full terminal object graph immediately after the
    # atomic CSV commit.  In memory-safe mode rows/base_rows alias the caller list;
    # clear() is therefore required to drop the caller's last reference before the
    # disk-backed semantic freeze scans the 100k+ row surface.
    if memory_safe_inplace and isinstance(rows,list):
        rows.clear()
    del rows; del base_rows
    scan=scan_candidate_csv(csv_path); freeze=str(scan["CANDIDATE_FREEZE_SHA256"])
    context=dict(context or {})
    authority_persistence = {
        "STATUS": "NOT_APPLICABLE",
        "PATCH_ID": "APEX_AUTHORITY_WALKFORWARD_PERSISTENCE_v1",
        "MANIFEST_PATH": "",
        "SURFACE_CSV": "",
        "SELECTOR_ORDER_MUTATED": False,
        "PRODUCTION_SELECTION_AUTHORITY": False,
    }
    _sport_norm, _mode_norm = normalize_sport_mode(sport, mode)
    if (_sport_norm, _mode_norm) == ("MLB", "CLASSIC"):
        try:
            from engines.common import apex_authority_walkforward_persistence_v1 as authority_persist
            authority_dir = Path(str(context.get("AUTHORITY_HISTORY_DIR") or (receipt_path.parent / "authority_history")))
            authority_persistence = authority_persist.persist_prelock_csv_snapshot(
                source_csv=csv_path,
                sport=_sport_norm,
                mode=_mode_norm,
                execution_id=str(execution_id),
                output_dir=authority_dir,
                candidate_count=int(scan["CANDIDATE_COUNT"]),
                semantic_surface_sha256=freeze,
                seed_id=context.get("SEED_ID"),
                context=context,
            )
        except Exception as exc:
            authority_persistence = {
                "STATUS": "FAILED_NONBLOCKING",
                "PATCH_ID": "APEX_AUTHORITY_WALKFORWARD_PERSISTENCE_v1",
                "ERROR_CLASS": type(exc).__name__,
                "ERROR": str(exc)[:500],
                "MANIFEST_PATH": "",
                "SURFACE_CSV": "",
                "SELECTOR_ORDER_MUTATED": False,
                "PRODUCTION_SELECTION_AUTHORITY": False,
            }
    receipt={
        "PATCH_ID":PATCH_ID,"SELECTOR_MODE":SELECTOR_MODE,"SPORT":str(sport).upper(),"MODE":str(mode).upper(),
        "EXECUTION_ID":str(execution_id),"CANDIDATE_COUNT":int(scan["CANDIDATE_COUNT"]),"CANDIDATE_FREEZE_SHA256":freeze,
        "CANDIDATE_SURFACE_PATH":str(csv_path),"CANDIDATE_SURFACE_SHA256":str(scan["CANDIDATE_SURFACE_SHA256"]),
        "TOP5_POLICY_ID":TOP5_POLICY_ID,"FINAL_BOARD_SIZE":BOARD_SIZE,"FULL_HANDOFF_REQUIRED":True,"NO_PRUNING":True,
        "NO_TOP_N_SIEVE":True,"NO_AI_REVIEW_COHORT":True,"AI_AUTHORITY":"RANK_SORT_COMPARE_TIEBREAK_PORTFOLIO_SELECT_ONLY",
        "AI_MAY_CREATE_LINEUPS":False,"AI_MAY_MUTATE_METRICS":False,"AI_MAY_RECALIBRATE":False,"AI_MAY_USE_POSTLOCK_RESULTS":False,
        "CODE_SELECTOR_ROLE":"ADVISORY_COMPARATOR_ONLY_WHEN_AI_AUTHORITY_ENABLED","FEATURE_AVAILABILITY":scan["FEATURE_AVAILABILITY"],
        "FEATURE_REGISTRY":FEATURE_REGISTRY,"INTELLIGENCE_PROFILE":intelligence_profile(sport,mode),
        "ALLOWED_REASON_CODES":sorted(ALLOWED_REASON_CODES),"CONTEXT":context,"MULTI_SEED_PATCH_ID":elite_tail.MULTI_SEED_PATCH_ID,
        "MULTI_SEED_CONVERGENCE":multi_seed_receipt,"TERMINAL_SURFACE_STREAMING_FREEZE":True,
        "TERMINAL_SURFACE_ATOMIC_PUBLISH_PATCH_ID":TERMINAL_SURFACE_ATOMIC_PUBLISH_PATCH_ID,
        "RUN_IDENTITY":str(os.environ.get("APEX_SINGLE_FLIGHT_RUN_IDENTITY") or ""),
        "TERMINAL_MEMORY_SAFE_INPLACE":bool(memory_safe_inplace),
        "AUTHORITY_PERSISTENCE_STATUS":str(authority_persistence.get("STATUS","")),
        "AUTHORITY_PERSISTENCE_PATCH_ID":str(authority_persistence.get("PATCH_ID","APEX_AUTHORITY_WALKFORWARD_PERSISTENCE_v1")),
        "AUTHORITY_PRELOCK_MANIFEST":str(authority_persistence.get("MANIFEST_PATH","")),
        "AUTHORITY_PRELOCK_SURFACE":str(authority_persistence.get("SURFACE_CSV","")),
        "AUTHORITY_PERSISTENCE_MUTATED_SELECTOR_ORDER":False,
        "AUTHORITY_PERSISTENCE_PRODUCTION_SELECTION_AUTHORITY":False,
        "AUTHORITY_PERSISTENCE_ERROR_CLASS":str(authority_persistence.get("ERROR_CLASS","")),
        "AUTHORITY_PERSISTENCE_ERROR":str(authority_persistence.get("ERROR","")),
    }
    _atomic_write_json(receipt_path,receipt)
    receipt["RECEIPT_PATH"]=str(receipt_path); receipt["RECEIPT_SHA256"]=_stream_file_sha256(receipt_path)
    return receipt

def _stream_file_sha256(path: str|Path) -> str:
    h=sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def scan_candidate_csv(path: str|Path) -> dict[str,Any]:
    """Validate and freeze a full candidate CSV with bounded RAM.

    The semantic freeze exactly preserves legacy freeze_candidates(): rows are
    canonical-JSON encoded, lexicographically ordered by lineup id, wrapped in
    a JSON list, and incrementally SHA-256 hashed. SQLite is disk-backed so the
    full candidate matrix is never duplicated in Python memory.
    """
    path=Path(path)
    if not path.exists(): raise TerminalAIHybridError(f"RUN_INVALID:AI_TERMINAL_SURFACE_MISSING:{path}")
    fd,tmp=tempfile.mkstemp(prefix="apex_candidate_freeze_",suffix=".sqlite",dir=str(path.parent))
    os.close(fd)
    count=0; fieldnames=[]
    try:
        db=sqlite3.connect(tmp)
        db.execute("PRAGMA journal_mode=OFF"); db.execute("PRAGMA synchronous=OFF"); db.execute("PRAGMA temp_store=FILE")
        db.execute("CREATE TABLE rows(lineup_id TEXT PRIMARY KEY, row_json BLOB NOT NULL)")
        with path.open("r",encoding="utf-8-sig",newline="") as f:
            rd=csv.DictReader(f); fieldnames=list(rd.fieldnames or [])
            forbidden=sorted({_norm(k) for k in fieldnames} & FORBIDDEN_POSTLOCK_FIELDS)
            if forbidden: raise TerminalAIHybridError("RUN_INVALID:POSTLOCK_FIELDS_ENTERED_AI_TERMINAL:"+",".join(forbidden))
            for row in rd:
                lid=_lineup_id(row)
                p=_players(row)
                if p and len(p)!=len({x.casefold() for x in p}):
                    raise TerminalAIHybridError(f"RUN_INVALID:DUPLICATE_PLAYER_IN_AI_CANDIDATE:{lid}")
                raw=_canonical_json(dict(row))
                try: db.execute("INSERT INTO rows(lineup_id,row_json) VALUES(?,?)",(lid,raw))
                except sqlite3.IntegrityError:
                    raise TerminalAIHybridError(f"RUN_INVALID:DUPLICATE_AI_LINEUP_ID:{lid}")
                count+=1
        _drop_page_cache(path)
        if count<=0: raise TerminalAIHybridError("RUN_INVALID:AI_TERMINAL_EMPTY_CANDIDATES")
        db.commit()
        h=sha256(); h.update(b"["); first=True
        for (raw,) in db.execute("SELECT row_json FROM rows ORDER BY lineup_id COLLATE BINARY"):
            if not first: h.update(b",")
            h.update(bytes(raw)); first=False
        h.update(b"]")
        cols={_norm(k) for k in fieldnames}
        availability={}
        for group,names in FEATURE_REGISTRY.items():
            present=[n for n in names if _norm(n) in cols]
            availability[group]={"AVAILABLE":len(present),"DEFINED":len(names),"MISSING":len(names)-len(present)}
        return {"CANDIDATE_COUNT":count,"CANDIDATE_FREEZE_SHA256":h.hexdigest(),
                "CANDIDATE_SURFACE_SHA256":_stream_file_sha256(path),"FEATURE_AVAILABILITY":availability,
                "FIELDNAMES":fieldnames}
    finally:
        try: db.close()
        except Exception: pass
        try: os.unlink(tmp)
        except FileNotFoundError: pass


def _compact_selector_columns(fieldnames: Sequence[str]) -> set[str]:
    exact={
        "LINEUP_ID","LINEUP_INDEX","ID","CPT","CAPTAIN","MVP","UTIL","UTILS","PLAYERS",
        "QB","RB1","RB2","WR1","WR2","WR3","TE","FLEX","DST","P1","P2","C","1B","2B","3B","SS",
        "OF1","OF2","OF3","G1","G2","G3","G4","G5","G6","F1","F2","F3","F4","F5","F6",
        "MC_WIN_RATE","WIN_RATE","WIN_PROB","MC_TOP_0_1_RATE","TOP_0_1_RATE","TOP01_RATE","MC_TOP_1_RATE",
        "TOP_1_RATE","TOP1_RATE","P99","MC_P99","CVAR99","MC_CVAR99","P95","MC_P95","SELECTOR_SCORE",
        "OBJECTIVE","SCORE","TRIALS","MC_TRIALS","SIM_TRIALS","N_TRIALS","EXPECTED_DUP","EXPECTED_DUPES",
        "EXPECTED_DUPLICATES","DUP_EXPECTED","P_UNIQUE","UNIQUE_PROB","PROB_UNIQUE","OWNERSHIP_PRODUCT",
        "PRODUCT_OWNERSHIP","LINEUP_OWN_PRODUCT","OWN_PRODUCT","FIELD_SIZE","CONTEST_SIZE","ENTRIES",
        "UNDEROWNED_CEILING_DENSITY","STACK_OPTO_LEVERAGE","PLAYER_PERFECT_LEVERAGE","PLAYER_BOOM_LEVERAGE",
        "SIM_LEVERAGE","CEILING_OWNERSHIP_EFFICIENCY","GLOBAL_CORE_FAMILY_ID","CHAMPIONSHIP_FAMILY_ID",
        "GLOBAL_CORE_SCENARIO_ID","CHAMPIONSHIP_SCENARIO_ID","GLOBAL_CORE_PROTECTED","GLOBAL_CORE_PRIORITY",
        "GLOBAL_CORE_FAMILY_CAP","SELECTION_LANE","SELECTOR_REASON","REASON","SCENARIO_RANK","RP_COUNT","SP_COUNT",
        "CPT_IS_SP","BRANCH","CURRENT_SELECTOR_SELECTED","CURRENT_SELECTOR_RANK","CURRENT_SELECTOR_SCORE"
    }
    for i in range(1,13): exact.add(f"PLAYER{i}")
    for i in range(1,13): exact.add(f"UTIL{i}")
    norm_to_orig={_norm(k):k for k in fieldnames}
    return {norm_to_orig[n] for n in exact if n in norm_to_orig}


def load_compact_candidate_csv(path: str|Path) -> list[dict[str,Any]]:
    path=Path(path)
    with path.open("r",encoding="utf-8-sig",newline="") as f:
        rd=csv.DictReader(f); keep=_compact_selector_columns(list(rd.fieldnames or []))
        rows=[{k:v for k,v in r.items() if k in keep} for r in rd]
    if not rows: raise TerminalAIHybridError("RUN_INVALID:AI_TERMINAL_EMPTY_CANDIDATES")
    return rows


def load_selected_candidate_rows(path: str|Path, lineup_ids: Sequence[str]) -> list[dict[str,Any]]:
    wanted=[str(x) for x in lineup_ids]; need=set(wanted); found={}
    with Path(path).open("r",encoding="utf-8-sig",newline="") as f:
        for r in csv.DictReader(f):
            lid=_lineup_id(r)
            if lid in need:
                found[lid]=dict(r)
                if len(found)==len(need): break
    missing=[x for x in wanted if x not in found]
    if missing: raise TerminalAIHybridError("RUN_INVALID:AI_CREATED_UNSEEN_LINEUP:"+",".join(missing))
    return [found[x] for x in wanted]


def load_candidate_csv(path: str|Path) -> list[dict[str,Any]]:
    with Path(path).open("r",encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))


def load_decision(path: str|Path) -> dict[str,Any]:
    obj=json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(obj,dict): raise TerminalAIHybridError("RUN_INVALID:AI_DECISION_NOT_OBJECT")
    return obj


def _overlap(a: Sequence[str], b: Sequence[str]) -> float:
    sa={str(x).casefold() for x in a if str(x).strip()}; sb={str(x).casefold() for x in b if str(x).strip()}
    return len(sa&sb)/max(1,min(len(sa),len(sb)))


def materialize_ai_board(rows: Sequence[Mapping[str,Any]], decision: Mapping[str,Any], *, board_size: int=BOARD_SIZE) -> list[dict[str,Any]]:
    """Materialize the user-visible board before formal legality/hash validation.

    This is intentionally not a validation gate. It only resolves the five AI-returned
    existing IDs to their frozen candidate rows so the board can be rendered first.
    Formal candidate-membership, reason-code, legality, and hash validation remains
    post-board in validate_ai_decision / the production seal.
    """
    picks=decision.get("selections")
    if not isinstance(picks,list) or len(picks)!=int(board_size):
        raise TerminalAIHybridError(f"RUN_INVALID:AI_BOARD_RENDER_SIZE_MISMATCH:{0 if not isinstance(picks,list) else len(picks)}:{board_size}")
    by_id={_lineup_id(dict(r)):dict(r) for r in rows}
    out=[]
    for rank,p in enumerate(picks,1):
        if not isinstance(p,dict):
            raise TerminalAIHybridError("RUN_INVALID:AI_BOARD_RENDER_SELECTION_NOT_OBJECT")
        lid=str(p.get("lineup_id",p.get("LINEUP_ID",p.get("LINEUP_INDEX",""))))
        # Lookup is board materialization, not the formal post-board membership receipt.
        if lid not in by_id:
            raise TerminalAIHybridError(f"RUN_INVALID:AI_BOARD_RENDER_UNKNOWN_ID:{lid}")
        r=dict(by_id[lid]); r["AI_TERMINAL_RANK"]=rank
        reasons=tuple(str(x) for x in (p.get("reason_codes") or []))
        if reasons: r["AI_REASON_CODES"]="|".join(reasons)
        out.append(r)
    return out



# ---------------------------------------------------------------------------
# WNBA SHOWDOWN PRODUCTION TERMINAL POLICY v1
# Sport-scoped. Does not alter generator, simulation, ownership, or other sports.
# ---------------------------------------------------------------------------

WNBA_SHOWDOWN_ROLE_QUOTAS = {
    "HIGH_CONFIDENCE_CORE": 3,
    "RUNBACK": 1,
    "COUNTER_SCRIPT": 1,
}

WNBA_SHOWDOWN_PRIMARY_PRIOR_FIELDS = (
    "TOP_0_1_RATE","MC_TOP_0_1_RATE","TOP01",
    "WIN_RATE","MC_WIN_RATE","WIN",
    "TOP10_RATE","MC_TOP10_RATE",
    "P99","MC_P99",
    "P95","MC_P95",
    "MEAN","MC_MEAN",
    "ROBUST_SELECTOR_SCORE","CURRENT_SELECTOR_SCORE","SCORE",
    "STANDALONE_SELECTOR_SCORE",
    "PORTFOLIO_SELECTOR_SCORE",
    "BASELINE_RESILIENCE",
    "TAIL_DEPENDENCY_COUNT",
    "EXPECTED_DUP","PROJECTED_EXACT_MATCH_DUPLICATION",
    "MACRO_FAMILY_ID","MACRO",
    "CORE_FAMILY_ID","VALUE_FAMILY_ID","VALUE_PAIR_ID","FAMILY_SHAPE",
)

_WNBA_SD_SCORE_WEIGHTS = {
    "FAMILY_CHAMPIONSHIP_MASS": 0.30,
    "TOP01": 0.25,
    "WIN": 0.15,
    "PREVIOUS_SELECTOR_SCORE": 0.12,
    "LOCAL_CORE_SUPPORT": 0.18,
}

def _first_present(row: Mapping[str,Any], names: Sequence[str], default: Any=None) -> Any:
    cmap={_norm(k):k for k in row}
    for name in names:
        k=cmap.get(_norm(name))
        if k is not None and row.get(k) not in (None,""):
            return row.get(k)
    return default

def _lane(row: Mapping[str,Any]) -> str:
    return _norm(_first_present(
        row, ("AI_LANE","LANE","SELECTOR_LANE","PORTFOLIO_LANE","AI_CALIBRATED_ROLE"), ""
    ))

def _family_value(row: Mapping[str,Any], field: str) -> str:
    aliases = {
        "MACRO_FAMILY_ID": ("MACRO_FAMILY_ID","MACRO"),
        "CORE_FAMILY_ID": ("CORE_FAMILY_ID",),
        "VALUE_FAMILY_ID": ("VALUE_FAMILY_ID",),
        "VALUE_PAIR_ID": ("VALUE_PAIR_ID",),
        "FAMILY_SHAPE": ("FAMILY_SHAPE",),
    }
    v=_first_present(row, aliases[field], "")
    return str(v).strip()

def _cpt(row: Mapping[str,Any]) -> str:
    return next((p.casefold() for slot,p in _lineup_slots(row) if slot=="CPT"),"")

def _metric_any(row: Mapping[str,Any], names: Sequence[str], default: float=float("nan")) -> float:
    for n in names:
        v=_float(row,n,float("nan"))
        if math.isfinite(v):
            return v
    return default

def _pct_map(rows: Sequence[Mapping[str,Any]], getter) -> dict[str,float]:
    vals=[]
    for r in rows:
        v=getter(r)
        if math.isfinite(v):
            vals.append((_lineup_id(r), float(v)))
    if not vals:
        return {_lineup_id(r):0.5 for r in rows}
    ordered=sorted(vals, key=lambda x:(x[1],x[0]))
    n=len(ordered)
    out={}
    i=0
    while i<n:
        j=i
        while j+1<n and ordered[j+1][1]==ordered[i][1]:
            j+=1
        rank=((i+1)+(j+1))/2.0
        pct=rank/n
        for k in range(i,j+1):
            out[ordered[k][0]]=pct
        i=j+1
    for r in rows:
        out.setdefault(_lineup_id(r),0.5)
    return out

def _wnba_sd_family_score(rows: Sequence[Mapping[str,Any]]) -> dict[str,float]:
    """Score only inside an already-authorized same-lane/same-family pool.

    Previous selector/tail metrics remain primary quantitative inputs.
    Family/local evidence confirms a replacement; it cannot redefine a lane.
    """
    fam_mass=_pct_map(rows, lambda r:_metric_any(r,(
        "FAMILY_CHAMPIONSHIP_MASS","CHAMP_TAIL","CHAMP",
        "AI_EXACT_PLAYERSET_FAMILY_TOP01_MASS"
    )))
    top01=_pct_map(rows, lambda r:_metric_any(r,("TOP_0_1_RATE","MC_TOP_0_1_RATE","TOP01")))
    win=_pct_map(rows, lambda r:_metric_any(r,("WIN_RATE","MC_WIN_RATE","WIN")))
    prior=_pct_map(rows, lambda r:_metric_any(r,(
        "PORTFOLIO_SELECTOR_SCORE","ROBUST_SELECTOR_SCORE",
        "CURRENT_SELECTOR_SCORE","STANDALONE_SELECTOR_SCORE","SCORE"
    )))
    local=_pct_map(rows, lambda r:_metric_any(r,(
        "AI_D1_TOP01_DENSITY","LOCAL_CHAMPIONSHIP_DENSITY",
        "CORE_CORR_MEAN","AI_D1_P99_DENSITY","MC_P99","P99"
    )))
    out={}
    for r in rows:
        lid=_lineup_id(r)
        out[lid]=(
            _WNBA_SD_SCORE_WEIGHTS["FAMILY_CHAMPIONSHIP_MASS"]*fam_mass[lid] +
            _WNBA_SD_SCORE_WEIGHTS["TOP01"]*top01[lid] +
            _WNBA_SD_SCORE_WEIGHTS["WIN"]*win[lid] +
            _WNBA_SD_SCORE_WEIGHTS["PREVIOUS_SELECTOR_SCORE"]*prior[lid] +
            _WNBA_SD_SCORE_WEIGHTS["LOCAL_CORE_SUPPORT"]*local[lid]
        )
    return out

def _selected_flag(row: Mapping[str,Any]) -> bool:
    v=_first_present(row,(
        "CURRENT_SELECTOR_SELECTED","PREVIOUS_SELECTOR_SELECTED",
        "SELECTOR_SELECTED","GLOBAL_CORE_PROTECTED"
    ),False)
    if isinstance(v,bool): return v
    return str(v).strip().upper() in {"1","TRUE","T","YES","Y","SELECTED","PROTECTED"}

def _pick_anchor_family(rows: Sequence[Mapping[str,Any]], lane: str, count: int) -> tuple[str,str]:
    lane_rows=[r for r in rows if _lane(r)==lane]
    if len(lane_rows)<count:
        raise TerminalAIHybridError(f"RUN_INVALID:WNBA_SD_LANE_DEPTH:{lane}:{len(lane_rows)}:{count}")

    selected=[r for r in lane_rows if _selected_flag(r)]
    source=selected if selected else lane_rows

    # Family is chosen by aggregate championship-family support, never by a single
    # raw metric maximum. This prevents role-architecture inversion.
    buckets={}
    for r in source:
        key=(_family_value(r,"MACRO_FAMILY_ID"), _cpt(r))
        buckets.setdefault(key,[]).append(r)

    def bucket_value(item):
        key, rr=item
        mass=sum(max(0.0,_metric_any(x,(
            "FAMILY_CHAMPIONSHIP_MASS","CHAMP_TAIL","CHAMP",
            "AI_EXACT_PLAYERSET_FAMILY_TOP01_MASS","TOP_0_1_RATE","MC_TOP_0_1_RATE","TOP01"
        ),0.0)) for x in rr)
        return (len(rr), mass, key)

    return max(buckets.items(), key=bucket_value)[0]

def _family_pool(rows: Sequence[Mapping[str,Any]], lane: str, macro: str, cpt: str) -> list[dict[str,Any]]:
    out=[]
    for r in rows:
        if _lane(r)!=lane: continue
        if macro and _family_value(r,"MACRO_FAMILY_ID")!=macro: continue
        if cpt and _cpt(r)!=cpt: continue
        out.append(dict(r))
    return out

def select_wnba_showdown_terminal_portfolio(
    rows: Sequence[Mapping[str,Any]],
    *,
    expected_freeze_hash: str|None=None,
) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    """Production WNBA Showdown terminal selection.

    Invariants:
      * full frozen candidate handoff only;
      * post-lock fields fail closed;
      * 3 HIGH_CONFIDENCE_CORE + 1 RUNBACK + 1 COUNTER_SCRIPT;
      * root family/captain architecture protected;
      * replacements occur only inside the same lane/family;
      * no player-name, team-name, or realized-result hardcoding.
    """
    rows=[dict(r) for r in rows]
    freeze=freeze_candidates(rows)
    if expected_freeze_hash and freeze!=str(expected_freeze_hash):
        raise TerminalAIHybridError("RUN_INVALID:AI_FROZEN_MATRIX_HASH_MISMATCH")

    profile=intelligence_profile("WNBA","SHOWDOWN")
    if not profile.get("sport_native_lane_authority"):
        raise TerminalAIHybridError("RUN_INVALID:WNBA_SD_ROLE_AUTHORITY_DISABLED")

    chosen=[]
    lane_receipts={}
    for lane, seats in WNBA_SHOWDOWN_ROLE_QUOTAS.items():
        macro,cpt=_pick_anchor_family(rows,lane,seats)
        pool=_family_pool(rows,lane,macro,cpt)
        if len(pool)<seats:
            raise TerminalAIHybridError(
                f"RUN_INVALID:WNBA_SD_SAME_FAMILY_DEPTH:{lane}:{len(pool)}:{seats}"
            )
        scores=_wnba_sd_family_score(pool)
        ordered=sorted(
            pool,
            key=lambda r:(
                -scores[_lineup_id(r)],
                -_metric_any(r,("TOP_0_1_RATE","MC_TOP_0_1_RATE","TOP01"),0.0),
                -_metric_any(r,("WIN_RATE","MC_WIN_RATE","WIN"),0.0),
                -_metric_any(r,("MC_P99","P99"),0.0),
                _lineup_id(r),
            )
        )
        lane_pick=ordered[:seats]
        chosen.extend(lane_pick)
        lane_receipts[lane]={
            "SEATS":seats,
            "MACRO_FAMILY_ID":macro,
            "CPT_ROLE_TOKEN":cpt,
            "FAMILY_POOL_SIZE":len(pool),
            "SELECTED_LINEUP_IDS":[_lineup_id(r) for r in lane_pick],
            "SCORES":{_lineup_id(r):round(scores[_lineup_id(r)],12) for r in lane_pick},
        }

    # Hard role count receipt. Lane membership came from the engine surface, not metrics.
    counts={}
    for r in chosen:
        counts[_lane(r)]=counts.get(_lane(r),0)+1
    if counts!=WNBA_SHOWDOWN_ROLE_QUOTAS:
        raise TerminalAIHybridError(f"RUN_INVALID:WNBA_SD_ROLE_CONTRACT:{counts}")

    reasons={
        "HIGH_CONFIDENCE_CORE":(
            "SPORT_NATIVE_LANE_AUTHORITY","ROOT_CHAMPIONSHIP_FAMILY_PROTECTED",
            "SAME_LANE_FAMILY_REPLACEMENT","CORRELATED_HIGH_CONFIDENCE_ANCHOR_PRESS",
            "FAMILY_CHAMPIONSHIP_MASS","LOCAL_CHAMPIONSHIP_DENSITY",
        ),
        "RUNBACK":(
            "SPORT_NATIVE_LANE_AUTHORITY","ROOT_CHAMPIONSHIP_FAMILY_PROTECTED",
            "SAME_LANE_FAMILY_REPLACEMENT","RUNBACK_PATH","PORTFOLIO_MARGINAL_VALUE",
        ),
        "COUNTER_SCRIPT":(
            "SPORT_NATIVE_LANE_AUTHORITY","ROOT_CHAMPIONSHIP_FAMILY_PROTECTED",
            "SAME_LANE_FAMILY_REPLACEMENT","NEGATIVE_CORRELATION_COUNTER_SCRIPT",
            "COUNTER_SCRIPT_COVERAGE","PORTFOLIO_MARGINAL_VALUE",
        ),
    }
    for rank,r in enumerate(chosen,1):
        r["AI_TERMINAL_RANK"]=rank
        r["AI_REASON_CODES"]="|".join(reasons[_lane(r)])

    receipt={
        "PATCH_ID":PATCH_ID,
        "STATUS":"PASS",
        "SPORT":"WNBA",
        "MODE":"SHOWDOWN",
        "CANDIDATE_FREEZE_SHA256":freeze,
        "FINAL_BOARD_SIZE":len(chosen),
        "ROLE_CONTRACT":dict(WNBA_SHOWDOWN_ROLE_QUOTAS),
        "ROLE_COUNTS":counts,
        "LANE_RECEIPTS":lane_receipts,
        "SELECTED_LINEUP_IDS":[_lineup_id(r) for r in chosen],
        "PHASE2_CHANGED":False,
        "GENERATOR_RERUN":False,
        "FULL_HANDOFF_PRUNING":0,
        "POSTLOCK_RESULTS_USED":False,
        "PLAYER_NAME_HARDCODES":False,
        "TEAM_NAME_HARDCODES":False,
        "METRIC_DOMINANCE_CAN_REDEFINE_LANE":False,
        "SAME_LANE_FAMILY_REPLACEMENT_ONLY":True,
        "ROOT_CHAMPIONSHIP_FAMILY_PROTECTED":True,
        "GLOBAL_POINTER_ROTATION_REQUIRED":False,
        "SPORT_SCOPED_ACTIVE_PIN":True,
    }
    return chosen,receipt

def validate_ai_decision(rows: Sequence[Mapping[str,Any]], decision: Mapping[str,Any], *, expected_freeze_hash: str|None=None,
                         board_size: int=BOARD_SIZE, sport: str|None=None, mode: str|None=None,
                         preverified_freeze_hash: str|None=None) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    rows=[dict(r) for r in rows]
    if preverified_freeze_hash is not None:
        validate_candidate_rows(rows)
        freeze=str(preverified_freeze_hash)
        if expected_freeze_hash and freeze != str(expected_freeze_hash):
            raise TerminalAIHybridError("RUN_INVALID:AI_PREVERIFIED_FREEZE_HASH_MISMATCH")
    else:
        freeze=freeze_candidates(rows)
        if expected_freeze_hash and freeze != str(expected_freeze_hash):
            raise TerminalAIHybridError("RUN_INVALID:AI_FROZEN_MATRIX_HASH_MISMATCH")
    if decision.get("candidate_freeze_sha256") not in (None,"",freeze):
        raise TerminalAIHybridError("RUN_INVALID:AI_DECISION_HASH_MISMATCH")
    picks=decision.get("selections")
    if not isinstance(picks,list) or len(picks)!=int(board_size):
        raise TerminalAIHybridError(f"RUN_INVALID:AI_BOARD_SIZE_MISMATCH:{0 if not isinstance(picks,list) else len(picks)}:{board_size}")
    by_id={_lineup_id(r):r for r in rows}
    out=[]; ids=[]; all_reasons=[]
    for rank,p in enumerate(picks,1):
        if not isinstance(p,dict): raise TerminalAIHybridError("RUN_INVALID:AI_SELECTION_NOT_OBJECT")
        lid=str(p.get("lineup_id",p.get("LINEUP_ID",p.get("LINEUP_INDEX",""))))
        if lid not in by_id: raise TerminalAIHybridError(f"RUN_INVALID:AI_CREATED_UNSEEN_LINEUP:{lid}")
        if lid in ids: raise TerminalAIHybridError(f"RUN_INVALID:AI_DUPLICATE_LINEUP:{lid}")
        reasons=tuple(str(x) for x in (p.get("reason_codes") or []))
        if not reasons: raise TerminalAIHybridError(f"RUN_INVALID:AI_MISSING_REASON_CODES:{lid}")
        bad=sorted(set(reasons)-ALLOWED_REASON_CODES)
        if bad: raise TerminalAIHybridError(f"RUN_INVALID:AI_INVALID_REASON_CODES:{lid}:{','.join(bad)}")
        r=dict(by_id[lid]); r["AI_TERMINAL_RANK"]=rank; r["AI_REASON_CODES"]="|".join(reasons)
        out.append(r); ids.append(lid); all_reasons.extend(reasons)
    player_sets=[_players(r) for r in out]
    role_sensitive=False
    profile=None
    if sport is not None and mode is not None:
        profile=intelligence_profile(sport,mode); role_sensitive=bool(profile.get("role_sensitive"))
    if role_sensitive:
        signatures=[]
        for r in out:
            slots=_lineup_slots(r)
            cpt=next((player.casefold() for slot,player in slots if slot=="CPT"),"")
            utils=tuple(sorted(player.casefold() for slot,player in slots if slot!="CPT"))
            signatures.append((cpt,utils))
    else:
        signatures=[tuple(sorted(x.casefold() for x in p)) for p in player_sets]
    if len(set(signatures)) != len(out):
        raise TerminalAIHybridError("RUN_INVALID:AI_FINAL_EXACT_DUPLICATE_LINEUP")
    # Global championship-head contract: Top-5 is a coherent elite neighborhood.
    # Diversification is not sufficient evidence for a Top-5 choice and may not be
    # the reason an otherwise stronger sibling is displaced.
    head_codes={"ELITE_WIN_PATH","ELITE_TOP_0_1_PATH","ELITE_TOP_1_PATH","P99_TAIL","CVAR99_TAIL","P95_TAIL",
                "CROSS_WORLD_RECURRENCE_BREADTH","CHAMPIONSHIP_NEIGHBORHOOD_PROTECTED","PAIRWISE_STRENGTH",
                "WORLD_BREADTH","STABLE_TAIL_PRESENCE","HEAD_MULTI_SIGNAL_AGREEMENT","DOMINANT_FAMILY_EVIDENCE",
                "DOMINANT_FAMILY_SUPPORT","CONDITIONAL_CORE_FIT","LOCAL_CHAMPIONSHIP_DENSITY","DECK_DEPTH_PROTECTED",
                "CHAMPIONSHIP_DECK","SEAT_SPECIFIC_SIBLING_RETENTION","ROOT_CHAMPIONSHIP_FAMILY_PROTECTED"}
    if not (set(all_reasons)&head_codes):
        raise TerminalAIHybridError("RUN_INVALID:AI_TOP5_CHAMPIONSHIP_NEIGHBORHOOD_REASON_MISSING")
    overlaps=[]
    for i in range(len(out)):
        for j in range(i+1,len(out)):
            overlaps.append(_overlap(player_sets[i],player_sets[j]))
    receipt={
        "PATCH_ID":PATCH_ID,"STATUS":"PASS","CANDIDATE_FREEZE_SHA256":freeze,"FINAL_BOARD_SIZE":len(out),
        "SELECTED_LINEUP_IDS":ids,"TOP5_POLICY_ID":TOP5_POLICY_ID,"TOP5_PARLAY_VALIDATED":True,
        "MAX_PAIRWISE_PLAYER_OVERLAP":max(overlaps) if overlaps else 0.0,"AVG_PAIRWISE_PLAYER_OVERLAP":sum(overlaps)/len(overlaps) if overlaps else 0.0,
        "AI_CREATED_LINEUPS":False,"AI_MUTATED_METRICS":False,"POSTLOCK_RESULTS_USED":False,
        "CHAMPIONSHIP_HEAD_POLICY_ID":championship_head_policy.PATCH_ID,
        "DIVERSIFICATION_APPLIED_INSIDE_HEAD":False,
        "CODE_SELECTOR_TERMINAL_AUTHORITY":False,"AI_TERMINAL_AUTHORITY":True,
        "INTELLIGENCE_PROFILE":profile,
    }
    return out,receipt
