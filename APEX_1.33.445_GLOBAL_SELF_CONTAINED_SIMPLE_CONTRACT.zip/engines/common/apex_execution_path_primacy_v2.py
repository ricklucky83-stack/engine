from __future__ import annotations
from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping
import hashlib
import numpy as np

PATCH_ID = "APEX_GLOBAL_EXECUTION_PATH_PRIMACY_EFFICIENCY_STANDARD_v2"

@dataclass(frozen=True)
class FrozenSlate:
    arrays: Mapping[str, np.ndarray]
    row_count: int
    fingerprint: str

def _fingerprint_arrays(arrays: Mapping[str, np.ndarray]) -> str:
    h = hashlib.sha256()
    for name in sorted(arrays):
        a = np.asarray(arrays[name])
        h.update(name.encode("utf-8")); h.update(str(a.dtype).encode("ascii")); h.update(str(a.shape).encode("ascii")); h.update(a.tobytes(order="C"))
    return h.hexdigest()

def freeze_static_slate_artifacts(**arrays) -> FrozenSlate:
    frozen = {}
    n = None
    for name, value in arrays.items():
        a = np.ascontiguousarray(np.asarray(value))
        if a.ndim == 0:
            raise ValueError(f"FROZEN_SLATE_SCALAR_NOT_ALLOWED:{name}")
        if n is None:
            n = len(a)
        elif len(a) != n:
            raise ValueError(f"FROZEN_SLATE_LENGTH_MISMATCH:{name}:{len(a)}:{n}")
        a.setflags(write=False)
        frozen[name] = a
    proxy = MappingProxyType(frozen)
    return FrozenSlate(proxy, int(n or 0), _fingerprint_arrays(proxy))

def percentile_rank_numpy(values) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64)
    n = x.size
    if n == 0:
        return x.copy()
    x = np.nan_to_num(x, nan=-np.inf, posinf=np.inf, neginf=-np.inf)
    order = np.argsort(x, kind="stable")
    sx = x[order]
    boundary = np.r_[True, sx[1:] != sx[:-1], True]
    edges = np.flatnonzero(boundary)
    starts, ends = edges[:-1], edges[1:]
    avg = ((starts + ends - 1) * 0.5 + 0.5) / n
    ranks_sorted = np.repeat(avg, ends - starts)
    out = np.empty(n, dtype=np.float64)
    out[order] = ranks_sorted
    return out

def stable_desc_rank(values) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64)
    order = np.argsort(-x, kind="stable")
    out = np.empty(x.size, dtype=np.int64)
    out[order] = np.arange(1, x.size + 1, dtype=np.int64)
    return out

def vectorized_legality_mask(lineup_ids: np.ndarray, salary: np.ndarray, eligible: np.ndarray, *, salary_min: int, salary_max: int, roster_size: int) -> np.ndarray:
    ids = np.asarray(lineup_ids, dtype=np.int32)
    if ids.ndim != 2 or ids.shape[1] != roster_size:
        raise ValueError("LINEUP_MATRIX_SHAPE_MISMATCH")
    if ids.size == 0:
        return np.zeros(ids.shape[0], dtype=bool)
    max_id = int(ids.max(initial=-1))
    if ids.min(initial=0) < 0 or max_id >= len(salary) or max_id >= len(eligible):
        raise ValueError("LINEUP_PLAYER_ID_OUT_OF_RANGE")
    sal = np.asarray(salary)[ids].sum(axis=1)
    sorted_ids = np.sort(ids, axis=1)
    unique_ok = np.all(sorted_ids[:, 1:] != sorted_ids[:, :-1], axis=1)
    eligible_ok = np.asarray(eligible, dtype=bool)[ids].all(axis=1)
    return (sal >= int(salary_min)) & (sal <= int(salary_max)) & unique_ok & eligible_ok

def early_structural_prune(*, core_completion_count, minimum_core_completions: int, ceiling_score=None, minimum_ceiling=None, structural_variance=None, minimum_structural_variance=None, protected_mask=None) -> np.ndarray:
    c = np.asarray(core_completion_count)
    mask = c >= int(minimum_core_completions)
    if ceiling_score is not None and minimum_ceiling is not None:
        mask &= np.asarray(ceiling_score) >= float(minimum_ceiling)
    if structural_variance is not None and minimum_structural_variance is not None:
        mask &= np.asarray(structural_variance) >= float(minimum_structural_variance)
    if protected_mask is not None:
        p = np.asarray(protected_mask, dtype=bool)
        if p.shape != mask.shape:
            raise ValueError("PROTECTED_MASK_SHAPE_MISMATCH")
        mask |= p
    return np.flatnonzero(mask).astype(np.int32, copy=False)

def shortlist_before_expensive_rank(primary_score, eligible_indices, *, max_rows: int | None = None, protected_indices=None) -> np.ndarray:
    idx = np.asarray(eligible_indices, dtype=np.int32)
    score = np.asarray(primary_score, dtype=np.float64)
    if idx.size == 0:
        return idx
    protected = np.empty(0, dtype=np.int32) if protected_indices is None else np.unique(np.asarray(protected_indices, dtype=np.int32))
    protected = protected[np.isin(protected, idx, assume_unique=False)]
    if max_rows is None or idx.size <= int(max_rows):
        return idx[np.argsort(-score[idx], kind="stable")]
    slots = max(int(max_rows) - protected.size, 0)
    candidates = idx[~np.isin(idx, protected, assume_unique=False)]
    if slots and candidates.size:
        if candidates.size > slots:
            part = np.argpartition(score[candidates], candidates.size - slots)[-slots:]
            candidates = candidates[part]
        candidates = candidates[np.argsort(-score[candidates], kind="stable")]
    else:
        candidates = np.empty(0, dtype=np.int32)
    out = np.r_[protected, candidates]
    return out[np.argsort(-score[out], kind="stable")]

def production_fast_membership_invariant_order(rows, *, score_key="pre_score"):
    return sorted(rows, key=lambda candidate: (-float(candidate.get(score_key, 0.0)), candidate.get("lineup")))
