from __future__ import annotations
from typing import Any, Protocol
PATCH_ID="APEX_GLOBAL_POINTER_OBJECT_EPOCH_FENCE_v1"
ACTIVE_TITLE="APEX_GLOBAL_STATE_LATEST.txt"
class PointerFenceError(RuntimeError): pass
class PointerRegistry(Protocol):
    def discover_exact_active_pointer(self) -> dict: ...
    def create_pointer_candidate(self, **kwargs: Any) -> dict: ...
    def finalize_pointer_candidate(self, **kwargs: Any) -> dict: ...
    def retire_pointer_object(self, **kwargs: Any) -> dict: ...
    def activate_pointer_object(self, **kwargs: Any) -> dict: ...

def next_pointer_epoch(pointer: dict) -> int: return int(pointer.get("POINTER_EPOCH",0) or 0)+1
def require_exact_title_unique(found: dict) -> None:
    if found.get("EXACT_TITLE_COUNT") not in (None,1): raise PointerFenceError("ACTIVE_POINTER_EXACT_TITLE_NOT_UNIQUE")
    if found.get("TITLE",ACTIVE_TITLE)!=ACTIVE_TITLE: raise PointerFenceError("ACTIVE_POINTER_TITLE_MISMATCH")
def rotate_pointer_object_fenced(registry: PointerRegistry, *, before: dict, pointer_payload: dict, from_version: str, to_version: str) -> dict:
    old_id=str(before.get("FILE_ID") or before.get("ACTIVE_POINTER_FILE_ID") or "")
    if not old_id: raise PointerFenceError("ACTIVE_POINTER_FILE_ID_REQUIRED_FOR_OBJECT_FENCE")
    pre=registry.discover_exact_active_pointer(); require_exact_title_unique(pre)
    if str(pre.get("FILE_ID"))!=old_id: raise PointerFenceError("POINTER_OBJECT_DRIFT_BEFORE_FENCE")
    candidate=registry.create_pointer_candidate(title=f"_PENDING_{ACTIVE_TITLE}_v{to_version}", pointer_payload=pointer_payload, pointer_epoch=next_pointer_epoch(before))
    new_id=str(candidate.get("FILE_ID") or "")
    if not new_id or new_id==old_id: raise PointerFenceError("POINTER_CANDIDATE_OBJECT_ID_NOT_NEW")
    registry.finalize_pointer_candidate(file_id=new_id, pointer_payload={**pointer_payload,"ACTIVE_POINTER_FILE_ID":new_id,"POINTER_EPOCH":next_pointer_epoch(before)})
    # Fence stale writers by retiring the object they pinned before activating the new exact-title object.
    registry.retire_pointer_object(file_id=old_id, retired_title=f"APEX_GLOBAL_STATE_LATEST_RETIRED_v{from_version}_E{int(before.get('POINTER_EPOCH',0) or 0)}.txt")
    registry.activate_pointer_object(file_id=new_id, active_title=ACTIVE_TITLE)
    rb=registry.discover_exact_active_pointer(); require_exact_title_unique(rb)
    if str(rb.get("FILE_ID"))!=new_id: raise PointerFenceError("POINTER_OBJECT_FENCE_READBACK_MISMATCH")
    return {"POINTER_OBJECT_FENCE":"PASS","RETIRED_POINTER_FILE_ID":old_id,"ACTIVE_POINTER_FILE_ID":new_id,"POINTER_EPOCH":next_pointer_epoch(before),"READBACK":rb}
