from __future__ import annotations

import json
from pathlib import Path
from typing import Any

PATCH_ID = "APEX_GLOBAL_NOTION_ENGINE_AUTHORITY_PARITY_v1"
STATUS = "ACTIVE_GLOBAL_PRODUCTION_CONTROL_PLANE"

PRODUCTION_STATUS_MARKERS = (
    "ACTIVE_PRODUCTION",
    "ACTIVE_GLOBAL_PRODUCTION",
    "ACTIVE_VERIFIED_LOCKED_PRODUCTION",
    "LOCKED_HARD_GATE",
)


class ProductionAuthorityDrift(RuntimeError):
    pass


def _is_production(status: str) -> bool:
    s = str(status or "").upper()
    return any(marker in s for marker in PRODUCTION_STATUS_MARKERS)


def validate_declared_authority(root: str | Path, registry: dict[str, Any] | None = None) -> dict[str, Any]:
    """Fail closed when a declared Notion production contract is absent from code.

    Notion is the declarative authority; the engine is executable law. The bridge
    ledger in engine_registry.json is the release-time reconciliation surface.
    """
    base = Path(root)
    reg = registry if registry is not None else json.loads((base / "engine_registry.json").read_text())
    contracts = list(reg.get("NOTION_PRODUCTION_AUTHORITY_CONTRACTS", []))
    failures: list[str] = []
    checked = 0
    for item in contracts:
        status = str(item.get("NOTION_STATUS", ""))
        if not _is_production(status):
            continue
        checked += 1
        patch_id = str(item.get("PATCH_ID", ""))
        contract = item.get("CONTRACT_FILE")
        execs = item.get("EXECUTABLE_FILES") or ([item["EXECUTABLE_FILE"]] if item.get("EXECUTABLE_FILE") else [])
        engine_id = item.get("REGISTRY_ENGINE_ID")
        if not patch_id:
            failures.append("MISSING_PATCH_ID")
            continue
        if not contract or not (base / str(contract)).is_file():
            failures.append(f"{patch_id}:MISSING_CONTRACT_FILE:{contract}")
        if not execs:
            failures.append(f"{patch_id}:MISSING_EXECUTABLE_DECLARATION")
        for rel in execs:
            if not (base / str(rel)).is_file():
                failures.append(f"{patch_id}:MISSING_EXECUTABLE_FILE:{rel}")
        if engine_id:
            matches = [e for e in reg.get("ENGINES", []) if e.get("ENGINE_ID") == engine_id]
            if len(matches) != 1:
                failures.append(f"{patch_id}:REGISTRY_ENGINE_BINDING_NOT_UNIQUE:{engine_id}")
            else:
                active = set(matches[0].get("ACTIVE_PATCHES", [])) | set(matches[0].get("ACTIVE_DOCTRINES", []))
                if patch_id not in active:
                    failures.append(f"{patch_id}:NOT_WIRED_TO_ENGINE:{engine_id}")
    if failures:
        raise ProductionAuthorityDrift("PRODUCTION_AUTHORITY_DRIFT:" + "|".join(failures))
    return {
        "PATCH_ID": PATCH_ID,
        "STATUS": "PASS",
        "DECLARED_PRODUCTION_CONTRACTS_CHECKED": checked,
        "FAILURES": [],
    }


def validate_bundle(root: str | Path) -> dict[str, Any]:
    return validate_declared_authority(root)
