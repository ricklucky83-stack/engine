from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Any, Mapping, Sequence
import math
import numpy as np

PATCH_ID = "APEX_GLOBAL_CONDITIONAL_SPORTS_FIELD_CONTEST_SURFACE_v1"
SPORTS_SURFACE_OBJECTIVE = "PURE_SPORTS_OUTCOMES_BEFORE_CONTEST_ECONOMICS"
FIELD_SURFACE_OBJECTIVE = "PUBLIC_LINEUP_GENERATION_AND_EXACT_DUPLICATION"
CONTEST_SURFACE_OBJECTIVE = "COMMON_WORLD_RANK_TIE_SPLIT_PAYOUT_EV"

# These may exist as metadata elsewhere, but they may not parameterize the sports
# outcome generator. This is the hard anti-contamination boundary.
FORBIDDEN_SPORTS_GENERATOR_KEYS = {
    "OWNERSHIP", "PROJECTED_OWNERSHIP", "LINEUP_OWNERSHIP", "OWNERSHIP_PRODUCT",
    "EXPECTED_DUP", "EXPECTED_DUPLICATION", "DUPLICATION", "P_DUP_0", "DUP_P95",
    "LEVERAGE", "LEVERAGE_SCORE", "FIELD_FREQUENCY", "CONSTRUCTION_FREQUENCY",
    "EXPECTED_PAYOUT", "EXPECTED_ROI", "PRIZE_POOL", "ENTRY_FEE", "PAYOUT_CURVE",
    "SALARY", "DK_SALARY", "PRICE",
}


class SurfaceContractError(RuntimeError):
    pass


@dataclass(frozen=True)
class DuplicationSurface:
    counts: np.ndarray  # shape=(candidates, field_sims), number of OTHER exact copies
    metrics: tuple[dict[str, float], ...]


@dataclass(frozen=True)
class ContestSurface:
    candidate_scores: np.ndarray  # shape=(trials, candidates)
    field_scores: np.ndarray      # shape=(trials, field_entries)
    metrics: tuple[dict[str, float], ...]
    receipt: dict[str, Any]


def _norm_key(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")


def validate_sports_generator_inputs(inputs: Mapping[str, Any]) -> None:
    bad = sorted({_norm_key(k) for k in inputs} & FORBIDDEN_SPORTS_GENERATOR_KEYS)
    if bad:
        raise SurfaceContractError("SPORTS_SURFACE_ECONOMIC_CONTAMINATION:" + ",".join(bad))


def canonical_lineup_key(lineup: Sequence[Any], slot_multipliers: Sequence[float] | None = None) -> tuple:
    vals = tuple(str(x) for x in lineup)
    if slot_multipliers is None:
        # Classic/Flex slot permutations do not create economically distinct lineups.
        return tuple(sorted(vals))
    mult = tuple(float(x) for x in slot_multipliers)
    if len(mult) != len(vals):
        raise SurfaceContractError("SLOT_MULTIPLIER_LENGTH_MISMATCH")
    # Role-changing multipliers (e.g. CPT 1.5x) remain identity-bearing; same-value
    # UTIL/FLEX slots collapse naturally via sorting.
    return tuple(sorted((round(m, 8), p) for m, p in zip(mult, vals)))


def lineup_score_matrix(
    player_fpts: np.ndarray,
    lineup_indices: np.ndarray,
    slot_multipliers: Sequence[float] | None = None,
) -> np.ndarray:
    x = np.asarray(player_fpts, dtype=np.float64)
    lu = np.asarray(lineup_indices, dtype=np.int64)
    if x.ndim != 2 or lu.ndim != 2:
        raise SurfaceContractError(f"SCORE_MATRIX_SHAPE_INVALID:{x.shape}:{lu.shape}")
    if np.any(lu < 0) or np.any(lu >= x.shape[1]):
        raise SurfaceContractError("LINEUP_PLAYER_INDEX_OUT_OF_RANGE")
    if slot_multipliers is None:
        m = np.ones(lu.shape[1], dtype=np.float64)
    else:
        m = np.asarray(slot_multipliers, dtype=np.float64)
        if m.shape != (lu.shape[1],) or np.any(~np.isfinite(m)):
            raise SurfaceContractError("INVALID_SLOT_MULTIPLIERS")
    # trials x candidates x slots -> trials x candidates
    return np.sum(x[:, lu] * m[None, None, :], axis=2, dtype=np.float64)


def estimate_duplication_surface(
    candidate_lineups: Sequence[Sequence[Any]],
    repeated_field_lineups: Sequence[Sequence[Sequence[Any]]],
    *,
    slot_multipliers: Sequence[float] | None = None,
) -> DuplicationSurface:
    if not candidate_lineups:
        raise SurfaceContractError("EMPTY_CANDIDATE_LINEUPS")
    if not repeated_field_lineups:
        raise SurfaceContractError("EMPTY_REPEATED_FIELDS")
    keys = [canonical_lineup_key(x, slot_multipliers) for x in candidate_lineups]
    counts = np.zeros((len(keys), len(repeated_field_lineups)), dtype=np.int32)
    for s, field in enumerate(repeated_field_lineups):
        c = Counter(canonical_lineup_key(x, slot_multipliers) for x in field)
        for i, key in enumerate(keys):
            counts[i, s] = int(c.get(key, 0))
    metrics: list[dict[str, float]] = []
    for row in counts:
        metrics.append({
            "EXPECTED_DUP": float(np.mean(row)),
            "P_DUP_0": float(np.mean(row == 0)),
            "P_DUP_1": float(np.mean(row == 1)),
            "P_DUP_2_PLUS": float(np.mean(row >= 2)),
            "P_DUP_5_PLUS": float(np.mean(row >= 5)),
            "P_DUP_10_PLUS": float(np.mean(row >= 10)),
            "DUP_P95": float(np.quantile(row, 0.95, method="higher")),
        })
    return DuplicationSurface(counts=counts, metrics=tuple(metrics))


def _payout_vector(payout_curve: Mapping[int, float] | Sequence[float], max_rank: int) -> np.ndarray:
    p = np.zeros(max(1, int(max_rank)), dtype=np.float64)
    if isinstance(payout_curve, Mapping):
        for rank, prize in payout_curve.items():
            r = int(rank)
            v = float(prize)
            if 1 <= r <= len(p) and math.isfinite(v) and v >= 0:
                p[r - 1] = v
    else:
        arr = np.asarray(tuple(payout_curve), dtype=np.float64)
        if arr.ndim != 1 or np.any(~np.isfinite(arr)) or np.any(arr < 0):
            raise SurfaceContractError("INVALID_PAYOUT_CURVE")
        p[: min(len(p), len(arr))] = arr[: len(p)]
    return p


def evaluate_common_world_contest(
    *,
    player_fpts: np.ndarray,
    candidate_lineups: np.ndarray,
    field_lineups: np.ndarray,
    payout_curve: Mapping[int, float] | Sequence[float],
    entry_fee: float = 0.0,
    slot_multipliers: Sequence[float] | None = None,
    top_fraction: float = 0.001,
) -> ContestSurface:
    """Evaluate candidate lineups and the synthetic field in the SAME sports worlds.

    `player_fpts` is the Sports Surface only. Ownership, salary, field frequency,
    duplication and payouts are deliberately absent from its construction here.
    `field_lineups` is a legal contest field generated by the Field Surface.
    Tie groups are paid by averaging all occupied payout ranks, so exact duplicate
    lineups and independent same-score ties split prize money correctly when the
    field contains those entries.
    """
    pf = np.asarray(player_fpts, dtype=np.float64)
    cand = np.asarray(candidate_lineups, dtype=np.int64)
    fld = np.asarray(field_lineups, dtype=np.int64)
    if pf.ndim != 2 or cand.ndim != 2 or fld.ndim != 2:
        raise SurfaceContractError("COMMON_WORLD_INPUT_SHAPE_INVALID")
    if cand.shape[1] != fld.shape[1]:
        raise SurfaceContractError("ROSTER_SIZE_MISMATCH")
    if pf.shape[0] <= 0 or fld.shape[0] <= 0 or cand.shape[0] <= 0:
        raise SurfaceContractError("EMPTY_COMMON_WORLD_SURFACE")
    if not math.isfinite(float(entry_fee)) or float(entry_fee) < 0:
        raise SurfaceContractError("INVALID_ENTRY_FEE")

    cscore = lineup_score_matrix(pf, cand, slot_multipliers)
    fscore = lineup_score_matrix(pf, fld, slot_multipliers)
    field_entries = int(fld.shape[0])
    max_rank = field_entries + 1
    prizes = _payout_vector(payout_curve, max_rank)
    prefix = np.concatenate(([0.0], np.cumsum(prizes)))
    top_k = max(1, int(math.ceil(max_rank * float(top_fraction))))

    # Exact lineup duplicates are identified independently of score ties for a
    # clean Field Surface receipt. Score tie payout below already includes them.
    field_keys = [canonical_lineup_key(row.tolist(), slot_multipliers) for row in fld]
    exact_counter = Counter(field_keys)

    out: list[dict[str, float]] = []
    for j in range(cand.shape[0]):
        s = cscore[:, j]
        greater = np.sum(fscore > s[:, None], axis=1).astype(np.int32)
        equal = np.sum(np.isclose(fscore, s[:, None], rtol=0.0, atol=1e-9), axis=1).astype(np.int32)
        tie_n = equal + 1
        start = greater + 1
        end = np.minimum(max_rank, greater + tie_n)
        paid_sum = prefix[end] - prefix[start - 1]
        payout = paid_sum / tie_n
        dup = int(exact_counter.get(canonical_lineup_key(cand[j].tolist(), slot_multipliers), 0))
        p95 = float(np.quantile(s, 0.95))
        p99 = float(np.quantile(s, 0.99))
        q99 = p99
        cvar99 = float(np.mean(s[s >= q99])) if np.any(s >= q99) else p99
        expected_payout = float(np.mean(payout))
        fee = float(entry_fee)
        out.append({
            "MEAN": float(np.mean(s)),
            "MEDIAN": float(np.median(s)),
            "P95": p95,
            "P99": p99,
            "CVAR99": cvar99,
            "WIN_RATE": float(np.mean(greater == 0)),
            "SOLE_WIN_RATE": float(np.mean((greater == 0) & (tie_n == 1))),
            "TOP_0_1_RATE": float(np.mean(start <= top_k)),
            "EXPECTED_PAYOUT": expected_payout,
            "EXPECTED_ROI": float((expected_payout - fee) / fee) if fee > 0 else float("nan"),
            "EXPECTED_DUP": float(dup),
            "P_DUP_0": float(dup == 0),
            "P_DUP_2_PLUS": float(dup >= 2),
            "DUP_P95": float(dup),
        })

    receipt = {
        "PATCH_ID": PATCH_ID,
        "SPORTS_SURFACE_CONTAMINATED_BY_FIELD_ECONOMICS": False,
        "COMMON_WORLD_RANKING": True,
        "FIELD_ENTRIES": field_entries,
        "TRIALS": int(pf.shape[0]),
        "CANDIDATES": int(cand.shape[0]),
        "TOP_FRACTION": float(top_fraction),
        "TOP_RANK_THRESHOLD": int(top_k),
        "TIE_SPLIT_PAYOUT": True,
        "EXACT_DUPLICATION_LINEUP_LEVEL": True,
        "INDIVIDUAL_LEVERAGE_PRIMARY_OBJECTIVE": False,
        "POSTLOCK_RESULTS_USED": False,
    }
    return ContestSurface(candidate_scores=cscore, field_scores=fscore, metrics=tuple(out), receipt=receipt)
