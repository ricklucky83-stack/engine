from __future__ import annotations
import math, os
from pathlib import Path
import numpy as np
import pandas as pd

PATCH_ID="MLB_SD_ROLE_AWARE_ZERO_PRESERVING_CONTEST_OWNERSHIP_CANDIDATE_v2"
NFL_SD_ROUTE_PATCH_ID="APEX_NFL_SD_OWNERSHIP_ROUTE_INVARIANT_v1"

OWN_CANDIDATES=("RST%","OWN%","OWNERSHIP","Ownership","Projected Ownership","PROJ OWN%")
PROJ_CANDIDATES=("FPTS","PROJ","Projection","Projected Points","FP")
SAL_CANDIDATES=("SAL","Salary","SALARY")

ROSTER_SIZES={
 ("MLB","SHOWDOWN"):6, ("MLB","CLASSIC"):10,
 ("NFL","SHOWDOWN"):6, ("NFL","CLASSIC"):9, ("NFL","SS_TDS"):3,
 ("WNBA","SHOWDOWN"):6, ("WNBA","CLASSIC"):8,
 ("NBA","SHOWDOWN"):6, ("NBA","CLASSIC"):8,
 ("MMA","CLASSIC"):6, ("MMA","SHOWDOWN"):6,
 ("PGA","CLASSIC"):6, ("PGA","SHOWDOWN"):6,
 ("TENNIS","CLASSIC"):6,
}

def _col(df, names):
    for n in names:
        if n in df.columns: return n
    return None

def _raw_pct(x):
    a=pd.to_numeric(x,errors="coerce").astype(float).to_numpy()
    finite=a[np.isfinite(a)]
    if finite.size and np.nanmax(finite)<=1.5: a=a*100.0
    return np.clip(np.nan_to_num(a,nan=0.0),0.0,99.0)

def _pct(x):
    return np.clip(_raw_pct(x),0.01,99.0)

def _z(x):
    x=np.asarray(x,float)
    med=np.nanmedian(x); mad=np.nanmedian(np.abs(x-med))
    if not np.isfinite(mad) or mad<1e-9: return np.zeros_like(x)
    return np.clip((x-med)/(1.4826*mad),-3.0,3.0)

def _num_series(df,name,default=0.0):
    if name not in df.columns: return pd.Series(default,index=df.index,dtype=float)
    return pd.to_numeric(df[name],errors='coerce').fillna(default).astype(float)


def _close_percent_mass(weights, target:float, cap:float=99.0, floor:float=0.01):
    """Deterministically close a nonnegative score vector to exact percent slot mass."""
    w=np.maximum(np.asarray(weights,dtype=float),0.0)
    n=len(w)
    if n==0 or target < n*floor-1e-9 or target > n*cap+1e-9:
        raise RuntimeError("RUN_INVALID:OWNERSHIP_MASS_CLOSURE_INFEASIBLE")
    out=np.full(n,float(floor),dtype=float)
    remaining=float(target)-float(out.sum())
    free=np.ones(n,dtype=bool)
    for _ in range(n+3):
        idx=np.flatnonzero(free)
        if remaining<=1e-12: break
        if not len(idx): raise RuntimeError("RUN_INVALID:OWNERSHIP_MASS_CLOSURE_EXHAUSTED")
        base=np.maximum(w[idx],1e-12)
        add=base*(remaining/base.sum())
        room=float(cap)-out[idx]
        hit=add>=room
        if not np.any(hit):
            out[idx]+=add; remaining=0.0; break
        hidx=idx[hit]
        consumed=float(room[hit].sum())
        out[hidx]=float(cap); free[hidx]=False; remaining-=consumed
    if remaining>1e-8:
        idx=np.flatnonzero(free)
        if not len(idx): raise RuntimeError("RUN_INVALID:OWNERSHIP_MASS_CLOSURE_REMAINDER")
        out[idx]+=remaining/len(idx)
    diff=float(target)-float(out.sum())
    if abs(diff)>1e-10:
        idx=np.flatnonzero((out>floor+1e-9)&(out<cap-1e-9))
        if not len(idx): idx=np.flatnonzero(out<cap-1e-9)
        if not len(idx): raise RuntimeError("RUN_INVALID:OWNERSHIP_MASS_CLOSURE_CORRECTION")
        out[idx[0]]+=diff
    if abs(float(out.sum())-float(target))>1e-6:
        raise RuntimeError("RUN_INVALID:OWNERSHIP_MASS_CLOSURE_PARITY")
    return out

def _normalize_mass_capped_pct(values, target, cap=99.0):
    a=np.maximum(np.asarray(values,float),1e-12)
    out=np.zeros_like(a); free=np.ones(len(a),dtype=bool); remain=float(target)
    if remain > cap*len(a)+1e-9:
        raise ValueError('OWNERSHIP_TARGET_MASS_INFEASIBLE')
    for _ in range(len(a)+2):
        if not free.any(): break
        alloc=remain*a[free]/a[free].sum(); over=alloc>cap
        if not over.any():
            out[free]=alloc; remain=0.0; break
        idx=np.where(free)[0]; hit=idx[over]
        out[hit]=cap; remain-=cap*len(hit); free[hit]=False
    if remain>1e-8 and free.any(): out[free]+=remain/free.sum()
    return out


def _derive_nfl_showdown_bootstrap(out:pd.DataFrame, own_col:str|None, contest_type:str|None)->pd.DataFrame:
    """Common-route bootstrap for NFL Showdown.

    Provider ownership is preserved as evidence only.  The compatibility RST alias is
    engine-owned and closed to six roster slots so malformed provider mass can never
    propagate into a public-field simulator.  The sport runtime subsequently refines
    this bootstrap with current role evidence and creates separate CPT/FLEX marginals.
    """
    if own_col is None:
        provider=np.zeros(len(out),dtype=float)
        own_col='RST%'
        out[own_col]=0.0
    else:
        provider=_raw_pct(out[own_col])
    out['RW_RST_PRIOR']=provider
    out['PROVIDER_RST_RAW']=provider
    pc=_col(out,PROJ_CANDIDATES); sc=_col(out,SAL_CANDIDATES)
    proj=pd.to_numeric(out[pc],errors='coerce').fillna(0).to_numpy(float) if pc else np.zeros(len(out))
    sal=pd.to_numeric(out[sc],errors='coerce').fillna(5000).to_numpy(float) if sc else np.full(len(out),5000.0)
    ceil_col='Ceil' if 'Ceil' in out.columns else pc
    ceilv=pd.to_numeric(out[ceil_col],errors='coerce').fillna(pd.Series(proj,index=out.index)).to_numpy(float) if ceil_col else proj.copy()
    value=np.divide(np.maximum(proj,0.0)*1000.0,np.maximum(sal,200.0))
    pos=(out.get('POS',pd.Series('',index=out.index)).astype(str).str.split('/').str[0].str.upper()).to_numpy(object)
    # Provider is one feature, never the authority.  Projection/value/tail and position
    # priors keep zero-provider K/DST/role rows alive for the sport-mode model.
    provider_signal=_z(np.log1p(np.maximum(provider,0.0))) if len(out) else np.array([])
    score=(0.38*provider_signal + 0.27*_z(proj) + 0.17*_z(value) + 0.18*_z(np.maximum(ceilv,proj)))
    score += np.where(np.isin(pos,['K','DST']),0.12,0.0)
    score += np.where(pos=='QB',0.08,0.0)
    w=np.exp(np.clip(score-np.max(score) if len(score) else score,-40,40)) if len(score) else score
    derived=_close_percent_mass(w,600.0)
    out['APEX_EXPECTED_OWNERSHIP']=derived
    out['APEX_OWNERSHIP_AUTHORITY']='NFL_SD_COMMON_INTERNAL_BOOTSTRAP_600_MASS'
    out['APEX_OWNERSHIP_ROUTE_PATCH_ID']=NFL_SD_ROUTE_PATCH_ID
    out[own_col]=derived
    return out

def _derive_mlb_showdown_role_aware(out:pd.DataFrame, own_col:str)->pd.DataFrame:
    prior=_raw_pct(out[own_col])
    out['RW_RST_PRIOR']=prior
    lineup=out.get('LINEUP',pd.Series('',index=out.index)).astype(str).str.strip()
    player=out.get('PLAYER',pd.Series('',index=out.index)).astype(str).str.strip()
    pitcher=lineup.str.upper().eq('SP')
    hitter=lineup.str.fullmatch(r'[1-9]')
    opp_names=set(out.loc[hitter,'Opp Pitcher'].dropna().astype(str).str.strip()) if 'Opp Pitcher' in out.columns else set()
    confirmed_sp=pitcher & player.isin(opp_names)
    games=_num_series(out,'G',0.0).clip(lower=1.0)
    innings=_num_series(out,'IP',0.0)
    ipg=innings/games
    sal=_num_series(out,_col(out,SAL_CANDIDATES) or 'SAL',0.0)
    bulk=pitcher & (~confirmed_sp) & (prior>0) & (innings>=20.0) & (games>=5.0) & (ipg>=3.0)
    rp_eligible=pitcher & (~confirmed_sp) & (prior>0) & ((sal<=5000.0) | bulk)
    live=hitter | confirmed_sp | rp_eligible

    score=np.full(len(out),-np.inf,float)
    order=pd.to_numeric(lineup.where(hitter),errors='coerce').fillna(10).astype(float).to_numpy()
    sal_k=sal.to_numpy()/1000.0
    cheap=np.maximum(0.0,6.5-sal_k)
    premium=np.maximum(0.0,sal_k-7.5)
    tr=_num_series(out,'T Runs',4.0).to_numpy()
    hs=(-16.0/3.0) - order/12.0 + (3.0/14.0)*cheap + (1.0/14.0)*premium + (5.0/3.0)*tr
    score[hitter.to_numpy()]=hs[hitter.to_numpy()]
    sp_score=1.55 + 0.000175*(sal.to_numpy()-10000.0)
    score[confirmed_sp.to_numpy()]=sp_score[confirmed_sp.to_numpy()]
    rp_score=-2.645833333333333 + 0.15*np.log1p(games.to_numpy()) + 0.045*np.clip(ipg.to_numpy(),0.0,3.0)
    score[rp_eligible.to_numpy()]=rp_score[rp_eligible.to_numpy()]

    derived=np.zeros(len(out),float)
    ids=np.where(live.to_numpy())[0]
    if len(ids):
        z=score[ids]-np.max(score[ids]); w=np.exp(np.clip(z,-60,0)); derived[ids]=600.0*w/w.sum()

    role=np.full(len(out),'INACTIVE_OR_BENCH',object)
    role[(pitcher & ~confirmed_sp & ~rp_eligible).to_numpy()]='PITCHER_NO_ROLE_EVIDENCE_ZERO_PRESERVED'
    role[hitter.to_numpy()]='CONFIRMED_STARTING_HITTER'
    role[confirmed_sp.to_numpy()]='CONFIRMED_STARTING_PITCHER'
    role[(rp_eligible & ~bulk).to_numpy()]='RELIEF_ROLE_EVIDENCE'
    role[bulk.to_numpy()]='BULK_ROLE_EVIDENCE'

    out['APEX_EXPECTED_OWNERSHIP']=derived
    out['APEX_CONFIRMED_STARTER']=confirmed_sp.to_numpy(dtype=bool)
    out['APEX_RP_ELIGIBLE']=rp_eligible.to_numpy(dtype=bool)
    out['APEX_BULK_ROLE_EVIDENCE']=bulk.to_numpy(dtype=bool)
    out['APEX_OWNERSHIP_ROLE_CLASS']=role
    out['APEX_OWNERSHIP_AUTHORITY']='MLB_SD_ROLE_AWARE_ZERO_PRESERVING_PRELOCK'
    out[own_col]=derived
    return out

def derive_expected_ownership(df:pd.DataFrame, sport:str, mode:str, field_size:int|None=None,
                              contest_type:str|None=None, roster_size:int|None=None)->pd.DataFrame:
    out=df.copy(); own_col=_col(out,OWN_CANDIDATES)
    if sport.upper()=='NFL' and mode.upper()=='SHOWDOWN':
        return _derive_nfl_showdown_bootstrap(out,own_col,contest_type)
    if own_col is None:
        out['RW_RST_PRIOR']=np.nan; out['APEX_EXPECTED_OWNERSHIP']=np.nan
        out['APEX_OWNERSHIP_AUTHORITY']='NO_PROVIDER_PRIOR_NATIVE_FIELD_MODEL_REQUIRED'; return out
    if sport.upper()=='MLB' and mode.upper()=='SHOWDOWN':
        return _derive_mlb_showdown_role_aware(out,own_col)
    prior=_pct(out[own_col]); out['RW_RST_PRIOR']=prior
    eps=1e-4; p=np.clip(prior/100.0,eps,1-eps); logit=np.log(p/(1-p))
    ctype=(contest_type or os.getenv('APEX_CONTEST_TYPE','')).upper(); concentration=1.0
    if any(k in ctype for k in ('SINGLE','SE','1-MAX','1MAX')): concentration=1.08
    elif any(k in ctype for k in ('3-MAX','3MAX','THREE')): concentration=1.04
    elif any(k in ctype for k in ('MME','150','20-MAX','20MAX')): concentration=0.96
    score=logit*concentration
    pc=_col(out,PROJ_CANDIDATES)
    if pc is not None and not (sport.upper()=='NFL' and mode.upper()=='SS_TDS'):
        score += 0.08*_z(pd.to_numeric(out[pc],errors='coerce').fillna(0).to_numpy())
    derived=1/(1+np.exp(-score))*100.0; derived=np.clip(derived,0.05,95.0)
    target=float(np.sum(prior)); rs=roster_size or ROSTER_SIZES.get((sport.upper(),mode.upper()))
    if rs and (target < rs*55 or target > rs*145): target=rs*100.0
    if sport.upper()=='NFL' and mode.upper()=='SS_TDS':
        derived=_normalize_mass_capped_pct(derived,target,cap=99.0)
    else:
        if derived.sum()>0 and target>0: derived*=target/derived.sum()
        derived=np.clip(derived,0.05,99.0)
    out['APEX_EXPECTED_OWNERSHIP']=derived; out['APEX_OWNERSHIP_AUTHORITY']='CONTEST_DERIVED_PRELOCK'; out[own_col]=derived
    return out

def repair_player_pool_file(path:str|Path, sport:str, mode:str, field_size:int|None=None,
                            contest_type:str|None=None, output_path:str|Path|None=None)->str:
    path=Path(path); df=pd.read_csv(path); out=derive_expected_ownership(df,sport,mode,field_size,contest_type)
    if output_path is None: output_path=path.with_name(path.stem+'.apex_ownership.csv')
    output_path=Path(output_path); out.to_csv(output_path,index=False); return str(output_path)

def leverage_score(win_or_optimal_equity, expected_ownership, eps=1e-6):
    q=np.asarray(win_or_optimal_equity,float); o=np.asarray(expected_ownership,float)
    if np.nanmax(o)>1.5: o=o/100.0
    return np.log(np.clip(q,eps,1.0))-np.log(np.clip(o,eps,1.0))
