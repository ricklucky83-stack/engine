from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence
import csv
import hashlib
import json
from datetime import datetime, timezone


from engines.common.universal_prebuild_availability_gate_v1 import (
    AvailabilityGateError, AvailabilityGateResult, merge_out_names,
    validate_prebuild_availability_receipt,
)

PATCH_ID = "APEX_GLOBAL_MANDATORY_PREBUILD_ROSTER_CHECK_v1"
LIFECYCLE_PATCH_ID = "APEX_GLOBAL_HARD_ENFORCED_ROSTER_GATE_LIFECYCLE_v1"
GATE_ID = "APEX_UNIVERSAL_PREBUILD_AVAILABILITY_AND_LINEUP_GATE_v2"


def require_prebuild_roster_check(
    receipt_path: str | Path | None, *, sport: str, mode: str, pool_path: str | Path,
    execution_id: str | int, field_size: int, final_selector_recheck: bool = False,
) -> AvailabilityGateResult:
    def _classification_only(reason: str) -> AvailabilityGateResult:
        pool = Path(pool_path)
        if not pool.exists():
            raise AvailabilityGateError(f"RUN_INVALID:PLAYER_POOL_MISSING:{pool}")
        # Player-pool bytes remain the authoritative live execution universe when
        # external availability bookkeeping is unavailable. No unverified OUT purge.
        pool_sha=hashlib.sha256(pool.read_bytes()).hexdigest()
        now=datetime.now(timezone.utc).isoformat()
        reason_hash=hashlib.sha256(reason.encode('utf-8')).hexdigest()
        return AvailabilityGateResult(
            receipt_path=f"CLASSIFICATION_ONLY:{reason}",receipt_sha256=reason_hash,gate_id=GATE_ID,
            code_only_contract='APEX_EXECUTION_AUTHORITY_MINIMAL_HARD_GATES_v1',generated_at_utc=now,age_minutes=0.0,
            sport=str(sport).upper(),mode=str(mode).upper(),pool_sha256=pool_sha,source_count=0,team_count=0,participant_count=0,
            out_players=(),starters_by_team={},participant_status={},individual_certified_hard_out_players=(),
            individual_unresolved_unavailable_candidates=(),individual_hard_out_evidence_mode={},dk_source_universe_hard_lock=False,
            missing_pool_starters=(),diagnostic_missing_starter_override=True,nfl_hard_out_temporal_provenance_required=False,
            nfl_player_status_records_count=0,nfl_unresolved_hard_out_candidates=(),nfl_hard_out_conflicts_resolved=(),nfl_latest_status_by_player={}
        )
    if receipt_path is None or not str(receipt_path).strip():
        return _classification_only('AVAILABILITY_RECEIPT_ABSENT_NONBLOCKING')
    try:
        gate = validate_prebuild_availability_receipt(
            receipt_path, sport=sport, mode=mode, pool_path=pool_path,
            execution_id=execution_id, field_size=field_size,
            final_selector_recheck=final_selector_recheck,
        )
    except AvailabilityGateError as exc:
        return _classification_only('AVAILABILITY_RECEIPT_INVALID_NONBLOCKING:'+str(exc))
    if gate.gate_id != GATE_ID:
        return _classification_only('AVAILABILITY_GATE_ID_MISMATCH_NONBLOCKING:'+str(gate.gate_id))
    return gate


def verified_out_names(gate: AvailabilityGateResult, explicit_out_names=()) -> list[str]:
    return merge_out_names(gate, explicit_out_names)


def gate_receipt(gate: AvailabilityGateResult) -> dict[str, Any]:
    return {
        "PATCH_ID": PATCH_ID,
        "MANDATORY_PREBUILD_ROSTER_CHECK": "PASS" if gate.source_count else "CLASSIFICATION_ONLY_NONBLOCKING",
        **gate.to_receipt(),
    }


class RosterGateLifecycleError(AvailabilityGateError):
    """Raised when build/resume/board execution is attempted without a fresh sealed gate."""


def _canonical_hash(payload: Mapping[str, Any]) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _resolve_state_version(explicit_state_version: str | None = None) -> str:
    if explicit_state_version and str(explicit_state_version).strip():
        return str(explicit_state_version).strip()
    manifest = Path(__file__).resolve().parents[2] / "bundle_manifest.json"
    if not manifest.exists():
        return 'UNCLASSIFIED'
    try:
        version = str(json.loads(manifest.read_text(encoding="utf-8")).get("STATE_VERSION") or "").strip()
    except Exception as exc:
        return 'UNCLASSIFIED'
    if not version:
        return 'UNCLASSIFIED'
    return version


def _pool_player_names(pool_path: str | Path) -> list[str]:
    path = Path(pool_path)
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise RosterGateLifecycleError("RUN_INVALID:ROSTER_GATE_POOL_HEADER_MISSING")
        player_col = next((c for c in ("PLAYER", "Name", "NAME", "Player") if c in reader.fieldnames), None)
        if player_col is None:
            raise RosterGateLifecycleError("RUN_INVALID:ROSTER_GATE_PLAYER_COLUMN_MISSING")
        names = [str(row.get(player_col) or "").strip() for row in reader]
    names = [x for x in names if x]
    if not names:
        raise RosterGateLifecycleError("RUN_INVALID:ROSTER_GATE_POOL_EMPTY")
    return names


class RuntimeRosterSeal:
    __slots__ = ("state_version","pool_sha256","active_pool_hash","roster_snapshot_hash",
                 "roster_snapshot_timestamp","gate_token","active_players","out_players")
    def __init__(self, *, state_version: str, pool_sha256: str, active_pool_hash: str,
                 roster_snapshot_hash: str, roster_snapshot_timestamp: str, gate_token: str,
                 active_players: tuple[str, ...], out_players: tuple[str, ...]):
        self.state_version=state_version; self.pool_sha256=pool_sha256; self.active_pool_hash=active_pool_hash
        self.roster_snapshot_hash=roster_snapshot_hash; self.roster_snapshot_timestamp=roster_snapshot_timestamp
        self.gate_token=gate_token; self.active_players=active_players; self.out_players=out_players
    def to_receipt(self) -> dict[str, Any]:
        return {"PATCH_ID":LIFECYCLE_PATCH_ID,"STATE_VERSION":self.state_version,"POOL_SHA256":self.pool_sha256,
                "ACTIVE_POOL_HASH":self.active_pool_hash,"ROSTER_SNAPSHOT_HASH":self.roster_snapshot_hash,
                "ROSTER_SNAPSHOT_TIMESTAMP":self.roster_snapshot_timestamp,"GATE_TOKEN":self.gate_token,
                "ACTIVE_POOL_SIZE":len(self.active_players),"OUT_PURGE":list(self.out_players),"GATE_SEALED":True}


def seal_runtime_roster_gate(gate: AvailabilityGateResult, *, pool_path: str | Path,
                             explicit_out_names: Sequence[str] = (), state_version: str | None = None) -> RuntimeRosterSeal:
    resolved_state = _resolve_state_version(state_version)
    pool_names = _pool_player_names(pool_path)
    out_names = tuple(sorted(set(verified_out_names(gate, explicit_out_names))))
    out_set = set(out_names)
    active = tuple(sorted(name for name in pool_names if name not in out_set))
    if not active:
        raise RosterGateLifecycleError("RUN_INVALID:ROSTER_GATE_ACTIVE_POOL_EMPTY")
    active_pool_hash = _canonical_hash({"PLAYERS":active})
    token_payload={"STATE_VERSION":resolved_state,"POOL_SHA256":gate.pool_sha256,"ACTIVE_POOL_HASH":active_pool_hash,
                   "ROSTER_SNAPSHOT_HASH":gate.receipt_sha256,"ROSTER_SNAPSHOT_TIMESTAMP":gate.generated_at_utc}
    return RuntimeRosterSeal(state_version=resolved_state,pool_sha256=gate.pool_sha256,active_pool_hash=active_pool_hash,
        roster_snapshot_hash=gate.receipt_sha256,roster_snapshot_timestamp=gate.generated_at_utc,
        gate_token=_canonical_hash(token_payload),active_players=active,out_players=out_names)


def assert_runtime_roster_seal(seal: RuntimeRosterSeal | None, *, pool_path: str | Path,
                               explicit_out_names: Sequence[str] = ()) -> None:
    if seal is None or not isinstance(seal, RuntimeRosterSeal):
        raise RosterGateLifecycleError("RUN_INVALID:ROSTER_GATE_RUNTIME_TOKEN_REQUIRED")
    current_names=_pool_player_names(pool_path)
    out_set=set(seal.out_players) | {str(x).strip() for x in explicit_out_names if str(x).strip()}
    current_active_hash=_canonical_hash({"PLAYERS":tuple(sorted(n for n in current_names if n not in out_set))})
    if current_active_hash != seal.active_pool_hash:
        raise RosterGateLifecycleError("RUN_INVALID:ROSTER_GATE_ACTIVE_POOL_LINEAGE_DRIFT")
    expected=_canonical_hash({"STATE_VERSION":seal.state_version,"POOL_SHA256":seal.pool_sha256,
        "ACTIVE_POOL_HASH":seal.active_pool_hash,"ROSTER_SNAPSHOT_HASH":seal.roster_snapshot_hash,
        "ROSTER_SNAPSHOT_TIMESTAMP":seal.roster_snapshot_timestamp})
    if expected != seal.gate_token:
        raise RosterGateLifecycleError("RUN_INVALID:ROSTER_GATE_TOKEN_MISMATCH")


def build_chunk_gate_receipt(seal: RuntimeRosterSeal, *, chunk_idx: int) -> dict[str, Any]:
    if not isinstance(chunk_idx,int) or chunk_idx < 0:
        raise RosterGateLifecycleError("RUN_INVALID:ROSTER_GATE_CHUNK_INDEX_INVALID")
    return {"PATCH_ID":LIFECYCLE_PATCH_ID,"STATE_VERSION":seal.state_version,"ACTIVE_POOL_HASH":seal.active_pool_hash,
        "ROSTER_SNAPSHOT_HASH":seal.roster_snapshot_hash,"ROSTER_SNAPSHOT_TIMESTAMP":seal.roster_snapshot_timestamp,
        "GATE_TOKEN_AT_PERSIST":seal.gate_token,"CHUNK_IDX":chunk_idx}


def validate_resume_chunk_gate(fresh_seal: RuntimeRosterSeal | None, chunk_receipt: Mapping[str, Any], *, pool_path: str | Path) -> None:
    # Persisted booleans/tokens are evidence only; the fresh runtime seal is the authority.
    assert_runtime_roster_seal(fresh_seal,pool_path=pool_path)
    if not isinstance(chunk_receipt,Mapping):
        raise RosterGateLifecycleError("RUN_INVALID:ROSTER_GATE_CHUNK_RECEIPT_REQUIRED")
    # STATE_VERSION is lineage/classification only; active-pool identity remains the hard resume authority.
    if str(chunk_receipt.get("ACTIVE_POOL_HASH") or "") != fresh_seal.active_pool_hash:
        raise RosterGateLifecycleError("RUN_INVALID:ROSTER_GATE_RESUME_ACTIVE_POOL_DRIFT")
