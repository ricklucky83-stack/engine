from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Protocol

PATCH_ID = "APEX_GLOBAL_POST_DIAGNOSTIC_PERSISTENCE_AND_PROMOTION_ENFORCEMENT_v1"
TRIGGERS = {"PASS_LOCAL","DIAGNOSIS_COMPLETE","VALIDATED_PATCH","VALIDATED_CALIBRATION_CHANGE","VALIDATED_SELECTOR_CHANGE","VALIDATED_HANDOFF_CHANGE","VALIDATED_SPORT_RULE_CHANGE"}

class StatePersistenceError(RuntimeError): pass
class PointerRotationFailure(RuntimeError): pass
class PointerDriftError(RuntimeError): pass

class DriveHandler(Protocol):
    def write_immutable_bundle(self, **kwargs: Any) -> dict: ...
class GlobalRegistry(Protocol):
    def read_active_pointer(self) -> dict: ...
    def stage_pointer_rotation(self, **kwargs: Any) -> dict: ...
    def readback_verify(self) -> dict: ...
    def rollback_pointer(self, **kwargs: Any) -> None: ...

def increment_patch_version(version: str) -> str:
    parts=version.split('.')
    if len(parts)!=3 or not all(p.isdigit() for p in parts): raise ValueError(f"INVALID_STATE_VERSION:{version}")
    return f"{parts[0]}.{parts[1]}.{int(parts[2])+1}"

def enforce_global_promotion_lifecycle(local_state: Any, drive_handler: DriveHandler, global_registry: GlobalRegistry) -> Any:
    status=getattr(local_state,'repair_status',None)
    if status not in TRIGGERS: return local_state
    before=global_registry.read_active_pointer()
    active=str(before['STATE_VERSION'])
    requested_parent=str(getattr(local_state,'parent_state_version',active))
    if requested_parent != active: raise PointerDriftError(f"ACTIVE_POINTER_DRIFT:{requested_parent}->{active}")
    new_version=increment_patch_version(active)
    try:
        write=drive_handler.write_immutable_bundle(
            target_directory='/Drive/Sealed_Patches/',
            state_version=new_version,
            manifest=getattr(local_state,'current_manifest'),
            hashes=getattr(local_state,'computed_sha256'),
            frozen_candidate=getattr(local_state,'frozen_candidate_universe',None),
        )
        local_state.persisted_to_drive=True
        local_state.new_immutable_state_created=True
    except Exception as exc:
        raise StatePersistenceError(f"CANNOT_SERIALIZE_IMMUTABLE_STATE:{exc}") from exc
    pre_rotate=global_registry.read_active_pointer()
    if str(pre_rotate['STATE_VERSION']) != active:
        raise PointerDriftError(f"PRE_ROTATION_POINTER_DRIFT:{active}->{pre_rotate['STATE_VERSION']}")
    global_registry.stage_pointer_rotation(
        from_version=active,to_version=new_version,bundle_hash=write['BUNDLE_SHA256'],
        encoded_hash=write['ENCODED_SHA256'],bundle_file_id=write['BUNDLE_FILE_ID'])
    rb=global_registry.readback_verify()
    checks=(str(rb.get('STATE_VERSION'))==new_version and rb.get('BUNDLE_FILE_ID')==write['BUNDLE_FILE_ID'] and rb.get('BUNDLE_SHA256')==write['BUNDLE_SHA256'] and rb.get('ENCODED_SHA256')==write['ENCODED_SHA256'])
    if not checks:
        local_state.global_pointer_rotated=False
        global_registry.rollback_pointer(previous_pointer=before)
        raise PointerRotationFailure('GLOBAL_POINTER_READBACK_MISMATCH_ROLLBACK_INITIATED')
    local_state.global_pointer_rotated=True
    local_state.pointer_readback_verified=True
    local_state.global_repair_status='COMMITTED'
    local_state.state_version=new_version
    return local_state
