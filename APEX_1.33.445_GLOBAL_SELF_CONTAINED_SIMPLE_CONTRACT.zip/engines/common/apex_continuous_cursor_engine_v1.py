from __future__ import annotations
import hashlib, json, os, time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

PATCH_ID = "APEX_GLOBAL_CONTINUOUS_CURSOR_ENGINE_v1"
PROTOCOL_ID = "PHASE2_STREAM_PROTOCOL_V1"
HOT_STATE_FILE = "APEX_HOT_RUNTIME_STATE.json"
GENESIS_HASH = "0" * 64

class CursorIntegrityError(RuntimeError): pass
class RuntimeInvalidatedError(CursorIntegrityError): pass
class LedgerCorruptionError(CursorIntegrityError): pass


def _canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def sha256_file(path: str | os.PathLike) -> str:
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda:f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()

def atomic_write_bytes(path: str | os.PathLike, data: bytes) -> None:
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_name(path.name+".tmp")
    with tmp.open("wb") as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)
    try:
        dfd=os.open(str(path.parent), os.O_RDONLY)
        try: os.fsync(dfd)
        finally: os.close(dfd)
    except OSError:
        pass

def atomic_write_json(path: str | os.PathLike, obj: Mapping[str, Any]) -> None:
    atomic_write_bytes(path, _canonical(dict(obj))+b"\n")

def deterministic_chunk_seed(*, state_hash: str, execution_id: str, phase: str, chunk_id: int, simulation_block_id: int=0) -> int:
    payload={"STATE_HASH":state_hash,"EXECUTION_ID":str(execution_id),"PHASE":str(phase),"CHUNK_ID":int(chunk_id),"SIMULATION_BLOCK_ID":int(simulation_block_id)}
    return int(sha256_bytes(_canonical(payload))[:16],16) & 0x7FFFFFFFFFFFFFFF

@dataclass(frozen=True)
class LedgerTail:
    chunk_id: int
    commit_hash: str
    output_hash: str
    record: dict[str, Any]

class AppendOnlyLedger:
    """Durable JSONL hash-chain. Ledger tail is the only progress authority."""
    def __init__(self, path: str | os.PathLike):
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)

    def verify(self) -> LedgerTail | None:
        if not self.path.exists() or self.path.stat().st_size==0: return None
        prev=GENESIS_HASH; last=None; expected_chunk=None
        with self.path.open("r",encoding="utf-8") as f:
            for lineno,line in enumerate(f,1):
                if not line.strip(): continue
                try: rec=json.loads(line)
                except Exception as exc: raise LedgerCorruptionError(f"LEDGER_JSON_INVALID:{lineno}:{exc}") from exc
                if rec.get("STATUS")!="COMMITTED": raise LedgerCorruptionError(f"LEDGER_NONCOMMITTED_RECORD:{lineno}")
                if rec.get("PREVIOUS_COMMIT_HASH")!=prev: raise LedgerCorruptionError(f"LEDGER_CHAIN_BREAK:{lineno}")
                body={k:v for k,v in rec.items() if k!="COMMIT_HASH"}
                actual=sha256_bytes(_canonical(body))
                if rec.get("COMMIT_HASH")!=actual: raise LedgerCorruptionError(f"LEDGER_COMMIT_HASH_MISMATCH:{lineno}")
                cid=int(rec["CHUNK_ID"])
                if expected_chunk is not None and cid!=expected_chunk: raise LedgerCorruptionError(f"LEDGER_CHUNK_GAP:{expected_chunk}:{cid}")
                expected_chunk=cid+1; prev=actual; last=rec
        return None if last is None else LedgerTail(int(last["CHUNK_ID"]),str(last["COMMIT_HASH"]),str(last["OUTPUT_HASH"]),last)

    def append_commit(self, record: Mapping[str, Any]) -> LedgerTail:
        tail=self.verify(); prev=tail.commit_hash if tail else GENESIS_HASH
        rec=dict(record)
        cid=int(rec["CHUNK_ID"])
        expected=(tail.chunk_id+1) if tail else 0
        if cid!=expected: raise LedgerCorruptionError(f"LEDGER_APPEND_CURSOR_MISMATCH:{expected}:{cid}")
        rec["PREVIOUS_COMMIT_HASH"]=prev; rec["STATUS"]="COMMITTED"
        body={k:v for k,v in rec.items() if k!="COMMIT_HASH"}
        rec["COMMIT_HASH"]=sha256_bytes(_canonical(body))
        payload=_canonical(rec)+b"\n"
        with self.path.open("ab") as f:
            f.write(payload); f.flush(); os.fsync(f.fileno())
        verified=self.verify()
        if verified is None or verified.commit_hash!=rec["COMMIT_HASH"]:
            raise LedgerCorruptionError("LEDGER_TAIL_VERIFY_FAILED")
        return verified

    @property
    def next_chunk_id(self) -> int:
        tail=self.verify(); return 0 if tail is None else tail.chunk_id+1


def seal_hot_runtime(runtime_root: str | os.PathLike, *, state_version: str, state_id: str, bundle_sha256: str, encoded_sha256: str, manifest_path: str | os.PathLike, registry_path: str | os.PathLike) -> dict[str, Any]:
    root=Path(runtime_root); manifest_path=Path(manifest_path); registry_path=Path(registry_path)
    marker={
        "PATCH_ID":PATCH_ID,"STATE":"HYDRATED","RUNTIME_HYDRATED":True,
        "STATE_VERSION":str(state_version),"STATE_ID":str(state_id),
        "BUNDLE_SHA256":str(bundle_sha256),"ENCODED_SHA256":str(encoded_sha256),
        "STATE_MANIFEST_HASH":sha256_file(manifest_path),"ENGINE_REGISTRY_HASH":sha256_file(registry_path),
        "SEALED_AT_UNIX_NS":time.time_ns(),
    }
    marker["RUNTIME_ID"]=sha256_bytes(_canonical({k:marker[k] for k in ("STATE_VERSION","STATE_ID","BUNDLE_SHA256","STATE_MANIFEST_HASH","ENGINE_REGISTRY_HASH")}))
    atomic_write_json(root/HOT_STATE_FILE,marker); return marker


def validate_hot_runtime(runtime_root: str | os.PathLike, pointer: Mapping[str, Any]) -> tuple[bool, dict[str, Any] | None, str]:
    root=Path(runtime_root); marker_path=root/HOT_STATE_FILE; manifest_path=root/"bundle_manifest.json"; registry_path=root/"engine_registry.json"
    if not marker_path.exists(): return False,None,"HOT_STATE_MISSING"
    if not manifest_path.exists() or not registry_path.exists(): return False,None,"HOT_STATE_CORE_FILES_MISSING"
    try: marker=json.loads(marker_path.read_text(encoding="utf-8")); manifest=json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc: return False,None,f"HOT_STATE_PARSE_FAILURE:{type(exc).__name__}"
    checks=[
        marker.get("RUNTIME_HYDRATED") is True,
        marker.get("STATE")=="HYDRATED",
        str(marker.get("STATE_VERSION"))==str(pointer.get("STATE_VERSION")),
        str(marker.get("STATE_ID"))==str(pointer.get("STATE_ID")),
        str(marker.get("BUNDLE_SHA256"))==str(pointer.get("BUNDLE_SHA256")),
        str(marker.get("ENCODED_SHA256"))==str(pointer.get("ENCODED_SHA256")),
        str(manifest.get("STATE_VERSION"))==str(pointer.get("STATE_VERSION")),
        marker.get("STATE_MANIFEST_HASH")==sha256_file(manifest_path),
        marker.get("ENGINE_REGISTRY_HASH")==sha256_file(registry_path),
    ]
    if not all(checks): return False,marker,"HOT_STATE_INVARIANT_MISMATCH"
    return True,marker,"CONTENT_ADDRESSED_HOT_RUNTIME_REUSE"
