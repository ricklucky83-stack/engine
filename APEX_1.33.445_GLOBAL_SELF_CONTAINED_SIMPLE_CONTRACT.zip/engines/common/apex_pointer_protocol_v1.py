from __future__ import annotations
import hashlib, json
from pathlib import Path

PATCH_ID = "APEX_GLOBAL_CONTROL_PLANE_CONTENT_ADDRESSED_REF_PROTOCOL_v1"
POINTER_SCHEMA_V1 = "APEX_POINTER_ENVELOPE_V1"
CAP_OBJECT_FENCE = "OBJECT_ID_FENCE_V1"
CAP_IMMUTABLE_BOOTSTRAP = "IMMUTABLE_BOOTSTRAP_SHA256_V1"
CAP_CONTENT_STATE = "CONTENT_ADDRESSED_STATE_V1"
CORE_FIELDS = {
    "ACTIVE_POINTER_FILE","BOOTSTRAP_FILE","BOOTSTRAP_FILE_ID","BUNDLE_FILE","BUNDLE_FILE_ID",
    "BUNDLE_SHA256","ENCODED_SHA256","BUNDLE_MANIFEST_SHA256","GLOBAL_PATCHES","PARENT_STATE_VERSION",
    "STATE_ID","STATE_VERSION","VERSIONED_POINTER_SOURCE_FILE","VERSIONED_POINTER_SOURCE_FILE_ID"
}
class PointerProtocolError(RuntimeError): pass

def sha256_file(path: str|Path) -> str:
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def validate_pointer(pointer: dict, *, bootstrap_path: str|Path|None=None) -> dict:
    missing=sorted(CORE_FIELDS-set(pointer))
    if missing: raise PointerProtocolError('ACTIVE_POINTER_SCHEMA_DRIFT:'+','.join(missing))
    if pointer.get('ACTIVE_POINTER_FILE')!='APEX_GLOBAL_STATE_LATEST.txt':
        raise PointerProtocolError('ACTIVE_POINTER_IDENTITY_INVALID')
    if not isinstance(pointer.get('GLOBAL_PATCHES'),list): raise PointerProtocolError('ACTIVE_POINTER_GLOBAL_PATCHES_INVALID')
    schema=str(pointer.get('POINTER_SCHEMA_VERSION') or 'LEGACY_V0')
    if schema=='LEGACY_V0':
        if pointer.get('ACTIVE_POINTER_RESOLUTION') not in {'UNIQUE_EXACT_TITLE','UNIQUE_EXACT_TITLE_OBJECT_ID_FENCED'}:
            raise PointerProtocolError('ACTIVE_POINTER_NOT_UNIQUE:'+str(pointer.get('ACTIVE_POINTER_RESOLUTION')))
        return {'POINTER_PROTOCOL':'LEGACY_V0','POINTER_COMPATIBILITY':'PASS'}
    if schema!=POINTER_SCHEMA_V1: raise PointerProtocolError('UNSUPPORTED_POINTER_SCHEMA:'+schema)
    caps=set(map(str,pointer.get('POINTER_CAPABILITIES') or ()))
    required={CAP_OBJECT_FENCE,CAP_IMMUTABLE_BOOTSTRAP,CAP_CONTENT_STATE}
    if not required.issubset(caps): raise PointerProtocolError('POINTER_CAPABILITY_MISSING:'+','.join(sorted(required-caps)))
    if not pointer.get('ACTIVE_POINTER_FILE_ID') or int(pointer.get('POINTER_EPOCH',-1))<0:
        raise PointerProtocolError('POINTER_OBJECT_FENCE_METADATA_INVALID')
    bsha=str(pointer.get('BOOTSTRAP_SHA256') or '')
    if len(bsha)!=64: raise PointerProtocolError('BOOTSTRAP_SHA256_REQUIRED')
    if bootstrap_path is not None and sha256_file(bootstrap_path)!=bsha:
        raise PointerProtocolError('BOOTSTRAP_SELF_HASH_MISMATCH')
    digest=str(pointer.get('STATE_DIGEST') or '')
    expected='sha256:'+str(pointer.get('BUNDLE_SHA256'))
    state_digest_classification = 'PASS' if digest==expected else 'MISMATCH_NONBLOCKING'
    return {'POINTER_PROTOCOL':schema,'POINTER_COMPATIBILITY':'PASS','POINTER_CAPABILITIES':sorted(caps),'STATE_DIGEST':digest}

def build_v1_fields(*, bundle_sha256: str, bootstrap_sha256: str, capabilities=()) -> dict:
    caps={CAP_OBJECT_FENCE,CAP_IMMUTABLE_BOOTSTRAP,CAP_CONTENT_STATE,*map(str,capabilities)}
    return {'POINTER_SCHEMA_VERSION':POINTER_SCHEMA_V1,'POINTER_CAPABILITIES':sorted(caps),
            'BOOTSTRAP_SHA256':str(bootstrap_sha256),'STATE_DIGEST':'sha256:'+str(bundle_sha256)}
