from __future__ import annotations

"""Offline curriculum builder for the terminal Hybrid AI selector.

This module never participates in Phase 0/1/2, simulation, handoff, legality, or
candidate creation.  It turns resolved historical selector surfaces into
player-name-free ranking lessons so the AI can improve its one authorized job:
selecting five existing lineup IDs from a frozen selector-reviewed surface.
"""

from dataclasses import dataclass
from typing import Any, Mapping, Sequence
import math

PATCH_ID = "APEX_GLOBAL_HYBRID_SELECTOR_TOP01_INTELLIGENCE_TRAINING_v1"
OBJECTIVE = "MAXIMIZE_WINNER_AND_TOP_0_1_CAPTURE_AT_5"
AUTHORITY_STAGE = "OFFLINE_TRAINING_ONLY_AND_LIVE_LAST_STEP_REASONING_ONLY"

POSTLOCK_OUTCOME_FIELDS = frozenset({
    "CONTEST_RANK", "ACTUAL_RANK", "FINAL_CONTEST_RANK", "ACTUAL_FPTS",
    "REALIZED_FPTS", "POSTLOCK_SCORE", "REALIZED_SCORE", "ACTUAL_SCORE",
})

PLAYER_IDENTITY_FIELDS = frozenset({
    "CPT", "CAPTAIN", "MVP", "UTIL", "UTILS", "PLAYER_IDS", "PLAYERS",
    *(f"UTIL{i}" for i in range(1, 13)),
    *(f"PLAYER{i}" for i in range(1, 13)),
    *(f"P{i}_ID" for i in range(1, 13)),
})

SAFE_EXACT_FIELDS = frozenset({
    "LINEUP_ID", "LINEUP_INDEX", "BRANCH", "ROUTE", "CPT_ROLE", "SP_COUNT",
    "RP_COUNT", "SALARY", "SALARY_GEOMETRY", "SCENARIO_ID",
    "CURRENT_SELECTOR_SELECTED", "CURRENT_SELECTOR_RANK", "CURRENT_SELECTOR_SCORE",
    "GLOBAL_CORE_PROTECTED", "GLOBAL_CORE_PRIORITY",
})

SAFE_PREFIXES = (
    "AI_", "MC_", "BASE_MC_", "FAMILY_", "COMMON_WORLD_", "SAME_WORLD_",
    "WORLD_COVERAGE", "FAST_PATH_WORLD_", "TOTAL_RECURRENCE", "FAST_PATH_TOTAL_",
    "PROJECTED_EXACT_MATCH_DUPLICATION", "P_UNIQUE", "OWNERSHIP_PRODUCT",
    "FIELD_MODEL_RELIABILITY", "LINEUP_OVERLAP", "PAIRWISE_OUTCOME_CORRELATION",
)


class SelectorCurriculumError(RuntimeError):
    pass


def _lineup_id(row: Mapping[str, Any]) -> str:
    for key in ("LINEUP_ID", "LINEUP_INDEX", "ID"):
        value = row.get(key)
        if value not in (None, ""):
            return str(value)
    raise SelectorCurriculumError("CURRICULUM_ROW_MISSING_LINEUP_ID")


def _rank(outcome: Mapping[str, Any]) -> int:
    for key in ("CONTEST_RANK", "FINAL_CONTEST_RANK", "ACTUAL_RANK", "RANK"):
        value = outcome.get(key)
        if value not in (None, ""):
            try:
                rank = int(float(value))
            except Exception as exc:
                raise SelectorCurriculumError(f"CURRICULUM_BAD_CONTEST_RANK:{value}") from exc
            if rank < 1:
                raise SelectorCurriculumError(f"CURRICULUM_BAD_CONTEST_RANK:{rank}")
            return rank
    raise SelectorCurriculumError("CURRICULUM_OUTCOME_RANK_MISSING")


def top01_cutoff(field_size: int) -> int:
    if int(field_size) < 1:
        raise SelectorCurriculumError("CURRICULUM_FIELD_SIZE_INVALID")
    return max(1, math.ceil(int(field_size) * 0.001))


def top1_cutoff(field_size: int) -> int:
    if int(field_size) < 1:
        raise SelectorCurriculumError("CURRICULUM_FIELD_SIZE_INVALID")
    return max(1, math.ceil(int(field_size) * 0.01))


def relevance_grade(rank: int, field_size: int) -> int:
    """Graded target: rank1 > Top0.1 > Top1 > field.

    Winner is intentionally separated from the rest of Top-0.1 because the user's
    primary objective is exact winner/perfect capture, with Top-0.1 the minimum
    championship-region target.
    """
    r = int(rank)
    if r == 1:
        return 4
    if r <= top01_cutoff(field_size):
        return 3
    if r <= top1_cutoff(field_size):
        return 2
    return 0


def _safe_feature_row(row: Mapping[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {"LINEUP_ID": _lineup_id(row)}
    for key, value in row.items():
        ku = str(key).upper()
        if ku in POSTLOCK_OUTCOME_FIELDS or ku in PLAYER_IDENTITY_FIELDS:
            continue
        if ku in SAFE_EXACT_FIELDS or any(ku.startswith(prefix) for prefix in SAFE_PREFIXES):
            out[str(key)] = value
    return out


def build_listwise_training_rows(
    surface_rows: Sequence[Mapping[str, Any]],
    outcomes_by_lineup: Mapping[str, Mapping[str, Any]],
    *,
    field_size: int,
    sport: str,
    mode: str,
    slate_id: str,
) -> list[dict[str, Any]]:
    """Create player-name-free graded listwise records from a resolved slate."""
    if not surface_rows:
        raise SelectorCurriculumError("CURRICULUM_EMPTY_SELECTOR_SURFACE")
    ids: set[str] = set()
    rows: list[dict[str, Any]] = []
    for src in surface_rows:
        lid = _lineup_id(src)
        if lid in ids:
            raise SelectorCurriculumError(f"CURRICULUM_DUPLICATE_LINEUP_ID:{lid}")
        ids.add(lid)
        outcome = outcomes_by_lineup.get(lid)
        if outcome is None:
            continue
        rank = _rank(outcome)
        rec = _safe_feature_row(src)
        rec.update({
            "TRAINING_PATCH_ID": PATCH_ID,
            "SLATE_ID": str(slate_id),
            "SPORT": str(sport).upper(),
            "MODE": str(mode).upper(),
            "FIELD_SIZE": int(field_size),
            "TARGET_CONTEST_RANK": rank,
            "TARGET_RELEVANCE_GRADE": relevance_grade(rank, field_size),
            "TARGET_WINNER": rank == 1,
            "TARGET_TOP_0_1": rank <= top01_cutoff(field_size),
            "TARGET_TOP_1": rank <= top1_cutoff(field_size),
        })
        rows.append(rec)
    if not rows:
        raise SelectorCurriculumError("CURRICULUM_NO_MATCHED_RESOLVED_ROWS")
    return rows


def _selector_rank(row: Mapping[str, Any]) -> float:
    value = row.get("CURRENT_SELECTOR_RANK")
    try:
        v = float(value)
        if math.isfinite(v) and v > 0:
            return v
    except Exception:
        pass
    score = row.get("CURRENT_SELECTOR_SCORE")
    try:
        s = float(score)
        if math.isfinite(s):
            return -s
    except Exception:
        pass
    return float("inf")


def mine_hard_negative_pairs(
    training_rows: Sequence[Mapping[str, Any]],
    *,
    max_negatives_per_positive: int = 8,
) -> list[dict[str, Any]]:
    """Mine preference pairs where a coded-selector favorite lost to Top-0.1 truth.

    Positives are winner/Top-0.1 rows.  Hard negatives are non-Top-0.1 rows that
    the coded selector ranked ahead of the positive or explicitly selected.
    """
    positives = [dict(r) for r in training_rows if int(r.get("TARGET_RELEVANCE_GRADE", 0)) >= 3]
    negatives = [dict(r) for r in training_rows if int(r.get("TARGET_RELEVANCE_GRADE", 0)) < 3]
    pairs: list[dict[str, Any]] = []
    for pos in positives:
        pr = _selector_rank(pos)
        hard = []
        for neg in negatives:
            nr = _selector_rank(neg)
            selected = str(neg.get("CURRENT_SELECTOR_SELECTED", "")).strip().lower() in {"1", "true", "yes", "y"}
            if selected or nr < pr:
                hard.append((0 if selected else 1, nr, neg))
        hard.sort(key=lambda x: (x[0], x[1], str(x[2].get("LINEUP_ID", ""))))
        for _, _, neg in hard[: max(0, int(max_negatives_per_positive))]:
            pairs.append({
                "TRAINING_PATCH_ID": PATCH_ID,
                "SLATE_ID": pos.get("SLATE_ID"),
                "SPORT": pos.get("SPORT"),
                "MODE": pos.get("MODE"),
                "PREFERRED_LINEUP_ID": str(pos.get("LINEUP_ID")),
                "REJECTED_LINEUP_ID": str(neg.get("LINEUP_ID")),
                "PREFERRED_GRADE": int(pos.get("TARGET_RELEVANCE_GRADE", 0)),
                "REJECTED_GRADE": int(neg.get("TARGET_RELEVANCE_GRADE", 0)),
                "PREFERRED_CONTEST_RANK": int(pos.get("TARGET_CONTEST_RANK", 0)),
                "REJECTED_CONTEST_RANK": int(neg.get("TARGET_CONTEST_RANK", 0)),
                "HARD_NEGATIVE_REASON": "CODE_SELECTOR_OUTRANKED_CHAMPIONSHIP_ROW",
            })
    return pairs


def evaluate_top5_decision(
    selected_lineup_ids: Sequence[str],
    outcomes_by_lineup: Mapping[str, Mapping[str, Any]],
    *,
    field_size: int,
) -> dict[str, Any]:
    ids = [str(x) for x in selected_lineup_ids]
    if len(ids) != 5 or len(set(ids)) != 5:
        raise SelectorCurriculumError("CURRICULUM_TOP5_DECISION_INVALID")
    ranks = []
    for lid in ids:
        outcome = outcomes_by_lineup.get(lid)
        if outcome is not None:
            ranks.append(_rank(outcome))
    return {
        "PATCH_ID": PATCH_ID,
        "OBJECTIVE": OBJECTIVE,
        "FINAL_BOARD_SIZE": 5,
        "MATCHED_OUTCOMES": len(ranks),
        "WINNER_CAPTURE_AT_5": any(r == 1 for r in ranks),
        "TOP_0_1_CAPTURE_AT_5": any(r <= top01_cutoff(field_size) for r in ranks),
        "TOP_1_CAPTURE_AT_5": any(r <= top1_cutoff(field_size) for r in ranks),
        "BEST_CONTEST_RANK_AT_5": min(ranks) if ranks else None,
    }


def curriculum_contract() -> dict[str, Any]:
    return {
        "PATCH_ID": PATCH_ID,
        "OBJECTIVE": OBJECTIVE,
        "AUTHORITY_STAGE": AUTHORITY_STAGE,
        "LIVE_AI_ROLE": "HYBRID_SELECTOR_REASONING_LAST_STEP_ONLY",
        "ENGINE_UPSTREAM_AUTHORITY": True,
        "AI_UPSTREAM_AUTHORITY": False,
        "PLAYER_NAME_MEMORIZATION": False,
        "HISTORICAL_OUTCOMES_FORWARD_INPUT": False,
        "TRAINING_FORMS": [
            "BLIND_LISTWISE_REPLAY",
            "GRADED_WINNER_TOP01_TOP1_LABELS",
            "HARD_NEGATIVE_MINING",
            "PAIRWISE_PREFERENCE_LESSONS",
            "WALK_FORWARD_EVALUATION",
        ],
        "PROMOTION_METRICS": [
            "WINNER_CAPTURE_AT_5",
            "TOP_0_1_CAPTURE_AT_5",
            "BEST_CONTEST_RANK_AT_5",
            "AVAILABLE_TOP_0_1_TO_SELECTED_TOP_0_1_GAP",
        ],
    }
