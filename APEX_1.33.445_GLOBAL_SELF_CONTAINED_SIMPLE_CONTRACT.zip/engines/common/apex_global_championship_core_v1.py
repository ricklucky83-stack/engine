from __future__ import annotations

"""Global APEX championship-core portfolio selector.

This layer is intentionally sport-agnostic. Sport engines remain responsible for
candidate birth, legality, simulation, and sport-native family/scenario logic.
The global production runner applies this final playable-board contract:

1) treat the five-lineup core as one coordinated high-confidence parlay;
2) maximize joint championship-state coverage rather than five independent ranks;
3) permit bounded concentration inside a high-confidence one-swap family;
4) reserve remaining seats for strong alternate/counter-script or protected scenarios;
5) never use post-lock contest results in selection;
6) satellites are disabled by default and may only be appended explicitly.
"""

from dataclasses import dataclass
from typing import Any, Iterable
import math
import re

try:
    from engines.common.apex_global_championship_family_adapter_v1 import describe_rows as _describe_family_rows, PATCH_ID as FAMILY_ADAPTER_PATCH_ID
    from engines.common import apex_field_relative_extreme_value_portfolio_v2 as _extreme_selector
    from engines.common import apex_global_championship_head_policy_v1 as _head_policy
except Exception:
    # Direct-file test/import path fallback.
    import importlib.util as _ilu
    from pathlib import Path as _Path
    _ap = _Path(__file__).with_name("apex_global_championship_family_adapter_v1.py")
    import sys as _sys
    _sp = _ilu.spec_from_file_location("apex_global_championship_family_adapter_v1", _ap)
    _am = _ilu.module_from_spec(_sp)
    _sys.modules[_sp.name] = _am
    _sp.loader.exec_module(_am)
    _describe_family_rows = _am.describe_rows
    FAMILY_ADAPTER_PATCH_ID = _am.PATCH_ID
    _ep = _Path(__file__).with_name("apex_field_relative_extreme_value_portfolio_v2.py")
    _esp = _ilu.spec_from_file_location("apex_field_relative_extreme_value_portfolio_v2", _ep)
    _extreme_selector = _ilu.module_from_spec(_esp)
    _sys.modules[_esp.name] = _extreme_selector
    _esp.loader.exec_module(_extreme_selector)
    _hp = _Path(__file__).with_name("apex_global_championship_head_policy_v1.py")
    _hsp = _ilu.spec_from_file_location("apex_global_championship_head_policy_v1", _hp)
    _head_policy = _ilu.module_from_spec(_hsp)
    _sys.modules[_hsp.name] = _head_policy
    _hsp.loader.exec_module(_head_policy)

PATCH_ID = "APEX_GLOBAL_CHAMPIONSHIP_CORE_5_v1"
TOP5_PARLAY_POLICY_ID = "APEX_GLOBAL_TOP5_HIGH_CONFIDENCE_PARLAY_v1"
CORE_SIZE = 5
DOMINANT_FAMILY_MAX = CORE_SIZE
NFL_SHOWDOWN_DOMINANT_FAMILY_MAX = 3
DEFAULT_SATELLITES_ENABLED = False
MAX_SATELLITES = 5
NFL_SHOWDOWN_DOMINANT_FAMILY_HARD_CAP_PATCH_ID = "NFL_SHOWDOWN_GLOBAL_CORE5_TERMINAL_AND_DOMINANT_FAMILY_CAP_v1"
CFB_CLASSIC_NATIVE_ORDER_PARITY_PATCH_ID = "CFB_CLASSIC_GLOBAL_CORE_NATIVE_AUTHORITY_PARITY_v1"
FORBIDDEN_FORWARD_FIELDS = {
    "CONTEST_RANK", "ACTUAL_FPTS", "REALIZED_FPTS", "POSTLOCK_SCORE",
    "WINNING_LINEUP", "TARGET_ACTUAL_SCORE", "FINAL_CONTEST_RANK",
}


class ChampionshipCoreError(RuntimeError):
    pass


def _norm_key(x: Any) -> str:
    return str(x or "").strip().upper().replace(" ", "_").replace("-", "_")


def _num(x: Any, default: float = float("nan")) -> float:
    try:
        if isinstance(x, str):
            x = x.replace("%", "").replace("$", "").replace(",", "").strip()
        y = float(x)
        return y if math.isfinite(y) else default
    except Exception:
        return default


def _flatten_players(row: dict[str, Any]) -> tuple[str, ...]:
    vals: list[str] = []
    # Ordered explicit roster keys first.
    for key in ("CPT", "CAPTAIN", "MVP"):
        v = row.get(key)
        if v not in (None, "", []):
            vals.append(str(v).strip())
            break
    for key in ("UTIL", "UTILS", "PLAYERS", "PLAYER_LIST", "LINEUP_PLAYERS"):
        v = row.get(key)
        if v in (None, "", []):
            continue
        if isinstance(v, (list, tuple, set)):
            vals.extend(str(x).strip() for x in v if str(x).strip())
        else:
            text = str(v).strip()
            if "|" in text:
                vals.extend(x.strip() for x in text.split("|") if x.strip())
            elif ";" in text:
                vals.extend(x.strip() for x in text.split(";") if x.strip())
            elif "," in text and key != "LINEUP_PLAYERS":
                vals.extend(x.strip() for x in text.split(",") if x.strip())
            elif text:
                vals.append(text)
        if vals:
            break
    # Generic sport-agnostic roster slots as fallback.  Be deliberately strict:
    # metric columns such as P95/P99 must never be interpreted as players.
    if len(vals) <= 1:
        exact_slots = {
            "C", "1B", "2B", "3B", "SS",
            "QB", "TE", "DST", "K", "D", "UTIL", "FLEX",
            "PG", "SG", "SF", "PF", "CEN",
        }

        def is_roster_slot(u: str) -> bool:
            if u in exact_slots:
                return True
            m = re.fullmatch(r"(P|G|F|OF|RB|WR|SP|RP|PG|SG|SF|PF|UTIL|FLEX|FIGHTER)(\d+)", u)
            if not m:
                return False
            # Roster multiplicities are small.  This bound rejects percentile
            # metrics P95/P99 and other numbered telemetry without sport logic.
            return 1 <= int(m.group(2)) <= 12

        slot_keys = []
        for k in row:
            u = _norm_key(k)
            if u in {"CPT", "CAPTAIN", "MVP"}:
                continue
            if is_roster_slot(u):
                slot_keys.append(k)
        # Preserve source-column order because engines already render roster slots
        # in canonical order; overlap itself remains order-insensitive.
        for k in slot_keys:
            v = row.get(k)
            if v not in (None, ""):
                vals.append(str(v).strip())
    # Last-resort lineup string; this is only used if it looks delimited.
    if not vals:
        text = str(row.get("LINEUP", "")).strip()
        for sep in ("|", ";", ","):
            if sep in text:
                vals = [x.strip() for x in text.split(sep) if x.strip()]
                break
    # Stable de-duplication, preserving roster order.
    out: list[str] = []
    seen: set[str] = set()
    for x in vals:
        k = x.casefold()
        if x and k not in seen:
            out.append(x); seen.add(k)
    return tuple(out)


def _metric(row: dict[str, Any], *names: str) -> float:
    cmap = {_norm_key(k): k for k in row}
    for name in names:
        k = cmap.get(_norm_key(name))
        if k is not None:
            v = _num(row.get(k))
            if math.isfinite(v):
                return v
    return float("nan")


def _rank_confidence(position: int) -> float:
    # Existing engine order remains evidence, but its influence decays fast enough
    # for a dense championship family to pull lower-ranked siblings into Core-5.
    return math.exp(-0.24 * max(0, position))


def _confidence(row: dict[str, Any], position: int) -> float:
    # Prefer forward extreme-tail metrics when engines expose them. Values may be
    # probabilities or percentiles; rank normalization happens across the board.
    parts = []
    field_size=_metric(row,"FIELD_SIZE","CONTEST_SIZE","ENTRIES")
    large=math.isfinite(field_size) and field_size >= _head_policy.LARGE_CONTEST_MIN_FIELD_SIZE
    metric_plan = [
        (("MC_TOP_0_0050_RATE","TOP_0_0050_RATE","TOP0050_RATE"),0.36),
        (("MC_TOP_0_0100_RATE","TOP_0_0100_RATE","TOP0100_RATE"),0.18),
        (("MC_WIN_RATE", "WIN_RATE", "WIN_PROB"), 0.20),
        (("P99", "MC_P99", "CVAR99"), 0.16),
        (("SELECTOR_SCORE", "OBJECTIVE", "SCORE"), 0.10),
    ] if large else [
        (("MC_WIN_RATE", "WIN_RATE", "WIN_PROB"), 0.40),
        (("MC_TOP_0_1_RATE", "TOP_0_1_RATE", "TOP01_RATE"), 0.28),
        (("P99", "MC_P99", "CVAR99"), 0.18),
        (("SELECTOR_SCORE", "OBJECTIVE", "SCORE"), 0.14),
    ]
    for names, weight in metric_plan:
        v = _metric(row, *names)
        if math.isfinite(v):
            parts.append((v, weight))
    # Metrics are heterogeneous across sports, so raw magnitudes are only a mild
    # bonus here; engine order stays the common comparable prior.
    prior = _rank_confidence(position)
    if not parts:
        return prior
    signal = sum(w * math.tanh(abs(v)) for v, w in parts) / max(1e-12, sum(w for _, w in parts))
    return 0.78 * prior + 0.22 * max(0.0, signal)


def _overlap(a: tuple[str, ...], b: tuple[str, ...]) -> int:
    return len({x.casefold() for x in a} & {x.casefold() for x in b})


def _family_threshold(a: tuple[str, ...], b: tuple[str, ...]) -> int:
    n = min(len(a), len(b))
    if n <= 2:
        return n
    return max(2, n - 1)  # one-swap sibling family


def _components(players: list[tuple[str, ...]]) -> list[list[int]]:
    """Exact one-swap connected components with linear signature indexing for fixed roster sizes."""
    n=len(players)
    canon=[tuple(sorted({str(x).casefold() for x in p if str(x).strip()})) for p in players]
    sizes={len(p) for p in canon if p}
    if len(sizes)==1 and next(iter(sizes),0)>=3:
        k=next(iter(sizes)); parent=list(range(n)); rank=[0]*n
        def find(x):
            while parent[x]!=x:
                parent[x]=parent[parent[x]]; x=parent[x]
            return x
        def union(a,b):
            a=find(a); b=find(b)
            if a==b:return
            if rank[a]<rank[b]: a,b=b,a
            parent[b]=a
            if rank[a]==rank[b]: rank[a]+=1
        sig_owner={}
        for i,p in enumerate(canon):
            if len(p)!=k: continue
            for drop in range(k):
                sig=p[:drop]+p[drop+1:]
                j=sig_owner.setdefault(sig,i)
                if j!=i: union(i,j)
        groups={}
        for i in range(n): groups.setdefault(find(i),[]).append(i)
        comps=[sorted(v) for v in groups.values()]
        comps.sort(key=lambda v:v[0])
        return comps
    # Variable-size schemas retain the exact legacy relation.
    adj=[[] for _ in range(n)]
    for i in range(n):
        if not players[i]: continue
        for j in range(i+1,n):
            if not players[j]: continue
            if _overlap(players[i],players[j]) >= _family_threshold(players[i],players[j]):
                adj[i].append(j); adj[j].append(i)
    seen=set(); comps=[]
    for i in range(n):
        if i in seen: continue
        stack=[i]; seen.add(i); comp=[]
        while stack:
            x=stack.pop(); comp.append(x)
            for y in adj[x]:
                if y not in seen: seen.add(y); stack.append(y)
        comps.append(sorted(comp))
    return comps

def _component_mass(comp: list[int], confidence: list[float]) -> float:
    # Saturation is evidence, but sqrt damping prevents a large mediocre family
    # from winning solely by count.
    vals = sorted((confidence[i] for i in comp), reverse=True)
    return sum(v / math.sqrt(k + 1.0) for k, v in enumerate(vals))


def _max_similarity(i: int, selected: Iterable[int], players: list[tuple[str, ...]]) -> float:
    best = 0.0
    for j in selected:
        denom = max(1, min(len(players[i]), len(players[j])))
        best = max(best, _overlap(players[i], players[j]) / denom)
    return best


def _nfl_showdown_dominant_family_hard_cap(sport: str, mode: str) -> bool:
    s = _norm_key(sport)
    m = _norm_key(mode)
    return s == "NFL" and m in {"SHOWDOWN", "SD", "SHOWDOWN_CAPTAIN", "CAPTAIN", "CPT"}


@dataclass(frozen=True)
class CoreSelection:
    rows: list[dict[str, Any]]
    source_indices: list[int]
    receipt: dict[str, Any]


def select_championship_core(
    rows: list[dict[str, Any]], *, sport: str, mode: str, core_size: int = CORE_SIZE,
    satellites_enabled: bool = DEFAULT_SATELLITES_ENABLED, max_satellites: int = MAX_SATELLITES,
) -> CoreSelection:
    if not isinstance(rows, list) or not rows:
        raise ChampionshipCoreError("RUN_INVALID:GLOBAL_CHAMPIONSHIP_CORE_EMPTY_BOARD")
    forbidden = sorted({ _norm_key(k) for row in rows for k in row } & FORBIDDEN_FORWARD_FIELDS)
    if forbidden:
        raise ChampionshipCoreError("RUN_INVALID:POSTLOCK_FIELDS_ENTERED_GLOBAL_CHAMPIONSHIP_CORE:" + ",".join(forbidden))
    target = min(max(1, int(core_size)), len(rows))
    players = [_flatten_players(r) for r in rows]
    confidence = [_confidence(r, i) for i, r in enumerate(rows)]
    family_desc = _describe_family_rows(rows, sport=sport, mode=mode)
    comps = _components(players)
    comp_mass = [_component_mass(c, confidence) for c in comps]
    comp_order = sorted(range(len(comps)), key=lambda c: (-comp_mass[c], min(comps[c])))
    dominant = comps[comp_order[0]] if comp_order else [0]
    nfl_sd_cap = NFL_SHOWDOWN_DOMINANT_FAMILY_MAX if _nfl_showdown_dominant_family_hard_cap(sport, mode) else target

    selected: list[int] = []
    extreme_receipt = None

    # 0) Resolve sport-native pre-lock protection metadata before either selector
    # path. Protected lanes remain authoritative under the field-relative upgrade.
    protected_groups: dict[str, list[int]] = {}
    protected_priority: dict[int, float] = {}
    for i, d in enumerate(family_desc):
        if d.protected:
            key = d.family_id or d.scenario_id or f"PROTECTED_{i}"
            protected_groups.setdefault(key, []).append(i)
            protected_priority[i] = float(d.protection_priority)
    protected_indices = [i for _, members in sorted(
        protected_groups.items(),
        key=lambda kv: (-max(family_desc[i].protection_priority for i in kv[1]), min(kv[1])),
    ) for i in sorted(members)]

    # Production upgrade v2: when forward field-relative tail metrics are exported
    # by the sport runtime, the terminal Core-5 is selected by the uncertainty-aware mispriced-ceiling extreme-value portfolio selector. Rows without those metrics retain
    # the proven legacy family selector unchanged.
    if _extreme_selector.has_sufficient_field_relative_metrics(rows):
        evsel = _extreme_selector.select_portfolio_rows(
            rows,
            players=players,
            board_size=target,
            protected_indices=protected_indices,
            protected_priority=protected_priority,
            dominant_family_max=nfl_sd_cap,
        )
        selected = list(evsel.source_indices)
        extreme_receipt = evsel.receipt
    else:
        protected_order = sorted(
            protected_groups.items(),
            key=lambda kv: (-max(family_desc[i].protection_priority for i in kv[1]), min(kv[1])),
        )
        for _, members in protected_order:
            if len(selected) >= target:
                break
            cap = min(target - len(selected), max(family_desc[i].protection_family_cap for i in members))
            # Source selector inclusion is itself evidence for protected lanes; preserve
            # the lane bunch in stable source order rather than re-sorting it by mean MC.
            for i in sorted(members)[:cap]:
                if i not in selected:
                    selected.append(i)

        # 1) Press the strongest spike-together family through the championship
        # head when forward evidence supports it.  A generic family cap is not a
        # valid reason to eject a stronger Top-5 sibling.
        dominant_sorted = sorted(dominant, key=lambda i: (-confidence[i], i))
        for i in dominant_sorted:
            if len(selected) >= target:
                break
            if i not in selected:
                if sum(1 for j in selected if j in dominant) >= nfl_sd_cap:
                    break
                selected.append(i)

        # 2) Fill remaining seats by confidence while respecting the NFL Showdown
        # one-swap-family cap when alternatives exist.
        while len(selected) < target:
            pool = [i for i in range(len(rows)) if i not in selected]
            if not pool:
                break
            dom_count=sum(1 for j in selected if j in dominant)
            if dom_count >= nfl_sd_cap:
                alt=[i for i in pool if i not in dominant]
                if alt:
                    pool=alt
            selected.append(max(pool, key=lambda i: (confidence[i], -i)))

    # Core membership freezes here.  CFB Classic has its own native terminal
    # ordinal layer; the global layer may choose membership but must not invent a
    # second ordering authority after that native board has been sealed.
    core = selected[:target]
    cfb_classic_native_order_parity = _norm_key(sport) == "CFB" and _norm_key(mode) == "CLASSIC"
    if cfb_classic_native_order_parity:
        core = sorted(core)
    satellites: list[int] = []
    if satellites_enabled and len(rows) > target:
        remaining = [i for i in range(len(rows)) if i not in core]
        for i in sorted(remaining, key=lambda j: (-confidence[j], j)):
            if len(satellites) >= max(0, int(max_satellites)):
                break
            sim = _max_similarity(i, core + satellites, players)
            marginal = confidence[i] * (1.0 - sim)
            # Explicitly positive, non-trivial new championship-state coverage.
            if marginal >= 0.12:
                satellites.append(i)

    final_indices = core + satellites
    final_rows = [rows[i] for i in final_indices]
    comp_receipt = []
    for rank, cidx in enumerate(comp_order, 1):
        comp_receipt.append({
            "FAMILY_RANK": rank,
            "SOURCE_INDICES": [i + 1 for i in comps[cidx]],
            "FAMILY_SIZE": len(comps[cidx]),
            "FAMILY_MASS": round(comp_mass[cidx], 8),
        })
    receipt = {
        "PATCH_ID": PATCH_ID,
        "SPORT": str(sport).upper(),
        "MODE": str(mode).upper(),
        "SOURCE_BOARD_SIZE": len(rows),
        "CORE_SIZE": len(core),
        "CORE_SOURCE_INDICES": [i + 1 for i in core],
        "SATELLITES_ENABLED": bool(satellites_enabled),
        "SATELLITE_SOURCE_INDICES": [i + 1 for i in satellites],
        "FINAL_PLAYABLE_BOARD_SIZE": len(final_rows),
        "DOMINANT_FAMILY_MAX": nfl_sd_cap,
        "CHAMPIONSHIP_HEAD_POLICY_ID": _head_policy.PATCH_ID,
        "TOP5_IS_CHAMPIONSHIP_NEIGHBORHOOD": True,
        "DIVERSIFICATION_APPLIED_INSIDE_HEAD": False,
        "DIVERSIFICATION_START_SEAT": _head_policy.DIVERSIFICATION_START_SEAT,
        "DOMINANT_FAMILY_SOURCE_INDICES": [i + 1 for i in dominant],
        "FAMILY_LEDGER": comp_receipt,
        "FAMILY_ADAPTER_PATCH_ID": FAMILY_ADAPTER_PATCH_ID,
        "FIELD_RELATIVE_EXTREME_VALUE_SELECTOR_PATCH_ID": _extreme_selector.PATCH_ID,
        "FIELD_RELATIVE_EXTREME_VALUE_SELECTOR_ACTIVE": extreme_receipt is not None,
        "FIELD_RELATIVE_EXTREME_VALUE_SELECTOR": extreme_receipt,
        "PROTECTED_SOURCE_INDICES": [i + 1 for i, d in enumerate(family_desc) if d.protected],
        "PROTECTED_REASONS": [family_desc[i].reason for i in final_indices if family_desc[i].protected],
        "POSTLOCK_RESULTS_USED": False,
        "PLAYER_NAME_CONSTANTS_USED": False,
        "CORE_FROZEN_BEFORE_SATELLITES": True,
        "TOP5_PARLAY_POLICY_ID": TOP5_PARLAY_POLICY_ID,
        "TOP5_PORTFOLIO_OBJECTIVE": "HIGH_CONFIDENCE_PARLAY_JOINT_CHAMPIONSHIP_COVERAGE",
        "FIVE_INDEPENDENT_RANKS_OBJECTIVE": False,
        "CORRELATED_SIBLING_CONCENTRATION_ALLOWED": True,
        "COUNTER_SCRIPT_COVERAGE_USED": False,
        "NFL_SHOWDOWN_DOMINANT_FAMILY_HARD_CAP_ENFORCED": _nfl_showdown_dominant_family_hard_cap(sport, mode),
        "NFL_SHOWDOWN_DOMINANT_FAMILY_HARD_CAP_PATCH_ID": NFL_SHOWDOWN_DOMINANT_FAMILY_HARD_CAP_PATCH_ID if _nfl_showdown_dominant_family_hard_cap(sport, mode) else None,
        "NFL_SHOWDOWN_DOMINANT_FAMILY_HARD_CAP_SUPERSEDED_BY": None,
        "DOMINANT_FAMILY_SELECTED_COUNT": sum(1 for i in core if i in dominant),
        "CFB_CLASSIC_NATIVE_ORDER_PARITY": bool(cfb_classic_native_order_parity),
        "CFB_CLASSIC_NATIVE_ORDER_PARITY_PATCH_ID": CFB_CLASSIC_NATIVE_ORDER_PARITY_PATCH_ID if cfb_classic_native_order_parity else None,
        "CFB_CLASSIC_GLOBAL_MEMBERSHIP_FROZEN_BEFORE_NATIVE_ORDER_RESTORE": bool(cfb_classic_native_order_parity),
    }
    return CoreSelection(final_rows, final_indices, receipt)
