from __future__ import annotations
import hashlib, json
from pathlib import Path

PROTOCOL_ID = "APEX_GLOBAL_CONCURRENT_DIAGNOSTIC_MERGE_REBASE_v1"

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def capture_pointer(path: str | Path) -> dict:
    p=Path(path); b=p.read_bytes(); obj=json.loads(b.decode("utf-8"))
    return {"PROTOCOL_ID":PROTOCOL_ID,"POINTER_BYTES_SHA256":sha256_bytes(b),"STATE_VERSION":obj.get("STATE_VERSION"),"BUNDLE_FILE_ID":obj.get("BUNDLE_FILE_ID"),"BUNDLE_SHA256":obj.get("BUNDLE_SHA256"),"POINTER_BYTES":len(b)}

def assert_parent_unchanged(path: str | Path, expected_pointer_sha256: str) -> dict:
    got=capture_pointer(path)
    if got["POINTER_BYTES_SHA256"] != expected_pointer_sha256:
        raise RuntimeError(f"ACTIVE_POINTER_DRIFT_REBASE_REQUIRED:{got['POINTER_BYTES_SHA256']}:{expected_pointer_sha256}")
    got["PARENT_POINTER_MATCH"]="PASS"
    return got

def assert_unique_version(candidate_version: str, existing_versions: list[str]) -> None:
    if candidate_version in set(existing_versions):
        raise RuntimeError(f"DUPLICATE_STATE_VERSION_PROHIBITED:{candidate_version}")
