from __future__ import annotations

from dataclasses import dataclass
from math import ceil
from typing import Iterable, Sequence

import numpy as np

PATCH_ID = "APEX_GLOBAL_ORDINAL_SELECTOR_CALIBRATION_AND_RANK1_ANCHOR_v1"
POSTLOCK_ONLY = True

DEFAULT_SELECTOR_SURFACES = (1, 3, 10, 20, 50, 75, 100, 150)
DEFAULT_CONTEST_PERCENTILES = (0.001, 0.01, 0.02, 0.05, 0.10, 0.20)


class PercentileCaptureIntegrityError(RuntimeError):
    pass


@dataclass(frozen=True)
class CaptureCell:
    selector_surface: int
    contest_percentile: float
    selector_rows_evaluated: int
    hit_count: int
    hit_rate: float
    contest_rank_cutoff: int


def _validate(selector_order: np.ndarray, realized_rank: np.ndarray, field_size: int) -> None:
    if field_size <= 0:
        raise PercentileCaptureIntegrityError("FIELD_SIZE_MUST_BE_POSITIVE")
    if selector_order.ndim != 1 or realized_rank.ndim != 1:
        raise PercentileCaptureIntegrityError("ORDER_AND_RANK_MUST_BE_1D")
    if selector_order.size != realized_rank.size:
        raise PercentileCaptureIntegrityError("ORDER_RANK_LENGTH_MISMATCH")
    if selector_order.size == 0:
        raise PercentileCaptureIntegrityError("EMPTY_SELECTOR_UNIVERSE")
    if len(set(map(int, selector_order))) != selector_order.size:
        raise PercentileCaptureIntegrityError("DUPLICATE_SELECTOR_ORDER_INDEX")
    if int(selector_order.min()) < 0 or int(selector_order.max()) >= selector_order.size:
        raise PercentileCaptureIntegrityError("SELECTOR_ORDER_INDEX_OUT_OF_RANGE")
    finite = np.isfinite(realized_rank)
    if np.any(realized_rank[finite] < 1):
        raise PercentileCaptureIntegrityError("REALIZED_RANK_BELOW_ONE")


def percentile_capture_grid(
    selector_order: Sequence[int] | np.ndarray,
    realized_rank: Sequence[float] | np.ndarray,
    *,
    field_size: int,
    selector_surfaces: Iterable[int] = DEFAULT_SELECTOR_SURFACES,
    contest_percentiles: Iterable[float] = DEFAULT_CONTEST_PERCENTILES,
) -> list[CaptureCell]:
    """Post-lock-only calibration matrix for a frozen prelock selector order.

    `realized_rank[i]` is the actual contest rank for lineup i when exact field match is
    available, or a virtual-if-played rank under the existing post-lock doctrine.
    Results are never inputs to live selection.
    """
    order = np.asarray(selector_order, dtype=np.int64)
    ranks = np.asarray(realized_rank, dtype=np.float64)
    _validate(order, ranks, int(field_size))

    cells: list[CaptureCell] = []
    for raw_k in selector_surfaces:
        k = int(raw_k)
        if k <= 0:
            raise PercentileCaptureIntegrityError("SELECTOR_SURFACE_MUST_BE_POSITIVE")
        n = min(k, order.size)
        surface_ranks = ranks[order[:n]]
        for raw_p in contest_percentiles:
            p = float(raw_p)
            if not (0.0 < p <= 1.0):
                raise PercentileCaptureIntegrityError("CONTEST_PERCENTILE_OUT_OF_RANGE")
            cutoff = max(1, int(ceil(field_size * p)))
            valid = np.isfinite(surface_ranks)
            hits = int(np.count_nonzero(valid & (surface_ranks <= cutoff)))
            cells.append(CaptureCell(k, p, n, hits, hits / float(n), cutoff))
    return cells


def board_percentile_ladder(
    board_indices: Sequence[int] | np.ndarray,
    realized_rank: Sequence[float] | np.ndarray,
    *,
    field_size: int,
    contest_percentiles: Iterable[float] = DEFAULT_CONTEST_PERCENTILES,
) -> list[dict[str, float | int]]:
    board = np.asarray(board_indices, dtype=np.int64)
    ranks = np.asarray(realized_rank, dtype=np.float64)
    if board.ndim != 1 or ranks.ndim != 1 or board.size == 0:
        raise PercentileCaptureIntegrityError("INVALID_BOARD_OR_RANK_VECTOR")
    if int(board.min()) < 0 or int(board.max()) >= ranks.size:
        raise PercentileCaptureIntegrityError("BOARD_INDEX_OUT_OF_RANGE")
    out: list[dict[str, float | int]] = []
    board_ranks = ranks[board]
    for raw_p in contest_percentiles:
        p = float(raw_p)
        cutoff = max(1, int(ceil(field_size * p)))
        valid = np.isfinite(board_ranks)
        hits = int(np.count_nonzero(valid & (board_ranks <= cutoff)))
        out.append({
            "CONTEST_PERCENTILE": p,
            "RANK_CUTOFF": cutoff,
            "BOARD_SIZE": int(board.size),
            "HIT_COUNT": hits,
            "HIT_RATE": hits / float(board.size),
        })
    return out


def monotone_selector_quality_summary(cells: Sequence[CaptureCell], *, contest_percentile: float) -> dict[str, object]:
    selected = [c for c in cells if abs(c.contest_percentile - contest_percentile) < 1e-12]
    selected.sort(key=lambda c: c.selector_surface)
    if not selected:
        raise PercentileCaptureIntegrityError("NO_CAPTURE_CELLS_FOR_PERCENTILE")
    # Cumulative hit count should be nondecreasing as the selector surface expands.
    hit_counts = [c.hit_count for c in selected]
    return {
        "CONTEST_PERCENTILE": float(contest_percentile),
        "SURFACES": [c.selector_surface for c in selected],
        "HIT_COUNTS": hit_counts,
        "CUMULATIVE_HIT_COUNT_MONOTONE": all(b >= a for a, b in zip(hit_counts, hit_counts[1:])),
        "BEST_HIT_RATE": max(c.hit_rate for c in selected),
    }
