from __future__ import annotations

import hashlib
from typing import Dict, NamedTuple

import numpy as np

PATCH_ID = "APEX_PHASE1_CALIBRATION_FREEZE_HASH_CHAIN_v1"


def ndarray_sha256(matrix: np.ndarray) -> str:
    """Canonical byte hash for an in-memory calibration matrix."""
    arr = np.ascontiguousarray(np.asarray(matrix))
    return hashlib.sha256(arr.tobytes(order="C")).hexdigest()


class CalibrationSeal(NamedTuple):
    sha256: str
    shape: tuple[int, ...]
    dtype: str


def freeze_calibration(matrix: np.ndarray) -> CalibrationSeal:
    """Freeze one run's Phase-1 calibration matrix against in-place mutation."""
    if not isinstance(matrix, np.ndarray):
        raise RuntimeError("ENGINE_INTEGRITY_HALT:PHASE1_CALIBRATION_NOT_NDARRAY")
    seal = CalibrationSeal(
        sha256=ndarray_sha256(matrix),
        shape=tuple(int(v) for v in matrix.shape),
        dtype=str(matrix.dtype),
    )
    matrix.flags.writeable = False
    return seal


def assert_calibration_unchanged(
    matrix: np.ndarray,
    seal: CalibrationSeal,
    stage: str,
    chain: Dict[str, str] | None = None,
) -> str:
    """Fail closed if any downstream stage sees a different Phase-1 calibration."""
    stage = str(stage).strip().upper()
    if tuple(int(v) for v in matrix.shape) != seal.shape or str(matrix.dtype) != seal.dtype:
        raise RuntimeError(f"ENGINE_INTEGRITY_HALT:CALIBRATION_SHAPE_OR_DTYPE_MUTATION:{stage}")
    current = ndarray_sha256(matrix)
    if current != seal.sha256:
        raise RuntimeError(
            f"ENGINE_INTEGRITY_HALT:CALIBRATION_MUTATION_DETECTED:{stage}:"
            f"EXPECTED={seal.sha256}:ACTUAL={current}"
        )
    if chain is not None:
        chain[stage] = current
    return current


def hash_chain_parity(chain: Dict[str, str], expected: str) -> bool:
    return bool(chain) and all(str(v) == str(expected) for v in chain.values())
