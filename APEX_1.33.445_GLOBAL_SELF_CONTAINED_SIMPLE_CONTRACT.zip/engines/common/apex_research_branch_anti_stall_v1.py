from __future__ import annotations
import hashlib, json
from dataclasses import dataclass, field
from typing import Any
PATCH_ID="APEX_GLOBAL_RESEARCH_BRANCH_ANTI_STALL_v1"
MAX_FAILED_ATTEMPTS_PER_UNCHANGED_BLOCKER_EPOCH=2

def _canonical(v:Any)->bytes:return json.dumps(v,sort_keys=True,separators=(",",":"),default=str).encode()
def stable_key(v:Any)->str:return hashlib.sha256(_canonical(v)).hexdigest()
@dataclass(frozen=True)
class RouteAttempt:
    route_id:str; method_class:str; evidence_set:tuple[str,...]; result:str; blocker_key:str; recovered_artifacts:tuple[str,...]=()
    @property
    def route_fingerprint(self)->str:return stable_key({"method_class":self.method_class,"evidence_set":sorted(self.evidence_set)})
@dataclass
class ResearchBranchState:
    branch_id:str; blocker_key:str; evidence_epoch:str; attempts:list[RouteAttempt]=field(default_factory=list); closed:bool=False; closure_reason:str=""
    def failed_attempts_same_blocker(self):return [a for a in self.attempts if a.blocker_key==self.blocker_key and a.result.upper() not in {"PASS","RESOLVED","CHANGED_BLOCKER"}]
def materially_different(prev:RouteAttempt,cand:RouteAttempt)->bool:
    if prev.blocker_key!=cand.blocker_key:return True
    return prev.method_class.strip().casefold()!=cand.method_class.strip().casefold() or set(prev.evidence_set)!=set(cand.evidence_set)
def preflight(state:ResearchBranchState,candidate:RouteAttempt)->dict[str,Any]:
    if state.closed:return {"PATCH_ID":PATCH_ID,"ALLOW":False,"STATE":"BRANCH_CLOSED_UNCHANGED_BLOCKER","REASON":state.closure_reason or "BRANCH_ALREADY_CLOSED"}
    if candidate.blocker_key!=state.blocker_key and candidate.result.upper()!="CHANGED_BLOCKER":return {"PATCH_ID":PATCH_ID,"ALLOW":False,"STATE":"BLOCKER_KEY_MISMATCH","REASON":"ATTEMPT_MUST_BIND_TO_BRANCH_BLOCKER"}
    failed=state.failed_attempts_same_blocker()
    if not failed:return {"PATCH_ID":PATCH_ID,"ALLOW":True,"ROLE":"PRIMARY_ROUTE","ATTEMPT_INDEX":1}
    if len(failed)>=MAX_FAILED_ATTEMPTS_PER_UNCHANGED_BLOCKER_EPOCH:return {"PATCH_ID":PATCH_ID,"ALLOW":False,"STATE":"BRANCH_CLOSED_UNCHANGED_BLOCKER","REASON":"ATTEMPT_BUDGET_EXHAUSTED"}
    if not materially_different(failed[-1],candidate):return {"PATCH_ID":PATCH_ID,"ALLOW":False,"STATE":"EQUIVALENT_FALLBACK_PROHIBITED","REASON":"METHOD_CLASS_AND_EVIDENCE_SET_UNCHANGED"}
    return {"PATCH_ID":PATCH_ID,"ALLOW":True,"ROLE":"MATERIALLY_DIFFERENT_FALLBACK","ATTEMPT_INDEX":len(failed)+1}
def record_attempt(state:ResearchBranchState,attempt:RouteAttempt,*,next_main_path:str="")->dict[str,Any]:
    d=preflight(state,attempt)
    if not d.get("ALLOW"):
        if d.get("STATE")=="BRANCH_CLOSED_UNCHANGED_BLOCKER":state.closed=True;state.closure_reason=str(d.get("REASON"))
        return d
    state.attempts.append(attempt); failed=state.failed_attempts_same_blocker()
    if attempt.result.upper() in {"PASS","RESOLVED","CHANGED_BLOCKER"}:return {"PATCH_ID":PATCH_ID,"STATE":"BRANCH_PROGRESS","ALLOW_NEXT":True,"RESULT":attempt.result,"ATTEMPTS":len(state.attempts)}
    if len(failed)>=MAX_FAILED_ATTEMPTS_PER_UNCHANGED_BLOCKER_EPOCH:
        state.closed=True;state.closure_reason="PRIMARY_AND_MATERIALLY_DIFFERENT_FALLBACK_FAILED_SAME_BLOCKER";arts=sorted({x for a in state.attempts for x in a.recovered_artifacts})
        return {"PATCH_ID":PATCH_ID,"STATE":"BRANCH_CLOSED_UNCHANGED_BLOCKER","BRANCH_ID":state.branch_id,"BLOCKER_KEY":state.blocker_key,"EVIDENCE_EPOCH":state.evidence_epoch,"PRIMARY_ROUTE":state.attempts[0].route_id,"FALLBACK_ROUTE":state.attempts[1].route_id,"PRIMARY_RESULT":state.attempts[0].result,"FALLBACK_RESULT":state.attempts[1].result,"RECOVERED_ARTIFACTS":arts,"EXACT_UNCHANGED_BLOCKER":state.blocker_key,"NEXT_MAIN_PATH":next_main_path,"AUTONOMOUS_NEXT_EXPERIMENT_ALLOWED":False}
    return {"PATCH_ID":PATCH_ID,"STATE":"PRIMARY_FAILED_FALLBACK_ALLOWED","ALLOW_NEXT":True,"ATTEMPTS":len(state.attempts)}
def reopen(state:ResearchBranchState,*,reason:str,new_evidence_epoch:str|None=None)->dict[str,Any]:
    allowed={"NEW_EVIDENCE","BLOCKER_STATE_CHANGED","MATERIALLY_NEW_METHOD_CLASS","EXPLICIT_USER_OVERRIDE_NAMING_THE_CLOSED_BRANCH"}; token=reason.strip().upper()
    if token not in allowed:return {"PATCH_ID":PATCH_ID,"REOPENED":False,"REASON":"REOPEN_GATE_NOT_MET"}
    state.closed=False;state.closure_reason="";state.attempts.clear()
    if new_evidence_epoch:state.evidence_epoch=str(new_evidence_epoch)
    return {"PATCH_ID":PATCH_ID,"REOPENED":True,"EVIDENCE_EPOCH":state.evidence_epoch,"REASON":token}
