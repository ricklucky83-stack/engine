from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Callable, Mapping

PATCH_ID = "APEX_GLOBAL_POINTER_DOCS_COORDINATOR_FENCED_COMMIT_v1"
PROTOCOL = "APEX_POINTER_DOCS_COORDINATOR_FENCED_COMMIT_V1"
CAPABILITY = "DOCS_REQUIRED_REVISION_ID_FENCED_COMMIT_V1"


class CoordinatorCASError(RuntimeError):
    pass


def canonical_json_line(value: Mapping[str, Any]) -> str:
    return json.dumps(dict(value), separators=(",", ":"), sort_keys=True) + "\n"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require_committed_parent(
    state: Mapping[str, Any],
    *,
    pointer_file_id: str,
    pointer_epoch: int,
    pointer_sha256: str,
) -> None:
    if str(state.get("PROTOCOL")) != PROTOCOL:
        raise CoordinatorCASError("COORDINATOR_PROTOCOL_MISMATCH")
    if str(state.get("STATUS")) != "COMMITTED":
        raise CoordinatorCASError("COORDINATOR_NOT_COMMITTED")
    if str(state.get("ACTIVE_POINTER_FILE_ID")) != str(pointer_file_id):
        raise CoordinatorCASError("COORDINATOR_POINTER_FILE_ID_MISMATCH")
    if int(state.get("POINTER_EPOCH", -1)) != int(pointer_epoch):
        raise CoordinatorCASError("COORDINATOR_POINTER_EPOCH_MISMATCH")
    if str(state.get("POINTER_SHA256")) != str(pointer_sha256):
        raise CoordinatorCASError("COORDINATOR_POINTER_SHA_MISMATCH")


def _require_sha256(value: str, code: str) -> str:
    value = str(value or "")
    if len(value) != 64 or any(c not in "0123456789abcdefABCDEF" for c in value):
        raise CoordinatorCASError(code)
    return value.lower()


def validate_candidate_pointer(*, file_id: str, expected_epoch: int, pointer_payload: Mapping[str, Any], pointer_bytes: bytes) -> tuple[int, str]:
    try:
        decoded = json.loads(pointer_bytes.decode("utf-8"))
    except Exception as exc:
        raise CoordinatorCASError(f"CANDIDATE_POINTER_INVALID_JSON:{exc}") from exc
    if decoded != dict(pointer_payload):
        raise CoordinatorCASError("CANDIDATE_POINTER_BYTES_PAYLOAD_MISMATCH")
    if str(pointer_payload.get("ACTIVE_POINTER_FILE")) != "APEX_GLOBAL_STATE_LATEST.txt":
        raise CoordinatorCASError("CANDIDATE_POINTER_TITLE_IDENTITY_MISMATCH")
    if str(pointer_payload.get("ACTIVE_POINTER_FILE_ID") or "") != str(file_id):
        raise CoordinatorCASError("CANDIDATE_POINTER_FILE_ID_MISMATCH")
    candidate_epoch = int(pointer_payload.get("POINTER_EPOCH", -1))
    if candidate_epoch != int(expected_epoch) + 1:
        raise CoordinatorCASError("CANDIDATE_POINTER_EPOCH_NOT_NEXT")
    bundle_sha = _require_sha256(pointer_payload.get("BUNDLE_SHA256"), "CANDIDATE_BUNDLE_SHA256_REQUIRED")
    if str(pointer_payload.get("STATE_DIGEST") or "") != "sha256:" + bundle_sha:
        raise CoordinatorCASError("CANDIDATE_STATE_DIGEST_MISMATCH")
    return candidate_epoch, sha256_bytes(pointer_bytes)


def build_claim(
    parent: Mapping[str, Any],
    *,
    candidate_epoch: int,
    candidate_sha256: str,
    candidate_state_version: str,
    candidate_bundle_sha256: str,
    tx_id: str,
) -> dict:
    return {
        "PROTOCOL": PROTOCOL,
        "STATUS": "CLAIMED",
        "ACTIVE_POINTER_FILE_ID": str(parent["ACTIVE_POINTER_FILE_ID"]),
        "PARENT_POINTER_EPOCH": int(parent["POINTER_EPOCH"]),
        "PARENT_POINTER_SHA256": str(parent["POINTER_SHA256"]),
        "PARENT_STATE_VERSION": str(parent.get("STATE_VERSION") or ""),
        "CANDIDATE_POINTER_EPOCH": int(candidate_epoch),
        "CANDIDATE_POINTER_SHA256": str(candidate_sha256),
        "CANDIDATE_STATE_VERSION": str(candidate_state_version),
        "CANDIDATE_BUNDLE_SHA256": str(candidate_bundle_sha256),
        "TX_ID": str(tx_id),
    }


def build_committed_from_claim(claim: Mapping[str, Any]) -> dict:
    if str(claim.get("PROTOCOL")) != PROTOCOL or str(claim.get("STATUS")) != "CLAIMED":
        raise CoordinatorCASError("INVALID_CLAIM_STATE")
    return {
        "PROTOCOL": PROTOCOL,
        "STATUS": "COMMITTED",
        "ACTIVE_POINTER_FILE_ID": str(claim["ACTIVE_POINTER_FILE_ID"]),
        "POINTER_EPOCH": int(claim["CANDIDATE_POINTER_EPOCH"]),
        "POINTER_SHA256": str(claim["CANDIDATE_POINTER_SHA256"]),
        "STATE_VERSION": str(claim["CANDIDATE_STATE_VERSION"]),
        "BUNDLE_SHA256": str(claim["CANDIDATE_BUNDLE_SHA256"]),
        "TX_ID": str(claim["TX_ID"]),
    }


def classify_recovery(
    claim: Mapping[str, Any],
    *,
    live_pointer_epoch: int,
    live_pointer_sha256: str,
) -> str:
    if str(claim.get("STATUS")) != "CLAIMED":
        return "NO_RECOVERY_REQUIRED"
    parent = (int(claim["PARENT_POINTER_EPOCH"]), str(claim["PARENT_POINTER_SHA256"]))
    candidate = (int(claim["CANDIDATE_POINTER_EPOCH"]), str(claim["CANDIDATE_POINTER_SHA256"]))
    live = (int(live_pointer_epoch), str(live_pointer_sha256))
    if live == parent:
        return "SAFE_TO_RETRY_OR_RELEASE_CLAIM"
    if live == candidate:
        return "FINALIZE_COMMITTED"
    return "HARD_HALT_POINTER_DIVERGED"


@dataclass
class ConnectorOps:
    discover_active_pointer: Callable[[], Mapping[str, Any]]
    read_coordinator: Callable[[], Mapping[str, Any]]
    cas_coordinator: Callable[..., Mapping[str, Any]]
    update_pointer_blob: Callable[..., Mapping[str, Any]]


class DocsCoordinatorPointerRegistry:
    """Concrete registry adapter for apex_stable_pointer_cas_v1.

    Atomic exclusion is obtained from Google Docs documents.batchUpdate with
    writeControl.requiredRevisionId. The raw Drive pointer blob remains the
    stable object and is updated only while the successful coordinator claim
    is held. Every compliant writer must use the same coordinator document.
    """

    def __init__(self, ops: ConnectorOps, *, coordinator_file_id: str):
        self.ops = ops
        self.coordinator_file_id = str(coordinator_file_id)

    def discover_exact_active_pointer(self) -> dict:
        return dict(self.ops.discover_active_pointer())

    def compare_and_swap_pointer_in_place(self, **kwargs: Any) -> dict:
        file_id = str(kwargs["file_id"])
        expected_sha = str(kwargs["expected_pointer_sha256"])
        expected_epoch = int(kwargs["expected_pointer_epoch"])
        pointer_payload = dict(kwargs["pointer_payload"])
        pointer_bytes = bytes(kwargs["pointer_bytes"])
        candidate_epoch, candidate_sha = validate_candidate_pointer(
            file_id=file_id, expected_epoch=expected_epoch, pointer_payload=pointer_payload, pointer_bytes=pointer_bytes
        )
        tx_id = str(kwargs.get("tx_id") or f"{expected_epoch}->{candidate_epoch}:{candidate_sha[:16]}")

        coord = dict(self.ops.read_coordinator())
        state = dict(coord.get("STATE") or {})
        revision_id = str(coord.get("REVISION_ID") or "")
        if not revision_id:
            raise CoordinatorCASError("COORDINATOR_REVISION_ID_REQUIRED")
        require_committed_parent(
            state,
            pointer_file_id=file_id,
            pointer_epoch=expected_epoch,
            pointer_sha256=expected_sha,
        )

        claim = build_claim(
            state,
            candidate_epoch=candidate_epoch,
            candidate_sha256=candidate_sha,
            candidate_state_version=str(pointer_payload.get("STATE_VERSION") or ""),
            candidate_bundle_sha256=str(pointer_payload.get("BUNDLE_SHA256") or ""),
            tx_id=tx_id,
        )
        claimed = dict(
            self.ops.cas_coordinator(
                coordinator_file_id=self.coordinator_file_id,
                required_revision_id=revision_id,
                expected_state=state,
                next_state=claim,
            )
        )
        if claimed.get("CAS") not in (True, "PASS"):
            raise CoordinatorCASError("COORDINATOR_CLAIM_FAILED")

        live = dict(self.ops.discover_active_pointer())
        if str(live.get("FILE_ID") or live.get("ACTIVE_POINTER_FILE_ID") or "") != file_id:
            raise CoordinatorCASError("ACTIVE_POINTER_FILE_ID_DRIFT_AFTER_CLAIM")
        live_sha = str(live.get("POINTER_BYTES_SHA256") or live.get("BYTES_SHA256") or "")
        if not live_sha:
            raise CoordinatorCASError("ACTIVE_POINTER_BYTES_SHA256_REQUIRED_AFTER_CLAIM")
        if live_sha != expected_sha:
            raise CoordinatorCASError("ACTIVE_POINTER_BYTES_DRIFT_AFTER_CLAIM")
        live_epoch = int(live.get("POINTER_EPOCH", expected_epoch))
        if live_epoch != expected_epoch:
            raise CoordinatorCASError("ACTIVE_POINTER_EPOCH_DRIFT_AFTER_CLAIM")

        write = dict(self.ops.update_pointer_blob(file_id=file_id, pointer_bytes=pointer_bytes))
        if write.get("WRITE") not in (True, "PASS"):
            raise CoordinatorCASError("ACTIVE_POINTER_BLOB_WRITE_FAILED")

        rb = dict(self.ops.discover_active_pointer())
        rb_sha = str(rb.get("POINTER_BYTES_SHA256") or rb.get("BYTES_SHA256") or "")
        if not rb_sha:
            raise CoordinatorCASError("ACTIVE_POINTER_BYTES_SHA256_REQUIRED_ON_READBACK")
        if str(rb.get("FILE_ID") or rb.get("ACTIVE_POINTER_FILE_ID") or "") != file_id:
            raise CoordinatorCASError("ACTIVE_POINTER_FILE_ID_CHANGED")
        if int(rb.get("POINTER_EPOCH", -1)) != candidate_epoch:
            raise CoordinatorCASError("ACTIVE_POINTER_EPOCH_READBACK_MISMATCH")
        if rb_sha != candidate_sha:
            raise CoordinatorCASError("ACTIVE_POINTER_BYTES_READBACK_MISMATCH")

        claim_revision_id = str(claimed.get("REVISION_ID") or "")
        if not claim_revision_id:
            raise CoordinatorCASError("COORDINATOR_CLAIM_REVISION_ID_REQUIRED")

        committed = build_committed_from_claim(claim)
        finalized = dict(
            self.ops.cas_coordinator(
                coordinator_file_id=self.coordinator_file_id,
                required_revision_id=claim_revision_id,
                expected_state=claim,
                next_state=committed,
            )
        )
        if finalized.get("CAS") not in (True, "PASS"):
            raise CoordinatorCASError("COORDINATOR_FINALIZE_FAILED")
        return {
            "CAS": "PASS",
            "BACKEND": PATCH_ID,
            "COORDINATOR_FILE_ID": self.coordinator_file_id,
            "TX_ID": tx_id,
            "POINTER_BYTES_SHA256": candidate_sha,
            "POINTER_EPOCH": candidate_epoch,
        }
