from __future__ import annotations
import hashlib, json
from pathlib import Path

GUARD_ID = "APEX_GLOBAL_PRODUCTION_RUN_IMMUTABILITY_AND_RECEIPT_GATE_v2"

class ProductionGuardError(RuntimeError):
    pass

def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _norm_command(text: str) -> str:
    return " ".join(str(text or "").upper().replace("_", " ").replace("-", " ").split())

def parse_production_directives(command_text: str) -> dict:
    text = _norm_command(command_text)
    return {
        "BOARD_PRIORITY": "BOARD PRIORITY" in text or "SHOW BOARD" in text,
        "NO_DIAGNOSTICS": "NO DIAGNOSTIC" in text,
        "NO_AUDITS": ("NO AUDIT" in text) or (("NO DIAGNOSTIC" in text) and ("AUDIT" in text)),
        "FIX_AND_PROCEED": "FIX AND PROCEED" in text,
        "FAST_PATH": "FAST PATH" in text or "FASTPATH" in text,
        "SHOW_RUN_METRICS": "SHOW RUN METRICS" in text or "SHOW METRICS AND STATS" in text,
        "MAX_NON_EXECUTION_ACTIONS_BEFORE_LAUNCH": 2 if ("FAST PATH" in text or "FASTPATH" in text) else None,
        "OPTIONAL_PREFLIGHT_ALLOWED": False if ("FAST PATH" in text or "FASTPATH" in text) else True,
    }

def build_immutable_run_lock(*, state_version: str, bundle_sha256: str, engine_id: str,
                             engine_root: str | Path, expected_hashes: dict[str, str],
                             command_text: str) -> dict:
    root = Path(engine_root)
    actual = {}
    failures = []
    for rel, expected in sorted(expected_hashes.items()):
        p = root / rel
        if not p.exists():
            failures.append(f"MISSING:{rel}")
            continue
        got = _sha256(p)
        actual[rel] = got
        if got != expected:
            failures.append(f"HASH:{rel}:{got}:{expected}")
    if failures:
        raise ProductionGuardError("PRODUCTION_LOCK_SOURCE_MISMATCH:" + "|".join(failures))
    directives = parse_production_directives(command_text)
    seal_payload = {
        "STATE_VERSION": str(state_version),
        "BUNDLE_SHA256": str(bundle_sha256),
        "ENGINE_ID": str(engine_id),
        "ENGINE_HASHES": actual,
        "DIRECTIVES": directives,
    }
    seal = hashlib.sha256(json.dumps(seal_payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {
        "GUARD_ID": GUARD_ID,
        "RUN_LOCK_STATE": "SEALED_IMMUTABLE",
        "STATE_VERSION": str(state_version),
        "BUNDLE_SHA256": str(bundle_sha256),
        "ENGINE_ID": str(engine_id),
        "ENGINE_HASHES": actual,
        "DIRECTIVES": directives,
        "RUN_LOCK_SHA256": seal,
        "MIDRUN_SOURCE_MUTATION_ALLOWED": False,
        "MIDRUN_STATE_ROTATION_ALLOWED": False,
        "MIDRUN_ENGINEERING_ALLOWED": False,
        "REPAIR_REQUIRES_NEW_GLOBAL_STATE": True,
        "REPAIR_REQUIRES_FRESH_PRODUCTION_RUN": True,
        "STATUS_CLAIM_REQUIRES_MACHINE_RECEIPT": True,
        "CHAT_EXECUTION_AUTHORITY": False,
        "CHAT_LATENCY_BASED_RESTART_ALLOWED": False,
        "CHAT_LIVE_PATCHING_ALLOWED": False,
        "CHAT_CHECKPOINT_MUTATION_ALLOWED": False,
        "ENGINE_CHECKPOINT_AUTHORITY": True,
        "ENGINE_PROCESS_LIFECYCLE_AUTHORITY": True,
    }

def assert_run_lock_unchanged(lock: dict, engine_root: str | Path) -> dict:
    root = Path(engine_root)
    failures = []
    for rel, expected in sorted(lock.get("ENGINE_HASHES", {}).items()):
        p = root / rel
        if not p.exists():
            failures.append(f"MISSING:{rel}")
            continue
        got = _sha256(p)
        if got != expected:
            failures.append(f"MUTATED:{rel}:{got}:{expected}")
    if failures:
        raise ProductionGuardError("PRODUCTION_RUN_MUTATED_RESTART_REQUIRED:" + "|".join(failures))
    return {"PRODUCTION_RUN_IMMUTABILITY_CHECK": "PASS", "RUN_LOCK_SHA256": lock["RUN_LOCK_SHA256"]}

def require_fresh_run_after_repair(previous_lock: dict, current_state_version: str) -> dict:
    same=str(current_state_version)==str(previous_lock.get('STATE_VERSION'))
    if same:
        raise ProductionGuardError(
            f"FRESH_STATE_REQUIRED_AFTER_REPAIR:{current_state_version}"
        )
    return {
        "REPAIR_COMMIT_GATE": "PASS",
        "FRESH_STATE_VERSION": str(current_state_version),
        "STATE_VERSION_CHANGED": True,
        "STATE_VERSION_EXECUTION_AUTHORITY": False,
        "SAME_RUN_REPAIR_RESUME_ALLOWED": False,
    }

def validate_stage_claim(stage: str, evidence: dict) -> dict:
    stage = str(stage).upper()
    e = dict(evidence or {})
    def positive_int(key):
        try: return int(e.get(key, 0)) > 0
        except Exception: return False
    requirements = {
        "PHASE1": lambda: positive_int("BASE_SIM_TRIALS") and bool(e.get("PHASE1_CALIBRATION_HASH")),
        "PHASE2": lambda: positive_int("PHASE2_BUILT_LINEUPS"),
        "HANDOFF": lambda: positive_int("HANDOFF_SURVIVORS"),
        "SELECTOR": lambda: positive_int("SELECTOR_REVIEWED_LINEUPS"),
        "BOARD": lambda: positive_int("FINAL_BOARD_SIZE") and e.get("BOARD_IDENTITY_RECONCILIATION") == "PASS" and e.get("DK_LEGALITY") == "PASS",
    }
    if stage not in requirements:
        raise ProductionGuardError(f"UNKNOWN_STAGE_CLAIM:{stage}")
    if not requirements[stage]():
        raise ProductionGuardError(f"UNPROVEN_STAGE_CLAIM_PROHIBITED:{stage}")
    receipt_hash = hashlib.sha256(json.dumps(e, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {"STAGE": stage, "CLAIM": "PROVEN", "EVIDENCE_SHA256": receipt_hash}

def integrity_failure_receipt(failure_code: str) -> dict:
    # Recoverable faults are orchestration signals. The immutable current run is
    # not mutated, but production must automatically reconcile/commit/rollback
    # and resume on a verified state until a legal board is sealed.
    return {
        "RUN_STATE": "RECOVERY_REQUIRED",
        "FINAL_BOARD_SIZE": None,
        "FAILURE_CODE": str(failure_code),
        "MIDRUN_FIX_PROHIBITED": True,
        "RECOVERY_REQUIRED": True,
        "TERMINAL_USER_FAILURE_ALLOWED": False,
        "RECOVERY_SEQUENCE": [
            "SAME_STATE_AUTHORITATIVE_RECONCILIATION",
            "FRESH_IMMUTABLE_STATE_REPAIR_IF_REQUIRED",
            "PRIOR_ACTIVE_VERIFIED_COMPATIBLE_STATE_ROLLBACK",
            "RESUME_PRODUCTION_TO_LEGAL_BOARD",
        ],
        "NEXT_ALLOWED_ACTION": "AUTO_RECOVER_AND_RESUME_TO_BOARD",
    }

FAST_PATH_CORRECTIVE_PATCH_ID = "APEX_GLOBAL_FAST_PATH_STALL_AND_TERMINAL_PARITY_CORRECTIVE_ACTION_v1"
FAST_PATH_REQUIRED_METRICS = (
    "ACTIVE_POOL", "OUT_PURGE", "PHASE2_BUILT_LINEUPS", "BASE_SIM_TRIALS",
    "BUBBLE_EXTRA_TRIALS_TOTAL", "HANDOFF_SURVIVORS", "SELECTOR_REVIEWED_LINEUPS",
    "FINAL_BOARD_SIZE", "EXECUTION_STATE",
)

def validate_fast_path_metrics(receipt: dict) -> dict:
    missing=[k for k in FAST_PATH_REQUIRED_METRICS if k not in dict(receipt or {})]
    if missing:
        raise ProductionGuardError("RUN_METRICS_MISSING:"+",".join(missing))
    return {"PATCH_ID":FAST_PATH_CORRECTIVE_PATCH_ID,"RUN_METRICS_PARITY":"PASS","FIELDS":list(FAST_PATH_REQUIRED_METRICS)}

def validate_execution_truth(claim: str, *, process_launched: bool, process_active: bool=False,
                             engine_return_code=None, engine_exit_receipt: bool=False,
                             actual_tool_process: bool=False, machine_event: dict|None=None) -> dict:
    c=str(claim or "").upper()
    if c in {"RUNNING","ACTIVE","CONTINUING","EXECUTED","EXECUTION_COMPLETE","TOOL_PROVEN_EXECUTED"}:
        if not isinstance(machine_event,dict):
            raise ProductionGuardError(f"MACHINE_EXECUTION_RECEIPT_REQUIRED:{c}")
        if machine_event.get("MACHINE_EVENT_PROVENANCE") != "PASS" or machine_event.get("MACHINE_EVENT_SOURCE") != "ENGINE_SUBPROCESS" or not machine_event.get("MACHINE_EVENT_RECEIPT_SHA256"):
            raise ProductionGuardError(f"MACHINE_EXECUTION_RECEIPT_INVALID:{c}")
    if c in {"RUNNING","ACTIVE","CONTINUING"} and not (process_launched and process_active):
        raise ProductionGuardError(f"FALSE_RUNNING_STATUS_BLOCKED:{c}")
    exited=(engine_return_code is not None and bool(engine_exit_receipt))
    if c in {"EXECUTED","EXECUTION_COMPLETE"} and not exited:
        raise ProductionGuardError(f"FALSE_EXECUTED_STATUS_BLOCKED:{c}")
    if c=="TOOL_PROVEN_EXECUTED" and not (exited and actual_tool_process):
        raise ProductionGuardError("FALSE_TOOL_PROVEN_EXECUTED_BLOCKED")
    return {"PATCH_ID":FAST_PATH_CORRECTIVE_PATCH_ID,"EXECUTION_TRUTH":"PASS","CLAIM":c}

def validate_terminal_board_parity(*, board_lineup_ids, selected_ledger_lineup_ids,
                                   final_board_size: int, board_run_artifact_id: str,
                                   ledger_run_artifact_id: str) -> dict:
    b=[str(x) for x in board_lineup_ids]; s=[str(x) for x in selected_ledger_lineup_ids]
    if len(b)!=int(final_board_size):
        raise ProductionGuardError(f"FINAL_BOARD_SIZE_MISMATCH:{len(b)}:{final_board_size}")
    if len(s)!=int(final_board_size):
        raise ProductionGuardError(f"SELECTOR_SELECTED_COUNT_MISMATCH:{len(s)}:{final_board_size}")
    if b!=s:
        raise ProductionGuardError("BOARD_SELECTOR_LINEUP_ID_MISMATCH")
    if not board_run_artifact_id or board_run_artifact_id!=ledger_run_artifact_id:
        raise ProductionGuardError("SAME_RUN_ARTIFACT_ID_MISMATCH")
    return {"PATCH_ID":FAST_PATH_CORRECTIVE_PATCH_ID,"TERMINAL_ARTIFACT_RECONCILIATION":"PASS","FINAL_BOARD_SIZE":int(final_board_size)}

