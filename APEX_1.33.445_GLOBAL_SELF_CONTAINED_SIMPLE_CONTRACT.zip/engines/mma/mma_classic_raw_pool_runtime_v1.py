from __future__ import annotations
import argparse, json, sys
from pathlib import Path
STATE_ROOT=Path(__file__).resolve().parents[2]
if str(STATE_ROOT) not in sys.path: sys.path.insert(0,str(STATE_ROOT))
from engines.common.mandatory_prebuild_roster_gate_v1 import gate_receipt, require_prebuild_roster_check
from engines.mma.mma_joint_fight_engine_v1 import MMAConfig, pipeline
ENGINE_ID='APEX_MMA_CLASSIC_RAW_POOL_RUNTIME_v1'
SPORT='MMA'; MODE='CLASSIC'

def run(pool, field_size, board_path, receipt_path, availability_receipt, execution_id, seed=None, config=None):
    gate=require_prebuild_roster_check(availability_receipt,sport=SPORT,mode=MODE,pool_path=pool,execution_id=execution_id,field_size=int(field_size))
    board,receipt,slate,p1,p2=pipeline(pool,int(field_size),mode=MODE,seed=seed,config=config,verified_out_names=gate.out_players)
    receipt={'RUN_STATE':'TOOL_PROVEN_EXECUTED','ENGINE_ID':ENGINE_ID,**receipt,'PREBUILD_ROSTER_CHECK':gate_receipt(gate),'EXECUTION_STATE':'TOOL_PROVEN_EXECUTED'}
    Path(board_path).parent.mkdir(parents=True,exist_ok=True); board.to_csv(board_path,index=False)
    Path(receipt_path).parent.mkdir(parents=True,exist_ok=True); Path(receipt_path).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    return board,receipt

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--pool',required=True); ap.add_argument('--field-size',required=True,type=int); ap.add_argument('--availability-receipt',required=True); ap.add_argument('--execution-id',required=True); ap.add_argument('--board',required=True); ap.add_argument('--receipt',required=True); ap.add_argument('--seed',type=int)
    a=ap.parse_args()
    try:
        board,r=run(a.pool,a.field_size,a.board,a.receipt,a.availability_receipt,a.execution_id,a.seed)
        keys=['ENGINE_ID','ACTIVE_POOL','OUT_PURGE','ORPHAN_FIGHT_PURGE','LEGAL_LINEUPS_SCANNED','PHASE2_BUILT_LINEUPS','BASE_SIM_TRIALS','BUBBLE_EXTRA_TRIALS_TOTAL','BUBBLE_LINEUPS_UNRESOLVED','HANDOFF_SURVIVORS','SELECTOR_REVIEWED_LINEUPS','FINAL_BOARD_SIZE','EXECUTION_STATE']
        print(json.dumps({k:r.get(k) for k in keys},indent=2));
        if len(board): print(board.to_string(index=False))
        return 0
    except Exception as exc:
        print(json.dumps({'RUN_STATE':'RUN_INVALID','ENGINE_ID':ENGINE_ID,'FINAL_BOARD_SIZE':0,'ENGINE_SUBSTITUTION':False,'FAILURE_CODE':f'{type(exc).__name__}:{exc}'},indent=2)); return 1
if __name__=='__main__': raise SystemExit(main())
