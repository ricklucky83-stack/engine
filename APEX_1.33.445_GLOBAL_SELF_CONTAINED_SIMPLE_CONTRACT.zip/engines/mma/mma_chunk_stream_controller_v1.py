#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, pickle, sys, time
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from engines.common.mandatory_prebuild_roster_gate_v1 import gate_receipt, require_prebuild_roster_check
from engines.mma import mma_joint_fight_engine_v1 as core
PATCH_ID='MMA_GLOBAL_ENGINE_OWNED_CHUNK_STREAM_v1'
CONTINUE_CODE=75

def atomic_json(p:Path,o:Any):
    p.parent.mkdir(parents=True,exist_ok=True); t=p.with_suffix(p.suffix+'.tmp')
    with t.open('w',encoding='utf-8') as f: json.dump(o,f,indent=2,sort_keys=True,default=str); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(t,p)
def atomic_pickle(p:Path,o:Any):
    t=p.with_suffix(p.suffix+'.tmp')
    with t.open('wb') as f: pickle.dump(o,f,protocol=5); f.flush(); os.fsync(f.fileno())
    os.replace(t,p)
def parse():
    ap=argparse.ArgumentParser(); ap.add_argument('--pool',required=True); ap.add_argument('--field-size',required=True,type=int); ap.add_argument('--availability-receipt',required=True); ap.add_argument('--execution-id',required=True); ap.add_argument('--board',required=True); ap.add_argument('--receipt',required=True); ap.add_argument('--seed',type=int)
    return ap.parse_args()
def mode():
    m=str(os.environ.get('APEX_MODE') or os.environ.get('APEX_SPORT_MODE') or 'CLASSIC').upper()
    return 'SHOWDOWN' if m in {'SHOWDOWN','SD','CAPTAIN','CPT'} else 'CLASSIC'
def main():
    a=parse(); m=mode(); root=Path(os.environ.get('APEX_RESUMABLE_RUN_ROOT') or Path(a.board).parent)/f'mma_chunk_{m.lower()}'
    root.mkdir(parents=True,exist_ok=True); sp=root/'controller_state.json'; ck=root/'checkpoint.pkl'
    ident={'PATCH_ID':PATCH_ID,'MODE':m,'EXECUTION_ID':str(a.execution_id),'FIELD_SIZE':int(a.field_size),'STATE_VERSION':str(os.environ.get('APEX_GLOBAL_STATE_VERSION') or os.environ.get('APEX_RESUMABLE_STATE_VERSION') or 'UNSPECIFIED')}
    st={}
    if sp.exists():
        try: st=json.loads(sp.read_text())
        except: st={}
    if st and st.get('IDENTITY')!=ident:
        stale=root.with_name(root.name+f'.stale.{time.time_ns()}'); os.replace(root,stale); root.mkdir(parents=True,exist_ok=True); st={}
    if not st: st={'IDENTITY':ident,'STAGE':0,'COMPLETED_CHUNKS':0}; atomic_json(sp,st)
    d={}
    if ck.exists():
        with ck.open('rb') as f:d=pickle.load(f)
    stage=int(st['STAGE'])
    if stage==0:
        gate=require_prebuild_roster_check(a.availability_receipt,sport='MMA',mode=m,pool_path=a.pool,execution_id=a.execution_id,field_size=a.field_size); d['gate']=gate
    elif stage==1:
        cfg=core.MMAConfig(field_size=int(a.field_size),seed=int(a.seed if a.seed is not None else a.field_size)); cfg.validate(); d['cfg']=cfg; d['slate']=core.load_slate(a.pool,mode=m,verified_out_names=d['gate'].out_players)
    elif stage==2: d['p1']=core.simulate_phase1(d['slate'],d['cfg'])
    elif stage==3: d['p2']=core.build_phase2(d['slate'],d['p1'],d['cfg'],mode=m)
    elif stage==4: d['sim']=core.simulate_phase2(d['p2'],d['p1'],d['slate'],d['cfg'],mode=m)
    elif stage==5: d['board_idx'],d['sel']=core.select_board(d['p2'],d['sim'],d['slate'],d['cfg'],mode=m)
    elif stage==6:
        board=core.build_board_records(d['board_idx'],d['p2'],d['sim'],d['sel'],d['slate'],mode=m); d['board']=board
        p2=d['p2']; slate=d['slate']; sim=d['sim']; sel=d['sel']; cfg=d['cfg']
        phase2_ids=[[slate.ids[j] for j in row] for row in p2.rows]; full_ledger=[phase2_ids[int(i)] for i in sel['full_order']]
        receipt={'RUN_STATE':'TOOL_PROVEN_EXECUTED','ENGINE_FAMILY':core.ENGINE_FAMILY,'SPORT':'MMA','MODE':m,'FIELD_SIZE':int(a.field_size),'ACTIVE_POOL':len(slate.names),'OUT_PURGE':slate.out_names,'ORPHAN_FIGHT_PURGE':slate.orphan_names,'LEGAL_LINEUPS_SCANNED':int(p2.legal_scan),'PHASE1_MC_TRIALS':int(cfg.player_trials),'PHASE1_CALIBRATION_HASH':d['p1'].metric_hash,'PHASE2_BUILT_LINEUPS':int(len(p2.rows)),'PHASE2_IDENTITY_LEDGER_SHA256':p2.identity_hash,'PHASE2_FREEZE_HASH':p2.identity_hash,'BASE_SIM_TRIALS':int(cfg.base_trials),'BUBBLE_EXTRA_TRIALS_TOTAL':int(sim['bubble_extra_trials_total']),'BUBBLE_LINEUPS_UNRESOLVED':int(sim['bubble_unresolved']),'HANDOFF_SURVIVORS':int(len(p2.rows)),'SELECTOR_REVIEWED_LINEUPS':int(len(p2.rows)),'FULL_REVIEW_LEDGER_ROWS':int(len(full_ledger)),'POST_PHASE2_MUTATION_COUNT':0,'FINAL_BOARD_SIZE':int(len(board)),'FINAL_SALARY_RECOMPUTE':board['SALARY'].astype(int).tolist() if len(board) else [],'PREBUILD_ROSTER_CHECK':gate_receipt(d['gate']),'EXECUTION_STATE':'TOOL_PROVEN_EXECUTED'}
        Path(a.board).parent.mkdir(parents=True,exist_ok=True); board.to_csv(a.board,index=False); Path(a.receipt).write_text(json.dumps(receipt,indent=2,default=str)+'\n')
        rows=board.to_dict('records'); st['STAGE']=7; st['COMPLETED_CHUNKS']+=1; atomic_pickle(ck,d); atomic_json(sp,st)
        print(json.dumps({'RUN_STATE':'NATIVE_BOARD_READY_FOR_GLOBAL_CORE5','EXECUTION_STATE':'TOOL_PROVEN_EXECUTED','PATCH_ID':PATCH_ID,'SPORT':'MMA','MODE':m,'EXECUTION_ID':str(a.execution_id),'FINAL_BOARD_SIZE':len(rows),'FINAL_BOARD':rows,'SOURCE_BOARD_FILE':str(Path(a.board).resolve()),'CHUNK_STREAM_COMPLETED_CHUNKS':st['COMPLETED_CHUNKS']},default=str)); return 0
    elif stage>=7:
        board=d.get('board'); rows=board.to_dict('records') if board is not None else []
        print(json.dumps({'RUN_STATE':'NATIVE_BOARD_READY_FOR_GLOBAL_CORE5','EXECUTION_STATE':'TOOL_PROVEN_EXECUTED','PATCH_ID':PATCH_ID,'SPORT':'MMA','MODE':m,'EXECUTION_ID':str(a.execution_id),'FINAL_BOARD_SIZE':len(rows),'FINAL_BOARD':rows,'SOURCE_BOARD_FILE':str(Path(a.board).resolve()),'CHUNK_STREAM_COMPLETED_CHUNKS':st['COMPLETED_CHUNKS']},default=str)); return 0
    st['STAGE']=stage+1; st['COMPLETED_CHUNKS']+=1; atomic_pickle(ck,d); atomic_json(sp,st)
    print(json.dumps({'RUN_STATE':'CHECKPOINTED_CONTINUE','EXECUTION_STATE':'RESUMABLE','PATCH_ID':PATCH_ID,'SPORT':'MMA','MODE':m,'EXECUTION_ID':str(a.execution_id),'COMPLETED_STAGE':stage,'NEXT_STAGE':stage+1,'CHECKPOINT':str(ck),'CHUNK_STREAM_COMPLETED_CHUNKS':st['COMPLETED_CHUNKS']})); return CONTINUE_CODE
if __name__=='__main__':
    try: raise SystemExit(main())
    except SystemExit: raise
    except Exception as exc:
        print(json.dumps({'RUN_STATE':'RUN_INVALID','EXECUTION_STATE':'FAILED','PATCH_ID':PATCH_ID,'FAILURE_CODE':f'{type(exc).__name__}:{exc}','FINAL_BOARD_SIZE':0})); raise SystemExit(2)
