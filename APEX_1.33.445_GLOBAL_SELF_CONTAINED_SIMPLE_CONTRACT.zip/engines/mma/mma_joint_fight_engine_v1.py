from __future__ import annotations

import hashlib
import itertools
import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

STATE_ROOT = Path(__file__).resolve().parents[1]

from engines.common import apex_global_sports_strategy_layer_v1 as global_strategy
from engines.common import right_neighborhood_door_selector_v1 as rn_door

PATCH_ID = "MMA_CLASSIC_JOINT_FINISH_CORE_POSTERIOR_v1"
ENGINE_FAMILY = "APEX_MMA_FULL_REBUILD_v1"
SPORT = "MMA"
SALARY_CAP = 50_000

FORBIDDEN_FORWARD = {
    "ACTUAL_FPTS", "REALIZED_FPTS", "FINAL_RANK", "CONTEST_RANK", "WINNING_LINEUP",
    "POSTLOCK_SCORE", "TARGET_ACTUAL_SCORE", "FINAL_BOARD_RANKS",
}

ALIASES: dict[str, tuple[str, ...]] = {
    "PLAYER": ("PLAYER", "NAME", "ATHLETE", "FIGHTER"),
    "ID": ("ID", "PLAYER_ID", "PLAYER ID", "DK_ID", "DK ID"),
    "POS": ("POS", "POSITION", "ROSTER_POSITION", "ROSTER POSITION"),
    "SAL": ("SAL", "SALARY"),
    "OPPONENT": ("OPPONENT", "OPP", "OPPONENT_NAME", "OPPONENT NAME"),
    "MATCHUP": ("MATCHUP", "GAME_INFO", "GAME INFO", "FIGHT", "BOUT"),
    "STATUS": ("STATUS", "INJURY_STATUS", "PARTICIPATION_STATUS", "FIGHT_STATUS"),
    "FPTS": ("FPTS", "PROJ", "PROJECTION", "PROJECTED_FPTS"),
    "VAL": ("VAL", "VALUE"),
    "RST": ("RST%", "RST", "OWNERSHIP", "OWN%", "OWNERSHIP%"),
    "WIN_PROB": ("WIN %", "WIN%", "WIN_PROBABILITY", "WIN PROBABILITY", "WIN_PROB"),
    "MONEYLINE": ("MONEYLINE", "ML", "ODDS", "FIGHT_ODDS", "FIGHT ODDS"),
    "FINISH_PROB": ("FINISH %", "FINISH%", "FINISH_PROBABILITY", "FINISH PROBABILITY", "ITD%", "ITD %"),
    "ITD_ODDS": ("ITD_ODDS", "ITD ODDS", "INSIDE_DISTANCE_ODDS", "INSIDE DISTANCE ODDS"),
    "SIG_LPM": ("SIG STR LPM", "SIG_STR_LPM", "SIG_STR_PER_MIN", "SLPM", "SIG STR", "SIG_STR"),
    "SIG_ABS_LPM": ("SIG STR ABS LPM", "SIG_STR_ABS_LPM", "SAPM", "SIG STR ABS", "SIG_STR_ABS"),
    "TD_15": ("TAKEDOWNS", "TD_15", "TD/15", "TD AVG", "TD_AVG", "TAKEDOWN_AVG"),
    "TD_ACC": ("TD ACC%", "TD_ACC", "TD ACC", "TAKEDOWN_ACCURACY", "TAKEDOWN ACCURACY"),
    "TD_DEF": ("TD DEF%", "TD_DEF", "TD DEF", "TAKEDOWN_DEFENSE", "TAKEDOWN DEFENSE"),
    "SUB_15": ("SUB AVG", "SUB_AVG", "SUB/15", "SUB_15", "SUBMISSION_AVG"),
    "CTRL_SEC": ("CONTROL TIME", "CONTROL_TIME", "CTRL", "CTRL_SEC", "CONTROL_SECONDS"),
    "KD_15": ("KNOCKDOWNS", "KD_15", "KD/15", "KNOCKDOWN_RATE"),
    "KO_RATE": ("KO %", "KO%", "KO_RATE", "TKO_RATE", "KO_TKO_RATE"),
    "SUB_RATE": ("SUB %", "SUB%", "SUB_RATE", "SUBMISSION_RATE"),
    "ROUNDS": ("ROUNDS", "SCHEDULED_ROUNDS", "SCHEDULED ROUNDS", "BEST_OF_ROUNDS"),
}

OUT_CODES = {"OUT", "CANCELLED", "CANCELED", "WITHDRAWN", "SCRATCH", "OFF", "INACTIVE"}


def _norm(x: Any) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", str(x or "").strip().upper()).strip("_")


def _stable_hash(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _rename_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    cmap = {_norm(c): c for c in out.columns}
    forbidden = sorted(set(cmap) & FORBIDDEN_FORWARD)
    if forbidden:
        raise RuntimeError("RUN_INVALID:POSTLOCK_FIELDS_IN_FORWARD_POOL:" + ",".join(forbidden))
    ren: dict[str, str] = {}
    for canonical, aliases in ALIASES.items():
        for alias in aliases:
            k = _norm(alias)
            if k in cmap:
                ren[cmap[k]] = canonical
                break
    out = out.rename(columns=ren)
    if "PLAYER" not in out or "SAL" not in out:
        raise RuntimeError("RUN_INVALID:MMA_POOL_REQUIRES_PLAYER_AND_SALARY")
    return out


def _num_series(df: pd.DataFrame, col: str) -> np.ndarray:
    if col not in df:
        return np.full(len(df), np.nan, dtype=np.float64)
    s = df[col].astype(str).str.replace("%", "", regex=False).str.replace("$", "", regex=False).str.replace(",", "", regex=False)
    return pd.to_numeric(s, errors="coerce").to_numpy(dtype=np.float64)


def _prob(values: np.ndarray) -> np.ndarray:
    x = values.astype(np.float64, copy=True)
    finite = np.isfinite(x)
    if finite.any() and np.nanmax(np.abs(x[finite])) > 1.0:
        x[finite] /= 100.0
    return x


def _american_prob(values: np.ndarray) -> np.ndarray:
    x = values.astype(np.float64, copy=True)
    out = np.full(len(x), np.nan, dtype=np.float64)
    pos = np.isfinite(x) & (x > 0)
    neg = np.isfinite(x) & (x < 0)
    out[pos] = 100.0 / (x[pos] + 100.0)
    out[neg] = (-x[neg]) / ((-x[neg]) + 100.0)
    return out


def _pct(x: np.ndarray) -> np.ndarray:
    a = np.asarray(x, dtype=np.float64)
    if not len(a):
        return np.asarray([], dtype=np.float32)
    finite = np.isfinite(a)
    med = float(np.nanmedian(a[finite])) if finite.any() else 0.0
    a = np.where(finite, a, med)
    order = np.argsort(a, kind="stable")
    out = np.empty(len(a), dtype=np.float64)
    vals = a[order]
    i = 0
    while i < len(a):
        j = i + 1
        while j < len(a) and vals[j] == vals[i]:
            j += 1
        out[order[i:j]] = ((i + j - 1) / 2.0 + 0.5) / len(a)
        i = j
    return out.astype(np.float32)


def _impute(values: np.ndarray, default: float, *, lo: float | None = None, hi: float | None = None) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64).copy()
    finite = np.isfinite(x)
    fill = float(np.nanmedian(x[finite])) if finite.any() else float(default)
    x[~finite] = fill
    if lo is not None:
        x = np.maximum(x, lo)
    if hi is not None:
        x = np.minimum(x, hi)
    return x


def _first_nonempty(series: Iterable[Any]) -> str:
    for x in series:
        s = str(x or "").strip()
        if s and s.lower() not in {"nan", "none"}:
            return s
    return ""


def _derive_opponent_from_matchup(player: str, matchup: str) -> str:
    if not matchup:
        return ""
    text = re.sub(r"\s+", " ", str(matchup)).strip()
    for token in (" vs. ", " vs ", " v ", " @ ", " - "):
        if token in text.lower():
            # preserve original casing by split on regex equivalent
            parts = re.split(r"\s+(?:vs\.?|v|@|-)\s+", text, maxsplit=1, flags=re.I)
            if len(parts) == 2:
                if _norm(parts[0]) == _norm(player):
                    return parts[1].strip()
                if _norm(parts[1]) == _norm(player):
                    return parts[0].strip()
    return ""


@dataclass(frozen=True)
class MMAConfig:
    field_size: int
    seed: int
    player_trials: int = 50_000
    base_trials: int = 10_000
    max_physical_trials: int = 50_000
    phase2_max: int = 50_000
    fake_field_cap: int = 4096
    board_size: int = 10

    def validate(self) -> None:
        if self.field_size <= 0:
            raise ValueError("field_size must be >0")
        if self.player_trials < self.max_physical_trials:
            raise ValueError("player_trials must be >= max_physical_trials")
        if not (100 <= self.base_trials <= self.max_physical_trials <= self.player_trials):
            raise ValueError("invalid simulation depth")
        if self.phase2_max < self.board_size or self.board_size <= 0:
            raise ValueError("invalid phase2/board size")


@dataclass
class MMASlate:
    frame: pd.DataFrame
    names: tuple[str, ...]
    ids: tuple[str, ...]
    salary: np.ndarray
    cpt_salary: np.ndarray
    opponent_index: np.ndarray
    fight_id: np.ndarray
    win_prob: np.ndarray
    finish_prob: np.ndarray
    sig_lpm: np.ndarray
    sig_abs_lpm: np.ndarray
    td15: np.ndarray
    td_acc: np.ndarray
    td_def: np.ndarray
    sub15: np.ndarray
    ctrl_sec: np.ndarray
    kd15: np.ndarray
    ko_rate: np.ndarray
    sub_rate: np.ndarray
    rounds: np.ndarray
    ownership: np.ndarray
    strategy_leverage: np.ndarray
    strategy_receipt: dict[str, Any]
    pool_sha256: str
    out_names: list[str]
    orphan_names: list[str]


@dataclass
class Phase1:
    player_scores: np.ndarray
    wins: np.ndarray
    finishes: np.ndarray
    player_p95: np.ndarray
    player_p99: np.ndarray
    player_cvar99: np.ndarray
    empirical_win: np.ndarray
    empirical_finish: np.ndarray
    metric_hash: str


@dataclass
class Phase2:
    rows: np.ndarray
    salary: np.ndarray
    tail_proxy: np.ndarray
    cvar_proxy: np.ndarray
    win_finish_proxy: np.ndarray
    leverage_proxy: np.ndarray
    duplication_proxy: np.ndarray
    dog_count: np.ndarray
    opponent_pair_count: np.ndarray
    distinct_fights: np.ndarray
    identity_hash: str
    legal_scan: int


def load_slate(pool_path: str | Path, *, mode: str, verified_out_names: Iterable[str] = ()) -> MMASlate:
    path = Path(pool_path)
    if not path.is_file():
        raise RuntimeError("RUN_INVALID:MMA_PLAYER_POOL_MISSING")
    raw = pd.read_csv(path)
    df = _rename_columns(raw)
    df["PLAYER"] = df["PLAYER"].astype(str).str.strip()
    df["SAL"] = pd.to_numeric(df["SAL"], errors="coerce")
    df = df[df["PLAYER"].ne("") & df["SAL"].notna() & (df["SAL"] > 0)].copy()
    if df.empty:
        raise RuntimeError("RUN_INVALID:MMA_EMPTY_ACTIVE_POOL")

    verified = {_norm(x) for x in verified_out_names if str(x).strip()}
    status = df["STATUS"].map(_norm) if "STATUS" in df else pd.Series([""] * len(df), index=df.index)
    status_out = set(df.loc[status.isin(OUT_CODES), "PLAYER"].map(_norm))
    # Local CSV status is advisory only for individual sports. The prebuild receipt is
    # the sole hard-exclusion authority after dual-source/official/human certification.
    all_out = verified
    df["LOCAL_STATUS_UNCERTAIN"] = df["PLAYER"].map(_norm).isin(status_out - verified)
    out_names = sorted({str(x) for x in df.loc[df["PLAYER"].map(_norm).isin(all_out), "PLAYER"].tolist()})
    if all_out:
        df = df.loc[~df["PLAYER"].map(_norm).isin(all_out)].copy()
    if df.empty:
        raise RuntimeError("RUN_INVALID:MMA_ALL_FIGHTERS_PURGED")

    # Collapse separate CPT/FLEX pool rows into one fighter identity. The base salary
    # is the FLEX/UTIL salary when present; Captain salary is read directly when present.
    records: list[dict[str, Any]] = []
    for name_key, g in df.groupby(df["PLAYER"].map(_norm), sort=False):
        player = _first_nonempty(g["PLAYER"])
        pos = g["POS"].astype(str).str.upper() if "POS" in g else pd.Series([""] * len(g), index=g.index)
        cpt_mask = pos.str.contains("CPT|CAPTAIN", regex=True)
        flex_mask = ~cpt_mask
        base_candidates = pd.to_numeric(g.loc[flex_mask, "SAL"], errors="coerce") if flex_mask.any() else pd.Series(dtype=float)
        base_salary = float(base_candidates.min()) if len(base_candidates) and base_candidates.notna().any() else float(pd.to_numeric(g["SAL"], errors="coerce").min())
        cpt_candidates = pd.to_numeric(g.loc[cpt_mask, "SAL"], errors="coerce") if cpt_mask.any() else pd.Series(dtype=float)
        cpt_salary = float(cpt_candidates.min()) if len(cpt_candidates) and cpt_candidates.notna().any() else float(round(base_salary * 1.5))
        rec: dict[str, Any] = {"PLAYER": player, "SAL": int(round(base_salary)), "CPT_SAL": int(round(cpt_salary))}
        rec["ID"] = _first_nonempty(g["ID"]) if "ID" in g else ""
        rec["OPPONENT"] = _first_nonempty(g["OPPONENT"]) if "OPPONENT" in g else ""
        rec["MATCHUP"] = _first_nonempty(g["MATCHUP"]) if "MATCHUP" in g else ""
        if not rec["OPPONENT"]:
            rec["OPPONENT"] = _derive_opponent_from_matchup(player, rec["MATCHUP"])
        for col in ("FPTS", "VAL", "RST", "WIN_PROB", "MONEYLINE", "FINISH_PROB", "ITD_ODDS", "SIG_LPM", "SIG_ABS_LPM", "TD_15", "TD_ACC", "TD_DEF", "SUB_15", "CTRL_SEC", "KD_15", "KO_RATE", "SUB_RATE", "ROUNDS"):
            if col in g:
                vals = pd.to_numeric(g[col].astype(str).str.replace("%", "", regex=False).str.replace("$", "", regex=False).str.replace(",", "", regex=False), errors="coerce")
                rec[col] = float(vals.dropna().median()) if vals.notna().any() else np.nan
        records.append(rec)
    f = pd.DataFrame(records)
    f = f.sort_values(["PLAYER", "SAL"], kind="stable").reset_index(drop=True)
    if len(f) < 6:
        raise RuntimeError("RUN_INVALID:MMA_ACTIVE_POOL_LT_6")

    # Reciprocal opponent pairing is a hard fight-integrity requirement. Orphans are
    # excluded rather than assigned synthetic opponents.
    name_to_i = {_norm(n): i for i, n in enumerate(f["PLAYER"].astype(str))}
    opp = np.full(len(f), -1, dtype=np.int32)
    for i, row in f.iterrows():
        j = name_to_i.get(_norm(row.get("OPPONENT", "")), -1)
        if j >= 0 and j != i:
            opp[i] = j
    reciprocal = np.asarray([j >= 0 and opp[j] == i for i, j in enumerate(opp)], dtype=bool)
    orphan_names = f.loc[~reciprocal, "PLAYER"].astype(str).tolist()
    if (~reciprocal).any():
        f = f.loc[reciprocal].reset_index(drop=True)
        name_to_i = {_norm(n): i for i, n in enumerate(f["PLAYER"].astype(str))}
        opp = np.full(len(f), -1, dtype=np.int32)
        for i, row in f.iterrows():
            j = name_to_i.get(_norm(row.get("OPPONENT", "")), -1)
            if j >= 0 and j != i:
                opp[i] = j
    if len(f) < 6 or np.any(opp < 0):
        raise RuntimeError("RUN_INVALID:MMA_RECIPROCAL_FIGHT_POOL_LT_6")

    ids: list[str] = []
    for _, row in f.iterrows():
        rid = str(row.get("ID", "") or "").strip()
        ids.append(rid if rid and rid.lower() != "nan" else hashlib.sha256(f"{_norm(row['PLAYER'])}|{_norm(row['OPPONENT'])}|{int(row['SAL'])}".encode()).hexdigest()[:16])

    salary = f["SAL"].to_numpy(dtype=np.int32)
    cpt_salary = f["CPT_SAL"].to_numpy(dtype=np.int32)

    # Global predictive-market layer freezes before the sports strategist; Phase 1
    # consumes only its derived strategy outputs plus sport-native rates below.
    sf = f.copy()
    sf["WIN %"] = sf.get("WIN_PROB", np.nan)
    sf["FINISH %"] = sf.get("FINISH_PROB", np.nan)
    sf["PACE"] = sf.get("SIG_LPM", np.nan)
    strategy = global_strategy.build_strategy_features(sf, sport="MMA", mode=mode)

    raw_win = _prob(_num_series(f, "WIN_PROB"))
    mlp = _american_prob(_num_series(f, "MONEYLINE"))
    raw_win = np.where(np.isfinite(raw_win), raw_win, mlp)
    # Salary is only a neutral within-fight prior when no direct win signal exists.
    for i in range(len(f)):
        j = int(opp[i])
        if not np.isfinite(raw_win[i]):
            raw_win[i] = 1.0 / (1.0 + math.exp(-(float(salary[i]) - float(salary[j])) / 1200.0))
    for i in range(len(f)):
        j = int(opp[i])
        if i < j:
            s = float(raw_win[i] + raw_win[j])
            if not math.isfinite(s) or s <= 0:
                raw_win[i] = raw_win[j] = 0.5
            else:
                raw_win[i] /= s
                raw_win[j] /= s
    leverage = np.asarray(strategy.strategic_leverage, dtype=np.float64)
    win_prob = np.clip(0.96 * raw_win + 0.04 * (0.35 + 0.30 * leverage), 0.03, 0.97)
    for i in range(len(f)):
        j = int(opp[i])
        if i < j:
            s = win_prob[i] + win_prob[j]
            win_prob[i], win_prob[j] = win_prob[i] / s, win_prob[j] / s

    finish = _prob(_num_series(f, "FINISH_PROB"))
    itd = _american_prob(_num_series(f, "ITD_ODDS"))
    finish = np.where(np.isfinite(finish), finish, itd)
    finish = _impute(finish, 0.45, lo=0.05, hi=0.95)
    finish = np.clip(0.94 * finish + 0.06 * (0.25 + 0.55 * leverage), 0.04, 0.96)

    sig_lpm = _impute(_num_series(f, "SIG_LPM"), 3.2, lo=0.3, hi=10.0)
    sig_abs = _impute(_num_series(f, "SIG_ABS_LPM"), 3.0, lo=0.3, hi=10.0)
    td15 = _impute(_num_series(f, "TD_15"), 1.2, lo=0.0, hi=12.0)
    td_acc = _prob(_num_series(f, "TD_ACC")); td_acc = _impute(td_acc, 0.40, lo=0.02, hi=0.95)
    td_def = _prob(_num_series(f, "TD_DEF")); td_def = _impute(td_def, 0.65, lo=0.02, hi=0.99)
    sub15 = _impute(_num_series(f, "SUB_15"), 0.45, lo=0.0, hi=6.0)
    ctrl = _impute(_num_series(f, "CTRL_SEC"), 55.0, lo=0.0, hi=900.0)
    kd15 = _impute(_num_series(f, "KD_15"), 0.30, lo=0.0, hi=5.0)
    ko = _prob(_num_series(f, "KO_RATE")); ko = _impute(ko, 0.45, lo=0.02, hi=0.98)
    sub = _prob(_num_series(f, "SUB_RATE")); sub = _impute(sub, 0.22, lo=0.01, hi=0.95)
    rounds = _impute(_num_series(f, "ROUNDS"), 3.0, lo=3.0, hi=5.0).round().astype(np.int16)
    ownership = _prob(_num_series(f, "RST"))
    if not np.isfinite(ownership).any():
        ownership = 0.08 + 0.45 * _pct(win_prob).astype(np.float64)
    ownership = _impute(ownership, 0.20, lo=0.005, hi=0.95)

    fight_id = np.empty(len(f), dtype=object)
    for i in range(len(f)):
        j = int(opp[i])
        fight_id[i] = "|".join(sorted((ids[i], ids[j])))

    return MMASlate(
        frame=f,
        names=tuple(f["PLAYER"].astype(str)), ids=tuple(ids), salary=salary, cpt_salary=cpt_salary,
        opponent_index=opp, fight_id=fight_id, win_prob=win_prob.astype(np.float32), finish_prob=finish.astype(np.float32),
        sig_lpm=sig_lpm.astype(np.float32), sig_abs_lpm=sig_abs.astype(np.float32), td15=td15.astype(np.float32),
        td_acc=td_acc.astype(np.float32), td_def=td_def.astype(np.float32), sub15=sub15.astype(np.float32),
        ctrl_sec=ctrl.astype(np.float32), kd15=kd15.astype(np.float32), ko_rate=ko.astype(np.float32), sub_rate=sub.astype(np.float32),
        rounds=rounds, ownership=ownership.astype(np.float32), strategy_leverage=leverage.astype(np.float32),
        strategy_receipt=dict(strategy.receipt), pool_sha256=sha256_file(path), out_names=out_names, orphan_names=orphan_names,
    )


def simulate_phase1(slate: MMASlate, cfg: MMAConfig) -> Phase1:
    cfg.validate()
    rng = np.random.default_rng(cfg.seed)
    t, n = cfg.player_trials, len(slate.names)
    scores = np.zeros((t, n), dtype=np.float32)
    wins = np.zeros((t, n), dtype=np.bool_)
    finishes = np.zeros((t, n), dtype=np.bool_)

    for i in range(n):
        j = int(slate.opponent_index[i])
        if i > j:
            continue
        p_i = float(slate.win_prob[i])
        i_win = rng.random(t) < p_i
        wins[:, i] = i_win
        wins[:, j] = ~i_win
        fp = np.where(i_win, float(slate.finish_prob[i]), float(slate.finish_prob[j]))
        finish = rng.random(t) < fp
        finishes[:, i] = finish & i_win
        finishes[:, j] = finish & (~i_win)
        sched = int(max(slate.rounds[i], slate.rounds[j]))
        # Earlier rounds carry more finish mass while preserving nonzero late-round tails.
        w = np.exp(-0.48 * np.arange(sched, dtype=np.float64))
        w /= w.sum()
        u = rng.random(t)
        cum = np.cumsum(w)
        finish_round = np.searchsorted(cum, u, side="right") + 1
        sec_in_round = rng.uniform(15.0, 295.0, size=t)
        duration = np.where(finish, (finish_round - 1) * 300.0 + sec_in_round, sched * 300.0)
        duration_min = duration / 60.0

        pair_pace = np.clip((float(slate.sig_lpm[i]) + float(slate.sig_lpm[j])) / 6.4, 0.65, 1.55)
        for a, b, a_win in ((i, j, i_win), (j, i, ~i_win)):
            strat = 0.94 + 0.12 * float(slate.strategy_leverage[a])
            offense = float(slate.sig_lpm[a])
            defense = float(slate.sig_abs_lpm[b])
            strike_rate = max(0.20, 0.62 * offense + 0.38 * defense) * pair_pace * strat
            sig = rng.poisson(np.clip(strike_rate * duration_min, 0.0, 250.0)).astype(np.float32)
            total = sig + rng.poisson(np.clip(sig * 0.45, 0.0, 160.0)).astype(np.float32)

            td_eff = float(slate.td15[a]) * (0.45 + 0.75 * float(slate.td_acc[a])) * (1.15 - 0.75 * float(slate.td_def[b]))
            td = rng.poisson(np.clip(td_eff * duration / 900.0, 0.0, 20.0)).astype(np.float32)
            sub_att = rng.poisson(np.clip(float(slate.sub15[a]) * duration / 900.0, 0.0, 10.0)).astype(np.float32)
            rev = rng.binomial(1, np.clip(0.015 + 0.025 * sub_att, 0.0, 0.20)).astype(np.float32)
            control_base = (float(slate.ctrl_sec[a]) / 900.0) * duration
            control = np.minimum(duration * 0.85, rng.gamma(shape=1.3 + 0.55 * td, scale=np.maximum(4.0, control_base / (1.3 + 0.55 * td)))).astype(np.float32)

            kd_rate = max(0.0, float(slate.kd15[a])) * duration / 900.0
            ko_finish = finish & a_win & (rng.random(t) < np.clip(float(slate.ko_rate[a]) / max(float(slate.ko_rate[a] + slate.sub_rate[a]), 1e-6), 0.08, 0.92))
            kd = rng.poisson(np.clip(kd_rate + ko_finish.astype(np.float64) * 0.65, 0.0, 6.0)).astype(np.float32)

            base = 0.2 * total + 0.2 * sig + 5.0 * td + 5.0 * rev + 10.0 * kd + 0.03 * control
            decision_win = a_win & (~finish)
            bonus = np.zeros(t, dtype=np.float32)
            bonus[decision_win] = 30.0
            if finish.any():
                fr = finish_round
                bonus[finish & a_win & (fr == 1)] = 90.0
                bonus[finish & a_win & (fr == 2)] = 70.0
                bonus[finish & a_win & (fr == 3)] = 45.0
                bonus[finish & a_win & (fr >= 4)] = 40.0
                quick = finish & a_win & (fr == 1) & (sec_in_round <= 60.0)
                bonus[quick] += 25.0
            scores[:, a] = base + bonus

    p95 = np.quantile(scores, 0.95, axis=0).astype(np.float32)
    p99 = np.quantile(scores, 0.99, axis=0).astype(np.float32)
    q99 = p99.astype(np.float64)
    cvar = np.asarray([float(scores[:, k][scores[:, k] >= q99[k]].mean()) if np.any(scores[:, k] >= q99[k]) else float(q99[k]) for k in range(n)], dtype=np.float32)
    empirical_win = wins.mean(axis=0).astype(np.float32)
    empirical_finish = finishes.mean(axis=0).astype(np.float32)
    metric_hash = hashlib.sha256(scores.tobytes() + wins.tobytes() + finishes.tobytes()).hexdigest()
    return Phase1(scores, wins, finishes, p95, p99, cvar, empirical_win, empirical_finish, metric_hash)


def _lineup_features(rows: np.ndarray, slate: MMASlate, p1: Phase1, mode: str) -> tuple[np.ndarray, ...]:
    if not len(rows):
        z = np.asarray([], dtype=np.float32)
        return z, z, z, z, z, z.astype(np.int16), z.astype(np.int16), z.astype(np.int16)
    mult = np.ones(rows.shape, dtype=np.float32)
    if mode == "SHOWDOWN":
        mult[:, 0] = 1.5
    tail = (p1.player_p99[rows] * mult).sum(axis=1)
    cvar = (p1.player_cvar99[rows] * mult).sum(axis=1)
    wf = ((p1.empirical_win[rows] * 40.0 + p1.empirical_finish[rows] * 65.0) * mult).sum(axis=1) + 0.35 * tail
    leverage = ((1.0 - slate.ownership[rows]) * (p1.player_p99[rows] / np.maximum(slate.salary[rows] / 1000.0, 1.0)) * mult).sum(axis=1)
    logdup = np.log(np.clip(slate.ownership[rows], 0.005, 0.95)).sum(axis=1)
    duplication = np.exp(np.clip(logdup, -30.0, 0.0)).astype(np.float32)
    dogs = (slate.win_prob[rows] < 0.5).sum(axis=1).astype(np.int16)
    pair_count = np.zeros(len(rows), dtype=np.int16)
    distinct = np.zeros(len(rows), dtype=np.int16)
    for r, row in enumerate(rows):
        fids = slate.fight_id[row]
        _, counts = np.unique(fids, return_counts=True)
        pair_count[r] = int(np.sum(counts // 2))
        distinct[r] = int(len(counts))
    return tail.astype(np.float32), cvar.astype(np.float32), wf.astype(np.float32), leverage.astype(np.float32), duplication, dogs, pair_count, distinct


def _salary_for_rows(rows: np.ndarray, slate: MMASlate, mode: str) -> np.ndarray:
    if mode == "SHOWDOWN":
        return (slate.cpt_salary[rows[:, 0]] + slate.salary[rows[:, 1:]].sum(axis=1)).astype(np.int32)
    return slate.salary[rows].sum(axis=1).astype(np.int32)


def _iter_candidate_batches(n: int, mode: str, batch_size: int = 50_000):
    buf: list[tuple[int, ...]] = []
    if mode == "CLASSIC":
        source = itertools.combinations(range(n), 6)
        for c in source:
            buf.append(c)
            if len(buf) >= batch_size:
                yield np.asarray(buf, dtype=np.int16); buf.clear()
    else:
        for cpt in range(n):
            rest = [x for x in range(n) if x != cpt]
            for flex in itertools.combinations(rest, 5):
                buf.append((cpt, *flex))
                if len(buf) >= batch_size:
                    yield np.asarray(buf, dtype=np.int16); buf.clear()
    if buf:
        yield np.asarray(buf, dtype=np.int16)


def build_phase2(slate: MMASlate, p1: Phase1, cfg: MMAConfig, *, mode: str) -> Phase2:
    if mode not in {"CLASSIC", "SHOWDOWN"}:
        raise ValueError(mode)
    kept: dict[tuple[int, ...], tuple[float, ...]] = {}
    legal_scan = 0
    per_lane = max(400, min(3000, cfg.phase2_max // 8))

    for batch in _iter_candidate_batches(len(slate.names), mode):
        sal = _salary_for_rows(batch, slate, mode)
        legal = sal <= SALARY_CAP
        if not legal.any():
            continue
        rows = batch[legal]
        sal = sal[legal]
        legal_scan += len(rows)
        tail, cvar, wf, lev, dup, dogs, pairs, distinct = _lineup_features(rows, slate, p1, mode)
        # Calibration-qualified birth lanes. No raw projection/mean sort is used.
        lane_scores = (tail, cvar, wf, lev - 20.0 * _pct(dup))
        take: set[int] = set()
        for x in lane_scores:
            k = min(per_lane, len(x))
            if k:
                ix = np.argpartition(x, len(x) - k)[len(x) - k:]
                take.update(map(int, ix))
        # Structural family closure: salary geometry, dog count, opponent-pair count,
        # and fight breadth each retain calibrated siblings.
        salary_band = np.minimum(9, np.maximum(0, ((sal - 35_000) // 1_500))).astype(np.int16)
        finish_count = (p1.empirical_finish[rows] >= np.median(p1.empirical_finish)).sum(axis=1).astype(np.int16)
        fam: dict[tuple[int, int, int, int, int], list[int]] = {}
        for k in range(len(rows)):
            key = (int(salary_band[k]), int(dogs[k]), int(pairs[k]), int(distinct[k]), int(finish_count[k]))
            fam.setdefault(key, []).append(k)
        for idxs in fam.values():
            if len(idxs) <= 4:
                take.update(idxs)
            else:
                a = np.asarray(idxs, dtype=np.int32)
                score = wf[a] + 0.35 * tail[a] + 0.12 * lev[a]
                kk = min(4, len(a))
                take.update(map(int, a[np.argpartition(score, len(a) - kk)[len(a) - kk:]]))
        for k in take:
            row = tuple(map(int, rows[k]))
            quality = (float(wf[k]), float(tail[k]), float(cvar[k]), float(lev[k]), -float(dup[k]), int(sal[k]), int(dogs[k]), int(pairs[k]), int(distinct[k]))
            prev = kept.get(row)
            if prev is None or quality > prev:
                kept[row] = quality

    if legal_scan == 0 or not kept:
        raise RuntimeError("RUN_INVALID:MMA_NO_LEGAL_PHASE2_LINEUPS")
    rows = np.asarray(list(kept), dtype=np.int16)
    sal = _salary_for_rows(rows, slate, mode)
    tail, cvar, wf, lev, dup, dogs, pairs, distinct = _lineup_features(rows, slate, p1, mode)
    # Global deterministic closure to configured Phase2 capacity.
    if len(rows) > cfg.phase2_max:
        candidate: set[int] = set()
        for x in (wf, tail, cvar, lev - 20.0 * _pct(dup)):
            k = min(max(cfg.board_size * 20, cfg.phase2_max // 4), len(rows))
            ix = np.argpartition(x, len(x) - k)[len(x) - k:]
            candidate.update(map(int, ix))
        idx = np.asarray(sorted(candidate), dtype=np.int32)
        if len(idx) > cfg.phase2_max:
            # Lexicographic right-tail cutoff, not a weighted metric sum.
            order = np.lexsort((dup[idx], -lev[idx], -cvar[idx], -tail[idx], -wf[idx]))
            idx = idx[order[:cfg.phase2_max]]
        rows, sal = rows[idx], sal[idx]
        tail, cvar, wf, lev, dup, dogs, pairs, distinct = tail[idx], cvar[idx], wf[idx], lev[idx], dup[idx], dogs[idx], pairs[idx], distinct[idx]

    ids = [[slate.ids[j] for j in row] for row in rows]
    identity_hash = _stable_hash({"mode": mode, "lineups": ids})
    return Phase2(rows, sal, tail, cvar, wf, lev, dup, dogs, pairs, distinct, identity_hash, legal_scan)


def _score_rows_trials(player_scores: np.ndarray, rows: np.ndarray, mode: str, trial_start: int, trial_end: int) -> np.ndarray:
    ps = player_scores[trial_start:trial_end]
    out = ps[:, rows].sum(axis=2, dtype=np.float32)
    if mode == "SHOWDOWN":
        out += 0.5 * ps[:, rows[:, 0]]
    return out


def _field_thresholds(p2: Phase2, p1: Phase1, slate: MMASlate, cfg: MMAConfig, mode: str) -> tuple[np.ndarray, np.ndarray, int]:
    rng = np.random.default_rng(cfg.seed ^ 0x5F3759DF)
    m = len(p2.rows)
    fake_n = int(min(cfg.fake_field_cap, max(256, min(m * 2, cfg.field_size * 4))))
    logw = np.log(np.clip(slate.ownership[p2.rows], 0.005, 0.95)).sum(axis=1)
    if mode == "SHOWDOWN":
        logw += 0.35 * np.log(np.clip(slate.ownership[p2.rows[:, 0]], 0.005, 0.95))
    logw -= np.max(logw)
    w = np.exp(logw)
    if not np.isfinite(w).all() or float(w.sum()) <= 0:
        w = np.ones(m, dtype=np.float64)
    w /= w.sum()
    field_idx = rng.choice(m, size=fake_n, replace=True, p=w)
    field_rows = p2.rows[field_idx]
    tmax = cfg.max_physical_trials
    field_max = np.empty(tmax, dtype=np.float32)
    top01 = np.empty(tmax, dtype=np.float32)
    ktop = max(1, int(math.ceil(fake_n * 0.001)))
    for a in range(0, tmax, 256):
        b = min(tmax, a + 256)
        s = _score_rows_trials(p1.player_scores, field_rows, mode, a, b)
        field_max[a:b] = s.max(axis=1)
        kth = fake_n - ktop
        top01[a:b] = np.partition(s, kth, axis=1)[:, kth]
    return field_max, top01, fake_n


def _wilson(count: np.ndarray, n: int, z: float = 1.96) -> tuple[np.ndarray, np.ndarray]:
    p = count.astype(np.float64) / max(n, 1)
    den = 1.0 + z * z / n
    center = (p + z * z / (2 * n)) / den
    half = z * np.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / den
    return (center - half).astype(np.float32), (center + half).astype(np.float32)


def simulate_phase2(p2: Phase2, p1: Phase1, slate: MMASlate, cfg: MMAConfig, *, mode: str) -> dict[str, Any]:
    field_max, top_thr, fake_n = _field_thresholds(p2, p1, slate, cfg, mode)
    m, base = len(p2.rows), cfg.base_trials
    win_count = np.zeros(m, dtype=np.int32)
    top_count = np.zeros(m, dtype=np.int32)
    p95 = np.zeros(m, dtype=np.float32)
    p99 = np.zeros(m, dtype=np.float32)
    cvar99 = np.zeros(m, dtype=np.float32)

    for a in range(0, m, 256):
        b = min(m, a + 256)
        s = _score_rows_trials(p1.player_scores, p2.rows[a:b], mode, 0, base)
        win_count[a:b] = (s >= field_max[:base, None]).sum(axis=0)
        top_count[a:b] = (s >= top_thr[:base, None]).sum(axis=0)
        p95[a:b] = np.quantile(s, 0.95, axis=0)
        p99[a:b] = np.quantile(s, 0.99, axis=0)
        for k in range(b - a):
            q = p99[a + k]
            vals = s[:, k]
            tail = vals[vals >= q]
            cvar99[a + k] = float(tail.mean()) if len(tail) else float(q)

    top_rate = top_count.astype(np.float64) / base
    win_rate = win_count.astype(np.float64) / base
    pre = np.lexsort((p2.duplication_proxy, -p2.leverage_proxy, -cvar99, -p99, -win_rate, -top_rate))
    cap = min(m, max(64, cfg.board_size * 16))
    cutoff_rank = min(cap - 1, m - 1)
    lo, hi = _wilson(top_count, base)
    cutoff_low = float(lo[pre[cutoff_rank]])
    bubble = np.flatnonzero(hi >= cutoff_low)
    if len(bubble) > max(cap * 4, 512):
        bubble = pre[:max(cap * 4, 512)]
    extra_trials = max(0, cfg.max_physical_trials - base)
    if extra_trials and len(bubble):
        for a in range(0, len(bubble), 128):
            ix = bubble[a:a + 128]
            s = _score_rows_trials(p1.player_scores, p2.rows[ix], mode, 0, cfg.max_physical_trials)
            win_count[ix] = (s >= field_max[:, None]).sum(axis=0)
            top_count[ix] = (s >= top_thr[:, None]).sum(axis=0)
            p95[ix] = np.quantile(s, 0.95, axis=0)
            p99[ix] = np.quantile(s, 0.99, axis=0)
            for k, idx in enumerate(ix):
                q = p99[idx]
                vals = s[:, k]
                tail = vals[vals >= q]
                cvar99[idx] = float(tail.mean()) if len(tail) else float(q)
        denom = np.full(m, base, dtype=np.int32)
        denom[bubble] = cfg.max_physical_trials
    else:
        denom = np.full(m, base, dtype=np.int32)
    top_rate = top_count / denom
    win_rate = win_count / denom
    return {
        "top01_rate": top_rate.astype(np.float32), "win_rate": win_rate.astype(np.float32),
        "p95": p95, "p99": p99, "cvar99": cvar99,
        "fake_field_size": fake_n, "bubble_indices": bubble.astype(np.int32),
        "bubble_found": int(len(bubble)), "bubble_extra_trials_total": int(len(bubble) * extra_trials),
        "bubble_unresolved": 0, "review_trials": denom,
    }


def select_board(p2: Phase2, sim: dict[str, Any], slate: MMASlate, cfg: MMAConfig, *, mode: str) -> tuple[np.ndarray, dict[str, Any]]:
    top = sim["top01_rate"]
    win = sim["win_rate"]
    p99 = sim["p99"]
    cvar = sim["cvar99"]
    # Structural neighborhood admission first; local door selection second.
    if mode == "SHOWDOWN":
        cpt_fight = np.asarray([slate.fight_id[int(r[0])] for r in p2.rows], dtype=object)
        neighborhood = np.asarray([f"{cpt_fight[i]}|D{int(p2.dog_count[i])}|O{int(p2.opponent_pair_count[i])}|F{int(p2.distinct_fights[i])}" for i in range(len(p2.rows))], dtype=object)
    else:
        neighborhood = np.asarray([f"D{int(p2.dog_count[i])}|O{int(p2.opponent_pair_count[i])}|F{int(p2.distinct_fights[i])}" for i in range(len(p2.rows))], dtype=object)
    order, rn_receipt = rn_door.neighborhood_door_order(neighborhood, {"top01_rate":top,"win_rate":win,"p99":p99,"cvar99":cvar,"p95":sim["p95"],"leverage":p2.leverage_proxy,"uniqueness":-p2.duplication_proxy}, {"top01_rate":.24,"win_rate":.14,"p99":.18,"cvar99":.18,"p95":.10,"leverage":.10,"uniqueness":.06})
    full_rank = np.empty(len(order), dtype=np.int32)
    full_rank[order] = np.arange(1, len(order) + 1, dtype=np.int32)
    board: list[int] = []
    overlap_limit = 5
    for idx in order:
        row = set(map(int, p2.rows[idx]))
        if all(len(row & set(map(int, p2.rows[j]))) <= overlap_limit for j in board):
            board.append(int(idx))
            if len(board) >= min(cfg.board_size, len(order)):
                break
    relaxed = False
    if len(board) < min(cfg.board_size, len(order)):
        relaxed = True
        for idx in order:
            if int(idx) not in board:
                board.append(int(idx))
                if len(board) >= min(cfg.board_size, len(order)):
                    break
    return np.asarray(board, dtype=np.int32), {
        "full_order": order.astype(np.int32), "full_rank": full_rank,
        "selector_score": (1.0 - (full_rank - 1) / max(len(full_rank), 1)).astype(np.float32),
        "portfolio_preference_relaxation": relaxed,
        "weighted_metric_sum_used": False, "right_neighborhood_receipt": rn_receipt,
    }


def build_board_records(board_idx: np.ndarray, p2: Phase2, sim: dict[str, Any], sel: dict[str, Any], slate: MMASlate, *, mode: str) -> pd.DataFrame:
    recs: list[dict[str, Any]] = []
    for rank, idx in enumerate(board_idx, start=1):
        row = p2.rows[idx]
        if mode == "SHOWDOWN":
            rec: dict[str, Any] = {"RANK": rank, "CPT": slate.names[int(row[0])]}
            for k, j in enumerate(row[1:], start=1): rec[f"FLEX{k}"] = slate.names[int(j)]
        else:
            rec = {"RANK": rank}
            for k, j in enumerate(row, start=1): rec[f"F{k}"] = slate.names[int(j)]
        rec.update({
            "SALARY": int(p2.salary[idx]), "TOP01_RATE": float(sim["top01_rate"][idx]), "WIN_RATE": float(sim["win_rate"][idx]),
            "P95": float(sim["p95"][idx]), "P99": float(sim["p99"][idx]), "CVAR99": float(sim["cvar99"][idx]),
            "DOG_COUNT": int(p2.dog_count[idx]), "OPPONENT_PAIR_COUNT": int(p2.opponent_pair_count[idx]),
            "DISTINCT_FIGHTS": int(p2.distinct_fights[idx]), "DUPLICATION_PROXY": float(p2.duplication_proxy[idx]),
            "SELECTOR_RANK": int(sel["full_rank"][idx]), "SELECTOR_SCORE": float(sel["selector_score"][idx]),
        })
        recs.append(rec)
    return pd.DataFrame(recs)


def pipeline(pool_path: str | Path, field_size: int, *, mode: str, seed: int | None = None, config: MMAConfig | None = None, verified_out_names: Iterable[str] = ()) -> tuple[pd.DataFrame, dict[str, Any], MMASlate, Phase1, Phase2]:
    resolved_mode = "SHOWDOWN" if _norm(mode) in {"SHOWDOWN", "SD", "CAPTAIN", "CPT"} else "CLASSIC"
    cfg = config or MMAConfig(field_size=int(field_size), seed=int(seed if seed is not None else field_size))
    cfg.validate()
    slate = load_slate(pool_path, mode=resolved_mode, verified_out_names=verified_out_names)
    p1 = simulate_phase1(slate, cfg)
    p2 = build_phase2(slate, p1, cfg, mode=resolved_mode)
    sim = simulate_phase2(p2, p1, slate, cfg, mode=resolved_mode)
    board_idx, sel = select_board(p2, sim, slate, cfg, mode=resolved_mode)
    board = build_board_records(board_idx, p2, sim, sel, slate, mode=resolved_mode)
    phase2_ids = [[slate.ids[j] for j in row] for row in p2.rows]
    full_ledger = [phase2_ids[int(i)] for i in sel["full_order"]]
    receipt = {
        "ENGINE_FAMILY": ENGINE_FAMILY, "SPORT": SPORT, "MODE": resolved_mode, "FIELD_SIZE": int(field_size),
        "ACTIVE_POOL": len(slate.names), "OUT_PURGE": slate.out_names, "ORPHAN_FIGHT_PURGE": slate.orphan_names,
        "LEGAL_LINEUPS_SCANNED": int(p2.legal_scan), "PHASE1_MC_TRIALS": int(cfg.player_trials),
        "PHASE1_CALIBRATION_HASH": p1.metric_hash, "PHASE2_CALIBRATION_HASH": p1.metric_hash, "PHASE3_CALIBRATION_HASH": p1.metric_hash,
        "HANDOFF_CALIBRATION_HASH": p1.metric_hash, "SELECTOR_INPUT_CALIBRATION_HASH": p1.metric_hash,
        "PHASE2_BUILT_LINEUPS": int(len(p2.rows)), "PHASE2_IDENTITY_LEDGER_SHA256": p2.identity_hash,
        "PHASE2_FREEZE_HASH": p2.identity_hash, "PHASE3_INPUT_HASH": p2.identity_hash, "HANDOFF_INPUT_HASH": p2.identity_hash,
        "SELECTOR_INPUT_HASH": p2.identity_hash, "HANDOFF_METRIC_PARITY_CHECK": "PASS",
        "BASE_SIM_TRIALS": int(cfg.base_trials), "BUBBLE_EXTRA_TRIALS_TOTAL": int(sim["bubble_extra_trials_total"]),
        "BUBBLE_LINEUPS_UNRESOLVED": int(sim["bubble_unresolved"]), "HANDOFF_SURVIVORS": int(len(p2.rows)),
        "SELECTOR_REVIEWED_LINEUPS": int(len(p2.rows)), "FULL_REVIEW_LEDGER_ROWS": int(len(full_ledger)),
        "FULL_REVIEW_LEDGER_SHA256": _stable_hash(full_ledger), "POST_PHASE2_MUTATION_COUNT": 0,
        "RAW_AGGREGATE_PROJECTION_PHASE1": "PROHIBITED_WEAK_PRIOR_NOT_CONSUMED_BY_PHASE1",
        "GLOBAL_SPORTS_STRATEGIST_PATCH_ID": slate.strategy_receipt.get("PATCH_ID"),
        "PREDICTIVE_LAYER_PATCH_ID": slate.strategy_receipt.get("PREDICTIVE_LAYER_PATCH_ID"),
        "PREDICTION_HASH": slate.strategy_receipt.get("PREDICTION_HASH"),
        "STRATEGY_CONTRACT_HASH": slate.strategy_receipt.get("CONTRACT_HASH"),
        "MMA_JOINT_FIGHT_POSTERIOR": PATCH_ID, "WEIGHTED_METRIC_SUM_USED": False,
        "FINAL_BOARD_SIZE": int(len(board)), "FINAL_SALARY_RECOMPUTE": board["SALARY"].astype(int).tolist() if len(board) else [],
        "PORTFOLIO_PREFERENCE_RELAXATION": bool(sel["portfolio_preference_relaxation"]),
        "RIGHT_NEIGHBORHOOD_DOOR_SELECTOR": sel.get("right_neighborhood_receipt"),
        "EXECUTION_STATE": "TOOL_PROVEN_EXECUTED",
    }
    if len(board) == 0 and len(p2.rows) > 0:
        raise RuntimeError("ENGINE_INTEGRITY_HALT:MMA_NONEMPTY_PHASE3_ZERO_BOARD")
    return board, receipt, slate, p1, p2
