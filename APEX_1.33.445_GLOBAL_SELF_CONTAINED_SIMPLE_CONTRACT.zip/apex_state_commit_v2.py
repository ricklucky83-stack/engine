from __future__ import annotations
import argparse, base64, hashlib, json, zipfile
from datetime import datetime, timezone
from pathlib import Path
PATCH_ID='APEX_GLOBAL_CONTROL_PLANE_CONTENT_ADDRESSED_REF_PROTOCOL_v1'
VOLATILE_PARTS={'.pytest_cache','__pycache__'}
VOLATILE_SUFFIXES={'.pyc','.pyo'}
class CommitV2Error(RuntimeError): pass

def sha256_bytes(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def sha256_file(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def jdump(x):return json.dumps(x,indent=2,sort_keys=True).encode()+b'\n'
def excluded(rel:str)->bool:
    p=Path(rel);return any(x in VOLATILE_PARTS for x in p.parts) or p.suffix in VOLATILE_SUFFIXES or rel=='bundle_manifest.json'
def load_pointer(p:Path)->dict:
    o=json.loads(p.read_text());
    for k in ('STATE_VERSION','BUNDLE_SHA256','BUNDLE_FILE_ID','BUNDLE_MANIFEST_SHA256'):
        if not o.get(k):raise CommitV2Error('PARENT_POINTER_FIELD_MISSING:'+k)
    return o
def parent_bundle(parent_zip:Path,parent:dict)->tuple[zipfile.ZipFile,dict]:
    if sha256_file(parent_zip)!=str(parent['BUNDLE_SHA256']):raise CommitV2Error('PARENT_BUNDLE_SHA256_MISMATCH')
    z=zipfile.ZipFile(parent_zip)
    m=json.loads(z.read('bundle_manifest.json'))
    if str(m.get('STATE_VERSION'))!=str(parent['STATE_VERSION']):raise CommitV2Error('PARENT_MANIFEST_STATE_MISMATCH')
    if sha256_bytes(z.read('bundle_manifest.json'))!=str(parent['BUNDLE_MANIFEST_SHA256']):raise CommitV2Error('PARENT_MANIFEST_SHA256_MISMATCH')
    return z,m
def stamp_json(raw:bytes,version:str,parent_version:str,change:str)->bytes:
    o=json.loads(raw)
    for k in ('STATE_VERSION','ACTIVE_STATE_VERSION','REGISTRY_STATE_VERSION'):o[k]=version
    o['PARENT_STATE_VERSION']=parent_version;o['CHANGE']=change;o['LAST_CHANGE']=change;o['UPDATED_AT_UTC']=datetime.now(timezone.utc).isoformat()
    return jdump(o)

def validate_registry_contract_shape(raw:bytes, available_files:set[str])->dict:
    try: registry=json.loads(raw)
    except Exception as exc: raise CommitV2Error(f'ENGINE_REGISTRY_INVALID_JSON:{exc}') from exc
    checked=0
    for field,id_key in (('GLOBAL_PATCHES','PATCH_ID'),('GLOBAL_DOCTRINES','DOCTRINE_ID')):
        entries=registry.get(field)
        if not isinstance(entries,list): raise CommitV2Error(f'REGISTRY_SHAPE_INVALID:{field}:NOT_LIST')
        for i,rec in enumerate(entries):
            if not isinstance(rec,dict): raise CommitV2Error(f'REGISTRY_SHAPE_INVALID:{field}:{i}:NOT_OBJECT')
            rid=rec.get(id_key)
            if not isinstance(rid,str) or not rid.strip(): raise CommitV2Error(f'REGISTRY_SHAPE_INVALID:{field}:{i}:{id_key}_MISSING')
            contract=rec.get('CONTRACT_FILE')
            if not isinstance(contract,str) or not contract.strip(): raise CommitV2Error(f'REGISTRY_SHAPE_INVALID:{field}:{i}:CONTRACT_FILE_MISSING:{rid}')
            if contract not in available_files: raise CommitV2Error(f'REGISTRY_CONTRACT_MISSING:{field}:{i}:{rid}:{contract}')
            checked += 1
    return {'STATUS':'PASS','RECORDS':checked}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--parent-pointer',required=True);ap.add_argument('--parent-zip',required=True);ap.add_argument('--overlay-root',required=True);ap.add_argument('--version',required=True);ap.add_argument('--out-dir',required=True);ap.add_argument('--change',default=PATCH_ID);ap.add_argument('--compression-level',type=int,default=1);a=ap.parse_args()
    parent=load_pointer(Path(a.parent_pointer));pz,pm=parent_bundle(Path(a.parent_zip),parent);overlay=Path(a.overlay_root);out=Path(a.out_dir);out.mkdir(parents=True,exist_ok=True)
    # Parent manifest is cryptographic authority for untouched members. Overlay is the only mutation surface.
    files=dict(pm.get('FILES') or {});payload={}
    for p in overlay.rglob('*'):
        if not p.is_file():continue
        rel=p.relative_to(overlay).as_posix()
        if excluded(rel):continue
        payload[rel]=p.read_bytes()
    # semantic authorities are always derived, never manually version-edited
    for rel in ('engine_registry.json','state_contract.json'):
        raw=payload.get(rel,pz.read(rel));payload[rel]=stamp_json(raw,a.version,str(parent['STATE_VERSION']),a.change)
    registry_gate=validate_registry_contract_shape(payload['engine_registry.json'], set(files)|set(payload))
    # hash changed/new overlay only; untouched parent hashes are reused from verified immutable bundle
    for rel,b in payload.items():files[rel]={'bytes':len(b),'sha256':sha256_bytes(b)}
    manifest={'STATE_ID':'APEX_GLOBAL_STATE','STATE_VERSION':a.version,'PARENT_STATE_VERSION':parent['STATE_VERSION'],'PARENT_BUNDLE_FILE_ID':parent['BUNDLE_FILE_ID'],'PARENT_BUNDLE_SHA256':parent['BUNDLE_SHA256'],'STATUS':'SEALED_PENDING_DRIVE_ACTIVATION','COMMIT_PROTOCOL':PATCH_ID,'CREATED_AT_UTC':datetime.now(timezone.utc).isoformat(),'FILES':dict(sorted(files.items()))}
    manifest_bytes=jdump(manifest)
    zp=out/f'APEX_GLOBAL_STATE_BUNDLE_v{a.version}.zip'
    names=set(files)|{'bundle_manifest.json'}
    with zipfile.ZipFile(zp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=max(0,min(9,a.compression_level))) as w:
        for rel in sorted(names):
            if rel=='bundle_manifest.json':data=manifest_bytes
            elif rel in payload:data=payload[rel]
            else:data=pz.read(rel)
            w.writestr(rel,data)
    bp=out/f'APEX_GLOBAL_STATE_BUNDLE_v{a.version}.b64.txt';bp.write_bytes(base64.b64encode(zp.read_bytes())+b'\n')
    receipt={'STATE_VERSION':a.version,'PARENT_STATE_VERSION':parent['STATE_VERSION'],'PATCH_ID':PATCH_ID,'CHANGED_FILES_HASHED':len(payload),'PARENT_HASHES_REUSED':len(files)-len(payload),'CONTENT_ADDRESSED_PARENT_REUSE':'PASS','PARENT_BUNDLE_SHA256_CHECK':'PASS','REGISTRY_CONTRACT_SHAPE_GATE':registry_gate,'BUNDLE_SHA256':sha256_file(zp),'ENCODED_SHA256':sha256_file(bp),'BUNDLE_MANIFEST_SHA256':sha256_bytes(manifest_bytes),'COMPRESSION_LEVEL':a.compression_level}
    rp=out/f'APEX_GLOBAL_STATE_COMMIT_RECEIPT_v{a.version}.json';rp.write_bytes(jdump(receipt));print(json.dumps(receipt,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
