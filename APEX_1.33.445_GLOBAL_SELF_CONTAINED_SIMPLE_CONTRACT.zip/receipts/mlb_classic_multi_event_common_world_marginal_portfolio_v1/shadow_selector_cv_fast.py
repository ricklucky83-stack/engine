from pathlib import Path
import csv,json,math,sys
import numpy as np
ROOT=Path('/mnt/data/apex_state_1_33_92'); ENG=ROOT/'engines/mlb'; sys.path.insert(0,str(ENG))
import mlb_advisor_tail_selector_v1 as advisor
import mlb_classic_noninferior_trophy_portfolio_selector_v1 as parent
CV=Path('/mnt/data/mlb_1411_shadow_cv'); ROST=Path('/mnt/data/mlb_1411_candidate_rosters/selector_candidate_rosters.csv')
files=sorted(CV.glob('seed_*/common_worlds.npz')); Z=[np.load(p,allow_pickle=False) for p in files]
ids=Z[0]['candidate_ids'].astype(str); N=len(ids); worlds=int(Z[0]['common_worlds'][0]); K=len(Z)
POP=np.unpackbits(np.arange(256,dtype=np.uint8)[:,None],axis=1).sum(axis=1).astype(np.int16)
players=[]
with ROST.open(newline='',encoding='utf-8') as f:
 for r in csv.DictReader(f): players.append(tuple(r[f'PID{k}'] for k in range(1,11)))
def count_bits(a): return POP[a].sum(axis=1).astype(np.int64)
def lcb(k,n):
 p=k/n; se=np.sqrt(np.maximum(p*(1-p),1e-12)/n); return np.maximum(0,p-1.959963984540054*se)
def union_hits(bits,pos):
 c=np.zeros(bits.shape[1],dtype=np.uint8)
 for j in pos:c|=bits[j]
 return int(POP[c].sum())
def maxov(j,sel):
 s=set(players[j]); return 0 if not sel else max(len(s.intersection(players[k])) for k in sel)
# Cache each LOOCV training fold once.
foldcache=[]
for h in range(K):
 tr=[s for s in range(K) if s!=h]
 wb=np.concatenate([Z[s]['win_bits'] for s in tr],axis=1); b01=np.concatenate([Z[s]['top01_bits'] for s in tr],axis=1); b1=np.concatenate([Z[s]['top1_bits'] for s in tr],axis=1)
 nw=len(tr)*worlds; kw=count_bits(wb); k01=count_bits(b01); k1=count_bits(b1); wr=kw/nw; r01=k01/nw; r1=k1/nw; lc=lcb(k01,nw)
 p99=np.mean(np.stack([Z[s]['p99'] for s in tr]),axis=0); cv=np.mean(np.stack([Z[s]['cvar99'] for s in tr]),axis=0)
 tiers,delta,ldelta=parent.quality_tiers({'top01_rate':r01,'top01_lcb':lc},context=advisor.context_profile(1411,2,nw))
 foldcache.append(dict(h=h,tr=tr,wb=wb,b01=b01,b1=b1,nw=nw,wr=wr,r01=r01,r1=r1,lc=lc,p99=p99,cv=cv,tiers=tiers,delta=delta,ldelta=ldelta))

def select_fc(fc,wt):
 wb,b01,b1=fc['wb'],fc['b01'],fc['b1']; tiers=fc['tiers']; lc,wr,r01,cv,p99=fc['lc'],fc['wr'],fc['r01'],fc['cv'],fc['p99']
 sel=[]; marg=[]; cw=np.zeros(wb.shape[1],np.uint8); c01=np.zeros(b01.shape[1],np.uint8); c1=np.zeros(b1.shape[1],np.uint8)
 for tier in sorted(set(map(int,tiers))):
  pool=[j for j in range(N) if int(tiers[j])==tier and j not in sel]
  while pool and len(sel)<5:
   if not sel:
    j=min(pool,key=lambda x:(-lc[x],-wr[x],-r01[x],-cv[x],-p99[x],ids[x])); gw=union_hits(wb,[j]); g01=union_hits(b01,[j]); g1=union_hits(b1,[j])
   else:
    arr=np.asarray(pool,dtype=np.int64); iw=np.bitwise_not(cw); i01=np.bitwise_not(c01); i1=np.bitwise_not(c1)
    gwv=POP[np.bitwise_and(wb[arr],iw)].sum(axis=1).astype(np.int64); g01v=POP[np.bitwise_and(b01[arr],i01)].sum(axis=1).astype(np.int64); g1v=POP[np.bitwise_and(b1[arr],i1)].sum(axis=1).astype(np.int64)
    score=wt[0]*gwv+wt[1]*g01v+wt[2]*g1v; best=score.max(); qs=np.flatnonzero(score==best)
    qi=min(qs,key=lambda q:(maxov(pool[int(q)],sel),-lc[pool[int(q)]],-wr[pool[int(q)]],-r01[pool[int(q)]],-cv[pool[int(q)]],-p99[pool[int(q)]],ids[pool[int(q)]]))
    j=pool[int(qi)]; gw=int(gwv[int(qi)]); g01=int(g01v[int(qi)]); g1=int(g1v[int(qi)])
   sel.append(j); marg.append((gw,g01,g1,int(tier))); cw|=wb[j]; c01|=b01[j]; c1|=b1[j]; pool.remove(j)
  if len(sel)>=5: break
 return sel,marg

def evaluate(pos,h): return union_hits(Z[h]['win_bits'],pos),union_hits(Z[h]['top01_bits'],pos),union_hits(Z[h]['top1_bits'],pos)

grid=[(ww,1.0,w1) for ww in (0.5,1,1.5,2,3,4,6,8,12,16) for w1 in (0,0.01,0.025,0.05,0.075,0.1,0.15,0.2)]
res=[]
for wt in grid:
 folds=[]
 for h,fc in enumerate(foldcache):
  pos,m=select_fc(fc,wt); ev=evaluate(pos,h); folds.append(dict(seed=int(Z[h]['seed'][0]),ids=[ids[j] for j in pos],holdout_win=ev[0],holdout_top01=ev[1],holdout_top1=ev[2],marginal_train=m,tier0=int((fc['tiers']==0).sum())))
 sw=sum(x['holdout_win'] for x in folds); s01=sum(x['holdout_top01'] for x in folds); s1=sum(x['holdout_top1'] for x in folds)
 res.append(dict(weights=wt,win_hits=sw,top01_hits=s01,top1_hits=s1,win_rate=sw/(K*worlds),top01_rate=s01/(K*worlds),top1_rate=s1/(K*worlds),folds=folds))
res.sort(key=lambda x:(-x['win_hits'],-x['top01_hits'],-x['top1_hits'],x['weights']))
best=res[0]
# Full 8-seed training cache
wb=np.concatenate([z['win_bits'] for z in Z],axis=1); b01=np.concatenate([z['top01_bits'] for z in Z],axis=1); b1=np.concatenate([z['top1_bits'] for z in Z],axis=1); nw=K*worlds
kw=count_bits(wb); k01=count_bits(b01); wr=kw/nw; r01=k01/nw; lc=lcb(k01,nw); p99=np.mean(np.stack([z['p99'] for z in Z]),axis=0); cv=np.mean(np.stack([z['cvar99'] for z in Z]),axis=0)
tiers,delta,ldelta=parent.quality_tiers({'top01_rate':r01,'top01_lcb':lc},context=advisor.context_profile(1411,2,nw))
fullfc=dict(wb=wb,b01=b01,b1=b1,tiers=tiers,lc=lc,wr=wr,r01=r01,cv=cv,p99=p99)
pos,m=select_fc(fullfc,best['weights']); fullids=[ids[j] for j in pos]
# fixed portfolios
idmap={x:i for i,x in enumerate(ids)}; fixed={'native5':['L000040','L000018','L000003','L000251','L000296'],'proposal300':['L000040','L000003','L000018','L000251','L000300'],'prior_joint5':['L000006','L000001','L000016','L000004','L000036']}
fe={}
for n,ls in fixed.items():
 p=[idmap[x] for x in ls]; vals=[evaluate(p,h) for h in range(K)]; fe[n]=dict(ids=ls,win_hits=sum(x[0] for x in vals),top01_hits=sum(x[1] for x in vals),top1_hits=sum(x[2] for x in vals),win_rate=sum(x[0] for x in vals)/(K*worlds),top01_rate=sum(x[1] for x in vals)/(K*worlds),top1_rate=sum(x[2] for x in vals)/(K*worlds),per_seed=vals)
out=dict(seeds=[int(z['seed'][0]) for z in Z],worlds_per_seed=worlds,candidates=N,grid_size=len(grid),best=best,full_data_portfolio=dict(ids=fullids,marginal_all=m,tier0_count=int((tiers==0).sum()),primary_delta=delta,lcb_delta=ldelta),fixed=fe,top15=[{k:v for k,v in r.items() if k!='folds'} for r in res[:15]])
(CV/'cross_validation_receipt.json').write_text(json.dumps(out,indent=2))
print('BEST',best['weights'],'W',best['win_hits'],'T01',best['top01_hits'],'T1',best['top1_hits'])
print('FULL',fullids,'MARG',m,'TIER0',int((tiers==0).sum()))
print('FIXED')
for n,v in fe.items(): print(n,v['win_hits'],v['top01_hits'],v['top1_hits'],v['win_rate'],v['top01_rate'])
print('TOP15')
for r in res[:15]: print(r['weights'],r['win_hits'],r['top01_hits'],r['top1_hits'])
