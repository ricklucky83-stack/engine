"""
APEX_SIMPLE_ENGINE_CONTRACT_v1
State: 1.33.445 — GLOBAL CPT LANE COVERAGE GUARD + FULL FAMILY CLOSURE + ORDINAL CHECKOFF

Locked production route:
LOAD CURRENT NOTION AUTHORITY
-> ENGINE READBACK / HASH RECEIPT
-> CONFIGURED MC COUNT LOCK
-> EXACT WORLD LEDGER LOCK
-> 0. MC FIRST
-> 1. CHAMPIONSHIP FAMILY DISCOVERY / RUBIK'S-CUBE HEAT SEEKER
-> 2. CPT LANE COVERAGE GUARD
-> 3. STACK SHAPE COVERAGE GUARD
-> 4. PUNT-FILLER BRANCH GUARD
-> 5. FULL FAMILY CLOSURE
-> 6. FAMILY CLOSURE RECEIPT
-> 7. EXACT COMMON-WORLD SCORING
-> 8. .00001 HARD GATE
-> 9. SAME-WORLD DOMINANCE PRUNING
-> 10. NFL ORDINAL / GLOBAL ORDINAL POSTERIOR SCORE
-> 11. ORDINAL ORDERING CHECKOFF
-> FINAL PORTFOLIO = NON-DOMINATED SURVIVOR SET

This module does not implement sport physics. It enforces route order and blocks
caller/chat substitutions such as missing mandatory CPT lanes, absent stack-shape coverage,
absent punt-filler branches, sampled heat-seeker final boards, one-build-per-world
birth, partial family closure, local parameter optimization, live MC-count changes,
capped heat birth, pool shrink, backfill, forced board size, broad legal shuffle birth,
terminal rerank, or partial board output.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from math import ceil, log10
from typing import Any, Callable, Sequence


ENGINE_STATE = "1.33.445_GLOBAL_CPT_LANE_COVERAGE_GUARD"
ROUTE = (
    "LOAD_NOTION__ENGINE_READBACK__CONFIGURED_MC_COUNT__EXACT_WORLD_LEDGER__"
    "MC_FIRST__CHAMPIONSHIP_FAMILY_DISCOVERY__CPT_LANE_COVERAGE_GUARD__"
    "STACK_SHAPE_COVERAGE_GUARD__PUNT_FILLER_BRANCH_GUARD__FULL_FAMILY_CLOSURE__"
    "FAMILY_CLOSURE_RECEIPT__EXACT_COMMON_WORLD_SCORING__.00001_GATE__"
    "SAME_WORLD_DOMINANCE_PRUNE__NFL_ORDINAL__ORDINAL_ORDERING_CHECKOFF"
)
CORE_TIE_BREAK_ORDER = (
    "perfect_raw_count",
    "replacement_pressure",
    "cpt_role_pressure",
    "pair_trio_core_cooccurrence",
    "distinct_world_support",
    "conditional_lift",
    "top3_top10_robustness",
    "true_core_tie",
)


class ApexContractError(RuntimeError):
    """Raised when the locked APEX contract is violated."""


@dataclass(frozen=True)
class FamilyClosureSummary:
    family_count: int
    legal_branch_count: int
    born_branch_count: int
    scored_branch_count: int
    closure_complete: bool


@dataclass(frozen=True)
class CptLaneCoverageSummary:
    ledger_present: bool
    mandatory_cpt_lanes: int
    covered_cpt_lanes: int
    missing_cpt_lanes: tuple[str, ...]
    coverage_complete: bool
    stack_shape_coverage_complete: bool
    punt_filler_branch_coverage_complete: bool


@dataclass(frozen=True)
class LockedApexReceipt:
    notion_loaded: bool
    engine_state: str
    route: str
    engine_readback_present: bool
    engine_readback_state: str
    engine_readback_hash: str | None
    configured_mc_count: int
    mc_first_completed: bool
    mc_worlds: int
    mc_count_locked: bool
    exact_world_ledger_present: bool
    exact_world_ledger_count: int
    local_parameter_optimization_used: bool
    live_mc_count_change_used: bool
    championship_families_identified: int
    cpt_lane_coverage_ledger_present: bool
    cpt_lane_coverage_complete: bool
    mandatory_cpt_lanes: int
    covered_cpt_lanes: int
    missing_cpt_lanes: tuple[str, ...]
    stack_shape_coverage_complete: bool
    punt_filler_branch_coverage_complete: bool
    family_closure_ledger_present: bool
    family_closure_complete: bool
    family_closure_family_count: int
    family_closure_legal_branches: int
    family_closure_born_branches: int
    family_closure_scored_branches: int
    rubiks_cube_builds: int
    exact_scored_builds: int
    gate_threshold: float
    gate_survivors: int
    dominance_pruning_completed: bool
    non_dominated_survivors: int
    ordinal_selector: str
    ordinal_ordering_complete: bool
    ordinal_checkoff_complete: bool
    final_portfolio_size: int
    portfolio_equals_survivor_set: bool
    final_board_allowed: bool
    tie_break_rule: tuple[str, ...]
    true_core_tie_policy: str
    backfill_used: bool
    forced_board_size: bool
    terminal_substitution: bool
    cap_used: bool
    pool_shrunk: bool
    broad_legal_shuffle_used: bool
    sampled_heat_seeker_final_used: bool
    one_build_per_world_final_used: bool
    checkpoint_state: str


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ApexContractError(message)


def _get(obj: Any, name: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def _flag(obj: Any, *names: str) -> bool:
    for name in names:
        value = _get(obj, name, None)
        if bool(value):
            return True
    return False


def _first_value(obj: Any, names: Sequence[str], default: Any = None) -> Any:
    for name in names:
        value = _get(obj, name, None)
        if value is not None:
            return value
    return default


def _count_worlds(mc_result: Any) -> int:
    for key in ("world_count", "mc_worlds", "n_worlds", "num_worlds", "worlds_solved"):
        value = _get(mc_result, key, None)
        if isinstance(value, int):
            return value
    worlds = _extract_world_ledger(mc_result)
    if worlds is not None:
        try:
            return len(worlds)
        except TypeError:
            pass
    return 0


def _extract_world_ledger(mc_result: Any) -> Any:
    return _first_value(
        mc_result,
        (
            "exact_world_ledger",
            "world_ledger",
            "fixed_world_ledger",
            "common_world_ledger",
            "worlds",
        ),
        None,
    )


def _receipt_state(engine_readback: Any) -> tuple[str, str | None]:
    state = _first_value(engine_readback, ("engine_state", "state", "version", "engine_version"), "")
    digest = _first_value(engine_readback, ("engine_hash", "sha256", "git_sha", "commit", "hash"), None)
    return str(state), None if digest is None else str(digest)


def _as_sequence(value: Any, *, label: str) -> Sequence[Any]:
    _require(value is not None, f"{label}_MISSING")
    if isinstance(value, (str, bytes)):
        raise ApexContractError(f"{label}_NOT_SEQUENCE")
    try:
        len(value)
    except TypeError as exc:
        raise ApexContractError(f"{label}_HAS_NO_LEN") from exc
    return value


def _extract_builds(closure_result: Any) -> Sequence[Any]:
    builds = _first_value(
        closure_result,
        (
            "complete_builds",
            "rubiks_cube_builds",
            "closed_builds",
            "family_closed_builds",
            "builds",
            "lineups",
        ),
        None,
    )
    if builds is None and not isinstance(closure_result, dict):
        builds = closure_result
    return _as_sequence(builds, label="FULL_FAMILY_CLOSURE_BUILDS")


def _extract_family_ledger(closure_result: Any) -> Any:
    return _first_value(
        closure_result,
        (
            "family_closure_ledger",
            "closure_ledger",
            "championship_family_ledger",
            "families",
            "family_receipts",
        ),
        None,
    )


def _extract_cpt_lane_coverage_ledger(family_result: Any) -> Any:
    return _first_value(
        family_result,
        (
            "cpt_lane_coverage_ledger",
            "cpt_coverage_ledger",
            "mandatory_cpt_lane_ledger",
            "captain_lane_coverage_ledger",
            "cpt_lanes",
            "captain_lanes",
        ),
        None,
    )


def _records_from_ledger(ledger: Any, *, label: str) -> Sequence[Any]:
    _require(ledger is not None, f"{label}_MISSING")
    if isinstance(ledger, dict):
        records = _first_value(ledger, ("rows", "lanes", "records", "required_lanes", "mandatory_lanes"), None)
    else:
        records = ledger
    _require(records is not None, f"{label}_ROWS_MISSING")
    if isinstance(records, (str, bytes)):
        raise ApexContractError(f"{label}_ROWS_NOT_SEQUENCE")
    try:
        rows = list(records)
    except TypeError as exc:
        raise ApexContractError(f"{label}_ROWS_NOT_ITERABLE") from exc
    _require(len(rows) > 0, f"{label}_ROWS_EMPTY")
    return rows


def _lane_id(row: Any, idx: int) -> str:
    return str(
        _first_value(
            row,
            (
                "lane_id",
                "cpt_lane",
                "captain_lane",
                "cpt_player",
                "captain_player",
                "player_name",
                "name",
            ),
            f"lane_{idx}",
        )
    )


def _row_bool(row: Any, names: Sequence[str], default: bool) -> bool:
    value = _first_value(row, names, None)
    if value is None:
        return default
    return bool(value)


def _validate_cpt_lane_coverage(*, family_result: Any, slate_inputs: Any) -> CptLaneCoverageSummary:
    """
    Global guard between family discovery and full family closure.

    The sport model must declare the mandatory CPT/captain lanes that cannot be
    skipped before closure. For MLB Showdown, this is where pitcher-anchor lanes
    such as a high-salary/high-projection/high-ownership starter are required to
    be discovered and closed into the legal family surface, even when hitter CPT
    tails dominate raw q999 discovery.
    """
    ledger = _extract_cpt_lane_coverage_ledger(family_result)
    rows = _records_from_ledger(ledger, label="CPT_LANE_COVERAGE_LEDGER")

    required_rows: list[Any] = []
    covered_rows: list[Any] = []
    missing: list[str] = []

    for idx, row in enumerate(rows):
        required = _row_bool(
            row,
            (
                "required",
                "mandatory",
                "coverage_required",
                "must_close",
                "closure_required",
                "is_mandatory",
            ),
            True,
        )
        if not required:
            continue
        required_rows.append(row)
        covered = _row_bool(
            row,
            (
                "coverage_complete",
                "covered",
                "discovered",
                "family_discovered",
                "lane_present",
                "present",
                "closed_into_family_surface",
            ),
            False,
        )
        if covered:
            covered_rows.append(row)
        else:
            missing.append(_lane_id(row, idx))

    direct_mandatory = _first_value(
        family_result,
        ("mandatory_cpt_lanes", "required_cpt_lanes", "mandatory_cpt_lane_count", "required_cpt_lane_count"),
        None,
    )
    direct_covered = _first_value(
        family_result,
        ("covered_cpt_lanes", "cpt_lanes_covered", "covered_cpt_lane_count"),
        None,
    )

    mandatory_count = int(direct_mandatory) if direct_mandatory is not None else len(required_rows)
    covered_count = int(direct_covered) if direct_covered is not None else len(covered_rows)

    _require(mandatory_count > 0, "NO_MANDATORY_CPT_LANES_DECLARED")
    _require(covered_count == mandatory_count, "CPT_LANE_COVERAGE_INCOMPLETE")
    _require(len(missing) == 0, "CPT_LANE_COVERAGE_MISSING_REQUIRED_LANE")

    stack_required = bool(
        _first_value(
            family_result,
            ("stack_shape_coverage_required", "team_shape_coverage_required"),
            True,
        )
    )
    stack_complete = bool(
        _first_value(
            family_result,
            ("stack_shape_coverage_complete", "team_shape_coverage_complete", "stack_lanes_covered"),
            False,
        )
    )
    if stack_required:
        _require(stack_complete, "STACK_SHAPE_COVERAGE_INCOMPLETE")

    punt_required = bool(
        _first_value(
            family_result,
            ("punt_filler_branch_required", "punt_filler_coverage_required", "salary_filler_branch_required"),
            True,
        )
    )
    punt_complete = bool(
        _first_value(
            family_result,
            (
                "punt_filler_branch_coverage_complete",
                "punt_filler_coverage_complete",
                "salary_filler_branch_coverage_complete",
                "dead_filler_branch_coverage_complete",
            ),
            False,
        )
    )
    if punt_required:
        _require(punt_complete, "PUNT_FILLER_BRANCH_COVERAGE_INCOMPLETE")

    complete_flag = bool(
        _first_value(
            family_result,
            ("cpt_lane_coverage_complete", "captain_lane_coverage_complete"),
            True,
        )
    )
    _require(complete_flag, "CPT_LANE_COVERAGE_COMPLETE_FLAG_FALSE")

    return CptLaneCoverageSummary(
        ledger_present=True,
        mandatory_cpt_lanes=mandatory_count,
        covered_cpt_lanes=covered_count,
        missing_cpt_lanes=tuple(missing),
        coverage_complete=True,
        stack_shape_coverage_complete=(not stack_required) or stack_complete,
        punt_filler_branch_coverage_complete=(not punt_required) or punt_complete,
    )


def _len_or_int(value: Any, *, default: int | None = None) -> int | None:
    if value is None:
        return default
    if isinstance(value, int):
        return value
    try:
        return len(value)
    except TypeError:
        return default


def _validate_fixed_mc_contract(
    *,
    engine_readback: Any,
    configured_mc_count: int,
    mc_result: Any,
) -> tuple[int, int, str | None]:
    _require(engine_readback is not None, "NO_ENGINE_READBACK")
    readback_state, readback_hash = _receipt_state(engine_readback)
    _require(bool(readback_state), "ENGINE_READBACK_STATE_MISSING")
    _require(configured_mc_count is not None, "NO_CONFIGURED_MC_COUNT_RECEIPT")
    _require(isinstance(configured_mc_count, int), "CONFIGURED_MC_COUNT_NOT_INT")
    _require(configured_mc_count > 0, "CONFIGURED_MC_COUNT_NOT_POSITIVE")

    _require(
        not _flag(
            mc_result,
            "local_parameter_optimization_used",
            "local_param_optimization_used",
            "local_mc_optimization_used",
            "parameter_tuned_live",
        ),
        "LOCAL_PARAMETER_OPTIMIZATION_USED",
    )
    _require(
        not _flag(
            mc_result,
            "live_mc_count_change_used",
            "mc_count_changed_live",
            "changed_mc_count_live",
            "runtime_mc_count_override",
        ),
        "LIVE_MC_COUNT_CHANGE_USED",
    )

    mc_worlds = _count_worlds(mc_result)
    _require(mc_worlds > 0, "MC_FIRST_ZERO_WORLDS")
    _require(mc_worlds == configured_mc_count, "MC_COUNT_MISMATCH")

    requested_worlds = _first_value(
        mc_result,
        ("configured_mc_count", "requested_mc_count", "target_mc_count", "mc_count_receipt"),
        configured_mc_count,
    )
    _require(int(requested_worlds) == configured_mc_count, "MC_COUNT_RECEIPT_CHANGED")

    ledger = _extract_world_ledger(mc_result)
    _require(ledger is not None, "NO_EXACT_WORLD_LEDGER")
    try:
        ledger_count = len(ledger)
    except TypeError as exc:
        raise ApexContractError("EXACT_WORLD_LEDGER_HAS_NO_LEN") from exc
    _require(ledger_count == configured_mc_count, "EXACT_WORLD_LEDGER_COUNT_MISMATCH")

    return mc_worlds, ledger_count, readback_hash


def _extract_family_count(family_result: Any) -> int:
    direct = _first_value(
        family_result,
        ("championship_family_count", "family_count", "families_identified", "n_families"),
        None,
    )
    if direct is not None:
        return int(direct)
    families = _first_value(family_result, ("championship_families", "families", "family_receipts"), None)
    count = _len_or_int(families, default=0)
    return int(count or 0)


def _count_family_branches_from_ledger(ledger: Any, key_names: Sequence[str]) -> int | None:
    if ledger is None:
        return None
    if isinstance(ledger, dict):
        direct = _first_value(ledger, key_names, None)
        if direct is not None:
            return int(direct)
        records = _first_value(ledger, ("families", "family_receipts", "rows"), None)
    else:
        records = ledger
    if records is None:
        return None
    total = 0
    try:
        iterator = list(records)
    except TypeError:
        return None
    for row in iterator:
        value = _first_value(row, key_names, None)
        if value is None:
            return None
        total += int(value)
    return total


def _validate_family_closure(
    *,
    family_result: Any,
    closure_result: Any,
    scored_count: int,
) -> FamilyClosureSummary:
    _require(family_result is not None, "CHAMPIONSHIP_FAMILY_DISCOVERY_RETURNED_NONE")
    family_count = _extract_family_count(family_result)
    _require(family_count > 0, "NO_CHAMPIONSHIP_FAMILIES_IDENTIFIED")

    _require(closure_result is not None, "FULL_FAMILY_CLOSURE_RETURNED_NONE")
    _require(not _flag(closure_result, "checkpointed", "resume_required"), "FULL_FAMILY_CLOSURE_CHECKPOINTED_NO_BOARD")
    _require(not _flag(closure_result, "partial_closure", "incomplete", "not_complete"), "FULL_FAMILY_CLOSURE_INCOMPLETE")
    _require(not _flag(closure_result, "sampled_heat_seeker_final_used", "sampled_surface_final_used"), "SAMPLED_HEAT_SEEKER_FINAL_USED")
    _require(not _flag(closure_result, "one_build_per_world_final_used", "one_lineup_per_world_final_used"), "ONE_BUILD_PER_WORLD_FINAL_USED")
    _require(not _flag(closure_result, "cap_used", "capped", "per_family_cap_used", "per_captain_cap_used"), "FAMILY_CLOSURE_CAP_USED")
    _require(not _flag(closure_result, "pool_shrunk", "player_pool_shrunk"), "FAMILY_CLOSURE_POOL_SHRUNK")
    _require(not _flag(closure_result, "broad_legal_shuffle_used", "legal_shuffle_used", "random_shuffle_used"), "BROAD_LEGAL_SHUFFLE_USED")

    builds = _extract_builds(closure_result)
    born_branch_count = len(builds)
    _require(born_branch_count > 0, "FULL_FAMILY_CLOSURE_BUILDS_EMPTY")

    ledger = _extract_family_ledger(closure_result)
    _require(ledger is not None, "NO_FAMILY_CLOSURE_LEDGER")

    legal_branch_count = _first_value(
        closure_result,
        ("legal_branch_count", "family_legal_branch_count", "total_legal_branches"),
        None,
    )
    if legal_branch_count is None:
        legal_branch_count = _count_family_branches_from_ledger(
            ledger,
            ("legal_branch_count", "legal_branches", "n_legal_branches"),
        )
    _require(legal_branch_count is not None, "FAMILY_LEGAL_BRANCH_COUNT_MISSING")
    legal_branch_count = int(legal_branch_count)

    born_count_receipt = _first_value(
        closure_result,
        ("born_branch_count", "family_born_branch_count", "closed_branch_count", "total_born_branches"),
        None,
    )
    if born_count_receipt is None:
        born_count_receipt = _count_family_branches_from_ledger(
            ledger,
            ("born_branch_count", "born_branches", "closed_branch_count", "n_born_branches"),
        )
    if born_count_receipt is not None:
        _require(int(born_count_receipt) == born_branch_count, "FAMILY_BORN_BRANCH_COUNT_RECEIPT_MISMATCH")

    scored_count_receipt = _first_value(
        closure_result,
        ("scored_branch_count", "family_scored_branch_count", "total_scored_branches"),
        None,
    )
    if scored_count_receipt is None:
        scored_count_receipt = _count_family_branches_from_ledger(
            ledger,
            ("scored_branch_count", "scored_branches", "n_scored_branches"),
        )
    if scored_count_receipt is not None:
        _require(int(scored_count_receipt) == scored_count, "FAMILY_SCORED_BRANCH_COUNT_RECEIPT_MISMATCH")

    _require(legal_branch_count > 0, "FAMILY_LEGAL_BRANCH_COUNT_ZERO")
    _require(legal_branch_count == born_branch_count, "FAMILY_CLOSURE_LEGAL_BORN_MISMATCH")
    _require(legal_branch_count == scored_count, "FAMILY_CLOSURE_LEGAL_SCORED_MISMATCH")

    closure_complete = bool(_first_value(closure_result, ("closure_complete", "full_family_closure_complete"), False))
    if isinstance(ledger, dict):
        ledger_rows = _first_value(ledger, ("families", "family_receipts", "rows"), None)
    else:
        ledger_rows = ledger
    if ledger_rows is not None:
        try:
            rows = list(ledger_rows)
            _require(len(rows) == family_count, "FAMILY_LEDGER_COUNT_MISMATCH")
            for idx, row in enumerate(rows):
                _require(bool(_first_value(row, ("closure_complete", "full_family_closure_complete"), True)), f"FAMILY_{idx}_CLOSURE_FALSE")
                legal = int(_first_value(row, ("legal_branch_count", "legal_branches", "n_legal_branches"), 0))
                born = int(_first_value(row, ("born_branch_count", "born_branches", "closed_branch_count", "n_born_branches"), legal))
                scored = int(_first_value(row, ("scored_branch_count", "scored_branches", "n_scored_branches"), legal))
                _require(legal == born == scored, f"FAMILY_{idx}_BRANCH_COUNT_MISMATCH")
        except TypeError as exc:
            raise ApexContractError("FAMILY_CLOSURE_LEDGER_NOT_ITERABLE") from exc

    _require(closure_complete, "FULL_FAMILY_CLOSURE_COMPLETE_FLAG_FALSE")

    return FamilyClosureSummary(
        family_count=family_count,
        legal_branch_count=legal_branch_count,
        born_branch_count=born_branch_count,
        scored_branch_count=scored_count,
        closure_complete=True,
    )


def exact_mc_rate(raw_count: int, configured_mc_count: int) -> str:
    """
    Preserve native MC resolution. For 20,000 worlds, 1 world = 0.00005,
    so five decimals are retained at minimum.
    """
    _require(configured_mc_count > 0, "CONFIGURED_MC_COUNT_NOT_POSITIVE")
    _require(raw_count >= 0, "RAW_COUNT_NEGATIVE")
    decimals = max(5, int(ceil(log10(configured_mc_count))))
    value = Decimal(raw_count) / Decimal(configured_mc_count)
    quant = Decimal(1).scaleb(-decimals)
    return str(value.quantize(quant, rounding=ROUND_HALF_UP))


def replacement_pressure(winner_score: float, best_legal_score_without_player: float) -> float:
    """WINNER_SCORE - BEST_LEGAL_SCORE_WITHOUT_PLAYER."""
    return float(winner_score) - float(best_legal_score_without_player)


def cpt_role_pressure(perfect_score: float, best_score_with_player_flex_allowed_cpt_forbidden: float) -> float:
    """Separate player necessity from captain/role necessity."""
    return float(perfect_score) - float(best_score_with_player_flex_allowed_cpt_forbidden)


def deterministic_core_tie_key(record: Any) -> tuple[Any, ...]:
    """
    Sort key for fixed-world tie separation without adding simulations.
    Higher values are stronger. If records remain identical, keep TRUE_CORE_TIE.
    """
    perfect_count = _get(record, "perfect_raw_count", _get(record, "number_one_count", 0))
    pressure = _get(record, "replacement_pressure", 0.0)
    cpt_pressure = _get(record, "cpt_role_pressure", _get(record, "role_pressure", 0.0))
    cooccurrence = _get(record, "pair_trio_core_cooccurrence", _get(record, "core_number_one_count", 0))
    distinct_support = _get(record, "distinct_world_support", 0)
    conditional_lift = _get(record, "conditional_lift", 0.0)
    top3 = _get(record, "top3_count", 0)
    top10 = _get(record, "top10_count", 0)
    return (
        perfect_count,
        pressure,
        cpt_pressure,
        cooccurrence,
        distinct_support,
        conditional_lift,
        top3,
        top10,
    )


def run_simple_apex_contract(
    *,
    notion_authority: Any,
    engine_readback: Any,
    configured_mc_count: int,
    slate_inputs: Any,
    mc_first: Callable[..., Any],
    championship_family_discovery: Callable[..., Any],
    full_family_closure: Callable[..., Any],
    exact_common_world_score: Callable[..., Sequence[Any]],
    is_00001_success: Callable[[Any], bool],
    same_world_dominance_prune: Callable[..., Sequence[Any]],
    global_ordinal_posterior_score: Callable[..., Sequence[Any]],
) -> tuple[Sequence[Any], LockedApexReceipt]:
    """
    Execute the locked 1.33.445 global route.

    Required proof before any final board:
      - current Notion authority loaded
      - engine readback/version/hash receipt present
      - configured MC count receipt present
      - exact frozen world ledger present
      - actual ledger count equals configured MC count
      - championship families identified from MC-first recurrence
      - mandatory CPT/captain lanes declared and covered before closure
      - required stack-shape and punt-filler branches checked before closure
      - every legal branch inside every championship family enumerated
      - every branch exact-scored on the same frozen world ledger
      - ordinal ordering check-off complete

    Final-board blocker:
      No CPT_LANE_COVERAGE receipt or no FULL_FAMILY_CLOSURE_COMPLETE receipt means CHECKPOINTED / RESUME_REQUIRED / NO BOARD.
    """

    # 0. CURRENT NOTION AUTHORITY + ENGINE READBACK
    _require(notion_authority is not None, "NOTION_AUTHORITY_NOT_LOADED")
    _require(engine_readback is not None, "NO_ENGINE_READBACK")
    readback_state, readback_hash = _receipt_state(engine_readback)
    _require(bool(readback_state), "ENGINE_READBACK_STATE_MISSING")

    # 1. MC FIRST, fixed count, exact ledger
    mc_result = mc_first(
        notion_authority=notion_authority,
        engine_readback=engine_readback,
        configured_mc_count=configured_mc_count,
        slate_inputs=slate_inputs,
    )
    _require(mc_result is not None, "MC_FIRST_RETURNED_NONE")
    mc_worlds, ledger_count, readback_hash = _validate_fixed_mc_contract(
        engine_readback=engine_readback,
        configured_mc_count=configured_mc_count,
        mc_result=mc_result,
    )

    _require(not _flag(mc_result, "cap_used", "capped", "pool_cap_used"), "MC_CAP_USED")
    _require(not _flag(mc_result, "pool_shrunk", "player_pool_shrunk"), "MC_POOL_SHRUNK")

    # 2. CHAMPIONSHIP FAMILY DISCOVERY / RUBIK'S-CUBE HEAT SEEKER
    family_result = championship_family_discovery(
        mc_result=mc_result,
        notion_authority=notion_authority,
        engine_readback=engine_readback,
        configured_mc_count=configured_mc_count,
        slate_inputs=slate_inputs,
    )
    _require(family_result is not None, "CHAMPIONSHIP_FAMILY_DISCOVERY_RETURNED_NONE")
    championship_families_identified = _extract_family_count(family_result)
    _require(championship_families_identified > 0, "NO_CHAMPIONSHIP_FAMILIES_IDENTIFIED")
    _require(not _flag(family_result, "cap_used", "capped", "pool_cap_used"), "FAMILY_DISCOVERY_CAP_USED")
    _require(not _flag(family_result, "pool_shrunk", "player_pool_shrunk"), "FAMILY_DISCOVERY_POOL_SHRUNK")
    _require(not _flag(family_result, "broad_legal_shuffle_used", "legal_shuffle_used", "random_shuffle_used"), "BROAD_LEGAL_SHUFFLE_USED")

    # 3. CPT LANE / STACK SHAPE / PUNT-FILLER COVERAGE. Global pre-closure blocker.
    cpt_summary = _validate_cpt_lane_coverage(
        family_result=family_result,
        slate_inputs=slate_inputs,
    )

    # 4. FULL FAMILY CLOSURE. This is global and mandatory for every sport/slate.
    closure_result = full_family_closure(
        family_result=family_result,
        mc_result=mc_result,
        notion_authority=notion_authority,
        engine_readback=engine_readback,
        configured_mc_count=configured_mc_count,
        slate_inputs=slate_inputs,
    )
    rubiks_cube_builds = _extract_builds(closure_result)

    # 5. EXACT COMMON-WORLD SCORING OF EVERY CLOSED BRANCH
    scored = exact_common_world_score(
        rubiks_cube_builds,
        mc_result=mc_result,
        family_result=family_result,
        closure_result=closure_result,
        notion_authority=notion_authority,
        engine_readback=engine_readback,
        configured_mc_count=configured_mc_count,
        slate_inputs=slate_inputs,
    )
    _require(scored is not None, "EXACT_SCORING_RETURNED_NONE")
    _require(len(scored) == len(rubiks_cube_builds), "EXACT_SCORING_COUNT_MISMATCH")

    family_summary = _validate_family_closure(
        family_result=family_result,
        closure_result=closure_result,
        scored_count=len(scored),
    )

    qualified = [build for build in scored if is_00001_success(build)]

    # Empty board is valid only after full closure and scoring completed. No backfill.
    if len(qualified) == 0:
        receipt = LockedApexReceipt(
            notion_loaded=True,
            engine_state=ENGINE_STATE,
            route=ROUTE,
            engine_readback_present=True,
            engine_readback_state=readback_state,
            engine_readback_hash=readback_hash,
            configured_mc_count=configured_mc_count,
            mc_first_completed=True,
            mc_worlds=mc_worlds,
            mc_count_locked=True,
            exact_world_ledger_present=True,
            exact_world_ledger_count=ledger_count,
            local_parameter_optimization_used=False,
            live_mc_count_change_used=False,
            championship_families_identified=championship_families_identified,
            cpt_lane_coverage_ledger_present=cpt_summary.ledger_present,
            cpt_lane_coverage_complete=cpt_summary.coverage_complete,
            mandatory_cpt_lanes=cpt_summary.mandatory_cpt_lanes,
            covered_cpt_lanes=cpt_summary.covered_cpt_lanes,
            missing_cpt_lanes=cpt_summary.missing_cpt_lanes,
            stack_shape_coverage_complete=cpt_summary.stack_shape_coverage_complete,
            punt_filler_branch_coverage_complete=cpt_summary.punt_filler_branch_coverage_complete,
            family_closure_ledger_present=True,
            family_closure_complete=True,
            family_closure_family_count=family_summary.family_count,
            family_closure_legal_branches=family_summary.legal_branch_count,
            family_closure_born_branches=family_summary.born_branch_count,
            family_closure_scored_branches=family_summary.scored_branch_count,
            rubiks_cube_builds=len(rubiks_cube_builds),
            exact_scored_builds=len(scored),
            gate_threshold=0.00001,
            gate_survivors=0,
            dominance_pruning_completed=True,
            non_dominated_survivors=0,
            ordinal_selector="GLOBAL_ORDINAL_POSTERIOR_SCORE",
            ordinal_ordering_complete=True,
            ordinal_checkoff_complete=True,
            final_portfolio_size=0,
            portfolio_equals_survivor_set=True,
            final_board_allowed=True,
            tie_break_rule=CORE_TIE_BREAK_ORDER,
            true_core_tie_policy="KEEP_TRUE_CORE_TIE_DO_NOT_MANUFACTURE_SEPARATION",
            backfill_used=False,
            forced_board_size=False,
            terminal_substitution=False,
            cap_used=False,
            pool_shrunk=False,
            broad_legal_shuffle_used=False,
            sampled_heat_seeker_final_used=False,
            one_build_per_world_final_used=False,
            checkpoint_state="FINAL_EMPTY_BOARD_VALID",
        )
        return [], receipt

    # 6. SAME-WORLD DOMINANCE PRUNING
    non_dominated = same_world_dominance_prune(
        qualified,
        mc_result=mc_result,
        family_result=family_result,
        closure_result=closure_result,
        notion_authority=notion_authority,
        engine_readback=engine_readback,
        configured_mc_count=configured_mc_count,
        slate_inputs=slate_inputs,
    )
    _require(non_dominated is not None, "DOMINANCE_PRUNE_RETURNED_NONE")
    _require(len(non_dominated) > 0, "DOMINANCE_PRUNE_EMPTY_AFTER_QUALIFIERS")
    _require(len(non_dominated) <= len(qualified), "DOMINANCE_PRUNE_ADDED_BUILDS")
    _require(not _flag(non_dominated, "backfill_used", "backfilled"), "DOMINANCE_PRUNE_BACKFILL_USED")
    _require(not _flag(non_dominated, "forced_board_size", "max_entry_forced"), "DOMINANCE_PRUNE_FORCED_BOARD_SIZE_USED")

    # 7. NFL ORDINAL / GLOBAL ORDINAL POSTERIOR SCORE
    board = global_ordinal_posterior_score(
        non_dominated,
        mc_result=mc_result,
        family_result=family_result,
        closure_result=closure_result,
        notion_authority=notion_authority,
        engine_readback=engine_readback,
        configured_mc_count=configured_mc_count,
        slate_inputs=slate_inputs,
    )
    _require(board is not None, "ORDINAL_RETURNED_NONE")
    _require(len(board) == len(non_dominated), "ORDINAL_DROPPED_OR_ADDED_BUILDS")
    _require(not _flag(board, "terminal_substitution", "ai_rerank_used", "manual_rerank_used"), "TERMINAL_SUBSTITUTION_USED")
    _require(not _flag(board, "forced_board_size", "max_entry_forced"), "FORCED_BOARD_SIZE_USED")
    _require(not _flag(board, "backfill_used", "backfilled"), "BACKFILL_USED")

    # 8. ORDINAL ORDERING CHECKOFF. Explicit receipt field required before final output.
    ordinal_checkoff = bool(
        _first_value(board, ("ordinal_ordering_complete", "ordinal_checkoff_complete"), True)
    )
    _require(ordinal_checkoff, "ORDINAL_ORDERING_CHECKOFF_FALSE")

    receipt = LockedApexReceipt(
        notion_loaded=True,
        engine_state=ENGINE_STATE,
        route=ROUTE,
        engine_readback_present=True,
        engine_readback_state=readback_state,
        engine_readback_hash=readback_hash,
        configured_mc_count=configured_mc_count,
        mc_first_completed=True,
        mc_worlds=mc_worlds,
        mc_count_locked=True,
        exact_world_ledger_present=True,
        exact_world_ledger_count=ledger_count,
        local_parameter_optimization_used=False,
        live_mc_count_change_used=False,
        championship_families_identified=championship_families_identified,
        cpt_lane_coverage_ledger_present=cpt_summary.ledger_present,
        cpt_lane_coverage_complete=cpt_summary.coverage_complete,
        mandatory_cpt_lanes=cpt_summary.mandatory_cpt_lanes,
        covered_cpt_lanes=cpt_summary.covered_cpt_lanes,
        missing_cpt_lanes=cpt_summary.missing_cpt_lanes,
        stack_shape_coverage_complete=cpt_summary.stack_shape_coverage_complete,
        punt_filler_branch_coverage_complete=cpt_summary.punt_filler_branch_coverage_complete,
        family_closure_ledger_present=True,
        family_closure_complete=True,
        family_closure_family_count=family_summary.family_count,
        family_closure_legal_branches=family_summary.legal_branch_count,
        family_closure_born_branches=family_summary.born_branch_count,
        family_closure_scored_branches=family_summary.scored_branch_count,
        rubiks_cube_builds=len(rubiks_cube_builds),
        exact_scored_builds=len(scored),
        gate_threshold=0.00001,
        gate_survivors=len(qualified),
        dominance_pruning_completed=True,
        non_dominated_survivors=len(non_dominated),
        ordinal_selector="GLOBAL_ORDINAL_POSTERIOR_SCORE",
        ordinal_ordering_complete=True,
        ordinal_checkoff_complete=True,
        final_portfolio_size=len(board),
        portfolio_equals_survivor_set=True,
        final_board_allowed=True,
        tie_break_rule=CORE_TIE_BREAK_ORDER,
        true_core_tie_policy="KEEP_TRUE_CORE_TIE_DO_NOT_MANUFACTURE_SEPARATION",
        backfill_used=False,
        forced_board_size=False,
        terminal_substitution=False,
        cap_used=False,
        pool_shrunk=False,
        broad_legal_shuffle_used=False,
        sampled_heat_seeker_final_used=False,
        one_build_per_world_final_used=False,
        checkpoint_state="FINAL_BOARD_VALID",
    )
    return board, receipt
