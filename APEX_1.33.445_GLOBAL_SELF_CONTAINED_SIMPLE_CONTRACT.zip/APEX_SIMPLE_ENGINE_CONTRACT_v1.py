"""APEX 1.33.445 global simple contract.

This file is declarative authority only. Sport adapters own simulation, roster
legality and scoring. The global pipeline owns championship discovery, exhaustive
closure, exact same-world .00001 admission, same-world dominance and rank-only
ordinal ordering.
"""
from __future__ import annotations

import math

ENGINE_STATE = "1.33.445_GLOBAL_EXACT_SAME_WORLD_TARGET_RANK"
MC_WORLDS = 200_000
DOT00001_THRESHOLD = 0.00001
ORDINAL_AUTHORITY = "GLOBAL_COMPLETE_ORDINAL_EVIDENCE_RANK_v2"
DOMINANCE_TOLERANCE = 1e-6

ROUTE = (
    "MC_200K_FIRST__COMPLETE_LEGAL_CHAMPIONSHIP_DISCOVERY__"
    "RUBIK_EXHAUSTIVE_CHAMPIONSHIP_NEIGHBORHOOD__"
    "EXACT_COMMON_WORLD_SCORING__SAME_WORLD_TARGET_RANK_00001_GATE__"
    "STRICT_SAME_WORLD_DOMINANCE_AFTER_GATE__COMPLETE_ORDINAL_EVIDENCE__"
    "ORDINAL_RANK_ONLY_ALL_SURVIVORS"
)

ORDINAL_EVIDENCE_ORDER = (
    "#1_COUNT",
    "REPLACEMENT_PRESSURE_MEAN",
    "REPLACEMENT_PRESSURE_MEDIAN",
    "REPLACEMENT_PRESSURE_P90",
    "CPT_ROLE_PRESSURE",
    "CPT_#1_COUNT",
    "PAIR_#1_COUNT",
    "TRIO_#1_COUNT",
    "CORE_#1_COUNT",
    "DISTINCT_WORLD_SUPPORT",
    "CONDITIONAL_LIFT",
    "OPPORTUNITY_NORMALIZED_RECURRENCE",
    "TOP3_COUNT",
    "TOP10_COUNT",
)


def target_rank(field_size: int) -> int:
    n = int(field_size)
    if n <= 0:
        raise ValueError("FIELD_SIZE_MUST_BE_POSITIVE")
    return max(1, int(math.ceil(n * DOT00001_THRESHOLD)))


def membership_rule(*, best_same_world_rank: int, field_size: int) -> bool:
    """True iff the complete legal lineup reaches the .00001 target in one world.

    The production pipeline applies this independently across each of the 200,000
    frozen worlds and keeps the lineup when this returns True for at least one world.
    Recurrence/probability is not a membership gate.
    """
    return int(best_same_world_rank) <= target_rank(int(field_size))


GLOBAL_PROHIBITIONS = {
    "restrictive_discovery_pool": True,
    "pre_gate_family_cap": True,
    "pre_gate_branch_cap": True,
    "top_k_closure_cap": True,
    "pre_score_performance_pruning": True,
    "older_selection_pipeline_fallback": True,
    "ordinal_membership_selection": True,
    "exposure_selector": True,
    "forced_board_size": True,
    "backfill": True,
}
