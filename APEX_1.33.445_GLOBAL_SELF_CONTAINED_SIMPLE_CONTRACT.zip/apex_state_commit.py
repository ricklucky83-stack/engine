from __future__ import annotations
import argparse, base64, hashlib, json, os, zipfile
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

EXCLUDE = {'bundle_manifest.json'}
VOLATILE_DIRS = {'.pytest_cache', '__pycache__'}
VOLATILE_SUFFIXES = {'.pyc', '.pyo'}

def excluded(path: Path, root: Path) -> bool:
    if path.name in EXCLUDE:
        return True
    rel = path.relative_to(root)
    if any(part in VOLATILE_DIRS for part in rel.parts):
        return True
    if path.suffix in VOLATILE_SUFFIXES:
        return True
    return False
PERSISTENCE_PATCH_ID = 'APEX_GLOBAL_POST_DIAGNOSTIC_PERSISTENCE_AND_PROMOTION_ENFORCEMENT_v4'
EFFICIENCY_PATCH_ID = 'APEX_GLOBAL_DIAGNOSTIC_NO_LOST_REPAIR_AND_STABLE_POINTER_CAS_v4'

class StateCommitError(RuntimeError): pass

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def increment_patch_version(version: str) -> str:
    parts = version.split('.')
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        raise StateCommitError(f'INVALID_PARENT_STATE_VERSION:{version}')
    return f'{parts[0]}.{parts[1]}.{int(parts[2])+1}'

def load_parent_pointer(path: Path) -> dict:
    if not path.exists():
        raise StateCommitError(f'FRESH_PARENT_POINTER_REQUIRED:{path}')
    data = json.loads(path.read_text(encoding='utf-8'))
    for key in ('STATE_VERSION','BUNDLE_FILE_ID','BUNDLE_SHA256','ENCODED_SHA256'):
        if not data.get(key):
            raise StateCommitError(f'PARENT_POINTER_FIELD_MISSING:{key}')
    return data

def stamp_semantic_authorities(root: Path, version: str, parent_version: str) -> dict:
    stamped = {}
    for name in ('engine_registry.json', 'state_contract.json'):
        p = root / name
        if not p.exists():
            raise StateCommitError(f'SEMANTIC_AUTHORITY_MISSING:{name}')
        obj = json.loads(p.read_text(encoding='utf-8'))
        obj['STATE_VERSION'] = str(version)
        obj['ACTIVE_STATE_VERSION'] = str(version)
        obj['REGISTRY_STATE_VERSION'] = str(version)
        obj['PARENT_STATE_VERSION'] = str(parent_version)
        p.write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')
        stamped[name] = str(version)
    return stamped

def inventory_files(root: Path) -> list[Path]:
    files = []
    for base, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in VOLATILE_DIRS]
        b = Path(base)
        for name in names:
            p = b / name
            if excluded(p, root):
                continue
            files.append(p)
    return sorted(files, key=lambda p: p.relative_to(root).as_posix())

def hash_inventory(root: Path, paths: list[Path]) -> dict:
    workers = min(32, max(4, (os.cpu_count() or 2) * 4))
    def one(p: Path):
        return p.relative_to(root).as_posix(), {'bytes': p.stat().st_size, 'sha256': sha256(p)}
    with ThreadPoolExecutor(max_workers=workers) as ex:
        pairs = list(ex.map(one, paths))
    return dict(pairs)

def incremental_hash_inventory(root: Path, paths: list[Path], parent_manifest: dict, changed_files: set[str]) -> tuple[dict, dict]:
    parent_files = dict(parent_manifest.get('FILES') or {})
    current = {p.relative_to(root).as_posix(): p for p in paths}
    changed = {str(Path(x).as_posix()).lstrip('./') for x in changed_files}
    # New files and inherited files whose byte size no longer matches the parent
    # are always hashed even if the caller forgot to declare them.
    to_hash = []
    reused = {}
    for rel, p in current.items():
        prior = parent_files.get(rel)
        if rel in changed or prior is None or int(prior.get('bytes', -1)) != p.stat().st_size:
            to_hash.append(p)
        else:
            reused[rel] = prior
    hashed = hash_inventory(root, to_hash)
    inventory = dict(reused); inventory.update(hashed)
    return dict(sorted(inventory.items())), {
        'INCREMENTAL_MANIFEST': True,
        'PARENT_HASHES_REUSED': len(reused),
        'FILES_HASHED_LOCAL_SEAL': len(hashed),
        'DECLARED_CHANGED_FILES': sorted(changed),
    }

def build_manifest(root: Path, state_id: str, version: str, parent: dict, *, files: dict | None = None) -> dict:
    if files is None:
        files = hash_inventory(root, inventory_files(root))
    return {
        'STATE_ID': state_id,
        'STATE_VERSION': version,
        'PARENT_STATE_VERSION': parent['STATE_VERSION'],
        'PARENT_BUNDLE_FILE_ID': parent['BUNDLE_FILE_ID'],
        'PARENT_BUNDLE_SHA256': parent['BUNDLE_SHA256'],
        'STATUS': 'SEALED_PENDING_DRIVE_ACTIVATION',
        'PERSISTENCE_PATCH_ID': PERSISTENCE_PATCH_ID,
        'EFFICIENCY_PATCH_ID': EFFICIENCY_PATCH_ID,
        'CREATED_AT_UTC': datetime.now(timezone.utc).isoformat(),
        'FILES': files,
    }

def verify_manifest(root: Path, manifest: dict, *, inventory: dict | None = None) -> None:
    expected = manifest.get('FILES', {})
    if inventory is None:
        inventory = hash_inventory(root, inventory_files(root))
    if set(inventory) != set(expected):
        missing = sorted(set(expected) - set(inventory)); extra = sorted(set(inventory) - set(expected))
        raise StateCommitError(f'INTERNAL_MANIFEST_FILESET_MISMATCH:MISSING={missing}:EXTRA={extra}')
    bad = [k for k in expected if inventory[k] != expected[k]]
    if bad:
        raise StateCommitError(f'INTERNAL_MANIFEST_HASH_MISMATCH:{bad}')

def semantic_parity_check(root: Path, version: str, parent_version: str) -> dict:
    bad = []
    for name in ('engine_registry.json','state_contract.json'):
        obj = json.loads((root/name).read_text(encoding='utf-8'))
        for key in ('STATE_VERSION','ACTIVE_STATE_VERSION','REGISTRY_STATE_VERSION'):
            if str(obj.get(key)) != str(version):
                bad.append(f'{name}:{key}:{obj.get(key)}:{version}')
        if str(obj.get('PARENT_STATE_VERSION')) != str(parent_version):
            bad.append(f'{name}:PARENT_STATE_VERSION:{obj.get("PARENT_STATE_VERSION")}:{parent_version}')
    if bad:
        raise StateCommitError('SEMANTIC_STATE_PARITY_FAILURE:' + '|'.join(bad))
    return {'SEMANTIC_STATE_PARITY':'PASS'}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--state-id', default='APEX_GLOBAL_STATE_VAULT_v1')
    ap.add_argument('--version', required=True)
    ap.add_argument('--parent-pointer', required=True)
    ap.add_argument('--burned-version', action='append', default=[])
    ap.add_argument('--out-dir', default='/mnt/data')
    ap.add_argument('--compression-level', type=int, default=1)
    ap.add_argument('--changed-file', action='append', default=[], help='Relative path changed in this isolated workspace; enables parent-manifest hash reuse.')
    ap.add_argument('--force-full-local-hash', action='store_true', help='Disable incremental parent-manifest reuse.')
    ap.add_argument('--repair-transaction-file', default=None, help='3E repair transaction state; when supplied, duplicate seal attempts on the same parent epoch are prohibited.')
    args = ap.parse_args()
    root = Path(args.root).resolve(); out = Path(args.out_dir).resolve(); out.mkdir(parents=True, exist_ok=True)
    parent = load_parent_pointer(Path(args.parent_pointer).resolve())
    repair_tx = None
    repair_tx_path = Path(args.repair_transaction_file).resolve() if args.repair_transaction_file else None
    if repair_tx_path:
        from engines.common.apex_3e_repair_transaction_v1 import load as load_repair_tx, require_ready_to_seal
        repair_tx = load_repair_tx(repair_tx_path)
        require_ready_to_seal(repair_tx)
        if str(repair_tx.get('PARENT_STATE_VERSION')) != str(parent['STATE_VERSION']):
            raise StateCommitError(f'REPAIR_TRANSACTION_PARENT_DRIFT:{repair_tx.get("PARENT_STATE_VERSION")}:{parent["STATE_VERSION"]}')
    required_version = increment_patch_version(str(parent['STATE_VERSION']))
    requested = str(args.version)
    if requested != required_version:
        pp = parent['STATE_VERSION'].split('.')
        rp = requested.split('.')
        if len(rp) != 3 or rp[:2] != pp[:2] or not rp[2].isdigit():
            raise StateCommitError(f'INVALID_STATE_VERSION_SEQUENCE:{parent["STATE_VERSION"]}->{requested}')
        expected_burned = [f'{pp[0]}.{pp[1]}.{i}' for i in range(int(pp[2])+1, int(rp[2]))]
        if sorted(set(args.burned_version)) != expected_burned:
            raise StateCommitError(f'NEXT_UNUSED_PATCH_VERSION_REQUIRES_BURNED_LEDGER:EXPECTED={expected_burned}:SUPPLIED={args.burned_version}')
    # Read the inherited parent manifest before replacing it. An extracted, verified
    # immutable parent bundle lets local seal reuse hashes for untouched files.
    inherited_manifest_path = root / 'bundle_manifest.json'
    inherited_manifest = json.loads(inherited_manifest_path.read_text(encoding='utf-8')) if inherited_manifest_path.exists() else None
    stamped = stamp_semantic_authorities(root, args.version, parent['STATE_VERSION'])
    semantic_parity_check(root, args.version, parent['STATE_VERSION'])
    paths = inventory_files(root)
    changed = set(args.changed_file) | {'engine_registry.json', 'state_contract.json', 'apex_state_commit.py'}
    if inherited_manifest and args.changed_file and not args.force_full_local_hash:
        inventory, incremental_receipt = incremental_hash_inventory(root, paths, inherited_manifest, changed)
    else:
        inventory = hash_inventory(root, paths)
        incremental_receipt = {'INCREMENTAL_MANIFEST': False, 'PARENT_HASHES_REUSED': 0, 'FILES_HASHED_LOCAL_SEAL': len(inventory), 'DECLARED_CHANGED_FILES': sorted(changed)}
    manifest = build_manifest(root, args.state_id, args.version, parent, files=inventory)
    (root / 'bundle_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    verify_manifest(root, manifest, inventory=inventory)
    zip_path = out / f'APEX_GLOBAL_STATE_BUNDLE_v{args.version}.zip'
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=max(0, min(9, args.compression_level))) as z:
        for fp in sorted(root.rglob('*')):
            if not fp.is_file():
                continue
            rel = fp.relative_to(root)
            if any(part in VOLATILE_DIRS for part in rel.parts) or fp.suffix in VOLATILE_SUFFIXES:
                continue
            # The manifest is excluded from its own hash inventory but MUST be
            # embedded in the immutable bundle so readback can verify all files.
            z.write(fp, rel.as_posix())
    b64_path = out / f'APEX_GLOBAL_STATE_BUNDLE_v{args.version}.b64.txt'
    b64_path.write_bytes(base64.b64encode(zip_path.read_bytes()) + b'\n')
    receipt = {
        'RUN_STATE':'TOOL_PROVEN_EXECUTED', 'PERSISTENCE_PATCH_ID':PERSISTENCE_PATCH_ID, 'EFFICIENCY_PATCH_ID':EFFICIENCY_PATCH_ID,
        'PARENT_STATE_VERSION':parent['STATE_VERSION'], 'PARENT_BUNDLE_FILE_ID':parent['BUNDLE_FILE_ID'], 'PARENT_BUNDLE_SHA256':parent['BUNDLE_SHA256'], 'BURNED_STATE_VERSIONS':sorted(set(args.burned_version)),
        'PERSISTED_TO_DRIVE':False, 'NEW_IMMUTABLE_STATE_CREATED':True, 'GLOBAL_POINTER_ROTATED':False, 'POINTER_READBACK_VERIFIED':False,
        'BUNDLE_READBACK_VERIFIED':False, 'GLOBAL_REPAIR_STATUS':'PACKAGED_PENDING_DRIVE_PROMOTION', 'STATE_ID':args.state_id, 'STATE_VERSION':args.version,
        'ZIP':str(zip_path), 'B64':str(b64_path), 'BUNDLE_SHA256':sha256(zip_path), 'ENCODED_SHA256':sha256(b64_path),
        'INTERNAL_MANIFEST_CHECK':f'PASS_{len(manifest["FILES"])}_OF_{len(manifest["FILES"])}', 'SEMANTIC_STATE_PARITY':'PASS', 'SEMANTIC_AUTHORITIES_STAMPED':stamped, 'COMPRESSION_LEVEL':args.compression_level,
        **incremental_receipt, 'FULL_IMMUTABLE_READBACK_VERIFICATION_REQUIRED': True,
        'NEXT_ACTION':'MANDATORY_UPLOAD_VERSIONED_B64_WRITE_VERSIONED_POINTER_CAS_UPDATE_ACTIVE_POINTER_IN_PLACE_AND_READBACK_VERIFY',
        'VOLATILE_SUCCESS_EXIT_ALLOWED':False, 'PACKAGED_ONLY_GLOBAL_SUCCESS_ALLOWED':False,
    }
    receipt_path = out / f'APEX_GLOBAL_STATE_COMMIT_RECEIPT_v{args.version}.json'
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    if repair_tx_path:
        from engines.common.apex_3e_repair_transaction_v1 import advance as advance_repair_tx, save_atomic as save_repair_tx
        repair_tx = advance_repair_tx(repair_tx, 'SEALED', receipt={'STATE_VERSION': args.version, 'BUNDLE_SHA256': receipt['BUNDLE_SHA256'], 'ENCODED_SHA256': receipt['ENCODED_SHA256']})
        save_repair_tx(repair_tx_path, repair_tx)
    print(json.dumps(receipt, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
