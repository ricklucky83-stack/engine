#!/usr/bin/env python3
from __future__ import annotations
from importlib import import_module
main = import_module('engines.global.apex_car_shop_postlock_router_v1').main
if __name__ == '__main__':
    raise SystemExit(main())
