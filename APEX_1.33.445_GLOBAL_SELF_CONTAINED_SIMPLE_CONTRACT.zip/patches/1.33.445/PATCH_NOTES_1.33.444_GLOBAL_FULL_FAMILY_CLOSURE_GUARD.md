# Patch Notes — APEX 1.33.444 GLOBAL FULL FAMILY CLOSURE GUARD

## Purpose

Make the missing family-closure guard global so no future runner can print a final board from a sampled heat-seeker surface.

## Hard Change

```text
NO FULL FAMILY CLOSURE RECEIPT = NO FINAL BOARD
```

This applies to every sport, site, slate type, and execution runner.

## New Mandatory Route Segment

```text
MC FIRST
-> CHAMPIONSHIP FAMILY DISCOVERY
-> FULL FAMILY CLOSURE
-> FAMILY CLOSURE RECEIPT
-> EXACT COMMON-WORLD SCORING
-> .00001 HARD GATE
```

## Required Equality

For every championship family:

```text
legal_branch_count == born_branch_count == scored_branch_count
closure_complete == true
```

If false:

```text
CHECKPOINTED / RESUME_REQUIRED
FINAL_BOARD_ALLOWED = false
NO FINAL BOARD
```

## Ordinal Check-Off Added

```text
ordinal_selector == GLOBAL_ORDINAL_POSTERIOR_SCORE
ordinal_ordering_complete == true
ordinal_checkoff_complete == true
```

The final board cannot print unless ordinal ordering is explicitly checked off after same-world dominance pruning.

## Substitutions Blocked

```text
sampled heat-seeker final board
one-build-per-world final board
first-legal-completion early stop as final
partial family closure as final
family candidate cap as final
partial rerank as final
terminal substitution
```
