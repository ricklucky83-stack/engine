# Patch Notes — APEX 1.33.443 FIXED MC + SMALL SURVIVOR SURFACE

## Purpose

Update `1.33.442_LOCKED_MC_FIRST_RUBIKS_CUBE` with the fixed-MC proof contract, deterministic tie separation, and small-survivor-surface portfolio doctrine.

## Added Locks

```text
NO ENGINE READBACK             = RUN_INVALID
NO CONFIGURED MC COUNT RECEIPT = RUN_INVALID
NO EXACT WORLD LEDGER          = RUN_INVALID
LOCAL PARAMETER OPTIMIZATION   = PROHIBITED
LIVE MC COUNT CHANGE           = PROHIBITED
```

Chunking is still allowed.
Changing total MC count during a live run is not allowed.

## Added Tie Handling

Do not add simulations to break ties.

Deterministic separator:

```text
1. #1 / PERFECT RAW COUNT
2. REPLACEMENT PRESSURE
3. CPT / ROLE PRESSURE
4. PAIR / TRIO / CORE #1 COOCCURRENCE
5. DISTINCT-WORLD SUPPORT
6. CONDITIONAL LIFT
7. TOP-3 / TOP-10 ROBUSTNESS
8. TRUE_CORE_TIE if still identical
```

Replacement pressure:

```text
WINNER_SCORE - BEST_LEGAL_SCORE_WITHOUT_PLAYER
```

## Added Small-Survivor Portfolio Doctrine

The final portfolio equals the legitimate non-dominated survivor set.

```text
If only 3 survive, play 3.
If only 8 survive, play 8.
If only 18 survive, play 18.
If only 25 survive, play 25.
```

No forced board size.
No backfill.
No filler.
No 150-entry noise spray.

## Route After Patch

```text
LOAD CURRENT NOTION AUTHORITY
-> ENGINE READBACK / HASH RECEIPT
-> CONFIGURED MC COUNT RECEIPT
-> EXACT WORLD LEDGER RECEIPT
-> MC FIRST
-> RUBIK'S-CUBE BUILDER / HEAT SEEKER
-> .00001 HARD GATE
-> SAME-WORLD DOMINANCE PRUNING
-> NFL ORDINAL
-> FINAL PORTFOLIO = NON-DOMINATED SURVIVOR SET
```
