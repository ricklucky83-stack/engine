# PATCH NOTES — 1.33.442 LOCKED MC-FIRST RUBIK'S-CUBE CONTRACT

Problem fixed:
- The prior simple contract still said `ENUMERATE EVERY LEGAL LINEUP`, which allowed broad legal-shuffle interpretations.
- The corrected user authority says: run MC first; MC scouts championship worlds; Rubik's cube builds only .00001-looking complete candidates; hard gate kills the rest; NFL ordinal orders the survivors.

Hard changes:
- MC-first is mandatory.
- Notion/current authority is mandatory before execution.
- Rubik's-cube candidate birth replaces broad legal-lineup shuffle.
- A candidate must already explain CPT path, core recurrence, salary geometry, value/punt unlock, ownership/duplication shape, and script path.
- A zero-punt is allowed only when it unlocks the correct dominant core.
- If the run cannot finish, checkpoint/resume; do not shrink or cap.

Final board is invalid unless all required phases complete.
