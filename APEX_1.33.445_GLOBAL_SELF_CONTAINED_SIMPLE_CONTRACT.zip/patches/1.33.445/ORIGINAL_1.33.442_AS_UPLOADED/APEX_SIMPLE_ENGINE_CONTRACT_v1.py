"""
APEX_SIMPLE_ENGINE_CONTRACT_v1
State: 1.33.442

Simple production contract:
LOAD NOTION -> 1. HEAT SEEKER -> 2. .00001 HARD GATE -> 3. NFL ORDINAL

This module is intentionally small. It does not implement sport scoring,
legality, MC physics, or ordinal math. It only enforces the route and prevents
caller/chat substitution.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable, Sequence


class ApexContractError(RuntimeError):
    """Raised when the simplified APEX contract is violated."""


@dataclass(frozen=True)
class SimpleApexReceipt:
    notion_loaded: bool
    legal_lineups: int
    heat_born_builds: int
    exact_scored_builds: int
    gate_threshold: float
    gate_survivors: int
    ordinal_selector: str
    backfill_used: bool
    forced_board_size: bool
    terminal_substitution: bool


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ApexContractError(message)


def run_simple_apex_contract(
    *,
    notion_authority: Any,
    legal_universe: Sequence[Any],
    proxy: Any,
    meta: Any,
    market_context: Any,
    sentinel_pm: Any,
    common_worlds: Any,
    heat_birth: Callable[..., tuple[Sequence[int], Any, Any, Any]],
    exact_common_world_score: Callable[..., Sequence[Any]],
    is_00001_success: Callable[[Any], bool],
    global_ordinal_posterior_score: Callable[..., Sequence[Any]],
) -> tuple[Sequence[Any], SimpleApexReceipt]:
    """
    Execute only the simple APEX route.

    Route:
      0. Notion loaded.
      1. Heat Seeker over the full legal universe.
      2. Hard .00001 gate on exact-scored heat-born complete builds.
      3. NFL ordinal ordering via GLOBAL_ORDINAL_POSTERIOR_SCORE.

    Prohibited here:
      - threshold lowering
      - backfill
      - forced board size
      - AI/manual rerank
      - terminal substitution
      - leverage/raw recurrence as terminal order
    """

    # PRE-STEP: LOAD NOTION
    _require(notion_authority is not None, "NOTION_AUTHORITY_MISSING")
    _require(len(legal_universe) > 0, "LEGAL_UNIVERSE_EMPTY")

    # 1. HEAT SEEKER
    born, comp, ls, lane_counts = heat_birth(
        proxy,
        meta,
        market_context=market_context,
        sentinel_pm=sentinel_pm,
    )
    _require(born is not None, "HEAT_BIRTH_RETURNED_NONE")
    _require(len(born) > 0, "HEAT_BIRTH_EMPTY")

    heat_born_builds = [legal_universe[i] for i in born]
    _require(len(heat_born_builds) == len(born), "HEAT_BIRTH_INDEX_MISMATCH")

    # 2. .00001 HARD GATE
    scored = exact_common_world_score(
        heat_born_builds,
        common_worlds=common_worlds,
    )
    _require(scored is not None, "EXACT_SCORING_RETURNED_NONE")
    _require(len(scored) == len(heat_born_builds), "EXACT_SCORING_COUNT_MISMATCH")

    qualified = [build for build in scored if is_00001_success(build)]

    # No backfill. No forced board size. Empty board is valid if no qualifiers.
    if len(qualified) == 0:
        receipt = SimpleApexReceipt(
            notion_loaded=True,
            legal_lineups=len(legal_universe),
            heat_born_builds=len(heat_born_builds),
            exact_scored_builds=len(scored),
            gate_threshold=0.00001,
            gate_survivors=0,
            ordinal_selector="GLOBAL_ORDINAL_POSTERIOR_SCORE",
            backfill_used=False,
            forced_board_size=False,
            terminal_substitution=False,
        )
        return [], receipt

    # 3. NFL ORDINAL
    board = global_ordinal_posterior_score(
        qualified,
        common_worlds=common_worlds,
    )
    _require(board is not None, "ORDINAL_RETURNED_NONE")
    _require(len(board) == len(qualified), "ORDINAL_DROPPED_OR_ADDED_BUILDS")

    receipt = SimpleApexReceipt(
        notion_loaded=True,
        legal_lineups=len(legal_universe),
        heat_born_builds=len(heat_born_builds),
        exact_scored_builds=len(scored),
        gate_threshold=0.00001,
        gate_survivors=len(qualified),
        ordinal_selector="GLOBAL_ORDINAL_POSTERIOR_SCORE",
        backfill_used=False,
        forced_board_size=False,
        terminal_substitution=False,
    )
    return board, receipt
