# APEX State 1.33.442 — Simple Engine Contract

## Route

```text
LOAD NOTION
-> 1. HEAT SEEKER
-> 2. .00001 HARD GATE
-> 3. NFL ORDINAL
```

## 1. Heat Seeker

```text
ENUMERATE EVERY LEGAL LINEUP
-> PROXY / CALIBRATION SCORE EVERY LEGAL PATH
-> FULL-POOL HEAT BIRTH
```

## 2. .00001 Hard Gate

```text
EXACT COMMON-WORLD SCORE EVERY HEAT-BORN COMPLETE BUILD
-> KEEP EVERY .00001 SUCCESS
-> DISCARD EVERYTHING ELSE
```

No threshold lowering. No backfill. No forced board size. No max-entry authority.

## 3. NFL Ordinal

```text
EVERY QUALIFIED COMPLETE BUILD
-> GLOBAL_ORDINAL_POSTERIOR_SCORE
-> ORDINAL ORDER
```

No AI rerank. No MLB-only terminal ordinal. No leverage override. No raw recurrence terminal order.
