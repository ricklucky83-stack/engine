from __future__ import annotations
import os, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parent
runner=ROOT/'engines'/'common'/'apex_global_production_board_runner_v1.py'
args=[sys.executable,str(runner)]
for flag,key in [('--site','APEX_SITE'),('--sport','APEX_SPORT'),('--mode','APEX_SLATE_TYPE'),('--execution-id','APEX_CONTEST_ID'),('--player-csv','APEX_PLAYER_CSV'),('--output-dir','APEX_OUTPUT_DIR')]:
    v=os.environ.get(key)
    if v: args += [flag,v]
raise SystemExit(subprocess.call(args,cwd=ROOT,env=os.environ.copy()))
