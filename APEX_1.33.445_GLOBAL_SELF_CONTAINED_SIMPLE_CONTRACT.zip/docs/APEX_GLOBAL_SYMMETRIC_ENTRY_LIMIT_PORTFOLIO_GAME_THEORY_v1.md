# APEX Global Symmetric Entry-Limit Portfolio Game Theory v1

## Governing correction
Contest entry limit is a strategic game parameter for both our entries and the opponent field. It is not merely the requested output count.

**Primary objective:** maximize the probability that at least one of our allowed entries finishes first against opponent portfolios constructed under the same contest entry-limit rules.

### Single Entry
Single Entry means **one shot, one kill for everyone**. The selector chooses exactly one lineup by first-place equity against an opponent field in which every entrant also has one lineup. SE does not imply safety, floor, reduced variance, forced chalk, forced contrarianism, diversification, or exposure management.

### Multi-entry
For 3-max, 20-max, 28-max, 48-max, 66-max, 94-max, 150-max, and other limits, both sides are modeled as coordinated portfolios. Portfolio seats are selected by **marginal new contest-winning world coverage**, not by taking the independently ranked Top-N lineups.

A second lineup that wins the same worlds as lineup one has less portfolio value than a lineup that adds credible new winning worlds. Shared cores remain valid when evidence supports them; diversification is a consequence of marginal championship coverage, never an end in itself.

### Field modeling
The synthetic field must preserve owner-level portfolio structure when the contest max-entry limit is known. When actual owner entry counts are unavailable, the default structural approximation groups opponent entries into portfolios up to the contest max-entry limit, with the final portfolio allowed to be partial so the total field size is exact.

### Selector implications
- `MAX_ENTRIES` and `USER_ENTRIES` are prelock contest context.
- The same `MAX_ENTRIES` governs opponent portfolio capacity.
- SE: maximize standalone contest-win probability / first-place equity.
- Multi-entry: maximize union probability that **any** selected lineup wins, using marginal new winning-world coverage for additional seats.
- Independent Top-N selection is prohibited for a multi-entry portfolio.
- Duplication is a first-place/split-pot equity cost, not a generic reason to prefer low ownership.
- Chalk and leverage are conditional evidence, not objectives.
- Cross-world recurrence is useful when it represents breadth across independent plausible worlds rather than repeated concentration inside one world family.

## Runtime authority
`engines/common/apex_entry_limit_game_theory_v1.py` is the common executable authority. Contest payload governance, synthetic-field construction, and the terminal AI selector expose the same entry-limit policy ID.
