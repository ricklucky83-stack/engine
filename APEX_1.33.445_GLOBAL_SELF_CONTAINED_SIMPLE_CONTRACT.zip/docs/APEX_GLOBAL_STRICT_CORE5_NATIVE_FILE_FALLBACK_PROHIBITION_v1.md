# Global Strict-Core5 Native File Fallback Prohibition v1

For any sport/mode covered by the strict global Core-5 terminal contract, a fresh native board file is not sufficient terminal authority. The production supervisor must receive `NATIVE_BOARD_READY_FOR_GLOBAL_CORE5`, validate and durably commit the frozen terminal candidate surface, then obtain a committed Hybrid AI selector decision before final board sealing.

If a strict-Core5 child exits with a fresh native board file but without the required terminal handoff, the supervisor fails closed with `*_STRICT_CORE5_NATIVE_BOARD_FILE_FALLBACK_PROHIBITED`. Non-strict routes retain their existing fallback behavior.

This is execution/control-plane plumbing only. It does not change any sport model, generator, simulation, selector objective, or portfolio scoring rule.
