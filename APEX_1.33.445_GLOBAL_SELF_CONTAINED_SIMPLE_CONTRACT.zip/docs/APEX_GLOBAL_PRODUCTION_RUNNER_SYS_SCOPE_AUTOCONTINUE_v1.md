# APEX Global Production Runner Sys-Scope Auto-Continue v1

A fresh DK MLB Classic 294 production run on active state 1.33.168 committed the Phase0/Phase1/Phase2-birth checkpoint and then failed inside the global production runner while emitting `ENGINE_INTERNAL_AUTO_CONTINUE`.

Root cause: `main()` contained inner `import sys` statements. Python therefore treated `sys` as a function-local variable. A checkpointed child could reach the auto-continue branch before either inner import executed, producing `UnboundLocalError`.

Repair:
- remove the inner `import sys` statements;
- use the already-imported module-level `sys`;
- preserve identical top-level command relaunch;
- preserve engine-owned checkpoint/stage/cursor control;
- no sport simulation, generator, calibration, selector, or portfolio change.

Production invariant: a valid `CHECKPOINTED_CONTINUE` state is nonterminal and cannot be converted into a live-run failure by runner bookkeeping.
