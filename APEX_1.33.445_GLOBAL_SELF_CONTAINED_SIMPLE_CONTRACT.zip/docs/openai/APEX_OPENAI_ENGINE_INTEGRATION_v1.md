# APEX OpenAI Engine Integration v1

## Authority boundary

OpenAI is integrated in two separate roles:

1. **Live terminal selector bridge** — reviews the complete frozen selector surface and returns existing lineup IDs only. The mechanical engine retains legality, generation, calibration, simulation, field modeling, handoff, validation, and sealing authority.
2. **Offline MC calibration advisor** — analyzes chronology-valid historical controls and emits bounded shadow hypotheses only. It never changes live simulation parameters or consumes same-slate postlock truth as forward input.

## Live bridge

Module: `engines/common/apex_openai_terminal_selector_bridge_v1.py`

Default model: `gpt-6-astra`; configurable with `APEX_OPENAI_SELECTOR_MODEL`.

Execution behavior:
- validates the existing frozen candidate receipt;
- rejects postlock outcome columns;
- processes 100% of the frozen surface in physical, resumable chunks;
- persists every completed AI chunk under `.apex_openai_selector/<freeze>/`;
- never restarts completed chunks with the same configuration;
- final merge is AI-owned and selects exactly existing lineup IDs;
- writes the engine's existing `*_AI_TERMINAL_DECISION.json` contract;
- the production board runner remains the formal membership/legality/hash validator and board sealer.

The chunk stage is not a code-side Top-N sieve: every candidate is supplied to the AI. Any candidate not advanced is rejected by the AI after review, not by a deterministic pre-AI filter.

## Selector doctrine

- Winner/perfect capture > Top-0.1 > Top-1 > best contest-rank potential > stability.
- Raw MC, P95, and P99 are evidence, not literal selection truth.
- Cross-world recurrence/breadth is preferred to repeated support concentrated in one fragile world.
- Current coded selector is advisory evidence only.
- Ownership/duplication is a late leverage/tie-break signal.
- Strong common championship cores remain allowed. Diversification inside the Top 5 is used only when it adds marginal winning-world coverage.

## Offline MC advisor

Module: `engines/common/apex_openai_mc_calibration_advisor_v1.py`

Seed dataset: `config/openai/APEX_NFL_SHOWDOWN_MC_CALIBRATION_SEED_v1.json`

The advisor may diagnose tail compression/overdispersion, event-process misspecification, correlation misspecification, CPT-role problems, DST-event problems, or missing input uncertainty. It may only emit bounded shadow recommendations. Production promotion requires chronological cross-control validation with common random numbers and reliability metrics.

## Secrets

`OPENAI_API_KEY` is loaded from environment / local `.env` and is never embedded in source, prompts, receipts, Notion, Airtable, or logs. `.env` must remain excluded from source control.

## Current runtime caveat

The current sandbox cannot resolve package/network endpoints, so OpenAI authentication/model access cannot be exercised from this runtime. The bridge therefore supports both the official SDK (when present) and a standard HTTPS fallback. Local contract tests use a deterministic mock transport and validate chunk/resume/security behavior without exposing the API key.
