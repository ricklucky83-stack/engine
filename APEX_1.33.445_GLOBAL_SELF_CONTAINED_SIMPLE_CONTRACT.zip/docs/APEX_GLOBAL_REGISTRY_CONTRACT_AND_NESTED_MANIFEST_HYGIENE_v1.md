# APEX_GLOBAL_REGISTRY_CONTRACT_AND_NESTED_MANIFEST_HYGIENE_v1

## Purpose
Repair inherited global registry shape drift and stale nested-manifest metadata without changing sport simulation, generator, selector, or portfolio logic.

## Permanent gates
- `GLOBAL_PATCHES` and `GLOBAL_DOCTRINES` are object-only at state seal and bootstrap.
- Every global record requires an ID and an existing `CONTRACT_FILE`.
- `apex_state_commit_v2.py` rejects malformed registry shape before bundle creation.
- Regular-chat bootstrap fails closed with explicit registry-shape errors instead of raw `TypeError`.
- Engine self-manifests are descriptive/diagnostic; the immutable bundle manifest is the cryptographic authority.
- Numbered-template trigger and roster rules remain active, while its obsolete execution-order clause is superseded by `APEX_GLOBAL_BOARD_OVER_EVERYTHING_v1`.

## Repair totals
- 9 bare patch strings normalized.
- 3 patch records repaired with missing contracts.
- 3 bare doctrine strings normalized.
- 5 doctrine IDs restored.
- 1 doctrine missing contract restored.
- MLB nested manifest hashes rebuilt from staged bytes; registry bootstrap expected SHA synchronized.

## Validation
- Targeted control-plane: 22/22 PASS.
- Broad global/control-plane parent: 216 pass / 26 fail.
- Candidate: 228 pass / 18 unchanged unrelated failures.
- Resolved inherited failures: 8. New failures: 0.
- CFB Showdown exact board parity: 4/4 PASS (GT-CU, ILL-UAB, MIA-STAN, LSU-CLEM 1764).
