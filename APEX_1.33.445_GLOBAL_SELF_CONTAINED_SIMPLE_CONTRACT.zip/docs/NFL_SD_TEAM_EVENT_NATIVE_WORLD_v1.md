# NFL_SD_TEAM_EVENT_NATIVE_WORLD_v1

Production NFL Showdown Monte Carlo now generates a shared discrete football-event layer rather than drawing every touchdown tail independently by player.

The prelock anytime-TD market remains the scorer-frequency authority. Same-team scorer counts share offense/pass/rush event-intensity worlds. WR/TE receiving touchdown events are credited to the primary team QB through the same event ledger; team touchdown totals drive PAT opportunity; opponent touchdowns apply centered DST points-allowed pressure; and the centered team scoring differential reshapes already-budgeted RB event variance to create game-control dependence with same-team DST.

Every event component is sample-centered before scoring. Per-player event variance is capped at 45% of the existing Phase-1 sigma squared, and continuous variance is reduced by the same amount. The patch therefore changes tail shape and dependence without raising player projections or target marginal standard deviations.

No player-name constants, realized results, current-contest postlock ownership, or same-slate parameter fitting are used. Phase-2 membership, public-field weighting, selector membership, and terminal ordering are unchanged by this patch.
