# APEX Global DK Source Universe Hard Lock + Individual Availability Quorum v1

## Purpose

The DraftKings salary/player file is the immutable Phase-A universe anchor for individual sports. Tennis, PGA, and MMA adapters may enrich that universe with external status evidence, but they may not silently delete a DK-listed participant because one provider, scrape, or local CSV status field says OUT/WD.

## Hard-exclusion contract

A DK-listed individual-sport participant can be removed from the active roster universe only when the prebuild availability gate certifies one of the following:

1. Two distinct verified source records support the hard-out status.
2. One explicitly official event/tour/organizer authority supplies a timestamped hard-out record.
3. A human verification record contains both a verifier identifier and verification timestamp.
4. Tennis postponement is explicitly resolved outside the contest scoring window with timing evidence.

A bare `OUT_PLAYERS` name, one generic provider status, or a local `STATUS`/`WD` column is not enough. Those cases remain in the DK universe and are surfaced as unresolved availability candidates.

## Prebuild sanity guardrail

`verify_active_pool_sanity()` binds proposed exclusions to the exact DK pool hash and rejects any proposed pool shrink outside the certified hard-out set with:

`RUN_INVALID:CRITICAL_PREBUILD_DK_UNIVERSE_SHRINK_UNCERTIFIED`

The receipt also surfaces certified hard-outs that are salary-elite (>= $8,000) or in the top projection decile so high-impact exclusions cannot be invisible.

## Sport-adapter changes

- Tennis Classic v2: local `STATUS` is advisory only; only gate-certified names may be purged. Existing explicit pair-level no-scoring confirmation remains required before a Tennis match pair is removed.
- PGA Showdown Flat-6: local `WD` flags are advisory only.
- PGA Showdown Captain: local `STATUS` flags are advisory only.
- MMA Classic/Showdown joint fight engine: local status codes are advisory only.

## RCA trigger

Contest 194375746 exposed the failure: Andrey Rublev and Marin Cilic were removed before Phase 1, and Rublev appeared in both the contest-winning lineup (500.45) and the slate-perfect lineup (510.50). No downstream selector could recover a player that had already been removed from the production universe.

## Non-goals

This patch does not change sports simulation math, ownership/field economics, contest economics, or selector weights. It changes only prebuild eligibility authority and provenance enforcement.
