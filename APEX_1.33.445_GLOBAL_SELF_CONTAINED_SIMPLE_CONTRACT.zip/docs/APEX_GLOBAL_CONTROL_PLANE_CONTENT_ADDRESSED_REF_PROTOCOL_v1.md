# APEX Global Control Plane / Content-Addressed Ref Protocol v1

## 3 E objective
**Efficient:** control-plane fixes do not require sport-model retuning; unchanged engine files reuse hashes from the verified immutable parent bundle; ZIP compression level 1 remains the default.

**Effective:** every run pins bundle file ID + SHA256; every promotion compares against the parent ref; every validated diagnostic remains append-only and accounted; bootstrap/pointer compatibility is tested before activation.

**Elite:** engine state is a content-addressed data plane. The active pointer is a tiny Git-style ref. Bootstrap is an immutable, hash-pinned control-plane release. Human `STATE_VERSION` is lineage metadata, never identity.

## Permanent invariants
1. Never mutate an active bootstrap file in place. Create a new immutable bootstrap object and rotate the ref.
2. `STATE_DIGEST = sha256:BUNDLE_SHA256` is the runtime identity.
3. Pointer compatibility is driven by `POINTER_SCHEMA_VERSION` + capabilities, never a hard-coded descriptive enum.
4. Object-ID fencing/CAS rejects stale promotion windows.
5. Diagnostic receipts are append-only; ACTIVE means the implementation patch IDs exist in the current active release.
6. Incremental sealing may reuse hashes only from a verified immutable parent ZIP. File size alone is never proof of identity.
7. Repairs happen in an overlay; untouched parent bytes/hashes are inherited from the verified bundle.
8. A control-plane defect is owned by EXECUTION/CONTROL_PLANE. Do not patch sport simulation, generator, calibration, selector, or portfolio to bypass it.
9. Promotion must preflight the candidate pointer with the candidate bootstrap before ref rotation.
10. Control-plane-only releases should not rebuild or retune the engine data plane when the engine bundle is unchanged.

## Research basis
The design follows proven patterns: Git conditional ref updates (new object only if old OID still matches), Kubernetes `resourceVersion` lost-update detection, etcd transactional compare-and-swap, Nix immutable/content-addressed store objects, and forward-compatible schema evolution where new fields/capabilities do not force old descriptive enums to be exhaustive.
