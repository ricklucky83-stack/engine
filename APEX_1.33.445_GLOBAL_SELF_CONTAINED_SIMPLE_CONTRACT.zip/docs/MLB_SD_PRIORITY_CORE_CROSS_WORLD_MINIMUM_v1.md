# MLB SD Priority Core Cross-World Minimum v1

A structural protection can claim a Core-5 seat only when its frozen championship-world count is at least 20% of the strongest active candidate's count. This blocks one/two-world punts from displacing robust portfolio members while preserving genuinely distinct game-script hedges. No postlock information is used.
