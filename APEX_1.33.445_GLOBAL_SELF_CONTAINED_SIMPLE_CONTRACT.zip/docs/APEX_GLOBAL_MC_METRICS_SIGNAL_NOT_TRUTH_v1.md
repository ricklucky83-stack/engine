# APEX Global MC Metrics = Signal, Not Truth v1

## Authority
This is a global APEX doctrine for every supported sport and contest mode. Monte Carlo outputs remain required evidence, but their raw numerical values are not literal truth and may not become unquestioned authority.

## Global interpretation

**PRIMARY**
- Cross-world recurrence
- Pairwise strength
- World breadth
- Stable championship-tail presence
- Exact-role common-world ordinal posterior when a sport-mode adapter supplies it
- Stable-tail family consensus as contextual neighborhood evidence
- Rank/cross-seed stability

**SECONDARY**
- Relative WIN / Top 0.1% / Top 1% or Top-10 rates
- Relative P95 / P99
- Relative expected / median / P90 rank

**PENALTIES**
- Instability
- Single-world concentration
- Extreme disagreement among independent evidence channels

## Execution rule
The doctrine applies in Phase 1, Phase 2, selector qualification, AI Hybrid Eyes, and terminal ordering. Raw MC magnitudes are converted to within-slate relative evidence before aggregation. Sport-mode adapters retain their own calibration and correlation models; this doctrine does not impose shared cross-sport coefficients.

`SELECT_SCORE` controls membership. `ORDER_SCORE` and terminal Hybrid Eyes may reorder only the frozen qualified board unless an explicit sport-mode membership rule is independently authorized. Postlock contest truth is evaluation-only.

## NFL Showdown implementation
NFL Showdown uses `engines/nfl/nfl_sd_mc_signal_hybrid_terminal_order_v1.py` after membership freeze. Cross-world recurrent Core-4 structures may nominate front-context candidates, but recurrence alone cannot force a row into the head. Hybrid Eyes chooses protected seats using the complete global MC-signal score with bounded Captain concentration.

`NFL_SD_STABLE_TAIL_FAMILY_CONSENSUS_ORDER_v2` remains available as **discovery prior / shrinkage context / exact-score tie-break evidence only**. Its neighbor Top-0.1, P95, P99 and global-confidence inputs are converted to within-board percentiles before aggregation. It cannot add or remove a lineup, raw MC probabilities never become literal authority, and postlock truth is prohibited.

When the exact-role common-world head is live, `APEX_GLOBAL_CONDITIONAL_FAMILY_ORDINAL_HEAD_v1` supersedes family inheritance as final head authority. NFL Showdown scores exact CPT + 5 FLEX lineups on the same 10,000 football worlds after membership freeze; family context can only break an exact posterior tie.
