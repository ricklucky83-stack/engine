# APEX Engine Control-Plane and MLB Classic Resume Integrity v1

## Purpose
Permanentize the execution repairs proven during the DK MLB Classic 9,803-entry production run on 2026-09-07. This is an execution/control-plane repair only. Player simulation, lineup-generation membership, calibration, ownership, selector scoring, and portfolio logic are unchanged.

## Permanent guards

### Pointer state-digest parity
A promotion derives `STATE_DIGEST` only from the newly written `BUNDLE_SHA256`. Promotion readback validates the digest itself, so stale pointer metadata cannot be marked successful.

### Active-code checkpoint hydration
Cross-version checkpoints are data-only. Runtime aliases are rehydrated from the active engine tree. `rs44_v7_mod` is mandatory after hydrate; missing active-code hydration hard-stops the run.

### Active output namespace
`OUT` is rebound to the active `APEX_OUTPUT_DIR` before and after checkpoint hydration. A migrated checkpoint cannot write final artifacts into a parent state's run directory.

### Terminal recovery
Empty `LAST_CHECKPOINT` is absent, never `Path('.')`. When terminal fallthrough is detected without a board, the controller recovers the most advanced durable pre-final checkpoint and replays only the final stage. Checkpoint ordering uses semantic stage/cursor values rather than filesystem modification time.

### Final-board artifact gate
A final-stage worker returning zero without a final-board artifact is invalid: `RUN_INVALID:FINAL_BOARD_ARTIFACT_MISSING_AFTER_FINAL_STAGE`.

## Production proof
The repaired MLB Classic 9,803 run completed with `PHASE2_BUILT_LINEUPS=89283`, `HANDOFF_SURVIVORS=2880`, `SELECTOR_REVIEWED_LINEUPS=2880`, `FINAL_BOARD_SIZE=5`, and `EXECUTION_STATE=TOOL_PROVEN_EXECUTED`.

## Regression policy
Future state promotions and MLB Classic resumptions fail before advancing if digest parity, active-module hydration, active output rebinding, deterministic checkpoint recovery, or final-board artifact integrity is absent.
