# APEX Global Hybrid Selector Intelligence v2

**Patch:** `APEX_GLOBAL_HYBRID_SELECTOR_INTELLIGENCE_v2`

## Global architecture

APEX uses one shared Hybrid Selector intelligence system across every supported DFS sport and contest mode. MLB, Tennis, CFB, NFL, PGA, MMA, NBA, WNBA, CBB, NHL and future registered sports do not get separate AI brains.

The global reasoner learns transferable championship-selection principles from the entire historical CAR SHOP library: extreme-tail evidence, cross-world recurrence, championship-family mass, uncertainty, ownership/duplication price, local neighborhood strength, portfolio redundancy and coded-selector disagreement.

Sport/mode profiles remain because the same evidence has different causal meaning in different games. They are **context adapters only**. They translate sport-native structure into the shared reasoning surface; they do not create independent models or independent selector authority.

## Production boundary

`ENGINE -> complete frozen selector surface -> GLOBAL HYBRID AI -> existing lineup IDs only -> ENGINE validation/seal`

AI remains last-step-only. It cannot generate lineups, modify the player pool, rerun simulations, change calibration, alter ownership, or fill an incomplete run. Plugins may support research/context but have no execution authority.

## Global training corpus

Every resolved historical slate contributes to one global corpus. Each row includes a sport/mode context tag, field size, safe prelock engine metrics and resolved ranking labels. Player identity fields are stripped from reusable lessons. Historical results are labels only and are never live forward inputs.

The corpus is global, but preference comparisons stay **within the same slate**. A lineup from MLB Showdown is never directly declared better than a Tennis lineup. Cross-sport transfer happens through shared ranking principles, not invalid cross-contest rank comparisons.

## Training objectives

1. `GLOBAL_WINNER_CAPTURE_AT_5`
2. `GLOBAL_TOP_0_1_CAPTURE_AT_5`
3. sport/mode non-regression
4. best contest rank at 5

Training uses global blind listwise replay, graded winner/Top-0.1/Top-1 labels, a shared hard-negative library, within-slate preference pairs, cross-sport transfer through context adapters, and time-ordered walk-forward holdouts.

## Hard negatives

The highest-value lesson is a championship candidate that existed on the frozen surface but lost to a plausible selector favorite. These mistakes are accumulated globally. The AI should learn the transferable reason the winner/Top-0.1 candidate deserved elevation while retaining the sport-native adapter context that made the evidence meaningful.

## Sport adapters

Examples: MLB Showdown supplies CPT/player-set/game-script structure; MLB Classic supplies stack/pitcher-hitter geometry; Tennis supplies match/surface/serve-return volatility; football supplies stack/role/game-script evidence; basketball supplies minutes/usage/game correlation; PGA supplies round/event/weather/birdie structure; MMA supplies fight-style/pace/finish structure.

These adapters feed one intelligence system. They are not separate intelligence policies.

## Promotion rule

A global intelligence candidate cannot be promoted because one sport improves. It must improve global winner/Top-0.1 capture while passing sport/mode non-regression and time-ordered blind validation.
