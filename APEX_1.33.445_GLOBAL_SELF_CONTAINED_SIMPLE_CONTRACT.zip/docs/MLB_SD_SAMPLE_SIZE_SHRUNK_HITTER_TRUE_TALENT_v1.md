# MLB SD Sample-Size-Shrunk Hitter True Talent v1

Prelock player-rate repair for MLB Showdown. Raw AVG/OBP/ISO/contact discipline and quality rates are shrunk toward league priors using stat-specific effective-sample constants before Phase-1 event simulation. Valid xBA may inform the AVG prior. Low-sample uncertainty widens simulated talent around the shrunk mean. Realized contest scores, winner identity, and postlock ownership are prohibited.
