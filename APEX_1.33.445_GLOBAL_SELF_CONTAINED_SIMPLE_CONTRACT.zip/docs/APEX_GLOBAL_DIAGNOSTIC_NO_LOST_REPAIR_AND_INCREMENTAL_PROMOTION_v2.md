# APEX Diagnostic No-Lost-Repair + Incremental Promotion v2

## Objective
Guarantee that simultaneous diagnostic/repair windows cannot silently overwrite, omit, or de-implement one another, while making `update doc and code` a fast transactional operation instead of a repeated full-state rebuild.

## Permanent no-lost-diagnostic invariant
Every validated diagnostic patch must resolve to exactly one accountable state:
1. `ACTIVE` / `MERGED` with the promoted state version recorded;
2. `QUEUED` / `MERGE_READY` and included in the next promotion set;
3. `SUPERSEDED` with an explicit successor patch ID;
4. `REJECTED` with an explicit reason.

There is no valid `missing`, `overwritten`, `forgotten`, `dropped because another window promoted`, or implicit supersession state.

## Immutable diagnostic event ledger
- Every diagnostic change-set has a deterministic `PATCH_ID` and immutable receipt hash.
- State changes create new immutable receipts; prior receipts are never rewritten.
- Multiple terminal states for one patch are a hard conflict, never resolved by arbitrary file ordering.
- `SUPERSEDED` requires `SUPERSEDED_BY`.
- `REJECTED` requires `REASON`.
- `ACTIVE` or `MERGED` requires `PROMOTED_STATE_VERSION`.

## Promotion coverage gate
Immediately before a promotion is sealed:
- load the live diagnostic queue;
- resolve the complete pending promotion set against current `GLOBAL_PATCHES`;
- prove every pending validated patch is present in the merged candidate;
- require `UNACCOUNTED_VALIDATED_PATCHES=0`;
- require `UNIMPLEMENTED_VALIDATED_PATCHES=0`.

A promotion cannot rotate ACTIVE merely because its own window finished successfully.

## Mandatory live rescan
The queue must be read from the live queue source twice: once before sealing and again immediately before pointer rotation. Reusing an old in-memory snapshot as the second read is prohibited. If a live rescan is unavailable, promotion fails closed with `DIAGNOSTIC_QUEUE_RESCAN_UNAVAILABLE`.

If the queue changes during the seal window, return `DIAGNOSTIC_QUEUE_DRIFT_REBASE_REQUIRED`, merge the new validated repair, reseal, and retry. Nothing is silently skipped.

## Multiwindow and CAS behavior
- Every repair workspace pins the active immutable parent.
- A running production slate stays on its pinned snapshot.
- A repair window may continue computing after another window promotes, but it cannot rotate ACTIVE from a stale base.
- Before pointer rotation, the active state and bundle hash are reread.
- Parent drift requires rebase; touched-component drift requires explicit reconciliation.
- ACTIVE rotation remains compare-and-swap guarded.

## Fast `update doc and code` transaction
Documentation and executable changes are one promotion transaction.

Fast path:
1. reuse the verified extracted parent state;
2. write only changed code/doctrine/doc files;
3. run compile plus targeted tests for touched components;
4. auto-stamp semantic state authorities at seal time;
5. reuse the parent manifest hashes for inherited unchanged files;
6. hash only changed/new files during local seal;
7. package once using best-speed compression;
8. perform one full integrity verification on immutable readback before activation;
9. batch compatible validated diagnostics into the same state;
10. rotate ACTIVE once and verify pointer/bundle parity.

The incremental local seal is an acceleration method, not an integrity relaxation. Full cryptographic assurance is restored by immutable bundle readback before promotion is declared global.

## Required receipts
- `VALIDATED_DIAGNOSTICS_TOTAL`
- `PROMOTION_REQUIRED_PATCHES`
- `PROMOTION_IMPLEMENTED_PATCHES`
- `UNACCOUNTED_VALIDATED_PATCHES=0`
- `UNIMPLEMENTED_VALIDATED_PATCHES=0`
- `QUEUE_SNAPSHOT_SHA256`
- `QUEUE_RESCAN=PASS`
- `BASE_CONCURRENCY_CHECK=PASS`
- `POINTER_COMPARE_AND_SWAP=PASS`
- `INTERNAL_MANIFEST_CHECK=PASS`
- `SEMANTIC_STATE_PARITY=PASS`
- `BUNDLE_READBACK=PASS`
- `POINTER_READBACK=PASS`

## Failure codes
- `DIAGNOSTIC_QUEUE_RESCAN_UNAVAILABLE`
- `DIAGNOSTIC_QUEUE_DRIFT_REBASE_REQUIRED`
- `VALIDATED_PATCHES_NOT_IMPLEMENTED`
- `UNACCOUNTED_VALIDATED_PATCHES`
- `DIAGNOSTIC_TERMINAL_STATE_CONFLICT`
- `SUPERSEDED_PATCH_REQUIRES_SUCCESSOR_PATCH_ID`
- `REJECTED_PATCH_REQUIRES_REASON`
- `MERGED_PATCH_REQUIRES_PROMOTED_STATE_VERSION`
- `ACTIVE_POINTER_DRIFT_REBASE_REQUIRED`
- `SEMANTIC_STATE_PARITY_FAILURE`
