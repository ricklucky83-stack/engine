# MLB Classic bounded checkpoint + common-world memory v1

Execution-only repair. No model, generator, calibration, selector objective, or portfolio semantics change.

- Keep only current + one fallback checkpoint after durable controller commit.
- Hash large checkpoint files by streaming blocks, never `read_bytes()`.
- Amortize cheap handoff packet construction over 20,000 rows per checkpoint.
- Keep frozen common-world bit tapes in place and pass selector row indices. Gain vectors are evaluated in bounded 4,096-row blocks.
- Candidate order, world event bits, selector metrics, tie-breaking, and board size remain unchanged.
