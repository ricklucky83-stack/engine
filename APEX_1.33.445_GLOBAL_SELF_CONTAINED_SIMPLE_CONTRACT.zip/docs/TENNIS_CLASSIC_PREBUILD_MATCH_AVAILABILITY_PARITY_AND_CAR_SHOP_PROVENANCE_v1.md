# Tennis Classic Prebuild Match Availability Parity and CAR SHOP Provenance v1

## Failure repaired

Contest `194375746`, execution `8823`, was run from a 70-player Tennis Classic pool. The production receipt reported an active pool of 68 and `OUT_PURGE=2`. Exact replay of the frozen prelock inputs reproduced the original prediction, strategy-feature, and Phase-1 calibration hashes only when the Cilic–Rublev match was removed. Andrey Rublev subsequently scored 81.8 DK points and appeared in the contest-winning lineup. Therefore the reference rank-1 lineup was unreachable before Phase 1 and cannot be used as evidence of a Phase-2, handoff, or selector miss.

The historical receipt did not persist which single participant status initiated the old opponent-cascade behavior, so this repair does not claim that either Cilic or Rublev was individually marked unavailable. The proven fact is that the prebuild layer removed both sides of that match.

## Forward hard gate

Tennis availability is pair-sensitive. A unilateral participant OUT/WD/PPD-style record cannot silently remove the opponent. The engine now requires explicit pair-level no-DK-scoring confirmation, represented by both participants being explicitly classified unavailable, before removing the pair. A unilateral status fails closed with:

`RUN_INVALID:TENNIS_UNILATERAL_UNAVAILABLE_STATUS_REQUIRES_EXPLICIT_PAIR_CONFIRMATION`

This prevents stale participant evidence from silently deleting a playable opponent.

## Provenance persistence

Every production Tennis Classic run now writes:

- `DK_TENNIS_CLASSIC_<execution>_ACTIVE_POOL_SNAPSHOT.csv`
- `DK_TENNIS_CLASSIC_<execution>_PREBUILD_AVAILABILITY_RECEIPT.json`

The final receipt records both filenames and SHA-256 hashes. CAR SHOP can therefore reconstruct the exact post-prebuild active pool without inference.

## CAR SHOP causal ordering

Before assigning a generator, handoff, selector, or variance failure, CAR SHOP must compare the contest reference winner against the exact production active pool.

If the reference winner is outside that active pool, CAR SHOP records the mismatch and derives the best legal contest lineup composed entirely of production-active players. That lineup becomes the downstream causal target. The postlock winner remains evidence of the upstream availability failure only; it is never fed into the forward selector or calibration model.

For contest `194375746`, 5,619 contest lineups were compatible with the reconstructed 68-player active pool. The best compatible entry ranked 3rd with 488.15002 points. Its Phase-2 birth status remains unresolved because the historical run did not preserve the Phase-2 manifest; that missing telemetry is not converted into a false generator failure.

## Governance

This patch changes availability safety and diagnostic provenance only. It does not alter projection weights, Monte Carlo calibration, ownership modeling, selector weights, or portfolio ranking.
