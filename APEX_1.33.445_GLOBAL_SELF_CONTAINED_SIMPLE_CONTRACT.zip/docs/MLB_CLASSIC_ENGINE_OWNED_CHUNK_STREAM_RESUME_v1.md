# MLB Classic Engine-Owned Chunk / Stream / Resume v1

## Purpose
Restore the integrated DraftKings MLB Classic production contract: Chat loads and runs the one active engine; the engine itself owns every execution step from Phase 0 through the final board. Runtime-window management is mechanical and internal.

## Production path
`global production runner -> APEX_MLB_MASTER_ENGINE_v1 -> MLB Classic resumable controller -> authoritative MLB Classic runtime -> selector handoff -> Core 5 board`

The resumable controller is an internal engine component. Chat does not invoke it, its checkpoint worker, source ranges, or cursors directly.

## Mechanical execution contract
- Every expensive MLB Classic section executes as an engine-defined semantic stage.
- Each completed stage atomically commits a checkpoint before returning control.
- `CHECKPOINTED_CONTINUE` (return code 75) means the exact same production command must be invoked again; the engine resumes from its saved cursor.
- The global production runner returns this state immediately instead of relaunching the same child inside one execution window.
- Completed work is never restarted while a matching checkpoint exists.
- Stage boundaries are derived from top-level Python statements and semantic engine markers, not Chat-selected source ranges.
- The heavy `2-2-1-1-1-1` distributed-geometry lane is internally sliced by the engine using a persistent pair cursor.
- FAST PATH preserves calibration-qualified Phase-2 work when deterministic closure exceeds the historical soft mass-build threshold; raw full-depth enumeration remains prohibited.
- Once the final board is emitted, production returns the board immediately; post-board artifact work remains skipped in FAST PATH.

## Chat boundary
Chat may load the active engine, pass run inputs, invoke the integrated production command, participate at the frozen selector boundary, and render the sealed board. It may not operate internal runtime stages, checkpoint files, cursor values, recovery scripts, or source slices.

## Validation requirement
Promotion requires two consecutive identical production invocations to prove forward cursor movement with no restart, plus direct proof that the heavy distributed-geometry cursor advances across multiple engine-owned checkpoints.

## 1.33.164 handoff packet continuation
- The raw selector-packet construction loop is now chunked internally by the engine with a contiguous packet cursor.
- The default packet slice is 250 selector-reviewed lineups per internal checkpoint.
- Chat does not choose packet slices, stage boundaries, checkpoint paths, or resume coordinates.
- State-version promotion may mechanically migrate the newest compatible controller checkpoint only when execution ID, player-pool SHA256, and authoritative raw-runtime SHA256 all match.
- Completed Phase 0/1/2/3 work is preserved across that compatible promotion.


## v3 lineage repair — state 1.33.350
`MLB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_v3` restores the 1.33.332 Stage-0 micro-chunk implementation onto the 1.33.349 lineage, makes the existing 4,096-parent cross-pattern block boundary controller-durable, recovers fully committed child checkpoints after host cutoff without replay, and restores `pickle` during checkpoint hydration. Model/simulation/generator/selector objectives are unchanged.
