# APEX_GLOBAL_TOP5_HIGH_CONFIDENCE_PARLAY_v1

Status: ACTIVE_VERIFIED_LOCKED_PRODUCTION

The final five lineups are one coordinated high-confidence parlay, not five independent rank outputs. Selection targets joint championship-state coverage with bounded concentration in a strong family and deliberate allocation to materially distinct protected/counter-script scenarios. Post-lock contest results are forbidden from forward selection.
