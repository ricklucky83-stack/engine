# APEX Global Terminal AI Hybrid Selector v5

**Authoritative state target:** 1.33.108  
**Selector patch:** `APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v5`  
**Code/doc parity patch:** `APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v5_CODE_DOC_PARITY_SEAL_v1`  
**Calibration contract:** `APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v5_MLB_SD_CHAMPIONSHIP_NEIGHBORHOOD_CALIBRATION_v1`

## 1. Objective

The terminal AI selector chooses the best **five-lineup championship portfolio** from the complete calibration-qualified handoff. It does not optimize mean projection. Its primary target is joint probability of contest-winning / Top-0.1% outcomes while controlling redundant exposure, duplication, and fragile single-script dependence.

The five seats are a portfolio. They are not simply the five highest standalone scalar scores.

## 2. Authority boundary

The engine owns player availability, roster/salary legality, calibration, Phase-2 birth, simulation, field construction, ownership/duplication inputs, and handoff metrics.

The AI begins **only after the complete selector-reviewed candidate matrix is handed off**. It may rank, compare, tiebreak, assign portfolio roles, and select existing lineup IDs. It may not create a lineup, mutate a candidate, change a projection, change ownership, rerun simulation, or use post-lock outcomes.

No Top-N sieve, Pareto pruning, beam frontier, or AI review cohort is allowed before AI selection. Full handoff parity is mandatory.

## 3. Calibration-first relationship

V5 does not replace calibration-first construction. Production flow remains:

`CALIBRATION -> CALIBRATION-QUALIFIED PHASE 2 BIRTH -> MC / FIELD EVALUATION -> COMPLETE HANDOFF -> TERMINAL AI -> CORE-5 BOARD`

The AI only decides which already-born, already-evaluated lineups belong on the final five-seat board.

## 4. MLB Showdown championship-neighborhood intelligence

V5 adds pre-lock-only neighborhood intelligence around strong five-player cores. The evidence surface includes five-player core championship mass/density, D1 local championship density, protected-anchor relationships, same-CPT satellites, reciprocal-CPT satellites, SP-CPT counter paths, counter-script reserves, and local P99 / win / Top-0.1 persistence.

The executable source of truth is `MLB_SD_CHAMPIONSHIP_NEIGHBORHOOD_POLICY` in `engines/common/apex_terminal_ai_hybrid_selector_v5.py`.

### Evidence prior

When a dominant championship neighborhood is supported by pre-lock evidence, the AI may concentrate up to **3 of 5** seats in that neighborhood and reserve up to **2 of 5** seats for counter-script paths. These are **evidence priors, not forced quotas**.

Structural relationship thresholds:

- dominant-neighborhood relationship: 5 shared players
- counter-script relationship: 4 shared players
- protected championship anchor receives priority when supported

Forced diversification away from a strong neighborhood is prohibited. Blind concentration without evidence is also prohibited.

## 5. Top-5 portfolio roles

MLB Showdown v5 can label existing candidates as `PROTECTED_CHAMPION`, `DOMINANT_CORE_SAME_CPT_SATELLITE`, `DOMINANT_CORE_RECIPROCAL_SATELLITE`, `DOMINANT_CORE_SP_CPT_COUNTER`, or `COUNTER_SCRIPT_RESERVE`. These labels never create lineups.

## 6. Resolved-slate calibration firewall

Resolved contests may be used only in **offline diagnostic/calibration mode** to measure selector errors and fit transferable pre-lock rules. The forward production selector must not receive realized contest fields.

Forbidden forward fields include contest rank, actual fantasy points, realized score, winning-lineup flags, and equivalent post-lock outcome columns. The source fails closed if such fields are present. Player-name constants are prohibited.

## 7. 5,882-field CAR SHOP calibration evidence

Resolved-slate diagnostic evidence:

- prior repaired Core-5 ranks: `1 / 417 / 329 / 173 / 3181`
- v5 calibrated diagnostic ranks: `1 / 2 / 7 / 10 / 10`
- prior average rank: `820.2`
- v5 diagnostic average rank: `6.0`

The transferable correction is greater weight on **local championship density, five-player core mass, neighborhood persistence, and protected-anchor relationship structure**, while retaining counter-script coverage. Unresolved post-lock scoring rows are excluded from diagnostic training instead of being misclassified as rank-1.

## 8. Runtime contract

The v5 relationship layer must preserve the complete handoff and remain practical for live production. Validation on the 54,152-lineup surface retained all 54,152 candidates with zero pruning and zero post-lock leakage. The optimized neighborhood layer reuses the existing relationship index rather than constructing a second large relationship map.

Live production remains board-first and does not run audits, diagnostic suites, or regression tests in the critical path. Those belong to maintenance / CAR SHOP mode.

## 9. Code/doc parity requirements

A promotion is valid only when these agree:

1. `engines/common/apex_terminal_ai_hybrid_selector_v5.py`
2. `doctrine/APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v5.json`
3. this documentation file
4. `engine_registry.json` active selector metadata
5. state contract / promotion receipt

The production source exposes `selector_contract_metadata()` so automated tests can verify the documented policy against executable constants without using candidate or post-lock data.

## 10. Non-negotiable invariants

- calibration-first generator remains authoritative
- AI may select existing IDs only
- complete handoff required
- no candidate pruning
- no post-lock fields in forward selector
- no player-name memorization
- no forced 3+2 quota
- no forced diversification away from supported championship neighborhoods
- final output remains exactly five playable lineups
- live no-audit / no-diagnostic / no-test policy remains preserved

## 11. Cross-world recurrence authority — ACTIVE

Final-board portfolio selection may use prelock world breadth: `MC_WORLD_COUNT`, `MC_TOP01_DISTINCT_WORLD_COUNT`, `MC_TOP01_WORLD_HIT_COUNT`, and `MC_TOP01_WORLD_HHI`. The derived cross-world recurrence signal rewards Top-0.1 coverage across distinct worlds and discounts repeat mass concentrated in one script. Missing evidence is explicit and never imputed. `CROSS_WORLD_TOP01_RECURRENCE` is a valid portfolio reason code; it is a tiebreak and marginal-coverage signal only.
