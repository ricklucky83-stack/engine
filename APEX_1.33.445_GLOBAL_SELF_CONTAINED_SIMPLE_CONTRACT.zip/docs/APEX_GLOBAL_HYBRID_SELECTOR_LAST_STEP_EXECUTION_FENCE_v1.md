# APEX Global Hybrid Selector Last-Step Execution Fence v1

**Patch:** `APEX_GLOBAL_HYBRID_SELECTOR_LAST_STEP_EXECUTION_FENCE_v1`

## Purpose

Make the production authority boundary explicit and fail closed. Plugins may support research, current-data verification, historical context, and selector reasoning. They do not own execution. AI participates at exactly one point: the final Hybrid Selector reasoning step after the engine has committed the complete frozen selector-reviewed surface.

## Production sequence

`plugins/context -> bootstrap/registry -> production runner -> authoritative sport engine -> complete frozen selector surface -> Hybrid AI final-five reasoning -> engine validates IDs/hash/legality -> engine seals board -> render`

The plugin/context stage may occur before or alongside engine preparation, but it may not mutate an already frozen run or substitute for engine artifacts.

## Engine-only authority before the Hybrid Selector

The engine owns all of the following without Chat/AI substitution:

- data governance and roster/availability gates
- Phase 1 calibration
- Phase 2 generation/recall
- simulation and adaptive bubble work
- ownership/field construction
- recurrence telemetry
- handoff and candidate identity reconciliation
- durable checkpoints and resume
- terminal surface publication and freeze hash

## Sole AI authority

After the complete selector surface is atomically committed, the AI may:

- compare existing lineup IDs;
- reason about championship / Top-0.1 evidence;
- use sport-specific Hybrid Selector intelligence;
- compare the coded selector with other prelock evidence;
- select exactly five existing lineup IDs;
- attach allowed reason codes.

The AI may not create a lineup, alter a player, recompute a metric, change the player pool, request upstream pruning, rerun simulations, change calibration, or use postlock outcomes.

## Plugin policy

Deep Research, Web Search, Study, and Notion are allowed as support inputs. They are not a fallback solver and they do not transfer execution authority to Chat. Their presence must never cause the runner to switch to AI-generated Phase 1/2, simulation, lineup generation, or board construction.

## Missing-decision behavior

A committed frozen selector surface with no AI decision must return:

`RUN_STATE = HYBRID_SELECTOR_HANDOFF_REQUIRED`

The runner must not make an engine-internal proxy decision. It must not invent a board. The durable surface remains committed, so the run resumes at the Hybrid Selector rather than replaying expensive sport-engine work.

## After the AI decision

The engine mechanically validates:

- candidate freeze hash parity;
- selected IDs exist in the frozen surface;
- exactly five unique legal selections;
- allowed reason codes;
- role-sensitive duplicate identity;
- final board artifact/hash parity.

No second AI decision is permitted after validation.
