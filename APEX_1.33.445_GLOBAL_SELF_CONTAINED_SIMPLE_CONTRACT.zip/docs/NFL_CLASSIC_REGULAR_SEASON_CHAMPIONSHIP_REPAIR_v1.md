# NFL Classic Regular-Season Championship Repair v1

Objective: maximize actual contest-winning and Top-0.1% lineup capture.

## Active architecture

- Player-file sportsbook props, projections, ceiling, role evidence, ownership and game environment feed player calibration.
- Normalized heavy-tail correlated football worlds replace the legacy under-dispersed factor combination.
- Candidate birth is a union of quality perturb optimization, world-native exact DK optimization, and recurrent-core exact-salary closure.
- High-frequency recurrent cores retain 2,500 exact-salary completions; cores with frequency <=8 retain 6,000. The legacy >12-frequency collapse to 700 is prohibited.
- Missing structural lanes include QB_1PASS_NO_BRING, QB_NAKED and QB_RB_GROUND_NO_BRING.
- The fixed pre-MC Phase-2 Top-K choke point is removed. Born-to-review parity is 1:1.
- Public-field lineups are generated independently from candidate construction with ownership, salary, stack and runback behavior.
- Historical learning is always on by user direction. Terminal historical intelligence is a dual-tail model: 85% actual-field Top-0.1% classification plus 15% actual-field Top-1% classification.
- Live MC, projection, legality, and field simulation remain admission and safety signals. Historical dual-tail intelligence owns terminal ordering once candidates are admitted.

## Validation controls

Leave-one-contest-out validation of the fixed 85/15 dual-tail rule:

- 5,945 holdout: best rank 1; Top-0.1 4; Top-1 29; Top-5 76.
- 15,854 holdout: best rank 2; Top-0.1 7; Top-1 44; Top-5 93.
- 19,607 holdout: best rank 3; Top-0.1 7; Top-1 37; Top-5 90.
- 47,562 holdout: best rank 1; Top-0.1 13; Top-1 60; Top-5 109.

The cumulative four-control learner contains 80,070 mapped historical entries: 92 Top-0.1 positives and 901 Top-1 positives.

## Forward rule

Generate broadly, simulate every born lineup, evaluate against an independent public field, preserve strong baseline football quality, keep recurrent-core closure deep enough to retain championship neighborhoods, and continuously append resolved NFL Classic field outcomes to the historical dual-tail learner.

## Top-5 championship-neighborhood head

- Production policy: `NFL_CLASSIC_TOP5_MEDIAN_HEAD_SHRINKAGE_v1`.
- The policy runs only after final-150 membership is frozen. It is terminal ordering only: no lineup can be added or removed.
- Seat 1 is immutable. Seats 2-5 are selected from the elite Top-0.1 probability neighborhood; Top-1 stability plus ownership and raw-ceiling shrinkage break near-ties.
- Diversification begins at Seat 6; it is not allowed to weaken the championship Top 5.
- 47,562 control before: ranks `1 / 21 / 2 / 24 / 241`, Top-5 median rank `21`, winner-removed median rank `22.5`.
- 47,562 control after: ranks `1 / 40 / 21 / 2 / 3`, Top-5 median rank `3`, winner-removed median rank `12`, worst Top-5 rank `40`.
- All five repaired head lineups finished Top-0.1%.
- Runtime receipts now emit `PATCH_ID=NFL_CLASSIC_TOP5_MEDIAN_HEAD_SHRINKAGE_v1` so each board proves the active head policy.
- Targeted head regression: `23/23 PASS`.

## Production receipts

- Historical learning: `TOP0_1_85_TOP1_15_ALWAYS_ON`.
- Recurrent-core policy: `FREQ_LE8_6000__GT8_2500`.
- Top-5 membership mutation: `FALSE`.
- Top-5 Seat-1 immutability: `TRUE`.
- Top-5 median control: `21 -> 3`.
- Winner-removed Top-5 median control: `22.5 -> 12`.
