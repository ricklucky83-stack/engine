# NFL SS YARDS calibration-qualified birth v1

This patch makes the historical SS YARDS logic compatible with the current global FAST PATH. Phase-1 yard worlds must exist before any lineup identity is born. No projection-sorted First-N path, no full legal-universe enumeration, and no raw pre-Phase2 C(N,3) lattice are permitted.
