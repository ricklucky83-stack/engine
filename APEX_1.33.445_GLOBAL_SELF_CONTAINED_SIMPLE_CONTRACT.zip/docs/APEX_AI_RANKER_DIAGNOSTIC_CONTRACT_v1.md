# APEX AI + Ranker Diagnostic Contract v1

Every post-run diagnostic must evaluate the intelligence layer separately from winner capture.

Required prelock telemetry:
- AI authority and selector mode.
- Native ranker Top 5 before portfolio/reserve overrides.
- Final-board Top 5 after portfolio/reserve overrides.
- Native rank of every protected/reserve row.
- No postlock inputs in ranker telemetry.

Required postlock grading when contest truth is available:
- Actual contest rank/copies/score for each native ranker Top 5 lineup.
- Winner native rank before any reserve/override.
- Winner final-board rank after overrides.
- Top-0.1% capture by native rank buckets: 1-5, 6-10, 11-25, 26-100, 101+.
- Explicit `RANKER_SOLVED` state independent from `SLATE_SOLVED`.

Interpretation:
- A slate can be `SLATE_SOLVED=YES` while `RANKER_SOLVED=NO` if a bounded reserve captures the winner but native AI/ranker ordering does not.
- Diagnostics must not hide that distinction.
- Reserve success is evidence for family preservation; it is not proof that the ranker understood the slate.
