# APEX Global Pointer Docs-Coordinator Fenced Commit v1

## Purpose
Provide a concrete server-enforced concurrency backend for the existing `APEX_GLOBAL_CROSS_CHAT_STABLE_POINTER_CAS_v1` contract without changing the active raw pointer object ID.

## Why this backend exists
The Drive raw-file update surface preserves file ID but does not expose an expected-version precondition in the available connector. Google Docs `documents.batchUpdate` does expose `writeControl.requiredRevisionId`, and a stale required revision is rejected by the server. A single native Google Doc is therefore used as the shared fencing coordinator.

## Production coordinator
- Title: `APEX_GLOBAL_POINTER_CAS_COORDINATOR_V1`
- File ID: `1vb-ak0UwoZIAaM8dCISF5eleQuHHJGU49EkYrZ5OzHo`
- Protocol: `APEX_POINTER_DOCS_COORDINATOR_FENCED_COMMIT_V1`

## Commit protocol
1. Read the exact active raw pointer and compute its full bytes SHA-256.
2. Read the coordinator state and revision ID.
3. Require coordinator `COMMITTED` state to match active pointer file ID, epoch, and bytes SHA-256.
4. CAS coordinator `COMMITTED -> CLAIMED` using `requiredRevisionId`.
5. Re-read the raw active pointer. Parent file ID, epoch, and full bytes SHA-256 must still match.
6. Update the same raw pointer object in place.
7. Re-read raw pointer and require stable file ID, candidate epoch, and exact candidate bytes SHA-256.
8. CAS coordinator `CLAIMED -> COMMITTED(candidate)` using the revision returned by the successful claim.
9. Re-read bundle and pointer; only then mark promotion active.

The successful coordinator claim is the linearization point. All compliant APEX writers must use this one coordinator. A stale writer cannot acquire the claim because its required Docs revision no longer matches.

## Crash recovery
- Coordinator `CLAIMED`, raw pointer still parent: retry or release the claim only after parent verification.
- Coordinator `CLAIMED`, raw pointer equals candidate: finalize coordinator to `COMMITTED`.
- Coordinator `CLAIMED`, raw pointer equals neither: hard halt; no automatic overwrite.

## Validation
A live connector probe created a temporary raw pointer and temporary Docs coordinator. Writer A acquired the expected-revision claim, Writer B using the same stale revision was rejected, Writer A updated the raw pointer in place, exact byte-hash readback passed, and the coordinator finalized successfully. Probe artifacts were then deleted. Production active pointer was not touched by the probe.

## v1.1 fail-closed hardening
The executable adapter now enforces the documentation literally rather than treating missing connector evidence as acceptable:
- post-claim parent re-read **must** supply a full raw-pointer bytes SHA-256; missing hash halts;
- post-write readback **must** supply the candidate bytes SHA-256; missing hash halts;
- candidate pointer bytes must parse to exactly the submitted pointer payload;
- candidate pointer must preserve `APEX_GLOBAL_STATE_LATEST.txt` and the stable pointer file ID;
- pointer epoch must advance by exactly one;
- `BUNDLE_SHA256` must be a 64-hex digest and `STATE_DIGEST` must equal `sha256:BUNDLE_SHA256`;
- successful coordinator claim must return a revision ID before finalization is attempted.

These are execution/control-plane integrity checks only. They do not alter any sport simulation, generator, calibration, selector, or portfolio logic.
