# MLB Showdown — Underdog Value-CPT / No-Full-Price / Elite Conditional-RP Core-5 v1

Patch: `MLB_SD_UNDERDOG_VALUE_CPT_NO_FULL_PRICE_ELITE_COND_RP_CORE5_v1`

## Purpose

This patch refines the existing underdog value-Captain 5-1 single-RP family. It implements the bargain-shopping Captain doctrine at the full six-man lineup level rather than simply ranking the highest raw-ceiling Captain or the highest-appearance-probability reliever.

Production remains pre-lock and identity-free. Realized contest scores, LineStar results, player-name constants, and contest IDs are prohibited selector inputs.

## Structural gate

A lineup enters the refined Core-5 candidate lane only when it already belongs to the pre-lock `HITTER_CPT_UNDERDOG_5_1_SP_SINGLE_RP_RECALL` family and additionally satisfies all of the following:

- Captain is the pre-lock roster-unlocker/value branch;
- Captain team is the underdog by frozen team-total context;
- branch is 5-1;
- exactly one same-team starter and exactly one same-team calibration-qualified reliever are rostered;
- no same-team hitter in CPT or UTIL is the team full-price active hitter;
- the reliever's pre-lock role probability is at least `0.15`;
- the reliever's simulated conditional P95 is at least `95%` of the best conditional P95 among calibration-qualified relievers on that team.

The full-price test covers both CPT and UTIL. The purpose is to enforce the shopping principle rather than allowing a cheap Captain while simply buying the sticker-price bat back in UTIL.

## Ranking inside the refined family

Once the structural gate is satisfied, lineup-level championship probability is primary:

1. MC win rate;
2. MC Top-0.1% rate;
3. P99;
4. existing quality score;
5. deterministic lineup ID.

If no lineup passes the refined gate, the previous generic underdog value-CPT 5-1 single-RP Core-5 seat remains the fallback.

## Relief-tail interpretation

Appearance probability and conditional upside are different quantities. A reliever with a lower probability of appearing can still be the superior tournament bargain when, conditional on appearing, his strikeout/save/hold path produces the strongest right tail at the same salary. The role-probability floor prevents the selector from chasing implausibly rare appearances, while the conditional-P95 ratio preserves the highest-upside qualified relief paths.

## 823 calibration evidence

Validation used the frozen full-run pre-lock Phase-2 tape plus a fresh 50,000-trial pre-lock player simulation. The parent underdog value-CPT 5-1 single-RP family contained 2,912 candidates. The no-full-price + elite-conditional-RP refinement contained 445.

Within that refined family, the MC-win-first rule selected lineup index `350605`, which post-lock validation identifies as the 110.5-point LineStar perfect lineup. The existing distributed underdog SP-CPT hedge still selected lineup index `30105`, the actual contest winner. Those identities are validation-only evidence; neither identity appears in the production selector logic.

A subsequent full fresh 50,000-trial end-to-end production rerun completed successfully. The frozen final playable Core-5 contained the independently established perfect lineup in seat 1 and the actual contest winner in seat 3. Machine-board parity and the strict success gate both passed. Post-lock identities and realized scores remained validation-only and were not selector inputs.
