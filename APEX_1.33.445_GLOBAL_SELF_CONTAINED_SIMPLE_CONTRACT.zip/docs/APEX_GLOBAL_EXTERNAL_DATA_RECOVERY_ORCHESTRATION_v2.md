# APEX Global External Data Recovery Orchestration v2

## Permanent rule
A recoverable public-data gap is an orchestration event, not an engine failure and not a reason to patch a sport model.

Production flow:

`child signal -> runner classification -> durable recovery request -> public search -> identity/timestamp/source validation -> exact schema injection -> same pinned-state same-slate rerun`

The runner must never blindly retry an identical child when the missing information has not changed.

### T_RUNS adapter
For MLB implied team runs, emit `VARIABLE=T_RUNS`, active team entities, and require injection through `APEX_TEAM_RUN_TOTALS_JSON`. At least two current public market sources are required when practical; source conflicts outside the existing recovery tolerance fail closed.

### Terminal semantics
- exit 76 + `RUN_STATE=EXTERNAL_DATA_RECOVERY_REQUIRED`: orchestration must recover and rerun.
- after two failed recovery attempts: `RUN_INVALID:UNRECOVERABLE_EXTERNAL_DATA_GAP`.
- no sport simulation/generator/selector code change is permitted for this class of failure.
