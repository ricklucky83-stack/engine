# APEX Global Terminal AI Hybrid Selector v4

## Purpose
v4 changes only the terminal intelligence surface. Candidate generation, calibration, simulation, ownership, legality, and the public-field model remain engine-owned and frozen before AI review.

## Global rule, exact local profile
Every supported sport and contest type uses the same terminal authority contract but receives an explicit sport × contest-type intelligence profile. A profile controls which structural relationships are meaningful; it never removes candidates.

Supported production profiles include MLB Classic / Showdown / SS HRS, WNBA Classic / Showdown, NFL Classic / Showdown, CFB Classic / Showdown, PGA Classic / Showdown Flat-6 / Showdown Captain, Tennis Classic / Showdown, MMA Classic / Showdown, and aligned NBA/CBB/NHL profiles where those runtimes are available. Golf routes to PGA; UFC routes to MMA.

Undefined sport/mode intelligence profiles fail closed rather than borrowing another sport's rules.

## Full handoff remains absolute
- 100% of calibration-qualified / selector-reviewed lineups remain AI eligible.
- No pruning.
- No Top-N sieve.
- No AI cohort.
- No Pareto cut.
- No beam frontier.

Relationship computation is evidence enrichment only. It cannot change the candidate count.

## Intelligence added in v4
### Universal
- Binomial 95% uncertainty half-width for MC Win and MC Top-0.1 probability.
- Exact-player-set family identity and family Top-0.1 mass.
- One-player mutation neighborhood density.
- Two-player mutation relationships are computed on demand for profiles where they are meaningful; they are not globally precomputed and never restrict eligibility.
- D1 neighborhood Top-0.1 and P99 density plus exact reciprocal-role sibling IDs.
- Market-tail vs MC-tail disagreement when independent pre-lock support fields exist.
- Selector disagreement remains evidence, not command.

### Multiplier contests
Reciprocal captain/multiplier siblings are role-distinct lineups. A lineup using the same player set with a different multiplier assignment is **not** a duplicate. This fixes the v3 validator mismatch exposed by calibration.

Reciprocal siblings are protected from automatic redundancy penalties but are never automatically selected.

### MLB Showdown native context
The terminal surface additionally carries, per slot:
- team;
- batting order;
- conditional-core support derived from pre-lock props / projection context;
- incoming-mutation support;
- team concentration;
- captain-side hitter count;
- batting-order adjacency.

These permit one-player / two-player mutation reasoning inside a championship neighborhood without naming or hard-coding a winning player.

## Conditional mutation doctrine
When two nearby lineups differ by a small number of players:
1. Compare MC Win and Top-0.1 differences to their simulation uncertainty bands.
2. If probability point estimates are statistically near-equivalent, do not pretend the larger point estimate is certain.
3. Compare tail magnitude (P95/P99), sport-native script completion, conditional-core fit, salary geometry, and independent pre-lock support.
4. A lower point-estimate candidate may be the superior tournament path when probability is equivalent and tail/script evidence is stronger.

No weighted scalar is globally authoritative. The AI receives components and performs the final judgment.

## Portfolio calibration gate
Realized contest rank is allowed only in offline calibration/backtest evaluation. It is prohibited from the production candidate surface and from terminal selection evidence.

Calibration acceptance gate:
`NEW_BEST_RANK <= PRIOR_BEST_RANK AND NEW_AVG_RANK < PRIOR_AVG_RANK`.

The latch advances to the best known calibration frontier after every accepted iteration. It is a validation criterion, not a production feature.

## Board order
AI selects five existing IDs → board is presented → legality / membership / candidate-freeze / board-hash validation runs. A failed post-board validation marks the shown board `BOARD_INVALID`; silent replacement remains prohibited.


## Large-universe chunk/stream stress contract
Large candidate universes may be stress-tested with a two-pass chunked stream without changing selector semantics.

Pass 1 streams every calibration-qualified lineup and builds compact **global** exact-family and D1 subset indexes. Pass 2 streams the same full universe in bounded chunks and derives/hash-checks structural evidence against those global indexes. Chunk-local percentiles or chunk-local family calculations are prohibited because they would change evidence at chunk boundaries.

The chunk/stream mechanism is test/runtime plumbing only:
- every qualified lineup remains AI eligible;
- no chunk is a cohort or pruning gate;
- cross-chunk family and D1 relationships remain visible;
- D2 remains on-demand over the complete candidate universe;
- deterministic rolling receipts must match the monolithic structural evidence hash at normalized selector-relevant precision.

MLB Showdown 2,139 calibration stress (62,440 candidates): 16 chunks of 4,096, 62,440 emitted, zero pruned, normalized structural semantic hash parity PASS versus monolithic enrichment. The chunked structural stress used ~173 MB peak RSS versus ~521 MB monolithic and completed the structural pass in ~2.84 seconds versus ~16.78 seconds in the comparison run. These timings are validation observations, not selection inputs or universal performance guarantees.
