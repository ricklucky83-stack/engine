# MLB SD Terminal Championship Species Portfolio Reserve v2

## Production status

`ACTIVE_VERIFIED_LOCKED_PRODUCTION_SELECTOR_PORTFOLIO`

This reserve operates after global terminal hybrid selection and before the final 50K rescore/board render. It preserves supported championship species when the native Top 5 is structurally concentrated or when cross-world-added families have repeated support.

## Verified evidence

The 1.33.215 sealed validation records:

- 3567: exact winner capture.
- 3208: exact winner capture.
- 2352: exact no-op control.
- 823: exact no-op control.
- Postlock results, realized points, standings, winner IDs, and player-name constants are not forward inputs.

## Authority comparison

Under `APEX_GLOBAL_BEST_VERIFIED_LOGIC_WINS_v1`, this mechanism remains the MLB Showdown terminal authority over `MLB_SD_TERMINAL_RECURRENCE_SELECTOR_v3` because it has stronger verified winner-capture evidence. Incumbency itself contributes no authority score.

The terminal recurrence V3 work remains research evidence and may challenge again when its verified evidence vector exceeds this production mechanism without violating hard integrity gates.
