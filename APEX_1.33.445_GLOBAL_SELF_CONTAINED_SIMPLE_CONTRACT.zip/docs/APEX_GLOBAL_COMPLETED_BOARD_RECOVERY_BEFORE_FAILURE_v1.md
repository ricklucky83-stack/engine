# APEX_GLOBAL_COMPLETED_BOARD_RECOVERY_BEFORE_FAILURE_v1

## Purpose

A live DFS run must not be reported as failed merely because the caller/runtime transport was throttled after the engine had already completed. The terminal path now performs a verified exact-slate completion lookup before relaunch or user-visible failure.

## Hard recovery order

1. Match `SPORT`, `MODE`, and `EXECUTION_ID`.
2. Require `RUN_STATE=BOARD_READY` and `EXECUTION_STATE=TOOL_PROVEN_EXECUTED`.
3. Match the current player-pool SHA-256 when the pool is available.
4. Match the active global state version when the receipt declares it.
5. Require the final board file SHA-256 to equal the receipt board hash.
6. Return that exact board immediately with `NO_RERUN=true`.
7. Only when no verified completion artifact exists may the engine launch or retry.

## Transport failures

`TooManyRequests`, transient runtime/tool throttling, connector transport errors, and caller-side interruption are not slate failures. Before any user-visible failure classification, the output directory must be checked for a completed exact-slate board/receipt pair.

## State-fetch policy

After an active state pointer and bundle are hash-verified, that state is session-pinned. Do not refetch the same pointer/bundle during the same run unless the pointer changes or local verification fails.

## Non-goals

This patch does not change projections, player availability logic, lineup generation, simulation depth, selector ordering, ownership, or final portfolio strategy. It only repairs completion detection and prevents unnecessary reruns.
