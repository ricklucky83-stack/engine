# NFL Showdown Public-Field Universe Decoupling v1

## Defect
The production NFL Showdown simulator sampled its synthetic opponent field from the same Phase-2 rows being evaluated. This conditioned public-field thresholds and ordinal rank evidence on APEX membership.

## Repair
`run()` now freezes the pre-Phase2 calibrated candidate universe and passes it explicitly to `_simulate_phase2(..., public_field_rows=candidates)`. Phase-2 rows remain the evaluation surface. Synthetic opponent identities are sampled only from the separate pre-Phase2 source, then reused for base and adaptive batches.

## Integrity
- Phase-2 membership logic unchanged.
- Selector and order logic unchanged.
- No player-name constants.
- No postlock contest truth used.
- Production fails closed if an explicit pre-Phase2 public-field source is absent.
- Receipt exposes source count/hash and `PUBLIC_FIELD_PHASE2_CONDITIONED=false`.

## Remaining open calibration
The current field weight still relies primarily on marginal CPT/FLEX ownership plus a role tilt. Salary-left, co-roster, team-split and other field-dependence calibration remain separate work and are not fitted from the diagnosed same-slate result.
