# NFL_SHOWDOWN_GLOBAL_CORE5_TERMINAL_AND_DOMINANT_FAMILY_CAP_v1

Status: ACTIVE_VERIFIED_LOCKED_PRODUCTION

## Contract

- The final five are one coordinated high-confidence parlay under `APEX_GLOBAL_TOP5_HIGH_CONFIDENCE_PARLAY_v1`; they are not five independent ranks.

- NFL Showdown sport-native selection may retain a 10-line review surface.
- The review surface is non-terminal and must never be rendered as the playable board.
- `APEX_GLOBAL_CHAMPIONSHIP_CORE_5_v1` is the final playable-board authority.
- Final playable board size is exactly five when satellites are disabled.
- The dominant one-swap family is capped at three Core-5 seats, including the generic fill step.
- When alternate families exist, remaining seats must come from alternate/counter-script families.
- Direct native board rendering is prohibited.
- Machine artifact/hash parity is required before user-visible rendering.
- No post-lock contest results or player-name hardcodes are used.

## Code

- `engines/common/apex_global_championship_core_v1.py`
- `engines/common/apex_global_production_board_runner_v1.py`

## 5,490 replay

The prior 10-line NFL Showdown board contained a five-line dominant one-swap cluster in source ranks 1/2/3/4/6. The repaired Core-5 keeps at most three from that cluster and reserves the remaining seats for alternate families when available.
