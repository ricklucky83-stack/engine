# MLB Showdown Live-Set Checkpoint and Terminal Memory Safety v1

## Incident
A DraftKings MLB Showdown 1,176 production run under original failure parent state 1.33.223 completed through `ELITE_SIBLINGS_AND_NATIVE_SELECTOR` and then hit the 4 GiB cgroup limit in `AI_TERMINAL_AND_CHAMPIONSHIP_RESERVE`. The OS killed the worker (`SIGKILL=-9`). This is an execution/control-plane regression, not a model, generator, simulation, or selector-objective failure.

## Prior invariant that regressed
The locked global terminal-memory doctrine from state 1.33.190 requires streaming validation/hash, disk-backed semantic freeze, compact selector handling, and final-selected-row hydration. The 1.33.223 MLB Showdown call path had reintroduced large Python object graphs and full-state checkpoint serialization around that boundary.

## Corrective action
1. Checkpoints serialize only values proven live in future runtime statements plus required mutable globals.
2. Terminal enrichment supports in-place execution to avoid full candidate copy chains.
3. The caller-owned candidate graph is cleared immediately after the atomic terminal CSV is durably committed and before disk-backed semantic freeze.
4. The durable terminal CSV is marked `POSIX_FADV_DONTNEED` after fsync/consumption so page cache does not consume the production cgroup envelope during SQLite freeze.
5. Candidate membership, frozen metrics, multi-seed logic, selector objective, and final-row semantics remain unchanged.

## Preventive action
Promotion is forbidden unless all of the following hold:
- targeted semantic-parity and regression tests pass;
- the exact failed 1,176 run resumes from the last completed checkpoint without recomputing earlier stages;
- `memory.events:oom_kill` does not increase;
- final terminal surface and board are sealed;
- candidate pruning remains zero;
- model/generator/simulation/selector-objective hashes are unchanged except execution plumbing files explicitly listed by this CAPA.

## Acceptance receipts
The validation receipt is stored at `receipts/mlb_showdown_terminal_memory_capa_v1/validation_receipt.json` at `receipts/mlb_showdown_terminal_memory_capa_v1/validation_receipt_v1.33.227.json`.

## Production rebase
The execution-only CAPA was rebased onto active state `1.33.225`; the active MLB Showdown terminal portfolio selector v4 is preserved unchanged. Target immutable production state: `1.33.227`.
