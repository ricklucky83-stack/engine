# Tennis Classic BARE MIN Cap-Only Legality v1

## Scope
This patch changes only the explicit `BARE MIN` alternate runtime for DraftKings Tennis Classic. The regular production Tennis v2 engine is unchanged.

## Defect
The BARE MIN runtime contained `SALARY_MIN=48000`, which contradicts the active Tennis global rule prohibiting a fixed salary floor. Contest 195185698 provides a direct regression control: the rank-1 lineup spent $47,900 and the rank-3 family spent $47,800.

## Repair
- Fixed minimum-spend legality gate removed.
- Salary legality is cap-only: positive total salary at or below $50,000.
- Salary geometry remains eligible as ranking evidence only.
- Same-match coexistence remains allowed; no opponent-pair hard legality ban is introduced.
- `FAST PATH` alone does not activate this runtime; the exact `BARE MIN` phrase remains required.

## Non-mutation boundary
Regular Tennis v2 Phase 1, Phase 2, sport simulation, handoff, Hybrid Selector, and portfolio logic are unchanged.
