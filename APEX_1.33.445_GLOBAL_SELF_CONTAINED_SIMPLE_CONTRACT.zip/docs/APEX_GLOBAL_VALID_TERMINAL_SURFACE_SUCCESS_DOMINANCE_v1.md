# APEX Global Valid Terminal Surface Success Dominance v1

## Incident
A production MLB Showdown 705 run completed the selector-reviewed terminal candidate surface and native board, then the sport child exited nonzero during later receipt/cleanup work. The global supervisor only finalized the terminal handoff when `child_return_code == 0`, so it misclassified the run as `MACHINE_BOARD_ARTIFACT_MISSING`, retried the expensive sport engine, and exposed canonical terminal files to overwrite/mixed-generation risk.

## Repair
1. A validated terminal candidate surface + matching receipt pair is a terminal-success checkpoint regardless of later child exit code.
2. Commit that surface to the durable ledger before any external-recovery, retry, or deterministic-no-progress classification.
3. Resume from the committed surface. If a valid Hybrid AI decision exists, validate it and seal Core-5. If no decision exists, emit the last-step `HYBRID_SELECTOR_HANDOFF_REQUIRED` state without replaying the sport engine.
4. Never replay the sport engine after a valid terminal surface has committed.
5. Validate candidate surface hash, semantic freeze hash, and row count against the receipt before durable commit.
6. Publish candidate CSV and receipt with same-filesystem temp files, `fsync`, and atomic `os.replace`, so canonical files are never exposed partially written.
7. Bind terminal receipts to `APEX_SINGLE_FLIGHT_RUN_IDENTITY` for provenance.

## Research basis
- AWS Step Functions Standard workflows persist execution state and redrive resumes from the failed state while preserving successful state outputs.
- Azure Durable Functions manages checkpoints, retries, and recovery for stateful workflows.
- Durable execution retry guidance requires idempotent/replay-safe side effects.

## Non-goals
No sport simulation, generator, calibration, ownership, selector objective, or portfolio logic changes.


## Descendant authority clarification
The success-dominance rule still means a valid terminal surface dominates a later child exit and suppresses expensive engine replay. Under `APEX_GLOBAL_HYBRID_SELECTOR_LAST_STEP_EXECUTION_FENCE_v1`, success dominance stops at the frozen selector handoff when the Hybrid AI decision has not yet been committed. It never authorizes an engine-internal substitute selector.
