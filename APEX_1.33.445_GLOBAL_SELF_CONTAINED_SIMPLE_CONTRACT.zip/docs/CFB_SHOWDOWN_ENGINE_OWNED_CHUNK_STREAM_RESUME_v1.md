# CFB Showdown Engine-Owned Chunk/Stream Resume v1

Production CFB Showdown now dispatches through `cfb_showdown_chunk_stream_controller_v1.py` instead of treating `execute()` as one external transaction.

## Streamed work
1. Base and extra public-field thresholds are evaluated in trial chunks.
2. Legacy-continuity and promoted Phase-3 lineup evaluation are persisted in lineup chunks.
3. Win/Top-0.1 world bit ledgers are persisted per promoted lineup chunk.
4. Cross-world recurrence telemetry is evaluated and persisted in recurrence-row chunks.
5. Selector work consumes the frozen committed artifacts only after all required chunks reconcile.

Each chunk is atomically written, SHA-256 identified, and followed by a durable cursor update. After the current chunk is committed, the engine checks its soft deadline. When necessary it emits `CHECKPOINTED_CONTINUE` with return code 75; the production supervisor automatically reinvokes the same command.

No completed chunk is restarted. No Chat continuation step is required.

## Semantic contract
Chunk size is an execution parameter only. Thresholds, lineup metrics, world bitsets, recurrence telemetry, selector inputs, and final board must be invariant to chunk boundaries.
