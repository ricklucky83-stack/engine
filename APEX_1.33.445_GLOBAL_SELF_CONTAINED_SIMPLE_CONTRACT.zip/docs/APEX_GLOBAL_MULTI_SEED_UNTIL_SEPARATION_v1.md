# APEX_GLOBAL_MULTI_SEED_UNTIL_SEPARATION_v1

## Purpose

Eliminate direct sorting of statistically overlapping rare-event candidates at the final Rank-1/Top-0.1% inclusion boundary. The engine must reduce Monte Carlo boundary noise with deterministic, sport-native multi-seed re-simulation before terminal selection.

## Authority boundary

- The **sport-native runtime** owns all additional simulation physics.
- The global elite-tail module owns only overlap detection, seed scheduling, ID/trial parity validation, convergence bookkeeping, and lineage propagation.
- The terminal AI selector has **no simulation authority**. It consumes the frozen post-convergence candidate surface only.
- No lineup may be created, removed, substituted, or pruned by this loop.

## Deterministic convergence loop

1. Enrich the complete selector-reviewed handoff with Rank-1 and Top-0.1% uncertainty intervals and structural-neighborhood shrinkage.
2. Identify the provisional board inclusion boundary.
3. If an outside elite candidate overlaps the boundary on both Rank-1 and Top-0.1% confidence intervals, construct the complete entangled bubble.
4. Re-simulate the exact bubble IDs with a fresh deterministic seed using the sport-native simulator and common random numbers within that seed.
5. Require exact returned lineup-ID parity and strictly increasing cumulative `MC_TRIALS`.
6. Merge only refreshed simulation evidence, re-enrich the complete handoff, and recompute the boundary.
7. Repeat with geometrically increasing trial budgets until separated or the configured maximum convergence budget is exhausted.
8. If the budget is exhausted with overlap remaining, label the cohort `MAX_BUDGET_EQUIVALENT`; never falsely claim statistical separation.

## Required telemetry

Each candidate carries:

- `MULTI_SEED_PATCH_ID`
- `MULTI_SEED_CONVERGENCE_STATUS`
- `MULTI_SEED_ROUNDS`
- `MULTI_SEED_EXTRA_TRIALS`
- `MULTI_SEED_SEEDS`
- `MULTI_SEED_SEPARATION_DELTA`
- updated `SIM_VARIANCE_METRICS`

The run receipt carries round seeds, world-trial budget, lineup-trial evaluations, final boundary ID, unresolved bubble count, and separation status.

## MLB Showdown production wiring

`mlb_showdown_raw_pool_runtime_v1_7.py` uses `apex_terminal_ai_hybrid_selector_v6` and supplies an MLB Showdown callback that:

- generates fresh sport-native player worlds for each seed;
- constructs same-seed public-field thresholds;
- scores every bubble lineup against the same seed/world tape (CRN);
- accumulates Rank-1, Top-0.1%, Top-10 and mean metrics by trial-weighted counts;
- leaves primary-tape P95/P99 secondary moments frozen;
- preserves the exact candidate identity set.

The global production board runner rejects MLB Showdown terminal handoff unless the patch ID is present and convergence status is `SEPARATED`, `NOT_REQUIRED`, or explicitly unresolved-as-equivalent at the configured maximum budget (`MAX_BUDGET_EQUIVALENT`).
