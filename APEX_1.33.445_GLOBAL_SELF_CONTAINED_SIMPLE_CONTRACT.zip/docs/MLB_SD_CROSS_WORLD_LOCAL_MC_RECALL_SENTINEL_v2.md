# MLB SD Cross-World Local-MC Recall Sentinel v2

Status: ACTIVE_VERIFIED_LOCKED_PRODUCTION_GENERATOR_RECALL (pending bundle activation).

- Source: `engines/mlb/mlb_showdown_cross_world_local_mc_recall_sentinel_v2.py`
- Source SHA256: `155da109b7371d70c3abfaf087275db76c54c790b271114a0a415671a5fcd890`
- Runtime wiring: `engines/mlb/mlb_showdown_raw_pool_runtime_v1_7.py`
- Runtime SHA256: `48e034e09ed9bed106856fb0a36e750502383971e2dd3cd35f9035bff4a4ce96`
- Scope: DraftKings MLB Showdown generator recall only.
- Terminal MC authority: unchanged.
- Selector logic: unchanged.
- Postlock results as forward inputs: prohibited.
- Rule: CPT-preserved supported five-player cores; min native support 4; 5 disjoint 2,000-world windows; local rank 1; require recurrence in >=4/5 windows; 8,192-lineup chunks; atomic checkpoints.

Validation on the 1.33.207 MLB-identical surface:
- 3567: winner and legal 105.0 perfect absent natively, both recalled; final/handoff 126,987/126,987.
- 2352: historical winner preserved; final/handoff 156,296/156,296.
- 823 replacement holdout (contest 193303574): historical winner preserved; final/handoff 94,716/94,716.
- Integrated 823 runtime reached and atomically committed all five v2 windows with the exact source hash. The later monolithic terminal path timed out and was not retried; this does not certify final-board capture.

Production seal is limited to generator recall/handoff parity. End-to-end selector winner capture remains separate work.
