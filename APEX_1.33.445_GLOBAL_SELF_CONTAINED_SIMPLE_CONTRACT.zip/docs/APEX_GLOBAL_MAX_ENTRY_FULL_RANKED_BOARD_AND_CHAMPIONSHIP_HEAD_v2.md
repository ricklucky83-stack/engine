# APEX Global MAX ENTRY Full Ranked Board + Championship Head v2

Effective: 2026-09-19 21:07:07 CDT

Newest dated production authority wins when rules conflict.

MAX ENTRY controls the final playable membership cap. The selector may return fewer only when active quality, legality, duplication, or portfolio constraints reject additional rows; fixed five- or ten-row compression is prohibited.

The full selected portfolio is ranked #1 through #N. Ranking and membership are separate authorities.

Championship Head is an ordering layer only. It may place highly similar closure/neighborhood lineups in the highest seats when supported by the active closure logic. It is not a diversification filter and it cannot delete rows #6 through #N.

Chat memory is not production authority. This doctrine and the canonical engine implementation are durable authority.
