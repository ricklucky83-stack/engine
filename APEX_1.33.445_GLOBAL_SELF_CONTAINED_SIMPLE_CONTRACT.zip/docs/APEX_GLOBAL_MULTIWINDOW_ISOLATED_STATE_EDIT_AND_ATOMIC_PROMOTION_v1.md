# APEX Global Multi-Window Isolated State Editing v1

## Objective
Permit simultaneous engine editing from multiple Chat/Work windows without cross-window contamination, stale overwrite, partial production mutation, or cross-sport leakage.

## Mandatory architecture
1. The active bundle is immutable and never edited in place.
2. Every editing window starts from a pinned `BASE_STATE_VERSION` and `BASE_BUNDLE_SHA256`.
3. Every workspace records the SHA-256 of each component it intends to touch before editing.
4. Sport-local work stays inside the sport namespace. Shared/global files pass the global merge gate.
5. Immediately before promotion, refetch the active pointer and compare it with the workspace base.
6. If the base state or bundle changed, return `REBASE_REQUIRED`; do not rotate the pointer.
7. If any touched component changed since workspace creation, return `MERGE_CONFLICT`; do not auto-overwrite it.
8. Nonconflicting changes may be merged into a new immutable state.
9. Promotion creates a complete bundle first, validates its manifest/hashes, uploads it, then atomically rotates the active pointer.
10. Pointer/bundle readback is mandatory before the change is considered global.

## Run isolation
Every production run pins:
- `RUN_STATE_VERSION`
- `RUN_BUNDLE_SHA256`
- `RUN_COMPONENT_HASHES`
- `RUN_SNAPSHOT_SHA256`

A run may finish against the immutable state on which it started even when another window promotes a newer state. Mid-run source switching is prohibited. New runs use the newest active verified state.

## Scope model
- `engines/mlb/` → MLB-local
- `engines/cfb/` → CFB-local
- `engines/nfl/` → NFL-local
- `engines/wnba/` → WNBA-local
- `engines/tennis/` → Tennis-local
- `engines/pga/` → PGA-local
- `engines/mma/` → MMA-local
- `engines/common/`, `engines/global/`, global doctrine/docs, registry and bundle manifest → GLOBAL

A sport-local workspace may touch its sport files plus explicitly declared global support files. It may not mutate a different sport namespace.

## Promotion receipts
A valid promotion must prove:
- `BASE_CONCURRENCY_CHECK=PASS`
- `PATCH_SCOPE_CHECK=PASS`
- `CONFLICT_COUNT=0`
- `MERGE_STATE=AUTO_MERGE_SAFE`
- `INTERNAL_MANIFEST_CHECK=PASS`
- `BUNDLE_HASH_CHECK=PASS`
- `POINTER_COMPARE_AND_SWAP=PASS`
- `POINTER_READBACK=PASS`
- `BUNDLE_READBACK=PASS`

Any stale base or touched-component drift fails closed before pointer rotation.

## Stable Pointer CAS Extension
- `APEX_GLOBAL_STATE_LATEST.txt` keeps one stable Drive object ID across promotions.
- Every window pins the exact active pointer file ID, pointer epoch, state/bundle identity, and full pointer-bytes SHA-256.
- Immediately before commit, all pinned values are re-read and must still match.
- The existing active pointer object is updated in place only through atomic compare-and-swap.
- Delete, retire, rename, and replacement of the active pointer object during promotion are prohibited.
- A stale writer fails with `REBASE_REQUIRED` / `STALE_WRITE_ABORT`; it cannot use last-writer-wins.
- Pointer and immutable bundle readback remain mandatory.
