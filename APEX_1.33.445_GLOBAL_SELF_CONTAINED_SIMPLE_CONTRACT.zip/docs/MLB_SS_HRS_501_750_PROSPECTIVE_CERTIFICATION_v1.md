# MLB SS HRS 501–750 prospective certification

Production execution for this field bucket is engine-owned `CHUNK_AND_STREAM_ONLY`. The controller streams legal triads into a disk-backed candidate surface, assigns global RNWD percentile ranks through bounded resumable passes, merges route neighborhoods as streams, and freezes a ten-line board before any outcome is accessible.

Certification is prospective only. Historical controls `191864350` and `191950963` are permanently read-only and cannot earn promotion credit. A board captures the winner only when one of its three-player sets exactly matches an entered rank-1 contest lineup. Matching the winning realized HR score without an exact entered lineup match is not winner capture.

Minimum gate: field 501–750, board 10, MC >= 10,000, fake field >= contest field, full Phase-2 birth and selector-review parity, immutable pool/engine/candidate/board/receipt hashes, and no postlock selector mutation. Exact entered rank-1 advances the candidate; Top 0.1% without exact rank-1 remains research-only; all other outcomes require repair on new prospective evidence.
