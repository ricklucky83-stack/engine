# NFL_SD_MC_RELIABILITY_LEDGER_v1

Production instrumentation only. Every NFL Showdown run freezes the complete Phase-2 MC probability surface before selector membership is evaluated. The artifact is a local NPZ sidecar next to the run receipt and contains lineup identities, physical simulation counts/rates, P95/P99, available ordinal-world evidence, and structural prelock metadata.

The ledger does not modify Phase-2 membership, MC parameters, selector membership, or terminal ordering. Postlock results may grade the frozen surface using Brier, class-balanced Brier, and class-balanced log loss, but source-slate truth is evaluation-only and cannot flow back into that slate.

Any future MC parameter promotion requires multiple distinct underlying games with genuinely prelock-frozen surfaces, chronological cross-slate validation, and compatibility with `ABSOLUTE_TAIL_CALIBRATION_GATE_v1`.
