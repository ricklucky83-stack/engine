# MLB_CLASSIC_SMALL_SLATE_LOW_TOTAL_MARGINAL_SYNC_v1

- Sport/mode: MLB Classic
- Production scope: active teams <= 8
- Alpha: 0.55
- Low-total cut: 4.0 implied runs
- Phase 1: unchanged
- Generator: unchanged
- Selector: unchanged
- Player/team-environment empirical marginals: preserved exactly by permutation
- Large slates: no-op

## Evidence

- 8-team blind 6,274 control: Top-0.1 and Top-1 improved.
- 4-team blind 705 control: non-regression.
- 26-team 5,945 control: forced alpha regressed; this proves global activation is prohibited and is why >8 teams is a hard no-op.
- 6-team 3,137 target: joint-event support improved, but exact winner still did not reach the final board.

This is a joint-event calibration repair, not a selector force-in.
