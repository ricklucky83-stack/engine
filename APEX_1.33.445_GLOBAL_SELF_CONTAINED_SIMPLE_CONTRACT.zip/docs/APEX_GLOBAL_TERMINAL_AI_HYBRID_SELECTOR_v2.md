# APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v2

## Purpose
Restore AI Hybrid as a strictly isolated terminal decision layer. The engine owns every upstream stochastic and legality operation. The AI can only choose five existing frozen candidate IDs.

## Boundary
`engine -> frozen selector-reviewed candidate matrix -> AI terminal adjudication -> Top-5 parlay validation -> production board seal`

The AI cannot create a lineup, alter metrics, alter ownership, change the public-field model, recalibrate, rerun simulations, or consume post-lock outcomes. Candidate bytes are frozen and hashed before AI review. The returned decision contains only lineup IDs and reason codes; code validates the decision against the frozen matrix.

## Current coded selector
The existing selector is retained as an advisory comparator. Its score, rank, selected flag, family/core protection and structural labels are exposed as evidence. When AI authority is enabled, those outputs cannot force terminal seats.

## Top-5 parlay
The final five remain one coordinated high-confidence portfolio under `APEX_GLOBAL_TOP5_HIGH_CONFIDENCE_PARLAY_v1`. The AI must explicitly account for marginal championship/Top-0.1 coverage, supported family concentration, and controlled counter-script diversification. Five independent scalar ranks are prohibited.

## AI evidence pack
Primary tail: win, Top-0.1, Top-1, lower confidence bounds. Tail shape: P95, P99, CVaR99, asymmetry. Robustness: trials, rank uncertainty, cross-seed and perturbation stability. Field-relative: exact-duplication expectation, uniqueness, governed ownership and field-model reliability. Family: championship mass, sibling count and scenario support. Portfolio: common-world marginal coverage and pairwise outcome correlation. Structure: CPT role, branch/route, salary geometry, SP/RP count. Comparator: current coded selector score/rank/protection.

No one weighted score is treated as truth. The AI compares multiple evidence lanes and explains each selected leg with bounded reason codes.

## Decision protocol
The AI starts from the full frozen selector-reviewed set. It identifies a multi-lane elite frontier instead of collapsing all evidence into one score. Field-dependent metrics are discounted when the field-model reliability flag is low. Each selected leg needs strong individual tail support; later seats must add credible marginal championship/Top-0.1 or regime coverage unless a dominant family is strongly supported. Current-selector disagreement is an opportunity signal, not automatic contrarianism.

## Derived evidence
The terminal surface derives uncertainty gaps, P99-P95 spread, tail asymmetry, duplication-adjusted win/Top-0.1 rates, empirical percentiles, elite-support breadth, a robust-tail floor percentile, and Top-0.1-versus-coded-selector disagreement. These are transparent helper features; none is a mandatory scalar objective.
