# TENNIS_STALE_ROUND_MARKET_RECOVERY_AND_BALANCED_UPSET_SELECTOR_v1

## Purpose

Recover DraftKings Tennis Classic slates when the supplied third-party player pool is from a stale/prior round but the active contest universe can be reconciled and current-round pre-match win probabilities are available. The recovery lane exists to prevent stale projection coverage from making a contest-winning lineup structurally impossible or selector-invisible.

## Authority Order

1. DraftKings contest/player eligibility is the roster authority.
2. DraftKings salary is authoritative when available. If exact salary is unavailable during historical CAR SHOP repair, a clearly labeled proxy salary may be used; it must not be represented as exact.
3. RotoWire or other third-party exports are enrichment sources only. They are not allowed to delete a DraftKings-eligible player from the active universe.
4. Current-round pre-match market probabilities may recover matchup strength when stale-round FPTS/VAL are neutralized.
5. Realized FPTS, final rank, winner labels, player names, and other post-lock outcomes are prohibited as forward selector features.

## Activation Gate

The recovery lane activates only when all of the following are true:

- standard six-player DraftKings Tennis Classic roster;
- explicit match-win probability is finite for every active player;
- every weak FPTS/VAL prior has been marked missing/nonpositive and neutralized by the existing missing-prior policy;
- the production selector receives no post-lock result fields.

If any condition is false, the recovery lane is inert and normal Tennis Classic selection is unchanged.

## Recovery Family

The v1 recovery family is a tightly gated balanced-upset construction. It uses only pre-lock/player-simulation information and structural lineup fields. Its current protected-lane contract is stored in `doctrine/TENNIS_STALE_ROUND_MARKET_RECOVERY_AND_BALANCED_UPSET_SELECTOR_v1.json`.

The lane is capped at two reserved board slots and is subject to exposure and overlap limits. It does not replace the primary Top-0.1% / win-tail selector.

## Historical CAR SHOP Validation

Historical target: DraftKings contest `194431147`, field size `2614`.

The supplied RotoWire snapshot was a stale-round pool. The reconciled contest universe contained 26 players. Eight contest-eligible players were missing from the RotoWire export, including Elise Mertens. Under proxy-salary historical reconstruction and current-round market recovery, the production Phase-2 generator produced the actual contest winner and the recovery lane placed it on the final board.

Validation receipt: `receipts/tennis_stale_round_market_recovery_balanced_upset_v1/validation_receipt_v1.33.68.json`.

## Runtime Receipts

Production final receipts must expose:

- `MARKET_RECOVERY_PATCH_ID`;
- `MARKET_RECOVERY_DOCTRINE_SHA256`;
- `MARKET_RECOVERY_ACTIVE`;
- `MARKET_RECOVERY_SELECTED`;
- `MARKET_RECOVERY_REASON_CODE`;
- `MARKET_RECOVERY_COMPATIBILITY_PATCH_ID`;
- `MARKET_RECOVERY_DOC_CODE_PATCH_ID`;
- `MARKET_RECOVERY_TELEMETRY_OPTIONAL`;
- `MARKET_RECOVERY_LEGACY_ABSENCE_BEHAVIOR`.

These fields are observability only. They do not change lineup scores or selector ordering.

## Non-Regression Contract

- Recovery inactive => byte/ordering behavior remains governed by the existing normal Tennis selector paths.
- No player-name selector features.
- No realized FPTS or post-lock results as forward inputs.
- No post-hoc win-rate scalar. Field-size alignment remains 1:1 with contest size.
- Existing missing-prior, event-native probability, adaptive-bubble, pipeline-parity, and exact-tail contracts remain active.


## Legacy selector compatibility

`MARKET_RECOVERY_ACTIVE` is optional telemetry outside the gated stale-round recovery path. If the field is absent, the recovery lane is deterministically inactive and the existing Tennis selector lanes execute unchanged. Missing recovery telemetry must never raise or mutate an ordinary Tennis Classic selection.

## Completed Compatibility Validation

Validation on global state `1.33.71` established the backward-compatible selector contract:

- absent `MARKET_RECOVERY_ACTIVE` telemetry resolves to recovery inactive;
- malformed/length-mismatched recovery telemetry resolves to recovery inactive;
- a fully asserted recovery vector activates the gated recovery lane exactly as before;
- ordinary Tennis selector ordering and behavior are not mutated when the recovery gate is inactive;
- the complete Tennis suite finished `67 PASS / 11 SKIP / 0 FAIL` before this documentation/code hardening update;
- global failures reproduced on the parent state were classified as inherited and not introduced by the Tennis compatibility change.

The runtime uses one compatibility helper for both selector activation and final-receipt emission so legacy payload handling cannot diverge between execution and observability.
