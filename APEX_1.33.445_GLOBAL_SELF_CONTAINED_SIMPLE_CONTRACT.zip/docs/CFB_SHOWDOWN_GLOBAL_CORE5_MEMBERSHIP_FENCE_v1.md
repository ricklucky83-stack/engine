# CFB_SHOWDOWN_GLOBAL_CORE5_MEMBERSHIP_FENCE_v1

CFB Showdown-specific terminal membership fence.

- MAX ENTRY owns final portfolio membership.
- The older global exact-five terminal rule does not apply to CFB Showdown membership.
- Global runner must pass the already-sealed CFB Showdown max-entry board through unchanged.
- Core5 may order the championship head but may not add/remove portfolio members.
- AI terminal membership authority is prohibited for live CFB Showdown.
- Durable/completed recovery must prove the max-entry passthrough marker.
- All other sport/mode global Core5 behavior remains unchanged.
