# MLB Showdown Phase 2 Early-Bound Compiled Enumeration v1

## Scope
DraftKings MLB Showdown production runtime.

## Failure corrected
The prior Phase 2 legal-prebirth enumerator allocated against the theoretical Captain × C(N-1,5) upper bound and deferred salary, RP, dual-RP, and same-team rejection until the fifth FLEX slot. On large active pools this can exhaust the execution window or memory before a sealed Phase 2 artifact is produced.

## Production enumeration contract
- Search FLEX candidates in ascending salary order through a player-index permutation.
- Preserve original player IDs in all emitted lineups.
- Apply salary feasibility bounds at each depth.
- Track RP count, dual-RP qualification, and same-Captain-team count incrementally.
- Perform a count-only pass first.
- Allocate exactly the number of legal prebirth rows found.
- Perform a second emission pass and require count/emission parity.
- No First-N behavior, random sampling, hard candidate cap, or theoretical-upper-bound matrix allocation is permitted.

## Structural legality retained
- 1 CPT + 5 FLEX.
- Salary $40,000 through $50,000 inclusive.
- CPT must satisfy native CPT eligibility and cannot be RP.
- At most two RP in FLEX.
- A two-RP lineup requires both RP to satisfy the calibrated dual-RP quality gate.
- At most four FLEX players may come from the Captain team, therefore at most five total roster players may come from the Captain team.

## Calibration-first birth semantics
The optimized enumerator creates the complete legal **prebirth** surface only. It does not redefine Phase 2 birth. Phase 1 calibration remains authoritative. `phase2_birth` must admit the full calibration-qualified legal candidate universe from that surface without sampling, First-N truncation, or a hard candidate cap.

Production flow:

`RAW POOL -> PHASE 1 CALIBRATION -> LEGAL PREBIRTH ENUMERATION -> CALIBRATION-QUALIFIED PHASE 2 BIRTH -> SIMULATION -> HANDOFF -> SELECTOR -> FINAL BOARD`

## Final board
The MLB Showdown final production board contains exactly five lineups. The Top-5 core is the final board; seats 6-10 are disabled. No greedy post-selector exposure pass is added by this patch.
