# APEX MLB Showdown — Captain + Championship Core Architecture v1

## Objective

**WINNER_CAPTURE_OR_FAIL.** The production board is constructed to maximize the probability that at least one playable entry captures the contest-winning state. Contest-rank improvement is diagnostic only.

## Captain doctrine

Captain is a role, not an open roster slot. A player is Captain-eligible only when at least one prelock path is proven:

1. **Slate Breaker** — the player's simulated extreme tail can plausibly create the decisive 1.5x score.
2. **Roster Unlocker** — using the player at Captain creates a legal six-man construction whose lineup-level extreme-tail ceiling is materially competitive with the slate frontier.

Cheap salary alone is not an unlock proof. Mean projection alone is not a slate-breaker proof. Player names, contest results, and realized fantasy points are prohibited from Captain qualification.

## Core-5 + satellites

For frozen common-world trial `t`, let `M_t` be the opponent-field winning score and `S_i,t` be lineup `i`'s score. For board `B`:

`J(B) = mean_t I(max_{i in B} S_i,t >= M_t)`

The selector builds exactly five immutable Core entries first by marginal championship-event union. Correlated siblings are allowed when they cover new winning worlds. There is no blanket overlap penalty.

After Core-5 is frozen, up to five satellites may be appended only when they add strictly positive championship-event coverage. Satellites can never displace Core-5.

## Sport-native priority authorities

Global Core-5 accepts bounded, prelock sport-native structural authorities. Every protected lineup must still win at least one frozen championship world. No authority may use a player-name or postlock trigger.

### MLB Showdown normal SP-CPT market

Trigger: `SP_CPT_SHARE >= 0.50` and `DUAL_SP_SHARE < 0.50`.

Protect up to one 5-1 SP-CPT middle-order representative per opposing runback tier: TOP (1-3), MID (4-6), BOT (7-9).

### MLB Showdown high/high market

Trigger: `DUAL_SP_SHARE >= 0.50` and `SP_CPT_SHARE >= 0.50`.

Birth a bounded SP-CPT 4-2 control family only when:

- single-SP lineup, SP at Captain, CPT side 4 players;
- Captain passed the slate-breaker gate;
- three same-team hitters are batting 3-8;
- two opposing hitters are top-5;
- candidate survives the multi-tail birth union.

Broad SP-CPT 4-2 flooding remains prohibited.

## Validation checkpoint

The sealed promotion receipt records:

- CLE/NYM 823: winner born, reviewed, Core-5, final Board Rank 1, Contest Rank 1/823.
- DET/TB 1764: winner born, reviewed, Core-5, final Board Rank 3, Contest Rank 1/1764.
- ATH/MIN 3208 negative control: high/high and normal 5-1 priority triggers both false.
- No postlock selector input.

This candidate remains separate from live pointer activation until the candidate state is sealed and promotion gates are satisfied.

## Terminal production contract — Core-5 enforcement

The MLB Showdown sport-native selector may construct and rank a **10-line review surface**, but that object is not a playable terminal board. Its machine state is `NATIVE_BOARD_READY_FOR_GLOBAL_CORE5` and `TERMINAL_PLAYABLE_BOARD=false`.

Only `engines/common/apex_global_production_board_runner_v1.py` may convert that native review surface into a terminal `BOARD_READY` artifact. The runner must apply `APEX_GLOBAL_CHAMPIONSHIP_CORE_5_v1`, satellites remain disabled by default, and the MLB Showdown final playable board must contain exactly **5** Core entries.

A raw MLB Showdown runtime emitting the legacy terminal state `BOARD_READY` is rejected with `MLB_SHOWDOWN_LEGACY_NATIVE_BOARD_READY_PROHIBITED`. A sealed MLB Showdown board with satellites disabled that is not size five is rejected with `MLB_SHOWDOWN_CORE5_TERMINAL_SIZE_VIOLATION`.

This separation is mandatory so the 10-line native selector surface can never be rendered or represented as the final playable board.

