# MLB_CLASSIC_LOW_TOTAL_WITHIN_TEAM_SCORE_CONCORDANCE_v1

## Production scope
- DraftKings MLB Classic only.
- Active teams: 8 or fewer.
- Qualifying offense: hitter team total strictly below 4.0.
- Phase 1, generator, handoff logic, selector, pitchers, and high-total opponents are unchanged by this component.

## Mechanism
After native hitter and pitcher score simulation completes in Phase 3/adaptive worlds, qualifying hitter score columns are rank-permuted against a shared team latent rank. The strength parameter is `clip(0.50 + 0.25*(4.0 - team_total), 0.50, 0.90)`. Each hitter retains the exact same simulated score multiset, so player marginals are exactly preserved while low-total teammates gain bounded same-world score concordance.

## Validation evidence
- Blind control 6,274: byte-complete compatible pool/contest pair; Top-0.1 and Top-1 gates passed.
- Blind control 3,529: byte-complete historical pool/contest pair; both actual Top-0.1 and actual Top-1 reference lineups improved through Top-0.1 and Top-1 gates.
- Opponent echo beta 0.10 was rejected because it regressed control 6,274.
- Target 3,137: research winner born, handed off, and selector-reviewed; approximate selector rank 494/2,880; board false. Selector and portfolio force-in were rejected.

## Isolation
The validated generator candidate `SYMMETRIC_4OF5_RANK_STRATIFIED_4_4_FAMILY_COVERAGE_v2` and handoff candidate `RS44_FAMILY_MIN_SALARY_FRONTIER_RESERVE_v2` remain research-only and are not included in this promotion.
