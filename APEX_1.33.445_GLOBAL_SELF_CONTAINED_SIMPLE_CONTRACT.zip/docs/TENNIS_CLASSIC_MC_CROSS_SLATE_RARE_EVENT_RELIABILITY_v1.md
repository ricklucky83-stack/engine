# Tennis Classic MC Cross-Slate Rare-Event Reliability v1

## Purpose

This patch stabilizes the DK Tennis Classic selector when physical Monte Carlo depth is too small for raw `WIN_RATE` and `TOP_0_1_RATE` to be reliable ranking signals. It does **not** change player simulations, lineup simulations, raw event counts, or raw event rates. It changes only the selector weight assigned to those sparse-count metrics.

## Reliability law

For each rare event, the selector credibility is:

```text
reliability = expected_event_count / (expected_event_count + prior_strength)
```

Expected event counts are calculated entirely from the contest and simulation design:

```text
expected_win_events   = physical_mc_trials / field_size
top01_slots           = max(1, ceil(field_size * 0.001))
expected_top01_events = physical_mc_trials * top01_slots / field_size
```

Frozen cross-slate strengths are `40.6` for WIN and `33.0` for Top 0.1%. The law uses no player identity, slate identity, or post-lock result.

## Selector integration

The base selector weights remain authoritative. `WIN_RATE` and `TOP_0_1_RATE` weights are multiplied by their reliability. The removed weight mass is transferred only to `P95`, `P99`, and `CVAR99`, proportional to those metrics' original base weights.

The following are invariants:

- raw `WIN_RATE`, `TOP_0_1_RATE`, and their event counts are never modified;
- no projection-mean weight is introduced;
- no generator, handoff, field-generation, or roster semantics are changed;
- adjusted weights remain finite and nonnegative;
- total selector weight is conserved exactly within `1e-12`;
- invalid field size, trial count, prior strength, or tail-target configuration fails closed.

## 2,614-entry / 10,000-trial example

For a 2,614-entry contest at 10,000 physical trials:

```text
expected_win_events   ~= 3.83
expected_top01_events ~= 11.48
win_reliability       ~= 0.086
top01_reliability     ~= 0.258
```

The implication is not that the raw rare-event rates are discarded. They remain in the receipt and selector. Their influence is reduced until physical MC depth makes their expected event counts sufficiently informative.

## Cross-slate basis

The reliability law is designed for the Tennis Classic field-size regime represented by historical controls at 951, 1,568, 1,960, 2,205, 2,352, 2,378, 2,614, and 2,745 entries. The rule is conditioned on field size and physical trial count, not on those slate IDs.

## Compatibility

This patch is additive to and must coexist with:

- `ABSOLUTE_TAIL_CALIBRATION_GATE_v1`
- `APEX_GLOBAL_EXACT_TAIL_RUNTIME_PIN_ENFORCEMENT_v2`
- `APEX_GLOBAL_EXACT_TAIL_HANDOFF_KERNEL_AND_RUNTIME_PIN_v1`
- `TENNIS_CLASSIC_DYNAMIC_CONTEST_FIELD_REALIGNMENT_v1`
- `TENNIS_CLASSIC_CROSS_SLATE_DUAL_LANE_SELECTOR_GOVERNANCE_v1`

## Non-goals

This patch does not retune player distributions, fit to a winner, impose salary geometry, change Phase 2 birth rules, or create a slate-specific selector branch. Any such change requires its own calibration and promotion gate.
