# CFB Showdown Role Recovery and Balanced-Value Anchor Retention v1

## Production rule
- Preserve the forward-blind balanced-value CPT anchor before adding a same-team/same-position sibling hedge.
- A sibling may occupy a portfolio seat only when the anchor is already represented entering the hedge operator.
- Missing-role 5-1 QB families may be recalled before role-complete CPT closure.
- Verified pregame role authority may restore position/depth for a source-missing player; opportunity priors are borrowed only from same-team/same-position source-known peers.
- Recovered first-string players may receive a same-role salary-release sibling hedge.

## Prohibitions
- No postlock result input.
- No realized-score player constants.
- No player-name targeting.
- No market line used by external role recovery.
- No random First-N generation.

## Validation
Four-slate winner-capture gate passed: GT-CU 194851604, ILL-UAB 194851625, MIA-STAN 194855337, and LSU-CLEM target 194963184. Phase-2, handoff, and selector counters retained 1:1 parity on all four runs.
