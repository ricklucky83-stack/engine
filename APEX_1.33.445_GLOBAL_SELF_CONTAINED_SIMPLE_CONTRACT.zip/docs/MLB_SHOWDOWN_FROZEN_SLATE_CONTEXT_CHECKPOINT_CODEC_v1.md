# MLB Showdown Frozen Slate Context Checkpoint Codec v1

Production chunk/stream checkpoints must preserve `FrozenSlateContext` explicitly rather than silently dropping it when the internal `MappingProxyType` is not pickleable.

The worker encodes a frozen context as a tagged plain dictionary and reconstructs the immutable context on load. Historical checkpoints created before this codec may reconstruct the phase-1 and phase-2 frozen contexts only from already-committed prelock `meta` and `_LAST_FIELD_RECEIPT`, with SHA parity against any existing context seal. No simulations, rankings, selector logic, or postlock data are recomputed during recovery.

This patch changes execution persistence only. Model logic and selector logic are unchanged. Direct raw-runtime fallback remains prohibited.
