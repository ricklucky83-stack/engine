# MLB Classic Blind RS44 v7

Production repair for small-slate DraftKings MLB Classic 4-4 family birth and Phase2→Phase3 handoff recall.

- Generator: `MLB_CLASSIC_BLIND_LOW_TOTAL_ANCHORED_44_STRATIFIED_COVERAGE_v7`
- Handoff: `MLB_CLASSIC_BLIND_RS44_NATIVE_SHADOW_RECURRENCE_RESERVE_v7`
- Scope: active teams <= 8; at least one team in the 4-4 pair has team total < 4.0.
- Generator: 32 rank strata; symmetric representative modes; max 600 accepted rows per team pair.
- Handoff: fixed 2,880-row budget; native recurrence first; exactly bounded patch reserve with max 76 global rows and max 19 per stack family.
- Phase 1 unchanged. Selector unchanged. Post-lock results are not inputs. Player/team/contest-result targeting is prohibited.

Validation: exact 3,137 target contest bytes recovered and rank-1 roster matched the promoted v7 handoff row. Rebased candidate shortlists are byte-identical to the validated research outputs for target 3,137 and blind controls 3,529 and 6,274. Blind-control non-regression passes.
