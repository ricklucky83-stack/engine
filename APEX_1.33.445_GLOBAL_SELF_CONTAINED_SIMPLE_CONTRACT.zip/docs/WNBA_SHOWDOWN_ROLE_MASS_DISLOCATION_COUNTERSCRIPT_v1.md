# APEX WNBA Showdown — Role-Mass Dislocation Counter-Script v1

## Objective

**WINNER_CAPTURE_OR_FAIL.** Preserve the production Core-5 geometry while fixing selector misses created by injury/OUT-driven role dislocation. The change is isolated to the single `COUNTER_SCRIPT` seat; the three `HIGH_CONFIDENCE_CORE` seats and one `RUNBACK` seat keep their existing authority.

## Production lane contract

`HIGH_CONFIDENCE_CORE, HIGH_CONFIDENCE_CORE, HIGH_CONFIDENCE_CORE, RUNBACK, COUNTER_SCRIPT`

No sixth seat, satellite, filler, or generic diversity slot is introduced.

## Role-mass dislocation trigger

The trigger is based on **lost pre-lock opportunity mass**, not raw OUT-player count. Before the OUT purge, the runtime records:

- total projected minutes removed;
- total derived DraftKings projection removed;
- maximum single-player minutes removed;
- maximum single-player projection removed;
- total vacancy minutes redistributed by the calibrated WNBA vacancy model.

The isolated counter reserve activates when any of these result-blind conditions is met:

- removed projection `>= 45.0`; or
- max removed projection `>= 32.0` and max removed minutes `>= 24.0`; or
- removed minutes `>= 50.0` and removed projection `>= 30.0`; or
- vacancy minutes `>= 35.0` and removed projection `>= 30.0`.

This allows one missing high-role player to register as a larger structural shock than multiple low-role OUTs.

## Counter reserve

When the dislocation trigger is inactive, v15 must preserve the normal v14 path.

When active, the selector may admit an adjacent role-diffusion reserve **only for the `COUNTER_SCRIPT` seat**. A candidate must satisfy all of the following:

- exactly one of the two championship anchors;
- captain is not an anchor;
- at least four indirect vacancy beneficiaries;
- zero direct vacancy absorbers;
- calibrated `ROLE_CONFLICT_COUNT == 0`;
- `TAIL_DEPENDENCY_COUNT <= 1`;
- Top-0.1 or win-rate percentile `>= 96th`;
- P99 percentile `>= 94th`;
- P95 percentile `>= 95th`;
- mean P95/P99 percentile `>= 96th`;
- deep equalization before final counter-seat competition;
- root team split preserved.

The normal same-team double-center position-label veto remains active in ordinary lanes. Inside this high-dislocation reserve only, calibrated `ROLE_CONFLICT_COUNT` is the authority; a raw position label cannot veto an otherwise conflict-clean role-diffusion candidate.

## AI-hybrid lane intelligence

The existing selector vector remains the quantitative prior. Same-lane AI evidence can refine a root sibling only when it improves independent pre-lock tail evidence without materially degrading win rate. AI cannot move a candidate across lane boundaries or replace the Core-5 contract.

Counter/runback lane ranking combines the existing selector prior with championship mass, Top-0.1, win rate, P99, P95, marginal championship coverage, duplication, closure correlation, and tail-dependency evidence.

## Governance

- Pre-lock inputs only.
- No player-name or team-name hardcodes.
- No realized fantasy points, contest rank, winner identity, or post-lock outcome input in forward selection.
- Phase 2 generation is unchanged.
- Handoff parity and adaptive bubble simulation remain required.
- The dislocation reserve cannot change `HIGH_CONFIDENCE_CORE` or `RUNBACK` seats.
- Raw OUT count alone cannot activate the reserve.
- Existing v14 remains bundled for rollback.

## Chunk/stream validation

Production rebase against parent state `1.33.108`:

- **Target 470:** removed minutes `86.3`; removed projection `72.875`; redistributed vacancy minutes `80.3`; role-mass trigger active; prior board missed the winner; v15 captures the exact winning lineup in `COUNTER_SCRIPT` at board slot 5.
- **Control 627:** removed minutes `25.0`; removed projection `24.975`; redistributed vacancy minutes `22.9`; trigger inactive; exact historical winner remains board rank 1; full five-lineup board identity is unchanged.

The older six-slate WNBA Showdown diagnostic surface showed that all six historical winners were present in the generated candidate universe while the older selector placed none on the board. That surface is diagnostic, not a true-blind promotion claim; it supports selector-architecture work but is not used as forward scoring input.

## Patch identity

- Engine: `APEX_WNBA_SHOWDOWN_RAW_POOL_RUNTIME_v15_ROLE_MASS_AI_HYBRID_CORE5`
- Patch: `WNBA_SHOWDOWN_ROLE_MASS_DISLOCATION_COUNTERSCRIPT_v1`
- Parent production engine: `APEX_WNBA_SHOWDOWN_RAW_POOL_RUNTIME_v14_ANCHOR_RUNBACK_COUNTER_CORE5`
- Parent global state: `1.33.108`
