# APEX Global Field-Relative Extreme-Value Portfolio Selector v2

## Global production objective

The terminal selector recognizes **championship capability first** and treats ownership as a **market price**, not an automatic fade signal.

The selector must distinguish four cases:

1. high ceiling + low expected ownership = premium positive leverage;
2. high ceiling + high expected ownership = justified chalk when quality supports the price;
3. weak ceiling + low ownership = bad contrarian construction, not leverage;
4. weak relative ceiling + high ownership = over-owned risk.

Low ownership by itself never improves a lineup.

## Recognition order

1. Ownership-free championship quality: WIN, Top-0.1, Top-1, P99/CVaR/P95.
2. Mispriced ceiling relative to expected contest ownership/popularity.
3. Sport-native correlation, stack, role and game-script structure.
4. Optional direct optimal/boom leverage exported by sport runtimes.
5. Duplication/uniqueness and expected payout dilution.
6. Common-world portfolio coverage and overlap redundancy.

Common-world recurrence is retained as useful portfolio evidence, but it may no longer override a materially stronger championship-quality path merely because the simulation repeatedly tells the same story.

## Global derived ownership metrics

`CHAMPIONSHIP_QUALITY` is ownership-free and cross-sport percentile normalized.

`LINEUP_POPULARITY_PCTL` uses direct expected duplication first, then ownership product, then inverse uniqueness when necessary.

`UNDEROWNED_CEILING_EDGE = max(0, CHAMPIONSHIP_QUALITY - LINEUP_POPULARITY_PCTL)`.

`OVEROWNED_RISK = max(0, LINEUP_POPULARITY_PCTL - CHAMPIONSHIP_QUALITY)`.

`CHALK_JUSTIFICATION = min(CHAMPIONSHIP_QUALITY, LINEUP_POPULARITY_PCTL)`.

`MISPRICED_CEILING_SCORE` adds a bounded field-size-sensitive positive-leverage adjustment and a smaller bounded over-owned penalty to championship quality. The adjustment is deliberately bounded so ownership cannot rescue materially inferior athletic/tail quality.

## Player/stack leverage inputs

When sport runtimes can export stronger direct evidence, the terminal layer recognizes:

- `UNDEROWNED_CEILING_DENSITY`
- `STACK_OPTO_LEVERAGE`
- `PLAYER_PERFECT_LEVERAGE`
- `PLAYER_BOOM_LEVERAGE`
- `SIM_LEVERAGE`
- `CEILING_OWNERSHIP_EFFICIENCY`

These are evidence after championship quality; they do not replace it.

## Duplication and product ownership

Product ownership and expected duplicates remain useful, but for a different job: estimating how much a first-place result is likely to be shared. They are late payoff/portfolio controls, not athletic-performance scores and not reasons to force weak low-owned plays.

## Terminal AI parity

The full terminal AI handoff now receives transparent global fields:

- `AI_CHAMPIONSHIP_QUALITY_PCTL`
- `AI_LINEUP_POPULARITY_PCTL`
- `AI_UNDEROWNED_CEILING_EDGE`
- `AI_OVEROWNED_RISK`
- `AI_CHALK_JUSTIFICATION`
- `AI_FIELD_SIZE_LEVERAGE_WEIGHT`
- `AI_MISPRICED_CEILING_SCORE`

Allowed terminal reasons include `MISPRICED_CEILING`, `UNDEROWNED_HIGH_CEILING`, `JUSTIFIED_CHALK`, `OVEROWNED_CEILING_MISMATCH`, and `OWNERSHIP_AS_MARKET_PRICE`.

## Production integration

- Code selector: `engines/common/apex_field_relative_extreme_value_portfolio_v2.py`
- Terminal AI evidence: `engines/common/apex_terminal_ai_hybrid_selector_v6.py`
- Terminal Core-5 integration: `engines/common/apex_global_championship_core_v1.py`
- Ownership authority remains: `APEX_GLOBAL_CONTEST_DERIVED_OWNERSHIP_AUTHORITY_v1`

The policy applies globally across supported sports and modes. Sport-native candidate birth, legality, simulation and structural logic remain unchanged.
