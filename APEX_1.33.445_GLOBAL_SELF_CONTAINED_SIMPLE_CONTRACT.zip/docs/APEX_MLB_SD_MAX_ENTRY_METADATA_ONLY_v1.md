# APEX MLB Showdown MAX ENTRY Metadata-Only v1

State: 1.33.440
Parent: 1.33.439

MAX ENTRY is optional contest metadata only. It cannot halt execution, size a selector, determine terminal membership, or cap the board.

Canonical membership:

LEGAL SURFACE -> SAME-WORLD SCORING -> MC_WIN_RATE > 0 (.00001) -> FULL QUALIFIED SURFACE -> ENGINE-OWNED TERMINAL ORDER

No forced board size. No backfill. Output lineup quota: NONE.

The checkpoint/rebind path follows the same rule as a fresh run. Missing MAX ENTRY is valid.
