# APEX Global Chat Load/Run + Selector-Only Boundary v1

## Purpose
Seal the long-standing production responsibility split: Chat loads the one active engine, passes the requested run inputs, starts the integrated production path, participates only at the engine-defined terminal selector boundary, and returns the final board. Chat does not operate engine internals.

## Live-production contract
Chat may do only four things:
1. Resolve/load the active committed engine.
2. Pass site, sport, mode, field size, player pool, and explicitly supplied contest inputs.
3. Start the integrated production runner.
4. Act only at the engine-defined selector handoff, then render the sealed board.

Everything else is engine-owned and mechanical: Phase 0/preflight, availability/roster gates, Phase 1 calibration, Phase 2 birth/recall, streaming, chunk sizing, checkpoints, resume, Monte Carlo, adaptive bubble, handoff, legality, identity reconciliation, board sealing, and recoverable execution control.

## Hard prohibitions during live production
- Chat may not directly invoke raw sport runtimes.
- Chat may not directly invoke checkpoint runners.
- Chat may not choose source line ranges or internal chunk boundaries.
- Chat may not set split/chunk cursor environment variables.
- Chat may not create or invoke local live-run shims or recovery runtimes.
- Chat may not substitute engines, selectors, algorithms, or reduced-quality paths.
- Chat may not restart completed engine work when a valid engine-owned checkpoint exists.

## Selector exception
The selector is the sole intentional Chat participation point. The engine must freeze and hand off the complete selector-reviewed candidate surface through the committed terminal-selector contract. Chat may make the selector decision only against that frozen surface; it may not alter upstream engine state or generation/simulation logic.

## Enforcement
`engines/common/apex_chat_engine_role_boundary_v1.py` is loaded by the global production runner. In production it rejects direct raw-runtime/checkpoint/shim commands, manual split controls, and child entrypoints that differ from `APEX_AUTHORITATIVE_ENGINE_ENTRYPOINT`.

## Required execution shape
`bootstrap/registry -> global production runner -> authoritative sport engine -> engine-defined selector handoff -> sealed Core 5 board`

No alternative Chat-operated execution path is production-authorized.
## Engine-internal resumable execution
The prohibition on Chat-operated checkpoint runners does not prohibit the authoritative engine from invoking committed resumable control internally. For MLB Classic, `APEX_MLB_MASTER_ENGINE_v1` mechanically owns `mlb_classic_resumable_controller_v1.py` and `mlb_classic_execution_window_checkpoint_runner_v2.py`. Chat invokes only the master engine / global production runner and never supplies internal stage bounds, checkpoint paths, or cursors.


## Plugin-assisted production clarification

Plugins are support surfaces, not execution substitutes. Deep Research, Web Search, Study, and Notion may supply current context, historical findings, or selector-reasoning evidence. Their presence does not authorize Chat to operate Phase 0/1/2, simulation, chunking, generation, or fallback board construction.

AI participation remains exactly one stage: Hybrid Selector reasoning after the engine freezes and commits the complete selector-reviewed candidate surface. After the AI returns five existing IDs, the engine mechanically validates and seals the board.
