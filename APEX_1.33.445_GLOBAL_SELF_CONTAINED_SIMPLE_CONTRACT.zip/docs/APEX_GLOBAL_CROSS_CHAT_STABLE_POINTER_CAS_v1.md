# APEX Global Cross-Chat Stable Pointer CAS v1

## Purpose
Eliminate cross-chat lost updates and the active-pointer deletion gap while preserving immutable state bundles.

## Commit model
1. Every window pins the active state version, bundle ID/hash, active pointer object ID, pointer epoch, and full pointer-bytes SHA-256.
2. Work occurs only in an isolated workspace derived from that immutable parent bundle.
3. A candidate is sealed as a new immutable bundle and verified before pointer mutation.
4. Immediately before commit, the active pointer is fetched again by exact title.
5. File ID, pointer epoch, state version, bundle hash, and full parent pointer bytes must still equal the pinned parent.
6. Any mismatch returns `STALE_WRITE_ABORT`/`REBASE_REQUIRED`; the candidate may be rebased but may not overwrite production.
7. The existing `APEX_GLOBAL_STATE_LATEST.txt` object is updated in place by file ID with an atomic compare-and-swap primitive.
8. The active pointer object is never deleted, retired, or renamed during commit.
9. Pointer and bundle readback are mandatory before `COMMITTED`.

## Why this replaces pointer-object rotation
The older object-epoch fence retired the active pointer object before the replacement became authoritative. A failed or interrupted swap could leave no active pointer and forced recovery through a copied historical source. Stable-ID CAS removes that failure window and prevents stale windows from committing unless the exact parent pointer bytes still match.

## Compatibility
`OBJECT_ID_FENCE_V1` remains advertised temporarily so older immutable bootstrap readers continue to accept the pointer envelope. `STABLE_POINTER_IN_PLACE_CAS_V1` is the current commit capability and is authoritative for new promotions.
