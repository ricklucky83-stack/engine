# CFB Showdown Forward Role, Birth, and Family Retention v1

Production reversible canary for CFB Showdown. It preserves the current global selector and simulation architecture while repairing a reproduced forward-slate championship-path failure.

The patch uses frozen prelock history as a conservative role/mean floor, adds a bounded large-favorite 3-3 RB-CPT dual-QB birth lane, protects at most one robust secondary-favorite RB-CPT championship family in the native Core5, and makes contest entry limit an explicit controller input included in checkpoint identity.

No player-name or contest-ID constant is used by production logic. No postlock result is a forward input. No fixed favorite-side exposure quota is introduced. The broad global simulation mutation tested during diagnosis was rejected and is not included.

Promotion class: `PROVEN_REPAIR_READY_FOR_LIVE_VALIDATION`. Roll back/quarantine on a reproduced forward regression.
