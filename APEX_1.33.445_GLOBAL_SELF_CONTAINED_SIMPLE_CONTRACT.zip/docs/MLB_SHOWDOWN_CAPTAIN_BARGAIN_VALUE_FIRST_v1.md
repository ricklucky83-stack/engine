# MLB Showdown Captain — Bargain / Value First

## Objective
Captain selection is a shopping problem, not a sticker-price contest. The engine should prefer the materially cheaper Captain who preserves nearly the same **six-man championship ceiling**, then spend the saved salary on stronger UTIL pieces.

## Default rule
**ROSTER_UNLOCKER / VALUE CPT is the default Captain class.**

A value Captain must preserve at least 97% of the best legal six-man P99 proxy, retain at least 83% of the slate-leading individual P99, and cost no more than 80% of the slate's maximum non-reliever base salary. Cheap salary by itself is never enough; punt Captains do not qualify merely because they are cheap.

## Raw-ceiling exception
The highest individual P99 player is **not** automatically a Captain candidate. The raw-ceiling path opens only when that player is a true slate breaker:

- only the raw P99 leader may qualify;
- its P99 must be astronomical relative to the slate: `max(1.25 × median P99, median P99 + 1.50 × IQR)`;
- it must gap the runner-up by at least `max(4 DK points, 12% of runner-up P99, 0.75 × IQR)`;
- its P95 must also clear the slate's 75th-percentile P95;
- a pitcher additionally needs blind pre-lock market participation support.

A small or ordinary raw-ceiling lead is not enough. In that case, the engine returns to value-Captain shopping.

## Generator recall vs. Captain priority
Birth coverage is broader than final preference. Confirmed starters and non-relievers with at least 80% of the slate-leading individual P99 may remain **coverage-only** Captain candidates so the generator cannot miss a winning Captain structure. Coverage-only rows receive no Captain-role priority; they must win on the actual frozen MC/portfolio evidence.

## Selector use
Common-world championship events and frozen MC tail metrics remain primary. Captain role is a bounded 4% close-call prior: roster unlockers receive the default bargain preference; an astronomical slate breaker receives the full exception prior. The role prior may not override a clear MC advantage.

## Fallback
If the strict Captain gates produce fewer than two options, the engine fills from the best legal six-man roster-unlock proxies. It may not revert to "highest raw P99 wins Captain."

## Production guards
Pre-lock inputs only. No winner names, realized scores, post-lock perfect lineups, or player-name constants are permitted in production Captain selection.

## CAR SHOP 823 follow-through — family recall and terminal Core-5 authority

The bargain-Captain doctrine is not complete if a bargain Captain can be classified correctly but its championship family is pruned before Phase 2 or discarded during terminal Core-5 compression.

The companion CAR SHOP repair therefore adds:

- `MLB_SD_SINGLE_RP_CALIBRATION_QUALIFIED_FULL_VISIBILITY_v1`;
- `MLB_SD_HITTER_CPT_UNDERDOG_5_1_SP_SINGLE_RP_RECALL_v1`;
- `MLB_SD_BARGAIN_CPT_AND_UNDERDOG_5_1_DISTRIBUTED_CORE5_v1`;
- `MLB_SD_GLOBAL_CORE_PROTECTION_KEY_PARITY_v1`.

The final contract remains: bargain/value Captain is the default preference; raw-ceiling Captain is an astronomical-gap exception; coverage-only Captains remain available for bounded structural hedges so generation recall is not destroyed.
