# MLB Classic Stage-0 Stateless Micro-Chunk v1 — Rebased

## Purpose
Eliminate the MLB Classic failure mode where the host execution window expires before the first durable Stage-0 checkpoint. This repair changes execution plumbing only. Simulation physics, calibration math, candidate legality, birth scoring, Phase-2 objectives, ownership authority, selector objectives, and board ordering are unchanged.

## Lineage
`MLB_CLASSIC_STAGE0_STATELESS_MICROCHUNK_v1` was promoted in state 1.33.332. Its implementation disappeared from the 1.33.349 controller lineage while later chunk-stream doctrine remained active. State 1.33.350 restores the exact 1.33.331 -> 1.33.332 Stage-0 code delta onto the 1.33.349 parent and keeps all later MLB Classic runtime changes.

## Controller contract
The controller state uses schema `mlb_classic_controller.v3` and carries execution identity, runtime SHA-256, player-pool SHA-256, frozen Notion-authority SHA-256, stage index, Stage-0 pattern cursor, downstream cursors, and checkpoint receipts. A changed source, pool, or frozen Notion authority cannot silently reuse prior controller state.

## Stage-0 micro-stages
1. `STAGE0_BOOTSTRAP_POOL_FREEZE`
2. `STAGE0_PHASE1_SIMULATION`
3. `STAGE0_PHASE1_CALIBRATION_PHASE2_PREP`
4. `STAGE0_PHASE2_BASE_PATTERN_BIRTH`
5. `STAGE0_ADAPTIVE_FAMILY_DOOR`

`STAGE0_PHASE2_BASE_PATTERN_BIRTH` executes only the next contiguous slice of the existing ordered `PATTERNS` loop. The source loop body and persisted RNG/model state remain unchanged. No First-N, mock generator, projection-only selector, or relaxed lineup path is introduced.

## Durability order
The transaction is write-then-advance:
1. execute the certified source slice;
2. write checkpoint temp artifact;
3. fsync checkpoint file;
4. atomic rename;
5. fsync checkpoint directory;
6. compute checkpoint SHA-256 and byte size;
7. persist checkpoint receipt;
8. advance the stage/cursor;
9. atomically persist controller JSON and fsync its directory;
10. return `CHECKPOINTED_CONTINUE` / return code 75.

A process death before cursor advancement leaves the prior cursor authoritative. The current controller additionally supports verified recovery when a fully committed child checkpoint exists after a host cutoff.

## Notion authority
The current production bridge provides the frozen Notion authority hash through engine environment. The controller requires `APEX_NOTION_AUTHORITY_SHA256` and can fail closed when live authority is explicitly required but only a bundled snapshot is present.
