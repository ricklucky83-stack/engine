# CFB Showdown Global Terminal AI Handoff v1

## Defect
CFB Showdown completed its sport-native recurrence/reserve Core-5 and wrote a board file, but the chunk-stream controller did not publish the complete selector-reviewed candidate surface under `NATIVE_BOARD_READY_FOR_GLOBAL_CORE5`. The global production runner could then seal the fresh native board after child exit. The global Hybrid AI selector therefore did not actually perform the last-step CFB selection even though the global registry declared Hybrid AI active.

## Repair
The CFB chunk-stream controller now publishes every selector-reviewed Phase-2 row to the global terminal AI surface with no candidate pruning. The native CFB five-lineup result remains advisory evidence only. It is not terminal-playable until the Hybrid AI decision is committed, validated against the frozen surface, and sealed.

Sport-native special-lane evidence is preserved on the terminal surface. A structurally earned reserve or hedge may carry `SELECTION_LANE`, `SELECTOR_REASON`, `SPORT_NATIVE_LANE_AUTHORITY`, `GLOBAL_CORE_PROTECTED`, `GLOBAL_CORE_PRIORITY`, `GLOBAL_CORE_FAMILY_ID`, and its pre-lock marginal Top-0.1-world contribution. This prevents generic metric dominance from erasing the exact reason the sport-native selector retained a championship hedge.

No realized score, contest rank, winner identity, player-name constant, team-name constant, or post-lock signal is introduced.

## Target proof
On DK CFB Showdown contest 194963184, field 1764, the frozen terminal handoff contains 39,371/39,371 selector-reviewed lineups. The sport-native recovered-starter salary-release hedge is lineup index 38034 and adds 66 Top-0.1 worlds beyond its anchor. The lane is now explicitly represented in terminal AI context. A retrospective shadow validation retains that row in a legal five-lineup AI decision. This same-slate check is **not blind forward performance proof** because the contest result is already known; it is a wiring/contract validation only.

## Non-regression contract
Generator, simulation, role recovery, native recurrence selector, reserve/hedge logic, and Top-5 sport-native advisory board remain unchanged. Historical CFB board parity must remain 4/4 on GT-CU 705, ILL-UAB 705, MIA-STAN 1176, and CLEM-LSU 1764 before promotion.
