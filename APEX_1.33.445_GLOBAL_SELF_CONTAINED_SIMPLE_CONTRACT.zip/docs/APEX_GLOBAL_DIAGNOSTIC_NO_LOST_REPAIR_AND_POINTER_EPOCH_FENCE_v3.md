# APEX_GLOBAL_DIAGNOSTIC_NO_LOST_REPAIR_AND_POINTER_EPOCH_FENCE_v3

## Purpose
Prevent multiwindow diagnostic loss and stale-pointer overwrites while keeping doc/code promotion fast.

## Hard invariants
1. Every diagnostic repair has an immutable event history. VALIDATED work must end current-active, explicitly superseded, or explicitly rejected.
2. A historical ACTIVE/MERGED receipt is evidence of a past promotion, not proof that the current bundle still implements the patch. Current implementation patch IDs are authoritative.
3. Missing current implementation requeues the diagnostic automatically.
4. Pointer promotion rotates the Drive object ID. The object pinned by old windows is retired before the new exact-title object becomes active.
5. `APEX_GLOBAL_STATE_LATEST.txt` must resolve to exactly one Drive object by exact title.
6. The promotion gate rescans the live diagnostic queue immediately before pointer-object rotation; no cached snapshot fallback is permitted.
7. `UNACCOUNTED_VALIDATED_PATCHES=0` and `UNIMPLEMENTED_VALIDATED_PATCHES=0` are hard gates.
8. State/active/registry/parent semantic versions are auto-stamped at seal time.
9. Parent manifest hashes may be reused for byte-size-identical inherited files; changed/new files are hashed locally in parallel. Full uploaded bundle readback remains mandatory.
10. Compatible diagnostics are batched; conflicting files require explicit reconciliation rather than last-writer-wins.

## Pointer epoch protocol
- Discover unique exact-title active pointer and record its file ID, full bytes hash, state version, bundle ID/hash, and pointer epoch.
- Create a new pointer candidate object with a new file ID.
- Finalize the candidate bytes with its own `ACTIVE_POINTER_FILE_ID` and incremented `POINTER_EPOCH`.
- Recheck parent pointer identity/bytes and live diagnostic queue.
- Rename the old active pointer object to a retired immutable title.
- Rename the candidate object to `APEX_GLOBAL_STATE_LATEST.txt`.
- Rediscover by exact title and require the new object ID plus byte/bundle/manifest parity.

This object-identity fence prevents an in-flight stale window from overwriting the current pointer even when the storage provider does not expose a conditional-write primitive.


## Supersession
The pointer-object rotation primitive is superseded by `APEX_GLOBAL_CROSS_CHAT_STABLE_POINTER_CAS_v1`. The diagnostic merge/queue invariants remain valid; active-pointer deletion/retire/rename during commit is no longer permitted.
