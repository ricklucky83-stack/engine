# MLB Classic Cross-Version Most-Advanced Checkpoint Discovery v1

Execution-only repair. A state-digest change may rename the outer run root; compatible work is selected by exact execution/pool/raw-source identity and highest committed progress, not folder name or recency.
