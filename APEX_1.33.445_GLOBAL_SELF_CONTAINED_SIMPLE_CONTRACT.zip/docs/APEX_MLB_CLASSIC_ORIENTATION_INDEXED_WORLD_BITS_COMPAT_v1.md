# APEX MLB Classic Orientation Indexed World Bits Compatibility v1

Execution-only compatibility bridge. Raw MLB runtime source unchanged; indexed-vs-compact selector parity PASS.
