# MLB Classic LineStar Under-Spend Salary Floor v1

DraftKings MLB Classic production salary eligibility is **$46,000–$50,000**.

This change exists to preserve viable under-spend championship/perfect constructions observed in historical perfect-lineup calibration. It does **not** alter starter-only eligibility, availability filtering, bench/inactive handling, roster legality, or position rules.

The salary floor is a legality/birth-range change only; it does not add a positive selector bonus for leaving salary unused.
