# NFL Regular-Season Role Model Activation v1

## Production decision

- State target: `1.33.228`
- Season stage: `REGULAR_SEASON`
- Applies to DraftKings NFL Showdown and Classic.
- Legacy exhibition/preseason execution authority: **removed from the active bundle**.
- Global Hybrid Selector architecture: **unchanged**.

## Live role authority

Primary role evidence is current, source-backed regular-season football usage:

1. snap share
2. route participation/share
3. target share
4. carry share
5. red-zone / goal-line role
6. QB dropback share where applicable

Current availability, depth chart and official inactive information are required. Hard OUT/IR/confirmed-out states purge the player. Questionable, doubtful and practice-limited states remain uncertainty states unless current evidence establishes a hard out.

Missing current role evidence does not silently receive a synthetic workload prior in live production.

## Showdown changes

Removed from live production:

- multi-QB exhibition rotation assumptions
- backup-QB rotation priors
- fixed exhibition pass-catcher keep rules
- QB + kicker exhibition stability-shell penalty
- defensive-rotation sentinel
- low-skill DST shadow lane
- low-total exhibition rotation reserve

Retained as sport/format structure:

- calibration-first distributions
- legal CPT/FLEX salary construction
- team-split family coverage
- QB/pass-catcher, RB/DST, kicker/environment and opponent-script correlation
- position/team closure without post-closure truncation
- public-field ownership model
- full Phase-2 identity ledger
- adaptive bubble simulation
- global Core-5 terminal portfolio
- cross-world recurrence and final Hybrid Selector

## Classic changes

Removed from live production:

- flat-$5,500 scenario-birth module
- exhibition role-correlation doctrine
- missing-role neutral workload prior

Current regular-season role evidence now controls Phase 1/2 opportunity. The existing Classic correlation, simulation, handoff and global Core-5/Hybrid-selector stack remains intact.

## Calibration and AI intelligence

Historical exhibition results remain preserved only in the immutable parent bundle (`1.33.227`) for provenance. They have no execution authority in `1.33.228`.

Resolved regular-season contests may become offline calibration / Hybrid-AI labels only after their complete prelock surface was frozen before outcomes were known. Live runs never consume postlock results.

## Promotion rule

The regular-season model is active before the first 2026 regular-season NFL slate. The first regular-season slate is a blind calibration/validation control for future weight adjustment; it is **not** a prerequisite for activating regular-season football logic.
