# APEX Global Hybrid Selector Intelligence v3

v3 corrects the v2 assumption that one learned reasoner should share ranking coefficients across sports.

The system now shares **contracts, feature semantics, uncertainty handling, diagnostics, and output schema globally**, while sport×mode adapters own domain-specific order evidence and any learned coefficients.

Shared components: most-probable-best evidence, rank uncertainty, cross-world consensus, rank stability, order diagnostics, and `GLOBAL_ORDER_*` outputs.

Adapter components: sport-native structural geometry, market/role context, scenario families, and optional historically learned sport×mode ranking models after chronological holdout validation.

No postlock label may enter a current-slate order score. No ranker may change lineup membership.
