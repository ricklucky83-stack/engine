# APEX_GLOBAL_FINAL_PLAYABLE_CORE5_TERMINAL_ENFORCEMENT_v1

Status: ACTIVE_VERIFIED_LOCKED_PRODUCTION

All live-production sport/mode routes may use larger native review surfaces internally, but those surfaces are non-terminal and must never be rendered as the playable board. The global production runner compresses the native review surface through `APEX_GLOBAL_CHAMPIONSHIP_CORE_5_v1` and seals exactly five lineups. Satellites and environment overrides are disabled on the live-production terminal path. A source review board with fewer than five rows fails closed.
