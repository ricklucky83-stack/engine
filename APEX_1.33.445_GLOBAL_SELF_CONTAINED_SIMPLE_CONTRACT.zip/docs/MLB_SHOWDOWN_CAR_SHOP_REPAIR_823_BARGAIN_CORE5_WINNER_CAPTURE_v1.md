# MLB Showdown CAR SHOP REPAIR — 823 Bargain Core-5 Winner Capture v1

## Objective

Preserve the pre-lock game-script read while repairing the layers that prevented the correct 5-1 underdog family from reaching the final playable Core-5.

The repair is structural and identity-free in production. Post-lock contest/perfect-lineup observations are validation evidence only and never enter production selection.

## Shopping doctrine

MLB Showdown Captain selection is bargain-shopping first.

- Default Captain class: `ROSTER_UNLOCKER` / value Captain.
- Highest raw-ceiling Captain is preferred only when the raw ceiling is astronomical and materially separated from the next-best ceiling.
- `COVERAGE_ONLY` Captains may remain in generation so winner recall is not destroyed, but they receive no generic Captain-priority bonus.
- Core-5 should preserve a bounded hedge for a structurally strong coverage-only SP-CPT family when it represents a materially different championship route.

## Repair 1 — single-RP full visibility

Patch: `MLB_SD_SINGLE_RP_CALIBRATION_QUALIFIED_FULL_VISIBILITY_v1`

Every calibration-qualified relief pitcher remains eligible for one-RP utility construction. The old per-team top-four RP reservoir could hide a valid single-RP championship path. Dual-RP construction remains separately constrained by the stricter `dual_rp_ok` gate.

## Repair 2 — underdog value-CPT 5-1 single-RP recall

Patch: `MLB_SD_HITTER_CPT_UNDERDOG_5_1_SP_SINGLE_RP_RECALL_v1`

Phase 2 retains the complete structural family when all of the following are true:

- hitter Captain is a pre-lock `ROSTER_UNLOCKER`;
- Captain team is the underdog by frozen team-total context;
- branch is 5-1 with five players from the Captain team;
- exactly one starter is rostered and it is from the Captain team;
- exactly one calibration-qualified RP is rostered and it is from the Captain team;
- the sixth player is the opposing-team one-off.

No player/team identity is used.

## Repair 3 — bounded bargain Core-5 authority

Patch: `MLB_SD_BARGAIN_CPT_AND_UNDERDOG_5_1_DISTRIBUTED_CORE5_v1`

The native selector may reserve at most three Core-5 priority seats:

1. one underdog value-CPT 5-1 + same-team SP + single-RP representative;
2. one underdog SP-CPT 5-1 distributed-core confidence representative;
3. one qualified lower-owned runback sibling from that distributed SP-CPT family.

The distributed SP-CPT family is identity-free and requires:

- underdog SP Captain;
- 5-1, Captain side count = 5;
- exactly one SP and zero RPs;
- four same-team hitters split exactly two in batting-order 1-3 and two in 4-6;
- no full-price same-team hitter anchor;
- one opponent runback in batting-order 4-6;
- frozen-tail qualification relative to the best row in the structural family.

This is controlled diversification inside a correctly identified game script, not a post-lock winner lock.

## Repair 4 — global protection-key parity

Patch: `MLB_SD_GLOBAL_CORE_PROTECTION_KEY_PARITY_v1`

Runtime protection maps use integer lineup IDs; JSON round-trips use string keys. The board handoff must read both key types. Failure to do so collapses distinct sport-native protected families into the receipt-level fallback family/cap and can discard valid protected Core seats.

## 823 validation contract

The post-lock 823 tape is validation only. A successful repair must show:

- actual contest winner is legal;
- actual contest winner is Phase-2 born;
- actual contest winner survives handoff/selector review;
- actual contest winner reaches the final playable Core-5;
- LineStar-perfect construction is legal and Phase-2 born once the single-RP visibility repair is active;
- production receipts state `POSTLOCK_INPUT_USED = false` and `PLAYER_NAME_CONSTANTS_USED = false` for the new selector authority.


## Repair 5 — no-full-price elite conditional-RP bargain seat

Patch: `MLB_SD_UNDERDOG_VALUE_CPT_NO_FULL_PRICE_ELITE_COND_RP_CORE5_v1`

The generic value-CPT seat is refined when a stronger bargain-shopping path exists. Inside the existing underdog 5-1 value-CPT + same-team SP + single-RP family, the selector first looks for rows that fade the Captain team's full-price hitter and roster a calibration-qualified same-team RP with role probability at least 0.15 and conditional P95 at least 95% of the team's best qualified-RP conditional P95.

Within that refined family, MC win rate is primary, followed by Top-0.1%, P99, quality, and deterministic lineup ID. If the refined lane is empty, the existing generic value-CPT representative remains the fallback.

On the frozen full-run 823 pre-lock tape, this refinement reduced the value-CPT family from 2,912 to 445 candidates and selected lineup index 350605. Post-lock validation identifies that row as the 110.5-point LineStar perfect lineup. The distributed SP-CPT hedge continued to select lineup index 30105, the actual contest winner. These identities are validation-only and do not enter production logic.

The calibration receipt explicitly records that a new full fresh 50,000-trial end-to-end rerun was not completed; this evidence is a frozen full-run selector replay plus a fresh 50,000-trial player simulation.

## Full-fresh 50K closure

State `1.33.90` was subsequently validated with a fresh end-to-end 50,000-trial Phase-1 production run. The final playable Core-5 contained the perfect lineup in seat 1 and the actual contest winner in seat 3, while machine-board parity and the strict success gate both passed. Production post-lock input use and production player-name constants were both false.

Reusable certification is now governed by `MLB_SD_FULL_FRESH_50K_DUAL_CAPTURE_CERTIFICATION_v1`. That certifier is post-lock only, fail-closed, and forbidden as a forward selector input.
