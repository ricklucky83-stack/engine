# NFL SS TDS — Event-Native Touchdown World v1

## Production contract

DraftKings NFL Single Stat Touchdowns is a three-athlete, no-salary-cap mode. APEX treats the selectable universe as non-QB touchdown scorers only: RB, WR, TE, and FB. Quarterbacks are hard-purged before generation, simulation, ownership, and selection. Passing touchdowns do not count as a quarterback scoring touchdown in this mode.

## Why this is a separate runtime

Touchdowns are discrete count events. The simulator therefore models each player's personal touchdown count and explicitly permits 0, 1, 2, 3+ touchdown outcomes. It does not reduce a player to a Bernoulli “scored / did not score” flag. Each team first receives a correlated offensive touchdown count, then those touchdowns are allocated among eligible scorers plus an unselectable residual scorer bucket for quarterback rushing, gadget, or other scoring routes. This keeps team-level scoring coherent while respecting the user-mandated QB exclusion.

## Prelock signal hierarchy

Player scoring allocation uses anytime-TD probability when available, then current role evidence: snaps, routes, targets, carries, goal-line/inside-10/inside-5 carries, red-zone targets, and end-zone targets. Team touchdown intensity prefers implied team totals, then game totals, and only falls back to sufficiently covered player touchdown markets. FPTS is never used to rank touchdown probability or ownership in this mode.

## Ownership and field

Showdown `RST%` is prior evidence only. NFL SS TDS owns a 300% player-marginal mass because every lineup contains exactly three athletes. The field is an exact 3-of-N maximum-entropy distribution matched to those internally derived marginals. Candidate success is measured against the simulated contest field using tied-first equity, first-place share EV, Top-0.1%, Top-1%, duplication, and uniqueness.

## Generation and selection

The event-native touchdown model remains the player/world authority, but candidate birth is now governed by `NFL_SS_TDS_CALIBRATION_QUALIFIED_WORLD_BIRTH_v2`. Phase-1 touchdown worlds must run before birth. Only calibration-qualified world-optimal, near-optimal, team-event, global-event, and recurrent-pair triads are born. Same-team 3-0 scorer triads remain legal when Phase-1 evidence supports them. The legal C(N,3) identity lattice is never enumerated. Every born candidate is evaluated 1:1 and published to the shared terminal AI; the NFL SS TDS intelligence adapter remains terminal-only and cannot birth or delete lineups.

## Validation invariants

- `QB_ALLOWED = FALSE`
- `ROSTER_SIZE = 3`
- `SALARY_CAP = NONE`
- `EXPECTED_OWNERSHIP_MASS = 3.0`
- `FPTS_USED_IN_SCORING_MODEL = FALSE`
- `COUNT_VALUED_TOUCHDOWN_WORLDS = TRUE`
- `MULTI_TD_PLAYER_SUPPORT = TRUE`
- `PHASE2_BUILT_LINEUPS = SELECTOR_REVIEWED_LINEUPS = CALIBRATION_QUALIFIED_BIRTHS`
- provider Showdown ownership cannot become NFL SS TDS authority
- postlock results cannot enter forward selection
