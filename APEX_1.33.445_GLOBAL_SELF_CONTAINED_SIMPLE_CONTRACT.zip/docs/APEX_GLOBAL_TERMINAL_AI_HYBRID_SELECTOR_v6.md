# APEX Global Terminal AI Hybrid Selector v6

**State target:** 1.33.132  
**Patch:** `APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v6`

## Objective

V6 makes **contest rank-1 / Top-0.1 capture** the terminal objective whenever the winning/perfect lineup has already been born and evaluated. For MLB Classic and MLB Showdown, `APEX_GLOBAL_TOP01_WINNER_SHAPE_OWNERSHIP_DIFFERENTIATOR_v1` makes winner-shape and ownership-shape the primary terminal evidence. MC Top-0.1, WIN, P99 and CVaR remain diagnostic/tiebreak evidence and do not define MLB championship quality.

## Authority boundary

The engine still owns availability, legality, Phase-1/2, simulation, ownership, field construction and candidate birth. V6 only ranks/selects existing IDs from the complete selector-reviewed handoff. No Top-N sieve or candidate pruning is allowed. Post-lock results and player-name constants are prohibited in forward production.

## Tennis Classic rank-1 posterior

The prior selector could over-trust a standalone scalar score and could lose relationship intelligence when Classic handoff rows used sealed `PLAYER_IDS`/`P1_ID...P6_ID` schemas. V6 fixes both problems.

For Tennis Classic, every candidate receives a pre-lock `AI_TENNIS_RANK1_POSTERIOR` built from:

- player-core Top-0.1 championship density across the **full handoff**
- player-core win density
- exact one-swap (D1) Top-0.1 neighborhood density
- Top-0.1 and win lower-confidence evidence when available
- P99 and CVaR99 right-tail magnitude
- independent market support when available
- low projected duplication
- Monte Carlo uncertainty stability

Top-0.1% rate and its confidence-adjusted evidence are the primary signals. A tail-consensus floor requires agreement across player-core density, one-swap density, Top-0.1%, P99 and CVaR99 instead of allowing one extreme metric to dominate.

Same-match-pair fragility receives a dynamic negative-correlation cost. Only candidates with elite Top-0.1% and P99 support receive bounded relief for a plausible long-match joint ceiling. Native selector rank, rank disagreement, realized regression and post-lock contest results are excluded from the Tennis Rank-1 score.

The final five maximize joint championship-union coverage and marginal portfolio value. They are not the five highest standalone scores.

## Sealed identity repair

`PLAYER_IDS` and `P1_ID...P12_ID` from pipeline identity ledgers are now recognized as lineup players by the terminal relationship layer. This restores player-set families and D1 neighborhood intelligence for Classic sports without reconstructing or mutating candidates.

## CAR SHOP calibration firewall

Resolved contest rank/actual fantasy points may diagnose selector misses offline, but they never enter the forward score. The Tennis CAR SHOP finding that Rublev was wrongly removed remains an upstream availability defect; V6 only improves rank-1 selection **conditional on the target being born**.

## Production invariants

- complete handoff required
- existing lineup IDs only
- no post-lock fields
- no player-name memorization
- no candidate pruning
- current selector is advisory comparator
- final board remains five coordinated lineups


## Global mispriced-ceiling ownership leverage

Ownership is a **market price**, not an automatic fade signal. Low ownership alone is never leverage; a low-owned player must retain enough ceiling and role/environment support to be a credible winning differentiator. High-owned players remain valid when their ceiling justifies the chalk.

For MLB Classic and MLB Showdown, terminal order is now: `WINNER_SHAPE` → `OWNERSHIP_SHAPE` → ceiling-to-ownership differentiator → value-to-ceiling unlock → justified chalk → sport structure/correlation → duplication/portfolio redundancy → **MC diagnostic support only**.

The terminal review surface records `AI_WINNER_SHAPE_SCORE`, `AI_OWNERSHIP_SHAPE_SCORE`, `AI_PRIMARY_DIFFERENTIATOR_SCORE`, `AI_VALUE_TO_CEILING_UNLOCK_SCORE`, and `AI_CREDIBLE_STRUCTURAL_SEPARATION`. `AI_MC_TERMINAL_AUTHORITY=false`. When credible alternatives exist, the five-lineup MLB portfolio cannot collapse into an all-chalk field-conformity monoculture.
## Engine-owned multi-seed convergence

Before the terminal candidate surface is frozen, a sport runtime may invoke `APEX_GLOBAL_MULTI_SEED_UNTIL_SEPARATION_v1` through the V6 callback contract. This is **engine-owned pre-freeze simulation**, not AI authority. The terminal selector cannot request arbitrary re-simulation, change sport physics, create candidates, or use post-lock results. It may select only from the exact candidate IDs after the convergence receipt is sealed. MLB Showdown requires this callback path in production.


## Global shared intelligence architecture

The Hybrid Selector has **one global intelligence layer across all supported sports and modes**. Sport/mode profiles are context adapters, not separate AI brains. The shared reasoner learns transferable championship-selection principles from the global historical corpus while each adapter supplies sport-native meaning for structure, role, correlation, salary geometry and game script.

Global training pools lessons from MLB, Tennis, CFB, NFL, PGA, MMA, NBA, WNBA, CBB, NHL and future registered sports. Preference pairs remain within the originating slate so incompatible contests are never directly ranked against each other. Cross-sport transfer occurs through shared features and reasoning patterns, not cross-contest outcome comparisons.

The production authority boundary does not change: AI remains the **last step only**, receives the complete frozen selector surface, and may return existing lineup IDs only.

## 2026-09-07 repair: last-step AI authority + Top-0.1 intelligence curriculum

`APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v6_REPAIR_AND_TOP01_CURRICULUM_BRIDGE_v1` restores code/doc parity for the terminal intelligence contract and explicitly binds V6 to `APEX_GLOBAL_HYBRID_SELECTOR_LAST_STEP_EXECUTION_FENCE_v1`.

The AI's production authority is **last-step-only**: it reasons over the complete frozen selector-reviewed surface and returns five existing lineup IDs. The production runner may not replace a missing AI decision with an engine-internal proxy selector. A missing decision returns `HYBRID_SELECTOR_HANDOFF_REQUIRED` while preserving the durable frozen surface for exact resume.

The associated `APEX_GLOBAL_HYBRID_SELECTOR_INTELLIGENCE_v2` workstream uses resolved historical frozen surfaces to create blind listwise, graded, and hard-negative training lessons. Resolved outcomes are offline labels only; player identities are stripped from reusable curriculum artifacts, and no postlock result enters a live selector surface.

The V6 repair also restores sealed `PLAYER_IDS` / `P1_ID...Pn_ID` relationship visibility and the Tennis Classic prelock rank-1 posterior evidence required by its existing regression contract.
