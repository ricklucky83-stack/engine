# NFL Showdown 52-Max Phase-1 + Ordinal + Portfolio Repair v1

- State: `1.33.307`
- Patch: `NFL_SD_52MAX_PHASE1_ORDINAL_PORTFOLIO_REPAIR_v1`
- Status: `PRODUCTION_PROMOTED_VALIDATED_PARTIAL_RANKER_OPEN`

## Repairs
- Preserve verified source projection as the Phase-1 central mean while using role evidence for uncertainty and eligibility.
- Scale player/Captain/script portfolio caps to requested board size; fail closed rather than abandoning constraints.
- Preserve bounded extreme 1-5/5-1 and K+DST closure lanes without player-name rules.
- Feed deterministic cross-world ordinal evidence (expected rank, median rank, rank P90, pairwise strength, world breadth, rank stability) into global ordering.
- Demote the prior defensive-balanced adapter from tier-first live ordering authority to bounded coverage evidence.

## Frozen control 195384249
- Field: 1,764 / 52-max
- Winner capture: PASS; board seat 28
- Top-0.1 capture: 1; Top-1% capture: 2
- Best contest rank: 1
- Full-board Spearman: +0.1396 (old production: -0.202)
- Full-board Kendall: +0.0959
- Pittsburgh D/ST: 11/52; K + Pittsburgh D/ST: 9/52
- Portfolio relaxation: FALSE
- Top-5 realized ranks: [1292, 341, 1564, 1303, 1102]; ranker remains NOT SOLVED.

## Safety
- Forward scoring uses no postlock truth.
- No winner/player-name hardcodes.
- Zero-role/inactive players still fail closed.
- 28/28 targeted NFL Showdown regression tests pass.
