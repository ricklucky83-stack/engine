# APEX Global FAST PATH Zero-Probe One-Shot Dispatch v1

## Problem sealed
A live production request containing **FAST PATH**, **NO AUDITS**, and **NO DIAGNOSTIC TESTS** must not spend separate execution calls on runtime probes, import probes, hash-only probes, state-only validation, audits, or diagnostic tests before attempting the requested production engine.

The August 31, 2026 Tennis Classic incident demonstrated the failure mode: execution-service throttling was encountered during unauthorized probe calls and the production engine child was never launched. The 429 itself does not prove the probes caused throttling; it proves the production run lost execution priority because probes were attempted first.

## Hard execution order
1. Resolve the active state pointer and obtain the exact immutable bundle.
2. Perform required bundle integrity/bootstrap work **inside the same production invocation**, not as separate compute probes.
3. Resolve platform, sport, mode, field size, player pool, and required live availability input.
4. Launch `apex_global_production_board_runner_v1.py` immediately.
5. Launch the resolved sport engine as the runner child.
6. Continue through simulation, Phase 2, handoff, selector, and board sealing according to the active sport contract.

## Forbidden before engine launch
- one-line Python health checks;
- import-only checks;
- standalone SHA/hash checks;
- standalone manifest/self-test calls;
- `--state-only` bootstrap probes;
- audits, regression tests, stress tests, diagnostics;
- rate-limit or concurrency test calls.

## Mandatory integrity retained
This patch does **not** weaken active-state integrity. Encoded bundle SHA-256, decoded bundle SHA-256, extraction integrity, and required internal manifest checks remain part of state bootstrap. The change is orchestration: those checks are not dispatched as extra compute calls ahead of production.

## Tennis Classic one-shot implementation
`apex_regular_chat_bootstrap.py` now recognizes the strict FAST PATH / NO AUDITS / NO DIAGNOSTIC TESTS contract. For DK Tennis Classic it directly invokes the global production runner and the Tennis Classic v2 engine in the same bootstrap process chain when the player pool, field size, and mandatory availability receipt are present.

No discretionary pre-engine subprocess is inserted.

## 429 classification
A `TooManyRequestsError`/429 occurring before child-process launch is classified as `EXECUTION_RUNTIME_THROTTLED_BEFORE_ENGINE`. It is not `RUN_INVALID`, not an input failure, and not an engine-logic failure.

## Change boundaries
- Selector behavior: unchanged.
- Simulation math: unchanged.
- Player-pool interpretation: unchanged.
- Availability/out gate: retained.
- Tests for this change: not run.
- Audits for this change: not run.
