# APEX Global Notion ↔ Engine Authority Parity v1

Notion is declarative authority. The production engine is executable law. A rule marked production-active in Notion must be represented by an in-bundle contract and executable runtime wiring when behavioral. A rebase or promotion that drops such a rule is `PRODUCTION_AUTHORITY_DRIFT` and is not compliant.

The engine registry carries a `NOTION_PRODUCTION_AUTHORITY_CONTRACTS` bridge ledger. `apex_notion_engine_authority_parity_v1.py` validates that every production-marked ledger entry has its contract, executable implementation, and required engine wiring. This check is maintenance/promotion-time and does not add a Notion network dependency to live slate execution.
