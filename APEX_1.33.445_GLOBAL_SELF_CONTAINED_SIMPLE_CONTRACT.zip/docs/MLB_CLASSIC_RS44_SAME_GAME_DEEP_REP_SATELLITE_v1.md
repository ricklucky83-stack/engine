# MLB Classic RS44 Same-Game Deep-Rep Satellite v1

STATUS: LOCKED_VALIDATED_PRODUCTION

## Purpose
Preserve the four-seat common-world Core-5 prefix while allowing one bounded terminal satellite seat for a prelock-qualified v7 RS44 same-game 4-4 deep representative.

## Forward-only gates
- Source must be `MLB_CLASSIC_BLIND_LOW_TOTAL_ANCHORED_44_STRATIFIED_COVERAGE_v7`.
- Structure must be 4-4 with mutually-opposed teams from the same MLB game.
- Deep representative mode must be `LAST/LAST`.
- Salary must equal the governed small-slate floor: 46,000.
- Existing selector objective must be at least 0.80.
- Candidate Top-0.1 rate must retain at least 50% of the weakest preserved Core-5 seat.
- Preserve the first four common-world core seats; at most one satellite seat may be added.

## Prohibitions
- No player-name targeting.
- No team-name targeting.
- No contest-rank or realized-score targeting.
- No postlock runtime input.
- No selector metric mutation.
- No board-size expansion.

## Validation
Target 3,137: exact historical rank-1 lineup `L028564` becomes board rank 5 while the first four core seats remain unchanged.
Blind 3,529 and 6,274: satellite hard no-op and exact final-board ID parity with the pre-patch production boards.
