# MLB SD Field Calibration and Selector Guard — CAR SHOP Repair v1

## Failure species
The contest winner can be born and reach terminal review while being suppressed because low-confidence or missing roster ownership is interpreted as reliable uniqueness. That error contaminates fake-field frequency, duplication, leverage, and contest-finish ranking.

## Production repair
1. Treat source RST as noisy roster exposure, not CPT ownership.
2. Fill missing/near-zero RST with a prelock structural proxy derived only from salary, simulated tail, batting order/role, team environment, and role probability.
3. Project total roster exposure to exactly six roster slots with a 100% per-player cap.
4. Split the market into distinct CPT and UTIL exposures with exact masses of 100% and 500%.
5. Sample contest entries with replacement so duplicate lineups emerge naturally.
6. Shrink ownership-derived leverage by field-model confidence; low-confidence ownership can never receive full leverage credit.
7. Penalize terminal ownership uncertainty rather than rewarding apparent uniqueness created by missing data.

## Guardrail
No realized ownership, contest rank, winner identity, or postlock fantasy points may be used in production calibration. Postlock evidence is diagnostic only.
