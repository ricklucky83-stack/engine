# CFB Showdown production canary — 2026-09-12

## Activation decision
`CFB_SHOWDOWN_FAVORITE_CONTROL_RB_CPT_4_2_SINGLE_QB_RESERVE_v1` is active as a **bounded production canary** for CFB Showdown.

Rationale: contest 195476934 proved a real architecture failure in which a legal championship family was pruned at generator beam depth 4, never reached Phase 2, and remained suppressed by the native recurrence selector after causal injection. Leaving the lane shadow-only would knowingly preserve the same miss mechanism on a future slate.

## Guardrails
- CFB Showdown only.
- Contest entry limit / board context must be at least 20.
- Birth reserve is limited to the top 16 prelock structural families.
- Family: favorite 4-2, favorite RB CPT, exactly one QB, favorite QB FLEX, at least three WR/TE, salary $47,000-$50,000.
- Exactly one terminal seat may be reserved.
- Existing sport-native protected lanes remain protected.
- The selected canary row is marked `GLOBAL_CORE_PROTECTED` in the terminal-AI handoff.
- No realized score, contest rank, contest ownership, or player-name constant may enter selection.
- Forward validation remains mandatory; any demonstrated regression triggers rollback/revision.

## Same-slate sealed proof
- Contest: 195476934 / field 941 / 28-max.
- Exact winner: Daniel Hill CPT + Keelon Russell + Ryan Coleman-Williams + Kenny Darby + Willie Rodriguez + Conor Talty.
- Exact winner prelock structural-lane rank: 5 / 16 retained families.
- Missing birth rows added by bounded lane: 13.
- Exact winner recurrence scalar: 158.12.
- Final 28-seat replay: exact winner captured, contest rank 1 / 941.
- Postlock signal used in selection: false.
- Player-name constants used: false.

## 5-1 production consistency repair
The active runtime also now contains the previously documented `CFB_SD_KNOWN_ROLE_5_1_QB_CPT_CORE_COMPLETION_RESERVE_v1` executable lane. The CAR SHOP page had marked this production-active on 2026-09-12, but the active 1.33.302 CFB Showdown runtime still contained only the older WR-CPT 5-1 reserve. State 1.33.305 closes that documentation/executable mismatch without removing the older protected lane.
