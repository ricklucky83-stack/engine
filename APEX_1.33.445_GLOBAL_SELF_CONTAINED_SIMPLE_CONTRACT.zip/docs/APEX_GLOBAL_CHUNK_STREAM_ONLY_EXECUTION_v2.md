# APEX Global Chunk-and-Stream Only Execution v2

Live production has one execution architecture: **chunk and stream**.

There is no raw-runtime or monolithic fallback. A live mode without a registered, certified chunk/stream controller fails closed with `RUN_INVALID:CHUNK_STREAM_ADAPTER_REQUIRED`.

Every long phase follows the durable loop:

1. read the durable cursor;
2. execute one deterministic bounded chunk;
3. atomically commit the chunk artifact and SHA-256;
4. advance only that cursor;
5. release chunk memory;
6. yield with `CHECKPOINTED_CONTINUE` / return code 75 when another process window is needed;
7. let the production supervisor resume from the committed cursor.

Compiled, vectorized, sparse, branch-and-bound, and cached-feasibility kernels are allowed **inside a chunk**. They are not separate execution routes and may not bypass durable chunk commits.

The former regression-only direct-monolithic exception is deleted. Native raw-runtime CLIs must delegate to a certified controller; otherwise they fail closed.
