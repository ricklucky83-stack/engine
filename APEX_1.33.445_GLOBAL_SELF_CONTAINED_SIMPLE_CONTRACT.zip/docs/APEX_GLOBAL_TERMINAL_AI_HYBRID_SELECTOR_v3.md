# APEX Global Terminal AI Hybrid Selector v3

## Scope
Global: all sports and all modes.

## Core rule
The mechanical engine owns calibration, candidate birth, simulation, field modeling, handoff, and metric computation. The Hybrid AI receives **every calibration-qualified / selector-reviewed lineup**. No Top-N reduction, pruning, cohort selection, Pareto cut, or beam frontier may remove an eligible lineup before AI review.

## Terminal authority
The Hybrid AI acts only at the final decision layer. It may rank, compare, tie-break, and select exactly five existing lineup IDs as one Top-5 parlay portfolio. It may not create or modify a lineup, alter projections or ownership, recalibrate, rerun simulations, change the field model, or consume post-lock results.

The current coded selector remains available only as advisory evidence when AI authority is enabled. It cannot force or replace a terminal seat.

## Required pipeline
1. Complete calibration.
2. Build all calibration-qualified lineups.
3. Hand off 100% of those qualified lineups.
4. Freeze the complete candidate surface.
5. Hybrid AI reviews the complete surface and returns five existing lineup IDs.
6. **Present the final board immediately.**
7. Run legality validation after presentation.
8. Run formal candidate-membership validation after presentation.
9. Run candidate freeze/hash validation after presentation.
10. Emit the final board-hash and validation receipt.

## Post-board failure
If post-board validation fails, the already-rendered board is explicitly marked `BOARD_INVALID`. Silent lineup substitution is prohibited. The exact failure is reported and the selector path must be rerun.

## Top-5 parlay policy
`APEX_GLOBAL_TOP5_HIGH_CONFIDENCE_PARLAY_v1` remains authoritative. The objective is not to pick five highest standalone rows. The five-lineup set should maximize championship / Top-0.1% capture while preserving high individual confidence and using diversification only when it adds real portfolio value. Dominant shared championship cores remain allowed when supported.
