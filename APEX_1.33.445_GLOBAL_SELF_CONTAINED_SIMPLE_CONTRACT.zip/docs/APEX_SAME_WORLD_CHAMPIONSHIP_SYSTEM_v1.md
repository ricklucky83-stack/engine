# APEX Same-World Championship System v1

## Governing objective
The world is the unit of truth. A lineup is preferred when the entire legal roster repeatedly remains alive and produces championship outcomes inside the same shared Monte Carlo worlds. Individual P99 values and pairwise correlation cannot substitute for this system event.

## Shared-world requirement
Every player outcome in trial `w` must be generated from the same causal slate state. Independently sampled player rows may not be relabeled as a common world.

## Role-relative wheels
Each player is judged against quantiles of that player's own pre-lock simulated distribution. Three simultaneous-system tiers are retained: loose, core, and strict. No single arbitrary threshold owns the decision.

## Recurrence
The production metric is event mass across repeated common worlds, with split-half recurrence retained as a stability signal. One freak world is weaker than a lineup that recreates the all-wheel state multiple times.

## MLB Classic production integration
MLB Classic evaluates full-wheel status sparsely only in common worlds where the legal lineup already crosses the frozen Top-0.1 boundary. This avoids an expensive live world-search loop and leaves the complete Phase-2 identity set intact. `SAME_WORLD_CORE_MASS` and split-half recurrence precede ordinary Top-0.1 and marginal tail metrics in the selector. The Core-5 portfolio maximizes full-wheel WIN and Top-0.1 event union before ordinary WIN/Top-0.1/Top-1 union.

## Governance
Post-lock results, player-name constants, same-slate winner identities, and unweighted importance-sampling frequencies are prohibited as forward inputs. Pairwise correlation is a late tiebreak only. BARE MIN remains a separate route.
