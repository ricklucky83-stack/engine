# NFL Showdown Phase-2 Calibration-Qualified Stream v1

State: `1.33.335`  
Patch: `NFL_SD_PHASE2_CALIBRATION_QUALIFIED_STREAM_v1`

Phase 2 now retains the complete union of the existing global calibration lane and all existing structural-family/macro qualifiers. The legacy `phase2_keep` / 20,000 value remains a diagnostic capacity reference only; it cannot delete or backfill membership.

Common-world Top-600 / Top-100 recurrence remains available as prelock evidence for simulation-budget priority, boundary uncertainty, cross-seed stability, and tie-breaking, but it is not an irreversible qualification gate.

The MC evaluator already processes candidate rows in physical batches, so qualified membership is streamed instead of reduced to fit a monolithic matrix.

DEN @ KC 88,235 reconstructed prelock replay: 252,307 candidates -> 70,034 qualified Phase-2 rows; exact winning construction at candidate index 77,727 survives Phase 2. No postlock result is used as a forward feature or player-specific rule.
