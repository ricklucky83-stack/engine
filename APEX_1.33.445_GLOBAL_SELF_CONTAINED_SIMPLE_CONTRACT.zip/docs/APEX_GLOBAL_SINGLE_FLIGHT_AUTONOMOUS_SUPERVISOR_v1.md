# APEX Global Single-Flight Autonomous Supervisor v1

## Scope
Global execution/control-plane ownership for one production run identity at a time.

## Preserved autonomy
The supervisor autonomously owns engine launch, checkpoint/resume, terminal-surface durability, no-progress protection, external-data recovery routing, and prevention of duplicate engine work. Chat may not operate engine internals.

## Selector boundary — descendant clarification
`APEX_GLOBAL_HYBRID_SELECTOR_LAST_STEP_EXECUTION_FENCE_v1` narrows only terminal decision authority:

- engine executes every upstream phase through a complete frozen selector surface;
- plugins may supply research/context support but have no execution authority;
- AI participates only at the final Hybrid Selector reasoning boundary;
- AI may select only existing lineup IDs from the frozen surface;
- if no valid Hybrid AI decision is present, the supervisor returns `HYBRID_SELECTOR_HANDOFF_REQUIRED` with return code 42;
- after the decision is committed, the engine validates membership/legality/hash parity and mechanically seals the Core-5 board;
- a valid frozen terminal surface suppresses sport-engine replay even while awaiting the AI decision.

This supersedes the former `ENGINE_INTERNAL_DURABLE_SELECTOR` / render-only Chat wording while preserving all single-flight and durable-run mechanics.
