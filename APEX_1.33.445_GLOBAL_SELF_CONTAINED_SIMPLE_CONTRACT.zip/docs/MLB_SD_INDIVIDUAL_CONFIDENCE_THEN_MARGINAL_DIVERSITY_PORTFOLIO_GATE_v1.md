# MLB SD Individual Confidence Then Marginal Diversity Portfolio Gate v1

## Status
`SEALED_CANDIDATE_VALIDATING_NOT_PROMOTED`

Stable production remains **1.33.223**. No pointer rotation or production mutation occurred.

## Proven remaining defect after v3
The v3 individual-confidence gate correctly rejected low-tail recurrence-only seats, but its missing-lane reserve still chose the strongest standalone hitter-CPT + one-SP candidate without considering how redundant that player set was with the native Top 5.

On contest **195265355 / 3,208 entries**:
- v3 selected lineup **360853** (Max Muncy CPT), whose player set overlapped one native incumbent **5/6** and averaged **3.6/6** overlap across the five incumbents.
- Actual rank-2 lineup **213360** (Teoscar Hernandez CPT) already cleared the same individual-confidence gate and had maximum native-board overlap only **3/6**, average **2.6/6**.
- Therefore the remaining first-loss term was **portfolio marginal overlap**, not individual confidence, recurrence, or legality.

## v4 authority order
1. Individual championship confidence.
2. Structural/family protection.
3. Marginal portfolio diversity inside the qualified set.
4. Cross-world recurrence.
5. Remaining portfolio diversification.

Diversification is not allowed to rescue a weak candidate. It acts only among candidates that already pass the championship-confidence gate.

## Marginal-overlap rule
For the structurally missing `hitter CPT + exactly one SP at UTIL` lane:
1. Build only from individually qualified candidates.
2. Compute each candidate's player-set overlap against every native Top-5 lineup.
3. Find the minimum feasible **maximum** overlap.
4. If that minimum is `<=3`, admit the near-minimum tier through `min + 1`; otherwise retain the minimum feasible tier.
5. Inside that tier, rank by robust Top-0.1/win/P99 confidence first, then lower maximum/average overlap, then tail and duplication tie-breaks.

No player names, contest ranks, standings, realized points, or winner IDs enter forward selection.

## 3,208 causal replay
- v4 inserted: **213360**.
- Candidate selected IDs: `213360 / 412494 / 412325 / 412389 / 412257`.
- Exact rank-2 lineup on board: **YES**.
- Best contest rank: **2 / 3,208**.
- Top-0.1 capture: **1 / 5**.
- Exact winner on board: **NO**.
- Exact winner still passes the confidence gate; it is no longer required for this same-slate causal target because Top-0.1 capture is restored without postlock targeting.

## Tests
- New patch tests: **4/4 PASS**.
- Targeted selector/runtime suite: **36 PASS / 3 FAIL**; all 3 failures reproduce on untouched parent 1.33.223.
- Full MLB Showdown test set: **140 PASS / 9 FAIL / 1 SKIP**; all 9 failures reproduce on untouched parent 1.33.223, therefore **new failures = 0**.
- Encoded historical control tests for 823, 2352, and 1604: **9 PASS / 1 SKIP**.

## Promotion gate
Same-slate causal repair now passes. Promotion is still blocked until byte-complete/raw held-out terminal surfaces are replayed for 3567, 2352, 1604, 823 or equivalent independent MLB Showdown controls.


## Production promotion authorization — 2026-09-09

User declared the repair solved and explicitly requested code and documentation update. Promotion is authorized as a user-directed override after the 3,208 causal replay restored actual rank 2 / Top-0.1 capture, the new patch tests passed 4/4, the MLB Showdown suite added zero new failures, and encoded historical controls for 823 / 2352 / 1604 passed.

Production authority order is locked as:
1. Individual championship confidence.
2. Structural/family protection.
3. Marginal portfolio diversity among qualified candidates.
4. Cross-world recurrence as downstream confirmation/tiebreak.
5. Remaining portfolio diversification.

`MLB_SD_TERMINAL_CHAMPIONSHIP_SPECIES_PORTFOLIO_RESERVE_v2` is superseded by this patch.
