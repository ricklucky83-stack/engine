# MLB SS HRS Historical Event-Rank Geometry Reserve v1

## Purpose

The repair protects repeatable SS-HRS championship geometries from being removed by compressed AI Pass-1/Pass-2 shortlists. It is an additive recall lane, not a new projection model and not a post-lock winner template.

## Pre-lock rule

Rank every active hitter by the frozen SS-HRS `P_EVENT` surface. A legal three-hitter lineup enters the protected reserve when:

- at least two hitters have event rank `1-40`; and
- all three hitters have event rank `1-120`.

Band labels used for diagnostics are `A=1-15`, `B=16-40`, `C=41-80`, `D=81-120`, and `E=121+`.

The reserve is unioned into downstream AI review. It does **not** delete candidates outside the rule, alter Phase-2 legality, use player names, inspect standings, or force a reserve lineup onto the final board.

## Cross-slate evidence

Three historical raw-pool/standings controls were replayed and scored before the current 3,567-entry slate was treated as holdout.

| Contest | Unique Rank-1 lineups | Captured by generalized rule |
|---|---:|---:|
| 191799824 | 18 | 13 |
| 191864350 | 3 | 3 |
| 191950963 | 24 | 24 |
| Historical total | 45 | 40 (88.89%) |
| Holdout 194552789 | 4 | 4 (100%) |

Across all four slates the rule retains `44/49` unique Rank-1 lineups (`89.80%`).

The holdout winners occupied `BBB`, `BBC`, and `BBD` geometry families. Those families were already present in historical controls, so the protection is based on recurring rank geometry rather than player-specific hindsight.

## Rejected intelligence path

A generic supervised boosted model was not promoted because its cross-slate behavior was unstable. SS-HRS therefore keeps the event-native probability kernel and uses historical evidence only as transparent structural recall protection.

## Production contract

- `P_EVENT` kernel: unchanged.
- Full legal Phase-2 enumeration: unchanged.
- Correlated common-world shadow layer: unchanged.
- No post-lock results or actual contest ownership may enter selection.
- The geometry reserve must survive both Pass 1 and Pass 2 when compressed AI review is used.
- The final AI hybrid selector still decides the portfolio using pre-lock quantitative/tail/duplication evidence; geometry protection guarantees visibility, not automatic selection.
