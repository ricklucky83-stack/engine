# APEX Global Research Branch Anti-Stall v1

## Hard rule

For one unchanged `BLOCKER_KEY` in one `EVIDENCE_EPOCH`, research gets exactly one primary route and at most one materially different fallback. If the same blocker remains after the fallback, the branch closes as `BRANCH_CLOSED_UNCHANGED_BLOCKER` and control returns to the first unresolved main engine/contest repair owner.

## Equivalent routes

Different mirrors, archive endpoints, search wording, or tool wrappers are equivalent when they still depend on the same unavailable bytes or the same causal algorithm. Restarting the same deterministic runtime from Phase 0 is also equivalent when a resumable continuation exists.

A fallback is materially different only when the evidence set or method/causal class changes enough to create a new falsifiable path.

## Reopen gate

A closed branch reopens only on new evidence, changed blocker state, a materially new method class, or an explicit user override naming that branch. Plain `GO` or `CONTINUE` does not reopen an equivalent closed branch.

## Conflict resolution

This hard gate bounds `APEX_GLOBAL_RESEARCH_NO_SHELF_BLIND_CLOSE_LOOP_v1`. Its autonomous-next-experiment instruction applies only inside this two-attempt budget. The anti-stall gate wins after the budget is exhausted.

## Scope boundary

This is orchestration/research governance only. It does not alter sport simulation, generator logic, selector weights, portfolio rules, or live-run recovery authority.
