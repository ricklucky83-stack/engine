# APEX Global Best Verified Logic Wins v1

## Authority rule

Production status is not evidence. A challenger does not lose merely because another implementation is already active.

For generator, model, selector, and portfolio authority decisions, compare verified evidence in this order:

1. Exact contest winner capture.
2. Perfect-lineup capture.
3. Top-0.1% capture.
4. Verified nonregression: zero new failures first, then breadth of passing controls.
5. Structural and prelock integrity.
6. Byte-complete blind-control depth and total verified cases.
7. Incumbency only if the verified evidence vector is exactly tied.

## Hard boundary

The evidence-first rule cannot waive integrity. A challenger is ineligible if it fails forward isolation, deterministic replay, state compatibility, identity-constant prohibition, or another nonwaivable integrity gate.

A domain-specific validation-depth requirement remains active by default. An explicit operator instruction may waive validation-depth only; it cannot waive integrity or allow postlock information into forward selection.

## Current MLB Showdown decision

`MLB_SD_TERMINAL_RECURRENCE_SELECTOR_v3` improved the earlier forced recurrence-seat design, but it does not have stronger verified winner-capture evidence than the active terminal championship-species reserve.

`MLB_SD_TERMINAL_CHAMPIONSHIP_SPECIES_PORTFOLIO_RESERVE_v2` remains terminal authority because its sealed 1.33.215 validation records exact winner capture on 3567 and 3208 plus exact no-op controls on 2352 and 823. The decision is evidence-based, not incumbent-based.

Generator authority remains `MLB_SD_CROSS_WORLD_LOCAL_MC_RECALL_SENTINEL_v2`; the rejected 1SP/2SP generator expansion is not activated.

## Promotion semantics

- A challenger with a strictly better verified evidence vector becomes authority after all nonwaivable hard gates pass.
- If validation depth is the only blocker, an explicit operator validation-depth override may authorize the superior challenger.
- If the challenger is worse, the existing authority stays because its evidence is better.
- If the evidence vectors are exactly equal, the existing authority stays as the stability tie-break.

This policy is promotion/arbitration governance only. It does not change live lineup scoring, simulation, or postlock isolation.
