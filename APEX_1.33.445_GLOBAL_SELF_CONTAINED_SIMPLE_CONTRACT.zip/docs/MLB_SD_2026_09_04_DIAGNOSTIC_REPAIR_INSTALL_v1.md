# MLB Showdown 2026-09-04 diagnostic repair install

Production installation includes:

1. `MLB_SD_ROLE_COMPLETE_CPT_PERMUTATION_CLOSURE_CARSHOP_v1`: after Phase-2 birth, complete every legal CPT assignment for each born six-player identity set before fake-field scoring and handoff. Player additions/removals are prohibited.
2. `ONE_PLAYER_CLOSURE_NEIGHBORHOOD_v2`: terminal role-swap comparisons stay inside the exact player set and frozen structural family; salary is feasibility only.
3. `MLB_SD_HITTER_CPT_ROLE_DISLOCATION_PROTECTED_LANE_v2`: role dislocation is a within-family ranking signal after tail-feasibility gating.
4. `MLB_SD_CONTEST_ENTRY_WITH_REPLACEMENT_FAKE_FIELD_v1`: fake field represents contest entries, samples with replacement, and preserves duplicate-entry/clumping behavior across the four Dual-SP/CPT strata.

No post-lock contest result is a production input.
