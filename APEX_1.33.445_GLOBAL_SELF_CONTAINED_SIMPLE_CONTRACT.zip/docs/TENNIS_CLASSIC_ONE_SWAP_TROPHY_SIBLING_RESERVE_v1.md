# Tennis Classic One-Swap Trophy Sibling Reserve v1

## Scope
DraftKings Tennis Classic final portfolio reconciliation only. The complete Phase 2 / handoff / selector-reviewed surface remains unchanged.

## Rule
The ordinary pairwise overlap ceiling remains 4-of-6. After the first strict global selector anchor is admitted, the engine may reserve at most one 5-of-6 sibling from the top 24 full-order selector rows. The sibling is chosen by pre-lock extreme-tail evidence only: Top-0.1 rate, win rate, P99 and CVaR99. Mean projection has zero weight.

## Forward firewall
- no player-name rules
- no actual fantasy points
- no contest standings or contest rank
- no post-lock ownership
- no lineup birth or restoration authority
- no change to Phase 2, simulation, handoff or Hybrid AI ranking

## Target causal replay
Contest 195185698 / field 3567 under active 1.33.204: the exact winner was born, survived handoff, was selector reviewed and ranked fifth in the full selector order, but was rejected from the board because it overlapped the primary anchor 5-of-6 while the general cap was 4-of-6. The reserve restored the winner to board position 2; official contest rank was 1/3567.

## Historical causal validation
The existing Tennis terminal-AI historical corpus already tests the same family-preservation mechanism:
- 2352 exact control: an exact perfect was rescued despite weaker MC point estimates than its one-swap sibling.
- 192407608: winner and perfect were born/in the frontier but terminal selection missed both.
- 192741221: actual ranks 1, 2 and 3 were one mutation cluster with pairwise 5-of-6 overlap.
- 192626197: winner and perfect were already selected; this is a no-op protection control.
- 192664039: winner/perfect never reached the frontier; selector-only logic correctly remains out of scope.
- 2745: the elite five-lineup deck is preserved by the family rule.

Historical causal backtest status: 8/8 PASS_HISTORICAL_CAUSAL. These historical outcomes are validation evidence only; they are not forward selector inputs.
