# APEX Global Mandatory Chunk-and-Stream Execution v1

## Rule
Large production work is never one monolithic in-memory transaction. The engine owns deterministic chunk boundaries and durable cursors.

The required loop is:

`read cursor -> execute chunk -> hash/commit sidecar -> advance chunk cursor -> release memory -> check deadline -> continue or return 75`.

A chunk may be a lineup-row block, simulation-trial block, public-field threshold block, recurrence-row block, or large handoff block. Chat does not choose or resume chunks. The global production supervisor owns return-code-75 continuation.

## Hard invariants
- No completed chunk is recomputed after an interruption.
- Chunk size may affect runtime only; it may not affect simulations, metrics, recurrence telemetry, lineup identity, selector decisions, or final board.
- Control records remain small. Large matrices live in immutable hashed sidecars.
- A large stage may not defer checkpointing until the entire stage is complete.
- A final board is the only successful terminal state.

## Trigger
Native chunk/stream behavior is mandatory when any large-work trigger applies: estimated runtime >=5 seconds, working set >=64 MiB, candidate rows >=2,048, or trials >=2,048.

## CFB Showdown adapter
`CFB_SHOWDOWN_ENGINE_OWNED_CHUNK_STREAM_RESUME_v1` implements trial-streamed public-field thresholds, lineup-streamed Phase 3 evaluation, recurrence-row streaming, durable per-chunk SHA-256 commits, and engine-owned return-code-75 continuation.

## Production CLI bypass closure
CFB Showdown now enforces the same contract even when the raw runtime module is invoked directly. The raw CLI delegates to `engines/cfb/cfb_showdown_chunk_stream_controller_v1.py` by default. The old monolithic `execute()` escape hatch is deleted. Direct native CLI invocation delegates to the chunk/stream controller with no regression exception.

## Active-state synchronization
Verified through state `1.33.201` as a code/documentation enforcement sync. Simulation, generator membership, recurrence math, selector objective, and final-board semantics are unchanged.
