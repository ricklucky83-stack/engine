# APEX Global Forward Holdout Auto Capture v1

Every validated production run now emits a forward-only holdout capsule from the global terminal boundary.

The capsule freezes the complete selector-reviewed surface, its hash/freeze identity, the terminal selector ledger, the final Top-5 Winner Circle, the active state version, and pool hash when available **before any resolved contest outcome is attached**.

Resolved standings are attached later as a separate immutable postlock receipt. The prelock manifest is never rewritten. Historical outcomes remain prohibited as live selector/generator/simulation inputs.

This patch changes no generation, simulation, ranking, ownership, diversification, or Winner-Circle decision logic. Its sole purpose is to guarantee future byte-complete clean holdouts so selector candidates can be promoted or rejected on time-ordered evidence instead of reconstructing old files.
