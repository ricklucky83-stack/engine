# APEX Global 3E Production Standard v2

## Objective
APEX must be **Efficient, Effective, and Elite** in both contest execution and engine repair. A technically correct repair that repeatedly diagnoses, retests, reseals, or rereads unchanged state is not 3E-compliant.

## Efficient — single-pass repair transaction
Every repair is one parent-pinned transaction:

`DIAGNOSED → PATCHED → TARGETED_TESTED → SEALED → CAS_VERIFIED → POINTER_ROTATED → READBACK_VERIFIED`

Within one parent epoch, each stage may execute **once**. Duplicate diagnosis, targeted tests, manifest verification, seal, CAS validation, or readback are prohibited. The only valid reason to repeat post-patch work is an actual ACTIVE-parent change detected at the CAS boundary.

When ACTIVE changes, preserve the root-cause diagnosis and minimal patch intent, rebase only the diff, then rerun the targeted test and seal once against the new parent. Do not rediscover settled evidence.

Diagnostic ledger work is incremental. Maintain the prior queue index/digest and apply only newly arrived immutable receipt events. A full historical ledger rescan is permitted only when the cursor/index is unavailable, corrupt, or fails integrity validation.

## Effective
- Root cause must be identified before code mutation.
- Patch the smallest owning component; do not retune sport logic for a control-plane defect.
- Run one bounded targeted test set that directly reproduces the failure and validates the repair.
- No-lost-repair coverage and CAS remain hard gates.
- One post-rotation readback verifies exact-title pointer identity, bundle/hash integrity, semantic state parity, and terminal diagnostic accounting.

## Elite
The production objective remains actual winner/perfect-lineup and Top-0.1% capture. Cross-world recurrence breadth remains primary, with common-world comparison, held-out confirmation, and Top-5 championship-union portfolio construction preserved.

## Enforced code
- `engines/common/apex_3e_repair_transaction_v1.py` — strict stage machine, duplicate-stage rejection, parent-drift-only rebase.
- `engines/common/apex_diagnostic_merge_ledger_v3.py` — incremental queue index + delta application; no mandatory historical reconstruction.
- `apex_state_commit.py` — optional repair-transaction guard blocks a second seal on the same parent epoch and advances the transaction atomically after a successful seal.

## CAR SHOP rule
CAR SHOP diagnostics must reuse validated context and service history. `DO_NOT_REDISCOVER_ALREADY_SETTLED_MECHANICS` now includes operational work: once the root cause is isolated and the bounded test passes, promotion proceeds directly through the remaining single-pass stages unless ACTIVE actually changes.
