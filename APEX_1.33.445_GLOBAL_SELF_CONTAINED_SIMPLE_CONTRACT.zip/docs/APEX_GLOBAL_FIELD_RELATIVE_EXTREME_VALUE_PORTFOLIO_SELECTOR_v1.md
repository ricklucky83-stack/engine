# APEX Global Field-Relative Extreme-Value Portfolio Selector v1

## Production objective

APEX no longer treats the final GPP decision as a deterministic knapsack or a five-lineup scalar ranking problem. Candidate birth and legality remain sport-native; the global terminal selector optimizes the **joint probability that at least one playable lineup captures a championship or Top-0.1% common world**.

Primary production objective:

\[
\max_B P\left(\exists L\in B:\ S_L > \max_{f\in F}S_f\right)
\]

subject to legal sport/mode roster rules and a five-lineup terminal board.

## Architecture

1. Sport-native latent opportunity and game-script simulation.
2. Calibration-qualified legal lineup birth.
3. Contest-sized or contract-qualified realistic public-field generation.
4. Common-random-number lineup-vs-field simulation.
5. Exact field-relative WIN / Top-0.1% / Top-1% event surfaces.
6. Uncertainty-aware ranking and adaptive bubble simulation.
7. Joint portfolio selection.
8. Terminal Core-5 seal.

A covariance matrix is not treated as a generative model. Upstream sport engines must produce a joint outcome distribution through sport-native event simulation, latent-factor/copula construction, or another validated dependency model.

## Exact common-world mode

When the sport runtime exports packed event masks, the selector uses exact incremental union coverage with WIN:Top-0.1%:Top-1% weights of **15:10:1**. Static metric sums do not override exact common-world marginal gains.

This mode is the preferred production path because it directly measures the championship worlds covered by the portfolio.

## Terminal proxy mode

Some native runtimes currently export field-relative row metrics but not packed common-world masks to the terminal runner. Those routes use a conservative proxy built from:

- WIN rate and one-sided lower confidence bound;
- Top-0.1% rate and lower confidence bound;
- Top-1% rate when available;
- P99/CVaR99 and P95 tail evidence;
- simulation trial count;
- duplication / uniqueness evidence;
- player-overlap redundancy.

Sparse rare-event rates are uncertainty-adjusted with Jeffreys posterior shrinkage plus a one-sided Wilson lower bound. Cross-sport fantasy-point scales are never combined directly; tail quantities are rank-normalized inside the candidate surface.

## Ownership and duplication

Ownership product remains a fallback field-density proxy, not the primary objective. Evidence priority is:

1. direct `P_UNIQUE`;
2. direct `EXPECTED_DUP` / expected duplicates;
3. ownership-product proxy only when direct duplication evidence is absent.

The performance model must not suppress a player merely because the public owns them. Ownership affects expected duplication and field-relative payoff, not simulated athletic performance.

## Portfolio concentration

The global selector does not force five unrelated lineups. A high-confidence one-swap family may occupy up to three Core-5 seats when field-relative evidence supports it. If alternatives exist, the selector prevents the entire board from collapsing into one near-duplicate family.

Sport-native protected lanes, scenario sentinels, captain structures, and other pre-lock structural authorities remain higher priority than the generic global selector.

## Sportsbook and market data

Sportsbook totals and player props belong upstream as calibration anchors. They do not become a second copy of the selector objective. Two-sided prices require no-vig normalization, market contamination/double-counting controls remain active, and ownership is prohibited from entering the athletic performance model.

## Adaptive simulation

The global selector assumes the existing `HANDOFF_METRIC_PARITY_AND_ADAPTIVE_BUBBLE_SIM_v1` contract is active. Broad candidates receive the base common-world budget; unresolved decision-boundary lineups receive additional trials until confidence intervals separate or the configured budget is exhausted.

## Production fail-closed rules

Selection halts if post-lock fields enter the selector, only part of the required common-world mask set is supplied, mask dimensions are invalid, or the requested board cannot be completed. No mock optimizer, projection-only fallback, relaxed lineup, or random First-N selection is permitted.

## Production integration

- Executable: `engines/common/apex_field_relative_extreme_value_portfolio_v1.py`
- Terminal integration: `engines/common/apex_global_championship_core_v1.py`
- Governance: `doctrine/APEX_GLOBAL_FIELD_RELATIVE_EXTREME_VALUE_PORTFOLIO_SELECTOR_v1.json`
- Tests: `tests/test_global_field_relative_extreme_value_portfolio_v1.py`

The terminal integration activates the new selector automatically when sport-native forward field-relative metrics are present. Metric-poor legacy surfaces retain the existing championship-family selector until their native runtime exports the required evidence.
