# APEX Global Side Selection Accuracy + Spread Calibration v1

Patch: `APEX_GLOBAL_SIDE_SELECTION_ACCURACY_AND_SPREAD_CALIBRATION_v1`

State target: `1.33.360` rebased from `1.33.359`.

## Scope

Global shared team-sport layer: NFL, CFB, CBB, NBA, WNBA, NHL, MLB. Sport adapters emit frozen prelock side receipts; postlock outcomes only grade those receipts.

## What is measured

- APEX selected/overweighted side vs outright winner.
- APEX selected/overweighted side vs ATS cover side.
- Market-favorite alignment and favorite win/cover rates.
- Results by sport, contest mode, and absolute-spread bucket.
- Top-0.1% hit, winner/perfect capture, and terminal rank when contest grading exists.

## Authority rule

No live favorite/spread boost is activated from installation alone. Forward authority remains 1.00 until at least 20 graded games overall; bucket-specific authority requires at least 12 graded games in that bucket. Any future multiplier is bounded to 0.80–1.20 and uses shrunk historical/prospective accuracy. Same-slate postlock feedback is prohibited.

## Invariant

`spread != mandatory favorite selection`

The spread may calibrate world/script prior probability only after evidence clears the gate. Candidate birth, tail scoring, leverage, duplication, correlation, and portfolio coverage remain authoritative.

Notion authority: https://app.notion.com/p/3e0aa12fda7b81ecb4fbcd3c777fbd42?pvs=204
