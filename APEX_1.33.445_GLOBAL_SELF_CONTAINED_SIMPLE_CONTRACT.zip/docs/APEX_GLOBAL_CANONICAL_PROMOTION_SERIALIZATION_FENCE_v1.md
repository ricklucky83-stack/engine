# APEX Global Canonical Promotion Serialization Fence v1

This is a promotion-only hard gate. It does not run before live CSV execution.

It prevents two cross-chat failure modes:

1. **Stale lineage overwrite** — a candidate cannot replace `APEX_DIRECT_ENGINE.zip` unless its declared parent state version and parent byte SHA-256 exactly match a freshly downloaded canonical file.
2. **Duplicate state version** — the immutable archive namespace is searched before preflight and again immediately before the canonical write. If `APEX_DIRECT_ENGINE_v<version>.zip` already exists, promotion hard-stops and the next unused version must be allocated.

Immediately before the write, canonical bytes are re-fetched. Any version/hash drift invalidates the receipt. After the write, the raw Drive bytes and embedded state version must match the exact candidate authorized by the precommit receipt.

Older-branch work may be preserved only by rebasing/cherry-picking the validated delta onto the current canonical lineage. Whole stale bundles may never become canonical.
