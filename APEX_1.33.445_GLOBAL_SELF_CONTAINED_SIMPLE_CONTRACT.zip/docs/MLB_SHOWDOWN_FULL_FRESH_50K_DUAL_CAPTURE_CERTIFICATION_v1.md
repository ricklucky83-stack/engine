# MLB Showdown — Full-Fresh 50K Dual-Capture Certification v1

Patch: `MLB_SD_FULL_FRESH_50K_DUAL_CAPTURE_CERTIFICATION_v1`

## Purpose

This is a post-lock certification contract for CAR SHOP repairs. It does not alter lineup generation, simulation, ranking, or Core-5 selection. Its only purpose is to fail closed unless a completed forward pre-lock production run proves that the final playable Core-5 contains both the actual contest winner and the independently established perfect lineup.

The certifier is post-lock only. It may read target identities and realized results only after the production board is frozen. It is prohibited from being imported by the forward engine or used as a selector input.

## Strict certification gate

A receipt certifies only when all conditions are true:

- the run is marked fresh end-to-end;
- Phase-1 simulation count is at least 50,000;
- the final playable board contains exactly five lineups;
- global final-playable Core-5 enforcement is active;
- machine-board parity is `PASS`;
- production used no post-lock input;
- production used no player-name constants;
- the actual contest winner is on the final Core-5;
- the perfect lineup is on the final Core-5;
- the upstream strict success gate and run status are both `PASS`.

Any missing or false condition blocks certification.

## 823 full-fresh evidence

The preserved validation receipt for state `1.33.90` records a fresh end-to-end run with 50,000 Phase-1 trials, split into 10,000 base and 40,000 extra trials, for field size 823. The final playable board size is five and global Core-5 terminal enforcement is active.

The perfect lineup is final Core-5 seat 1 and the actual contest winner is final Core-5 seat 3. Machine-board parity and the strict success gate are both `PASS`. The receipt also records that production used neither post-lock inputs nor player-name constants.

This evidence is validation-only and is not a forward selector input.
