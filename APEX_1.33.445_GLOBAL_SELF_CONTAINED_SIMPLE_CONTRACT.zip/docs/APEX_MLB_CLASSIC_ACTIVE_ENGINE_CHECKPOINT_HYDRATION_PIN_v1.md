# APEX MLB Classic Active Engine Checkpoint Hydration Pin v1

Cross-version checkpoints are data-only. Hydration pins module/class resolution to the current active engine root before unpickling. No model or selector-scoring changes. Live proof: preserved MLB Classic 294 selector checkpoint advanced from stage 17 to stage 18 without loading the historical engine module.
