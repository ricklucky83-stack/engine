# APEX Global Conditional Sports → Field → Contest Surface v1

## Production rule

Raw stat columns are never acknowledged in arbitrary order and DraftKings point values do not determine the sports simulation order. The sports model generates realistic conditional events first; DK scoring transforms those events into fantasy points afterward.

Authoritative hierarchy:

1. Game environment.
2. Team / match state.
3. Player role and opportunity.
4. Sport-native event probabilities.
5. Joint conditional outcomes and shared latent factors.
6. DraftKings scoring transformation.
7. Extreme-tail / win / Top-0.1% sports outcomes.
8. Legal synthetic field generation.
9. Lineup-level ownership and exact duplication.
10. Common-world contest ranking, tie splitting and payout EV.
11. Salary / roster geometry as legal construction constraints.
12. Portfolio marginal value for the final board.

## Three-surface separation

### Sports Surface
Pure athletic outcomes only. Ownership, leverage, duplication, payout structure and salary price may not parameterize the sports distribution. Salary is allowed later only as a roster legality / geometry constraint.

Required principle:

`Distribution_i = f(Role, Opportunity, Event Rates, Environment, Uncertainty, Shared State)`

not:

`Distribution_i = f(Salary, Ownership, Leverage)`

Fantasy points are emergent from sport events rather than a direct Normal/Poisson/Lognormal draw whenever a sport-native event model exists.

### Field Surface
Represents public behavior. Legal lineups are sampled using ownership, stack/construction preferences, salary usage, positional paths and other field tendencies. Duplication is computed at the exact lineup level. Required output includes `EXPECTED_DUP`, `P_DUP_0`, `P_DUP_1`, `P_DUP_2_PLUS`, `P_DUP_5_PLUS`, `P_DUP_10_PLUS`, and `DUP_P95` when repeated fields are available.

### Contest Surface
Candidate and field lineups are scored in the same simulated sports worlds. Rank is therefore a joint outcome, not a post-hoc scalar penalty. Tied ranks split the occupied payout positions. The surface emits Win Rate, Top-0.1% Rate, Expected Payout and Expected ROI.

## MLB conditional batting adapter

The MLB adapter simulates one plate-appearance event at a time. A PA produces exactly one event (`BB`, `HBP`, `K`, `1B`, `2B`, `3B`, `HR`, `OUT`). Base/out state then determines runners scoring and RBI. Runs and RBI are not independently sampled.

A shared fat-tailed team latent shifts the event logits for all hitters in a trial, producing natural teammate covariance before DK scoring. The adapter does not read salary, ownership, leverage, duplication or contest payouts.

The adapter is intentionally event-rate driven. Salary-bucket variance rules are prohibited because they create circular price bias.

## Duplication and leverage

Individual leverage remains diagnostic. It is not the terminal objective. Two lineups with similar ownership can have very different duplication because of stack shape, salary left, value combinations, CPT role and public optimizer behavior.

The terminal economics target is lineup / portfolio value under the simulated contest:

`EV(L) = E[split-adjusted payout(L)] - entry fee`

For multi-entry boards, five high standalone scores are not sufficient. The selector must preserve strong championship cores while maximizing incremental championship-world / payout coverage and avoiding redundant fragile scripts.

## Executable modules

- Global surface contract and common-world evaluator: `engines/common/apex_conditional_sports_field_contest_surface_v1.py`
- MLB sequential batting-state adapter: `engines/mlb/mlb_conditional_batting_state_surface_v1.py`

## Compatibility

This patch is additive to existing calibrated sport runtimes. It establishes the required interface and executable common-world economics layer without replacing a sport-native model until that sport provides compatible event-rate inputs. Existing selectors may consume the new contest metrics when present; absence of those metrics must not be faked or backfilled from projection-only proxies.
