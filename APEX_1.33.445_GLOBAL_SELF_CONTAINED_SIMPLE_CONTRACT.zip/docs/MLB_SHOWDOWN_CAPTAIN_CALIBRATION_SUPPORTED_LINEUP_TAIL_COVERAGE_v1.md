# MLB Showdown Captain Calibration-Supported Lineup-Tail Coverage v1

This patch supersedes the hard-exclusion behavior of `MLB_SD_CAPTAIN_BARGAIN_VALUE_FIRST_v1` while preserving its slate-breaker and roster-unlocker priority classes.

A non-RP Captain remains eligible for Phase-2 enumeration when its best legal six-man construction preserves at least 97% of the best legal Captain lineup-tail proxy. Standalone player P99 remains useful evidence but cannot by itself delete a lineup-level championship path. Starting-pitcher visibility is preserved.

The rule is forward-blind and identity-free. It uses only frozen Phase-1 distributions, salary/roster legality, and current pre-lock player-pool data.
