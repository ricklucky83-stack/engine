# APEX Global Chunk-and-Stream Only Execution v3

Chunk-and-stream is a **global engine execution architecture**, not a sport-specific optimization. Every live sport/mode must resolve to a certified engine-owned chunk controller. The production runner never falls back to a raw runtime.

A mode is executable only when its registry status is `CERTIFIED` and its chunk-stream controller is registered. `ADAPTER_REQUIRED` fails closed with `RUN_INVALID:CHUNK_STREAM_ADAPTER_REQUIRED`; it never silently runs monolithically.

The contract applies to Phase 1, Phase 2, Phase 3, generation/enumeration, Monte Carlo, public-field simulation, recurrence, selector evaluation, merges, historical replay, and live execution. Completed chunks persist and are resumed from the last committed cursor; completed work is not restarted.

Vectorized, compiled, sparse, branch-and-bound, and cached-feasibility kernels are permitted inside deterministic bounded chunks. They do not create alternate execution paths.

## Reset compatibility

Live startup remains direct: Notion-authoritative rules -> active sport controller/runtime -> current player-pool CSV -> execute. Bootstrap, pointer, bundle-hash, and manifest-hash gates are not startup authority. Per-chunk hashes/checksums may be used only after load for durable artifact/resume integrity.

## Production coverage — 1.33.345

- Registered mode labels: **30**
- Certified chunk-stream mode labels: **30**
- Adapter-required mode labels: **0**
- Raw runtime fallback: **prohibited**
- End-to-end monolithic raw runtime dispatch: **prohibited**
- Continue return code: **75 (`CHECKPOINTED_CONTINUE`)**
- Completed chunks resume from persisted state and are not restarted.
- Bootstrap, pointer, bundle-hash, and manifest-hash checks are not live startup gates. Internal chunk/artifact integrity checks remain allowed after runtime load.
- Chat and OpenAI have no live execution or terminal board authority; the engine owns the terminal board.

The generic controller advances Python runtimes at native deterministic statement boundaries while preserving the sport runtime as code authority. Sport-native controllers remain in use where deeper stage-specific chunking exists (including MLB, CFB Showdown, MMA, and Tennis preflight + generic runtime execution).
