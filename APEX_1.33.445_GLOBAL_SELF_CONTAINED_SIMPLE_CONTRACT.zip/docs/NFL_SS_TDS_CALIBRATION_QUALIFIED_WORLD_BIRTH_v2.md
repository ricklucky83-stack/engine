# NFL SS TDS Calibration-Qualified World Birth v2

This patch restores NFL Single-Stat Touchdowns on the current global FAST PATH contract without reviving the legacy all-triad Phase-2 lattice.

## Production order
1. Freeze the active non-QB scorer pool.
2. Simulate count-valued touchdown worlds from prelock team/scorer evidence.
3. Birth only Phase-1-qualified triads from world-optimal, near-optimal, team-event, global-event, and recurrent-pair lanes.
4. Compute the weighted public-field score distribution with dynamic programming over the 3-of-N score polynomial. No legal lineup identity universe is enumerated.
5. Evaluate every born triad on the same common worlds and hand the complete frozen surface to the terminal selector.

## Hard invariants
- QB/K/DST remain excluded.
- FPTS has no touchdown-scoring or ownership authority.
- Player touchdown outcomes remain integer counts and preserve multi-TD tails.
- Same-team triads are allowed when Phase-1 event evidence births them.
- Provider Showdown RST is not field authority.
- Ownership mass remains 300%.
- Full legal-universe enumeration is prohibited.
- Unqualified candidate birth is prohibited.
- Postlock results and player-name constants are prohibited.
