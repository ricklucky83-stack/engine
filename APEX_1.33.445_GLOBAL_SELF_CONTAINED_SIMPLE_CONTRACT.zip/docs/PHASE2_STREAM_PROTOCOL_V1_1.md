# PHASE2_STREAM_PROTOCOL_V1.1

Production architecture is an unbroken elite-tail propagation chain.

- Birth: championship-neighborhood recall; median/projection may not cull rare-tail neighborhoods.
- Handoff: qualified elite-tail rows receive immutable propagation passports and are immune to family, ownership, median, and diversification eviction.
- Simulation: use common worlds/CRN, multi-seed confirmation, and adaptive bubble re-simulation through the sport-native simulator.
- Selector: primary objective is `P(Contest Rank=1)` then `P(Top 0.1%)`; sparse rates are uncertainty-bounded and empirically shrunk toward structural-neighborhood means.
- Final gate: selected rows require complete Birth -> Handoff -> Sim -> Selector lineage. Missing lineage hard-fails.

Ownership remains market-price/tie-break evidence and has no culling authority over protected championship candidates.
## Multi-seed convergence hard gate

`APEX_GLOBAL_MULTI_SEED_UNTIL_SEPARATION_v1` operationalizes the simulation clause. Confidence-overlapping board-boundary candidates must be passed through a sport-native, deterministic multi-seed re-simulation loop before terminal selection. Exact lineup-ID parity and cumulative trial growth are mandatory. The loop never creates or prunes lineups. If the configured convergence budget is exhausted with overlap remaining, the cohort is explicitly marked `MAX_BUDGET_EQUIVALENT`; it is not mislabeled as separated. Terminal AI receives the frozen post-convergence surface and has no simulation authority.

