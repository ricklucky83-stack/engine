# APEX_GLOBAL_SINGLE_MANIFEST_INTEGRITY_AUTHORITY_v1

`bundle_manifest.json` is the sole file-integrity authority. Registry and nested engine manifest hashes are metadata diagnostics only and may not halt a runtime whose bundle manifest verifies. Missing files or any mismatch against the embedded bundle manifest remain hard failures.

Hot-runtime identity excludes registry-file hashes. Registry content continues to supply routing, entrypoints, capabilities, and schemas.
