# APEX Global Durable Run Ledger and Terminal Commit Protocol v1

Global execution durability repair. Large candidate/selector/board artifacts remain immutable sidecars; the run ledger stores only hashes, paths, counts, event lineage and commit state.

Terminal contract:
`TERMINAL_SURFACE_COMMITTED -> AI_DECISION_COMMITTED -> CORE5_BOARD_COMMITTED -> BOARD_READY`.

Chat remains outside engine execution except for the selector decision. Before selector handoff the engine commits the complete frozen candidate surface and lineup identity mapping. Chat selection is atomically written and committed before board sealing. The next identical top-level command can therefore resume from a committed selector decision without replaying Phase 0-3.

A selector handoff is an expected `AI_SELECTOR_HANDOFF_REQUIRED` state, not a failure. No Chat-selected stage/cursor/chunk/checkpoint controls are allowed.
