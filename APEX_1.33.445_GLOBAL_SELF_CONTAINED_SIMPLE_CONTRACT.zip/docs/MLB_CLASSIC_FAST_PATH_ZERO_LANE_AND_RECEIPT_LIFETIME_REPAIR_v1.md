# MLB_CLASSIC_FAST_PATH_ZERO_LANE_AND_RECEIPT_LIFETIME_REPAIR_v1

## Scope
DraftKings MLB Classic FAST_PATH runtime safety.

## Corrective action
1. Zero stochastic births no longer terminate a family before deterministic Phase-2 sentinels/closures run.
2. Deferred zero families are checked once, after all Phase-2 construction. A family still at zero fails closed.
3. FAST_PATH receipt counters are snapshotted before memory pruning, so terminal serialization cannot reference released sets.
4. Scoring, calibration, simulations, handoff, selector logic, and Core-5 ranking are unchanged.

## Triggering failure
The 2,352-entry MLB Classic run produced zero stochastic `2-2-1-1-1-1` rows, then the deterministic distributed-geometry sentinel produced two legal rows. The old early fatal gate aborted before that backfill. The recovery later exposed a second defect: `closure_family_reserved` had been deleted by FAST_PATH pruning before final receipt serialization.

## Invariant
Temporary zero != terminal zero. Receipt serialization must not depend on generation-only objects after the FAST_PATH release boundary.
