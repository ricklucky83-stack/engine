> **Superseded in candidate by `APEX_GLOBAL_HYBRID_SELECTOR_INTELLIGENCE_v2`: one global shared intelligence system with sport/mode context adapters.**

# APEX Global Hybrid Selector Top-0.1 Intelligence Training v1

**Patch:** `APEX_GLOBAL_HYBRID_SELECTOR_TOP01_INTELLIGENCE_TRAINING_v1`

## Objective

Train and evaluate the AI specifically for its only production responsibility: choose the five existing lineups with the strongest championship / Top-0.1 portfolio value from the engine's complete frozen selector surface.

Primary metrics:

1. `WINNER_CAPTURE_AT_5`
2. `TOP_0_1_CAPTURE_AT_5`
3. `BEST_CONTEST_RANK_AT_5`
4. gap between the best Top-0.1 candidate available in the frozen surface and the best Top-0.1 candidate actually selected.

This workstream does not expand AI authority upstream.

## Training unit

Each resolved historical slate becomes one listwise ranking problem:

- input: the exact prelock frozen selector surface available to the AI;
- action: blind AI Top-5 selection;
- reveal: resolved contest ranks only after the blind decision;
- lesson: identify missed championship candidates and the hard negatives that displaced them.

Training labels are graded rather than binary:

- rank 1: grade 4;
- Top-0.1 excluding rank 1: grade 3;
- Top-1 excluding Top-0.1: grade 2;
- remainder: grade 0.

This preserves the primary rank-1 objective while giving the model enough dense ranking signal to learn.

## Hard-negative curriculum

The highest-value training pairs are not obvious bad lineups. They are coded-selector favorites or AI-selected candidates that outranked a winner/Top-0.1 candidate on the frozen surface.

Each historical miss creates a preference lesson:

`preferred = resolved winner/Top-0.1 candidate`

`rejected = plausible prelock hard negative that the existing selector preferred`

The lesson must explain the generalizable prelock distinction. Player-name memorization is prohibited.

## Player-identity firewall

Offline training artifacts remove CPT/UTIL/player identity fields and retain only lineup ID plus safe prelock metrics, structures, family evidence, recurrence, ownership/duplication, simulation/tail evidence, and coded-selector comparator fields. Resolved contest rank is a training label only and never enters a forward production surface.

## Training methods

- blind listwise replay;
- graded ranking labels;
- hard-negative mining;
- pairwise preference lessons;
- sport/mode-specific curriculum;
- walk-forward holdout evaluation.

The architecture is consistent with learning-to-rank research: listwise LLM reranking can improve final-stage rankings; preference optimization can learn preferred-versus-rejected choices; and ranking objectives should concentrate learning pressure near the top of the list rather than optimize irrelevant full-field regression accuracy.

## Sport-specific lessons

Global lessons teach championship ranking under uncertainty. Sport profiles teach the causal structure needed to interpret the frozen metrics:

- MLB Showdown: CPT role, player-set reciprocal siblings, game scripts, zero/one/two-SP states, cross-world recurrence, local championship density, ownership/duplication and salary unlocks;
- MLB Classic: stack geometry, pitcher-hitter covariance, recurring same-world cores and ownership-shape differentiation;
- Tennis: player-core Top-0.1 density, one-swap neighborhoods, P99/CVaR tail consensus and same-match fragility;
- CFB/NFL: role stacks, game scripts, usage/route/pace evidence and correlation;
- PGA/MMA/WNBA: use their registered sport-native intelligence profiles.

## Promotion rules

Do not promote a new AI curriculum because it explains a known winner after the fact. Require time-ordered walk-forward slates with frozen prelock surfaces. A candidate curriculum must improve `WINNER_CAPTURE_AT_5` and/or `TOP_0_1_CAPTURE_AT_5` without contaminating forward inputs with resolved results.

## Research basis

- Ma et al., *Zero-Shot Listwise Document Reranking with a Large Language Model* (2023): supports final-stage listwise reranking rather than independent point scoring.
- Rafailov et al., *Direct Preference Optimization* (2023): supports learning from preferred/rejected examples without requiring a separate reward-model/RL pipeline.
- Burges / Microsoft learning-to-rank work: supports optimizing ranking objectives and applying stronger learning pressure to the top of the ranked list.

## Production boundary

The curriculum builder is offline only. In live production the AI still receives no postlock labels. Its authority remains the final Hybrid Selector decision over existing frozen lineup IDs.
