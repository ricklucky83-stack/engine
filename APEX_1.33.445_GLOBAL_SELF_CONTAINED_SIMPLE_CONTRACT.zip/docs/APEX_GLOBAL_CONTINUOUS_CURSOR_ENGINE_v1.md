# APEX_GLOBAL_CONTINUOUS_CURSOR_ENGINE_v1

Production contract for content-addressed hot runtime reuse and append-only chunk recovery.

- Normal states: ZERO_STATE, HYDRATED, RUNNING, INVALIDATED.
- Execution timeout/preemption never invalidates a hydrated runtime.
- A valid hot runtime forbids pointer-driven bundle decode/extract/rebuild work.
- Cold hydration is permitted only for zero state, explicit invalidation, or invariant mismatch.
- Progress authority is the verified append-only hash-chain ledger tail.
- `CURSOR = LAST_VERIFIED_COMMIT + 1`.
- Chunk replay is deterministic and idempotent.
- Tennis Classic Phase 2 is the first production adapter: legal-universe CAS reuse plus resumable full-scan ledger commits.
