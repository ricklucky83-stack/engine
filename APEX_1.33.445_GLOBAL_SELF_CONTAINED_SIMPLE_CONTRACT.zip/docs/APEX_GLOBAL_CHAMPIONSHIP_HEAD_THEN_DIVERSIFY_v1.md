# APEX_GLOBAL_CHAMPIONSHIP_HEAD_THEN_DIVERSIFY_v1

Status: ACTIVE_GLOBAL_USER_DIRECTED

The first five playable seats are a **championship neighborhood**, not a diversification showcase.

Global execution rule:

- Seats 1-5: protect the strongest recurring championship neighborhood using cross-world recurrence, pairwise strength, world breadth, stable tail presence, rank stability, and Hybrid Eyes multi-signal agreement.
- MC metrics remain evidence only: `MC METRICS = SIGNAL; MC VALUES != TRUTH`.
- No generic overlap penalty, shared-core saturation penalty, family cap, marginal-new-world bonus, ownership diversification, Captain rotation, or counter-script coverage rule may displace an otherwise stronger championship-head row solely to make the first five look different.
- Seat 6 onward: controlled diversification, exposure management, alternate scripts, ownership/duplication management, and secondary-piece rotation may optimize portfolio breadth.

Mandatory post-lock head diagnostics:

1. `WINNER_RANK`
2. `TOP5_EX_WINNER_MEDIAN`
3. `TOP10_EX_WINNER_MEDIAN`
4. `TOP1PCT_IN_TOP5`
5. `TOP1PCT_IN_TOP10`
6. `PHASE2_TO_BOARD_ELITE_RECALL`
7. `ORACLE_GAP`

Winner capture alone never marks a board solved. If removing rank 1 causes the head to collapse, the head remains unsolved. `ORACLE_GAP` separates a ranker/order failure from a membership/handoff failure by comparing the displayed championship neighborhood with the best neighborhood available on the frozen upstream surface.

This policy is global. Sport/mode adapters retain their own calibration and structural meaning, but may not override the head-first contract with sport-local diversification logic.
