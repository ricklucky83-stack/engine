# NFL_CLASSIC_GLOBAL_CORE5_TERMINAL_ENFORCEMENT_v1

Status: ACTIVE_VERIFIED_LOCKED_PRODUCTION

## Contract

- NFL Classic sport-native selection retains a 10-line review surface.
- The 10-line review surface is non-terminal and must never be rendered as the playable board.
- Native completion state is `NATIVE_BOARD_READY_FOR_GLOBAL_CORE5`.
- The global production runner is the sole terminal `BOARD_READY` authority.
- `APEX_GLOBAL_CHAMPIONSHIP_CORE_5_v1` compresses the native review surface to exactly five playable lineups when satellites are disabled.
- Satellites are disabled by default.
- Direct native board rendering is prohibited.
- Machine artifact/hash parity is required before user-visible rendering.

## Code

- `engines/nfl/nfl_classic_raw_pool_runtime_v1.py`
- `engines/common/apex_global_production_board_runner_v1.py`

## Production rerun

DK NFL Classic field 5,490: native source board 10 -> Core-5 final playable board 5; satellites off; machine board parity PASS.
