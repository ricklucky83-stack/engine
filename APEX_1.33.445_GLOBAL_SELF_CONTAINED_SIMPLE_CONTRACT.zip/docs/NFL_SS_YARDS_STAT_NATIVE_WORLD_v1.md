# NFL SS YARDS stat-native runtime v1

DraftKings NFL Single Stat Yards uses exactly three athletes and no salary cap. The selectable universe is RB/WR/TE/FB only. Quarterbacks, kickers and defense/special teams are removed before simulation and birth. Passing yards never enter the target statistic.

The scoring authority is rushing plus receiving yards from prelock yard props, with prelock historical rushing/receiving yard columns used only when the corresponding market line is absent. FPTS may inform the separate public-field ownership prior but is never used to score yard worlds.

Phase 1 runs before candidate birth. Candidate identities come only from yard-world optimal/near-optimal triads, recurrent-pair closure, and bounded team/global tail cores. The legal C(N,3) lattice is never enumerated.

The public field is sampled from the mode-specific SS YARDS ownership model. Terminal evidence is field-relative win/tied-first, Top-0.1%, Top-1%, extreme-tail yards, and duplication. The preserved 20-max selector `NFL_SS_YARDS_20MAX_FIELD_RELATIVE_PLUS_DOUBLE_SECONDARY_v2` supplies the bounded 20-entry native portfolio.

The 713 control remains same-slate validation only; it does not satisfy the independent holdout gate.
