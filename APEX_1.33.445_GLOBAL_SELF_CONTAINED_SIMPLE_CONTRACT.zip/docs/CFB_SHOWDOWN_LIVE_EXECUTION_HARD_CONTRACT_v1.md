# CFB Showdown Live Execution Hard Contract v1

This contract simplifies the DraftKings CFB Showdown live path and makes the user's run command a literal execution boundary.

## Live authority

The live entrypoint is `engines/cfb/cfb_showdown_chunk_stream_controller_v1.py`. Critical live parameters, including contest entry limit, must be explicit. Missing or conflicting critical authority fails closed; the controller may not invent a default.

The live phase order is fixed:

`CALIBRATION -> QUALIFIED_BIRTH -> SIMULATION -> SELECTOR -> MAX_ENTRY_PORTFOLIO`

The live generator must report `DETERMINISTIC_CALIBRATION_QUALIFIED_BEAM_BRANCH` and `FULL_LEGAL_UNIVERSE_ENUMERATED=false`. Legacy pre-role-complete simulation/selector lanes and alternate live selector paths are prohibited.

## Board authority

`MAX ENTRY` controls final portfolio membership and size. A 28-max contest produces a 28-lineup portfolio when at least 28 legal selector-reviewed candidates exist.

Core5 is not final-board membership authority. The established championship-head ranker may order up to five lineups only after the max-entry portfolio membership is sealed. It may not add, remove, or replace portfolio members.

## Controller boundary

The controller has no authority to change run semantics. It may persist committed chunks and resume only the exact same run identity. Entry limit is part of checkpoint identity. A checkpoint with a different entry limit, pool, field size, seed, runtime hash, role-authority hash, controller hash, schema, or live-contract identity is not resumable as the requested run.

Chunk-stream durability does not authorize full enumeration, a different phase order, a smaller board, a second selector path, or a Chat-owned fallback.

## Validation

On CFB Showdown contest 195743780, field 941, explicit entry limit 28, the governed candidate replay completed after host-window checkpoint recovery with `RC=0`. It reviewed 38,979 selector candidates and sealed 28 lineups. The exact contest-winning lineup remained in the portfolio at seat 9/28.

The replay receipt records:

- `FULL_LEGAL_UNIVERSE_ENUMERATED=false`
- `CFB_LIVE_LEGACY_SELECTOR_PATH=false`
- `CFB_MAX_ENTRY_CONTROLS_MEMBERSHIP=true`
- `CFB_CORE5_CONTROLS_MEMBERSHIP=false`
- `CFB_CHAMPIONSHIP_HEAD_MEMBERSHIP_MUTATION_ALLOWED=false`

This was a recovered validation run, not a clean uninterrupted execution. Forward production runs remain subject to immediate interruption reporting and fail-closed execution identity.
