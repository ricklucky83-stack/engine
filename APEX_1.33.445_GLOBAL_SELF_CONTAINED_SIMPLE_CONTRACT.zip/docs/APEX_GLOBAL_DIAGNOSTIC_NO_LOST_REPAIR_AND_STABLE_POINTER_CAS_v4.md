# APEX Global Diagnostic No-Lost Repair + Stable Pointer CAS v4

## Purpose
Retain the no-lost-repair diagnostic ledger while replacing pointer-object rotation with a stable-ID compare-and-swap commit primitive.

## Hard invariants
1. Validated repairs remain accounted for through active, superseded, or rejected terminal states.
2. Current active implementation IDs, not historical receipts, define what production contains.
3. The live diagnostic queue is rescanned immediately before global commit.
4. `UNACCOUNTED_VALIDATED_PATCHES=0` and `UNIMPLEMENTED_VALIDATED_PATCHES=0` remain hard gates.
5. Every candidate is a complete immutable bundle derived from a pinned parent state/bundle.
6. Every editing window pins the exact active pointer object ID, pointer epoch, and full pointer-bytes SHA-256.
7. Immediately before commit, the pointer is refetched. Any state, bundle, file-ID, epoch, or bytes drift returns `REBASE_REQUIRED`.
8. `APEX_GLOBAL_STATE_LATEST.txt` is never deleted, retired, renamed, or replaced during commit.
9. The active pointer is updated in place only through atomic compare-and-swap on the pinned parent identity.
10. Pointer and full immutable-bundle readback are required before production status becomes `COMMITTED`.

## Supersession
This v4 doctrine supersedes the pointer-rotation portion of `APEX_GLOBAL_DIAGNOSTIC_NO_LOST_REPAIR_AND_POINTER_EPOCH_FENCE_v3` and `APEX_GLOBAL_POINTER_OBJECT_EPOCH_FENCE_v1`. The v3 diagnostic ledger implementation remains valid and is retained as the queue/receipt engine.
