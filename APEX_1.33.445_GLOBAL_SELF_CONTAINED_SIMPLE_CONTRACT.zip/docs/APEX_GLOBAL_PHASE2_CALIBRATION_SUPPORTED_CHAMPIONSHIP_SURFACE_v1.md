# APEX Global Phase-2 Calibration-Supported Championship Surface v1

## Decision

Phase 2 remains calibration-first, but calibration is a **construction map rather than a guillotine**. Frozen Phase-1 evidence decides where the engine searches hardest and what it preserves. It may not silently erase a structurally distinct championship species that still has credible lineup-level support.

## Global flow

1. Phase 1 freezes player distributions, shared-world outcomes, P95/P99, win/Top-0.1 evidence, correlation, ownership/field context, and sport-specific role state.
2. Phase 2 builds the **calibration-supported championship surface** as the union of:
   - calibrated primary birth;
   - championship-species coverage;
   - cross-world recurrence birth where supported;
   - legal role/slot completion;
   - local core/sibling completion;
   - tail/Pareto rescue.
3. Phase 2 freezes once. Phase 3, handoff, and selector review must preserve the same lineup identities.
4. The global Hybrid AI remains last-step-only and can select only from the frozen surface.

## No-credible-species-collapse gate

A species is not protected merely because it exists legally. It must first show credible frozen lineup-level championship support. Once credible, Phase 2 must retain a calibrated neighborhood and may not reduce the species to zero rows. Resource pressure is handled by streaming/chunking, not silent family deletion.

## MLB Showdown holdout motivation

The 3,208-entry TOR-OAK holdout exposed a Captain-species collapse: the old Captain gate admitted only two starting pitchers despite several hitter-Captain constructions preserving at least 97% of the best legal six-man tail proxy. The generic repair keeps those lineup-tail-supported Captain orientations visible to Phase 2; existing calibrated Phase-2 birth plus legal CPT role completion then restores the championship six-player family without player-name or result targeting.

## Boundaries

- No standings, realized FPTS, post-lock ownership, or winner keys may enter live construction.
- No equal quotas are imposed across species.
- No First-N, projection-only birth, or scalar Top-N cull may replace calibrated family construction.
- AI authority is unchanged: final Hybrid Selector reasoning only.
