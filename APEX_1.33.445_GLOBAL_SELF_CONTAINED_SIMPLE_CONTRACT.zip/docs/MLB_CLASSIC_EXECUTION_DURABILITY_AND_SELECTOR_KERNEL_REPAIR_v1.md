# MLB Classic Execution Durability + Selector Kernel Repair v1

## Scope
This state repairs execution plumbing only. It does not change MLB Classic simulation physics, Phase-1 calibration, candidate legality, Phase-2 scoring objectives, selector objective, ownership authority, lineup membership rules, or final board size.

## Restored lineage
State 1.33.332 previously promoted `MLB_CLASSIC_STAGE0_STATELESS_MICROCHUNK_v1`. State 1.33.349 no longer contained that implementation even though later chunk-stream doctrine remained active. The 1.33.331 -> 1.33.332 code delta was rebased onto the verified 1.33.349 parent with no merge conflicts.

The restored controller uses `mlb_classic_controller.v3`, binds execution ID + runtime SHA + player-pool SHA + frozen Notion-authority SHA, and commits Stage 0 as semantic micro-stages. Base-pattern birth advances only after an fsynced checkpoint, SHA/byte receipt, and atomic controller-state commit.

## Cross-pattern durable cursor
The existing 5-3 -> 5-2-1 cross-pattern source already works in 4,096-parent blocks, but the controller previously wrapped the entire source loop as one stage. A host cutoff after a child block commit could therefore leave a valid checkpoint while the controller cursor still pointed at the previous block.

`MLB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_v3` promotes that existing block boundary into the controller:
- prep;
- one exact 4,096-parent block per durable cursor step;
- finalize.

If the child checkpoint is already present after a host cutoff, the controller verifies nonzero bytes + SHA-256 and advances the cursor without replaying the completed block. Checkpoint hydration explicitly restores `pickle`, which the source imports at process start but checkpoint serialization intentionally excludes as a module object.

## Common-world selector kernel
`MLB_CLASSIC_COMMON_WORLD_NATIVE_POPCOUNT_v1` replaces only the packed-byte popcount implementation. When available, NumPy `bitwise_count` counts bits directly on the existing `uint8` packed event tapes; older NumPy builds fall back to the prior 256-entry lookup table. Both paths return `int64` totals. No candidate is pruned and no selector score/tie-break is changed.

## Fast Path routing
`APEX_FAST_PATH_METHOD_ONLY=1` is a diagnostic/parity switch. It is not the live MLB Classic Fast Path activator. In production, that toggle now fails closed. Live Fast Path continues through the already-authoritative calibration-qualified anti-enumeration path (`MLB_CLASSIC_FAST_PATH_ANTI_ENUMERATION_v1`). This prevents accidental activation of the multi-million-row second-hop materialization branch while preserving the existing quality contract.

## Promotion gates
- Python compile for modified runtime/controller/worker/selector: PASS required.
- Stage-0 regression: PASS required.
- Cross-pattern durable-cursor structural test: PASS required.
- Native/fallback popcount exact parity: PASS required.
- Fast-Path method-only production guard: PASS required.
- Existing MLB Classic resume-integrity tests: no new failure allowed; documented stale-hash fixtures may remain inherited only when reproduced on the untouched parent.
