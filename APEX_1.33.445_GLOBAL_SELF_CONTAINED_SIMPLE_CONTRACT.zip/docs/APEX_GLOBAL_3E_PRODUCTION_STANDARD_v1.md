# APEX Global 3E Production Standard v1

## Objective
APEX production must simultaneously be **Efficient, Effective, and Elite**. A slate is not production-ready when only one or two dimensions pass.

## 1. Efficient
- One external production command. Chat loads/runs the pinned engine; internal stages remain engine-owned.
- Durable, idempotent checkpoint/resume. Same input/run identity resumes from the last committed cursor.
- A single invocation consumes multiple committed internal checkpoints while runtime budget remains.
- Checkpoints contain live state, not arrays already dead at the next stage.
- Chunk size is based on compute/I-O economics; cheap handoff packet loops amortize serialization overhead.
- No restart of completed Phase 0–3 work after recoverable interruption.
- Adaptive MC concentrates extra trials on unresolved boundary candidates rather than uniformly oversimulating obvious rows.

## 2. Effective
- The legal universe, player identity, Phase2 birth, handoff, simulation and selector identities are traceable.
- Generator recall defects are repaired before downstream selector changes.
- A zero stochastic structure lane triggers bounded deterministic legal recovery; it does not kill a non-empty legal slate.
- Stable player identity is PID/team-aware; display-name joins are insufficient.
- Exact/optimizer claims require brute-force or property-test equality on small synthetic controls.
- Joint-event/game-script calibration is the repair owner when individually plausible tails never occur together.

## 3. Elite
- Objective is championship / Top-0.1% path quality, not median projection.
- Cross-world recurrence **breadth** is primary; repeated recurrence concentrated in fewer worlds is secondary.
- Candidate comparison uses common random numbers where feasible and disjoint confirmation worlds before promotion.
- Top-5 is optimized as a championship-union portfolio with controlled script/family diversification.
- Promotion requires held-out/walk-forward/non-regression evidence, not one hindsight winner.

## Research basis
- Temporal durable execution: workflow state is persisted so execution resumes after failures — https://docs.temporal.io/
- Apache Flink checkpointing: recover consistent application state from checkpoints — https://nightlies.apache.org/flink/flink-docs-stable/docs/ops/state/checkpoints/
- AWS Step Functions Standard workflows: persisted state and exactly-once workflow execution — https://docs.aws.amazon.com/step-functions/latest/dg/choosing-workflow-type.html
- Chick & Inoue, Management Science: common random numbers plus second-stage allocation reduce selection error/computation — https://pubsonline.informs.org/doi/10.1287/mnsc.47.8.1133.10229
- dfs-sim-engine: heuristic pruning caused silent optimal-lineup misses; exact optimizers are verified against brute force and held-out tests — https://github.com/justincfung/dfs-sim-engine

## Current code changes
- `MLB_CLASSIC_ENGINE_OWNED_CHUNK_STREAM_RESUME_v2` — controller import closure, adaptive handoff packet chunking.
- `APEX_GLOBAL_3E_PRODUCTION_STANDARD_v1` — production runner internally consumes checkpoint transitions under a soft runtime budget; Chat never selects stages.
- `MLB_CLASSIC_ZERO_LANE_DETERMINISTIC_RECOVERY_v1` — bounded deterministic recovery for stochastic zero lanes; non-empty legal universes continue with telemetry.
- Stage-aware dead-state pruning after adaptive bubble to shrink checkpoint serialization.
- `APEX_GLOBAL_CROSS_WORLD_RECURRENCE_BREADTH_v1` — terminal selector evidence exposes cross-world breadth separately from within-world recurrence density.

## Promotion gate
All of the following must pass: compile/import, deterministic resume continuity, legal-universe preservation, selector-evidence transparency, bundle hash/manifest integrity, unique active pointer. CAR SHOP performance validation remains independent of execution validation.
