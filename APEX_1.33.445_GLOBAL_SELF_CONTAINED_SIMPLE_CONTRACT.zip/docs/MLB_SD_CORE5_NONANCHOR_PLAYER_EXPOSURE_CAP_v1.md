# MLB SD Core-5 Nonanchor Player Exposure Cap v1

Purpose: enforce the standing Top-5 portfolio rule that five near-duplicate lineups cannot all depend on one non-Captain player when a high-confidence alternative preserves meaningful cross-world championship support.

- Captain superanchors may remain 5/5 when supported.
- Any non-Captain player is capped at Core-5 minus one seat.
- Replacement candidates must clear a distinct-world support floor equal to 20% of the active maximum event count.
- Replacement ranking is marginal championship-world gain first, then total distinct-world recurrence, then frozen prelock quality.
- No realized score, postlock identity target, or player-name constant is allowed.
