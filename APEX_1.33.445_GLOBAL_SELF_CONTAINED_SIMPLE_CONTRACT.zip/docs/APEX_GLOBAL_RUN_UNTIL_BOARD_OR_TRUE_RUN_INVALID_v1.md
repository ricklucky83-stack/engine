# APEX_GLOBAL_RUN_UNTIL_BOARD_OR_TRUE_RUN_INVALID_v1

Status: ACTIVE_LOCKED_HARD_GATE

## Purpose

A live DFS execution does not terminate merely because an engine process exits, a tool window expires, a transport call fails, a board artifact is temporarily missing, or a continuation step is required. The terminal contract is now binary: produce and render the sealed machine final board, or prove a true `RUN_INVALID` impossibility.

## Terminal rule

`RUN UNTIL BOARD OR TRUE RUN_INVALID.`

The only user-visible terminal payloads during live production are:

1. The sealed final board.
2. `RUN_INVALID` backed by a proven hard impossibility.

Intermediate execution states are continuation signals, not completion states.

## True RUN_INVALID boundary

A run may terminate as `RUN_INVALID` only when the active execution proves one of these components is unavailable or invalid:

- current player pool is missing or structurally invalid;
- executable production engine source is unavailable;
- a required runtime dependency is missing;
- encoded bundle, decoded bundle, or internal manifest integrity fails;
- the legal lineup universe is empty;
- valid simulation capability is unavailable.

A nonzero child return code is not sufficient evidence by itself.

## Mandatory recovery order

1. Check for a verified completed exact-slate board/receipt pair.
2. If found, render it immediately.
3. If no board exists, classify the failure against the true-impossibility boundary.
4. If the failure is recoverable, resume or retry the same slate automatically.
5. Repeat until the final board is sealed or a true `RUN_INVALID` condition is proven.

## Explicitly nonterminal conditions

The following must not stop a live run:

- tool/runtime execution-window expiration;
- transient connector or transport error;
- child process nonzero exit without a proven hard-invalid component;
- stale or temporarily missing board file;
- recoverable external-data gap;
- checkpoint/resume requirement;
- `AI_TERMINAL_DECISION_REQUIRED` or other internal continuation state.

## User-command behavior

No permission is requested to resume a recoverable run. No mock, filler, random, relaxed, or undocumented board may be substituted. `SHOW BOARD` renders the completed legal board immediately when available.

## Implementation

The global command barrier and execution router mark intermediate failures as nonterminal. `apex_fast_path_execution_contract_v1.py` owns strict terminal classification. `apex_global_production_board_runner_v1.py` now performs completed-board recovery, true-invalid classification, and automatic same-slate retry instead of converting a missing board/nonzero child exit directly into `RUN_INVALID`.
