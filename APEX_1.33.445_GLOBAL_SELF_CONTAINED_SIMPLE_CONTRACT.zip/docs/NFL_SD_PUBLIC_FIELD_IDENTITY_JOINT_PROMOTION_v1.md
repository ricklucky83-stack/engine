# NFL Showdown Public Field Identity-Joint Promotion v1

State target: v1.33.338.

This repair separates historical public-field evidence into independent ownership, identity-structural, and salary-structural certification levels. A DraftKings-listed player may be absent from the projection provider export while still being present in the actual contest pool. When official roster evidence resolves that player's team and position, an explicit identity-only supplement may complete team/position field geometry. It may not invent or backfill salary.

Three distinct September 13 games now pass identity-structural certification: ATL-PIT (195384249), CAR-CHI (195384277), and DET-NO (195384221). ATL-PIT and CAR-CHI also pass exact salary certification. DET-NO remains salary-partial because Charlie Smyth, Cedric Tillman, Zamir White, and Luke Altmyer are present in the DraftKings field but absent from the frozen projection export and their exact Showdown salaries were not recovered.

Production public-field generation therefore activates maximum-entropy/IPF calibration for non-salary structure only: team split, Captain-side split, Captain role, favorite-side geometry, position counts, QB/pass-catcher pairs, RB-DST and K-DST pairs. Salary-left constraints remain disabled until a third salary-complete distinct game exists.

If a current legal candidate universe cannot support the installed historical structural targets, the IPF layer fails closed to the prior marginal-product field distribution rather than changing targets or crashing a live run. Same-contest and same-underlying-game postlock evidence remains prohibited from forward training.
