# APEX Global Authorized Env Master Dispatch Routing v1

Repairs the production bootstrap -> global runner -> authorized sport master boundary.

- Bootstrap exports `APEX_SPORT`, `APEX_SPORT_MODE`, `APEX_MODE`, board size, and prebuild availability receipt.
- The global production runner reasserts sport/mode after governance and ownership derivation.
- The MLB master dispatcher accepts env-driven production invocation only when launched as the authorized master entrypoint.
- `APEX_PLAYER_POOL` remains the governed/ownership-derived runtime pool.
- `APEX_ORIGINAL_PLAYER_POOL` remains the availability/hash authority.
- Direct Chat invocation of raw sport runtimes remains prohibited.
- Exit-code-2 retries caused by missing argparse subcommands are eliminated at the master boundary.

This is an execution/control-plane repair only; no simulation, generation, calibration, selector, or portfolio objective is modified.
