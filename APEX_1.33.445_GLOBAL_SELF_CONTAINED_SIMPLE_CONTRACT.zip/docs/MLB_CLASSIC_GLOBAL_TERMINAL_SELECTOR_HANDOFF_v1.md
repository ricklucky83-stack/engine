# MLB Classic Global Terminal Selector Handoff v1

The MLB Classic resumable controller owns computation through the complete selector-reviewed surface. The raw worker legacy `BOARD_READY` message remains internal. The controller emits `NATIVE_BOARD_READY_FOR_GLOBAL_CORE5`, with all selector-reviewed lineups frozen for the Hybrid AI selector. Chat participation is selector-only. The global production runner validates the five selected existing lineups and seals the terminal playable Core-5.

No sport simulation, generation, calibration, or native comparator logic changes.
