# APEX Global Terminal Surface Streaming Freeze and Linear Family Index v1

## Failure owner
`EXECUTION / TERMINAL_HANDOFF`

## Reproduced failure
The DK MLB Showdown 4705 run completed the expensive generation/simulation work and emitted a full terminal candidate surface of 120,685 lineups (324,985,226 bytes), then exceeded the 4 GiB execution envelope while the terminal layer repeatedly materialized and copied the same CSV into Python object graphs. A second latent scalability defect was the fixed-roster one-swap family graph's quadratic pairwise comparison path.

## Production repair
`APEX_GLOBAL_TERMINAL_SURFACE_STREAMING_FREEZE_AND_LINEAR_FAMILY_INDEX_v1`

The repair preserves the full candidate handoff and selector objective while changing execution mechanics only:

- stream candidate CSV validation and file hashing;
- compute the legacy lexical candidate freeze with a disk-backed SQLite sort/index;
- load only compact selector columns for terminal selection;
- build fixed-roster one-swap connected components with leave-one-out signatures and union-find rather than O(N^2) pairwise comparisons;
- hydrate only the final selected rows from the full terminal surface;
- commit the frozen terminal selector surface through the durable terminal path;
- if a valid Hybrid AI decision already exists, validate it and seal Core-5; otherwise expose the frozen surface at the last-step Hybrid Selector boundary without replaying the sport engine.

## Invariants
- model logic changed: NO;
- generator membership changed: NO;
- selector objective changed: NO;
- candidate pruning: 0;
- Top-N sieve: prohibited;
- terminal execution may pause only at the explicit last-step `HYBRID_SELECTOR_HANDOFF_REQUIRED` boundary when no valid Hybrid AI decision exists;
- after a valid decision exists, terminal return is `BOARD_READY` or true `RUN_INVALID`.

## Validation evidence
The state-1.33.190 validation receipt records:

- 120,685 full-handoff candidates;
- exact freeze semantic parity: PASS;
- fixed-roster family-component parity: PASS;
- machine board parity: PASS;
- final board size: 5;
- durable terminal peak RSS approximately 383,284 KiB, below the 4 GiB cgroup envelope.

Validation receipt: `receipts/global_terminal_surface_streaming_freeze_v1/validation_receipt_120685.json`.

## Persistence rule
This repair is a locked global execution patch. It must remain listed in `GLOBAL_PATCHES`, retain its doctrine and validation receipt, and keep the dedicated regression test green in every descendant global state. Sport-model retuning is not part of this repair.


## Descendant authority clarification — Hybrid Selector last-step fence
`APEX_GLOBAL_HYBRID_SELECTOR_LAST_STEP_EXECUTION_FENCE_v1` supersedes only the selector-authority wording above. The streaming/freeze/memory and no-replay mechanics remain locked. A committed terminal surface is a successful engine checkpoint; it is not permission for the engine or Chat to invent a proxy selector decision. Plugins remain allowed as support and have no execution authority.
