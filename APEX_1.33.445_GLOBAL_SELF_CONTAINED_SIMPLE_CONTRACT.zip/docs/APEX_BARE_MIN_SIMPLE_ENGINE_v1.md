# APEX BARE MIN SIMPLE ENGINE v1

`BARE MIN` is an explicit alternate execution profile. It does **not** replace, modify, simplify, or supersede the regular production engine.

## Routing
- Default: regular production engine, unchanged.
- Explicit `BARE MIN`: route to the separate simple runtime for that sport/mode.
- If a sport/mode has no BARE MIN runtime, fail closed with `RUN_INVALID:BARE_MIN_NOT_IMPLEMENTED_FOR_ROUTE`.

## BARE MIN responsibilities
1. Load the submitted player pool.
2. Build a compact legal candidate surface.
3. Run Monte Carlo.
4. Rank championship outcomes.
5. Return top championship clusters.
6. Build local closure only around those clusters.
7. Render the board first, then clusters/closure/run metrics.

## BARE MIN exclusions
No full legal-universe scan, no global Phase 2 closure tree, no historical back-optimization, no diagnostic/audit stack, no AI runtime improvisation, and no mutation of the regular engine.

## Tennis Classic v1
`engines/tennis/tennis_classic_bare_min_runtime_v1.py`

The Tennis BARE MIN runtime uses a compact salary-legal candidate set, one coherent MC outcome matrix, recurring four-player championship cores for cluster discovery, and one-swap local closure around the highest-mass clusters.

The regular Tennis Classic runtime remains:
`engines/tennis/tennis_classic_raw_pool_runtime_v2.py`


## Tennis Classic legality correction — cap-only
- DraftKings Tennis Classic BARE MIN has **no fixed minimum-spend gate**.
- Legal salary condition: positive roster salary `<= $50,000`.
- `SALARY_MIN=0` is a compatibility sentinel, not a strategy threshold.
- Salary geometry may affect ranking, but it may not delete an otherwise cap-legal lineup.
- Same-match coexistence is not a hard BARE MIN legality ban.
- `FAST PATH` without the exact phrase `BARE MIN` continues to route to the regular Tennis Classic v2 production engine.
