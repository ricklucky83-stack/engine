# APEX WNBA Showdown — Anchor + Runback + Counter-Script Core-5 v1

## Objective

**WINNER_CAPTURE_OR_FAIL.** The playable WNBA Showdown board is five entries. The selector is not allowed to fill extra seats merely for generic diversification.

## Production Core-5 contract

The board is selected in this order and then frozen:

1. **HIGH_CONFIDENCE_CORE** — three seats. Press the strongest championship family/sibling neighborhood when multiple constructions spike in the same winning worlds. Correlated siblings are allowed because repeated exposure to a high-confidence championship state is intentional.
2. **RUNBACK** — one seat. Keep the high-confidence anchor spine live while rotating to an opponent response that extends the same high-scoring game environment. This is positive game-environment correlation, not generic opponent exposure.
3. **COUNTER_SCRIPT** — one seat. Keep anchor conviction while shifting closure/usage toward the opponent so the board survives a materially different script when the dominant root closure fails. This is negative correlation to the dominant closure, not random diversification.

Exact lane contract: `HIGH_CONFIDENCE_CORE, HIGH_CONFIDENCE_CORE, HIGH_CONFIDENCE_CORE, RUNBACK, COUNTER_SCRIPT`.

## Correlation doctrine

Correlation is concentrated **inside** a ticket when players can spike together. Across the five-ticket board, correlation is diversified by outcome path rather than by arbitrary player overlap. **Generic diversity is not rewarded.** The selector therefore prefers:

- repeated high-confidence family exposure when championship worlds overlap for good reason;
- an opponent runback response that keeps the primary game environment alive;
- a counter-script that removes dependence on the dominant closure while retaining legitimate Rank-1 ceiling.

Direct same-role cannibalization remains a structural negative. In the current WNBA Showdown implementation, same-team double-center packages are rejected because center minutes are the strongest direct substitution channel.

## Governance

- Prelock simulation and sport-native family authority only.
- No player-name or team-name hardcodes.
- No realized contest points, contest rank, or winner identity in forward selection.
- Phase 2 generation is unchanged.
- Captain exposure maximum remains 3 across Core-5.
- Satellites remain OFF by default.
- If a valid RUNBACK or COUNTER_SCRIPT lane is unavailable, preserve source-selector authority rather than manufacture a low-confidence hedge.

## Validation checkpoint

The validated production checkpoint remains unchanged by this documentation/code synchronization:

- Target 470: contest-equivalent ranks `1, 27, 4, 26, 21`; winner captured; Top-10% = 5/5; captain max = 3.
- Control 627: exact historical winner retained at Core slot 1; captain max = 2.

State 1.33.74 changes contract visibility and documentation only; selection behavior is required to remain byte-for-byte equivalent at the validated board-output level.
