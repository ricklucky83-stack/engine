# APEX_GLOBAL_FAST_PATH_BOARD_READY_IMMEDIATE_RENDER_v1

When FAST PATH has a legal selector-complete board at or above the requested entry count, execution reaches a hard terminal fence.

Required behavior:
- stop research, diagnostics, patch investigation, and auxiliary analysis;
- render the completed board in chat immediately;
- render vertically;
- treat file links as secondary;
- print `[EXECUTION_COMPLETE]` after the board.

Further diagnostics or repair may occur only after board rendering and only when explicitly requested.
