# APEX Global Contest Order Intelligence v1

## Purpose

Every supported sport and contest mode must pass its frozen selector-reviewed lineup surface through a common terminal **order-intelligence framework**. The framework ranks existing lineups; it never creates, deletes, legalizes, or selects lineup membership.

`SELECT_SCORE` remains membership authority. `GLOBAL_ORDER_SCORE` / `GLOBAL_ORDER_RANK` are terminal ordering evidence only. Portfolio diversification remains downstream.

## Architecture

The production architecture is **global framework + sport×mode adapters**. It is explicitly *not* one universal cross-sport learned model. A prior APEX universal cross-sport LambdaMART experiment regressed aggregate ranking quality and improved only 1/5 heterogeneous holdouts; sport-specific structural meaning must therefore stay in adapters.

The global layer standardizes and combines within-slate evidence for:

- probability of being best / championship probability;
- extreme-tail support;
- rank uncertainty and stability;
- recurrence across independent worlds;
- projected duplication;
- sport-native structural evidence supplied by the adapter.

Sport×mode adapters own domain structure such as NFL game-script/role families, MLB stack/branch geometry, CFB script/role concentration, Tennis match-correlation structure, PGA scoring regime, and similar context-specific signals. Learned coefficients, when used, are trained only on chronological query groups for the same sport×mode and require independent holdout non-regression before live authority.

## Research basis

- Kim, Kim & Song, *Selection of the Most Probable Best*, Operations Research: rank by probability of being optimal under input uncertainty and allocate simulation adaptively to distinguish contenders.
- 2026 repeated-trial ranking research: ranking stability and uncertainty matter when scores arise from stochastic repeated trials; point-estimate ranks alone are insufficient.
- Conformal/full-ranking research: expose uncertainty in predicted absolute ranks rather than pretending every close ordering is certain.
- Haugh & Singal DFS research: opponent behavior and top-heavy contest reward structure must be modeled; multi-entry portfolio construction is a distinct downstream optimization problem.
- APEX internal evidence: universal cross-sport LTR failed, while CFB/MLB sport-specific mechanisms produced useful ordering improvements.

## Hard boundaries

- `MEMBERSHIP_MUTATION_ALLOWED = FALSE`
- `UNIVERSAL_CROSS_SPORT_MODEL_ALLOWED = FALSE`
- `POSTLOCK_FORWARD_INPUT = FALSE`
- `PORTFOLIO_DIVERSIFICATION = DOWNSTREAM_ONLY`
- live execution remains direct player-file-first; this patch adds no bootstrap, pointer, hash, or manifest gate.

## NFL Showdown same-slate diagnostic

On the NE@SEA 95,124-entry control, the legacy NFL terminal order placed the exact winner at approximately `11,612 / 20,000`. Under the global framework plus the already-certified NFL low-total defensive balanced sport adapter, the winner moved to `GLOBAL_ORDER_RANK = 2` before postlock grading. Candidate membership remained unchanged. This is diagnostic evidence for the architecture, not historical training credit.
