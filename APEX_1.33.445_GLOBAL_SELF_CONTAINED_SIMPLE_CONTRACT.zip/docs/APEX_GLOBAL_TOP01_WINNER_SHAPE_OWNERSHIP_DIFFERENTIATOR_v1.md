# APEX Global Top-0.1 Winner-Shape Ownership Differentiator v1

**Patch:** `APEX_GLOBAL_TOP01_WINNER_SHAPE_OWNERSHIP_DIFFERENTIATOR_v1`  
**State target:** `1.33.132`

## Objective

The terminal selector targets **contest Rank 1 / Top 0.1%**, not similarity to the median field. For MLB Classic and MLB Showdown, terminal selection must recognize the ownership and salary geometry repeatedly observed in actual winner/perfect calibrations:

- a justified chalk/core spine may remain;
- at least one low-owned player or small correlated cluster must have a credible slate-breaking ceiling before it receives leverage credit;
- salary relief is valuable only when the ceiling retained by the differentiator materially improves the complete lineup;
- low-owned, low-ceiling dust receives no leverage credit;
- field conformity is not a selection objective.

## Terminal authority order

For MLB Classic and MLB Showdown, terminal evidence is ordered:

1. `WINNER_SHAPE`
2. `OWNERSHIP_SHAPE`
3. `CEILING_TO_OWNERSHIP_DIFFERENTIATOR`
4. `VALUE_TO_CEILING_UNLOCK`
5. `JUSTIFIED_CHALK`
6. sport-native structure / correlation / game script
7. duplication and portfolio redundancy
8. MC evidence as diagnostic support / tiebreak only

`MC_TOP_0_1_RATE`, `MC_WIN_RATE`, `P99`, `CVAR99`, and related MC fields remain in the candidate ledger for uncertainty and diagnostics. They do **not** define MLB terminal championship quality.

## Ownership rule

Ownership is the field's market price, not an automatic fade signal. The selector distinguishes:

- **justified chalk** — high ownership with enough ceiling/role support;
- **underowned ceiling** — low ownership with enough slate-breaking ceiling to matter;
- **productive unlock** — a ceiling-qualified low/mid-owned player whose salary relief improves the rest of the roster;
- **low-owned dust** — low ownership without sufficient ceiling; never promoted just for being contrarian.

Projected roster ownership (`RST%`) must not be mislabeled as actual CPT ownership. Showdown surfaces therefore expose `CPT_ROSTER_OWNERSHIP_PCT` separately from any true CPT-ownership source.

## Winner-shape fields

The terminal review surface derives:

- `AI_WINNER_SHAPE_SCORE`
- `AI_WINNER_SHAPE_PCTL`
- `AI_WINNER_SHAPE_BUCKET`
- `AI_OWNERSHIP_SHAPE_SCORE`
- `AI_PRIMARY_DIFFERENTIATOR_PLAYER`
- `AI_PRIMARY_DIFFERENTIATOR_SCORE`
- `AI_LOW_OWNED_CEILING_COUNT`
- `AI_LOW_OWNED_DUST_COUNT`
- `AI_CHALK_SPINE_COUNT`
- `AI_JUSTIFIED_CHALK_COUNT`
- `AI_VALUE_TO_CEILING_UNLOCK_SCORE`
- `AI_CREDIBLE_STRUCTURAL_SEPARATION`
- `AI_MC_ROLE=DIAGNOSTIC_SUPPORT_TIEBREAK_ONLY`
- `AI_MC_TERMINAL_AUTHORITY=false`

## MLB Classic

Classic candidate manifests now carry the ten rostered players' pre-lock roster ownership percentiles, Phase-1 player ceiling percentiles, salary-unlock flags, and strategic leverage. This allows the terminal selector to distinguish a chalk spine plus a low-owned ceiling mini/one-off from an all-chalk field-conforming roster.

The historical 17,835-entry calibration remains a structural control: the winning roster used a 3-3-1-1 shape with mid/low-owned eruption clusters while retaining a materially owned pitcher. The transferable rule is the **shape**, not the player identities or realized outcome.

## MLB Showdown

Showdown candidate surfaces now carry the six players' pre-lock roster ownership percentiles, Phase-1 ceiling percentiles, salary-unlock flags, and strategic leverage. CPT roster ownership is labeled as roster ownership unless a true CPT-ownership source exists.

The championship-neighborhood score no longer uses MC Top-0.1 / WIN / P99 as its primary ingredients. It uses winner shape, ownership shape, differentiator quality, value-to-ceiling unlock, conditional support, low-duplication evidence, and market/script context.

## Top-5 portfolio gate

When the full MLB handoff contains credible structural-separation candidates, the final five may not collapse into a field-conforming all-chalk monoculture. At least three structurally separated seats are required when at least three are available. This is not a low-ownership quota; justified chalk remains valid and may anchor the portfolio.

## Firewall

- pre-lock inputs only;
- no contest rank, realized FPTS, winner identity, or post-lock ownership in forward selection;
- no player-name constants;
- no lineup creation or mutation;
- full selector-reviewed handoff remains required.
