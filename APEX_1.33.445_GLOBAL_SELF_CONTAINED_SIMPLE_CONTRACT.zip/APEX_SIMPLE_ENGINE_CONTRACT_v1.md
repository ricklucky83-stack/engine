# APEX 1.33.445 — Global Exact Same-World .00001 Contract

Scope: **all sports, all sites, all slate types, all production runners**.

## Locked route

```text
200K MC FIRST
→ identify championship worlds / cores / lanes from the complete legal discovery surface

RUBIK + EXHAUSTIVE
→ exhaust every legal closure around every discovered championship core/lane
→ complete legal lineups only
→ no arbitrary family quota
→ no branch quota
→ no top-K closure cap
→ no performance-based pruning before exact scoring
→ exact duplicate removal only

EXACT COMMON-WORLD SCORING
→ score every complete legal build in the exhausted championship neighborhood
→ compare against the complete legal surface in the same frozen world

HARD .00001 GATE
→ TARGET_RANK = max(1, ceil(FIELD_SIZE × 0.00001))
→ if a lineup reaches TARGET_RANK or better in at least one of the 200,000 frozen worlds: KEEP
→ otherwise: DISCARD
→ recurrence does not control membership

SAME-WORLD DOMINANCE
→ occurs only after .00001 admission
→ remove a survivor only when another survivor is no worse in every common world
  and strictly better in at least one common world
→ explicit numerical tolerance = 1e-6

ORDINAL
→ compute the complete evidence stack for every remaining survivor
→ rank all remaining survivors
→ preserve genuine evidence ties
→ never decide membership
→ never delete survivors
→ never impose a board size
→ never backfill
→ never apply exposure selection

FINAL PORTFOLIO
= ALL LEGITIMATE NON-DOMINATED .00001 SURVIVORS IN ORDINAL RANK ORDER
```

## Discovery rule

No restrictive scout pool may own championship discovery. NFL/CFB discovery may not use CPT/FLEX top-player limits, bounded position additions, bounded team additions, family caps, branch caps, or top-K closure caps. Uncapped closure cannot recover a core that discovery never admitted, so championship discovery scans the complete legal surface under the sport adapter.

## Sport-adapter boundary

Sport adapters supply only:

- sport-native 200K simulation logic
- exact roster legality
- exact lineup scoring
- roster rendering / identity

The global contract owns discovery membership, exhaustive closure, exact same-world .00001 admission, dominance, ordinal evidence, and final rank-only ordering. No production route may silently fall back to an older selector pipeline. A route without a certified global-simple-contract adapter must fail closed.

## Replacement pressure

For player `p` and frozen world `w`:

```text
REPLACEMENT_PRESSURE(p, w)
= WINNER_SCORE(w)
  − BEST_COMPLETE_LEGAL_SCORE(w | p excluded)
```

The alternative search is the complete legal surface. All necessary roster and captain rotations are allowed. It is not a single-slot swap.

Lineup replacement-pressure summaries are explicitly documented as mean / median / P90 over the preserved player × world component values for the players in that lineup. Component-level evidence is retained so the summaries can be reproduced.

## CPT role pressure

For CPT player `p` and frozen world `w`:

```text
CPT_ROLE_PRESSURE(p, w)
= WINNER_SCORE(w)
  − BEST_COMPLETE_LEGAL_SCORE(w | p forbidden at CPT, p permitted at FLEX)
```

The alternative search is the complete legal surface and may rotate all supporting roster slots.

## Distinct-world component evidence

`PAIR_#1_COUNT`, `TRIO_#1_COUNT`, and `CORE_#1_COUNT` are built from component-level distinct qualifying-world support. Each component counts a frozen world at most once even if many overlapping closures support it.

The board preserves the component records used to reproduce the lineup aggregates.

## Conditional lift

For component `C`:

```text
BASELINE_SUCCESS_PROBABILITY
= total qualifying lineup-world events
  / total eligible championship-neighborhood lineup-world opportunities

P(success | C)
= qualifying lineup-world events containing C
  / eligible legal lineup-world opportunities containing C

CONDITIONAL_LIFT(C)
= P(success | C) / BASELINE_SUCCESS_PROBABILITY
```

The lineup-level `CONDITIONAL_LIFT` is the documented arithmetic mean of its explicit championship-core component lifts. Component values are preserved.

## Opportunity-normalized recurrence

For component `C`:

```text
OPPORTUNITY_NORMALIZED_RECURRENCE(C)
= distinct qualifying worlds supporting C
  / explicit eligible worlds for C
```

Eligibility is measured directly from legal closure availability. It is not the number of overlapping discovered subsets. The lineup-level value is the documented arithmetic mean of its explicit championship-core component values.

## Required ordinal evidence

```text
#1_COUNT
#1_RATE_EXACT
CPT_#1_COUNT
CPT_#1_RATE_EXACT

REPLACEMENT_PRESSURE_MEAN
REPLACEMENT_PRESSURE_MEDIAN
REPLACEMENT_PRESSURE_P90
CPT_ROLE_PRESSURE

PAIR_#1_COUNT
TRIO_#1_COUNT
CORE_#1_COUNT

DISTINCT_WORLD_SUPPORT
CONDITIONAL_LIFT
OPPORTUNITY_NORMALIZED_RECURRENCE

TOP3_COUNT
TOP10_COUNT
```

All requested evidence signals participate in the documented lexicographic ordinal order. Ordinal is **rank-only** and preserves membership before and after ranking.

## Implemented global-simple-contract adapters in this ZIP

- NFL Showdown / SD / Captain
- CFB Showdown / SI / single-game alias
- CFB Classic

Any route without a certified global-simple-contract adapter fails closed rather than silently entering an older selection pipeline.
