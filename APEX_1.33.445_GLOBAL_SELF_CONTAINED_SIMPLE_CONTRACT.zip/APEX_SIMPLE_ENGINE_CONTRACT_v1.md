# APEX State 1.33.445 — GLOBAL CPT LANE COVERAGE GUARD + FULL FAMILY CLOSURE + ORDINAL CHECKOFF

## Status

This file updates `1.33.444_GLOBAL_FULL_FAMILY_CLOSURE_GUARD` with a global CPT-lane coverage blocker before full-family closure.
The rule applies to every sport, site, slate type, and runner.

A heat-seeker surface can discover a championship family.
It cannot finalize that family.

## Locked Global Route

```text
LOAD CURRENT NOTION AUTHORITY
-> ENGINE READBACK / HASH RECEIPT
-> CONFIGURED MC COUNT RECEIPT
-> EXACT WORLD LEDGER RECEIPT
-> 0. MC FIRST
-> 1. CHAMPIONSHIP FAMILY DISCOVERY / RUBIK'S-CUBE HEAT SEEKER
-> 2. CPT LANE COVERAGE GUARD
-> 3. STACK SHAPE COVERAGE GUARD
-> 4. PUNT-FILLER BRANCH GUARD
-> 5. FULL FAMILY CLOSURE
-> 6. FAMILY CLOSURE RECEIPT
-> 7. EXACT COMMON-WORLD SCORING
-> 8. .00001 HARD GATE
-> 9. SAME-WORLD DOMINANCE PRUNING
-> 10. NFL ORDINAL / GLOBAL ORDINAL POSTERIOR SCORE
-> 11. ORDINAL ORDERING CHECKOFF
-> FINAL PORTFOLIO = NON-DOMINATED SURVIVOR SET
```


## Global CPT-Lane Coverage Law

```text
CPT_LANE_COVERAGE_COMPLETE is mandatory before FULL_FAMILY_CLOSURE.
```

The family-discovery phase must emit a CPT lane coverage ledger before closure.

```text
CPT_LANE_COVERAGE_LEDGER_PRESENT == true
mandatory_cpt_lanes > 0
covered_cpt_lanes == mandatory_cpt_lanes
missing_cpt_lanes == []
STACK_SHAPE_COVERAGE_COMPLETE == true
PUNT_FILLER_BRANCH_COVERAGE_COMPLETE == true
```

If a slate has a high-salary, high-projection, high-ownership, or role-anchor CPT/captain lane, that lane must be represented in the discovered family surface before closure.
For MLB Showdown, this blocks the exact Michael King-type miss: hitter CPT tails may rank higher, but an anchor pitcher CPT lane cannot be absent from closure.

If any required lane or filler branch is missing:

```text
STATUS = CHECKPOINTED / RESUME_REQUIRED
FINAL_BOARD_ALLOWED = false
BLOCKING_REASON = CPT_LANE_COVERAGE_INCOMPLETE
NO FINAL BOARD
```

## Global Family-Closure Law

```text
FULL_FAMILY_CLOSURE_COMPLETE is mandatory before .00001 gate, dominance pruning, ordinal ordering, or final board.
```

For every MC-discovered championship family:

```text
legal_branch_count == born_branch_count == scored_branch_count
closure_complete == true
```

If any family fails that equality:

```text
STATUS = CHECKPOINTED / RESUME_REQUIRED
FINAL_BOARD_ALLOWED = false
NO FINAL BOARD
```

## Required Family Closure Ledger

Every run must emit a CPT lane coverage ledger and a family closure ledger.

Required CPT lane coverage ledger fields:

```text
lane_id
cpt_lane
required
coverage_complete
lane_present
family_discovered
stack_shape_coverage_complete
punt_filler_branch_coverage_complete
missing_reason
```

Every run must emit a family closure ledger with one row per championship family:

```text
family_id
family_signature
sport
site
slate_type
required_core
cpt_lane
team_shape
salary_min
salary_max
legal_branch_count
born_branch_count
scored_branch_count
closure_complete
```

The global runner must prove:

```text
family_closure_ledger_present == true
family_closure_complete == true
family_closure_family_count > 0
family_closure_legal_branches > 0
family_closure_legal_branches == family_closure_born_branches
family_closure_legal_branches == family_closure_scored_branches
```

## Forbidden Final-Board Substitutions

The following cannot produce a final board:

```text
sampled heat-seeker surface
one-build-per-world birth
first-legal-completion early stop
missing required CPT lane
missing stack-shape coverage
missing punt-filler branch
partial family closure
candidate cap per captain
candidate cap per family
pool shrink
broad legal shuffle birth
proxy-only final board
partial rerank as final
terminal substitution
manual AI rerank
threshold lowering
backfill
forced board size
contest max-entry fill
```

## Ordinal Ordering Check-Off

Ordinal ordering is an explicit final gate.

```text
ORDINAL_SELECTOR = GLOBAL_ORDINAL_POSTERIOR_SCORE
ORDINAL_ORDERING_COMPLETE = true
ORDINAL_CHECKOFF_COMPLETE = true
```

The final board cannot print unless:

```text
len(ordinal_board) == non_dominated_survivors
ordinal_ordering_complete == true
ordinal_checkoff_complete == true
```

No AI rerank.
No leverage override.
No sport-specific terminal selector.
No raw recurrence terminal order.

## Fixed-MC Receipts Remain Mandatory

```text
NOTION_LOADED
ENGINE_READBACK_PRESENT
CONFIGURED_MC_COUNT_RECEIPT_PRESENT
EXACT_WORLD_LEDGER_PRESENT
MC_COUNT_EQUALS_WORLD_LEDGER_COUNT
MC_FIRST_COMPLETE
LOCAL_PARAMETER_OPTIMIZATION_USED == false
LIVE_MC_COUNT_CHANGE_USED == false
```

## Small Survivor Surface Doctrine Remains Active

The final portfolio equals the legitimate non-dominated survivor set.

```text
If only 3 survive, play 3.
If only 8 survive, play 8.
If only 18 survive, play 18.
If only 25 survive, play 25.
```

No forced board size.
No backfill.
No filler.
No 150-entry noise spray.

## Tie Handling Remains Deterministic

Do not add simulations to break ties.

```text
1. #1 / PERFECT RAW COUNT
2. REPLACEMENT PRESSURE
3. CPT / ROLE PRESSURE
4. PAIR / TRIO / CORE #1 COOCCURRENCE
5. DISTINCT-WORLD SUPPORT
6. CONDITIONAL LIFT
7. TOP-3 / TOP-10 ROBUSTNESS
8. TRUE_CORE_TIE if still identical
```

If two pieces remain identical after all deterministic separators:

```text
TRUE_CORE_TIE
KEEP THE TIE
DO NOT MANUFACTURE SEPARATION
```

## Checkpoint Rule

If any required phase cannot complete in the current tool window:

```text
WRITE CHECKPOINT
REPORT EXACT STOPPING POINT
STATUS = CHECKPOINTED / RESUME_REQUIRED
FINAL_BOARD_ALLOWED = false
NO FINAL BOARD
```

Next execution resumes from the checkpoint. It must not restart with a smaller surface, modified MC count, sampled proxy surface, or modified contract.
