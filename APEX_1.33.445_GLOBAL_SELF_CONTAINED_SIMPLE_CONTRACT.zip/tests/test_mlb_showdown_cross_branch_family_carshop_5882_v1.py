from pathlib import Path
import importlib.util, sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
MLB=ROOT/'engines'/'mlb'
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
if str(MLB) not in sys.path: sys.path.insert(0,str(MLB))


def _engine():
    p=MLB/'mlb_showdown_raw_pool_runtime_v1_7.py'
    spec=importlib.util.spec_from_file_location('mlb_sd_cross_branch_carshop_test',p)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


def test_runtime_wires_cross_branch_birth_deep_sim_and_core5_sentinel():
    text=(MLB/'mlb_showdown_raw_pool_runtime_v1_7.py').read_text()
    assert "MLB_SD_CROSS_BRANCH_FIVE_PLAYER_CHAMPIONSHIP_FAMILY_CLOSURE_v1" in text
    assert "CROSS_BRANCH_FIVE_PLAYER_CHAMPIONSHIP_FAMILY_CLOSURE" in text
    assert "CROSS_BRANCH_FAMILY_DEEP_SIM_LINEUPS" in text
    assert "MLB_SD_CROSS_BRANCH_SUPERANCHOR_LOW_OWN_FAMILY_CORE5_SENTINEL_v1" in text


def test_superanchor_low_owned_family_champion_is_identity_free_and_win_primary():
    m=_engine()
    # Three legal siblings share core 0..4. Player 0 is the one >=50% superanchor;
    # the remaining four core pieces are all <10%. Candidate 2 has best MC win.
    meta={
        'idx':np.asarray([[0,1,2,3,4,5],[0,1,2,3,4,6],[0,1,2,3,4,7]],np.int32),
        'own':np.asarray([70.,8.,7.,6.,5.,20.,18.,15.],float),
        'lane_cross_branch_five_player_championship_family':np.ones(3,bool),
    }
    cm={'win':np.asarray([.001,.002,.004]),'top01':np.asarray([.010,.011,.009]),'p99':np.asarray([100.,101.,99.])}
    groups,total,protection,receipt=m._cross_branch_superanchor_family_core5_priority(np.arange(3,dtype=np.int32),np.asarray([.7,.8,.6]),cm,meta)
    assert total==1
    assert receipt['TRIGGERED'] is True
    assert receipt['SELECTED_GLOBAL']==2
    assert receipt['CHAMPION_ORDER'].startswith('MC_WIN_RATE')
    assert receipt['POSTLOCK_INPUT_USED'] is False
    assert receipt['PLAYER_NAME_CONSTANTS_USED'] is False
    assert 2 in protection
    assert bool(groups[0][1][2])


def test_superanchor_family_requires_real_sibling_breadth():
    m=_engine()
    meta={'idx':np.asarray([[0,1,2,3,4,5],[0,1,2,3,4,6]],np.int32),'own':np.asarray([70.,8.,7.,6.,5.,20.,18.]),'lane_cross_branch_five_player_championship_family':np.ones(2,bool)}
    cm={'win':np.asarray([.01,.02]),'top01':np.asarray([.02,.03]),'p99':np.asarray([100.,101.])}
    groups,total,protection,receipt=m._cross_branch_superanchor_family_core5_priority(np.arange(2,dtype=np.int32),np.asarray([.5,.6]),cm,meta)
    assert groups is None and total==0 and protection=={}
    assert receipt['TRIGGERED'] is False


def test_live_run_hard_corrective_patch_is_preserved_in_rebased_state():
    reg=(ROOT/'engine_registry.json').read_text()
    assert 'APEX_GLOBAL_LIVE_RUN_NO_AUDIT_DIAGNOSTIC_TEST_HARD_CORRECTIVE_ACTION_v1' in reg
