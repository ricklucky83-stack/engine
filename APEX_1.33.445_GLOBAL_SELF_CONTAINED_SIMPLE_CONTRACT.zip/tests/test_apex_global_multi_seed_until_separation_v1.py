import importlib.util
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'engines/common/apex_elite_tail_propagation_v1.py'
spec=importlib.util.spec_from_file_location('elite_tail_v1',P)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


def _row(lid, win, top01, trials=1000):
    return {
        'LINEUP_ID':str(lid), 'MC_TRIALS':int(trials),
        'MC_WIN_RATE':float(win), 'MC_TOP_0_1_RATE':float(top01),
        'MC_P99':100.0+float(lid), 'CORE_FAMILY_ID':'F'+str(int(lid)//2),
    }


def test_multi_seed_runs_until_boundary_separates_and_preserves_ids():
    rows=[
        _row(1,.020,.040), _row(2,.019,.039), _row(3,.018,.038),
        _row(4,.017,.037), _row(5,.010,.020), _row(6,.0098,.0198),
    ]
    calls=[]
    def cb(bubble, extra_trials, seed):
        calls.append((extra_trials,seed,tuple(sorted(r['LINEUP_ID'] for r in bubble))))
        out=[]
        for r0 in bubble:
            r=dict(r0); n0=int(r['MC_TRIALS']); n1=int(extra_trials); nt=n0+n1
            # Fresh seed evidence separates 5 from 6 deterministically.
            target=.002 if r['LINEUP_ID']=='6' else .030
            target_top=.004 if r['LINEUP_ID']=='6' else .050
            r['MC_WIN_RATE']=(r['MC_WIN_RATE']*n0+target*n1)/nt
            r['MC_TOP_0_1_RATE']=(r['MC_TOP_0_1_RATE']*n0+target_top*n1)/nt
            r['MC_TRIALS']=nt
            out.append(r)
        return out
    out,receipt=m.multi_seed_until_separation(
        rows,simulator=cb,sport='MLB',mode='SHOWDOWN',execution_id='t',
        board_size=5,base_extra_trials=5000,max_rounds=3,seed0=700,
    )
    assert receipt['STATUS']=='SEPARATED'
    assert receipt['SEPARATION_ACHIEVED'] is True
    assert receipt['ROUNDS_EXECUTED']>=1
    assert set(r['LINEUP_ID'] for r in out)==set(str(i) for i in range(1,7))
    assert all(r['MULTI_SEED_PATCH_ID']==m.MULTI_SEED_PATCH_ID for r in out)
    assert any(int(r['MULTI_SEED_EXTRA_TRIALS'])>0 for r in out)
    assert calls[0][1]==700


def test_callback_id_mutation_fails_closed():
    rows=[_row(i,.01,.02) for i in range(1,7)]
    def bad_cb(bubble, extra_trials, seed):
        out=[]
        for r0 in bubble[:-1]:
            r=dict(r0); r['MC_TRIALS']=int(r['MC_TRIALS'])+int(extra_trials); out.append(r)
        return out
    try:
        m.multi_seed_until_separation(rows,simulator=bad_cb,sport='MLB',mode='SHOWDOWN',execution_id='t',board_size=5)
    except m.EliteTailPropagationError as exc:
        assert 'MULTI_SEED_CALLBACK_ID_PARITY' in str(exc)
    else:
        raise AssertionError('expected exact ID parity failure')


def test_unresolved_max_budget_is_never_reported_separated():
    rows=[_row(i,.01,.02) for i in range(1,7)]
    def neutral_cb(bubble, extra_trials, seed):
        out=[]
        for r0 in bubble:
            r=dict(r0); r['MC_TRIALS']=int(r['MC_TRIALS'])+int(extra_trials); out.append(r)
        return out
    out,receipt=m.multi_seed_until_separation(
        rows,simulator=neutral_cb,sport='MLB',mode='SHOWDOWN',execution_id='t',
        board_size=5,base_extra_trials=1000,max_rounds=1,seed0=900,
    )
    assert receipt['STATUS']=='MAX_BUDGET_EQUIVALENT'
    assert receipt['SEPARATION_ACHIEVED'] is False
    assert receipt['UNRESOLVED_BOUNDARY_LINEUPS']>0
