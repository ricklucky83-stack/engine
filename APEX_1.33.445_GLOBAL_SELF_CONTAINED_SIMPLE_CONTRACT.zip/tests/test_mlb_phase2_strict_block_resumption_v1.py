from pathlib import Path
import importlib.util
ROOT=Path(__file__).resolve().parents[1]
MOD=ROOT/'engines/common/mlb_phase2_strict_block_resumption_v1.py'
RUNTIME=ROOT/'engines/mlb/mlb_classic_raw_pool_runtime_v1_20_2.py'
DOCTRINE=ROOT/'doctrine/MLB_PHASE2_STRICT_BLOCK_RESUMPTION_v1.json'

def _load():
    spec=importlib.util.spec_from_file_location('blk',MOD); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def test_block_contract_locked_4096():
    m=_load(); assert m.BLOCK_ROWS==4096; assert m.SINGLE_PASS_ALLOWED is False
    assert list(m.block_ranges(9000))==[(0,0,4096),(1,4096,8192),(2,8192,9000)]

def test_classic_runtime_routes_right_neighborhood_through_blocks():
    s=RUNTIME.read_text()
    assert "MLB_PHASE2_SINGLE_PASS_ALLOWED = mlb_phase2_blocks.SINGLE_PASS_ALLOWED" in s
    assert "block_ranges(len(base_5_3_rows), MLB_PHASE2_BLOCK_ROWS)" in s
    assert "block_ranges(len(right_neighborhood_5_3_parents), MLB_PHASE2_BLOCK_ROWS)" in s
    assert "MLB_PHASE2_STREAM_CHUNK_ROWS_MUST_EQUAL" in s

def test_doctrine_exists():
    import json
    d=json.loads(DOCTRINE.read_text())
    assert d['HARD_CONTRACT']['PHASE2_BLOCK_ROWS']==4096
    assert d['HARD_CONTRACT']['SINGLE_PASS_LATTICE_EXECUTION_ALLOWED'] is False
