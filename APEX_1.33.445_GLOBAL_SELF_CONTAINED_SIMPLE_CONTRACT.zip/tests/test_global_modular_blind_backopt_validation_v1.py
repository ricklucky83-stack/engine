from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "engines/common/apex_modular_blind_backopt_validation_v1.py"
DOCTRINE = ROOT / "doctrine/APEX_GLOBAL_MODULAR_BLIND_BACKOPT_VALIDATION_v1.json"
CAL_V2 = ROOT / "doctrine/APEX_CALIBRATION_FIRST_PHASE2_CONSTRUCTION_v2.json"
WNBA = ROOT / "engines/wnba/wnba_classic_raw_pool_runtime_v1.py"
REGISTRY = ROOT / "maintenance/APEX_COMPARTMENT_TEST_REGISTRY_v1.json"


def load_module():
    spec = importlib.util.spec_from_file_location("apex_modular_blind_test", MODULE)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def test_production_and_maintenance_are_separated():
    d = json.loads(DOCTRINE.read_text())
    assert d["PRODUCTION_SEPARATION"]["DIAGNOSTICS_ON_LIVE_CRITICAL_PATH"].startswith("PROHIBITED")
    assert d["COMPARTMENT_RULE"]["FULL_ENGINE_INTEGRATION_RUN_LAST"] is True


def test_known_historical_same_contest_blind_replay_is_allowed_only_with_preseal_isolation():
    d = json.loads(DOCTRINE.read_text())["BLIND_HISTORICAL_PROTOCOL"]
    assert d["SAME_CONTEST_BLIND_REPRODUCTION_ALLOWED"] is True
    assert d["ENGINE_OUTCOME_ACCESS_BEFORE_BOARD_SEAL"] == "PROHIBITED"
    assert d["BOARD_AND_SELECTOR_LEDGER_SEALED_BEFORE_UNBLIND"] is True
    assert "NOT_INDEPENDENT_PROMOTION_PROOF" in d["SAME_CONTEST_REPLAY_AFTER_TARGETED_REPAIR_COUNTS_AS"]


def test_prelock_outcome_leak_fails_closed():
    mod = load_module()
    with pytest.raises(RuntimeError, match="BLIND_PRELOCK_OUTCOME_LEAK"):
        mod.assert_prelock_blind({"pool_sha": "x", "contest_rank": 1})
    mod.assert_prelock_blind({"pool_sha": "x", "weather": "prelock"})


def test_board_and_selector_are_immutable_after_seal():
    mod = load_module()
    board = [["A", "B"]]
    selector = [{"id": 1, "score": 2.0}]
    seal = mod.seal_board(board, selector)
    mod.verify_seal(board, selector, seal)
    with pytest.raises(RuntimeError, match="BLIND_BOARD_MUTATED_AFTER_SEAL"):
        mod.verify_seal([["A", "C"]], selector, seal)


def test_family_recall_report_locates_selector_failure():
    mod = load_module()
    winner = ["A", "B", "C"]
    p2 = [winner, ["A", "B", "D"], ["X", "Y", "Z"]]
    report = mod.family_recall_report(
        phase2_lineups=p2,
        handoff_lineups=p2,
        selector_reviewed_lineups=p2,
        board_lineups=[["A", "B", "D"]],
        winner_lineup=winner,
        family_key=lambda row: row[:2],
    )
    assert report["WINNER_BORN"] is True
    assert report["WINNER_SELECTOR_REVIEWED"] is True
    assert report["WINNER_BOARD"] is False
    assert report["FAILURE_CLASS"] == "SELECTOR_OR_PORTFOLIO_FAILURE"


def test_calibration_first_v2_prohibits_arbitrary_family_cull():
    d = json.loads(CAL_V2.read_text())
    assert d["FAMILY_PRESERVATION"]["ARBITRARY_PHASE2_LINEUP_CAP"] == "PROHIBITED"
    assert d["FAMILY_PRESERVATION"]["STREAMING_OR_CHUNKING_OVER_LINEUP_DELETION"] == "REQUIRED"
    assert d["UNIVERSAL_ARCHITECTURE"]["SELECTOR_ROLE"].startswith("CHOOSE_BEST_REPRESENTATIVES")


def test_wnba_phase2_does_not_apply_sim_cap_to_delete_qualified_births():
    source = WNBA.read_text()
    block = source[source.index("def phase2_family_closure"):source.index("def _build_fake_field")]
    assert "if selected_idx.size > config.phase2_sim_cap" not in block
    assert '"phase2_cap_applied": np.asarray([0])' in block
    assert '"phase2_lineup_reduction_prohibited": np.asarray([1])' in block


def test_compartment_registry_covers_required_wnba_classic_stages():
    r = json.loads(REGISTRY.read_text())["WNBA_CLASSIC"]
    for key in (
        "PHASE1_CALIBRATION", "PHASE2_GENERATOR_BIRTH", "FAMILY_GROUP_CLOSURE",
        "PHASE3_SIMULATION", "SELECTOR_RANKER", "FINAL_RENDER_LEGALITY",
    ):
        assert key in r and r[key]
