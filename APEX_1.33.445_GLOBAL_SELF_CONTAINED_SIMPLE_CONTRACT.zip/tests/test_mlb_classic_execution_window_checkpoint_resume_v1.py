import hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
contract=json.loads((ROOT/'doctrine/MLB_CLASSIC_EXECUTION_WINDOW_CHECKPOINT_RESUME_v1.json').read_text())
source=ROOT/contract['AUTHORITATIVE_RUNTIME_FILE']; runner=ROOT/contract['EXECUTABLE_FILE']
assert source.exists() and runner.exists()
assert hashlib.sha256(source.read_bytes()).hexdigest()==contract['AUTHORITATIVE_RUNTIME_SHA256']
for k in ['PLAYER_POOL_REDUCTION_ALLOWED','LINEUP_UNIVERSE_REDUCTION_ALLOWED','RANDOM_SUBSETTING_ALLOWED','FIRST_N_ALLOWED','RELAXED_LINEUPS_ALLOWED','MODEL_LOGIC_CHANGED','CALIBRATION_LOGIC_CHANGED','PHASE2_MEMBERSHIP_LOGIC_CHANGED','PHASE3_SCORING_LOGIC_CHANGED','SELECTOR_LOGIC_CHANGED']:
    assert contract[k] is False, k
stages=contract['STAGES']; assert len(stages)==8
assert stages[0]['START_LINE']==1 and stages[-1]['END_LINE']==len(source.read_text().splitlines())
assert stages[-1]['CHECKPOINT'] is False
text=runner.read_text()
for needle in ['pickle.dumps(v, protocol=5)','os.replace(tmp,path)','APEX_SPLIT_SOURCE_SHA256','RUN_INVALID:SOURCE_SHA256_MISMATCH','INVALID_STAGE_BOUNDS']:
    assert needle in text
v=contract['VALIDATION']
assert v['PHASE2_BUILT_LINEUPS']==v['HANDOFF_SURVIVORS']==v['SELECTOR_REVIEWED_LINEUPS']==13826
assert v['FINAL_BOARD_SIZE']==10 and v['EXECUTION_STATE']=='TOOL_PROVEN_EXECUTED'
print('PASS:MLB_CLASSIC_EXECUTION_WINDOW_CHECKPOINT_RESUME_v1')
