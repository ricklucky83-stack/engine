import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
NEW='APEX_GLOBAL_PHASE1_DIAGNOSTIC_RECALIBRATION_CASCADE_v1'
LEGACY='APEX_PHASE1_DIAGNOSTIC_RECALIBRATION_CASCADE_v1'

def load(rel): return json.loads((ROOT/rel).read_text())

def test_global_doctrine_identity_and_scope():
    d=load(f'doctrine/{NEW}.json')
    assert d['STATUS']=='LOCKED_HARD_GATE'
    assert d['SCOPE']=='ALL_SPORTS_ALL_MODES_ALL_ENGINE_RUNS'
    assert d['CORE_PRINCIPLE']=='PHASE1_IS_PHASE3_EYES'

def test_calibration_is_immutable_inside_run():
    d=load(f'doctrine/{NEW}.json')
    r=d['RUN_IMMUTABILITY']
    assert r['PHASE1_CALIBRATION_COMPUTE_ONCE_PER_RUN'] is True
    assert r['PHASE1_CALIBRATION_FREEZE_BEFORE_PHASE2'] is True
    assert r['MIDRUN_PHASE1_RECALIBRATION_PROHIBITED'] is True
    assert r['ORIGINAL_PRODUCTION_RUN_CALIBRATION_IS_NEVER_REWRITTEN'] is True

def test_model_miss_restarts_at_phase1():
    d=load(f'doctrine/{NEW}.json')
    assert d['DIAGNOSTIC_TRIGGER']['CONTEST_OR_MODEL_OUTCOME_MISS']=='RESTART_AT_PHASE1'
    c=d['MANDATORY_RECALIBRATION_CASCADE']
    assert c.index('RECALIBRATE_PHASE1') < c.index('REBUILD_PHASE2_FROM_NEW_PHASE1') < c.index('RERUN_PHASE3_FROM_NEW_PHASE1') < c.index('RERUN_SELECTOR_FROM_NEW_DOWNSTREAM_RESULTS')

def test_phase1_change_invalidates_every_downstream_artifact():
    d=load(f'doctrine/{NEW}.json')['DOWNSTREAM_INVALIDATION']
    for key in ['OLD_PHASE2_REUSE_AFTER_PHASE1_CHANGE_PROHIBITED','OLD_HANDOFF_REUSE_AFTER_PHASE1_CHANGE_PROHIBITED','OLD_PHASE3_REUSE_AFTER_PHASE1_CHANGE_PROHIBITED','OLD_DEEP_SIM_REUSE_AFTER_PHASE1_CHANGE_PROHIBITED','OLD_SELECTOR_RESULT_REUSE_AFTER_PHASE1_CHANGE_PROHIBITED','OLD_BOARD_REUSE_AFTER_PHASE1_CHANGE_PROHIBITED']:
        assert d[key] is True

def test_required_hash_chain_complete():
    d=load(f'doctrine/{NEW}.json')
    assert d['REQUIRED_HASH_CHAIN']==['PHASE1_CALIBRATION_SHA256','PHASE2_INPUT_CALIBRATION_SHA256','HANDOFF_INPUT_CALIBRATION_SHA256','PHASE3_INPUT_CALIBRATION_SHA256','DEEP_SIM_INPUT_CALIBRATION_SHA256','SELECTOR_INPUT_CALIBRATION_SHA256','FINAL_BOARD_INPUT_CALIBRATION_SHA256']

def test_strict_hash_claim_requires_runtime_proof():
    d=load(f'doctrine/{NEW}.json')['HASH_CHAIN_POLICY']
    assert d['STRICT_HASH_CHAIN_ENFORCEMENT_CLAIM_REQUIRES_RUNTIME_RECEIPT_PROOF'] is True
    assert d['DOCTRINE_ACTIVE_DOES_NOT_IMPLY_RUNTIME_HASH_CHAIN_IS_WIRED'] is True
    assert d['UNWIRED_RUNTIME_MAY_NOT_CLAIM_STRICT_HASH_CHAIN_PASS'] is True

def test_global_registry_and_rules():
    r=load('engine_registry.json')
    assert NEW in {x['DOCTRINE_ID'] for x in r['GLOBAL_DOCTRINES']}
    assert r['GLOBAL_RULES']['GLOBAL_PHASE1_DIAGNOSTIC_RECALIBRATION_SCOPE']=='ALL_SPORTS_ALL_MODES_ALL_ENGINE_RUNS'
    assert r['GLOBAL_RULES']['PHASE1_IS_PHASE3_EYES_GLOBAL'] is True

def test_all_registered_engines_are_under_global_rule():
    r=load('engine_registry.json')
    engine_ids=[e.get('ENGINE_ID') for e in r['ENGINES']]
    assert engine_ids and len(engine_ids)==len(set(engine_ids))
    assert all(e.get('SPORT') for e in r['ENGINES'])
    assert r['GLOBAL_RULES']['GLOBAL_PHASE1_DIAGNOSTIC_RECALIBRATION_DOCTRINE_REQUIRED'] is True

def test_runtime_enforcement_boundary_is_truthful():
    d=load(f'doctrine/{NEW}.json')['RUNTIME_ENFORCEMENT_STATUS_AT_PROMOTION']
    assert d['MLB_SHOWDOWN'].startswith('WIRED_')
    for k,v in d.items():
        if k!='MLB_SHOWDOWN': assert 'STRICT_RUNTIME_HASH_CHAIN_NOT_CLAIMED' in v

def test_backward_research_does_not_mutate_forward_accuracy():
    d=load(f'doctrine/{NEW}.json')['POSTLOCK_AND_FORWARD_ISOLATION']
    assert d['BACKWARD_CALIBRATION_SCORECARD_SEPARATE_FROM_FORWARD_ACCURACY'] is True
    assert d['POSTLOCK_REPLAY_CANNOT_COUNT_AS_FORWARD_ACCURACY'] is True

def test_selector_ranker_unchanged_by_doctrine_only_promotion():
    d=load(f'doctrine/{NEW}.json')
    assert d['DOWNSTREAM_SIGNAL_FIDELITY_AUDIT']['DOCTRINE_ONLY_PROMOTION_MAY_NOT_CHANGE_PRODUCTION_SELECTOR_OR_RANKER'] is True
    s=load('state_contract.json')
    assert s['VALIDATION']['PRODUCTION_SELECTOR_WEIGHTS_CHANGED'] is False
    assert s['VALIDATION']['PRODUCTION_RANKER_HASH_UNCHANGED']=='PASS'

def test_legacy_doctrine_preserved_and_global_successor_separate():
    assert (ROOT/'doctrine'/f'{LEGACY}.json').exists()
    d=load(f'doctrine/{NEW}.json')
    assert d['LEGACY_DOCTRINE_PRESERVED']==LEGACY
    assert d['SUPERSEDES_SCOPE_OF']==LEGACY

def test_postlock_and_winner_science_route_to_global_doctrine():
    loss=load('doctrine/APEX_GLOBAL_POSTLOCK_LOSS_CAUSAL_RESEARCH_AND_REPAIR_v1.json')
    sci=load('doctrine/APEX_GLOBAL_WINNER_FOCUSED_CONTEST_SCIENCE_v1.json')
    assert loss['DIAGNOSTIC_RECALIBRATION_DOCTRINE']==NEW
    assert sci['PHASE1_DIAGNOSTIC_RECALIBRATION_DOCTRINE']==NEW
    assert loss['LEGACY_PHASE1_DIAGNOSTIC_RECALIBRATION_DOCTRINE']==LEGACY
    assert sci['LEGACY_PHASE1_DIAGNOSTIC_RECALIBRATION_DOCTRINE']==LEGACY

def test_persistence_policy_globalized():
    p=load('persistence_policy.json')
    assert p['EFFECTIVE_STATE_VERSION']=='1.32.4'
    assert p['RULES']['PHASE1_IS_PHASE3_EYES_ALL_SPORTS_ALL_MODES'] is True
    assert p['RULES']['STRICT_HASH_CHAIN_CLAIMS_REQUIRE_RUNTIME_RECEIPT_PROOF'] is True
