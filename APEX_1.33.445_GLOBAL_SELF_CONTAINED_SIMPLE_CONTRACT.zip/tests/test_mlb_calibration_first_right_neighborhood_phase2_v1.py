from pathlib import Path

RUNTIME = Path(__file__).resolve().parents[1] / 'engines' / 'mlb' / 'mlb_classic_raw_pool_runtime_v1_20_2.py'
DOCTRINE = Path(__file__).resolve().parents[1] / 'doctrine' / 'MLB_CALIBRATION_FIRST_RIGHT_NEIGHBORHOOD_PHASE2_v1.json'

def test_runtime_hard_gates():
    s = RUNTIME.read_text()
    assert 'RIGHT_NEIGHBORHOOD_CALIBRATED_SUPPORT_REQUIRED = True' in s
    assert 'RAW_FULL_DEPTH_ENUMERATION_ACTIVE = False' in s
    assert 'MLB_PHASE2_RAW_UNCALIBRATED_FULL_DEPTH_ENUMERATION_PROHIBITED' in s
    assert 'MLB_RIGHT_NEIGHBORHOOD_CALIBRATED_SUPPORT_MUST_BE_ENABLED' in s

def test_calibration_controls_birth_targets():
    s = RUNTIME.read_text()
    assert "calibration_payload['BRANCH_PROBABILITIES']" in s
    assert 'branch_probabilities[name] * PHASE2_TARGET' in s
    assert 'APEX_CALIBRATION_FIRST_RIGHT_NEIGHBORHOOD_PHASE2_v1' in s

def test_right_neighborhood_remains_active_after_calibrated_birth():
    s = RUNTIME.read_text()
    assert "base_calibrated_5_2_1_adjacent_rows" in s
    assert "right_neighborhood_5_3_parents" in s
    assert "PHASE2_RIGHT_NEIGHBORHOOD_CROSS_PATTERN" in s
    assert "PHASE2_RIGHT_NEIGHBORHOOD_SECOND_HOP_UNION" in s
    assert "MLB_PHASE2_BLOCK_ROWS" in s
    assert DOCTRINE.exists()
