from __future__ import annotations

import csv
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from apex_regular_chat_bootstrap import resolve_engine


STATE_ROOT = Path(__file__).resolve().parents[1]
ENGINE_ROOT = STATE_ROOT / "engines" / "pga" / "classic_v1_1"
RUNNER = ENGINE_ROOT / "run.py"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class PgaClassicRuntimeV11Tests(unittest.TestCase):
    def _fixtures(self, root: Path, variant: int = 0) -> tuple[Path, Path, Path]:
        pool = root / f"pool_{variant}.csv"
        eligibility = root / f"eligibility_{variant}.csv"
        config = root / f"config_{variant}.json"
        pool_fields = [
            "PLAYER", "SAL", "FPTS", "CEILING", "CUT%", "CUTS",
            "TOP 10", "TOP 3", "RST%", "BIRDIE%", "BOGEY%", "TEE TIME",
        ]
        with pool.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=pool_fields)
            writer.writeheader()
            for index in range(12):
                writer.writerow({
                    "PLAYER": f"CONTROL_{variant}_{index:02d}",
                    "SAL": 6500 + index * 200,
                    "FPTS": 60 + index * 1.35 + variant * .2,
                    "CEILING": 88 + index * 1.8 + variant * .3,
                    "CUT%": 54 + index * 3,
                    "CUTS": 18,
                    "TOP 10": index % 6,
                    "TOP 3": index % 3,
                    "RST%": 5 + index * 1.5,
                    "BIRDIE%": 15 + (index * 2 + variant) % 12,
                    "BOGEY%": 11 + (11 - index) * .4,
                    "TEE TIME": "AM" if (index + variant) % 2 else "PM",
                })
        eligibility_fields = ["PLAYER", "STATUS", "SOURCE_URL", "RETRIEVED_AT_UTC", "EVENT"]
        with eligibility.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=eligibility_fields)
            writer.writeheader()
            for index in range(12):
                writer.writerow({
                    "PLAYER": f"CONTROL_{variant}_{index:02d}",
                    "STATUS": "ACTIVE",
                    "SOURCE_URL": f"https://example.test/pga-control-{variant}",
                    "RETRIEVED_AT_UTC": f"2026-07-{20 + variant:02d}T12:00:00Z",
                    "EVENT": f"Blind Control {variant}",
                })
        config.write_text(json.dumps({
            "engine_id": "APEX_PGA_CLASSIC_BUNDLED_ENGINE_v1_1",
            "engine_version": "1.1.0",
            "mode": "PGA_CLASSIC",
            "roster_size": 6,
            "salary_floor": 39000,
            "salary_cap": 50000,
            "phase1_frontier_players": 12,
            "phase2_qualified_target": 500,
            "hybrid_handoff_policy": "ALL_PHASE2_EXACT_SET",
            "final_board_size": 10,
            "minimum_simulations": 15000,
            "serious_simulations": 50000,
        }, indent=2) + "\n", encoding="utf-8")
        return pool, eligibility, config

    def _run(self, root: Path, variant: int, seed: int) -> tuple[dict[str, object], Path]:
        pool, eligibility, config = self._fixtures(root, variant)
        output = root / f"run_{variant}_{seed}"
        result = subprocess.run([
            sys.executable, str(RUNNER), "execute",
            "--input", str(pool),
            "--eligibility-file", str(eligibility),
            "--config", str(config),
            "--field-size", "64",
            "--output-dir", str(output),
            "--seed", str(seed),
            "--simulations", "15000",
        ], capture_output=True, text=True, cwd=STATE_ROOT)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return json.loads(result.stdout), output

    def test_health_source_and_strategy_wiring(self):
        result = subprocess.run(
            [sys.executable, str(RUNNER), "health"],
            capture_output=True, text=True, cwd=STATE_ROOT,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        receipt = json.loads(result.stdout)
        self.assertEqual(receipt["ENGINE_ID"], "APEX_PGA_CLASSIC_BUNDLED_ENGINE_v1_1")
        self.assertTrue(receipt["GLOBAL_SPORTS_STRATEGY_SOURCE_WIRED"])
        self.assertTrue(receipt["PREDICTIVE_MARKET_LAYER_SOURCE_WIRED"])
        self.assertTrue(receipt["PREDICTION_HASH_FREEZE_REQUIRED"])
        self.assertTrue(receipt["PREDICTIVE_POSTLOCK_INPUT_PROHIBITED"])
        self.assertTrue(receipt["PHASE2_HANDOFF_SELECTOR_SET_EQUAL_REQUIRED"])
        self.assertFalse(receipt["HANDOFF_COMPRESSION_ALLOWED"])
        self.assertFalse(receipt["FINAL_BOARD_FILLERS_ALLOWED"])

    def test_registry_mode_isolation_routes_classic_and_showdown(self):
        registry = json.loads((STATE_ROOT / "engine_registry.json").read_text(encoding="utf-8"))
        classic = resolve_engine(registry, "DK", "PGA", "CLASSIC")
        showdown = resolve_engine(registry, "DK", "PGA", "SD")
        self.assertEqual(classic["ENGINE_ID"], "APEX_PGA_CLASSIC_BUNDLED_ENGINE_v1_1")
        self.assertEqual(showdown["ENGINE_ID"], "APEX_PGA_SHOWDOWN_FLAT6_RUNTIME_v1_1")
        self.assertNotEqual(classic["ENGINE_ID"], showdown["ENGINE_ID"])
        self.assertTrue(classic["PRODUCTION_RUN_ALLOWED"])
        self.assertTrue(showdown["PRODUCTION_RUN_ALLOWED"])

    def test_complete_hybrid_exact_set_identity_and_determinism(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first, first_dir = self._run(root, 0, 310061)
            second, second_dir = self._run(root, 0, 310061)
            blind, blind_dir = self._run(root, 1, 310062)
            self.assertTrue(first["PHASE2_HANDOFF_SELECTOR_SET_EQUAL"])
            self.assertFalse(first["HANDOFF_COMPRESSION_USED"])
            self.assertEqual(first["PHASE2_BUILT_LINEUPS"], first["PHASE3_EVALUATED_ROWS"])
            self.assertEqual(first["PHASE2_BUILT_LINEUPS"], first["HANDOFF_ROWS"])
            self.assertEqual(first["PHASE2_BUILT_LINEUPS"], first["SELECTOR_REVIEWED_LINEUPS"])
            set_hashes = {
                first["PHASE2_LINEUP_ID_SET_SHA256"],
                first["PHASE3_LINEUP_ID_SET_SHA256"],
                first["HANDOFF_LINEUP_ID_SET_SHA256"],
                first["SELECTOR_REVIEW_LINEUP_ID_SET_SHA256"],
            }
            self.assertEqual(len(set_hashes), 1)
            self.assertEqual(first["SPORT_STRATEGY_ADAPTER_STATUS"], "PASS")
            self.assertEqual(first["PREDICTIVE_LAYER_STATUS"], "PASS")
            self.assertTrue(first["PREDICTIVE_LAYER_SOURCE_WIRED"])
            self.assertTrue(first["PREDICTION_FROZEN"])
            self.assertEqual(first["PREDICTION_HASH"], first["STRATEGY_CONSUMED_PREDICTION_HASH"])
            self.assertFalse(first["PREDICTIVE_LAYER_POSTLOCK_RESULTS_USED"])
            self.assertFalse(first["PREDICTIVE_RAW_AGGREGATE_PROJECTION_TO_PHASE1"])
            self.assertFalse(first["SPORT_STRATEGY_POSTLOCK_RESULTS_USED"])
            self.assertEqual(first["PREBUILD_AVAILABILITY_GATE"], "PASS_CODE_GENERATED_POOL_HASH_BOUND")
            self.assertEqual(first["PREBUILD_AVAILABILITY"]["PRESELECTOR_EXECUTION"], "CODE_ONLY")
            self.assertEqual(first["FINAL_SELECTOR_AVAILABILITY_RECHECK"], "PASS")
            self.assertEqual(first["FINAL_BOARD_FILLER_ROWS"], 0)
            self.assertEqual(first["FINAL_BOARD_ROWS"], 10)
            self.assertTrue(blind["PHASE2_HANDOFF_SELECTOR_SET_EQUAL"])
            self.assertEqual(blind["PHASE2_BUILT_LINEUPS"], blind["SELECTOR_REVIEWED_LINEUPS"])
            self.assertEqual(blind["FINAL_BOARD_FILLER_ROWS"], 0)
            self.assertEqual(blind["FINAL_BOARD_ROWS"], 10)
            self.assertNotEqual(first["INPUT_SHA256"], blind["INPUT_SHA256"])
            self.assertNotEqual(
                sha256(first_dir / "final_execution_matrix.csv"),
                sha256(blind_dir / "final_execution_matrix.csv"),
            )
            self.assertEqual(
                sha256(first_dir / "final_execution_matrix.csv"),
                sha256(second_dir / "final_execution_matrix.csv"),
            )
            self.assertEqual(
                sha256(first_dir / "phase2_calibration_qualified_matrix.csv"),
                sha256(second_dir / "phase2_calibration_qualified_matrix.csv"),
            )


if __name__ == "__main__":
    unittest.main()
