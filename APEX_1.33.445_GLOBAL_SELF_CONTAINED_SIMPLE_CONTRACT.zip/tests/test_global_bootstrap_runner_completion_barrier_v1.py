import json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PATCH="APEX_GLOBAL_BOOTSTRAP_RUNNER_COMPLETION_BARRIER_v1"

def test_live_bootstrap_cannot_claim_completed_execution():
    src=(ROOT/"apex_regular_chat_bootstrap.py").read_text()
    for token in ("'RUN_STATE':'PRODUCTION_RUNNER_REQUIRED'","'EXECUTION_STATE':'BOOTSTRAP_VERIFIED_ONLY'","'BOARD_RENDER_ALLOWED':False","'MACHINE_BOARD_PARITY':'NOT_YET_RUN'","'USER_VISIBLE_BOARD_ALLOWED_ONLY_AFTER_MACHINE_BOARD_PARITY_PASS':True","'RUN_AUTHORITY':'PRODUCTION_RUNNER_REQUIRED_BEFORE_ANY_BOARD_OUTPUT'"):
        assert token in src

def test_registry_contract_and_concurrent_patch_globalized():
    r=json.loads((ROOT/"engine_registry.json").read_text())
    assert r["STATE_VERSION"] == r.get("REGISTRY_STATE_VERSION")
    assert r["GLOBAL_RULES"]["PRODUCTION_BOOTSTRAP_MAY_NOT_CLAIM_EXECUTION_COMPLETE"] is True
    assert r["GLOBAL_RULES"]["PRODUCTION_RUNNER_REQUIRED_BEFORE_BOARD_RENDER"] is True
    assert any(x.get("PATCH_ID")==PATCH for x in r["GLOBAL_PATCHES"] if isinstance(x,dict))
    assert any(x.get("PATCH_ID")=="MLB_CLASSIC_POSTLOCK_NAME_SUFFIX_CANONICALIZATION_v1" for x in r["GLOBAL_PATCHES"] if isinstance(x,dict))
    d=json.loads((ROOT/"doctrine"/f"{PATCH}.json").read_text())
    assert d["SELECTOR_CHANGED"] is False and d["POSTLOCK_RESULTS_USED_IN_FORWARD_ENGINE"] is False

def test_mlb_nested_manifest_tracks_bootstrap_bytes():
    h=hashlib.sha256((ROOT/"apex_regular_chat_bootstrap.py").read_bytes()).hexdigest()
    m=json.loads((ROOT/"engines/mlb/APEX_MLB_RAW_POOL_RUNTIME_v1_20_2.manifest.json").read_text())
    assert m["FILES"]["apex_regular_chat_bootstrap.py"]==h
    r=json.loads((ROOT/"engine_registry.json").read_text())
    engines=[e for e in r["ENGINES"] if "apex_regular_chat_bootstrap.py" in e.get("EXPECTED_SHA256",{})]
    assert engines and all(e["EXPECTED_SHA256"]["apex_regular_chat_bootstrap.py"]==h for e in engines)
