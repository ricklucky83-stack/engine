from __future__ import annotations
import importlib.util, json, sys
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
COMMON=ROOT/'engines/common/apex_contest_derived_ownership_v1.py'
NFL=ROOT/'engines/nfl/nfl_showdown_raw_pool_runtime_v1.py'

def _load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); sys.modules[name]=m; spec.loader.exec_module(m); return m
own=_load('own_route_test',COMMON); nfl=_load('nfl_route_test',NFL)

def _pool():
    rows=[]
    ownvals=[72.6,65.4,81.3,58.9,56.3,8.9,6.7,7.4,14.5,0.0,5.0,6.4,1.5]
    k=0
    for team,opp in [('AAA','BBB'),('BBB','AAA')]:
        for pos in ['QB','RB','RB','WR','WR','TE','K','DST']:
            rows.append({'PLAYER':f'{team}_{pos}_{k}','POS':f'{pos}/CPTN/FLEX','TEAM':team,'OPP':opp,'SAL':4000+300*k,
                         'FPTS':5+(k%9),'Ceil':8+(k%11),'Floor':1.0,'RST%':ownvals[k%len(ownvals)],'TM Score':21.5,'O/U':43.0,'SPRD':0.0})
            k+=1
    return pd.DataFrame(rows)

def test_common_nfl_showdown_bridge_closes_600_and_preserves_provider():
    df=_pool(); raw=float(df['RST%'].sum())
    out=own.derive_expected_ownership(df,'NFL','SHOWDOWN',field_size=95124,contest_type='20 MAX')
    assert abs(float(out['RST%'].sum())-600.0)<1e-6
    assert abs(float(out['RW_RST_PRIOR'].sum())-raw)<1e-9
    assert set(out['APEX_OWNERSHIP_AUTHORITY'])=={'NFL_SD_COMMON_INTERNAL_BOOTSTRAP_600_MASS'}
    assert np.isfinite(out['RST%']).all() and (out['RST%']>0).all()

def test_common_bridge_missing_provider_still_internal_600():
    df=_pool().drop(columns=['RST%'])
    out=own.derive_expected_ownership(df,'NFL','SHOWDOWN')
    assert abs(float(out['RST%'].sum())-600.0)<1e-6
    assert float(out['RW_RST_PRIOR'].sum())==0.0

def _role_ready_frame():
    out=own.derive_expected_ownership(_pool(),'NFL','SHOWDOWN')
    out['POS_BASE']=out['POS'].str.split('/').str[0]
    out['ROLE_STATUS']='ACTIVE'; out['SNAPS']=70.0; out['ROUTES']=45.0; out['TARGETS']=6.0; out['CARRIES']=3.0
    out.loc[out.POS_BASE.eq('QB'),['SNAPS','ROUTES','TARGETS','CARRIES']]=[95.0,0.0,0.0,4.0]
    out.loc[out.POS_BASE.isin(['K','DST']),['SNAPS','ROUTES','TARGETS','CARRIES']]=0.0
    return out

class S:
    opportunity_score=np.ones(16,dtype=float)

def test_final_internal_contract_uses_raw_provider_prior_and_separates_slot_mass():
    df=_role_ready_frame(); p99=np.linspace(8,28,len(df))
    roster,cpt,flex,rec=nfl._role_consistent_ownership_contract(df,p99,S())
    assert rec['PROVIDER_PRIOR_COLUMN']=='RW_RST_PRIOR'
    assert rec['PROVIDER_PRIOR_AUTHORITY'] is False
    assert abs(float(roster.sum())-6.0)<2e-6
    assert abs(float(cpt.sum())-1.0)<2e-6
    assert abs(float(flex.sum())-5.0)<2e-6
    assert np.all(cpt<=roster+2e-7)
    assert np.allclose(roster,cpt+flex,atol=2e-7)
    assert rec['ADJUSTMENT_MODE'].startswith('INTERNAL_ROLE_TAIL_OPPORTUNITY_AUTHORITY')

def test_defensive_candidate_lanes_are_not_pruned(tmp_path):
    # Use the engine fixture conventions with synthetic role priors enabled in test mode.
    df=_pool(); pool=tmp_path/'pool.csv'; own.derive_expected_ownership(df,'NFL','SHOWDOWN').to_csv(pool,index=False)
    role=tmp_path/'role.json'; role.write_text(json.dumps({'players':{}}))
    market=tmp_path/'market.json'; market.write_text(json.dumps({'current_total':39.0,'open_total':41.0}))
    cfg=nfl.Config(field_size=100,seed=7,player_trials=120,base_trials=100,max_trials=100,cpt_pool_size=12,flex_pool_size=12,test_mode=True)
    cal=nfl._load_calibration(pool,role,market,cfg)
    rows,meta=nfl._generate_candidates(cal,cfg)
    pos=cal.pos[rows]
    assert np.any(pos[:,0]=='DST')
    assert np.any((pos=='DST').sum(axis=1)>=2)
    assert meta['cpt_certified_size']>=2

def test_direct_raw_player_file_exec_builds_internal_bridge(tmp_path):
    raw=tmp_path/'raw.csv'; _pool().to_csv(raw,index=False)
    role=tmp_path/'role.json'; role.write_text(json.dumps({'players':{}}))
    market=tmp_path/'market.json'; market.write_text(json.dumps({'current_total':43.0,'open_total':44.5}))
    cfg=nfl.Config(field_size=100,seed=7,player_trials=120,base_trials=100,max_trials=100,cpt_pool_size=12,flex_pool_size=12,test_mode=True)
    cal=nfl._load_calibration(raw,role,market,cfg)
    rec=nfl._ownership_route_receipt_from_frame(cal.frame)
    assert rec['STATUS']=='PASS'
    assert rec['DIRECT_RAW_PLAYER_FILE_EXECUTION'] is True
    assert abs(rec['BRIDGE_MASS']-600.0)<1e-6
    assert abs(float(cal.frame['RW_RST_PRIOR'].sum())-float(_pool()['RST%'].sum()))<1e-6

def test_runtime_ownership_receipt_separates_cpt_and_flex_mass(tmp_path):
    raw=tmp_path/'raw.csv'; _pool().to_csv(raw,index=False)
    role=tmp_path/'role.json'; role.write_text(json.dumps({'players':{}}))
    market=tmp_path/'market.json'; market.write_text(json.dumps({'current_total':39.0,'open_total':44.5}))
    cfg=nfl.Config(field_size=100,seed=11,player_trials=120,base_trials=100,max_trials=100,cpt_pool_size=12,flex_pool_size=12,test_mode=True)
    cal=nfl._load_calibration(raw,role,market,cfg)
    rec=cal.ownership_receipt
    assert abs(rec['NORMALIZED_ROSTER_MASS']-6.0)<2e-6
    assert abs(rec['NORMALIZED_CAPTAIN_MASS']-1.0)<2e-6
    assert abs(rec['NORMALIZED_FLEX_MASS']-5.0)<2e-6
    assert rec['PROVIDER_PRIOR_AUTHORITY'] is False
