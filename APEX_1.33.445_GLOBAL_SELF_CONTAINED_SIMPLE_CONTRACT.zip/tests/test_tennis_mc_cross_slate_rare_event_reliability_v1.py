from engines.tennis import tennis_classic_raw_pool_runtime_v2 as m
def test_cross_slate_reliability():
    for f in (951,1568,1960,2205,2352,2378,2614,2745):
        a=m.rare_event_reliability(f,10000); b=m.rare_event_reliability(f,50000)
        assert 0<a["WIN_RATE"]<b["WIN_RATE"]<1
        assert 0<a["TOP_0_1_RATE"]<b["TOP_0_1_RATE"]<1
def test_2614_expected_counts_and_mass():
    r=m.rare_event_reliability(2614,10000); assert 3.8<r["EXPECTED_WIN_EVENTS"]<3.9 and 11.4<r["EXPECTED_TOP01_EVENTS"]<11.6
    base={k:float(v) for k,v in m.CALIBRATION["SELECTOR"]["WEIGHTS"].items()}; adj,_=m.reliability_adjusted_selector_weights(2614,10000); assert abs(sum(base.values())-sum(adj.values()))<1e-12
