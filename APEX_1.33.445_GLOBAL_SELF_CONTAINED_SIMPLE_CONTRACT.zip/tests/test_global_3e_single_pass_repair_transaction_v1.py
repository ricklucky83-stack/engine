import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from engines.common.apex_3e_repair_transaction_v1 import (
    RepairTransactionError, advance, assert_single_pass, new_transaction, rebase, require_ready_to_seal
)
from engines.common.apex_diagnostic_merge_ledger_v3 import build_incremental_queue_index, apply_incremental_queue_delta


def _tx():
    return new_transaction(repair_id='R1', parent_state_version='1.33.173', parent_pointer_file_id='P1', parent_pointer_sha256='a'*64, root_cause='X', changed_components=['a.py'])


def test_single_pass_stage_order_and_duplicate_block():
    tx=_tx()
    for stage in ('DIAGNOSED','PATCHED','TARGETED_TESTED'):
        tx=advance(tx, stage)
    require_ready_to_seal(tx); assert_single_pass(tx)
    try:
        advance(tx, 'TARGETED_TESTED')
        assert False
    except RepairTransactionError as e:
        assert 'DUPLICATE_REPAIR_STAGE_PROHIBITED' in str(e)


def test_rebase_only_on_parent_drift_and_preserves_diagnosis_patch():
    tx=_tx(); tx=advance(tx,'DIAGNOSED'); tx=advance(tx,'PATCHED'); tx=advance(tx,'TARGETED_TESTED')
    tx2=rebase(tx, parent_state_version='1.33.174', parent_pointer_file_id='P2', parent_pointer_sha256='b'*64)
    assert tx2['COMPLETED_STAGES']==['DIAGNOSED','PATCHED']
    assert tx2['REBASE_COUNT']==1
    try:
        rebase(tx2, parent_state_version='1.33.174', parent_pointer_file_id='P2', parent_pointer_sha256='b'*64)
        assert False
    except RepairTransactionError as e:
        assert 'REBASE_PROHIBITED_WITHOUT_ACTIVE_PARENT_DRIFT' in str(e)


def test_incremental_ledger_delta_deduplicates_history():
    r1={'PATCH_ID':'P1','STATUS':'VALIDATED','CREATED_AT_UTC':'2026-09-07T00:00:00Z'}
    r2={'PATCH_ID':'P1','STATUS':'ACTIVE','CREATED_AT_UTC':'2026-09-07T00:01:00Z'}
    idx=build_incremental_queue_index([r1])
    idx2=apply_incremental_queue_delta(idx,[r1,r2])
    assert idx2['EVENT_COUNT']==2
    assert idx2['DELTA_EVENTS_ADDED']==1
    assert idx2['LATEST_BY_PATCH']['P1']['STATUS']=='ACTIVE'
