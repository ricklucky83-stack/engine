import importlib.util
import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "engines/nfl/nfl_showdown_raw_pool_runtime_v1.py"
spec = importlib.util.spec_from_file_location("nfl_sd_mc_variance_test", ENGINE)
nfl = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = nfl
spec.loader.exec_module(nfl)


def test_factor_draw_restores_phase1_sigma_without_td_events():
    positions = np.array(["QB", "RB", "WR", "TE", "K"], dtype=object)
    base = {
        "mu": np.full(len(positions), 50.0, dtype=np.float32),
        "sigma": np.full(len(positions), 6.0, dtype=np.float32),
        "pos": positions,
        "team": np.array(["A", "A", "A", "A", "A"], dtype=object),
        "td_event_lambda": np.zeros(len(positions), dtype=np.float32),
        "td_event_scale": np.zeros(len(positions), dtype=np.float32),
    }
    sims = nfl._simulate_players(base, trials=160_000, seed=24680)
    means = sims.mean(axis=1)
    sds = sims.std(axis=1)
    assert np.all(np.abs(means - 50.0) < 0.12)
    # Legacy kernel landed around 5.05-5.30 here because Var(z)<1.
    assert np.all(np.abs(sds - 6.0) < 0.12), sds


def test_centered_td_event_plus_continuous_component_preserves_total_variance():
    base = {
        "mu": np.array([50.0], dtype=np.float32),
        "sigma": np.array([6.0], dtype=np.float32),
        "pos": np.array(["RB"], dtype=object),
        "team": np.array(["A"], dtype=object),
        "td_event_lambda": np.array([0.50], dtype=np.float32),
        "td_event_scale": np.array([0.50], dtype=np.float32),
    }
    sims = nfl._simulate_players(base, trials=200_000, seed=13579)[0]
    assert abs(float(sims.mean()) - 50.0) < 0.10
    # event_var=4.5; continuous_var=31.5. Unit-normalized factor + centered
    # Poisson must restore total variance ~=36 before any floor clipping.
    assert abs(float(sims.var()) - 36.0) < 0.75, float(sims.var())


def test_unit_normalization_preserves_qb_wr_factor_correlation_shape():
    base = {
        "mu": np.array([50.0, 50.0], dtype=np.float32),
        "sigma": np.array([6.0, 6.0], dtype=np.float32),
        "pos": np.array(["QB", "WR"], dtype=object),
        "team": np.array(["A", "A"], dtype=object),
        "td_event_lambda": np.zeros(2, dtype=np.float32),
        "td_event_scale": np.zeros(2, dtype=np.float32),
    }
    sims = nfl._simulate_players(base, trials=200_000, seed=97531)
    observed = float(np.corrcoef(sims)[0, 1])
    cov = 0.20 * 0.18 + 0.22 * 0.19 + 0.28 * 0.32
    v_qb = 0.78**2 + 0.20**2 + 0.22**2 + 0.28**2
    v_wr = 0.78**2 + 0.18**2 + 0.19**2 + 0.32**2
    expected = cov / math.sqrt(v_qb * v_wr)
    assert abs(observed - expected) < 0.015, (observed, expected)


def test_patch_id_is_exposed():
    assert nfl.MC_LATENT_VARIANCE_NORMALIZATION_PATCH_ID == "NFL_SD_MC_LATENT_VARIANCE_NORMALIZATION_v1"
