from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
SRC=(ROOT/'engines/mlb/mlb_showdown_raw_pool_runtime_v1_7.py').read_text()
REC=json.loads((ROOT/'receipts/mlb_showdown_elite_dual_rp_scenario_v1/validation_receipt_v1.32.47.json').read_text())
D1=json.loads((ROOT/'doctrine/MLB_SHOWDOWN_ELITE_DUAL_RP_CONDITIONAL_RECALL_v1.json').read_text())
D2=json.loads((ROOT/'doctrine/MLB_SHOWDOWN_ELITE_DUAL_RP_SCENARIO_FAMILY_SELECTOR_v1.json').read_text())
def test_strict_four_signal_gate_wired():
 assert all(x in SRC for x in ['P95_2P5X','ONE_PLUS_IP','K_SPIKE_2PLUS','WIN_HOLD_ROLE'])
def test_dual_rp_cap_is_conditional_not_generic():
 assert 'elite_rp_count' in SRC and 'MLB_SD_ELITE_DUAL_RP_CONDITIONAL_RECALL_v1' in SRC
def test_phase2_elite_rp_recall_lanes_wired():
 assert 'ELITE_SINGLE_RP_TAIL_RECALL' in SRC and 'ELITE_DUAL_RP_TAIL_RECALL' in SRC
def test_scenario_selector_is_normal_market_only_and_highdual_bypassed():
 assert '_normal_market_elite_rp_family_closure' in SRC and '_high_dual_sp_cpt_market' in SRC
 assert D2['ACTIVATION_GATES']['HIGH_DUAL_SP_MARKET'].startswith('BYPASS')
def test_top01_threshold_not_top10_for_family_complementarity():
 assert D2['ACTIVATION_GATES']['TOP01_THRESHOLD']=='ACTUAL_COMMON_WORLD_TOP_0_1_THRESHOLD'
 assert D2['ACTIVATION_GATES']['TOP10_EQUIVALENT_THRESHOLD_FOR_FAMILY_COMPLEMENTARITY']=='PROHIBITED'
def test_2352_blind_acceptance_captures_winner_and_top3():
 b=REC['FINAL_50K_BLIND_BOARD']; assert b['ACTUAL_WINNER_BOARD_POSITION']==10 and b['ACTUAL_WINNER_REALIZED_CONTEST_RANK']==1 and b['TOP3_BOARD_COUNT']>=2
def test_perfect_not_forced():
 assert REC['GENERATION']['PERFECT_BORN'] is True and REC['FINAL_50K_BLIND_BOARD']['PERFECT_SELECTED'] is False
def test_941_1176_noop():
 for c in REC['CONTROLS'].values(): assert c['ELITE_RP_PAIR_EXISTS'] is False and c['NEW_NORMAL_MARKET_RP_SCENARIO_SELECTOR_CAN_ACTIVATE'] is False
def test_phase1_and_field_invariants():
 assert D1['HARD_GATES']['PHASE1_PLAYER_KERNEL_CHANGED'] is False and D1['HARD_GATES']['PUBLIC_FIELD_MODEL_CHANGED'] is False
