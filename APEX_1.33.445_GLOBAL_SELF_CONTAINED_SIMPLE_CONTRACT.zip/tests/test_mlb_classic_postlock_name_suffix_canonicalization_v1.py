from __future__ import annotations
import importlib.util
from pathlib import Path
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
MATCHER_PATH = ROOT / "engines/mlb/mlb_classic_postlock_contest_matcher_v1.py"
SPEC = importlib.util.spec_from_file_location("matcher_suffix_test", MATCHER_PATH)
M = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(M)


def test_identity_name_strips_only_trailing_generational_suffixes():
    assert M.identity_name("Rafael Flores Jr.") == M.identity_name("Rafael Flores")
    assert M.identity_name("Bobby Witt Jr.") == "bobby witt"
    assert M.identity_name("John Smith Sr") == "john smith"
    assert M.identity_name("John Smith II") == "john smith"
    assert M.identity_name("John Smith III") == "john smith"
    assert M.identity_name("John Smith IV") == "john smith"
    assert M.identity_name("Junior Caminero") == "junior caminero"


def test_parser_preserves_visible_suffix():
    lineup = "P A One P B Two C Rafael Flores Jr. 1B C Three 2B D Four 3B E Five SS F Six OF G Seven OF H Eight OF I Nine"
    known = {M.normalize_name(x) for x in ["A One","B Two","Rafael Flores Jr.","C Three","D Four","E Five","F Six","G Seven","H Eight","I Nine"]}
    names = M.parse_classic_lineup(lineup, known_players=known)
    assert "rafael flores jr" in names
    assert M.identity_name("rafael flores jr") == "rafael flores"


def test_identity_set_fails_closed_on_suffix_collision():
    with pytest.raises(RuntimeError, match="POSTLOCK_IDENTITY_CANONICALIZATION_COLLISION"):
        M.identity_set(["John Smith", "John Smith Jr."], "TEST")


def test_pool_contest_compatibility_accepts_suffix_drift(tmp_path):
    pool = tmp_path / "pool.csv"
    contest = tmp_path / "contest.csv"
    players_pool = ["A One","B Two","Rafael Flores","C Three","D Four","E Five","F Six","G Seven","H Eight","I Nine"]
    pd.DataFrame({"PLAYER": players_pool}).to_csv(pool, index=False)
    lineup = "P A One P B Two C Rafael Flores Jr. 1B C Three 2B D Four 3B E Five SS F Six OF G Seven OF H Eight OF I Nine"
    players_contest = ["A One","B Two","Rafael Flores Jr.","C Three","D Four","E Five","F Six","G Seven","H Eight","I Nine"]
    rows=[]
    for i,n in enumerate(players_contest):
        rows.append({"Rank":1,"Lineup":lineup,"Player":n})
    pd.DataFrame(rows).to_csv(contest, index=False)
    out=M.pool_contest_compatibility(pool, contest)
    assert out["POOL_CONTEST_COMPATIBILITY_PASS"] is True
    assert out["CONTEST_PLAYER_COVERAGE"] == 1.0
    assert out["WINNER_POOL_COVERAGE"] == 1.0
    assert out["WINNER_PLAYERS_MISSING_FROM_POOL"] == []
