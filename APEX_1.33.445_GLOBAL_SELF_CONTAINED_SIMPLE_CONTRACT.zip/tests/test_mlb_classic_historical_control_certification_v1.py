from __future__ import annotations
import copy, importlib.util, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "engines/mlb/mlb_classic_historical_control_certification_v1.py"
EVIDENCE = ROOT / "receipts/mlb_classic_cross_pattern_family_closure_v2_rebase/historical_control_evidence_v1.json"
DOCTRINE = ROOT / "doctrine/MLB_CLASSIC_HASH_ANCHORED_HISTORICAL_RAW_CONTROL_CERTIFICATION_v1.json"

def load():
    spec=importlib.util.spec_from_file_location("certmod", MODULE)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

def evidence(): return json.loads(EVIDENCE.read_text())

def test_official_hash_anchored_controls_pass():
    r=load().validate_evidence(evidence())
    assert r["STATUS"] == "PASS"
    assert r["ACCEPTED_CONTROLS"] == 2
    assert r["GLOBAL_CONTROL_GATE_SATISFIED"] is True
    assert r["AUTOMATIC_PRODUCTION_PROMOTION_ALLOWED"] is False

def test_duplicate_pool_hash_fails_closed():
    e=evidence(); e["CONTROLS"][1]["POOL_SHA256"]=e["CONTROLS"][0]["POOL_SHA256"]
    r=load().validate_evidence(e)
    assert r["STATUS"] == "FAIL_CLOSED" and "DISTINCT_POOL_HASH_DEFICIT" in r["FAILURES"]

def test_target_pool_collision_fails_closed():
    e=evidence(); e["CONTROLS"][0]["POOL_SHA256"]=e["TARGET_POOL_SHA256_EXCLUDED"]
    r=load().validate_evidence(e)
    assert r["STATUS"] == "FAIL_CLOSED"
    assert any("TARGET_POOL_HASH_COLLISION" in x for x in r["FAILURES"])

def test_reference_without_byte_complete_source_proof_fails_closed():
    e=evidence(); e["CONTROLS"][0]["BYTE_COMPLETE_SOURCE_PROOF"]=False
    r=load().validate_evidence(e)
    assert r["STATUS"] == "FAIL_CLOSED"

def test_doctrine_preserves_postlock_and_auto_promotion_boundaries():
    d=json.loads(DOCTRINE.read_text())
    assert d["ACCEPTANCE_CONTRACT"]["MINIMUM_DISTINCT_CONTROLS"] == 2
    assert d["BOUNDARIES"]["POSTLOCK_FIELDS_ENTER_FORWARD_GENERATION"] is False
    assert d["BOUNDARIES"]["SELECTOR_WEIGHTS_MUTATED"] is False
    assert d["BOUNDARIES"]["AUTOMATIC_PRODUCTION_PROMOTION_ALLOWED"] is False
