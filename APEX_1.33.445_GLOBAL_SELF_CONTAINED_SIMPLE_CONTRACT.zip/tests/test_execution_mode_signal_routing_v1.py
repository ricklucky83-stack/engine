from __future__ import annotations
import json, zipfile
from pathlib import Path
from apex_execution_mode_router_v1 import classify_execution_mode, is_contest_results_file
ROOT=Path(__file__).resolve().parents[1]
TEMPLATE="""1 DK
2 MLB
3 CLASSIC
4 2941
RUN SKILL ENG
BOOTSTRAP
**READ ENG DOCTRINE FIRST!!!"""

def test_code_only_doctrine_locked_and_authoritative():
    d=json.loads((ROOT/'doctrine/APEX_PRODUCTION_CODE_ONLY_EXECUTION_v1.json').read_text())
    assert d['STATUS']=='LOCKED_HARD_GATE'
    assert d['DEFAULT_MODE']=='LIVE_PRODUCTION_CODE_ONLY'
    assert any('authoritative POSTLOCK_DIAGNOSTIC signal' in x for x in d['RULES'])

def test_template_means_live_without_contest_file():
    r=classify_execution_mode(TEMPLATE,[])
    assert r['EXECUTION_MODE']=='LIVE_PRODUCTION'
    assert r['MODE_SIGNAL']=='LIVE_RUN_TEMPLATE'

def test_bootstrap_and_read_doctrine_do_not_trigger_diagnostics():
    r=classify_execution_mode(TEMPLATE,[])
    assert r['CONTEST_FILE_DETECTED'] is False

def test_contest_filename_overrides_live_template(tmp_path):
    p=tmp_path/'contest-standings-123.zip'; p.write_bytes(b'not-needed-for-name-signal')
    r=classify_execution_mode(TEMPLATE,[str(p)])
    assert r['EXECUTION_MODE']=='POSTLOCK_DIAGNOSTIC'

def test_contest_schema_overrides_live_template(tmp_path):
    p=tmp_path/'results.csv'; p.write_text('Rank,Lineup,Points\n1,P A P B,100\n')
    assert is_contest_results_file(p)
    assert classify_execution_mode(TEMPLATE,[str(p)])['EXECUTION_MODE']=='POSTLOCK_DIAGNOSTIC'

def test_zip_schema_detected(tmp_path):
    p=tmp_path/'data.zip'
    with zipfile.ZipFile(p,'w') as z: z.writestr('entries.csv','Rank,Lineup,Points\n1,P A P B,100\n')
    assert is_contest_results_file(p)

def test_player_pool_does_not_trigger_diagnostics(tmp_path):
    p=tmp_path/'rw-mlb-player-pool.csv'; p.write_text('Name,Salary,TeamAbbrev\nA,5000,X\n')
    assert classify_execution_mode(TEMPLATE,[str(p)])['EXECUTION_MODE']=='LIVE_PRODUCTION'

def test_mlb_dispatcher_routes_contest_to_postlock():
    text=(ROOT/'engines/mlb/apex_mlb_master_engine_dispatch_v1_20_2.py').read_text()
    assert "if args.contest_file:" in text
    assert "POSTLOCK_ROUTER" in text
    assert "RUN_INVALID_DIAGNOSTIC_INPUT_ON_PRODUCTION_TRIGGER" not in text

def test_bootstrap_auto_mode_router():
    text=(ROOT/'apex_regular_chat_bootstrap.py').read_text()
    assert "choices=('AUTO','PRODUCTION','POSTLOCK_DIAGNOSTIC')" in text
    assert "classify_execution_mode" in text
    assert "POSTLOCK_DIAGNOSTIC_ROUTER_NEXT" in text


def test_plain_four_line_template_means_live():
    r=classify_execution_mode('1 DK\n2 MLB\n3 SHOWDOWN\n4 941',[])
    assert r['EXECUTION_MODE']=='LIVE_PRODUCTION'
    assert r['MODE_SIGNAL']=='LIVE_RUN_TEMPLATE'

def test_standalone_contest_file_is_postlock(tmp_path):
    p=tmp_path/'contest-standings-941.zip'; p.write_bytes(b'x')
    r=classify_execution_mode('',[str(p)])
    assert r['EXECUTION_MODE']=='POSTLOCK_DIAGNOSTIC'
    assert r['MODE_SIGNAL']=='CONTEST_RESULTS_FILE'
