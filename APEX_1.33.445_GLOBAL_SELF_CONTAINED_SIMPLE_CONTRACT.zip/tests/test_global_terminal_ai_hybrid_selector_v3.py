import importlib.util, json, subprocess, sys
from pathlib import Path
import pytest

ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'engines/common/apex_terminal_ai_hybrid_selector_v3.py'
s=importlib.util.spec_from_file_location('aihyb_v3',P); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)

def rows(n=8):
    out=[]
    for i in range(n):
        out.append({'LINEUP_ID':str(i),'LINEUP_INDEX':i,'CPT':f'C{i}','UTIL1':f'A{i}','UTIL2':f'B{i}','UTIL3':f'D{i}','UTIL4':f'E{i}','UTIL5':f'F{i}',
                    'SALARY':48000+i*100,'BRANCH':'5-1','ROUTE':'TEST','SP_COUNT':0,'CPT_IS_SP':False,'RP_COUNT':0,
                    'OPPOSING_HITTERS_VS_SOLE_SP':0,'MAX_OPPOSING_HITTERS_VS_ROSTERED_SP':0,'SELF_CONFLICT_SEVERITY':'NONE','SIDE_COMMITMENT_SEVERITY':'NONE',
                    'MC_TRIALS':50000,'MC_WIN_RATE':.01+i/1000,'MC_WIN_LCB':.009+i/1000,'MC_TOP_0_1_RATE':.03+i/1000,'MC_TOP_0_1_LCB':.029+i/1000,
                    'MC_P95':90+i,'MC_P99':100+i,'CURRENT_SELECTOR_SELECTED':i<5,'CURRENT_SELECTOR_PRE_SCORE':i/10})
    return out

def decision(ids, h):
    return {'candidate_freeze_sha256':h,'selections':[{'lineup_id':str(i),'reason_codes':['ELITE_TOP_0_1_PATH','PORTFOLIO_MARGINAL_VALUE']} for i in ids]}

def test_full_handoff_receipt_explicitly_forbids_pruning(tmp_path):
    r=rows(27)
    rec=m.write_review_surface(r,csv_path=tmp_path/'c.csv',receipt_path=tmp_path/'r.json',sport='PGA',mode='CLASSIC',execution_id='X')
    assert rec['CANDIDATE_COUNT']==27
    assert rec['FULL_HANDOFF_REQUIRED'] is True
    assert rec['NO_PRUNING'] is True
    assert rec['NO_TOP_N_SIEVE'] is True
    assert rec['NO_AI_REVIEW_COHORT'] is True

def test_board_can_materialize_before_bad_hash_is_formally_rejected(tmp_path):
    r=rows(); good=m.freeze_candidates(r)
    d=decision([7,6,5,4,3], 'bad-hash')
    board=m.materialize_ai_board(r,d)
    assert [x['LINEUP_ID'] for x in board]==['7','6','5','4','3']
    with pytest.raises(m.TerminalAIHybridError):
        m.validate_ai_decision(r,d,expected_freeze_hash=good)

def test_valid_postboard_validation_preserves_exact_ids_order():
    r=rows(); h=m.freeze_candidates(r); d=decision([7,6,5,4,3],h)
    rendered=m.materialize_ai_board(r,d)
    validated,rec=m.validate_ai_decision(r,d,expected_freeze_hash=h)
    assert [x['LINEUP_ID'] for x in rendered]==[x['LINEUP_ID'] for x in validated]
    assert rec['TOP5_PARLAY_VALIDATED'] is True

def test_doctrine_is_global_full_handoff_and_board_first():
    d=json.loads((ROOT/'doctrine/APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v3.json').read_text())
    assert d['SCOPE']=='ALL_SPORTS_ALL_MODES'
    assert d['FULL_HANDOFF_CONTRACT']['NO_PRUNING'] is True
    assert d['FULL_HANDOFF_CONTRACT']['EVERY_QUALIFIED_LINEUP_AI_ELIGIBLE'] is True
    assert d['BOARD_FIRST_ORDER'][1]=='PRESENT_FINAL_BOARD_IMMEDIATELY'
