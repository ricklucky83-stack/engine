import copy, importlib, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'engines/common'),str(ROOT/'engines/mlb')]
from engines.common import apex_terminal_ai_hybrid_selector_v6 as ai
from engines.common import apex_elite_tail_propagation_v1 as elite


def _rows(n=12):
    out=[]
    for i in range(n):
        out.append({
            'LINEUP_ID':str(i+1),'CPT':f'P{i%4}','UTIL1':f'A{i}','UTIL2':f'B{i}','UTIL3':f'C{i}','UTIL4':f'D{i}','UTIL5':f'E{i}',
            'MC_WIN_RATE':0.001*(i+1),'MC_WIN_LCB':0.0008*(i+1),'MC_TOP_0_1_RATE':0.002*(i+1),'MC_TOP_0_1_LCB':0.0015*(i+1),
            'MC_P99':100+i,'MC_P95':90+i,'PROJECTED_EXACT_MATCH_DUPLICATION':float(i%3),'CURRENT_SELECTOR_PRE_SCORE':float(i),
            'MC_TRIALS':10000,'WORLD_COVERAGE_COUNT':i%5,'TOTAL_RECURRENCE':i%7,'BRANCH':'3-3','SP_COUNT':0,
            'CPT_CONDITIONAL_SUPPORT':0.5,'CPT_STRATEGIC_LEVERAGE':0.7,
        })
    return out

def _norm(rows):
    return json.dumps(rows,sort_keys=True,separators=(',',':'),default=str)

def test_inplace_enrichment_semantic_parity():
    a=_rows(); b=copy.deepcopy(a)
    x=ai.enrich_ai_evidence(a,sport='MLB',mode='SHOWDOWN',copy_rows=True)
    y=ai.enrich_ai_evidence(b,sport='MLB',mode='SHOWDOWN',copy_rows=False)
    assert _norm(x)==_norm(y)
    assert y is b

def test_elite_tail_inplace_semantic_parity():
    a=_rows(); b=copy.deepcopy(a)
    x=elite.enrich_elite_tail_lineage(a,sport='MLB',mode='SHOWDOWN',execution_id='T',copy_rows=True)
    y=elite.enrich_elite_tail_lineage(b,sport='MLB',mode='SHOWDOWN',execution_id='T',copy_rows=False)
    assert _norm(x)==_norm(y)
    assert y is b

def test_locked_streaming_global_invariant_still_registered():
    d=json.loads((ROOT/'doctrine/APEX_GLOBAL_TERMINAL_SURFACE_STREAMING_FREEZE_AND_LINEAR_FAMILY_INDEX_v1.json').read_text())
    assert 'COMPACT_SELECTOR_PROJECTION_ONLY' in d['CONTRACT']
    assert 'HYDRATE_ONLY_FINAL_SELECTED_ROWS' in d['CONTRACT']
    assert d['FULL_HANDOFF_PRUNING']==0
