import ast, importlib.util, json, sys
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
ENG=ROOT/'engines/mlb'
sys.path.insert(0,str(ENG))
spec=importlib.util.spec_from_file_location('mlb_sd_bulk_test',ENG/'mlb_showdown_raw_pool_runtime_v1_7.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def raw(ip=30.0,g=10,rst=5.0):
    rows=[]
    for team,opp in [('A','B'),('B','A')]:
        for order in range(1,10):
            rows.append({'PLAYER':f'{team}H{order}','TEAM':team,'OPP':opp,'LINEUP':str(order),'Opp Pitcher':f'{opp}SP','SAL':7000,'RST%':10})
        rows.append({'PLAYER':f'{team}SP','TEAM':team,'OPP':opp,'LINEUP':'SP','Opp Pitcher':'','SAL':11000,'RST%':50})
    rows.append({'PLAYER':'BULK_X','TEAM':'A','OPP':'B','LINEUP':'SP','Opp Pitcher':'','SAL':9600,'RST%':rst,'G':g,'IP':ip})
    return pd.DataFrame(rows)

def test_high_capacity_bulk_above_salary_tier_is_active():
    p=m.active_pool(raw(ip=40,g=10,rst=5)); assert 'BULK_X' in set(p.PLAYER); assert bool(p.loc[p.PLAYER.eq('BULK_X'),'_APEX_BULK_ROLE'].iloc[0])

def test_sub_three_ipg_bulk_is_not_active():
    p=m.active_pool(raw(ip=29,g=10,rst=5)); assert 'BULK_X' not in set(p.PLAYER)

def test_zero_rst_bulk_is_not_active():
    p=m.active_pool(raw(ip=40,g=10,rst=0)); assert 'BULK_X' not in set(p.PLAYER)

def test_no_postlock_player_name_constants_in_engine():
    src=(ENG/'mlb_showdown_raw_pool_runtime_v1_7.py').read_text(); vals={n.value for n in ast.walk(ast.parse(src)) if isinstance(n,ast.Constant) and isinstance(n.value,str)}
    assert not {'Adrian Houser','Osleivis Basabe','Kevin McGonigle','Rafael Devers','Willy Adames','Jung Hoo Lee'} & vals

def test_promotion_receipt_passes():
    r=json.loads((ROOT/'receipts/mlb_showdown_high_capacity_bulk_5_1_v1/validation_receipt_v1.32.16.json').read_text()); assert r['PASS'] is True; assert r['BLIND_CONTROLS_EXACT_CORE_NONREGRESSION'] is True; assert r['TARGET']['winner_selected_by_2rep'] is True
