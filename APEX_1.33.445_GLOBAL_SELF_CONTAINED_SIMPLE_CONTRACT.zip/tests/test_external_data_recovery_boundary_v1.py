from pathlib import Path
import importlib.util, tempfile, json
P=Path(__file__).resolve().parents[1]/'engines/common/apex_external_data_recovery_boundary_v1.py'
s=importlib.util.spec_from_file_location('r',P); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)

def test_parse_legacy_pregame_gap_and_request():
    r=m.detect(['Traceback','engines.common.X: RUN_RECOVERABLE:PREGAME_DATA_GAP:T_RUNS:TEAMS=CIN,MIL:DETAIL=PUBLIC_SEARCH_INJECT_RERUN_REQUIRED'])
    assert r['VARIABLE']=='T_RUNS' and r['ENTITIES']==['CIN','MIL']
    with tempfile.TemporaryDirectory() as d:
        q=m.build_request(recovery=r,sport='MLB',mode='SHOWDOWN',execution_id='941',output_dir=Path(d),env={'APEX_GLOBAL_STATE_VERSION':'1.33.171','APEX_PLAYER_POOL':'x','APEX_FIELD_SIZE':'941'},child_return_code=1)
        assert q['RUN_STATE']=='EXTERNAL_DATA_RECOVERY_REQUIRED'
        assert q['INJECTION_CONTRACT']['ENV']=='APEX_TEAM_RUN_TOTALS_JSON'
        assert Path(q['RECOVERY_REQUEST_PATH']).exists()

def test_parse_global_gap():
    r=m.detect(['RUN_RECOVERABLE:EXTERNAL_DATA_GAP:WEATHER:ENTITIES=GAME123:DETAIL=PUBLIC_RECOVERY_REQUIRED'])
    assert r['VARIABLE']=='WEATHER' and r['ENTITIES']==['GAME123']

def test_max_attempts_hard_stops():
    r={'VARIABLE':'T_RUNS','ENTITIES':['CIN','MIL'],'DETAIL':'x'}
    with tempfile.TemporaryDirectory() as d:
        q=m.build_request(recovery=r,sport='MLB',mode='SHOWDOWN',execution_id='941',output_dir=Path(d),env={'APEX_EXTERNAL_RECOVERY_ATTEMPT':'2'},child_return_code=1)
        assert q['RUN_STATE']=='RUN_INVALID'
