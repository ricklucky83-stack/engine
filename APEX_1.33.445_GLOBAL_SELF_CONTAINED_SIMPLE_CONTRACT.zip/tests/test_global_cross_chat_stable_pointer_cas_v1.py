import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(rel, name):
    spec = importlib.util.spec_from_file_location(name, ROOT / rel)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


class Registry:
    def __init__(self, payload):
        self.payload = dict(payload)
        self.file_id = payload["ACTIVE_POINTER_FILE_ID"]
        self.bytes = (json.dumps(self.payload, indent=2, sort_keys=True) + "\n").encode()

    def discover_exact_active_pointer(self):
        return {
            **self.payload,
            "FILE_ID": self.file_id,
            "TITLE": "APEX_GLOBAL_STATE_LATEST.txt",
            "EXACT_TITLE_COUNT": 1,
            "POINTER_BYTES_SHA256": hashlib.sha256(self.bytes).hexdigest(),
        }

    def compare_and_swap_pointer_in_place(self, **kw):
        assert kw["file_id"] == self.file_id
        assert kw["expected_pointer_sha256"] == hashlib.sha256(self.bytes).hexdigest()
        assert kw["expected_pointer_epoch"] == self.payload["POINTER_EPOCH"]
        self.payload = dict(kw["pointer_payload"])
        self.bytes = bytes(kw["pointer_bytes"])
        return {"CAS": "PASS"}


def test_stable_pointer_id_and_epoch_increment():
    m = load("engines/common/apex_stable_pointer_cas_v1.py", "cas")
    before = {
        "ACTIVE_POINTER_FILE": "APEX_GLOBAL_STATE_LATEST.txt",
        "ACTIVE_POINTER_FILE_ID": "stable-id",
        "POINTER_EPOCH": 11,
        "POINTER_CAPABILITIES": ["CONTENT_ADDRESSED_STATE_V1"],
        "STATE_VERSION": "1.33.177",
        "BUNDLE_SHA256": "a" * 64,
    }
    r = Registry(before)
    before = {**before, "POINTER_BYTES_SHA256": hashlib.sha256(r.bytes).hexdigest()}
    out = m.stable_pointer_cas(r, before=before, pointer_payload={**before, "STATE_VERSION": "1.33.178"})
    assert out["POINTER_STABLE_ID_CAS"] == "PASS"
    assert out["ACTIVE_POINTER_FILE_ID"] == "stable-id"
    assert out["POINTER_EPOCH"] == 12
    assert r.payload["ACTIVE_POINTER_FILE_ID"] == "stable-id"
    assert "STABLE_POINTER_IN_PLACE_CAS_V1" in r.payload["POINTER_CAPABILITIES"]


def test_stale_bytes_abort_before_write():
    m = load("engines/common/apex_stable_pointer_cas_v1.py", "cas2")
    before = {"ACTIVE_POINTER_FILE_ID": "stable-id", "POINTER_EPOCH": 3, "STATE_VERSION": "x"}
    r = Registry({**before, "ACTIVE_POINTER_FILE": "APEX_GLOBAL_STATE_LATEST.txt"})
    before["POINTER_BYTES_SHA256"] = "0" * 64
    try:
        m.stable_pointer_cas(r, before=before, pointer_payload=before)
    except m.StablePointerCASError as exc:
        assert "STALE_POINTER_BYTES" in str(exc)
    else:
        raise AssertionError("stale parent write was not rejected")
