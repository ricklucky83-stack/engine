from pathlib import Path
import importlib.util, ast, inspect
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('gate',ROOT/'engines/mlb/mlb_showdown_side_commitment_gate_v1.py')
gate=importlib.util.module_from_spec(spec); spec.loader.exec_module(gate)

def _meta(rows,branches,sp_count,team_runs=(4.9,4.8)):
    # 0=LAA SP, 1=HOU SP, 2..5=LAA hitters, 6..9=HOU hitters
    teams=np.asarray(['LAA','HOU']+['LAA']*4+['HOU']*4,object)
    tr=np.asarray([team_runs[0],team_runs[1]]+[team_runs[0]]*4+[team_runs[1]]*4,float)
    sal=np.asarray([10400,10000,9000,8200,7600,6200,11000,9600,8000,6000],float)
    order=np.asarray([99,99,1,2,3,5,1,2,4,7],np.int16)
    return {
        'idx':np.asarray(rows,np.int32), 'teams':teams,
        'sp_player_ids':np.asarray([0,1],np.int32), 'rp_player_ids':np.asarray([],np.int32),
        'sp_count':np.asarray(sp_count,np.int8), 'branch':np.asarray(branches,object),
        'team_runs':tr,'player_salary':sal,'batting_order':order,
    }

def test_exact_dual_sp_five_one_four_hitters_vs_opposing_sp_is_rejected():
    # LAA SP + 4 LAA hitters + HOU SP = 5-1, with four bats attacking HOU SP.
    m=_meta([[0,1,2,3,4,5]],['5-1'],[2]); e=gate.evaluate(m)
    assert bool(e['HARD_REJECT'][0])
    assert bool(e['FIVE_ONE_OPPOSING_SP_CONFLICT'][0])
    assert int(e['MAX_OPPOSING_HITTERS_VS_ROSTERED_SP'][0])==4

def test_five_one_with_premium_opposing_hitter_is_rewarded_not_rejected():
    # Five LAA pieces, lone HOU elite hitter.
    m=_meta([[0,2,3,4,5,6]],['5-1'],[1]); e=gate.evaluate(m)
    assert not bool(e['HARD_REJECT'][0])
    assert bool(e['COHERENT_FIVE_ONE_HITTER_RUNBACK'][0])
    assert bool(e['PREMIUM_ONEOFF_HITTER'][0])
    assert float(e['SIDE_COMMITMENT_BONUS'][0])==0.10

def test_four_hitters_vs_sp_outside_five_one_gets_strong_friction_not_ban():
    # 4 LAA hitters + HOU SP + HOU hitter = 4-2.
    m=_meta([[1,2,3,4,5,6]],['4-2'],[1]); e=gate.evaluate(m)
    assert not bool(e['HARD_REJECT'][0])
    assert float(e['CONFLICT_PENALTY'][0])>=0.24

def test_dual_sp_two_good_offenses_gets_friction_not_automatic_ban():
    m=_meta([[0,1,2,3,6,7]],['3-3'],[2],team_runs=(4.9,4.8)); e=gate.evaluate(m)
    assert not bool(e['HARD_REJECT'][0])
    assert bool(e['DUAL_SP_BOTH_GOOD_OFFENSES'][0])
    assert float(e['CONFLICT_PENALTY'][0])>=0.12

def test_primary_path_has_no_python_loop_and_no_extra_mc():
    tree=ast.parse(inspect.getsource(gate.evaluate))
    assert not any(isinstance(n,(ast.For,ast.While)) for n in ast.walk(tree))
    e=gate.evaluate(_meta([[0,2,3,4,5,6]],['5-1'],[1]))
    assert e['PERFORMANCE']['EXTRA_MONTE_CARLO_PASSES']==0
    assert e['PERFORMANCE']['POSTLOCK_INPUT_USED'] is False

def test_minority_sp_cpt_dual_sp_five_one_attack_hedge_is_allowed_with_friction():
    # HOU SP is the lone-side Captain; LAA SP + 4 LAA hitters form the majority side.
    # This dual-SP hedge remains risky but is no longer deleted before Phase 2.
    m=_meta([[1,0,2,3,4,5]],['5-1'],[2]); e=gate.evaluate(m)
    assert not bool(e['HARD_REJECT'][0])
    assert bool(e['DUAL_SP_ATTACK_HEDGE_5_1'][0])
    assert int(e['MAX_OPPOSING_HITTERS_VS_ROSTERED_SP'][0])==4
    assert float(e['CONFLICT_PENALTY'][0])>=0.24


def test_one_sp_plus_five_opposing_hitters_is_hard_reject_no_exception():
    # HOU SP + five LAA hitters: exact 1-SP + 5-opposing-hitter contradiction.
    # Expand local test metadata by reusing the four LAA hitters plus a duplicate-free
    # fifth hitter identity synthesized as player 10.
    teams=np.asarray(['LAA','HOU']+['LAA']*4+['HOU']*4+['LAA'],object)
    tr=np.asarray([4.9,4.8]+[4.9]*4+[4.8]*4+[4.9],float)
    sal=np.asarray([10400,10000,9000,8200,7600,6200,11000,9600,8000,6000,5000],float)
    order=np.asarray([99,99,1,2,3,5,1,2,4,7,8],np.int16)
    m={'idx':np.asarray([[1,2,3,4,5,10]],np.int32),'teams':teams,
       'sp_player_ids':np.asarray([0,1],np.int32),'rp_player_ids':np.asarray([],np.int32),
       'sp_count':np.asarray([1],np.int8),'branch':np.asarray(['5-1'],object),
       'team_runs':tr,'player_salary':sal,'batting_order':order}
    e=gate.evaluate(m)
    assert bool(e['HARD_REJECT'][0])
    assert bool(e['ONE_SP_FIVE_OPPOSING_HITTERS'][0])
    assert int(e['MAX_OPPOSING_HITTERS_VS_ROSTERED_SP'][0])==5
