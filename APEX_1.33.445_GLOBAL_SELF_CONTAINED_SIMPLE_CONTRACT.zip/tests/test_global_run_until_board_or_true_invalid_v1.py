from pathlib import Path
import importlib.util

ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'engines/common/apex_fast_path_execution_contract_v1.py'
spec=importlib.util.spec_from_file_location('fp',P)
fp=importlib.util.module_from_spec(spec); spec.loader.exec_module(fp)


def test_nonzero_exit_alone_is_recoverable():
    r=fp.terminal_disposition(run_state='FAILED',failure_code='MACHINE_BOARD_ARTIFACT_MISSING',child_return_code=9)
    assert r['DISPOSITION']=='RECOVERABLE_RETRY'


def test_missing_board_alone_is_recoverable():
    r=fp.terminal_disposition(run_state='',failure_code='STALE_OR_MISSING_MACHINE_BOARD_ARTIFACT',child_return_code=1)
    assert r['DISPOSITION']=='RECOVERABLE_RETRY'


def test_true_invalid_pool_missing_terminates():
    r=fp.terminal_disposition(run_state='RUN_INVALID',failure_code='PLAYER_POOL_MISSING:/tmp/pool.csv',child_return_code=2)
    assert r['DISPOSITION']=='TRUE_RUN_INVALID'


def test_true_invalid_manifest_hash_terminates():
    r=fp.terminal_disposition(run_state='RUN_INVALID',failure_code='INTERNAL_BUNDLE_MANIFEST_HASH_MISMATCH:engine_registry.json',child_return_code=2)
    assert r['DISPOSITION']=='TRUE_RUN_INVALID'


def test_recoverable_data_gap_does_not_terminate():
    r=fp.terminal_disposition(run_state='RUN_INVALID',failure_code='RECOVERABLE_EXTERNAL_DATA_GAP:WEATHER',child_return_code=7)
    assert r['DISPOSITION']=='RECOVERABLE_RETRY'
