from __future__ import annotations
import importlib.util
import sys
from collections import Counter
from pathlib import Path
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "engines" / "wnba" / "wnba_showdown_raw_pool_runtime_v6.py"
FIXTURE = ROOT / "tests" / "fixtures" / "wnba_showdown_627_pool.csv"
_spec = importlib.util.spec_from_file_location("wnba_sd_v6_test_module", ENGINE)
mod = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = mod
_spec.loader.exec_module(mod)
OUTS = ["Rickea Jackson", "Skylar Diggins"]
WINNER = ("Natasha Cloud", tuple(sorted(["Nneka Ogwumike", "Dearica Hamby", "Kamilla Cardoso", "Jacy Sheldon", "Rachel Banham"])))
PERFECT = ("Dearica Hamby", tuple(sorted(["Kamilla Cardoso", "Natasha Cloud", "Rae Burrell", "Jacy Sheldon", "Rachel Banham"])))


def lineup_key(cal, row):
    names = cal.frame.iloc[row]["PLAYER"].astype(str).tolist()
    return names[0], tuple(sorted(names[1:]))


@pytest.fixture(scope="module")
def built():
    cfg = mod.Config(
        field_size=627, seed=627, player_trials=2500, base_trials=1000,
        extra_trials=1500, phase2_global_keep=4000, phase2_macro_keep=24,
        phase2_core_family_limit=300, phase2_core_keep=12,
        phase2_value_family_limit=250, phase2_value_keep=24,
        phase2_role_keep=60, bubble_cap=64, board_size=10,
    )
    cal, ids = mod._load_calibration(FIXTURE, OUTS, cfg)
    legal, lmeta = mod._enumerate(cal, ids)
    phase2, pmeta = mod._phase2(legal, lmeta, cal, cfg)
    sim = mod._simulate(phase2, legal, pmeta, cal, cfg)
    board, metrics, state = mod._select(phase2, pmeta, sim, cal, cfg)
    return cfg, cal, ids, legal, lmeta, phase2, pmeta, sim, board, metrics, state


def test_explicit_family_birth_and_sibling_closure(built):
    cfg, cal, ids, legal, lmeta, phase2, pmeta, sim, board, metrics, state = built
    assert len(legal) > 150000
    assert len(phase2) < len(legal)
    assert np.unique(pmeta["macro_family_id"]).size == int(pmeta["macro_family_count_all"][0])
    assert np.count_nonzero(pmeta["birth_reason"] & 4) > 0
    assert np.count_nonzero(pmeta["birth_reason"] & 8) > 0
    assert set(np.unique(pmeta["birth_reason"])) != {1}


def test_winner_and_perfect_are_born(built):
    _, cal, _, _, _, phase2, _, _, _, _, _ = built
    keys = {lineup_key(cal, row) for row in phase2}
    assert WINNER in keys
    assert PERFECT in keys


def test_showdown_role_tail_guard_removes_double_tail(built):
    _, cal, *_ = built
    audit = {x["PLAYER"]: x for x in cal.showdown_tail_guard_audit}
    assert audit["Courtney Vandersloot"]["P99_AFTER"] < audit["Courtney Vandersloot"]["P99_BEFORE"]
    assert audit["Elizabeth Williams"]["P99_AFTER"] < audit["Elizabeth Williams"]["P99_BEFORE"]
    assert audit["Courtney Vandersloot"]["P99_AFTER"] <= 72.0
    assert audit["Elizabeth Williams"]["P99_AFTER"] <= 58.0


def test_atomic_family_bundle_is_selected(built):
    cfg, cal, ids, legal, lmeta, phase2, pmeta, sim, board, metrics, state = built
    bundle = np.asarray(metrics["required_family_bundle"], dtype=int)
    assert 2 <= len(bundle) <= cfg.value_pair_bundle_cap
    assert np.isin(bundle, metrics["chosen"]).all()
    assert state.startswith("STRICT_FAMILY_MILP_COMPLETE")
    assert metrics["selector_mode"][0] == "EXPLICIT_FAMILY_BIRTH_STRICT_MILP"


def test_full_review_legality_and_exposure_caps(built):
    cfg, cal, ids, legal, lmeta, phase2, pmeta, sim, board, metrics, state = built
    assert metrics["selector_reviewed"][0] == len(phase2)
    assert len(board) == cfg.board_size
    player_counts = Counter(int(x) for row in board for x in row)
    captain_counts = Counter(int(row[0]) for row in board)
    script_counts = Counter(int(x) for x in pmeta["script"][metrics["chosen"]])
    assert max(player_counts.values()) <= cfg.player_exposure_cap
    assert max(captain_counts.values()) <= cfg.captain_exposure_cap
    assert max(script_counts.values()) <= cfg.script_exposure_cap
    salaries = pmeta["salary"][metrics["chosen"]]
    assert np.all((salaries >= mod.SALARY_MIN) & (salaries <= mod.SALARY_MAX))


def test_no_player_name_constants_in_forward_engine():
    text = ENGINE.read_text(encoding="utf-8")
    for name in ("Rachel Banham", "Jacy Sheldon", "Natasha Cloud", "Dearica Hamby"):
        assert name not in text
