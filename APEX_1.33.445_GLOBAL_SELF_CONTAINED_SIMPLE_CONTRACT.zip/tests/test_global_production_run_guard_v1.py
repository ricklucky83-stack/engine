import hashlib, json
from pathlib import Path
import pytest
from engines.common.apex_production_run_guard_v1 import (
    ProductionGuardError, parse_production_directives, build_immutable_run_lock,
    assert_run_lock_unchanged, require_fresh_run_after_repair, validate_stage_claim,
    integrity_failure_receipt,
)

def test_directives_are_hard_signals():
    d=parse_production_directives('RUN SKILL ENG BOARD PRIORITY NO DIAGNOSTICS, AUDITS')
    assert d['BOARD_PRIORITY'] is True
    assert d['NO_DIAGNOSTICS'] is True
    assert d['NO_AUDITS'] is True

def test_run_lock_detects_midrun_mutation(tmp_path):
    p=tmp_path/'engine.py'; p.write_text('x=1\n')
    h=hashlib.sha256(p.read_bytes()).hexdigest()
    lock=build_immutable_run_lock(state_version='1.0',bundle_sha256='abc',engine_id='E',engine_root=tmp_path,expected_hashes={'engine.py':h},command_text='BOARD PRIORITY')
    assert assert_run_lock_unchanged(lock,tmp_path)['PRODUCTION_RUN_IMMUTABILITY_CHECK']=='PASS'
    p.write_text('x=2\n')
    with pytest.raises(ProductionGuardError,match='PRODUCTION_RUN_MUTATED_RESTART_REQUIRED'):
        assert_run_lock_unchanged(lock,tmp_path)

def test_repair_cannot_resume_same_state():
    lock={'STATE_VERSION':'1.0'}
    with pytest.raises(ProductionGuardError,match='FRESH_STATE_REQUIRED'):
        require_fresh_run_after_repair(lock,'1.0')
    assert require_fresh_run_after_repair(lock,'1.1')['REPAIR_COMMIT_GATE']=='PASS'

def test_unproven_status_claims_fail_closed():
    with pytest.raises(ProductionGuardError,match='UNPROVEN_STAGE_CLAIM_PROHIBITED:PHASE1'):
        validate_stage_claim('PHASE1',{'BASE_SIM_TRIALS':50000})
    with pytest.raises(ProductionGuardError,match='UNPROVEN_STAGE_CLAIM_PROHIBITED:BOARD'):
        validate_stage_claim('BOARD',{'FINAL_BOARD_SIZE':1,'BOARD_IDENTITY_RECONCILIATION':'PASS'})

def test_proven_status_claims_pass():
    assert validate_stage_claim('PHASE1',{'BASE_SIM_TRIALS':50000,'PHASE1_CALIBRATION_HASH':'h'})['CLAIM']=='PROVEN'
    assert validate_stage_claim('PHASE2',{'PHASE2_BUILT_LINEUPS':1})['CLAIM']=='PROVEN'
    assert validate_stage_claim('HANDOFF',{'HANDOFF_SURVIVORS':1})['CLAIM']=='PROVEN'
    assert validate_stage_claim('SELECTOR',{'SELECTOR_REVIEWED_LINEUPS':1})['CLAIM']=='PROVEN'
    assert validate_stage_claim('BOARD',{'FINAL_BOARD_SIZE':1,'BOARD_IDENTITY_RECONCILIATION':'PASS','DK_LEGALITY':'PASS'})['CLAIM']=='PROVEN'

def test_integrity_failure_is_internal_recovery_signal_not_terminal():
    r=integrity_failure_receipt('ENGINE_FILE_HASH_MISMATCH')
    assert r['RUN_STATE']=='RECOVERY_REQUIRED'
    assert r['MIDRUN_FIX_PROHIBITED'] is True
    assert r['RECOVERY_REQUIRED'] is True
    assert r['TERMINAL_USER_FAILURE_ALLOWED'] is False
    assert r['NEXT_ALLOWED_ACTION']=='AUTO_RECOVER_AND_RESUME_TO_BOARD'
