from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from engines.mma.mma_joint_fight_engine_v1 import MMAConfig, load_slate, pipeline, simulate_phase1

ROWS = [
('Alpha','a1',9400,'Bravo',68,62,4.8,3.1,2.2,48,76,.5,.7,65,18,3,31),('Bravo','b1',6800,'Alpha',32,40,3.5,4.5,1.1,38,60,.4,.3,42,20,3,12),
('Charlie','c1',9000,'Delta',64,48,3.9,2.8,3.8,52,81,1.2,.2,30,55,3,27),('Delta','d1',7200,'Charlie',36,43,4.1,4.0,.8,34,58,.2,.4,58,12,3,15),
('Echo','e1',8700,'Foxtrot',59,52,5.4,4.1,.5,30,73,.1,.9,78,8,3,24),('Foxtrot','f1',7500,'Echo',41,46,4.7,4.9,1.4,42,64,.3,.5,62,14,3,18),
('Golf','g1',8400,'Hotel',57,37,3.2,2.6,4.9,61,88,1.8,.1,18,70,3,22),('Hotel','h1',7800,'Golf',43,34,2.9,3.5,2.6,49,67,1.0,.1,22,58,3,19),
('India','i1',8200,'Juliet',54,45,6.1,5.2,.3,28,70,0,1.1,86,4,5,21),('Juliet','j1',8000,'India',46,38,5.8,6.0,.1,20,62,.1,.8,82,6,5,20),
('Kilo','k1',7900,'Lima',51,50,3.6,3.7,2.9,46,74,.8,.4,46,40,3,20),('Lima','l1',7900,'Kilo',49,49,3.7,3.6,2.7,45,73,.9,.4,45,43,3,20),
]
COLS=['PLAYER','ID','SAL','OPPONENT','WIN %','FINISH %','SIG STR LPM','SIG STR ABS LPM','TAKEDOWNS','TD ACC%','TD DEF%','SUB AVG','KNOCKDOWNS','KO %','SUB %','ROUNDS','RST%']

def pool(tmp_path: Path) -> Path:
    p=tmp_path/'mma.csv'; pd.DataFrame(ROWS,columns=COLS).to_csv(p,index=False); return p

def cfg(mode_seed=7):
    return MMAConfig(field_size=1000,seed=mode_seed,player_trials=1024,base_trials=256,max_physical_trials=1024,phase2_max=700,fake_field_cap=256,board_size=5)

def test_joint_fight_mutual_exclusivity_and_shared_finish(tmp_path):
    s=load_slate(pool(tmp_path),mode='CLASSIC')
    p1=simulate_phase1(s,cfg())
    for i,j in enumerate(s.opponent_index):
        if i < j:
            assert np.all(p1.wins[:,i].astype(np.int8)+p1.wins[:,j].astype(np.int8)==1)
            assert not np.any(p1.finishes[:,i] & p1.finishes[:,j])

def test_classic_full_review_parity_and_legality(tmp_path):
    board,r,s,p1,p2=pipeline(pool(tmp_path),1000,mode='CLASSIC',config=cfg())
    assert len(board)==5
    assert board['SALARY'].max() <= 50000
    assert r['PHASE2_BUILT_LINEUPS']==r['HANDOFF_SURVIVORS']==r['SELECTOR_REVIEWED_LINEUPS']==r['FULL_REVIEW_LEDGER_ROWS']
    assert r['PHASE2_FREEZE_HASH']==r['PHASE3_INPUT_HASH']==r['HANDOFF_INPUT_HASH']==r['SELECTOR_INPUT_HASH']
    assert r['POST_PHASE2_MUTATION_COUNT']==0
    assert r['RAW_AGGREGATE_PROJECTION_PHASE1']=='PROHIBITED_WEAK_PRIOR_NOT_CONSUMED_BY_PHASE1'
    assert r['WEIGHTED_METRIC_SUM_USED'] is False

def test_showdown_captain_unique_identity_and_salary(tmp_path):
    board,r,s,p1,p2=pipeline(pool(tmp_path),1000,mode='SHOWDOWN',config=cfg(11))
    assert len(board)==5
    assert board['SALARY'].max() <= 50000
    for _,row in board.iterrows():
        names=[row['CPT']]+[row[f'FLEX{i}'] for i in range(1,6)]
        assert len(set(names))==6
    assert r['MODE']=='SHOWDOWN'
    assert r['SELECTOR_REVIEWED_LINEUPS']==r['PHASE2_BUILT_LINEUPS']

def test_orphan_bout_is_purged_not_synthetically_paired(tmp_path):
    df=pd.DataFrame(ROWS,columns=COLS)
    df.loc[len(df)] = ['Orphan','o1',7000,'Missing',40,35,3,3,1,40,60,.2,.2,40,20,3,5]
    p=tmp_path/'orphan.csv'; df.to_csv(p,index=False)
    s=load_slate(p,mode='CLASSIC')
    assert 'Orphan' in s.orphan_names
    assert 'Orphan' not in s.names

def test_forward_postlock_fields_fail_closed(tmp_path):
    df=pd.DataFrame(ROWS,columns=COLS); df['ACTUAL_FPTS']=0
    p=tmp_path/'bad.csv'; df.to_csv(p,index=False)
    with pytest.raises(RuntimeError,match='POSTLOCK_FIELDS'):
        load_slate(p,mode='CLASSIC')
