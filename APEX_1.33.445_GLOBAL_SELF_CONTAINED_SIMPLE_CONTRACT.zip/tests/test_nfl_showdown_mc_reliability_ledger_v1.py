from __future__ import annotations
import json
from types import SimpleNamespace
import numpy as np
import pandas as pd
from engines.nfl import nfl_showdown_mc_reliability_ledger_v1 as m


def _fixture(n=4):
    rows=np.array([[0,1,2,3,4,5],[1,0,2,3,4,5],[2,0,1,3,4,5],[3,0,1,2,4,5]],dtype=np.int32)[:n]
    metrics={
        'win_count':np.arange(n,dtype=np.int32),'top0050_count':np.arange(n,dtype=np.int32)+1,
        'top0100_count':np.arange(n,dtype=np.int32)+2,'top01_count':np.arange(n,dtype=np.int32)+3,
        'top10_count':np.arange(n,dtype=np.int32)+4,'trials':np.full(n,10000,dtype=np.int32),
        'win_rate':np.arange(n)/10000,'top0050_rate':(np.arange(n)+1)/10000,
        'top0100_rate':(np.arange(n)+2)/10000,'top01_rate':(np.arange(n)+3)/10000,
        'top10_rate':(np.arange(n)+4)/10000,'p95':np.arange(n)+80.,'p99':np.arange(n)+95.,
    }
    pmeta={'salary':np.full(n,49000),'score':np.arange(n,dtype=float)}
    cal=SimpleNamespace(ids=np.arange(6),pos=np.array(['QB','RB','WR','TE','K','DST']),team=np.array(['A','A','A','B','B','B']),frame=pd.DataFrame({'PLAYER':['p0','p1','p2','p3','p4','p5']}))
    return rows,pmeta,metrics,cal


def test_freeze_is_prelock_complete_and_hash_verified(tmp_path):
    rows,pmeta,metrics,cal=_fixture(); path=tmp_path/'surface.npz'; meta=tmp_path/'surface.json'
    r=m.freeze_prelock_surface(rows,pmeta,metrics,cal,field_size=88235,seed=7,execution_id='X',output_path=path,metadata_path=meta,public_field_source_hash='abc')
    assert r['PATCH_ID']==m.PATCH_ID and r['ROWS']==4
    assert r['PRELOCK_SURFACE_FROZEN'] is True and r['SAME_SLATE_POSTLOCK_OUTCOME_PRESENT'] is False
    assert r['POSTLOCK_FORWARD_INPUT_USED'] is False and r['SELECTOR_MEMBERSHIP_MUTATION'] is False
    z=m.read_surface(path,r['SURFACE_SHA256']); assert np.array_equal(z['rows'],rows)
    assert 'metric__top01_rate' in z and 'pmeta__salary' in z
    assert json.loads(meta.read_text())['PHASE2_SHA256']==r['PHASE2_SHA256']


def test_read_fails_closed_on_hash_mismatch(tmp_path):
    rows,pmeta,metrics,cal=_fixture(); path=tmp_path/'surface.npz'
    m.freeze_prelock_surface(rows,pmeta,metrics,cal,field_size=10,seed=1,execution_id='X',output_path=path)
    try: m.read_surface(path,'0'*64)
    except RuntimeError as e: assert 'HASH_MISMATCH' in str(e)
    else: raise AssertionError('expected fail closed')


def test_postlock_grade_does_not_mutate_or_claim_forward_authority(tmp_path):
    rows,pmeta,metrics,cal=_fixture(); path=tmp_path/'surface.npz'
    r=m.freeze_prelock_surface(rows,pmeta,metrics,cal,field_size=100,seed=1,execution_id='X',output_path=path)
    z=m.read_surface(path,r['SURFACE_SHA256'])
    actual=np.array([20,10,8,7,6,5],dtype=float)
    before=z['metric__top01_rate'].copy()
    g=m.grade_surface(z,actual,{'win':60,'top0050':55,'top0100':50,'top01':45})
    assert g['POSTLOCK_EVALUATION_ONLY'] is True and g['FORWARD_INPUT_TO_SOURCE_SLATE'] is False
    assert np.array_equal(before,z['metric__top01_rate'])
    assert set(g['METRICS'])=={'win','top0050','top0100','top01'}


def test_actual_scoring_captain_multiplier():
    rows,_,_,_=_fixture(1); actual=np.array([20,10,8,7,6,5],dtype=float)
    s=m.score_rows_from_actual_points(rows,actual)
    assert float(s[0])==20*1.5+10+8+7+6+5
