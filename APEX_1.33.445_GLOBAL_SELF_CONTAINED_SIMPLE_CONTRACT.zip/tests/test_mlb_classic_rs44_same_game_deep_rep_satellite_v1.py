from engines.mlb.mlb_classic_rs44_same_game_deep_rep_satellite_v1 import SatelliteCandidate, apply_satellite, GENERATOR_PATCH_ID

def c(pos, lid, *, pair=('A','B'), reps=('LAST','LAST'), obj=.9, top=.003, salary=46000, birth=GENERATOR_PATCH_ID):
    return SatelliteCandidate(pos,lid,birth,salary,pair,reps[0],reps[1],obj,top)

def base():
    core=[0,1,2,3,4]
    cs=[c(i,f'C{i}',birth='BASE',obj=.99-i*.01,top=.006-i*.0002) for i in core]
    return core,cs

def test_active_preserves_four_core_and_one_satellite():
    core,cs=base(); cs.append(c(8,'S',obj=.885,top=.0031))
    out,r=apply_satellite(core_positions=core,candidates=cs,team_opponents={'A':'B','B':'A'},salary_floor=46000)
    assert out==[0,1,2,3,8]; assert r['STATUS']=='ACTIVE'; assert r['SELECTED_SATELLITE_LINEUP_ID']=='S'

def test_non_mutual_pair_noop():
    core,cs=base(); cs.append(c(8,'S'))
    out,r=apply_satellite(core_positions=core,candidates=cs,team_opponents={'A':'C','B':'D'},salary_floor=46000)
    assert out==core; assert r['STATUS'].startswith('NOOP')

def test_mid_rep_noop():
    core,cs=base(); cs.append(c(8,'S',reps=('MID','MID')))
    out,r=apply_satellite(core_positions=core,candidates=cs,team_opponents={'A':'B','B':'A'},salary_floor=46000)
    assert out==core

def test_objective_gate_noop():
    core,cs=base(); cs.append(c(8,'S',obj=.79))
    out,r=apply_satellite(core_positions=core,candidates=cs,team_opponents={'A':'B','B':'A'},salary_floor=46000)
    assert out==core

def test_tail_retention_gate_noop():
    core,cs=base(); cs.append(c(8,'S',obj=.9,top=.001))
    out,r=apply_satellite(core_positions=core,candidates=cs,team_opponents={'A':'B','B':'A'},salary_floor=46000)
    assert out==core
