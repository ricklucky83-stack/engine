from pathlib import Path
import importlib.util, sys, copy
ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'engines/common/apex_terminal_ai_hybrid_selector_v6.py'
spec=importlib.util.spec_from_file_location('apex_terminal_ai_hybrid_selector_v6',P)
mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)


def row(lid, lowown, mc):
    owns=[46,38,31,22,lowown,18]
    ceilings=[.97,.92,.89,.84,.94,.78]
    return {
      'LINEUP_ID':str(lid),'CPT':f'C{lid}','UTIL1':f'A{lid}','UTIL2':f'B{lid}','UTIL3':f'D{lid}','UTIL4':f'E{lid}','UTIL5':f'F{lid}',
      'CPT_TEAM':'A','UTIL1_TEAM':'A','UTIL2_TEAM':'A','UTIL3_TEAM':'B','UTIL4_TEAM':'A','UTIL5_TEAM':'B',
      'CPT_ORDER':1,'UTIL1_ORDER':2,'UTIL2_ORDER':3,'UTIL3_ORDER':4,'UTIL4_ORDER':5,'UTIL5_ORDER':6,
      'SALARY':49000,'SALARY_RELEASE_SCORE':5.0,'PROJECTED_EXACT_MATCH_DUPLICATION':1.0,
      'PLAYER_ROSTER_OWNERSHIP_PCTS':str(owns),'PLAYER_OWNERSHIP_PCTLS':str([.95,.85,.75,.55,.1,.4]),
      'PLAYER_CEILING_PCTLS':str(ceilings),'PLAYER_SALARY_UNLOCK_FLAGS':str([0,0,0,0,1,0]),'PLAYER_STRATEGIC_LEVERAGE':str([0,0,0,0,1,0]),
      'MC_TRIALS':10000,'MC_WIN_RATE':mc,'MC_WIN_LCB':mc*.9,'MC_TOP_0_1_RATE':mc*2,'MC_TOP_0_1_LCB':mc*1.8,'MC_P95':80+mc,'MC_P99':100+mc,
      'GLOBAL_CORE_PROTECTED':False,'CURRENT_SELECTOR_PRE_SCORE':mc,
    }


def test_mlb_championship_quality_is_winner_shape_not_mc():
    a=[row(i,7+i,0.001*i) for i in range(1,7)]
    b=copy.deepcopy(a)
    for i,r in enumerate(b,1):
        r['MC_WIN_RATE']=.20/i; r['MC_WIN_LCB']=.18/i; r['MC_TOP_0_1_RATE']=.30/i; r['MC_TOP_0_1_LCB']=.27/i; r['MC_P99']=200-i*10
    ea=mod.enrich_ai_evidence(a,sport='MLB',mode='SHOWDOWN')
    eb=mod.enrich_ai_evidence(b,sport='MLB',mode='SHOWDOWN')
    assert [r['AI_WINNER_SHAPE_SCORE'] for r in ea]==[r['AI_WINNER_SHAPE_SCORE'] for r in eb]
    assert [r['AI_CHAMPIONSHIP_QUALITY_PCTL'] for r in ea]==[r['AI_CHAMPIONSHIP_QUALITY_PCTL'] for r in eb]
    assert all(r['AI_MC_TERMINAL_AUTHORITY'] is False for r in ea)
    assert any(r['AI_MC_DIAGNOSTIC_QUALITY_PCTL'] != q['AI_MC_DIAGNOSTIC_QUALITY_PCTL'] for r,q in zip(ea,eb))


def test_primary_order_puts_mc_last():
    order=mod.GLOBAL_MISPRICED_CEILING_POLICY['primary_order']
    assert order[0]=='WINNER_SHAPE'
    assert order[1]=='OWNERSHIP_SHAPE'
    assert order[-1]=='MC_DIAGNOSTIC_SUPPORT_ONLY'
    assert mod.MC_TERMINAL_AUTHORITY is False
