from __future__ import annotations
import importlib.util, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / 'engines' / 'common' / 'apex_global_championship_core_v1.py'
spec = importlib.util.spec_from_file_location('champ_core_test', MOD)
mod = importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)


def _row(cpt, utils):
    return {'CPT': cpt, 'UTIL': utils, 'salary': 49000}


def test_core5_presses_dense_one_swap_family_and_keeps_counter_scripts():
    rows = [
        _row('A',['B','C','D','E','F']),      # 1
        _row('G',['H','I','J','K','L']),      # 2
        _row('M',['N','O','P','Q','R']),      # 3
        _row('S',['T','U','V','W','X']),      # 4
        _row('S',['T','U','V','W','Y']),      # 5
        _row('S',['T','U','V','W','Z']),      # 6
        _row('G',['H','I','J','K','AA']),     # 7
        _row('AB',['AC','AD','AE','AF','AG']),# 8
        _row('A',['B','C','D','E','H']),      # 9
        _row('A',['B','C','D','E','I']),      # 10
    ]
    sel = mod.select_championship_core(rows, sport='WNBA', mode='SHOWDOWN')
    assert len(sel.rows) == 5
    # Dominant family is source ranks 1/9/10 and all three are pressed.
    assert {1,9,10}.issubset(set(sel.receipt['CORE_SOURCE_INDICES']))
    assert sel.receipt['CORE_FROZEN_BEFORE_SATELLITES'] is True
    assert sel.receipt['SATELLITES_ENABLED'] is False


def test_real_470_family_shape_keeps_rank1_rank4_rank27_cluster():
    rows = [
        _row('Caitlin Clark',['Kelsey Mitchell','Makayla Timpson','Monique Billings','Azura Stevens','Lexie Hull']),
        _row('Courtney Vandersloot',['Caitlin Clark','Kelsey Mitchell','Kamilla Cardoso','Lexie Hull','Elizabeth Williams']),
        _row('Elizabeth Williams',['Caitlin Clark','Kamilla Cardoso','Natasha Cloud','Monique Billings','Azura Stevens']),
        _row('Kamilla Cardoso',['Kelsey Mitchell','Courtney Vandersloot','Monique Billings','Azura Stevens','Elizabeth Williams']),
        _row('Kelsey Mitchell',['Kamilla Cardoso','Courtney Vandersloot','Monique Billings','Azura Stevens','Elizabeth Williams']),
        _row('Courtney Vandersloot',['Kelsey Mitchell','Kamilla Cardoso','Natasha Cloud','Monique Billings','Elizabeth Williams']),
        _row('Courtney Vandersloot',['Caitlin Clark','Kamilla Cardoso','Natasha Cloud','Lexie Hull','Elizabeth Williams']),
        _row('Kamilla Cardoso',['Caitlin Clark','Courtney Vandersloot','Azura Stevens','Elizabeth Williams','Jacy Sheldon']),
        _row('Caitlin Clark',['Kelsey Mitchell','Makayla Timpson','Monique Billings','Azura Stevens','Myisha Hines-Allen']),
        _row('Caitlin Clark',['Kelsey Mitchell','Makayla Timpson','Courtney Vandersloot','Monique Billings','Lexie Hull']),
    ]
    sel = mod.select_championship_core(rows, sport='WNBA', mode='SHOWDOWN')
    assert {1,9,10}.issubset(set(sel.receipt['CORE_SOURCE_INDICES']))


def test_postlock_contest_rank_is_rejected():
    rows = [_row('A',['B','C','D','E','F']) for _ in range(5)]
    rows[0]['contest_rank'] = 1
    try:
        mod.select_championship_core(rows, sport='NFL', mode='SHOWDOWN')
    except mod.ChampionshipCoreError as e:
        assert 'POSTLOCK_FIELDS' in str(e)
    else:
        raise AssertionError('postlock result should be rejected')


def test_satellites_are_off_by_default():
    rows = [_row(str(i), [f'{i}-{j}' for j in range(5)]) for i in range(10)]
    sel = mod.select_championship_core(rows, sport='PGA', mode='CLASSIC')
    assert len(sel.rows) == 5
    assert sel.receipt['SATELLITE_SOURCE_INDICES'] == []


def test_global_roster_parser_covers_mlb_classic_without_percentile_pollution():
    row = {
        "P1":"SP A","P2":"SP B","C":"C A","1B":"1B A","2B":"2B A","3B":"3B A","SS":"SS A",
        "OF1":"OF A","OF2":"OF B","OF3":"OF C","P95":123.4,"P99":145.6,
    }
    got = mod._flatten_players(row)
    assert len(got) == 10
    assert set(got) == {"SP A","SP B","C A","1B A","2B A","3B A","SS A","OF A","OF B","OF C"}
    assert "123.4" not in got and "145.6" not in got


def test_global_roster_parser_covers_nfl_classic():
    row = {
        "QB":"QB A","RB1":"RB A","RB2":"RB B","WR1":"WR A","WR2":"WR B","WR3":"WR C",
        "TE":"TE A","FLEX":"FLEX A","DST":"DST A","P95":150.0,"P99":180.0,
    }
    got = mod._flatten_players(row)
    assert len(got) == 9
    assert "150.0" not in got and "180.0" not in got


def test_global_roster_parser_covers_wnba_classic_util():
    row = {"G1":"G A","G2":"G B","F1":"F A","F2":"F B","F3":"F C","UTIL":"U A","P95":200.0}
    got = mod._flatten_players(row)
    assert len(got) == 6
    assert "U A" in got and "200.0" not in got


def test_global_roster_parser_covers_pga_tennis_mma_without_p95_p99():
    for row in [
        {"G1":"A","G2":"B","G3":"C","G4":"D","G5":"E","G6":"F","P95":300,"P99":350},
        {"P1":"A","P2":"B","P3":"C","P4":"D","P5":"E","P6":"F","P95":300,"P99":350},
        {"F1":"A","F2":"B","F3":"C","F4":"D","F5":"E","F6":"F","P95":300,"P99":350},
    ]:
        got = mod._flatten_players(row)
        assert len(got) == 6
        assert "300" not in got and "350" not in got

def test_nfl_showdown_structural_sentinel_is_protected_into_core5():
    rows = [_row(str(i), [f"{i}-{j}" for j in range(5)]) for i in range(10)]
    rows[9].update({"SELECTION_LANE":"DEFENSIVE_ROTATION_SENTINEL","SCENARIO_RANK":1})
    sel = mod.select_championship_core(rows, sport="NFL", mode="SHOWDOWN")
    assert 10 in sel.receipt["CORE_SOURCE_INDICES"]
    assert 10 in sel.receipt["PROTECTED_SOURCE_INDICES"]


def test_mlb_showdown_dual_rp_tail_bunch_is_preserved():
    rows = []
    for i in range(10):
        r = {"CPT":f"C{i}", "UTIL":"|".join(f"U{i}-{j}" for j in range(5)), "BRANCH":"5-1", "SP_COUNT":2, "RP_COUNT":0,
             "WIN":0.02 - i*.001, "TOP01":0.04-i*.001, "P99":110-i}
        rows.append(r)
    for i in (7,8,9):
        rows[i]["RP_COUNT"] = 2
        rows[i]["WIN"] = 0.0; rows[i]["TOP01"] = 0.0; rows[i]["P99"] = 95-i
    sel = mod.select_championship_core(rows, sport="MLB", mode="SHOWDOWN")
    assert {8,9,10}.issubset(set(sel.receipt["CORE_SOURCE_INDICES"]))


def test_cfb_classic_protected_membership_preserves_native_source_order_after_core5():
    rows=[]
    for i in range(10):
        row={
            'QB':f'QB{i}','RB1':f'RB{i}a','RB2':f'RB{i}b',
            'WR1':f'WR{i}a','WR2':f'WR{i}b','WR3':f'WR{i}c',
            'FLEX':f'FLEX{i}','SFLEX':f'SFLEX{i}',
            'TOP01_RATE':0.10-i*0.001,'WIN_RATE':0.05-i*0.001,
            'P95':120-i,'P99':150-i,'SELECTOR_SCORE':1.0-i*.01,
        }
        rows.append(row)
    # Simulate native CFB handoff: balance escapes are protected for membership,
    # strict rows are the remaining protected championship core.  Their inclusion
    # priority is allowed to differ, but final visible order must return to the
    # native CFB source order after membership is frozen.
    for idx,priority,lane in [(6,120,'BALANCE'),(7,120,'BALANCE'),(0,110,'STRICT'),(1,110,'STRICT'),(2,110,'STRICT')]:
        rows[idx].update({
            'GLOBAL_CORE_PROTECTED':True,
            'GLOBAL_CORE_PRIORITY':priority,
            'GLOBAL_CORE_FAMILY_ID':f'CFB_CLASSIC_{lane}_{idx+1}',
            'GLOBAL_CORE_SCENARIO_ID':f'CFB_CLASSIC_{lane}',
            'GLOBAL_CORE_FAMILY_CAP':1,
        })
    sel=mod.select_championship_core(rows,sport='CFB',mode='CLASSIC')
    assert set(sel.receipt['CORE_SOURCE_INDICES']) == {1,2,3,7,8}
    assert sel.receipt['CORE_SOURCE_INDICES'] == [1,2,3,7,8]
    assert sel.receipt['CFB_CLASSIC_NATIVE_ORDER_PARITY'] is True
