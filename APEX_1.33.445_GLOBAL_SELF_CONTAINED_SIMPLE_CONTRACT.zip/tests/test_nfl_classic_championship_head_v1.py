from types import SimpleNamespace
import numpy as np
import pandas as pd
from engines.nfl import nfl_classic_historical_field_ranker_v1 as h

def test_nfl_classic_championship_head_anchor_and_elite_gate(monkeypatch):
    rows=np.arange(54,dtype=np.int32).reshape(6,9)
    p01=np.array([.90,.89,.88,.87,.40,.39],dtype=float)
    p1=np.array([.90,.80,.70,.60,.99,.98],dtype=float)
    monkeypatch.setattr(h,"_predict_components",lambda r,p,c:(p01,p1))
    ownership=np.full(54,.15,dtype=float); ownership[36:54]=.01
    frame=pd.DataFrame({"Ceil":np.r_[np.full(36,15.0),np.full(18,5.0)]})
    cal=SimpleNamespace(ownership=ownership,frame=frame,p99=np.full(54,20.0))
    order,rec=h.championship_head_order(rows,{},cal,anchor_index=0,head_size=5)
    assert int(order[0])==0
    assert rec["PATCH_ID"]=="NFL_CLASSIC_TOP5_MEDIAN_HEAD_SHRINKAGE_v1"
    assert rec["STATUS"]=="ACTIVE_TOP01_QUARTILE_HEAD_SHRINKAGE"
    assert rec["ANCHOR_INDEX"]==0
    # The Top-1-only low-Top0.1 rows cannot hijack the championship head.
    assert 5 not in set(order[:5].tolist())
