from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'engines/mlb'))
import mlb_advisor_tail_selector_v1 as sel


def test_materially_better_top01_cannot_be_overridden():
    ctx=sel.context_profile(5000,10,50000)
    m={
      'top01_rate':np.array([0.0200,0.0150,0.0100]),
      'top01_lcb':np.array([0.019,0.014,0.009]),
      'win_rate':np.array([0.001,0.90,0.80]),
      'cvar99':np.array([120.,250.,240.]), 'p99':np.array([115.,230.,220.]),
      'p95':np.array([100.,210.,200.]), 'correlation':np.array([0.,1.,1.]),
      'leverage':np.array([0.,1.,1.]), 'top1_rate':np.array([0.1,0.9,0.8]),
    }
    o=sel.ranking_order(m,context=ctx)
    assert int(o[0])==0


def test_near_tie_can_use_right_tail_tiebreak():
    ctx=sel.context_profile(1176,1,50000)
    w=ctx.primary_tie_width
    m={
      'top01_rate':np.array([0.0100,0.0100 + 0.2*w]),
      'top01_lcb':np.array([0.009,0.009]), 'win_rate':np.array([0.01,0.01]),
      'cvar99':np.array([170.,150.]), 'p99':np.array([150.,140.]),
      'p95':np.array([120.,120.]), 'correlation':np.array([0.8,0.8]),
      'leverage':np.array([0.7,0.7]), 'top1_rate':np.array([0.05,0.05]),
    }
    o=sel.ranking_order(m,context=ctx)
    assert int(o[0])==0


def test_no_weighted_sum_or_family_quota():
    assert sel.WEIGHTED_METRIC_SUM_USED is False
    assert sel.HARD_FAMILY_QUOTAS_USED is False
    assert sel.HARD_PITCHER_PAIR_QUOTAS_USED is False
