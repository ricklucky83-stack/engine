from __future__ import annotations
import importlib.util, sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
ENG=ROOT/'engines/mlb'
sys.path.insert(0,str(ENG))
SRC=ENG/'mlb_showdown_raw_pool_runtime_v1_7.py'
spec=importlib.util.spec_from_file_location('sd_runtime_v17',SRC)
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
from mlb_showdown_contest_finish_ranker_v1 import wilson_lcb, rank_selected_board
from mlb_showdown_postlock_board_rank_evaluator_v1 import parse_lineup, evaluate_board, normalized_fpts

def test_best_by_signature_preserves_distinct_salary_release_paths():
    rosters=np.array([[0,1,2,3,4,5],[0,1,2,3,4,6],[0,1,2,3,4,7],[0,8,9,10,11,12]],dtype=np.int32)
    cands=np.arange(4,dtype=np.int32); score=np.array([1.0,.90,.80,.70])
    meta={'idx':rosters}; mask=np.array([1,1,1,1],bool); signatures=np.array([10,11,12,13])
    reps=m.best_by_signature_reps(cands,score,meta,mask,signatures,n=2,max_overlap=5)
    assert reps==[0,1]

def test_counter_orientation_is_distinct_from_control_orientation():
    assert 2 != 4

def test_percentile_rank_is_deterministic_v17():
    x=np.array([3.,1.,2.,2.]); assert np.array_equal(m.pct_rank(x),m.pct_rank(x))

def test_wilson_lcb_is_monotonic():
    p=np.array([.001,.002,.01])
    out=wilson_lcb(p,50000)
    assert np.all(np.diff(out)>0)
    assert np.all(out<=p)

def test_final_board_is_score_ordered_even_with_family_masks():
    cands=np.array([10,11,12,13,14],dtype=np.int32)
    selected=cands.copy()
    components={'score':np.array([.9,.7,.8,.6,1.0])}
    mask_a=np.zeros(20,bool); mask_b=np.zeros(20,bool)
    mask_a[[10,11]]=True; mask_b[[12,13]]=True
    meta={'lane_sp_cpt_control_51_speed':mask_a,'lane_hitter_cpt_speed_low_spend_42_counter_top2':mask_b}
    ordered,scores,reasons=rank_selected_board(selected,cands,components,meta,podium_depth=2)
    assert ordered.tolist()==[14,10,12,11,13]
    assert np.all(np.diff(scores)<=0)
    assert reasons==['TOP_0_1_PRIMARY_NEAR_TIE_ORDER']*5

def test_parse_dk_showdown_lineup():
    key=parse_lineup('CPT A UTIL B UTIL C UTIL D UTIL E UTIL F')
    assert key==('A',('B','C','D','E','F'))

def test_postlock_evaluator_never_marks_selector_usage(tmp_path):
    board=pd.DataFrame([{'RANK':1,'CPT':'A','UTIL1':'B','UTIL2':'C','UTIL3':'D','UTIL4':'E','UTIL5':'F'}])
    standings=pd.DataFrame([{'Rank':1,'Points':100,'Lineup':'CPT A UTIL B UTIL C UTIL D UTIL E UTIL F','Player':None,'FPTS':None}])
    p=tmp_path/'standings.csv'; standings.to_csv(p,index=False)
    _,summary=evaluate_board(board,p)
    assert summary['EXACT_FIELD_MATCHES']==1
    assert summary['BOARD_RANK_1_CONTEST_RANK']==1
    assert summary['ACTUAL_RESULTS_USED_BY_SELECTOR'] is False

def test_postlock_evaluator_role_normalizes_captain_fpts():
    standings=pd.DataFrame([
        {'Player':'A','Roster Position':'UTIL','FPTS':20.0},
        {'Player':'A','Roster Position':'CPT','FPTS':30.0},
        {'Player':'B','Roster Position':'UTIL','FPTS':5.0},
    ])
    values,spread=normalized_fpts(standings)
    assert values=={'A':20.0,'B':5.0}
    assert spread==0.0

def test_postlock_evaluator_rejects_inconsistent_role_normalization():
    standings=pd.DataFrame([
        {'Player':'A','Roster Position':'UTIL','FPTS':20.0},
        {'Player':'A','Roster Position':'CPT','FPTS':33.0},
    ])
    try:
        normalized_fpts(standings)
    except RuntimeError as exc:
        assert 'ROLE_NORMALIZED_FPTS_CONSISTENCY' in str(exc)
    else:
        raise AssertionError('inconsistent role-normalized FPTS must fail closed')

def test_mandatory_spine_is_exempt_from_impossible_overlap_cap():
    rosters=np.array([
        [0,1,2,3,4,5],
        [0,1,2,3,4,6],
        [0,1,2,3,4,7],
    ],dtype=np.int32)
    cands=np.arange(3,dtype=np.int32)
    score=np.array([1.0,.9,.8])
    meta={'idx':rosters,'cpt':np.array([0,0,0],dtype=np.int32)}
    mask=np.array([1,1,1],bool)
    reps=m.diverse_family_reps(cands,score,meta,mask,n=2,max_overlap=4)
    assert reps==[0,1]

def test_diversity_cap_expands_only_to_minimum_legal_pair_overlap():
    rosters=np.array([
        [0,1,2,3,4,5],
        [0,1,2,3,4,6],
        [0,1,2,3,5,6],
    ],dtype=np.int32)
    cands=np.arange(3,dtype=np.int32)
    score=np.array([1.0,.9,.8])
    meta={'idx':rosters,'cpt':np.array([0,0,0],dtype=np.int32)}
    mask=np.array([1,1,1],bool)
    reps=m.diverse_family_reps(cands,score,meta,mask,n=2,max_overlap=4)
    assert reps==[0,1]

def test_certified_podium_receipt_gate_rejects_any_family_override():
    bad=pd.Series([
        'CERTIFIED_FAMILY_PODIUM:A:REP_1',
        'TOP_0_1_PRIMARY_NEAR_TIE_ORDER',
    ])
    good=pd.Series([
        'TOP_0_1_PRIMARY_NEAR_TIE_ORDER',
        'TOP_0_1_PRIMARY_NEAR_TIE_ORDER',
    ])
    assert not m.certified_podium_ordering_ok(bad,True,False)
    assert not m.certified_podium_ordering_ok(bad,False,False)
    assert m.certified_podium_ordering_ok(good,True,True)


def test_selector_has_no_forced_family_representatives_or_family_bonus():
    src=SRC.read_text()
    block=src[src.index('def select_milp'):src.index('def certified_podium_ordering_ok')]
    assert 'forced_reps' not in block
    assert "lane_sp_cpt_51'][cands]" not in block
    assert "'WEIGHTED_METRIC_SUM_USED':False" in block
    assert "'HARD_FAMILY_QUOTAS_USED':False" in block
    assert 'advisor_selector.select_ranked_stream' not in block  # ranker supplies sealed order

def test_fake_field_uses_starter_ownership_for_structural_targets():
    src=SRC.read_text()
    block=src[src.index('def choose_fake'):src.index('def field_thresholds')]
    assert "sp_player_ids" in block
    assert 'dual_target=float(np.clip(0.20+0.55*second' in block
    assert 'spcpt_target=float(np.clip' in block

def test_ranker_is_top01_win_tail_first_not_top10_first():
    from mlb_showdown_contest_finish_ranker_v1 import contest_finish_components
    src=(ENG/'mlb_showdown_contest_finish_ranker_v1.py').read_text()
    block=src[src.index('def contest_finish_components'):src.index('def rank_selected_board')]
    assert 'ranking_order(selector_metrics,context=ctx)' in block
    assert "'top01_rate':top01" in block
    assert 'WEIGHTED' not in block.upper()
    assert "'win_rate':win" in block
    assert 'pct_rank(top10_lcb)' not in block
