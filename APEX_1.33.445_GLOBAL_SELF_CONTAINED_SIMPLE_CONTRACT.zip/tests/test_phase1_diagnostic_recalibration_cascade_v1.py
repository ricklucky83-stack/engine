import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]


def _load_json(rel):
    return json.loads((ROOT / rel).read_text())


def _load_module(name, rel):
    spec = importlib.util.spec_from_file_location(name, ROOT / rel)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def test_doctrine_phase1_is_phase3_eyes_and_cascade_is_hard_gated():
    d = _load_json('doctrine/APEX_PHASE1_DIAGNOSTIC_RECALIBRATION_CASCADE_v1.json')
    assert d['STATUS'] == 'LOCKED_HARD_GATE'
    assert d['CORE_PRINCIPLE'] == 'PHASE1_IS_PHASE3_EYES'
    r = d['RULES']
    assert r['PHASE1_CALIBRATION_COMPUTE_ONCE_PER_RUN'] is True
    assert r['PHASE1_CALIBRATION_FREEZE_BEFORE_PHASE2'] is True
    assert r['MIDRUN_RECALIBRATION_PROHIBITED'] is True
    assert r['DIAGNOSTIC_MISS_RESTARTS_AT_PHASE1'] is True
    assert r['PHASE1_HASH_CHANGE_INVALIDATES_OLD_PHASE2'] is True
    assert r['PHASE1_HASH_CHANGE_INVALIDATES_OLD_PHASE3'] is True
    assert r['PHASE1_HASH_CHANGE_INVALIDATES_OLD_SELECTOR_RESULTS'] is True
    assert r['PHASE1_HASH_CHANGE_INVALIDATES_OLD_BOARD'] is True
    assert r['BACKWARD_CALIBRATION_TRACKED_SEPARATELY_FROM_FORWARD_ACCURACY'] is True


def test_required_hash_chain_is_complete():
    d = _load_json('doctrine/APEX_PHASE1_DIAGNOSTIC_RECALIBRATION_CASCADE_v1.json')
    assert d['REQUIRED_HASH_CHAIN'] == [
        'PHASE1_CALIBRATION_SHA256',
        'PHASE2_INPUT_CALIBRATION_SHA256',
        'HANDOFF_INPUT_CALIBRATION_SHA256',
        'PHASE3_INPUT_CALIBRATION_SHA256',
        'DEEP_SIM_INPUT_CALIBRATION_SHA256',
        'SELECTOR_INPUT_CALIBRATION_SHA256',
        'FINAL_BOARD_INPUT_CALIBRATION_SHA256',
    ]


def test_freeze_makes_phase1_matrix_read_only_and_parity_passes():
    m = _load_module('phase1_freeze_test', 'engines/common/apex_phase1_calibration_freeze_v1.py')
    x = np.arange(24, dtype=np.float32).reshape(4, 6)
    seal = m.freeze_calibration(x)
    assert x.flags.writeable is False
    chain = {'PHASE1_CALIBRATION_SHA256': seal.sha256}
    for stage in [
        'PHASE2_INPUT_CALIBRATION_SHA256', 'HANDOFF_INPUT_CALIBRATION_SHA256',
        'PHASE3_INPUT_CALIBRATION_SHA256', 'DEEP_SIM_INPUT_CALIBRATION_SHA256',
        'SELECTOR_INPUT_CALIBRATION_SHA256', 'FINAL_BOARD_INPUT_CALIBRATION_SHA256'
    ]:
        assert m.assert_calibration_unchanged(x, seal, stage, chain) == seal.sha256
    assert m.hash_chain_parity(chain, seal.sha256) is True


def test_mutation_after_freeze_fails_closed():
    m = _load_module('phase1_freeze_mutation_test', 'engines/common/apex_phase1_calibration_freeze_v1.py')
    x = np.arange(12, dtype=np.float64).reshape(3, 4)
    seal = m.freeze_calibration(x)
    x.flags.writeable = True
    x[0, 0] += 1.0
    with pytest.raises(RuntimeError, match='ENGINE_INTEGRITY_HALT:CALIBRATION_MUTATION_DETECTED'):
        m.assert_calibration_unchanged(x, seal, 'PHASE3_INPUT_CALIBRATION_SHA256')


def test_runtime_wires_every_hash_boundary_and_receipt():
    s = (ROOT / 'engines/mlb/mlb_showdown_raw_pool_runtime_v1_7.py').read_text()
    for name in [
        'PHASE1_CALIBRATION_SHA256','PHASE2_INPUT_CALIBRATION_SHA256',
        'HANDOFF_INPUT_CALIBRATION_SHA256','PHASE3_INPUT_CALIBRATION_SHA256',
        'DEEP_SIM_INPUT_CALIBRATION_SHA256','SELECTOR_INPUT_CALIBRATION_SHA256',
        'FINAL_BOARD_INPUT_CALIBRATION_SHA256','CALIBRATION_HASH_CHAIN_PARITY'
    ]:
        assert name in s
    assert 'freeze_calibration(p1)' in s
    assert 'MIDRUN_RECALIBRATION_PROHIBITED=True' in s


def test_loss_research_doctrine_recovered_and_final_1604_case_corrected():
    d = _load_json('doctrine/APEX_GLOBAL_POSTLOCK_LOSS_CAUSAL_RESEARCH_AND_REPAIR_v1.json')
    assert d['STATUS'] == 'LOCKED_HARD_GATE'
    case = next(x for x in d['REFERENCE_CASES'] if x['CONTEST_ID'] == 193254886)
    assert case['FULL_CONTEST_FILE_PROVIDED'] is True
    assert case['WINNER_PHASE2_LINEUP_INDEX'] == 65241
    assert case['FAILURE_CLASS'] == 'SELECTOR_FAILURE'
    assert case['PHASE1_RECALIBRATION_CASCADE_REQUIRED_FOR_CAUSAL_ENGINE_REPAIR'] is True
    w = _load_json('doctrine/APEX_GLOBAL_WINNER_FOCUSED_CONTEST_SCIENCE_v1.json')
    assert w['LOSS_CAUSAL_RESEARCH_DOCTRINE'] == d['DOCTRINE_ID']
    assert w['PHASE1_DIAGNOSTIC_RECALIBRATION_DOCTRINE'] == 'APEX_GLOBAL_PHASE1_DIAGNOSTIC_RECALIBRATION_CASCADE_v1'
    assert w['LEGACY_PHASE1_DIAGNOSTIC_RECALIBRATION_DOCTRINE'] == 'APEX_PHASE1_DIAGNOSTIC_RECALIBRATION_CASCADE_v1'


def test_state_contract_restarts_model_miss_at_phase1():
    s = _load_json('state_contract.json')
    c = s['PHASE1_CALIBRATION_CONTRACT']
    assert c['CORE_PRINCIPLE'] == 'PHASE1_IS_PHASE3_EYES'
    assert c['CONTEST_OR_MODEL_MISS_RESTARTS_AT_PHASE1'] is True
    assert c['PHASE1_HASH_CHANGE_INVALIDATES_ALL_DOWNSTREAM_ARTIFACTS'] is True
    assert 'CONTEST_OR_MODEL_OUTCOME_MISS_RESTARTS_AT_PHASE1' in s['PRODUCTION_TRIGGER_CONTRACT']['DIAGNOSTIC_REPLAY']
    assert s['FAILURE_POLICY']['PHASE1_CALIBRATION_HASH_MISMATCH'] == 'ENGINE_INTEGRITY_HALT'
    assert s['FAILURE_POLICY']['DIAGNOSTIC_RECALIBRATION_WITH_OLD_DOWNSTREAM_ARTIFACTS'] == 'RUN_INVALID'


def test_persistence_separates_backward_from_forward_accuracy():
    p = _load_json('persistence_policy.json')['RULES']
    assert 'DIAGNOSTIC_FAILED_STAGE_ONLY_REPLAY_REQUIRED' not in p
    assert p['DIAGNOSTIC_CONTEST_OUTCOME_MISS_PHASE1_RECALIBRATION_CASCADE_REQUIRED'] is True
    assert p['PHASE1_HASH_CHANGE_INVALIDATES_ALL_DOWNSTREAM_ARTIFACTS'] is True
    assert p['BACKWARD_CALIBRATION_ACCURACY_MUST_REMAIN_SEPARATE_FROM_FORWARD_ACCURACY'] is True


def test_production_ranker_matches_sealed_advisor_rebuild_and_research_ranker_not_production_active():
    prod = ROOT / 'engines/mlb/mlb_showdown_contest_finish_ranker_v1.py'
    reg = _load_json('engine_registry.json')
    mlb = next(e for e in reg['ENGINES'] if e['ENGINE_ID'] == 'APEX_MLB_MASTER_ENGINE_v1')
    actual = hashlib.sha256(prod.read_bytes()).hexdigest()
    assert actual == mlb['EXPECTED_SHA256']['engines/mlb/mlb_showdown_contest_finish_ranker_v1.py']
    assert mlb['SHOWDOWN_BASE_ADVISOR_SELECTOR_PATCH'] == 'MLB_ADVISOR_RIGHT_TAIL_PRIMARY_SELECTOR_v1'
    assert mlb['SHOWDOWN_FINAL_SELECTOR_PATCH'] == 'MLB_SD_RECIPROCAL_CPT_DUAL_SP_TROPHY_POSTERIOR_v1'
    assert mlb['SHOWDOWN_FINAL_SELECTOR_WEIGHTED_SUM_USED'] is False
    assert mlb['SHOWDOWN_RESEARCH_SIGNAL_FAITHFUL_RANKER_PRODUCTION_ACTIVE'] is False
    assert 'blind' in mlb['SHOWDOWN_RESEARCH_SIGNAL_FAITHFUL_RANKER_PROMOTION_BLOCKER'].lower()


def test_research_ranker_signal_dominance_synthetic():
    m = _load_module('signal_ranker_test', 'engines/mlb/research/mlb_showdown_phase1_signal_faithful_ranker_v2.py')
    # Verify the research ranker exposes its declared identity and a generic signal-primary policy.
    assert m.PATCH_ID == 'MLB_SD_PHASE1_PHASE3_SIGNAL_FAITHFUL_BOARD_RANKER_v2'
    assert m.RANKER_ID == 'PHASE1_PHASE3_SIGNAL_PRIMARY_FAMILY_TIEBREAK_v2'
    src = (ROOT / 'engines/mlb/research/mlb_showdown_phase1_signal_faithful_ranker_v2.py').read_text()
    assert 'family' in src.lower()
    assert 'signal' in src.lower()


def test_registry_runtime_hashes_match_bytes():
    reg = _load_json('engine_registry.json')
    mlb = next(e for e in reg['ENGINES'] if e['ENGINE_ID'] == 'APEX_MLB_MASTER_ENGINE_v1')
    for rel in [
        'engines/mlb/mlb_showdown_raw_pool_runtime_v1_7.py',
        'engines/common/apex_phase1_calibration_freeze_v1.py',
        'doctrine/APEX_PHASE1_DIAGNOSTIC_RECALIBRATION_CASCADE_v1.json',
        'doctrine/APEX_GLOBAL_POSTLOCK_LOSS_CAUSAL_RESEARCH_AND_REPAIR_v1.json',
        'doctrine/APEX_GLOBAL_WINNER_FOCUSED_CONTEST_SCIENCE_v1.json',
        'engines/mlb/APEX_MLB_RAW_POOL_RUNTIME_v1_20_2.manifest.json',
    ]:
        actual = hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()
        assert mlb['EXPECTED_SHA256'][rel] == actual
