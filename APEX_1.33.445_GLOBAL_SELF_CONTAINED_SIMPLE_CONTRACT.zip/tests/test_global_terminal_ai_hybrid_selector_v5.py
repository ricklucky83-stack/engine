import importlib.util
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'engines/common/apex_terminal_ai_hybrid_selector_v5.py'
spec=importlib.util.spec_from_file_location('ai_v5',P); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def row(lid,cpt,utils,*,sp=1,cpt_sp=False,t01=.01,t01_l=.009,win=.002,win_l=.0015,p99=120,dup=.001,score=1.0,protected=False,priority=0):
    d={'LINEUP_ID':str(lid),'LINEUP_INDEX':lid,'CPT':cpt,'MC_TRIALS':12000,'MC_WIN_RATE':win,'MC_WIN_LCB':win_l,'MC_TOP_0_1_RATE':t01,'MC_TOP_0_1_LCB':t01_l,'MC_P95':108,'MC_P99':p99,'PROJECTED_EXACT_MATCH_DUPLICATION':dup,'CURRENT_SELECTOR_PRE_SCORE':score,'SP_COUNT':sp,'CPT_IS_SP':cpt_sp,'GLOBAL_CORE_PROTECTED':protected,'GLOBAL_CORE_PRIORITY':priority,'LINEUP_MARKET_TT':4.2,'TT_LEVERAGE_SCORE':.3}
    for i,u in enumerate(utils,1): d[f'UTIL{i}']=u
    # deterministic structure metadata, all pre-lock
    players=[cpt,*utils]
    for slot,pl in zip(['CPT','UTIL1','UTIL2','UTIL3','UTIL4','UTIL5'],players):
        d[f'{slot}_TEAM']='CHC' if pl in {'Pete Crow-Armstrong','Ian Happ','Chase Burns'} else 'CIN'
        d[f'{slot}_ORDER']=2
        d[f'{slot}_CONDITIONAL_SUPPORT']=4.0
    return d

def slate_rows():
    anchor=row(241641,'Pete Crow-Armstrong',['Chase Burns','Ian Happ','Dane Myers','Hector Rodriguez','Tyler Stephenson'],t01=.019,t01_l=.0175,win=.0035,win_l=.0030,p99=124,protected=True,priority=100)
    reciprocal=row(549539,'Sal Stewart',['Chase Burns','Pete Crow-Armstrong','Dane Myers','Hector Rodriguez','Tyler Stephenson'],t01=.01825,t01_l=.017068,win=.003333,win_l=.002847,p99=122.067,dup=.000058)
    samecpt=row(241926,'Pete Crow-Armstrong',['Chase Burns','Dane Myers','Hector Rodriguez','Tyler Stephenson','Eugenio Suarez'],t01=.01025,t01_l=.008775,win=.00175,win_l=.001202,p99=119.09,dup=.000045)
    spcounter=row(117394,'Chase Burns',['Pete Crow-Armstrong','Dane Myers','Hector Rodriguez','Tyler Stephenson','Eugenio Suarez'],cpt_sp=True,t01=.012,t01_l=.010396,win=.0015,win_l=.001,p99=118.537)
    counterscript=row(249037,'Pete Crow-Armstrong',['Elly De La Cruz','Dane Myers','Hector Rodriguez','Tyler Stephenson','Sal Stewart'],sp=0,t01=.013,t01_l=.012006,win=.00275,win_l=.002312,p99=124.238,dup=.000024)
    outsider=row(999999,'Elly De La Cruz',['Matt McLain','Sal Stewart','Eugenio Suarez','Michael Conforto','Edwin Arroyo'],sp=0,t01=.004,t01_l=.003,win=.0004,win_l=.0002,p99=110)
    return [anchor,reciprocal,samecpt,spcounter,counterscript,outsider]

def test_profile_v5_and_policy():
    p=m.intelligence_profile('MLB','SHOWDOWN')
    assert p['profile_id']=='MLB_SHOWDOWN_TERMINAL_INTELLIGENCE_v5'
    assert p['dominant_neighborhood_max_seats']==3
    assert p['counter_script_reserve_seats']==2

def test_core5_mass_density_and_role_intelligence_are_prelock_only():
    out=m.enrich_ai_evidence(slate_rows(),sport='MLB',mode='SHOWDOWN')
    by={int(r['LINEUP_INDEX']):r for r in out}
    assert by[241641]['AI_MLB_SD_PORTFOLIO_ROLE']=='PROTECTED_CHAMPION'
    assert by[549539]['AI_MLB_SD_PORTFOLIO_ROLE']=='DOMINANT_CORE_RECIPROCAL_SATELLITE'
    assert by[241926]['AI_MLB_SD_PORTFOLIO_ROLE']=='DOMINANT_CORE_SAME_CPT_SATELLITE'
    assert by[117394]['AI_MLB_SD_PORTFOLIO_ROLE']=='DOMINANT_CORE_SP_CPT_COUNTER'
    assert by[249037]['AI_MLB_SD_PORTFOLIO_ROLE']=='COUNTER_SCRIPT_RESERVE'
    assert by[241641]['AI_CORE5_MEMBER_COUNT']>=2
    assert 'AI_CORE5_TOP01_DENSITY' in by[241641]
    assert 0 <= by[549539]['AI_MLB_SD_CHAMPIONSHIP_NEIGHBORHOOD_SCORE'] <= 1

def test_postlock_training_leakage_still_fails_closed():
    rows=slate_rows(); rows[0]['ACTUAL_SCORE']=129.55
    with pytest.raises(m.TerminalAIHybridError): m.enrich_ai_evidence(rows,sport='MLB',mode='SHOWDOWN')

def test_full_handoff_count_unchanged():
    rows=slate_rows(); out=m.enrich_ai_evidence(rows,sport='MLB',mode='SHOWDOWN')
    assert len(out)==len(rows)


def test_code_contract_metadata_is_authoritative_and_prelock_only():
    meta=m.selector_contract_metadata()
    pol=meta['mlb_showdown_championship_neighborhood_policy']
    assert meta['code_doc_parity_patch_id']=='APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v5_CODE_DOC_PARITY_SEAL_v1'
    assert pol['dominant_neighborhood_max_seats']==3
    assert pol['counter_script_reserve_seats']==2
    assert pol['dominant_shared_players']==5
    assert pol['counter_shared_players']==4
    assert pol['quota_semantics']=='EVIDENCE_PRIOR_NOT_FORCED_QUOTA'
    assert pol['production_inputs']=='PRELOCK_ONLY'
    assert pol['resolved_results_role']=='OFFLINE_DIAGNOSTIC_CALIBRATION_ONLY'
    assert pol['player_name_constants'] is False
    assert pol['postlock_selector_fields'] is False

def test_doctrine_matches_executable_neighborhood_policy():
    import json
    doctrine=json.loads((ROOT/'doctrine/APEX_GLOBAL_TERMINAL_AI_HYBRID_SELECTOR_v5.json').read_text())
    pol=m.selector_contract_metadata()['mlb_showdown_championship_neighborhood_policy']
    cal=doctrine['MLB_SHOWDOWN_CHAMPIONSHIP_NEIGHBORHOOD_CALIBRATION']; prior=cal['PORTFOLIO_PRIOR']
    assert prior['DOMINANT_NEIGHBORHOOD_MAX_SEATS']==pol['dominant_neighborhood_max_seats']
    assert prior['COUNTER_SCRIPT_RESERVE_SEATS']==pol['counter_script_reserve_seats']
    assert cal['DOMINANT_SHARED_PLAYERS']==pol['dominant_shared_players']
    assert cal['COUNTER_SHARED_PLAYERS']==pol['counter_shared_players']
    assert cal['PROTECTED_ANCHOR_PRIORITY']==pol['protected_anchor_priority']
    assert prior['RULE']==pol['quota_semantics']
