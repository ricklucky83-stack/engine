from __future__ import annotations
from types import SimpleNamespace
import inspect
import numpy as np
import pandas as pd

from engines.nfl import nfl_classic_raw_pool_runtime_v1 as nflc
from engines.nfl import nfl_showdown_raw_pool_runtime_v1 as nfls
from engines.wnba import wnba_classic_raw_pool_runtime_v1 as wnbac
from engines.wnba import wnba_showdown_raw_pool_runtime_v7 as wnbas

PATCH_ID = "APEX_GLOBAL_NONEMPTY_PRODUCTION_BOARD_v1"


def _sim(n: int) -> dict:
    # Deliberately only one lineup is extreme enough to look "strict"; the board must still fill from Phase3.
    x = np.linspace(0.0, 0.01, n, dtype=float)
    m = {
        "top01_rate": x.copy(),
        "top01_lcb": x.copy(),
        "top01_ucb": x.copy() + 0.001,
        "win_rate": x[::-1].copy(),
        "top10_rate": np.linspace(0.1, 0.9, n),
        "p95": np.linspace(10, 20, n),
        "p99": np.linspace(12, 24, n),
        "mean": np.linspace(5, 15, n),
        "win_count": np.arange(n),
        "top10_count": np.arange(n),
        "top01_count": np.arange(n),
        "trials": np.full(n, 10_000, dtype=int),
    }
    return {"metrics": m}


def test_nfl_classic_thresholds_cannot_zero_board():
    n = 12
    rows = np.arange(n * 9, dtype=np.int32).reshape(n, 9)
    pmeta = {"family": np.arange(n, dtype=np.int16)}
    cal = SimpleNamespace(ownership=np.full(n * 9, 0.1), phase1_hash="phase1")
    cfg = nflc.Config(field_size=8823, seed=1, test_mode=True, board_size=10)
    board, metrics, state = nflc._select(rows, pmeta, _sim(n), cal, cfg)
    assert board.shape == (10, 9)
    assert len(metrics["chosen"]) == 10
    assert int(metrics["final_board_target"][0]) == 10
    assert "VALID_EMPTY_BOARD" not in state


def test_nfl_showdown_thresholds_cannot_zero_board():
    n = 12
    rows = np.arange(n * 6, dtype=np.int32).reshape(n, 6)
    pmeta = {
        "same_cpt_team": np.arange(n, dtype=np.int16) % 6,
        "skill_count": np.full(n, 3, dtype=np.int16),
    }
    cal = SimpleNamespace(ids=np.arange(n * 6), ownership=np.full(n * 6, 0.1), phase1_hash="phase1")
    cfg = nfls.Config(field_size=8823, seed=1, test_mode=True, board_size=10)
    board, metrics, state = nfls._select(rows, pmeta, _sim(n), cal, cfg)
    assert board.shape == (10, 6)
    assert len(metrics["chosen"]) == 10
    assert int(metrics["final_board_target"][0]) == 10
    assert "VALID_EMPTY_BOARD" not in state


def test_active_wnba_selectors_have_no_valid_empty_board_return():
    for fn in (wnbac.select_board, wnbas._select):
        src = inspect.getsource(fn)
        assert "VALID_EMPTY_BOARD" not in src
        assert "return np.empty((0, 6)" not in src


def test_policy_is_hard_coded_in_active_sources():
    for fn in (nflc._select, nfls._select, wnbac.select_board, wnbas._select):
        src = inspect.getsource(fn)
        assert "ENGINE_INTEGRITY_FAILURE" in src or "NONEMPTY_PHASE3_BOARD" in src


def test_wnba_classic_thin_strict_signal_still_builds_board(monkeypatch):
    n = 12
    candidates = np.arange(n * 6, dtype=np.int16).reshape(n, 6)
    sim = {
        "top01_rate": np.linspace(0.0, 0.01, n),
        "top10_rate": np.linspace(0.1, 0.9, n),
        "win_rate": np.linspace(0.01, 0.0, n),
        "p95": np.linspace(10, 20, n),
        "p99": np.linspace(12, 24, n),
        "mean": np.linspace(5, 15, n),
        "trials_per_lineup": np.full(n, 10_000, dtype=int),
    }
    players = n * 6
    cal = SimpleNamespace(
        frame=pd.DataFrame({"SAL": np.full(players, 8_000)}),
        ownership_proxy=np.full(players, 0.1),
        vacancy_beneficiary=np.zeros(players, dtype=bool),
        p_expand=np.zeros(players),
        is_guard=np.zeros(players, dtype=bool),
        team_codes=np.arange(players, dtype=np.int16),
        game_codes=(np.arange(players, dtype=np.int16) // 2),
    )
    cfg = wnbac.RuntimeConfig(field_size=3567, seed=1, board_size=10)
    monkeypatch.setattr(wnbac, "_assert_frozen_phase1_calibration", lambda *a, **k: "phase1")
    monkeypatch.setattr(wnbac, "_certified_premium_guard_lane", lambda rows, cal, salary: np.zeros(len(rows), dtype=bool))
    monkeypatch.setattr(wnbac, "_uncertainty_aware_scenario_lane_order", lambda chosen, *a, **k: (np.asarray(chosen), {"scenario_lane_candidates":0,"scenario_lane_priority_rank":0,"scenario_lane_leader_candidate_index":-1}))
    board, metrics, state = wnbac.select_board(candidates, sim, cal, cfg, expected_phase1_hash="phase1")
    assert board.shape == (10, 6)
    assert int(metrics["final_board_target"][0]) == 10
    assert state.startswith("PASS")
