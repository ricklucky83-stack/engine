from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / 'engines/nfl/nfl_showdown_nflverse_prelock_role_v1.py'
ENGINE = ROOT / 'engines/nfl/nfl_showdown_raw_pool_runtime_v1.py'

def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m

nv = _load('nflverse_prelock_role_test_mod', MOD)
nfl = _load('nflverse_prelock_role_runtime_test', ENGINE)


def _pbp_rows():
    rows = []
    # Two historical games. RB3 has repeat red-zone usage; QB has pass + rush RZ paths.
    for week, date in [(16, '2025-12-21'), (17, '2025-12-28')]:
        gid = f'2025_{week:02d}_AAA_BBB'
        for yd in [18, 9, 4]:
            rows.append({'game_id':gid,'posteam':'AAA','yardline_100':yd,'game_date':date,'season_type':'REG','rush_attempt':1,'rusher_player_id':'RB3','pass_attempt':0,'receiver_player_id':None,'passer_player_id':None,'air_yards':None,'qb_kneel':0})
        for yd in [17, 8]:
            rows.append({'game_id':gid,'posteam':'AAA','yardline_100':yd,'game_date':date,'season_type':'REG','rush_attempt':0,'rusher_player_id':None,'pass_attempt':1,'receiver_player_id':'TE1','passer_player_id':'QB1','air_yards':yd+2,'qb_kneel':0})
        rows.append({'game_id':gid,'posteam':'AAA','yardline_100':7,'game_date':date,'season_type':'REG','rush_attempt':1,'rusher_player_id':'QB1','pass_attempt':0,'receiver_player_id':None,'passer_player_id':None,'air_yards':None,'qb_kneel':0})
        # team denominator work for other backs/receivers
        rows.append({'game_id':gid,'posteam':'AAA','yardline_100':12,'game_date':date,'season_type':'REG','rush_attempt':1,'rusher_player_id':'RB1','pass_attempt':0,'receiver_player_id':None,'passer_player_id':None,'air_yards':None,'qb_kneel':0})
        rows.append({'game_id':gid,'posteam':'AAA','yardline_100':15,'game_date':date,'season_type':'REG','rush_attempt':0,'rusher_player_id':None,'pass_attempt':1,'receiver_player_id':'WR1','passer_player_id':'QB1','air_yards':5,'qb_kneel':0})
    # Target-slate date row must be excluded even if huge.
    for _ in range(25):
        rows.append({'game_id':'2026_01_AAA_BBB','posteam':'AAA','yardline_100':1,'game_date':'2026-09-13','season_type':'REG','rush_attempt':1,'rusher_player_id':'RB3','pass_attempt':0,'receiver_player_id':None,'passer_player_id':None,'air_yards':None,'qb_kneel':0})
    return pd.DataFrame(rows)


def _pool():
    return pd.DataFrame([
        {'PLAYER':'Quarter Back','POS':'QB/CPTN/FLEX','TEAM':'AAA','OPP':'BBB','SAL':10000,'FPTS':19,'Ceil':26,'Floor':10,'RST%':60,'VAL':1.9,'TM Score':24,'O/U':48,'SPRD':-2,'1+ TD':200,'Time (ET)':'2026-09-13 20:20:00'},
        {'PLAYER':'Lead Back','POS':'RB/CPTN/FLEX','TEAM':'AAA','OPP':'BBB','SAL':9000,'FPTS':15,'Ceil':23,'Floor':8,'RST%':50,'VAL':1.7,'TM Score':24,'O/U':48,'SPRD':-2,'1+ TD':150,'Time (ET)':'2026-09-13 20:20:00'},
        {'PLAYER':'Third Back','POS':'RB/CPTN/FLEX','TEAM':'AAA','OPP':'BBB','SAL':2000,'FPTS':5,'Ceil':11,'Floor':1,'RST%':5,'VAL':2.5,'TM Score':24,'O/U':48,'SPRD':-2,'1+ TD':500,'Time (ET)':'2026-09-13 20:20:00'},
        {'PLAYER':'Tight End','POS':'TE/CPTN/FLEX','TEAM':'AAA','OPP':'BBB','SAL':6000,'FPTS':9,'Ceil':17,'Floor':3,'RST%':25,'VAL':1.5,'TM Score':24,'O/U':48,'SPRD':-2,'1+ TD':350,'Time (ET)':'2026-09-13 20:20:00'},
        {'PLAYER':'Other QB','POS':'QB/CPTN/FLEX','TEAM':'BBB','OPP':'AAA','SAL':9800,'FPTS':18,'Ceil':25,'Floor':9,'RST%':55,'VAL':1.8,'TM Score':22,'O/U':48,'SPRD':2,'1+ TD':250,'Time (ET)':'2026-09-13 20:20:00'},
        {'PLAYER':'Other RB','POS':'RB/CPTN/FLEX','TEAM':'BBB','OPP':'AAA','SAL':8000,'FPTS':13,'Ceil':20,'Floor':6,'RST%':40,'VAL':1.6,'TM Score':22,'O/U':48,'SPRD':2,'1+ TD':200,'Time (ET)':'2026-09-13 20:20:00'},
        {'PLAYER':'Other WR','POS':'WR/CPTN/FLEX','TEAM':'BBB','OPP':'AAA','SAL':7000,'FPTS':12,'Ceil':19,'Floor':5,'RST%':35,'VAL':1.7,'TM Score':22,'O/U':48,'SPRD':2,'1+ TD':300,'Time (ET)':'2026-09-13 20:20:00'},
    ])


def _rosters():
    return pd.DataFrame([
        {'gsis_id':'QB1','full_name':'Quarter Back'},
        {'gsis_id':'RB1','full_name':'Lead Back'},
        {'gsis_id':'RB3','full_name':'Third Back'},
        {'gsis_id':'TE1','full_name':'Tight End'},
        {'gsis_id':'WR1','full_name':'Wide Receiver'},
    ])


def _snaps():
    rows=[]
    for week in [16,17]:
        gid=f'2025_{week:02d}_AAA_BBB'
        rows += [
            {'game_id':gid,'gsis_id':'QB1','team':'AAA','offense_pct':1.0},
            {'game_id':gid,'gsis_id':'RB1','team':'AAA','offense_pct':0.70},
            {'game_id':gid,'gsis_id':'RB3','team':'AAA','offense_pct':0.31},
            {'game_id':gid,'gsis_id':'TE1','team':'AAA','offense_pct':0.77},
        ]
    return pd.DataFrame(rows)


def test_prelock_strict_cutoff_and_redzone_features():
    feat, rec = nv.derive_from_frames(_pool(), _pbp_rows(), _snaps(), _rosters(), pd.DataFrame(), as_of='2026-09-13 20:20:00', lookback_games=8)
    rb = feat[nv._norm_name('Third Back')]
    assert rec['MAX_GAME_DATE_USED'] == '2025-12-28'
    assert rec['POSTLOCK_TARGET_GAME_USED'] is False
    assert 2.0 < rb['rz_rush_attempts'] < 4.0  # weighted per-game opportunity, not leaked 25 target-date carries
    assert rb['inside5_rush_attempts'] > 0.0
    assert rb['goal_line_share'] > 0.0
    assert rb['snap_share_hist'] > 0.25


def test_cached_enrichment_preserves_current_role_authority(tmp_path):
    cache = tmp_path/'cache'; cache.mkdir()
    _pbp_rows().to_csv(cache/'play_by_play_2025.csv', index=False)
    _snaps().to_csv(cache/'snap_counts_2025.csv', index=False)
    _rosters().to_csv(cache/'roster_weekly_2025.csv', index=False)
    pd.DataFrame(columns=['gsis_id','display_name']).to_csv(cache/'players.csv', index=False)
    poolp=tmp_path/'pool.csv'; _pool().to_csv(poolp,index=False)
    role={'players':{
        'Third Back':{'status':'ACTIVE','source_ref':'PRELOCK_CURRENT_ROLE','snap_share':0.22,'carry_share':0.11,'target_share':0.03,'role_uncertainty':0.55},
        'Quarter Back':{'status':'ACTIVE','source_ref':'PRELOCK_CURRENT_ROLE','snap_share':1.0,'role_uncertainty':0.1},
    }}
    out, rec = nv.enrich_role_evidence(role,poolp,cache_dir=cache,as_of='2026-09-13 20:20:00',seasons=[2025])
    rb=out['players']['Third Back']
    assert rb['snap_share']==0.22 and rb['carry_share']==0.11  # historical source never replaces current role
    assert rb['rz_rush_attempts']>0 and rb['goal_line_share']>0
    assert rec['STATUS']=='ENRICHED' and rec['PLAYERS_ENRICHED_COUNT']>=2


def test_runtime_ingests_local_nflverse_cache(tmp_path):
    cache=tmp_path/'cache'; cache.mkdir()
    _pbp_rows().to_csv(cache/'play_by_play_2025.csv',index=False)
    _snaps().to_csv(cache/'snap_counts_2025.csv',index=False)
    _rosters().to_csv(cache/'roster_weekly_2025.csv',index=False)
    pd.DataFrame(columns=['gsis_id','display_name']).to_csv(cache/'players.csv',index=False)
    pool=_pool()
    poolp=tmp_path/'pool.csv'; pool.to_csv(poolp,index=False)
    players={}
    for _,r in pool.iterrows():
        p=r['POS'].split('/')[0]
        ev={'status':'ACTIVE','source_ref':'TEST_CURRENT_ROLE','snap_share':0.7,'role_uncertainty':0.25}
        if p=='RB': ev.update({'carry_share':0.25,'target_share':0.05})
        if p in {'WR','TE'}: ev.update({'route_share':0.55,'target_share':0.15})
        players[r['PLAYER']]=ev
    rolep=tmp_path/'role.json'; rolep.write_text(json.dumps({'players':players,'nflverse_prelock':{'enabled':True,'cache_dir':str(cache),'as_of':'2026-09-13 20:20:00','seasons':[2025]}}))
    market=tmp_path/'market.json'; market.write_text(json.dumps({'current_total':48.0,'open_total':48.0}))
    cfg=nfl.Config(field_size=100,seed=3,player_trials=100,base_trials=100,max_trials=100,test_mode=True)
    cal=nfl._load_calibration(poolp,rolep,market,cfg)
    idx=cal.frame.index[cal.frame.PLAYER.eq('Third Back')][0]
    assert bool(cal.frame.loc[idx,'PRELOCK_RED_ZONE_EVIDENCE_SUPPLIED']) is True
    assert float(cal.frame.loc[idx,'RED_ZONE_OPPORTUNITY'])>0.0
    rec=cal.role_evidence_payload.get('nflverse_prelock_receipt',{})
    assert rec.get('STATUS')=='ENRICHED'
    assert rec.get('POSTLOCK_TARGET_GAME_USED') is False
